# vBRDC282 — Option-B Live TV hero + icon/resource restore

- Restores the proven vBRDC228 tvOS icon metadata/bundle strategy.
- Forces Assets.car into the final .app and copies raw AppIcon + SignalChromeWordmark fallback resources.
- Uses the approved black SIGNAL artwork; no new mockup/artwork generation.
- Reworks Live TV Grid to match Option B: edge-to-edge hero, dark left info gradient, artwork/live preview right, one horizontal six-channel rail.
- Keeps only Grid and Full Guide in the visible switcher.
- Preserves native trailer playback and Aether/KSPlayer architecture.
