# vBRDC283 — Option B parity + v228 icon restore + smaller in-app logo

- Uses the exact vBRDC228 tvOS AppIcon.brandassets metadata/layer strategy with the approved black SIGNAL artwork.
- Keeps raw 1280x768 fallback icon and Signal chrome resource for sideloaders/IPAs that do not decode Assets.car.
- Makes the in-app SIGNAL wordmark slightly smaller.
- Live TV Grid is Option B: full-width hero, dark left information half, artwork/live preview on the right, six-channel rail directly below, smooth artwork-to-live crossfade.
- Grid and Full Guide remain the only user-facing Live TV presentations. List remains migration-only.
- Auto hero preview settles faster (0.9 s) while Live Preview settles at 0.35 s; artwork remains underneath so the hero never blanks during decoder startup.
- Build speed: the icon post-build step now reuses Xcode's existing Assets.car and only runs a fallback actool compile if Assets.car is actually missing.
