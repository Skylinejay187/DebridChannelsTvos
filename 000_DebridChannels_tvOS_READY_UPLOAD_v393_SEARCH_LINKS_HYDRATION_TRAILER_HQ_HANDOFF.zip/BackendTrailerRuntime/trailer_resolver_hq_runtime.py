"""
Debrid Channels backend trailer resolver foundation (v393).

Drop this helper into the backend trailer/remux service. It is intentionally
standalone so the tvOS app upload repo keeps building while backend work can
copy the helper into the real backend tree.

Goals:
- use yt-dlp with cookies.txt support when YouTube requires auth/session cookies
- allow yt-dlp's JS runtime path when YouTube signature/player extraction needs it
- prefer 4K when available, otherwise 1080p+, otherwise best available <= requested cap
- return a single direct URL or remux inputs for the existing backend remux-cache flow
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


@dataclass(frozen=True)
class TrailerRuntimeConfig:
    cookies_path: Optional[str] = None
    node_binary: Optional[str] = None
    prefer_4k: bool = True
    min_height: int = 1080
    max_height: int = 2160


def _existing_file(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    path = Path(value).expanduser()
    return str(path) if path.exists() and path.is_file() else None


def _format_score(fmt: Dict[str, Any], config: TrailerRuntimeConfig) -> tuple[int, int, int, int]:
    height = int(fmt.get("height") or 0)
    width = int(fmt.get("width") or 0)
    vcodec = str(fmt.get("vcodec") or "none").lower()
    acodec = str(fmt.get("acodec") or "none").lower()
    ext = str(fmt.get("ext") or "").lower()
    has_video = vcodec != "none" and height > 0
    has_audio = acodec != "none"
    muxed_bonus = 1 if has_video and has_audio else 0
    mp4_bonus = 1 if ext in {"mp4", "m4v", "mov"} else 0
    preferred_height = 2160 if config.prefer_4k else 1080
    height_score = -abs(preferred_height - min(height, config.max_height))
    if height < config.min_height:
        height_score -= 10_000
    return (muxed_bonus, mp4_bonus, height_score, width)


def select_best_trailer_format(info: Dict[str, Any], config: TrailerRuntimeConfig) -> Optional[Dict[str, Any]]:
    formats = [f for f in info.get("formats", []) if f.get("url") and str(f.get("vcodec") or "none").lower() != "none"]
    if not formats:
        direct_url = info.get("url")
        return {"url": direct_url, "height": info.get("height"), "ext": info.get("ext")} if direct_url else None
    return max(formats, key=lambda fmt: _format_score(fmt, config))


def build_yt_dlp_options(config: TrailerRuntimeConfig) -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "format": f"bestvideo[height<={config.max_height}]+bestaudio/best[height<={config.max_height}]/best",
    }
    cookies = _existing_file(config.cookies_path)
    if cookies:
        opts["cookiefile"] = cookies
    # yt-dlp can use Node for JS player/signature work when available. Keep this
    # optional so backend installs without Node still start normally.
    if config.node_binary:
        opts["js_runtimes"] = {"node": {"executable": config.node_binary}}
    return opts


def resolve_trailer_with_ytdlp(search_or_url: str, config: TrailerRuntimeConfig) -> Optional[Dict[str, Any]]:
    """Return selected direct trailer media info. Caller owns remux-cache handling."""
    from yt_dlp import YoutubeDL  # imported lazily so backend can boot without hard failure in diagnostics

    query = search_or_url if search_or_url.startswith(("http://", "https://")) else f"ytsearch1:{search_or_url} trailer"
    with YoutubeDL(build_yt_dlp_options(config)) as ydl:
        info = ydl.extract_info(query, download=False)
    if not info:
        return None
    if "entries" in info:
        entries: Iterable[Dict[str, Any]] = (entry for entry in info.get("entries") or [] if entry)
        info = next(iter(entries), None)
        if not info:
            return None
    selected = select_best_trailer_format(info, config)
    if not selected:
        return None
    return {
        "title": info.get("title"),
        "webpageUrl": info.get("webpage_url"),
        "formatId": selected.get("format_id"),
        "height": selected.get("height"),
        "ext": selected.get("ext"),
        "url": selected.get("url"),
        "needsRemux": str(selected.get("acodec") or "none").lower() == "none",
    }
