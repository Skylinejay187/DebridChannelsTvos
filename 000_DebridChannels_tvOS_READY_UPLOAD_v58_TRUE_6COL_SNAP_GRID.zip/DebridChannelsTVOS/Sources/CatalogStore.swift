import SwiftUI
import Foundation

struct MediaItem: Identifiable, Hashable {
    let id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StremioManifest: Decodable {
    var name: String?
    var catalogs: [StremioCatalog]?
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?
}

struct StremioMeta: Decodable {
    var id: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case live = "Live TV"
    case settings = "Settings"
    var id: String { rawValue }
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var selectedTab: AppTab = .home
    @Published var status: String = "Build v58 TRUE 6-COLUMN SNAP GRID: top-left landscape hero, bottom-left Continue Watching, right side equal 4x2 portrait grid."
    @Published var menuFocusToken: Int = 0
    @Published var isLoading: Bool = false

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func loadManifest(urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, let manifestURL = URL(string: clean) else {
            status = "Enter a valid Stremio manifest URL."
            return
        }

        isLoading = true
        defer { isLoading = false }

        do {
            let (data, _) = try await URLSession.shared.data(from: manifestURL)
            let manifest = try JSONDecoder().decode(StremioManifest.self, from: data)
            let base = manifestURL.deletingLastPathComponent()
            let catalogs = (manifest.catalogs ?? []).prefix(8)
            var builtRows: [MediaRow] = []

            for catalog in catalogs {
                let type = catalog.type ?? "movie"
                let id = catalog.id ?? "popular"
                let catalogURL = base.appending(path: "catalog").appending(path: type).appending(path: id + ".json")
                do {
                    let (catalogData, _) = try await URLSession.shared.data(from: catalogURL)
                    let response = try JSONDecoder().decode(CatalogResponse.self, from: catalogData)
                    let items = (response.metas ?? []).prefix(24).map { meta in
                        MediaItem(
                            id: meta.id ?? UUID().uuidString,
                            title: meta.name ?? "Untitled",
                            year: Self.firstYear(from: meta.releaseInfo),
                            type: meta.type ?? type,
                            catalog: catalog.name ?? id.capitalized,
                            description: meta.description ?? "No description available yet.",
                            genres: Array((meta.genres ?? [type.capitalized, "Cinema"]).prefix(3)),
                            rating: meta.imdbRating ?? "—",
                            posterURL: Self.highest(meta.poster),
                            landscapeURL: Self.highest(meta.background ?? meta.poster),
                            logoURL: Self.highest(meta.logo)
                        )
                    }
                    if !items.isEmpty {
                        builtRows.append(MediaRow(id: "\(type)-\(id)", title: catalog.name ?? id.capitalized, items: items))
                    }
                } catch {
                    continue
                }
            }

            if builtRows.isEmpty {
                status = "No catalog rows returned. Demo rows kept."
            } else {
                rows = builtRows
                let manifestName = manifest.name ?? "manifest"
                status = "Loaded \(builtRows.count) rows from \(manifestName)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo, text.count >= 4 else { return "2026" }
        return String(text.prefix(4))
    }

    static func highest(_ url: String?) -> String? {
        guard var u = url, !u.isEmpty else { return nil }
        u = u.replacingOccurrences(of: "w92", with: "original")
        u = u.replacingOccurrences(of: "w154", with: "original")
        u = u.replacingOccurrences(of: "w185", with: "original")
        u = u.replacingOccurrences(of: "w342", with: "original")
        u = u.replacingOccurrences(of: "w500", with: "original")
        u = u.replacingOccurrences(of: "w780", with: "original")
        return u
    }

    static func demoRows() -> [MediaRow] {
        let items: [MediaItem] = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "movie", catalog: "Featured", description: "A temporary small-town sheriff uncovers a violent mystery after a bank robbery exposes a deeper conspiracy.", genres: ["Action", "Crime", "Thriller"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "apex", title: "APEX", year: "2026", type: "movie", catalog: "Featured", description: "A climber enters a hidden cave system and finds the rescue mission was never about saving him.", genres: ["Adventure", "Thriller"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "red", title: "RED SIGNAL", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators through a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "BLUE FALL", year: "2026", type: "movie", catalog: "Featured", description: "A detective wakes in a fractured digital city with one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "circle", title: "THE CIRCLE", year: "2026", type: "movie", catalog: "Featured", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "cinema", title: "CENTRAL CINEMA", year: "2026", type: "movie", catalog: "Featured", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "THE LOST PATH", year: "2026", type: "movie", catalog: "Featured", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "STORMLINE", year: "2026", type: "movie", catalog: "Featured", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "night", title: "NIGHT RUN", year: "2026", type: "movie", catalog: "Featured", description: "A driver with no name carries the wrong package across the city before sunrise.", genres: ["Action", "Neo-Noir"], rating: "7.4", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "harbor", title: "HARBOR BLACK", year: "2026", type: "series", catalog: "Featured", description: "A dockside murder opens a case that reaches every powerful family in the city.", genres: ["Series", "Crime"], rating: "7.6", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed())),
            MediaRow(id: "shows", title: "Shows", items: items.map { item in var copy = item; copy.type = "series"; return copy })
        ]
    }
}
