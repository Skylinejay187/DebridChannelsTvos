Debrid Channels tvOS v43 stable geometry 1+8 layout with reduced internal poster glow. Preserves v14 Signulous-compatible packaging.
