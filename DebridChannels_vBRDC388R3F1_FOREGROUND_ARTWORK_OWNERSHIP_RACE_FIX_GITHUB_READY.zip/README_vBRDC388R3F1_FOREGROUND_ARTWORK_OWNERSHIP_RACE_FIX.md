# vBRDC388R3F1 — Foreground Artwork Ownership Race Fix

Version 1.0.1097 / build 1097.

This patch preserves vBRDC388R3 single-active-surface runtime quiescence and fixes the first-presentation VOD artwork race that remained in vBRDC388R1.

- Foreground VOD artwork ownership is now explicit; Aether exclusive-playback entry no longer cancels already-mounted playback artwork requests.
- Hidden-overlay cleanup uses actual playback-artwork ownership instead of a <=640px heuristic.
- Mounted blank rehydration preserves `forceVisiblePlaybackPublication` instead of silently downgrading the loader on retry.
- Catalog/decorative/background artwork remains quiescent during playback.
- No Kingfisher dependency was added; Signal adopts the durable ownership/request-lifecycle behavior in its existing loader.

Physical Apple TV acceptance: cold launch -> VOD -> first overlay must populate title/logo and Spotlight Related artwork; first Cast Explorer and Episodes visits must populate without close/reopen.
