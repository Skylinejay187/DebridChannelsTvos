# vBRDC384 / 1.0.1086 / build 1086 — Phase 2 Live TV Timeshift

Base: vBRDC383R7 physical-Apple-TV-confirmed Live playback.

## Regression locks
- Preserve R7 Live audio look-ahead and smooth video/deinterlace path.
- Preserve R3 navigation, catalog exit, top menu and Signal-logo behavior.
- Preserve ambient lifecycle correction.
- No Signal-server media proxying. DVR data is Apple-TV-local only.

## Phase 2
- Raw HDHomeRun/generic transport Live sessions use Aether's existing #107 reader/feeder DVR architecture with a 30-minute requested rolling window.
- Aether remains authoritative for disk budgeting/eviction and deletes the ring on teardown/channel change.
- Live controls add Rewind 30s, Pause/Resume, Forward 60s and Go Live.
- Seek bounds come from Aether PlaybackClock.seekableLiveRange; Signal does not invent a seekable window.
- Go Live calls AetherEngine.seekToLiveEdge().
- Live edge / behind-live state is bridged to the app without adding a second playback clock.
- FiOS/native HLS route policy is unchanged from R7; timeshift UI activates only where Aether publishes a DVR seekable range.
