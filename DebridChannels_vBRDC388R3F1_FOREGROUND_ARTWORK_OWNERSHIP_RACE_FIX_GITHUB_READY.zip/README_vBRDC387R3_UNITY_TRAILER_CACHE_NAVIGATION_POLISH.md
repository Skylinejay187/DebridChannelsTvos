# vBRDC387R3 — Unity / Trailer / Cache / Navigation Polish

Base: vBRDC387R2 (physically confirmed approved ambient appearance).
Version: 1.0.1092 (1092). Release ID: vBRDC387R3.

## R3 changes
- VOD cached-ahead scrubber state now accepts every throttled Aether buffer notification, even while player chrome is hidden. Opening the scrubber no longer depends on a Play/Pause state change to publish the latest endpoint.
- Full trailer ownership pauses an already-playing VOD session in place and resumes it after trailer teardown without deliberately seeking or destroying the VOD session.
- Embedded trailer-from-VOD is permanently pinned to Aether with display matching disabled, preserving the current VOD display mode and avoiding trailer-triggered HDR/SDR/frame-rate renegotiation. Normal catalog trailers retain their existing display-match policy.
- Yellow removed from VOD subtitle color choices. White, Cyan, Green remain.
- Preview Mirror first-row Up now reveals/focuses the auto-hidden top menu directly; it no longer routes through the removed upper-right GRID/GUIDE chip.
- Live D-pad debounce reduced from 160ms to 100ms for a less sluggish grid/menu handoff while retaining duplicate-event protection.
- Preview Mirror Unity background ownership resumes immediately after a catalog overlay closes, even while the selected top-menu tab remains a catalog tab. Catalog-open still fully unmounts decorative animation. This removes the black base that previously waited for Down-to-Live.

## Regression locks
- Preserve exact vBRDC387R2 Classic Smoke appearance.
- Catalog/Guide/Settings/Media Info/search/full-screen playback/Live preview/background state still suspend decorative renderers.
- Preserve R7 Live playback stability, Phase 2 timeshift, VOD disk cache, amplification, subtitle cue behavior, Preview Mirror chrome/logo/navigation, and existing trailer resolver.

## Physical Apple TV validation
Syntax/plist validation cannot prove runtime behavior. Verify cache growth while paused/playing without Play/Pause refresh, trailer/VOD pause-resume ownership, embedded trailer no display-mode flash, top-menu reveal, catalog exit zero-black-frame restoration, and rapid Live grid/menu scrolling.
