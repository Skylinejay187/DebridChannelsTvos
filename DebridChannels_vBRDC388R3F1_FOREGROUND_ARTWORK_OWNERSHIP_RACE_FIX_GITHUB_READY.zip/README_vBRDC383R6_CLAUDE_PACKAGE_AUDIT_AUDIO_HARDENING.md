# vBRDC383R6 — Phase 1 Claude-package audit + Live audio hardening

Base: vBRDC383R5 (which itself is the accepted vBRDC383R3 rollback lineage).
Marketing/build remain 1.0.1085 / 1085. Phase 2 vBRDC384 is NOT started.

## Audit findings
- Claude package modified only `Sources/AetherPlaybackBridge/...`; the app packages `Vendor/AetherPlaybackKit/...`, so those advertised changes would not have reached runtime.
- Claude `DirectURLStreamReader` was rejected: Aether 6.89.1 `MediaSource.custom` requires an `IOReader` (`read`, `seek`, `close`), not an NSObject exposing URL/header methods.
- Claude software -> automatic -> software route cycle was rejected. Existing bounded R3/R5 routing remains.
- Claude watchdog increases were rejected as unrelated to the observed post-start audio death.
- The package is not renamed vBRDC384 because that version remains reserved for Phase 2 timeshift after physical audio confirmation.

## Safe ideas retained
- Preserve/reapply an explicitly selected Live TV audio track across internal Aether retunes/reloads; clear it on a real session stop.
- Expand `audioDelivery` diagnostics with route, source profile and first-frame state.
- Both bridge copies are synchronized so the packaged Vendor bridge actually contains the changes.

## Preserved from vBRDC383R5
- R3 navigation/top-menu/logo behavior; no R4 lifecycle/navigation/logo changes.
- Ambient animation is unmounted outside the active visible Live TV dashboard/grid.
- Aether 6.89.1 Phase-1 patch enabling bounded audio decoupling/look-ahead for Live software playback without enabling DVR/timeshift.
- FiOS native-HLS-first split and VOD paths remain unchanged.

Physical Apple TV validation is still required. Phase 1 remains open until Live TV audio is continuous.
