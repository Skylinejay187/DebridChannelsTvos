# vBRDC385 — Phase 3: VOD Smart Cache + Subtitle Timing + Volume Amplification

Base: vBRDC384F3, physically confirmed Live TV timeshift.

- Adds a cyan Live TV timeshift cache rail with white playhead.
- Enables Aether disk-backed VOD forward caching with an adaptive 90–180 segment window from existing Source Intelligence hints. Aether retains control of disk budgeting/eviction.
- Fixes subtitle paragraph accumulation by rendering only cues active at Aether source time; existing subtitle delay is applied on the same clock.
- Implements VOD-only Off/+3/+6/+9/+12 dB decoded PCM gain. Gain >0 uses Aether software decode; Off preserves normal Aether routing. Live TV stays isolated at 0 dB.
- Preserves R7 Live playback and v384F3 timeshift behavior.

## VOD clock / resume correctness — required Phase 3 follow-up
Physical report carried into this phase: while a movie/show is playing the displayed playhead can advance about two seconds faster than wall-clock playback, and Catalog Resume has reopened roughly seven minutes ahead of the user's true last position. Treat these as one timing-integrity investigation: compare Aether source clock, PlaybackController snapshot, UI presentation clock, local resume checkpoint, Trakt checkpoint, seek landing/keyframe tolerance, and teardown/background saves. Do not paper over this by subtracting a fixed offset. Phase 4 must regression-test long playback, Catalog exit/re-entry, app background/foreground, source failover, seek, pause/resume, and Trakt/local checkpoint arbitration after the root cause is corrected.
