# vBRDC388 — Final VOD Trailer Display Handoff Hardening

Version: 1.0.1093 (1093)
Base: vBRDC387R3F1

## Physical regression lock
VOD-overlay trailer playback is already physically confirmed smooth on Apple TV. This phase does not retune cadence, source selection, or the approved trailer presentation.

## Change
When display matching is disabled for an embedded VOD trailer, Signal now tells Aether to suppress display criteria entirely in addition to disabling match-content. This closes the teardown/return path that could still let tvOS renegotiate HDR/SDR or refresh criteria as the temporary trailer engine is destroyed.

- Catalog/main-screen trailers retain normal display matching policy.
- Trailer launched over active VOD remains Aether-only and display-match disabled.
- Embedded trailer teardown suppresses Aether display criteria, so returning to the preserved VOD presentation should not request a new display mode.
- Existing smooth trailer cadence is untouched.
- Existing VOD position/state preservation is untouched.
- R2 ambient appearance, R3 Unity/navigation/cache work, Live R7, timeshift, subtitles and amplification remain regression locks.

## Physical test
1. Start HDR/Dolby Vision or SDR VOD with tvOS Match Dynamic Range / Match Frame Rate enabled.
2. Open its trailer from the VOD overlay.
3. Confirm no unwanted mode flash on entry.
4. Close the trailer.
5. Confirm the original VOD resumes without an HDMI/display-mode black flash.
6. Separately verify a Catalog trailer still follows normal tvOS matching policy.
