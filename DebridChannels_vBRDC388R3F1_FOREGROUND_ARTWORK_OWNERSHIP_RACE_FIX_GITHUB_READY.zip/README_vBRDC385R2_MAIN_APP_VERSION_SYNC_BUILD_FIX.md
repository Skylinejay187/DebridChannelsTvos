# vBRDC385R2 — Phase 3 Main App Version Sync Build Fix

Base: vBRDC385R1 / 1.0.1087 / build 1087.

GitHub Actions run logs_99964598845 failed in the version-validation build phase because the generated main app Info.plist still declared 1.0.1086 / 1086 while project.yml and Top Shelf declared 1.0.1087 / 1087.

R2 changes only Sources/Info.plist to CFBundleShortVersionString 1.0.1087 and CFBundleVersion 1087. No VOD disk-cache, scrubber, subtitles, amplification, Live TV, timeshift, navigation, logo, catalog, or ambient behavior is changed.
