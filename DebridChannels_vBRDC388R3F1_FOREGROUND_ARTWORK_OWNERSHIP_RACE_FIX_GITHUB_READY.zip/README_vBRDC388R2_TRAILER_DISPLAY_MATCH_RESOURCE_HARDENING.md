# vBRDC388R2 — Trailer Display-Match + Resource Hardening

Patch-forward from vBRDC388R1.

- Disables tvOS dynamic-range/frame-rate display matching for **all built-in trailer playback**, not only the VOD-overlay call site.
- Fixes the second TrailerPopup path that still inherited `allowDisplayMatch = true`.
- Forces built-in trailers through one Aether playback lane with display criteria suppressed.
- Removes trailer-only animated glow/sweep and heavy live-video shadows while the decoder is active, reserving compositor/GPU budget for Aether and tvOS system overlays such as volume and Control Center.
- Preserves vBRDC388/R1 VOD, artwork, overlay, cast/episode, timeshift/cache, navigation, and approved ambient behavior.

Physical Apple TV validation required: trailer must not trigger HDMI range/frame-rate black flash on enter/exit, and volume/Control Center should remain responsive while trailer video is playing.
