# Signal tvOS — vBRDC383 / 1.0.1085 / build 1085
## Phase 1 — Aether Live Audio Stability

Authoritative source: vBRDC382 / 1.0.1084 / build 1084. Patch-forward only.

### Root-path audit finding
`project.yml` embeds the local SwiftPM package at `Vendor/AetherPlaybackKit`. Therefore the runtime Aether bridge is `Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift`.

vBRDC382 also contained a newer-looking bridge copy under `Sources/AetherPlaybackBridge`, but that file is not the bridge compiled by the local AetherPlaybackKit package. The packaged Vendor bridge still selected `.fastZap` and `liveJoinStartsImmediately = true` for Live TV, while the newer source copy reflected the intended `.standard` reliability profile. This source/package drift could make prior stabilization appear present in source while physical Apple TV still executed the older live join behavior.

### vBRDC383 changes
- Patched the actual packaged Vendor Aether bridge; synchronized the non-package bridge copy to prevent future drift.
- Live TV uses `liveJoinProfile = .standard` on initial load and every Aether recovery route.
- Live TV sets `liveJoinStartsImmediately = false` on initial load and every recovery route.
- Added Aether 6.89.x `audioDelivery` observation. `.droppedNoPipeline` is treated as a real unhealthy audio path and enters the existing bounded Aether recovery/retune path.
- Preserved native remote-HLS → explicit HLS ingest → software-decode recovery routing.
- Preserved bounded probe/analyze limits and existing first-frame correctness.
- Added physical-device diagnostics under `[Signal][AetherLive][vBRDC383]` for route/reason, playback phase, audio delivery, first frame, `liveSourceReset`, and bounded retune decisions.
- Recovery messages now retain the actual trigger (source reset, audio-delivery failure, or Aether state error).

### Explicit Phase 1 scope lock
- No Live TV DVR/timeshift window is enabled in this build.
- No VOD progressive cache is added.
- No UI/navigation/Preview Mirror/catalog/logo/wallpaper/smoke/deadlight/membership redesign.
- AetherEngine remains the primary and only active internal playback family.

### Physical Apple TV acceptance gate
Do not mark Phase 1 fixed from compile/syntax validation. Test dashboard/guide/focused previews and full-screen Live TV on physical Apple TV, including channel changes and background/foreground. Audio must remain continuous. If a cutout occurs, capture the `[Signal][AetherLive][vBRDC383]` lines around the event; they identify the active route and Aether signal that triggered recovery.
