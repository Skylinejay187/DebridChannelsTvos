# vBRDC383R7 — Phase 1 Live Video Smoothness

Base: vBRDC383R6. Physical Apple TV testing indicates the R6 Live audio starvation correction is effective. R7 keeps the diagnosis but removes the temporary live use of Aether's VOD parked-video FIFO, because Aether 6.89.1 itself documents that this mechanism can make queued video late and visibly skip when software 1080i decode/deinterlace is near realtime.

For raw transport Live sources (HDHomeRun and generic MPEG-TS), R7 supplies a small 30-second internal `dvrWindowSeconds` so Aether selects its #107 live reader/feeder architecture. That path has the engine's independent audio look-ahead pump and keeps source reading independent from video-renderer backpressure. No Signal timeshift controls are exposed; this is an internal playback-stability ring only. User-facing timeshift remains vBRDC384.

The bridge also explicitly selects Aether's `.auto` deinterlacer and `.field` hardware cadence for raw transport Live sources: `yadif_videotoolbox`/Metal at field rate when available, with Aether's CPU fallback if hardware setup cannot engage.

Regression locks: R3 navigation/exit/top-menu/logo behavior remains untouched; R5 ambient lifecycle remains; R6 audio-track persistence/diagnostics remain; HLS/FiOS and VOD route policy is unchanged.

Physical Apple TV validation remains authoritative. Test HDHomeRun 1080i/720p channels plus the premium Live streams that previously showed cadence glitches. Confirm continuous audio and smooth motion before Phase 1 is closed.
