# vBRDC386R1 — Phase 4 Playback Polish

Base: vBRDC386 / 1.0.1088 / build 1088
Version: 1.0.1089 / build 1089

## Physical-test corrections

- VOD amplification changes no longer reload the Aether VOD source when moving between Off / +3 / +6 / +9 / +12 dB. Gain is applied to the active decoded-audio path in-session so the playhead/cache session is not deliberately restarted.
- Existing audio-track selection remains in-session and re-applies the selected amplification after Aether finishes the track transition.
- Removed the translucent black/gray rounded subtitle background from the Aether VOD subtitle overlay.
- Subtitle text keeps the existing dark shadow for readability.
- Added persistent VOD subtitle text colors: White, Yellow, Cyan, Green.
- Subtitle color changes are presentation-only and do not reload playback or change subtitle timing/track selection.

## Regression locks

No intentional changes to Live TV R7 stability, Live timeshift, VOD disk-cache policy/cleanup, cache scrubber refresh, catalog/navigation/logo behavior, or ambient lifecycle.
