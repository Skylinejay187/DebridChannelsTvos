import SwiftUI
import AVKit
import Combine
import UIKit

private func streamStatusText(_ message: String) -> String {
    let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
    let lower = trimmed.lowercased()
    if trimmed.isEmpty || lower.contains("trailer resolver") || lower.contains("resolving trailer") || lower == "trailer ready." || lower.contains("split video/audio") {
        return ""
    }
    return trimmed
}

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct StaticAppBackground: View {
    var body: some View {
        ZStack {
            Color.black
            LinearGradient(
                colors: [Color.black.opacity(0.96), Color(red: 0.018, green: 0.022, blue: 0.028), Color.black.opacity(0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

struct HomeArtworkBackground: View {
    let item: MediaItem

    private var backgroundURL: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black
            RemoteImageFit(url: backgroundURL, mode: .fill)
                .ignoresSafeArea()
                .scaleEffect(1.01)
                .opacity(0.86)
                .saturation(1.08)
                .contrast(1.04)
            // Keep the home readable without blurring or washing out the selected artwork.
            LinearGradient(
                colors: [Color.black.opacity(0.58), Color.black.opacity(0.28), Color.black.opacity(0.72)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
    }
}


struct PreviewAwareHomeBackground: View {
    let item: MediaItem
    let previewActive: Bool

    var body: some View {
        ZStack {
            // Static clean background.
            Color.clear
            if previewActive, let preview = item.previewURL, let url = URL(string: preview) {
                SilentVideoBackground(url: url)
                    .ignoresSafeArea()
                    .opacity(0.94)
                    .overlay(Color.black.opacity(0.30))
                    .transition(.opacity.animation(.easeInOut(duration: 0.35)))
            }
        }
        .ignoresSafeArea()
    }
}

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL
    var isMuted: Bool = true

    final class Coordinator {
        var player: AVPlayer?
        var endObserver: NSObjectProtocol?

        func configure(url: URL, isMuted: Bool, controller: AVPlayerViewController) {
            if let current = player?.currentItem?.asset as? AVURLAsset, current.url == url {
                player?.isMuted = isMuted
                player?.volume = isMuted ? 0.0 : 1.0
                controller.player = player
                controller.showsPlaybackControls = false
                controller.videoGravity = .resizeAspectFill
                player?.play()
                return
            }

            cleanup()

            let item = AVPlayerItem(url: url)
            let nextPlayer = AVPlayer(playerItem: item)
            nextPlayer.isMuted = isMuted
            nextPlayer.volume = isMuted ? 0.0 : 1.0
            item.preferredForwardBufferDuration = isMuted ? 0.0 : 1.0
            controller.player = nextPlayer
            controller.showsPlaybackControls = false
            controller.videoGravity = .resizeAspectFill
            endObserver = NotificationCenter.default.addObserver(
                forName: .AVPlayerItemDidPlayToEndTime,
                object: item,
                queue: .main
            ) { [weak nextPlayer] _ in
                nextPlayer?.seek(to: .zero)
                nextPlayer?.play()
            }
            player = nextPlayer
            nextPlayer.play()
        }

        func cleanup() {
            if let endObserver {
                NotificationCenter.default.removeObserver(endObserver)
                self.endObserver = nil
            }
            player?.pause()
            player?.replaceCurrentItem(with: nil)
            player = nil
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        context.coordinator.configure(url: url, isMuted: isMuted, controller: controller)
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        context.coordinator.configure(url: url, isMuted: isMuted, controller: controller)
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        coordinator.cleanup()
        controller.player = nil
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    @State private var didRequestDefaultCatalogLoad = false

    var body: some View {
        ZStack(alignment: .top) {
            // v220: Careful slot-panel rebuild approach. Live TV grid remains the main surface,
            // the normal top menu is restored, and Movies/Shows/Home open as focus-owned overlay shelves.
            // The left quick controls are completely off-screen until LEFT is pressed on the first grid column.
            if store.selectedTab == .settings {
                SettingsScreen()
            } else if store.selectedTab == .membership {
                MembershipScreen()
                    .zIndex(4300)
            } else {
                let catalogOverlayActive = (store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows)
                LiveTVScreen()
                    .disabled(catalogOverlayActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                    .allowsHitTesting(!(catalogOverlayActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil))
                if catalogOverlayActive {
                    GridOSCatalogOverlay(filter: store.selectedTab == .movies ? "movie" : (store.selectedTab == .shows ? "series" : nil))
                        .disabled(store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                        .allowsHitTesting(store.selectedDetail == nil && !store.searchActive && store.playbackURL == nil)
                        .zIndex(4200)
                }
            }

            if store.playbackURL == nil && !store.searchActive && store.selectedDetail == nil && !store.liveQuickPanelOpen {
                TopMenuBar()
                    .zIndex(6100)
            }

            if let detail = store.selectedDetail {
                MediaInfoPopup(item: detail)
                    .zIndex(5500)
            }

            if store.searchActive && store.playbackURL == nil {
                GlobalSearchScreen()
                    .zIndex(5000)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .id(url.absoluteString)
                    .zIndex(9000)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V442_TRAILER_SESSION_COMPILE_FIX") }
        .task {
            guard !didRequestDefaultCatalogLoad else { return }
            didRequestDefaultCatalogLoad = true
            await store.loadAllManifests()
        }
    }
}

struct LiveClockText: View {
    @State private var now = Date()
    private let timer = Timer.publish(every: 30, on: .main, in: .common).autoconnect()
    private static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .none
        f.timeStyle = .short
        return f
    }()

    var body: some View {
        Text(Self.formatter.string(from: now))
            .font(.system(size: 18, weight: .semibold, design: .rounded))
            .foregroundStyle(.white.opacity(0.72))
            .monospacedDigit()
            .onReceive(timer) { now = $0 }
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                // v205: no visible app logo/brand in menu; native transparent top menu with real-time clock and stable focus position.
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: 96)
                    .ignoresSafeArea(edges: .top)

                HStack(spacing: 42) {
                    ForEach(AppTab.allCases) { tab in
                        VStack(spacing: 7) {
                            Text(tab.rawValue == "Shows" ? "TV Shows" : tab.rawValue)
                                .font(.system(size: 25, weight: (focusedTab == tab || store.selectedTab == tab) ? .semibold : .regular, design: .rounded))
                                .tracking(0.2)
                                .foregroundStyle(focusedTab == tab ? Color.black : (store.selectedTab == tab ? Color.white : Color.white.opacity(0.62)))
                                .padding(.horizontal, focusedTab == tab ? 22 : 12)
                                .padding(.vertical, focusedTab == tab ? 9 : 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .fill(focusedTab == tab ? Color.white.opacity(0.92) : Color.clear)
                                        .shadow(color: focusedTab == tab ? Color.cyan.opacity(0.25) : .clear, radius: 8, x: 0, y: 0)
                                )
                            Capsule()
                                .fill(store.selectedTab == tab ? Color.orange : Color.clear)
                                .frame(width: tab.rawValue == "Settings" ? 64 : 54, height: 4)
                                .shadow(color: store.selectedTab == tab ? .orange.opacity(0.55) : .clear, radius: 8)
                        }
                        .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .scaleEffect(focusedTab == tab ? 1.018 : 1.0)
                        .focusable(true)
                        .focused($focusedTab, equals: tab)
                        .modifier(TransparentTVFocusVisual())
                        .onTapGesture {
                            withAnimation(.easeInOut(duration: 0.26)) {
                                store.selectedTab = tab
                                store.selectedDetail = nil
                                store.detailBackStack.removeAll()
                            }
                        }
                    }
                }
                .position(x: geo.size.width * 0.46, y: 58)
                .focusSection()

                HStack(spacing: 28) {
                    Button {
                        store.searchActive = true
                        store.status = "Search opened. Results include loaded Stremio/Cinemeta/service rows and configured catalog rows."
                    } label: {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundStyle(searchFocused ? Color.orange : Color.white.opacity(0.78))
                            .frame(width: 48, height: 48)
                            .background(Circle().fill(Color.clear))
                    }
                    .buttonStyle(.plain)
                    .focused($searchFocused)
                    .modifier(TransparentTVFocusVisual())

                    LiveClockText()
                }
                .position(x: geo.size.width - max(150, geo.size.width * 0.078), y: 58)
            }
            .frame(width: geo.size.width, height: 100, alignment: .top)
        }
        .frame(height: 122)
        .background(Color.clear.ignoresSafeArea(edges: .top))
        .zIndex(6000)
        .focusSection()
        .onMoveCommand { direction in
            if direction == .down {
                store.topMenuFocusLocked = false
                store.contentFocusToken += 1
                focusedTab = nil
                searchFocused = false
            }
        }
        .onChange(of: store.menuFocusToken) { _ in
            store.topMenuFocusLocked = true
            focusedTab = store.selectedTab
            searchFocused = false
        }
        .onChange(of: focusedTab) { newTab in
            // v203: do not auto-open sections while sliding across the top menu.
            // This keeps the search icon reachable and matches the requested manual selection behavior.
            if newTab != nil { store.topMenuFocusLocked = true }
        }
    }
}

struct GlobalSearchScreen: View {
    @EnvironmentObject var store: CatalogStore
    @StateObject private var liveModel = LiveTVSourceModel()
    @AppStorage("tmdbApiKey") private var tmdbApiKey: String = ""
    @State private var query: String = ""
    @State private var tmdbResults: [MediaItem] = []
    @State private var tmdbSearchToken: Int = 0
    @State private var isSearchingTMDB: Bool = false
    @FocusState private var focusedID: String?
    @FocusState private var focusedChannelID: Int?

    private var catalogResults: [MediaItem] {
        query.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 ? store.searchResults(for: query) : []
    }

    private var mergedMediaResults: [MediaItem] {
        var seen = Set<String>()
        let merged = catalogResults + tmdbResults
        return merged.filter { seen.insert($0.id).inserted }
    }

    private var liveResults: [LiveTVChannel] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard trimmed.count >= 2 else { return [] }
        let channels = liveModel.channels
        return Array(channels.filter { channel in
            [channel.number, channel.name, channel.category, channel.source, channel.now, channel.next]
                .joined(separator: " ")
                .lowercased()
                .contains(trimmed)
        }.prefix(80))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.opacity(0.94).ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.98), .black.opacity(0.72), .black.opacity(0.96)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()

            VStack(alignment: .leading, spacing: 22) {
                Spacer().frame(height: 116)
                HStack(alignment: .lastTextBaseline, spacing: 18) {
                    Text("Universal Search")
                        .font(.system(size: 58, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(tmdbApiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Catalogs + Live TV" : "Catalogs + TMDB + Live TV")
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .foregroundStyle(.cyan.opacity(0.82))
                }

                TextField("Search movies, shows, Cinemeta/Stremio catalogs, TMDB, Xtream/M3U/Channels DVR…", text: $query)
                    .font(.system(size: 31, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 28)
                    .frame(width: 1240, height: 74)
                    .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.10)))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.16), lineWidth: 1))
                    .onChange(of: query) { _ in scheduleTMDBSearch() }

                if isSearchingTMDB {
                    Text("Searching TMDB with this Apple TV's saved key…")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                }

                if query.trimmingCharacters(in: .whitespacesAndNewlines).count < 2 {
                    Text("Type to search movies, shows, and Live TV channels.")
                        .font(.system(size: 22, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.56))
                        .padding(.top, 12)
                }

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 30) {
                        if !liveResults.isEmpty {
                            Text("Live TV Channels")
                                .font(.system(size: 25, weight: .black, design: .rounded))
                                .foregroundStyle(.white.opacity(0.92))
                            LazyVGrid(columns: Array(repeating: GridItem(.fixed(278), spacing: 28), count: 5), spacing: 28) {
                                ForEach(liveResults) { channel in
                                    Button {
                                        store.searchActive = false
                                        store.selectedTab = .live
                                    } label: {
                                        SearchLiveChannelCard(channel: channel, isFocused: focusedChannelID == channel.id)
                                    }
                                    .buttonStyle(.plain)
                                    .focusEffectDisabled()
                                    .focused($focusedChannelID, equals: channel.id)
                                    .modifier(TransparentTVFocusVisual())
                                }
                            }
                        }

                        if !mergedMediaResults.isEmpty {
                            Text("Movies & Shows")
                                .font(.system(size: 25, weight: .black, design: .rounded))
                                .foregroundStyle(.white.opacity(0.92))
                            LazyVGrid(columns: Array(repeating: GridItem(.fixed(278), spacing: 28), count: 5), spacing: 34) {
                                ForEach(mergedMediaResults) { item in
                                    Button {
                                        Task {
                                            let hydrated = await store.searchHydratedDetailItem(for: item, query: query, tmdbApiKey: tmdbApiKey)
                                            store.searchActive = false
                                            store.openDetail(hydrated, pushCurrent: false)
                                        }
                                    } label: {
                                        SearchResultCard(item: item, isFocused: focusedID == item.id)
                                    }
                                    .buttonStyle(.plain)
                                    .focused($focusedID, equals: item.id)
                                    .modifier(TransparentTVFocusVisual())
                                }
                            }
                        }
                    }
                    .padding(.bottom, 140)
                }
                .frame(maxHeight: 690)
            }
            .padding(.leading, 86)
        }
        .onAppear {
            liveModel.loadCachedOrDemo()
            Task { await liveModel.refreshIfNeeded() }
            focusedID = mergedMediaResults.first?.id
        }
        .onExitCommand { store.searchActive = false }
    }

    private func scheduleTMDBSearch() {
        tmdbSearchToken += 1
        let token = tmdbSearchToken
        let currentQuery = query
        let key = tmdbApiKey
        guard currentQuery.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2,
              !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            tmdbResults = []
            isSearchingTMDB = false
            return
        }
        isSearchingTMDB = true
        Task {
            try? await Task.sleep(nanoseconds: 320_000_000)
            guard token == tmdbSearchToken else { return }
            let results = await store.tmdbSearchResults(for: currentQuery, apiKey: key)
            await MainActor.run {
                guard token == tmdbSearchToken else { return }
                tmdbResults = results
                isSearchingTMDB = false
            }
        }
    }
}

struct SearchResultCard: View {
    let item: MediaItem
    let isFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                .frame(width: 278, height: 156)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            Text(item.title)
                .font(.system(size: 22, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
            Text("\(item.year) • \(item.catalog)")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.54))
                .lineLimit(1)
        }
        .frame(width: 278, alignment: .leading)
        .scaleEffect(isFocused ? 1.065 : 1.0)
        .offset(y: isFocused ? -8 : 0)
        .shadow(color: isFocused ? .black.opacity(0.78) : .black.opacity(0.38), radius: isFocused ? 24 : 10, y: isFocused ? 18 : 6)
        .animation(.spring(response: 0.24, dampingFraction: 0.76), value: isFocused)
    }
}

struct SearchLiveChannelCard: View {
    let channel: LiveTVChannel
    let isFocused: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.24))
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFit().padding(10)
                        default: Text(channel.logo).font(.system(size: 25, weight: .black)).foregroundStyle(.white)
                        }
                    }
                } else {
                    Text(channel.logo).font(.system(size: 25, weight: .black)).foregroundStyle(.white)
                }
            }
            .frame(width: 74, height: 58)
            VStack(alignment: .leading, spacing: 5) {
                Text(channel.name).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1)
                Text("\(channel.number) • \(channel.source)").font(.system(size: 14, weight: .heavy)).foregroundStyle(.white.opacity(0.62)).lineLimit(1)
                Text(channel.now).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
            }
        }
        .padding(14)
        .frame(width: 278, height: 94, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(isFocused ? Color.white.opacity(0.16) : Color.white.opacity(0.07)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(isFocused ? Color.cyan.opacity(0.65) : Color.white.opacity(0.10), lineWidth: isFocused ? 2 : 1))
        .scaleEffect(isFocused ? 1.07 : 1.0)
        .offset(y: isFocused ? -7 : 0)
        .shadow(color: .black.opacity(isFocused ? 0.78 : 0.32), radius: isFocused ? 24 : 10, y: isFocused ? 18 : 6)
        .animation(.spring(response: 0.24, dampingFraction: 0.76), value: isFocused)
    }
}



// MARK: - v220 Grid Overlay Catalog Shelves
struct GridOSCatalogOverlay: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    let filter: String?
    @FocusState private var focusedRow: Int?
    @State private var selectedIndices: [String: Int] = [:]

    private var overlayTitle: String {
        if filter == "movie" { return "Movies" }
        if filter == "series" { return "TV Shows" }
        return "Streaming Catalogs"
    }

    private var rows: [MediaRow] {
        let source = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        if let filter {
            return source.compactMap { row in
                let items = row.items.filter { $0.type == filter }
                guard !items.isEmpty else { return nil }
                return MediaRow(id: row.id + "-slot-overlay-" + filter, title: row.title, items: Array(items.prefix(28)))
            }
        }
        return source.map { MediaRow(id: $0.id + "-slot-overlay", title: $0.title, items: Array($0.items.prefix(28))) }
    }

    private var focusedBackdropItem: MediaItem? {
        guard !rows.isEmpty else { return nil }
        let rowIndex = min(max(focusedRow ?? 0, 0), rows.count - 1)
        let row = rows[rowIndex]
        guard !row.items.isEmpty else { return nil }
        let selected = min(max(selectedIndices[row.id, default: 0], 0), row.items.count - 1)
        return row.items[selected]
    }

    private var focusedBackdropURL: String? {
        guard let item = focusedBackdropItem else { return nil }
        return item.landscapeURL ?? item.posterURL
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottomLeading) {
                // Main Grid OS surface stays clean; Movies/Shows panel owns its focused-card backdrop.
                Color.clear
                    .ignoresSafeArea()
                    .contentShape(Rectangle())

                VStack(alignment: .leading, spacing: 10) {
                    overlayHeader

                    ScrollViewReader { proxy in
                        ScrollView(.vertical, showsIndicators: false) {
                            LazyVStack(alignment: .leading, spacing: 12) {
                                ForEach(Array(rows.prefix(7).enumerated()), id: \.element.id) { rowIndex, row in
                                    GridOSFixedSlotCatalogRail(
                                        row: row,
                                        rowIndex: rowIndex,
                                        focusedRow: $focusedRow,
                                        selectedIndex: Binding(
                                            get: { selectedIndices[row.id, default: 0] },
                                            set: { selectedIndices[row.id] = $0 }
                                        )
                                    )
                                    .id(row.id)
                                    .onChange(of: focusedRow) { value in
                                        if value == rowIndex {
                                            withAnimation(.easeOut(duration: 0.22)) {
                                                proxy.scrollTo(row.id, anchor: .center)
                                            }
                                        }
                                    }
                                }
                            }
                            .padding(.top, 4)
                            .padding(.bottom, 64)
                        }
                        .frame(maxHeight: min(geo.size.height * 0.34, 335))
                    }
                }
                .padding(.horizontal, 82)
                .padding(.top, 10)
                .padding(.bottom, 10)
                .frame(width: geo.size.width, alignment: .bottomLeading)
                .background(
                    ZStack {
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(Color.black.opacity(0.54))
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(.regularMaterial.opacity(0.18))
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [Color.black.opacity(0.34), Color.black.opacity(0.62), Color.black.opacity(0.46)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
                    .clipShape(UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous))
                )
                .shadow(color: .black.opacity(0.78), radius: 42, y: -12)
                .transition(.asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity), removal: .move(edge: .bottom).combined(with: .opacity)))
            }
            .focusSection()
            .onAppear {
                focusedRow = 0
                for row in rows where selectedIndices[row.id] == nil { selectedIndices[row.id] = 0 }
            }
        }
        .allowsHitTesting(true)
        .onExitCommand { closeOverlay() }
    }

    private var overlayHeader: some View {
        HStack(alignment: .lastTextBaseline, spacing: 16) {
            ThemedPanelLogo(title: overlayTitle)
                .frame(height: 58, alignment: .leading)
            Text("slot carousel")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Spacer(minLength: 0)
            Text("MENU closes")
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.36))
        }
        .padding(.horizontal, 8)
    }

    private func closeOverlay() {
        withAnimation(.easeInOut(duration: 0.22)) {
            store.selectedTab = .live
            store.selectedDetail = nil
        }
    }
}

struct GridOSFixedSlotCatalogRail: View {
    @EnvironmentObject var store: CatalogStore
    let row: MediaRow
    let rowIndex: Int
    var focusedRow: FocusState<Int?>.Binding
    @Binding var selectedIndex: Int

    private var safeIndex: Int {
        guard !row.items.isEmpty else { return 0 }
        return min(max(selectedIndex, 0), row.items.count - 1)
    }

    private var selectedItem: MediaItem? {
        guard !row.items.isEmpty else { return nil }
        return row.items[safeIndex]
    }

    private var previewItems: [MediaItem] {
        guard !row.items.isEmpty else { return [] }
        return Array(row.items.dropFirst(safeIndex + 1).prefix(12))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(row.title)
                .font(.system(size: focusedRow.wrappedValue == rowIndex ? 28 : 24, weight: .heavy, design: .rounded))
                .foregroundStyle(focusedRow.wrappedValue == rowIndex ? .white : .white.opacity(0.70))
                .padding(.leading, 4)

            HStack(alignment: .bottom, spacing: 14) {
                if let selectedItem {
                    FixedSlotFocusedCatalogCard(item: selectedItem, focused: focusedRow.wrappedValue == rowIndex)
                        .id(selectedItem.id)
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                }

                ForEach(Array(previewItems.enumerated()), id: \.element.id) { offset, item in
                    FixedSlotPreviewCatalogCard(item: item, depth: offset)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                }

                Spacer(minLength: 0)
            }
            .frame(height: 218, alignment: .bottomLeading)
            .contentShape(Rectangle())
            .focusable(true)
            .focused(focusedRow, equals: rowIndex)
            .modifier(TransparentTVFocusVisual())
            .onTapGesture { openSelected() }
            .onPlayPauseCommand { openSelected() }
            .onMoveCommand { direction in
                handleMove(direction)
            }
            .animation(.spring(response: 0.42, dampingFraction: 0.84), value: selectedIndex)
            .animation(.spring(response: 0.34, dampingFraction: 0.84), value: focusedRow.wrappedValue == rowIndex)
        }
    }

    private func handleMove(_ direction: MoveCommandDirection) {
        switch direction {
        case .left:
            if selectedIndex > 0 { selectedIndex -= 1 }
        case .right:
            if selectedIndex < row.items.count - 1 { selectedIndex += 1 }
        case .up:
            focusedRow.wrappedValue = max(rowIndex - 1, 0)
        case .down:
            focusedRow.wrappedValue = rowIndex + 1
        @unknown default:
            break
        }
    }

    private func openSelected() {
        guard let selectedItem else { return }
        store.openDetail(selectedItem, pushCurrent: false)
    }
}

struct StremioAddonSourceBadge: View {
    let item: MediaItem
    var compact: Bool = false

    private var label: String {
        let raw = (item.addonName ?? item.catalog).trimmingCharacters(in: .whitespacesAndNewlines)
        return raw.isEmpty ? "Stremio" : raw
    }

    private var initials: String {
        let parts = label.split(separator: " ").prefix(2)
        let text = parts.compactMap { $0.first }.map(String.init).joined().uppercased()
        return text.isEmpty ? "S" : text
    }

    var body: some View {
        HStack(spacing: compact ? 6 : 8) {
            ZStack {
                Circle().fill(Color.black.opacity(0.36))
                if let icon = item.addonIconURL, !icon.isEmpty {
                    RemoteImageFit(url: icon, mode: .fit)
                        .clipShape(Circle())
                } else {
                    Text(initials)
                        .font(.system(size: compact ? 10 : 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.92))
                }
            }
            .frame(width: compact ? 22 : 28, height: compact ? 22 : 28)

            if !compact {
                Text(label)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.90))
                    .lineLimit(1)
                    .frame(maxWidth: 145, alignment: .leading)
            }
        }
        .padding(.horizontal, compact ? 7 : 10)
        .padding(.vertical, compact ? 5 : 7)
        .background(Capsule().fill(Color.black.opacity(0.58)))
        .overlay(Capsule().stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.40), radius: 8, y: 3)
        .allowsHitTesting(false)
    }
}

struct FixedSlotFocusedCatalogCard: View {
    let item: MediaItem
    let focused: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                Color.black.opacity(0.38)
                RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                    .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
            }
            .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

            LinearGradient(colors: [.clear, .black.opacity(0.84)], startPoint: .center, endPoint: .bottom)
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))


            VStack(alignment: .leading, spacing: 7) {
                CardThemedLogo(item: item, focused: focused)
                    .frame(width: focused ? 278 : 230, height: focused ? 42 : 34, alignment: .leading)
                Text("\(item.year) • \(item.rating.ifEmpty(item.catalog))")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .lineLimit(1)
            }
            .padding(18)
        }
        .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.white.opacity(focused ? 0.18 : 0.08), lineWidth: focused ? 0.9 : 0.8)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 27, style: .continuous)
                .stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(focused ? 0.96 : 0.0), lineWidth: focused ? 4.0 : 0.0)
                .blur(radius: focused ? 0.15 : 0.0)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 31, style: .continuous)
                .stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(focused ? 0.42 : 0.0), lineWidth: focused ? 8.0 : 0.0)
                .blur(radius: focused ? 7 : 0)
        )
        // v438: Movies/Shows quick panel now uses the same blue second-ring focus language as Live TV grid focus.
        .offset(y: focused ? -8 : 0)
        .shadow(color: Color(red: 0.16, green: 0.58, blue: 1.0).opacity(focused ? 0.36 : 0.02), radius: focused ? 28 : 6, y: focused ? 5 : 1)
        .shadow(color: .black.opacity(focused ? 0.82 : 0.46), radius: focused ? 30 : 14, y: focused ? 18 : 7)
        .animation(.spring(response: 0.36, dampingFraction: 0.86), value: focused)
    }
}

struct FixedSlotPreviewCatalogCard: View {
    let item: MediaItem
    let depth: Int

    private var cardWidth: CGFloat { max(64, 116 - CGFloat(depth) * 4.4) }
    private var cardHeight: CGFloat { cardWidth * 1.48 }
    private var opacity: Double { max(0.36, 0.90 - Double(depth) * 0.045) }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ZStack(alignment: .topTrailing) {
                Color.black.opacity(0.34)
                RemoteImageFit(url: item.posterURL, mode: .fill)
                    .frame(width: cardWidth, height: cardHeight)
            }
            .frame(width: cardWidth, height: cardHeight)
            .clipShape(RoundedRectangle(cornerRadius: max(9, 16 - CGFloat(depth) * 0.45), style: .continuous))
            EmptyView()
        }
        .opacity(opacity)
        .shadow(color: .black.opacity(0.50), radius: 12, y: 6)
        .brightness(depth == 0 ? 0.012 : -0.016)
        .saturation(depth == 0 ? 1.02 : 0.92)
    }
}


struct MediaInfoPopup: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focused: Bool
    @State private var focus: DetailPage.DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var trailerSessionID: String = UUID().uuidString
    @State private var trailerResolving = false
    @State private var isFindingLinks = false
    @State private var isLoadingEpisodes = false
    @State private var episodeItems: [MediaItem] = []
    @State private var episodesVisible = false
    @State private var episodeWindowStart: Int = 0
    @State private var selectedSeasonNumber: Int = 1
    @State private var seasonDropdownOpen = false
    @State private var linkWindowStart: Int = 0
    @State private var relatedWindowStart: Int = 0
    @State private var lastActionAt: TimeInterval = 0
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"

    private var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(8))
    }

    private var isSeriesItem: Bool {
        let lower = item.type.lowercased()
        return lower.contains("series") || lower.contains("show")
    }

    private var seasonNumbers: [Int] {
        let values = Set(episodeItems.map { $0.seasonNumber ?? 1 })
        return values.isEmpty ? [selectedSeasonNumber] : values.sorted()
    }

    private var selectedSeasonIndex: Int {
        seasonNumbers.firstIndex(of: selectedSeasonNumber) ?? 0
    }

    private var filteredEpisodeItems: [MediaItem] {
        episodeItems.filter { ($0.seasonNumber ?? 1) == selectedSeasonNumber }
    }

    private var visibleEpisodeItems: [MediaItem] {
        Array(filteredEpisodeItems.dropFirst(episodeWindowStart).prefix(4))
    }

    private var visibleLinks: [StreamLink] {
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(6))
    }

    private var visibleRelatedItems: [MediaItem] {
        Array(relatedItems.dropFirst(relatedWindowStart).prefix(5))
    }

    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.black.opacity(0.58))
                .ignoresSafeArea()
                .transition(.opacity)

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .top, spacing: 30) {
                    DetailPoster(item: item)
                        .frame(width: 250, height: 374)
                        .clipShape(RoundedRectangle(cornerRadius: 28))
                        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.12), lineWidth: 1))
                        .shadow(color: .black.opacity(0.45), radius: 28, y: 18)

                    VStack(alignment: .leading, spacing: 16) {
                        PopupArtworkLogoOnly(item: item)
                            .frame(width: 760, height: 98, alignment: .leading)

                        HStack(spacing: 18) {
                            Text(item.year)
                            Text(item.type.uppercased())
                            Text(item.genres.prefix(2).joined(separator: ", "))
                            Text("★ \(item.rating)")
                        }
                        .font(.system(size: 22, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.78))

                        Text(item.description)
                            .font(.system(size: 22, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.86))
                            .lineLimit(4)
                            .frame(width: 820, alignment: .leading)

                        HStack(spacing: 18) {
                            ManualDetailButton(title: "▶ PLAY", selected: focus == .play)
                            ManualDetailButton(title: trailerResolving ? "LOADING TRAILER..." : "TRAILER", selected: focus == .trailer)
                            ManualDetailButton(title: "YOUTUBE", selected: focus == .youtube)
                            ManualDetailButton(title: isFindingLinks ? "FINDING..." : "FIND LINKS", selected: focus == .findLinks)
                            if isSeriesItem {
                                ManualDetailButton(title: isLoadingEpisodes ? "LOADING..." : "EPISODES", selected: focus == .episodes)
                            }
                            ManualDetailButton(title: "CLOSE", selected: focus == .close)
                        }

                        Text(streamStatusText(store.lastStreamMessage))
                            .font(.system(size: 17, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.60))
                            .lineLimit(2)
                            .frame(width: 860, alignment: .leading)

                        if episodesVisible {
                            ManualEpisodesRow(focus: focus, visibleEpisodes: visibleEpisodeItems, episodeWindowStart: episodeWindowStart, totalEpisodeCount: filteredEpisodeItems.count, seasonNumbers: seasonNumbers, selectedSeasonNumber: selectedSeasonNumber, seasonDropdownOpen: seasonDropdownOpen)
                        }

                        ManualStreamLinksRow(focus: focus, visibleLinks: visibleLinks, linkWindowStart: linkWindowStart, totalLinkCount: store.streamLinks.count)
                    }
                }

                VStack(alignment: .leading, spacing: 12) {
                    Text("More Like This")
                        .font(.system(size: 26, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    ManualRelatedRow(focus: focus, relatedItems: visibleRelatedItems, baseIndex: relatedWindowStart)
                        .frame(width: 1188, alignment: .leading)
                        .clipped()
                }
            }
            .padding(34)
            .frame(width: 1320, alignment: .leading)
            .clipped()
            .background(
                RoundedRectangle(cornerRadius: 42)
                    .fill(Color.black.opacity(0.82))
                    .overlay(
                        LinearGradient(colors: [Color.white.opacity(0.08), Color.white.opacity(0.018)], startPoint: .topLeading, endPoint: .bottomTrailing)
                            .clipShape(RoundedRectangle(cornerRadius: 42))
                    )
            )
            .overlay(RoundedRectangle(cornerRadius: 42).stroke(Color.white.opacity(0.13), lineWidth: 1))
            .shadow(color: .black.opacity(0.38), radius: 24, y: 10)
            .scaleEffect(focused ? 1.0 : 0.965)
            .opacity(focused ? 1.0 : 0.0)
            .animation(.spring(response: 0.42, dampingFraction: 0.88), value: focused)
            .padding(.top, 108)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL, audioURL: nil, sessionID: trailerSessionID) {
                    trailerPopup = false
                    self.trailerURL = nil
                    trailerSessionID = UUID().uuidString
                    focused = true
                }
                .zIndex(10)
            }
        }
        .focusSection()
        .focusable(true)
        .focused($focused)
        .onAppear {
            focused = true
            focus = .play
            trailerPopup = false
            trailerURL = nil
            trailerSessionID = UUID().uuidString
            trailerResolving = false
            store.beginTrailerPrewarm(for: item)
        }
        .onChange(of: item.id) { _ in
            trailerPopup = false
            trailerURL = nil
            trailerSessionID = UUID().uuidString
            trailerResolving = false
        }
        .onChange(of: focused) { value in
            if !value && store.selectedDetail?.id == item.id && store.playbackURL == nil {
                DispatchQueue.main.async { focused = true }
            }
        }
        .onTapGesture { activateDebounced() }
        .onPlayPauseCommand { activateDebounced() }
        .onExitCommand {
            if trailerPopup { trailerPopup = false; trailerURL = nil; trailerSessionID = UUID().uuidString } else { store.closeDetail() }
        }
        .onMoveCommand { route($0) }
    }

    private func route(_ direction: MoveCommandDirection) {
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close: break
            case .searchLinks, .stream, .season, .episode: focus = .play
            case .related: focus = store.streamLinks.isEmpty ? .searchLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close: focus = .searchLinks
            case .searchLinks, .stream:
                relatedWindowStart = 0
                focus = .related(0)
            case .season:
                focus = filteredEpisodeItems.isEmpty ? .searchLinks : .episode(0)
            case .episode:
                relatedWindowStart = 0
                focus = .related(0)
            case .related: break
            }
        case .left:
            switch focus {
            case .play: break
            case .trailer: focus = .play
            case .youtube: focus = .trailer
            case .findLinks: focus = .youtube
            case .episodes: focus = .findLinks
            case .close: focus = isSeriesItem ? .episodes : .findLinks
            case .searchLinks: focus = .close
            case .season(let index):
                let prev = max(0, index - 1)
                selectedSeasonNumber = seasonNumbers[prev]
                episodeWindowStart = 0
                focus = .season(prev)
            case .stream(let index):
                if index <= 0 { focus = .searchLinks } else { let previous = index - 1; focus = .stream(previous); ensureLinkVisible(previous) }
            case .episode(let index):
                if index <= 0 { focus = .episodes } else { let previous = index - 1; focus = .episode(previous); ensureEpisodeVisible(previous) }
            case .related(let index):
                let previous = max(0, index - 1)
                focus = .related(previous)
                ensureRelatedVisible(previous)
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .trailer: focus = .youtube
            case .youtube: focus = .findLinks
            case .findLinks: focus = isSeriesItem ? .episodes : .close
            case .episodes: focus = .close
            case .close: focus = episodesVisible ? .season(selectedSeasonIndex) : .searchLinks
            case .season(let index):
                let next = min(max(seasonNumbers.count - 1, 0), index + 1)
                selectedSeasonNumber = seasonNumbers[next]
                episodeWindowStart = 0
                focus = .season(next)
            case .searchLinks:
                if !store.streamLinks.isEmpty { ensureLinkVisible(linkWindowStart); focus = .stream(linkWindowStart) }
            case .stream(let index):
                let next = min(max(store.streamLinks.count - 1, 0), index + 1)
                focus = .stream(next)
                ensureLinkVisible(next)
            case .episode(let index):
                let next = min(max(filteredEpisodeItems.count - 1, 0), index + 1)
                focus = .episode(next)
                ensureEpisodeVisible(next)
            case .related(let index):
                let next = min(max(relatedItems.count - 1, 0), index + 1)
                focus = .related(next)
                ensureRelatedVisible(next)
            }
        default: break
        }
    }

    private func ensureRelatedVisible(_ absoluteIndex: Int) {
        guard !relatedItems.isEmpty else { relatedWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), relatedItems.count - 1)
        if clamped < relatedWindowStart {
            relatedWindowStart = clamped
        } else if clamped >= relatedWindowStart + 5 {
            relatedWindowStart = max(0, clamped - 4)
        }
    }

    private func playTrailerUsingSelectedMode() {
        let mode = trailerPlaybackMode.lowercased()
        if mode == "youtube" {
            openTrailerInYouTube()
            return
        }
        Task {
            let requestedID = item.id
            await MainActor.run {
                trailerPopup = false
                trailerURL = nil
                trailerSessionID = UUID().uuidString
                trailerResolving = true
                store.lastStreamMessage = "Loading trailer for \(item.title)…"
            }
            if let url = await store.resolvePlayableTrailerURL(for: item) {
                await MainActor.run {
                    guard requestedID == item.id else { return }
                    trailerResolving = false
                    trailerSessionID = UUID().uuidString
                    trailerURL = url
                    trailerPopup = true
                }
            } else {
                await MainActor.run { trailerResolving = false }
                if mode == "automatic" {
                    openTrailerInYouTube()
                } else {
                    await MainActor.run { store.status = "No direct playable trailer found. Try Open in YouTube or switch Trailer Playback Mode to Automatic Fallback." }
                }
            }
        }
    }

    private func openTrailerInYouTube() {
        trailerResolving = true
        Task {
            let externalURL = await store.resolveTrailerWatchURL(for: item)
            await MainActor.run {
                trailerResolving = false
                guard let externalURL else {
                    store.status = "No YouTube trailer link found yet."
                    return
                }
                openYouTubeTrailerURL(externalURL)
            }
        }
    }

    @MainActor
    private func openYouTubeTrailerURL(_ url: URL) {
        let candidates = youtubeLaunchCandidates(from: url)
        func attempt(_ index: Int) {
            guard index < candidates.count else {
                store.status = "Could not open YouTube from this Apple TV. Make sure the YouTube app is installed, or switch Trailer Playback back to In-App Popup."
                return
            }
            UIApplication.shared.open(candidates[index], options: [:]) { success in
                if success {
                    store.status = "Opening trailer in YouTube…"
                } else {
                    attempt(index + 1)
                }
            }
        }
        attempt(0)
    }

    private func youtubeLaunchCandidates(from url: URL) -> [URL] {
        let raw = url.absoluteString
        let videoID = youtubeVideoID(from: raw)
        var out: [URL] = []
        if let videoID {
            out.append(contentsOf: [
                URL(string: "youtube://watch?v=\(videoID)"),
                URL(string: "youtube://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "vnd.youtube://watch?v=\(videoID)"),
                URL(string: "https://www.youtube.com/watch?v=\(videoID)")
            ].compactMap { $0 })
        }
        out.append(url)
        let query = "\(item.title) \(item.year) official trailer".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? item.title
        out.append(URL(string: "youtube://results?search_query=\(query)")!)
        out.append(URL(string: "vnd.youtube://results?search_query=\(query)")!)
        out.append(URL(string: "https://www.youtube.com/results?search_query=\(query)")!)
        var seen = Set<String>()
        return out.filter { seen.insert($0.absoluteString).inserted }
    }

    private func youtubeVideoID(from raw: String) -> String? {
        let patterns = [
            #"[?&]v=([A-Za-z0-9_-]{11})"#,
            #"youtu\.be/([A-Za-z0-9_-]{11})"#,
            #"youtubeVideoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtubeId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"videoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"video_id[\"':\s]+([A-Za-z0-9_-]{11})"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let ns = raw as NSString
            let range = NSRange(location: 0, length: ns.length)
            if let match = regex.firstMatch(in: raw, range: range), match.numberOfRanges > 1 {
                return ns.substring(with: match.range(at: 1))
            }
        }
        return nil
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + 6 {
            linkWindowStart = max(0, clamped - 5)
        }
    }

    private func ensureEpisodeVisible(_ absoluteIndex: Int) {
        guard !filteredEpisodeItems.isEmpty else { episodeWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), filteredEpisodeItems.count - 1)
        if clamped < episodeWindowStart {
            episodeWindowStart = clamped
        } else if clamped >= episodeWindowStart + 4 {
            episodeWindowStart = max(0, clamped - 3)
        }
    }

    private func activateDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastActionAt > 0.36 else { return }
        lastActionAt = now
        activate()
    }

    private func activate() {
        switch focus {
        case .play:
            Task { isFindingLinks = true; await store.playFirstDirectStream(for: item); isFindingLinks = false }
        case .trailer:
            playTrailerUsingSelectedMode()
        case .youtube:
            openTrailerInYouTube()
        case .findLinks, .searchLinks:
            Task {
                episodesVisible = false
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(0)
            }
        case .episodes:
            Task {
                isLoadingEpisodes = true
                if episodeItems.isEmpty { episodeItems = await store.fetchSeriesEpisodes(for: item) }
                isLoadingEpisodes = false
                episodesVisible = true
                selectedSeasonNumber = seasonNumbers.first ?? 1
                seasonDropdownOpen = true
                episodeWindowStart = 0
                focus = episodeItems.isEmpty ? .episodes : .season(selectedSeasonIndex)
            }
        case .close:
            store.closeDetail()
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver service is needed for magnet/infoHash/debrid-only links."
            }
        case .season(let index):
            guard seasonNumbers.indices.contains(index) else { return }
            selectedSeasonNumber = seasonNumbers[index]
            seasonDropdownOpen = true
            episodeWindowStart = 0
            focus = filteredEpisodeItems.isEmpty ? .season(index) : .episode(0)
        case .episode(let index):
            guard filteredEpisodeItems.indices.contains(index) else { return }
            let episode = filteredEpisodeItems[index]
            store.openDetail(episode, pushCurrent: true)
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}

struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var canvasFocused: Bool
    @State private var focus: DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var trailerSessionID: String = UUID().uuidString
    @State private var trailerResolving = false
    @State private var isFindingLinks = false
    @State private var isLoadingEpisodes = false
    @State private var episodeItems: [MediaItem] = []
    @State private var episodesVisible = false
    @State private var episodeWindowStart: Int = 0
    @State private var selectedSeasonNumber: Int = 1
    @State private var seasonDropdownOpen = false
    @State private var lastRemoteActionAt: TimeInterval = 0
    @State private var linkWindowStart: Int = 0
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"

    enum DetailNode: Hashable {
        case play, trailer, youtube, findLinks, episodes, close, searchLinks
        case stream(Int)
        case season(Int)
        case episode(Int)
        case related(Int)
    }

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(8))
    }

    let maxVisibleStreamLinks = 6
    let maxVisibleEpisodes = 6

    private var isSeriesItem: Bool {
        let lower = item.type.lowercased()
        return lower.contains("series") || lower.contains("show")
    }

    var seasonNumbers: [Int] {
        let values = Set(episodeItems.map { $0.seasonNumber ?? 1 })
        return values.isEmpty ? [selectedSeasonNumber] : values.sorted()
    }

    var selectedSeasonIndex: Int {
        seasonNumbers.firstIndex(of: selectedSeasonNumber) ?? 0
    }

    var filteredEpisodeItems: [MediaItem] {
        episodeItems.filter { ($0.seasonNumber ?? 1) == selectedSeasonNumber }
    }

    var visibleEpisodeItems: [MediaItem] {
        Array(filteredEpisodeItems.dropFirst(episodeWindowStart).prefix(maxVisibleEpisodes))
    }

    var visibleLinks: [StreamLink] {
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(maxVisibleStreamLinks))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            DetailBackdropArtwork(item: item)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.28))
                .overlay(LinearGradient(colors: [.black.opacity(0.78), .black.opacity(0.20), .black.opacity(0.62)], startPoint: .leading, endPoint: .trailing))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom))

            VStack(alignment: .leading, spacing: 24) {
                Spacer().frame(height: 250)

                // v251: detail page keeps themed artwork logos static; popup removed fallback text logos/pulse.
                HeroLogoText(item: item, pulse: false)
                    .frame(width: 780, height: 132, alignment: .leading)
                    .padding(.leading, 84)

                HStack(spacing: 30) {
                    Text(item.genres.first?.uppercased() ?? item.type.uppercased())
                    Text(item.year)
                    Text(item.type.uppercased())
                    Text("152min")
                    Text("🍅 80%")
                    Text("🍿 82%")
                    Text("★ \(item.rating)")
                }
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white.opacity(0.86))
                .padding(.leading, 84)

                HStack(spacing: 22) {
                    ManualDetailButton(title: "▶ PLAY", selected: focus == .play)
                    ManualDetailButton(title: trailerResolving ? "LOADING TRAILER..." : "TRAILER", selected: focus == .trailer)
                    ManualDetailButton(title: "YOUTUBE", selected: focus == .youtube)
                    ManualDetailButton(title: isFindingLinks ? "FINDING..." : "FIND LINKS", selected: focus == .findLinks)
                    if isSeriesItem {
                        ManualDetailButton(title: isLoadingEpisodes ? "LOADING..." : "EPISODES", selected: focus == .episodes)
                    }
                    ManualDetailButton(title: "CLOSE", selected: focus == .close)
                }
                .padding(.leading, 84)

                Text(streamStatusText(store.lastStreamMessage))
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.leading, 84)
                    .frame(width: 980, alignment: .leading)

                if episodesVisible {
                    ManualEpisodesRow(focus: focus, visibleEpisodes: visibleEpisodeItems, episodeWindowStart: episodeWindowStart, totalEpisodeCount: filteredEpisodeItems.count, seasonNumbers: seasonNumbers, selectedSeasonNumber: selectedSeasonNumber, seasonDropdownOpen: seasonDropdownOpen)
                        .padding(.leading, 84)
                }

                ManualStreamLinksRow(focus: focus, visibleLinks: visibleLinks, linkWindowStart: linkWindowStart, totalLinkCount: store.streamLinks.count)
                    .padding(.leading, 84)

                Spacer()

                VStack(alignment: .leading, spacing: 18) {
                    Text("More Like This")
                        .font(.system(size: 34, weight: .black))
                    ManualRelatedRow(focus: focus, relatedItems: relatedItems)
                }
                .foregroundStyle(.white)
                .padding(.leading, 84)
                .padding(.bottom, 46)
            }

            VStack(alignment: .leading, spacing: 14) {
                Text(item.description)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .foregroundStyle(.white.opacity(0.94))
                Text("Directors: Metadata source credits")
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Stars: Actor information appears here when credits metadata is available")
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .font(.system(size: 14, weight: .medium))
            .foregroundStyle(.white.opacity(0.80))
            .padding(16)
            .frame(width: 430, alignment: .leading)
            .frame(minHeight: 248, alignment: .leading)
            .background(.ultraThinMaterial.opacity(0.46), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.14), lineWidth: 1))
            // v160: mathematically pinned beside the stream-link arrow area, moved a half-inch right from v159.
            .position(x: 1238, y: 622)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL, audioURL: nil, sessionID: trailerSessionID) {
                    trailerPopup = false
                    self.trailerURL = nil
                    trailerSessionID = UUID().uuidString
                    canvasFocused = true
                }
                .zIndex(10)
            }
        }
        .focusable(true)
        .focused($canvasFocused)
        .onAppear {
            canvasFocused = true
            focus = .play
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
        }
        .onChange(of: item.id) { _ in
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
        }
        .onTapGesture { activateFocusedNodeDebounced() }
        .onPlayPauseCommand { activateFocusedNodeDebounced() }
        .onMoveCommand { direction in route(direction) }
        .task(id: item.id) {
            // v410: start the KinoCheck/trailer service resolve as soon as details open.
            // Pressing Trailer should usually consume an already prepared URL instead
            // of starting the 20-30 second extraction/remux path on click.
            trailerPopup = false
            trailerURL = nil
            trailerSessionID = UUID().uuidString
            store.beginTrailerPrewarm(for: item)
        }
        .onExitCommand {
            if trailerPopup { trailerPopup = false; trailerURL = nil; trailerSessionID = UUID().uuidString } else { store.closeDetail() }
        }
    }

    private func route(_ direction: MoveCommandDirection) {
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close:
                canvasFocused = true
            case .searchLinks, .stream, .season, .episode:
                focus = .play
            case .related:
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close:
                focus = .searchLinks
            case .searchLinks, .stream:
                focus = .related(0)
            case .season:
                focus = filteredEpisodeItems.isEmpty ? .searchLinks : .episode(0)
            case .episode:
                focus = .related(0)
            case .related:
                break
            }
        case .left:
            switch focus {
            case .play: break
            case .trailer: focus = .play
            case .youtube: focus = .trailer
            case .findLinks: focus = .youtube
            case .episodes: focus = .findLinks
            case .close: focus = isSeriesItem ? .episodes : .findLinks
            case .searchLinks: focus = .close
            case .season(let index):
                let prev = max(0, index - 1)
                selectedSeasonNumber = seasonNumbers[prev]
                episodeWindowStart = 0
                focus = .season(prev)
            case .stream(let index):
                if index <= 0 { focus = .searchLinks } else {
                    let previous = index - 1
                    focus = .stream(previous)
                    ensureLinkVisible(previous)
                }
            case .episode(let index):
                if index <= 0 { focus = .episodes } else {
                    let previous = index - 1
                    focus = .episode(previous)
                    ensureEpisodeVisible(previous)
                }
            case .related(let index): focus = .related(max(0, index - 1))
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .trailer: focus = .youtube
            case .youtube: focus = .findLinks
            case .findLinks: focus = isSeriesItem ? .episodes : .close
            case .episodes: focus = .close
            case .close: focus = episodesVisible ? .season(selectedSeasonIndex) : .searchLinks
            case .season(let index):
                let next = min(max(seasonNumbers.count - 1, 0), index + 1)
                selectedSeasonNumber = seasonNumbers[next]
                episodeWindowStart = 0
                focus = .season(next)
            case .searchLinks:
                if !store.streamLinks.isEmpty {
                    ensureLinkVisible(linkWindowStart)
                    focus = .stream(linkWindowStart)
                }
            case .stream(let index):
                let next = min(max(store.streamLinks.count - 1, 0), index + 1)
                focus = .stream(next)
                ensureLinkVisible(next)
            case .episode(let index):
                let next = min(max(filteredEpisodeItems.count - 1, 0), index + 1)
                focus = .episode(next)
                ensureEpisodeVisible(next)
            case .related(let index): focus = .related(min(max(relatedItems.count - 1, 0), index + 1))
            }
        default:
            break
        }
    }

    private func playTrailerUsingSelectedMode() {
        let mode = trailerPlaybackMode.lowercased()
        if mode == "youtube" {
            openTrailerInYouTube()
            return
        }
        Task {
            let requestedID = item.id
            await MainActor.run {
                trailerPopup = false
                trailerURL = nil
                trailerSessionID = UUID().uuidString
                trailerResolving = true
                store.lastStreamMessage = "Loading trailer for \(item.title)…"
            }
            if let url = await store.resolvePlayableTrailerURL(for: item) {
                await MainActor.run {
                    guard requestedID == item.id else { return }
                    trailerResolving = false
                    trailerSessionID = UUID().uuidString
                    trailerURL = url
                    trailerPopup = true
                }
            } else {
                await MainActor.run { trailerResolving = false }
                if mode == "automatic" {
                    openTrailerInYouTube()
                } else {
                    await MainActor.run { store.status = "No direct playable trailer found. Try Open in YouTube or switch Trailer Playback Mode to Automatic Fallback." }
                }
            }
        }
    }

    private func openTrailerInYouTube() {
        trailerResolving = true
        Task {
            let externalURL = await store.resolveTrailerWatchURL(for: item)
            await MainActor.run {
                trailerResolving = false
                guard let externalURL else {
                    store.status = "No YouTube trailer link found yet."
                    return
                }
                openYouTubeTrailerURL(externalURL)
            }
        }
    }

    @MainActor
    private func openYouTubeTrailerURL(_ url: URL) {
        let candidates = youtubeLaunchCandidates(from: url)
        func attempt(_ index: Int) {
            guard index < candidates.count else {
                store.status = "Could not open YouTube from this Apple TV. Make sure the YouTube app is installed, or switch Trailer Playback back to In-App Popup."
                return
            }
            UIApplication.shared.open(candidates[index], options: [:]) { success in
                if success {
                    store.status = "Opening trailer in YouTube…"
                } else {
                    attempt(index + 1)
                }
            }
        }
        attempt(0)
    }

    private func youtubeLaunchCandidates(from url: URL) -> [URL] {
        let raw = url.absoluteString
        let videoID = youtubeVideoID(from: raw)
        var out: [URL] = []
        if let videoID {
            out.append(contentsOf: [
                URL(string: "youtube://watch?v=\(videoID)"),
                URL(string: "youtube://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "vnd.youtube://watch?v=\(videoID)"),
                URL(string: "https://www.youtube.com/watch?v=\(videoID)")
            ].compactMap { $0 })
        }
        out.append(url)
        let query = "\(item.title) \(item.year) official trailer".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? item.title
        out.append(URL(string: "youtube://results?search_query=\(query)")!)
        out.append(URL(string: "vnd.youtube://results?search_query=\(query)")!)
        out.append(URL(string: "https://www.youtube.com/results?search_query=\(query)")!)
        var seen = Set<String>()
        return out.filter { seen.insert($0.absoluteString).inserted }
    }

    private func youtubeVideoID(from raw: String) -> String? {
        let patterns = [
            #"[?&]v=([A-Za-z0-9_-]{11})"#,
            #"youtu\.be/([A-Za-z0-9_-]{11})"#,
            #"youtubeVideoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtubeId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"videoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"video_id[\"':\s]+([A-Za-z0-9_-]{11})"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let ns = raw as NSString
            let range = NSRange(location: 0, length: ns.length)
            if let match = regex.firstMatch(in: raw, range: range), match.numberOfRanges > 1 {
                return ns.substring(with: match.range(at: 1))
            }
        }
        return nil
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + maxVisibleStreamLinks {
            linkWindowStart = max(0, clamped - maxVisibleStreamLinks + 1)
        }
    }

    private func ensureEpisodeVisible(_ absoluteIndex: Int) {
        guard !filteredEpisodeItems.isEmpty else { episodeWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), filteredEpisodeItems.count - 1)
        if clamped < episodeWindowStart {
            episodeWindowStart = clamped
        } else if clamped >= episodeWindowStart + maxVisibleEpisodes {
            episodeWindowStart = max(0, clamped - maxVisibleEpisodes + 1)
        }
    }

    private func activateFocusedNodeDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastRemoteActionAt > 0.38 else { return }
        lastRemoteActionAt = now
        activateFocusedNode()
    }

    private func activateFocusedNode() {
        switch focus {
        case .play:
            Task {
                isFindingLinks = true
                await store.playFirstDirectStream(for: item)
                isFindingLinks = false
            }
        case .trailer:
            playTrailerUsingSelectedMode()
        case .youtube:
            openTrailerInYouTube()
        case .findLinks, .searchLinks:
            Task {
                episodesVisible = false
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(0)
            }
        case .episodes:
            Task {
                isLoadingEpisodes = true
                if episodeItems.isEmpty { episodeItems = await store.fetchSeriesEpisodes(for: item) }
                isLoadingEpisodes = false
                episodesVisible = true
                selectedSeasonNumber = seasonNumbers.first ?? 1
                seasonDropdownOpen = true
                episodeWindowStart = 0
                focus = episodeItems.isEmpty ? .episodes : .season(selectedSeasonIndex)
            }
        case .close:
            store.closeDetail()
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver service is needed for magnet/infoHash/debrid-only links."
            }
        case .season(let index):
            guard seasonNumbers.indices.contains(index) else { return }
            selectedSeasonNumber = seasonNumbers[index]
            seasonDropdownOpen = true
            episodeWindowStart = 0
            focus = filteredEpisodeItems.isEmpty ? .season(index) : .episode(0)
        case .episode(let index):
            guard filteredEpisodeItems.indices.contains(index) else { return }
            let episode = filteredEpisodeItems[index]
            store.openDetail(episode, pushCurrent: true)
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}

struct ManualDetailButton: View {
    let title: String
    let selected: Bool
    var body: some View {
        Text(title)
            .font(.system(size: 26, weight: .black))
            .foregroundStyle(selected ? Color.black : Color.white)
            .padding(.horizontal, 34)
            .padding(.vertical, 18)
            .background(RoundedRectangle(cornerRadius: 18).fill(selected ? Color.cyan.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color.white.opacity(0.80) : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
            .scaleEffect(selected ? 1.075 : 1.0)
            .shadow(color: selected ? .cyan.opacity(0.65) : .clear, radius: 18)
    }
}

struct ManualEpisodesRow: View {
    let focus: DetailPage.DetailNode
    let visibleEpisodes: [MediaItem]
    let episodeWindowStart: Int
    let totalEpisodeCount: Int
    let seasonNumbers: [Int]
    let selectedSeasonNumber: Int
    let seasonDropdownOpen: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Text("Seasons & Episodes")
                    .font(.system(size: 22, weight: .black))
                if totalEpisodeCount > visibleEpisodes.count {
                    Text("Showing \(episodeWindowStart + 1)-\(min(episodeWindowStart + visibleEpisodes.count, totalEpisodeCount)) of \(totalEpisodeCount)")
                        .font(.system(size: 16, weight: .bold))
                        .foregroundStyle(.white.opacity(0.62))
                }
            }
            if seasonDropdownOpen {
                HStack(spacing: 10) {
                    Text("Season")
                        .font(.system(size: 17, weight: .black))
                        .foregroundStyle(.white.opacity(0.62))
                    ForEach(Array(seasonNumbers.enumerated()), id: \.element) { index, season in
                        let selected = selectedSeasonNumber == season
                        let focusedSeason = focus == .season(index)
                        Text("S\(season)")
                            .font(.system(size: 18, weight: .black))
                            .foregroundStyle(selected || focusedSeason ? Color.black : Color.white)
                            .padding(.horizontal, 18)
                            .padding(.vertical, 10)
                            .background(RoundedRectangle(cornerRadius: 14).fill(selected || focusedSeason ? Color.white.opacity(0.92) : Color.white.opacity(0.12)))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedSeason ? Color.cyan.opacity(0.95) : Color.white.opacity(0.18), lineWidth: focusedSeason ? 3 : 1))
                    }
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(RoundedRectangle(cornerRadius: 18).fill(Color.black.opacity(0.34)))
            }
            HStack(spacing: 12) {
                if visibleEpisodes.isEmpty {
                    Text("Select EPISODES to load seasons from the series metadata source.")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.66))
                        .padding(.vertical, 14)
                        .padding(.horizontal, 18)
                        .background(RoundedRectangle(cornerRadius: 16).fill(.white.opacity(0.10)))
                } else {
                    ForEach(Array(visibleEpisodes.enumerated()), id: \.element.id) { offset, episode in
                        let absolute = episodeWindowStart + offset
                        let selected = focus == .episode(absolute)
                        VStack(alignment: .leading, spacing: 6) {
                            Text("S\(String(format: "%02d", episode.seasonNumber ?? 1))E\(String(format: "%02d", episode.episodeNumber ?? absolute + 1))")
                                .font(.system(size: 18, weight: .black))
                            Text(episode.title.replacingOccurrences(of: "  ", with: " "))
                                .font(.system(size: 15, weight: .bold))
                                .lineLimit(2)
                        }
                        .foregroundStyle(selected ? Color.black : Color.white)
                        .frame(width: 245, height: 82, alignment: .leading)
                        .padding(.horizontal, 14)
                        .background(RoundedRectangle(cornerRadius: 18).fill(selected ? Color.cyan.opacity(0.92) : Color.white.opacity(0.12)))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color.white.opacity(0.85) : Color.white.opacity(0.14), lineWidth: selected ? 3 : 1))
                    }
                }
            }
        }
        .foregroundStyle(.white)
    }
}

extension StreamLink {
    var vodLinkDetailLine: String {
        let tags = vodFeatureTags
        if tags.isEmpty { return size }
        return "\(size) • \(tags.joined(separator: " • "))"
    }

    private var vodFeatureTags: [String] {
        let haystack = "\(title) \(quality) \(source)".lowercased()
        var tags: [String] = []
        func add(_ value: String) { if !tags.contains(value) { tags.append(value) } }

        if haystack.contains("dolby vision") || haystack.contains("dovi") || haystack.contains(" dv ") || haystack.contains(".dv.") || haystack.contains("-dv-") { add("DV") }
        if haystack.contains("hdr10+") || haystack.contains("hdr10plus") { add("HDR10+") }
        else if haystack.contains("hdr10") || haystack.contains(" hdr ") || haystack.contains(".hdr.") || haystack.contains("-hdr-") { add("HDR") }
        if haystack.contains("hlg") { add("HLG") }
        if haystack.contains("atmos") { add("Atmos") }
        if haystack.contains("truehd") || haystack.contains("true hd") { add("TrueHD") }
        if haystack.contains("dts-hd") || haystack.contains("dtshd") { add("DTS-HD") }
        else if haystack.contains(" dts ") || haystack.contains(".dts.") || haystack.contains("-dts-") { add("DTS") }
        if haystack.contains("ddp") || haystack.contains("eac3") || haystack.contains("e-ac3") || haystack.contains("dolby digital plus") { add("DD+") }
        else if haystack.contains(" ac3") || haystack.contains(".ac3") || haystack.contains("-ac3") { add("AC3") }
        if haystack.contains(" aac") || haystack.contains(".aac") || haystack.contains("-aac") { add("AAC") }

        let languagePatterns: [(String, [String])] = [
            ("English", [" english", " eng", ".eng", "-eng", " en "]),
            ("Spanish", [" spanish", " spa", ".spa", "-spa", " es ", " latino"]),
            ("French", [" french", " fre", " fra", ".fre", ".fra", " fr "]),
            ("Japanese", [" japanese", " jpn", ".jpn", " ja "]),
            ("Korean", [" korean", " kor", ".kor", " ko "]),
            ("German", [" german", " ger", " deu", ".ger", ".deu", " de "]),
            ("Italian", [" italian", " ita", ".ita", " it "]),
            ("Portuguese", [" portuguese", " por", ".por", " pt "])
        ]
        for (name, patterns) in languagePatterns where patterns.contains(where: { haystack.contains($0) }) { add(name) }

        if haystack.contains("remux") { add("REMUX") }
        if haystack.contains("web-dl") || haystack.contains("webdl") { add("WEB-DL") }
        if haystack.contains("bluray") || haystack.contains("blu-ray") { add("BluRay") }
        return Array(tags.prefix(5))
    }
}

struct ManualStreamLinksRow: View {
    let focus: DetailPage.DetailNode
    let visibleLinks: [StreamLink]
    let linkWindowStart: Int
    let totalLinkCount: Int

    var rangeText: String? {
        guard totalLinkCount > 0 else { return nil }
        let first = min(linkWindowStart + 1, totalLinkCount)
        let last = min(linkWindowStart + visibleLinks.count, totalLinkCount)
        return "\(first)-\(last) of \(totalLinkCount)"
    }

    var body: some View {
        HStack(spacing: 14) {
            ManualLinkChip(title: "Search Links", subtitle: rangeText, selected: focus == .searchLinks, playable: true)

            if linkWindowStart > 0 {
                Text("‹")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }

            ForEach(Array(visibleLinks.enumerated()), id: \.element.id) { offset, link in
                let absoluteIndex = linkWindowStart + offset
                ManualLinkChip(title: link.quality, subtitle: link.vodLinkDetailLine, selected: focus == .stream(absoluteIndex), playable: link.isDirectPlayable)
            }

            if linkWindowStart + visibleLinks.count < totalLinkCount {
                Text("›")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }
        }
        .frame(width: 1460, alignment: .leading)
    }
}

struct ManualLinkChip: View {
    let title: String
    let subtitle: String?
    let selected: Bool
    let playable: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.system(size: subtitle == nil ? 20 : 18, weight: .black))
            if let subtitle { Text(subtitle).font(.system(size: 12, weight: .semibold)).opacity(0.82).lineLimit(2).fixedSize(horizontal: false, vertical: true) }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 18)
        .padding(.vertical, subtitle == nil ? 12 : 9)
        .background(RoundedRectangle(cornerRadius: 14).fill(selected ? Color.orange.opacity(0.76) : Color.white.opacity(playable ? 0.16 : 0.07)))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(selected ? Color.orange : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
        .scaleEffect(selected ? 1.06 : 1.0)
    }
}

struct ManualRelatedRow: View {
    let focus: DetailPage.DetailNode
    let relatedItems: [MediaItem]
    var baseIndex: Int = 0
    var body: some View {
        HStack(spacing: 24) {
            ForEach(Array(relatedItems.enumerated()), id: \.element.id) { index, item in
                let absoluteIndex = baseIndex + index
                let selected = focus == .related(absoluteIndex)
                ZStack(alignment: .bottomLeading) {
                    RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fit)
                    LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                    Text(item.title)
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                        .padding(14)
                }
                .frame(width: 210, height: 310)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .contentShape(RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? Color.white.opacity(0.06) : Color.white.opacity(0.06), lineWidth: 1))
                .modifier(SafeCardScrollMotion(isFocused: selected, intensity: 0.85))
            }
        }
    }
}

struct RelatedMoviesRow: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    @FocusState private var focusedID: String?

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != current.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(current.genres))) }
        let fallback = all.filter { $0.id != current.id }
        let chosen = sameGenre.isEmpty ? fallback : sameGenre
        return Array(chosen.prefix(8))
    }

    var body: some View {
        HStack(spacing: 24) {
            ForEach(relatedItems) { item in
                Button {
                    store.openDetail(item, pushCurrent: true)
                } label: {
                    ZStack(alignment: .bottomLeading) {
                        RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                        LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                        Text(item.title)
                            .font(.system(size: 19, weight: .black))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                            .padding(14)
                    }
                    .frame(width: 210, height: 310)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .contentShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.06), lineWidth: 1))
                    .modifier(SafeCardScrollMotion(isFocused: focusedID == item.id, intensity: 0.85))
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: item.id)
            }
        }
        .focusSection()
        .onAppear { if focusedID == nil { focusedID = relatedItems.first?.id } }
    }
}

struct StreamLinksRow: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focusedID: String?

    var visibleLinks: [StreamLink] { Array(store.streamLinks.prefix(20)) }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                Button {
                    Task { _ = await store.findStreams(for: item) }
                } label: {
                    Text("Search Links")
                        .font(.system(size: 20, weight: .black))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(focusedID == "search" ? Color.orange.opacity(0.75) : Color.white.opacity(0.12)))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedID == "search" ? Color.orange : Color.white.opacity(0.18), lineWidth: focusedID == "search" ? 3 : 1))
                        .scaleEffect(focusedID == "search" ? 1.06 : 1.0)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: "search")

                ForEach(visibleLinks) { link in
                    Button {
                        if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                            let alternates = store.playableURLs(from: store.streamLinks, selected: link)
                            store.startPlayback(item: item, url: url, alternates: alternates, subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive retry is armed.")
                        } else {
                            store.status = "This link is not direct-playable by AVFoundation. Magnet/infoHash playback needs the planned torrent/libVLC engine or a debrid direct URL."
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(link.quality)
                                .font(.system(size: 18, weight: .heavy))
                            Text(link.size)
                                .font(.system(size: 13, weight: .semibold))
                                .opacity(0.78)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 11)
                        .background(RoundedRectangle(cornerRadius: 13).fill(focusedID == link.id.uuidString ? Color.cyan.opacity(0.58) : Color.cyan.opacity(link.isDirectPlayable ? 0.30 : 0.10)))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(focusedID == link.id.uuidString ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == link.id.uuidString ? 3 : 1))
                        .scaleEffect(focusedID == link.id.uuidString ? 1.06 : 1.0)
                    }
                    .buttonStyle(.plain)
                    .focused($focusedID, equals: link.id.uuidString)
                }
            }
            .focusSection()
        }
        .frame(width: 1220, alignment: .leading)
        .onAppear { if focusedID == nil { focusedID = "search" } }
    }
}


struct MembershipScreen: View {
    @EnvironmentObject var store: CatalogStore
    @State private var email: String = ""
    @State private var deviceId: String = UserDefaults.standard.string(forKey: "DebridChannelsDeviceId") ?? UUID().uuidString
    @State private var membershipStatus: String = "Choose a Debrid Channels membership to support development and unlock access."

    private let backendBaseURL = URL(string: UserDefaults.standard.string(forKey: "backendBaseURL") ?? "http://192.168.100.55:8181")!

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(red: 0.02, green: 0.04, blue: 0.075), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(alignment: .leading, spacing: 28) {
                Text("Debrid Channels Membership")
                    .font(.system(size: 58, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(membershipStatus)
                    .font(.system(size: 24, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .frame(width: 1180, alignment: .leading)
                HStack(spacing: 26) {
                    membershipCard(title: "Supporter", price: "$5.99 / Year", subtitle: "Supports ongoing development and unlocks one year of updates.", tier: "supporter")
                    membershipCard(title: "Lifetime Unlock", price: "$14.99 One-Time", subtitle: "Fully unlocks Debrid Channels with lifetime updates.", tier: "lifetime")
                }
                Text("Restore Membership uses the email used at Stripe checkout. Plans: Supporter, Lifetime, and owner access.")
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.46))
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
        }
        .onAppear {
            UserDefaults.standard.set(deviceId, forKey: "DebridChannelsDeviceId")
        }
    }

    private func membershipCard(title: String, price: String, subtitle: String, tier: String) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title).font(.system(size: 34, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(price).font(.system(size: 42, weight: .black, design: .rounded)).foregroundStyle(Color(red: 0.20, green: 0.62, blue: 1.0))
            Text(subtitle).font(.system(size: 20, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.70)).lineLimit(3)
            Button { startCheckout(tier: tier) } label: {
                Text(tier == "lifetime" ? "Unlock Forever" : "Continue Supporting")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .padding(.horizontal, 28).padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(30)
        .frame(width: 560, height: 350, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 30, style: .continuous).fill(Color.white.opacity(0.085)))
        .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(0.55), lineWidth: 2))
        .shadow(color: Color(red: 0.16, green: 0.58, blue: 1.0).opacity(0.18), radius: 28, y: 12)
    }

    private func startCheckout(tier: String) {
        let planName = tier == "lifetime" ? "Lifetime" : "Supporter"
        membershipStatus = "Opening Stripe checkout for \(planName)…"
        guard var comps = URLComponents(url: backendBaseURL.appendingPathComponent("api/membership/checkout"), resolvingAgainstBaseURL: false) else { return }
        comps.queryItems = [URLQueryItem(name: "tier", value: tier), URLQueryItem(name: "deviceId", value: deviceId)]
        if let url = comps.url { UIApplication.shared.open(url) }
    }
}

struct TrailerPopup: View {
    let url: URL
    let audioURL: URL?
    let sessionID: String
    let close: () -> Void

    @State private var trailerMuted: Bool = false
    @State private var trailerControlsVisible: Bool = true
    @State private var hideControlsTask: Task<Void, Never>? = nil
    @State private var dismissTask: Task<Void, Never>? = nil
    @State private var popupVisible: Bool = false
    @State private var lightSweepActive: Bool = false
    @State private var isClosing: Bool = false
    @FocusState private var focusedAction: TrailerPopupAction?

    private enum TrailerPopupAction: Hashable {
        case mute
        case close
    }

    var body: some View {
        ZStack {
            Color.black
                .opacity(popupVisible && !isClosing ? 0.86 : 0.0)
                .ignoresSafeArea()
                .animation(.easeOut(duration: 0.22), value: popupVisible)
                .animation(.easeIn(duration: 0.16), value: isClosing)

            VStack(spacing: 18) {
                trailerVideoCard
                if trailerControlsVisible { trailerActionRow.transition(.opacity.combined(with: .move(edge: .bottom))) }
            }
            .focusSection()
            .scaleEffect(popupVisible && !isClosing ? 1.0 : 0.92)
            .opacity(popupVisible && !isClosing ? 1.0 : 0.0)
            .blur(radius: popupVisible && !isClosing ? 0 : 8)
            .animation(.spring(response: 0.34, dampingFraction: 0.82), value: popupVisible)
            .animation(.easeIn(duration: 0.16), value: isClosing)
        }
        .onAppear { prepareTrailerPopupEntrance() }
        .onChange(of: url.absoluteString) { _ in prepareTrailerPopupEntrance() }
        .onMoveCommand { direction in
            revealTrailerControls()
            switch direction {
            case .left:
                focusedAction = .mute
            case .right:
                focusedAction = .close
            default:
                break
            }
        }
        .onTapGesture { revealTrailerControls(); activateFocusedTrailerAction() }
        .onPlayPauseCommand { revealTrailerControls(); activateFocusedTrailerAction() }
        .onExitCommand(perform: dismissTrailerPopup)
        .onDisappear {
            hideControlsTask?.cancel()
            dismissTask?.cancel()
        }
    }

    private var trailerVideoCard: some View {
        TrailerPlayableSurface(url: url, audioURL: audioURL, muted: trailerMuted, sessionID: sessionID)
            .id(url.absoluteString + "|audio=\(audioURL?.absoluteString ?? "none")")
            .frame(width: 1540, height: 720)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .background(Color.black)
            .overlay(trailerGlassStroke)
            .overlay(trailerCinemaSweep.clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous)))
            .shadow(color: Color.orange.opacity(0.22), radius: popupVisible ? 38 : 0, x: 0, y: 16)
            .shadow(color: Color.blue.opacity(0.16), radius: popupVisible ? 52 : 0, x: 0, y: -8)
    }

    private var trailerGlassStroke: some View {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
            .stroke(
                LinearGradient(
                    colors: [Color.white.opacity(0.30), Color.orange.opacity(0.22), Color.white.opacity(0.10)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 1.4
            )
    }

    private var trailerCinemaSweep: some View {
        GeometryReader { proxy in
            LinearGradient(
                colors: [Color.clear, Color.white.opacity(0.16), Color.clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(width: 260, height: proxy.size.height * 1.5)
            .rotationEffect(.degrees(18))
            .offset(x: lightSweepActive ? proxy.size.width + 220 : -360, y: -proxy.size.height * 0.22)
            .opacity(lightSweepActive ? 0.0 : 1.0)
            .animation(.easeOut(duration: 0.95).delay(0.12), value: lightSweepActive)
        }
        .allowsHitTesting(false)
    }

    private var trailerActionRow: some View {
        HStack(spacing: 18) {
            Button(action: { revealTrailerControls(); trailerMuted.toggle() }) {
                Text(trailerMuted ? "Unmute" : "Mute")
                    .font(.system(size: 26, weight: .bold))
                    .padding(.horizontal, 34)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .focused($focusedAction, equals: .mute)
            .focusable(true)

            Button(action: dismissTrailerPopup) {
                Text("Close Trailer")
                    .font(.system(size: 26, weight: .bold))
                    .padding(.horizontal, 34)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .focused($focusedAction, equals: .close)
            .focusable(true)
        }
        .focusSection()
        .opacity(popupVisible && !isClosing ? 1.0 : 0.0)
    }

    private func prepareTrailerPopupEntrance() {
        dismissTask?.cancel()
        trailerMuted = false
        trailerControlsVisible = true
        focusedAction = .close
        isClosing = false
        lightSweepActive = false
        popupVisible = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) {
            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) { popupVisible = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { lightSweepActive = true }
        }
        scheduleTrailerControlHide()
    }

    private func activateFocusedTrailerAction() {
        switch focusedAction ?? .close {
        case .mute: trailerMuted.toggle(); scheduleTrailerControlHide()
        case .close: dismissTrailerPopup()
        }
    }

    private func dismissTrailerPopup() {
        hideControlsTask?.cancel()
        dismissTask?.cancel()
        withAnimation(.easeIn(duration: 0.16)) {
            isClosing = true
            trailerControlsVisible = false
        }
        dismissTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 170_000_000)
            close()
        }
    }

    private func revealTrailerControls() {
        withAnimation(.easeOut(duration: 0.18)) { trailerControlsVisible = true }
        if focusedAction == nil { focusedAction = .close }
        scheduleTrailerControlHide()
    }

    private func scheduleTrailerControlHide() {
        hideControlsTask?.cancel()
        hideControlsTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            withAnimation(.easeOut(duration: 0.22)) { trailerControlsVisible = false }
        }
    }
}

struct TrailerPlayableSurface: View {
    let url: URL
    let audioURL: URL?
    let muted: Bool
    let sessionID: String

    var body: some View {
        // v442: trailer popup is AVPlayer-only with a fresh per-title session. The user-facing blocker was that
        // KSPlayer could attach and render the first trailer frame/thumbnail but remain
        // internally paused. Main VOD, Live TV, and guide preview remain on KSPlayer.
        TrailerAVPlayerSurface(url: url, muted: muted, sessionID: sessionID)
            .id(url.absoluteString + "|av-trailer-v442|session=\(sessionID)|muted=\(muted)")
    }
}

struct TrailerAVPlayerSurface: UIViewRepresentable {
    let url: URL
    let muted: Bool
    let sessionID: String

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    final class Coordinator {
        var player: AVPlayer?
        var item: AVPlayerItem?
        var currentURL: URL?
        var currentSessionID: String?
        var endObserver: NSObjectProtocol?
        var statusObserver: NSKeyValueObservation?
        var timeControlObserver: NSKeyValueObservation?
        var rateObserver: NSKeyValueObservation?
        var retryTask: Task<Void, Never>?
        var hasIssuedInitialPlay = false

        deinit { teardown() }

        func teardown() {
            retryTask?.cancel(); retryTask = nil
            if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
            endObserver = nil
            statusObserver = nil
            timeControlObserver = nil
            rateObserver = nil
            player?.pause()
            player?.replaceCurrentItem(with: nil)
            player = nil
            item = nil
            currentURL = nil
            currentSessionID = nil
            hasIssuedInitialPlay = false
        }

        func configure(url: URL, muted: Bool, sessionID: String, view: PlayerLayerView) {
            if currentURL != url || currentSessionID != sessionID || player == nil {
                teardown()

                let asset = AVURLAsset(url: url, options: [
                    AVURLAssetPreferPreciseDurationAndTimingKey: false
                ])
                let nextItem = AVPlayerItem(asset: asset)
                nextItem.preferredForwardBufferDuration = 1
                nextItem.canUseNetworkResourcesForLiveStreamingWhilePaused = true

                let nextPlayer = AVPlayer(playerItem: nextItem)
                // v416 trailer single-player fast-restore fix: do not force AVPlayer into no-wait mode on tvOS.
                // v410 could load the first frame and then sit at rate 0 on slow HLS/remux URLs.
                nextPlayer.automaticallyWaitsToMinimizeStalling = false
                nextPlayer.preventsDisplaySleepDuringVideoPlayback = true
                nextPlayer.actionAtItemEnd = .none
                nextPlayer.isMuted = muted
                nextPlayer.volume = muted ? 0.0 : 1.0

                view.playerLayer.player = nextPlayer
                view.playerLayer.videoGravity = .resizeAspectFill
                view.playerLayer.backgroundColor = UIColor.black.cgColor

                player = nextPlayer
                item = nextItem
                currentURL = url
                currentSessionID = sessionID

                statusObserver = nextItem.observe(\.status, options: [.new, .initial]) { [weak self] item, _ in
                    guard item.status == .readyToPlay else { return }
                    DispatchQueue.main.async { self?.startPlaybackIfNeeded() }
                }
                timeControlObserver = nextPlayer.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
                    // v412: do not spam playImmediately while the item is buffering. Repeated
                    // play kicks against a still-growing trailer source caused the visible
                    // opening-frame replay/loop effect. Only rescue a pause after playback
                    // has already been issued for this one player instance.
                    guard player.timeControlStatus == .paused else { return }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self?.resumeIfUnexpectedlyPaused() }
                }
                rateObserver = nextPlayer.observe(\.rate, options: [.new]) { [weak self] player, _ in
                    guard player.rate == 0 else { return }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { self?.resumeIfUnexpectedlyPaused() }
                }
                endObserver = NotificationCenter.default.addObserver(
                    forName: .AVPlayerItemDidPlayToEndTime,
                    object: nextItem,
                    queue: .main
                ) { [weak self] _ in
                    self?.player?.seek(to: .zero)
                    self?.hasIssuedInitialPlay = false
                    self?.startPlaybackIfNeeded()
                }

                startPlaybackIfNeeded(forceSeek: true)
                retryTask = Task { @MainActor [weak self] in
                    try? await Task.sleep(nanoseconds: 650_000_000)
                    self?.startPlaybackIfNeeded()
                    try? await Task.sleep(nanoseconds: 1_250_000_000)
                    self?.resumeOrRebuildIfStuck()
                }
            } else {
                player?.isMuted = muted
                player?.volume = muted ? 0.0 : 1.0
                startPlaybackIfNeeded()
            }
        }

        func startPlaybackIfNeeded(forceSeek: Bool = false) {
            guard let player, let item, item.status == .readyToPlay else { return }
            if hasIssuedInitialPlay && player.rate > 0 { return }
            hasIssuedInitialPlay = true
            if forceSeek { player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero) }
            if #available(tvOS 10.0, *) { player.playImmediately(atRate: 1.0) }
            else { player.play() }
        }

        func resumeIfUnexpectedlyPaused() {
            guard let player, let item, item.status == .readyToPlay else { return }
            guard hasIssuedInitialPlay, player.rate == 0, player.timeControlStatus == .paused else { return }
            if #available(tvOS 10.0, *) { player.playImmediately(atRate: 1.0) } else { player.play() }
        }

        func resumeOrRebuildIfStuck() {
            guard let player, let item, item.status == .readyToPlay else { return }
            guard player.rate == 0 else { return }
            player.pause()
            player.seek(to: .zero, toleranceBefore: .zero, toleranceAfter: .zero) { _ in
                if #available(tvOS 10.0, *) { player.playImmediately(atRate: 1.0) } else { player.play() }
            }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        context.coordinator.configure(url: url, muted: muted, sessionID: sessionID, view: view)
    }

    static func dismantleUIView(_ view: PlayerLayerView, coordinator: Coordinator) {
        coordinator.teardown()
        view.playerLayer.player = nil
    }
}



struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL

    @State private var player: AVPlayer? = nil
    @State private var controlsVisible = true
    @State private var isPlaying = true
    @State private var isLoading = true
    @State private var errorText: String? = nil
    @State private var retryText: String? = nil
    @State private var currentSeconds: Double = 0
    @State private var durationSeconds: Double = 0
    @State private var metadataRuntimeSeconds: Double = 0
    @State private var metadataRuntimeLabel: String = ""
    @State private var runtimeLookupTask: Task<Void, Never>? = nil
    @State private var videoGravity: AVLayerVideoGravity = .resizeAspect
    @State private var timeObserver: Any? = nil
    @State private var statusObserver: NSKeyValueObservation? = nil
    @State private var hideTask: Task<Void, Never>? = nil
    @State private var endObserver: NSObjectProtocol? = nil
    @State private var renderWatchdogTask: Task<Void, Never>? = nil
    @State private var nativePrepareTask: Task<Void, Never>? = nil
    @State private var activePanel: PlayerPanel? = nil
    @State private var playbackNotice: String = ""
    @State private var lastPlayerActionAt: TimeInterval = 0
    @State private var lastPlayerMoveAt: TimeInterval = 0
    @State private var forceVLCSurface = false
    @State private var forceKSPlayerSurface = true
    @State private var avRetryAttemptedForCurrentURL = false
    @State private var nativeProfileText: String = ""
    @State private var diagnosticsTick: Int = 0
    @State private var vlcSeekSerial = 0
    @State private var vlcSeekSeconds: Double = 0
    @State private var vlcSurfaceToken: Int = 0
    @State private var ksSurfaceToken: Int = 0
    @State private var ksStartTimeSeconds: Double = 0
    @FocusState private var focusedControl: PlayerControl?
    @FocusState private var playerCanvasFocused: Bool
    @AppStorage("vodCacheLimitGB") private var vodCacheLimitGB: Int = 10
    @AppStorage("vodPlaybackDiagnosticsEnabled") private var vodPlaybackDiagnosticsEnabled: Bool = false
    @AppStorage("tmdbApiKey") private var vodTMDBApiKey: String = ""
    @AppStorage("externalMoviesInfuseDefault") private var externalMoviesInfuseDefault: Bool = false
    @AppStorage("externalMoviesVLCDefault") private var externalMoviesVLCDefault: Bool = false
    @AppStorage("externalMoviesSenPlayerDefault") private var externalMoviesSenPlayerDefault: Bool = false
    @AppStorage("externalShowsInfuseDefault") private var externalShowsInfuseDefault: Bool = false
    @AppStorage("externalShowsVLCDefault") private var externalShowsVLCDefault: Bool = false
    @AppStorage("externalShowsSenPlayerDefault") private var externalShowsSenPlayerDefault: Bool = false
    @AppStorage("liveTVUseAVPlayerDefault") private var liveTVUseAVPlayerDefault: Bool = false
    @StateObject private var cacheSession = TemporaryVODCacheSession()
    @State private var preparedPlaybackURL: URL? = nil
    @State private var vodBootstrapDeadline: Date? = nil
    @State private var playbackClockTask: Task<Void, Never>? = nil
    @State private var startupLoadingTask: Task<Void, Never>? = nil
    @State private var lastKnownControlFocus: PlayerControl = .playPause
    @State private var didSeedVODOverlayFocus = false
    @State private var selectedAudioMode: String = "Auto"
    @State private var selectedSubtitleMode: String = "Off"
    @State private var selectedPlaybackMode: String = "KS Direct"
    @State private var selectedEpisodeSeason: Int = 1
    @State private var isFindingAlternateAudio = false
    @State private var selectedAlternateAudioIndex: Int? = nil
    @StateObject private var liveQuickGuideModel = LiveTVSourceModel()
    @State private var liveQuickGuideVisible = false
    @State private var liveQuickGuideIndex: Int = 0
    @FocusState private var focusedPanelOption: PlayerPanelOption?
    @State private var selectedPanelOption: PlayerPanelOption? = nil
    @State private var vodOverlayLockedForRemoteNavigation = false

    enum PlayerControl: Hashable { case back10, playPause, forward10, ksplayer, internalVLC, avplayer, audio, findAudio, subtitles, episodes, zoom, settings, infuse, vlc, senplayer, close }
    enum PlayerPanel: Hashable { case audio, subtitles, episodes, settings }
    enum PlayerPanelOption: Hashable { case audioAuto, audioEnglish, audioOriginal, audioNext, findAlternateAudio, alternateAudio(Int), alternateAudioMinus250, alternateAudioPlus250, alternateAudioReset, alternateAudioClear, subtitlesOff, subtitlesEnglish, subtitlesAuto, subtitlesNext, season(Int), episodesOpen, cache5, cache10, cacheUnlimited, frameRateInfo, settingsDiagnostics, settingsFindAudio, settingsInfuse, settingsVLC, settingsSenPlayer, closePanel }

    private var activeEngineName: String {
        if isLivePlayback && forceKSPlayerSurface { return "KSPlayer Live TV" }
        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface { return "AVPlayer Live TV" }
        return forceKSPlayerSurface ? "KSPlayer Internal" : "VLC Internal"
    }

    private var resolvedDurationSeconds: Double {
        let playerDuration = durationSeconds.isFinite ? durationSeconds : 0
        if playerDuration > 1 { return playerDuration }
        let metadataDuration = metadataRuntimeSeconds.isFinite ? metadataRuntimeSeconds : 0
        if metadataDuration > 1 { return metadataDuration }
        return 0
    }

    private var progress: Double {
        let total = resolvedDurationSeconds
        guard total > 0 else { return 0 }
        return min(max(currentSeconds / total, 0), 1)
    }

    private var remainingSeconds: Double {
        let total = resolvedDurationSeconds
        guard total > 0 else { return 0 }
        return max(total - currentSeconds, 0)
    }

    private var progressPercentText: String {
        guard resolvedDurationSeconds > 0 else { return "0%" }
        return "\(Int((progress * 100).rounded()))%"
    }

    private var isLivePlayback: Bool {
        item.type.lowercased() == "live" || store.playbackLinkLabel.localizedCaseInsensitiveContains("Live TV")
    }

    private var activePlaybackURL: URL? {
        if isLivePlayback { return url }
        // v259: KSPlayer must start from the resolved direct stream immediately.
        // The temp cache warms in parallel and is kept as a safe fallback/resume source;
        // do not hot-swap the visible KS surface to a partial cache file while a user is watching.
        if forceKSPlayerSurface { return url }
        return cacheSession.playbackURL ?? url
    }

    private var vodStartThresholdBytes: Int64 {
        256 * 1024
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            if let activePlaybackURL {
                UniversalVideoSurface(
                    url: activePlaybackURL,
                    avPlayer: player,
                    videoGravity: videoGravity,
                    forceVLC: forceVLCSurface,
                    routeHint: store.playbackLinkLabel,
                    vlcShouldPlay: isPlaying,
                    vlcSeekSerial: vlcSeekSerial,
                    vlcSeekSeconds: vlcSeekSeconds,
                    vlcSurfaceToken: vlcSurfaceToken,
                    ksShouldPlay: isPlaying,
                    ksSeekSerial: vlcSeekSerial,
                    ksSeekSeconds: vlcSeekSeconds,
                    ksReloadToken: ksSurfaceToken,
                    ksStartTimeSeconds: ksStartTimeSeconds,
                    preferKSPlayer: forceKSPlayerSurface,
                    preferAVFoundation: isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface,
                    externalAudioURL: store.selectedAlternateAudioSource.flatMap { URL(string: $0.url) },
                    externalAudioOffsetMS: store.alternateAudioSyncOffsetMS
                )
                .ignoresSafeArea()
                .zIndex(0)
                .allowsHitTesting(!(controlsVisible || activePanel != nil || isLoading || errorText != nil))
                .disabled(controlsVisible || activePanel != nil || isLoading || errorText != nil)
                .focusable(false)
            } else {
                Color.black.ignoresSafeArea()
            }

            if isLoading {
                ZStack {
                    Color.black.opacity(0.30).ignoresSafeArea()
                    DebridMovieLoadingView(message: retryText ?? "Loading movie…")
                }
                .zIndex(30)
            }

            if let errorText {
                ApplePlayerErrorCard(message: errorText) { store.closePlayer() }
                    .zIndex(40)
            }

            if isLivePlayback && liveQuickGuideVisible {
                livePlaybackQuickGuideOverlay
                    .zIndex(35)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            // v151: diagnostics are useful, but keeping a diagnostic panel alive over every playing
            // frame adds SwiftUI/compositing work exactly where cadence is most sensitive. Show it while
            // paused/loading/settings are open, not during normal hidden-controls playback.
            if !isLivePlayback && vodPlaybackDiagnosticsEnabled && (!isPlaying || activePanel == .settings || isLoading || errorText != nil) {
                DebridPlaybackDiagnosticsPanel(diagnostics: currentPlaybackDiagnostics())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .padding(.top, 42)
                    .padding(.trailing, 54)
                    .zIndex(12)
                    .transition(.opacity)
            }

            if controlsVisible || activePanel != nil {
                AppleVODChromeBackground()
                    .ignoresSafeArea()
                    .opacity(isPlaying ? 0.18 : 1.0)
                    .allowsHitTesting(false)
            }

            if let activePanel {
                // v269: panel shield blocks remote/tap leakage to the bottom VOD bar while
                // the option panel is open. The bottom bar remains visible, but is silenced.
                Color.black.opacity(0.001)
                    .ignoresSafeArea()
                    .contentShape(Rectangle())
                    .allowsHitTesting(true)
                    .zIndex(34)

                DebridPlayerPanel(
                    title: panelTitle(activePanel),
                    detail: panelDetail(activePanel),
                    focusedOption: selectedPanelOption ?? focusedPanelOption
                ) {
                    panelOptions(activePanel)
                    PanelOptionChip(title: "Close Panel", selected: (selectedPanelOption ?? focusedPanelOption) == .closePanel, focus: .closePanel, focused: $focusedPanelOption) {
                        focusedPanelOption = .closePanel
                        selectedPanelOption = .closePanel
                        activateFocusedPanelOption()
                    }
                }
                .focusSection()
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
                .padding(.trailing, 76)
                .padding(.bottom, 292)
                .zIndex(35)
                .onAppear { seedPanelFocus(activePanel) }
            }

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .bottom, spacing: 26) {
                    AppleVODPosterCard(item: item)

                    VStack(alignment: .leading, spacing: 12) {
                        // v152: VOD overlay keeps the themed logo, but it is static only.
                        // No pulse animation, and no extra large title text.
                        HeroLogoText(item: item, pulse: false)
                            .frame(width: 520, height: 82, alignment: .leading)
                            .allowsHitTesting(false)

                        HStack(spacing: 12) {
                            AppleVODBadge(text: activeEngineName, highlighted: true)
                            AppleVODBadge(text: videoGravity == .resizeAspectFill ? "Fill" : "Aspect Fit", highlighted: false)
                            AppleVODBadge(text: item.rating.isEmpty ? "NR" : "★ \(item.rating)", highlighted: false)
                            AppleVODBadge(text: item.year, highlighted: false)
                            if let alt = store.selectedAlternateAudioSource {
                                AppleVODBadge(text: "Alt Audio: \(alt.confidence)", highlighted: true)
                            }
                        }

                        Text("\(item.type.capitalized)  •  \(item.genres.prefix(3).joined(separator: "  •  "))")
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))

                        Text(item.description)
                            .font(.system(size: 21, weight: .medium, design: .rounded))
                            .lineLimit(2)
                            .foregroundStyle(.white.opacity(0.72))
                            .frame(width: 1040, alignment: .leading)
                    }
                }

                HStack(alignment: .center, spacing: 18) {
                    Text(formatTime(currentSeconds))
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 86, alignment: .leading)
                    PlayerProgressBar(progress: progress)
                        .frame(width: 1290, height: 14)
                    Text(resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "--:--")
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 96, alignment: .trailing)
                }
                .foregroundStyle(.white.opacity(0.92))

                VODRuntimeProgressSummary(
                    title: item.title,
                    current: formatTime(currentSeconds),
                    total: isLivePlayback ? "LIVE" : (resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "--:--"),
                    remaining: isLivePlayback ? "LIVE" : formatTime(remainingSeconds),
                    percent: isLivePlayback ? "LIVE" : progressPercentText,
                    cacheLabel: isLivePlayback ? "Live TV: cache disabled" : cacheLimitLabel,
                    cacheUsed: isLivePlayback ? "0.00GB" : String(format: "%.2fGB", cacheUsedGB),
                    cacheLimit: isLivePlayback ? "Disabled" : (cacheLimitGBValue == 0 ? "Unlimited" : String(format: "%.0fGB", cacheLimitGBValue))
                )
                .frame(width: 1510, alignment: .leading)

                if !isLivePlayback {
                    VODCacheProgressRow(cacheLabel: cacheLimitLabel, usedGB: cacheUsedGB, limitGB: cacheLimitGBValue, progress: cacheFillProgress, status: cacheSession.statusText)
                        .frame(width: 1510, alignment: .leading)
                }

                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            PlayerControlButton(title: "−30", focus: .back10, focused: $focusedControl) { playerAction { seekRelative(-30) } }.id(PlayerControl.back10)
                            PlayerControlButton(title: isPlaying ? "Pause" : "Play", focus: .playPause, focused: $focusedControl) { playerAction { togglePlay() } }.id(PlayerControl.playPause)
                            PlayerControlButton(title: "+30", focus: .forward10, focused: $focusedControl) { playerAction { seekRelative(30) } }.id(PlayerControl.forward10)
                            PlayerControlButton(title: "KS", focus: .ksplayer, focused: $focusedControl) { playerAction { selectedPlaybackMode = "KS Direct"; switchToKSPlayerEngine(manual: true) } }.id(PlayerControl.ksplayer)
                            PlayerControlButton(title: "VLC", focus: .internalVLC, focused: $focusedControl) { playerAction { selectedPlaybackMode = "VLC Internal"; switchToVLCEngine(manual: true) } }.id(PlayerControl.internalVLC)
                            PlayerControlButton(title: "AV", focus: .avplayer, focused: $focusedControl) { playerAction { selectedPlaybackMode = "AVPlayer"; switchToAVPlayerEngine(manual: true) } }.id(PlayerControl.avplayer)
                            PlayerControlButton(title: "Audio: \(selectedAudioMode)", focus: .audio, focused: $focusedControl) { playerAction { activePanel = .audio; seedPanelFocus(.audio); forceControlsVisibleForNavigation() } }.id(PlayerControl.audio)
                            PlayerControlButton(title: "Subs: \(selectedSubtitleMode)", focus: .subtitles, focused: $focusedControl) { playerAction { activePanel = .subtitles; seedPanelFocus(.subtitles); forceControlsVisibleForNavigation() } }.id(PlayerControl.subtitles)
                            PlayerControlButton(title: "Episodes: S\(selectedEpisodeSeason)", focus: .episodes, focused: $focusedControl) { playerAction { activePanel = .episodes; seedPanelFocus(.episodes); forceControlsVisibleForNavigation() } }.id(PlayerControl.episodes)
                            PlayerControlButton(title: "Zoom", focus: .zoom, focused: $focusedControl) { playerAction { toggleZoom() } }.id(PlayerControl.zoom)
                            PlayerControlButton(title: "Settings", focus: .settings, focused: $focusedControl) { playerAction { activePanel = .settings; seedPanelFocus(.settings); forceControlsVisibleForNavigation() } }.id(PlayerControl.settings)
                            PlayerControlButton(title: "Close", focus: .close, focused: $focusedControl) { playerAction { store.closePlayer() } }.id(PlayerControl.close)
                        }
                        .padding(.trailing, 620)
                    }
                    .frame(width: 1510, alignment: .leading)
                    .onAppear { seedVODOverlayFocusIfNeeded(); if let f = focusedControl { proxy.scrollTo(f, anchor: .center) } }
                    .onChange(of: focusedControl) { newFocus in
                        guard let newFocus else { return }
                        withAnimation(.easeOut(duration: 0.16)) { proxy.scrollTo(newFocus, anchor: .center) }
                    }
                }
                .focusSection()
                .modifier(VODFocusBoundaryModifier())
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.black.opacity(0.22)))
                .contentShape(Rectangle())
            }
            .foregroundStyle(.white)
            .padding(.leading, 68)
            .padding(.bottom, 58)
            .frame(maxWidth: .infinity, alignment: .leading)
            .opacity(controlsVisible ? 1.0 : 0.0)
            .allowsHitTesting(controlsVisible && activePanel == nil)
            .disabled(activePanel != nil)
            .focusable(activePanel == nil)
            .focusSection()
            .contentShape(Rectangle())
            .zIndex(25)
            .animation(isPlaying ? nil : .easeInOut(duration: 0.22), value: controlsVisible)
        }
        .contentShape(Rectangle())
        .focusSection()
        .onAppear { setupPlayer(); if isLivePlayback { liveQuickGuideModel.loadCachedOrDemo(); controlsVisible = false } else { forceControlsVisibleForNavigation(); seedVODOverlayFocusIfNeeded() } }
        .onDisappear { teardownPlayer() }
        .onMoveCommand { direction in routePlayerMove(direction) }
        .onTapGesture {
            handlePlayerSelectPress()
        }
        .onPlayPauseCommand {
            handlePlayerPlayPausePress()
        }
        .onChange(of: controlsVisible) { visible in
            if visible { seedVODOverlayFocusIfNeeded() }
        }
        .onChange(of: activePanel) { panel in
            if let panel { vodOverlayLockedForRemoteNavigation = true; seedPanelFocus(panel) } else { focusedPanelOption = nil; selectedPanelOption = nil; vodOverlayLockedForRemoteNavigation = controlsVisible }
        }
        .onChange(of: focusedControl) { newFocus in
            if let newFocus, visiblePlayerControlOrder.contains(newFocus) { lastKnownControlFocus = newFocus }
        }
        .onExitCommand { if activePanel != nil { activePanel = nil; selectedPanelOption = nil; focusedPanelOption = nil; forceControlsVisibleForNavigation() } else { store.closePlayer() } }
    }

    private func ensureVODChipsFocused(lockOverlay: Bool = true) {
        if lockOverlay { vodOverlayLockedForRemoteNavigation = true }
        forceControlsVisibleForNavigation(lockOverlay: lockOverlay)
        if focusedControl == nil || !visiblePlayerControlOrder.contains(focusedControl!) {
            if !visiblePlayerControlOrder.contains(lastKnownControlFocus) { lastKnownControlFocus = .playPause }
            focusedControl = lastKnownControlFocus
        }
        didSeedVODOverlayFocus = true
    }

    private var visiblePlayerControlOrder: [PlayerControl] {
        [.back10, .playPause, .forward10, .ksplayer, .internalVLC, .audio, .subtitles, .episodes, .zoom, .settings, .close]
    }

    private func handlePlayerSelectPress() {
        if isLivePlayback && liveQuickGuideVisible { playLiveQuickGuideSelection(); return }
        if activePanel != nil { activateFocusedPanelOption(); return }
        if !controlsVisible { ensureVODChipsFocused(lockOverlay: true); return }
        ensureVODChipsFocused(lockOverlay: true)
        activateFocusedPlayerControl()
    }

    private func handlePlayerPlayPausePress() {
        if isLivePlayback && liveQuickGuideVisible { playerAction { playLiveQuickGuideSelection() }; return }
        if activePanel != nil { activateFocusedPanelOption(); return }
        // v384: the Siri Remote Play/Pause button is treated as an overlay reveal/focus command first.
        // It must not immediately activate the Play/Pause chip and hide the VOD overlay on the same press.
        // Center/select activates the highlighted chip after the overlay is stable.
        ensureVODChipsFocused(lockOverlay: true)
    }

    private var liveQuickGuideChannels: [LiveTVChannel] {
        let loaded = liveQuickGuideModel.channels.isEmpty ? [] : liveQuickGuideModel.channels
        return loaded.isEmpty ? LiveTVScreen.sampleChannels : loaded
    }

    private var currentLiveQuickGuideChannel: LiveTVChannel? {
        liveQuickGuideChannels.first(where: { $0.name == item.title || "live-\($0.id)-\($0.streamURL.hashValue)" == item.id })
    }

    private var livePlaybackQuickGuideOverlay: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Text("Quick Guide")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                    .padding(.horizontal, 28)
                    .padding(.vertical, 11)
                    .background(Capsule().fill(Color.white.opacity(0.28)))
                Text("Options")
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.horizontal, 22)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color.black.opacity(0.22)))
                Spacer()
                Text(Date().formatted(date: .omitted, time: .shortened))
                    .font(.system(size: 25, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.86))
            }
            .padding(.horizontal, 74)
            .padding(.top, 48)
            .padding(.bottom, 20)

            liveQuickGuideChannelRail
                .padding(.horizontal, 74)

            if let selected = liveQuickGuideSelectedChannel {
                let program = liveQuickGuideModel.currentProgram(for: selected) ?? liveQuickGuideModel.programs(for: selected).first
                HStack(alignment: .center, spacing: 28) {
                    liveQuickGuideLogo(selected)
                    VStack(alignment: .leading, spacing: 8) {
                        Text(program?.title ?? selected.now)
                            .font(.system(size: 34, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text([selected.number, selected.source, selected.category].filter { !$0.isEmpty }.joined(separator: " • "))
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.72))
                            .lineLimit(1)
                        Text((program?.description).flatMap { $0.isEmpty ? nil : $0 } ?? selected.description)
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.86))
                            .lineLimit(2)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 8) {
                        Text("Left/Right browses guide • Up/Down hides")
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white.opacity(0.55))
                        Text("Select/Play opens channel")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))
                    }
                }
                .padding(.horizontal, 74)
                .padding(.top, 20)
                .padding(.bottom, 28)
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(
            LinearGradient(colors: [Color.blue.opacity(0.92), Color.indigo.opacity(0.64), Color.black.opacity(0.16), Color.clear], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        )
        .onAppear { syncLiveQuickGuideIndexToCurrentChannel() }
        .onExitCommand { liveQuickGuideVisible = false }
    }

    private var liveQuickGuideSelectedChannel: LiveTVChannel? {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return nil }
        let index = min(max(liveQuickGuideIndex, 0), channels.count - 1)
        return channels[index]
    }

    private var liveQuickGuideChannelRail: some View {
        let channels = liveQuickGuideWindow
        return HStack(spacing: 18) {
            ForEach(channels, id: \.id) { channel in
                let isSelected = channel.id == liveQuickGuideSelectedChannel?.id
                let program = liveQuickGuideModel.currentProgram(for: channel) ?? liveQuickGuideModel.programs(for: channel).first
                ZStack(alignment: .bottomLeading) {
                    if let imageURL = program?.imageURL, let url = URL(string: imageURL), !imageURL.isEmpty {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .success(let image): image.resizable().scaledToFit().padding(6)
                            default: LinearGradient(colors: [channel.accent.opacity(0.40), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
                            }
                        }
                    } else if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                        ZStack { channel.accent.opacity(0.34); AsyncImage(url: url) { phase in if case .success(let image) = phase { image.resizable().scaledToFit().padding(22) } else { Text(channel.logo).font(.system(size: 30, weight: .black)) } } }
                    } else {
                        LinearGradient(colors: [channel.accent.opacity(0.46), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    }
                    LinearGradient(colors: [.clear, .black.opacity(0.88)], startPoint: .center, endPoint: .bottom)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(program?.title ?? channel.now)
                            .font(.system(size: isSelected ? 21 : 18, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text(channel.name)
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.74))
                            .lineLimit(1)
                    }
                    .padding(12)
                }
                .frame(width: isSelected ? 292 : 250, height: isSelected ? 174 : 142)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(isSelected ? Color.white.opacity(0.92) : Color.white.opacity(0.15), lineWidth: isSelected ? 4 : 1))
                .shadow(color: .black.opacity(isSelected ? 0.48 : 0.20), radius: isSelected ? 18 : 8, y: isSelected ? 10 : 4)
                .animation(.easeOut(duration: 0.12), value: isSelected)
            }
        }
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private var liveQuickGuideWindow: [LiveTVChannel] {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return [] }
        let center = min(max(liveQuickGuideIndex, 0), channels.count - 1)
        let start = max(0, center - 3)
        let end = min(channels.count, start + 7)
        return Array(channels[start..<end])
    }

    private func liveQuickGuideLogo(_ channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.28))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 30, weight: .black)) }
                }
                .padding(12)
            } else {
                Text(channel.logo).font(.system(size: 30, weight: .black))
            }
        }
        .frame(width: 150, height: 88)
    }

    private func syncLiveQuickGuideIndexToCurrentChannel() {
        liveQuickGuideModel.loadCachedOrDemo()
        let channels = liveQuickGuideChannels
        if let idx = channels.firstIndex(where: { $0.name == item.title || "live-\($0.id)-\($0.streamURL.hashValue)" == item.id }) {
            liveQuickGuideIndex = idx
        } else if liveQuickGuideIndex >= channels.count {
            liveQuickGuideIndex = max(0, channels.count - 1)
        }
    }

    private func moveLiveQuickGuide(_ delta: Int) {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return }
        liveQuickGuideIndex = min(max(liveQuickGuideIndex + delta, 0), channels.count - 1)
    }

    private func playLiveQuickGuideSelection() {
        guard let channel = liveQuickGuideSelectedChannel, let playURL = URL(string: channel.streamURL), !channel.streamURL.isEmpty else { return }
        liveQuickGuideVisible = false
        store.startPlayback(
            item: MediaItem(id: "live-\(channel.id)-\(channel.streamURL.hashValue)", title: channel.name, year: "Live", type: "live", catalog: channel.source, description: channel.description, genres: [channel.category, channel.source], rating: "", posterURL: channel.iconURL, landscapeURL: nil, logoURL: nil, previewURL: nil),
            url: playURL,
            alternates: [],
            subtitles: [],
            label: "Live TV direct stream: \(channel.name) • \(channel.source) • \(channel.number) • quick guide selection"
        )
    }

    private func seedVODOverlayFocusIfNeeded() {
        guard controlsVisible else { return }
        guard !didSeedVODOverlayFocus || focusedControl == nil else { return }
        didSeedVODOverlayFocus = true
        if focusedControl == nil || !visiblePlayerControlOrder.contains(focusedControl!) {
            if !visiblePlayerControlOrder.contains(lastKnownControlFocus) { lastKnownControlFocus = .playPause }
            focusedControl = lastKnownControlFocus
        }
    }

    private func activateFocusedPlayerControl() {
        if activePanel != nil {
            activateFocusedPanelOption()
            return
        }
        lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        switch focusedControl ?? lastKnownControlFocus {
        case .back10: playerAction { seekRelative(-30) }
        case .playPause: playerAction { togglePlay() }
        case .forward10: playerAction { seekRelative(30) }
        case .ksplayer: playerAction { switchToKSPlayerEngine(manual: true) }
        case .avplayer: playerAction { switchToAVPlayerEngine(manual: true) }
        case .internalVLC: playerAction { switchToVLCEngine(manual: true) }
        case .audio: playerAction { activePanel = .audio; seedPanelFocus(.audio); forceControlsVisibleForNavigation() }
        case .findAudio: playerAction { findAlternateAudio() }
        case .subtitles: playerAction { activePanel = .subtitles; seedPanelFocus(.subtitles); forceControlsVisibleForNavigation() }
        case .episodes: playerAction { activePanel = .episodes; seedPanelFocus(.episodes); store.status = "Episode selector is wired into the Apple-style VOD overlay and ready for series episode rows."; forceControlsVisibleForNavigation() }
        case .zoom: playerAction { toggleZoom() }
        case .settings: playerAction { activePanel = .settings; seedPanelFocus(.settings); forceControlsVisibleForNavigation() }
        case .infuse: playerAction { openExternal(.infuse) }
        case .vlc: playerAction { openExternal(.vlc) }
        case .senplayer: playerAction { openExternal(.senPlayer) }
        case .close: playerAction { store.closePlayer() }
        }
    }

    private func playerAction(_ action: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastPlayerActionAt > 0.44 else { return }
        lastPlayerActionAt = now
        action()
    }

    private func routePlayerMove(_ direction: MoveCommandDirection) {
        let now = Date().timeIntervalSinceReferenceDate
        let moveDebounce: TimeInterval = activePanel != nil ? 0.42 : (isLivePlayback ? 0.34 : 0.40)
        guard now - lastPlayerMoveAt > moveDebounce else { return }
        lastPlayerMoveAt = now

        // v354 input priority is explicit and ordered:
        // 1) Open chip submenu owns UP/DOWN.
        // 2) Visible Live TV quick guide owns LEFT/RIGHT browsing only; UP/DOWN hides it.
        // 3) Visible chip rail owns LEFT/RIGHT chip movement.
        // 4) UP/DOWN opens quick guide only when no chip submenu is open.
        if let panel = activePanel {
            routePanelMove(direction, panel: panel)
            return
        }

        if liveQuickGuideVisible {
            switch direction {
            case .left:
                moveLiveQuickGuide(-1)
            case .right:
                moveLiveQuickGuide(1)
            case .up, .down:
                withAnimation(.easeOut(duration: 0.16)) { liveQuickGuideVisible = false }
            default:
                break
            }
            return
        }

        if !controlsVisible {
            if isLivePlayback, direction == .up || direction == .down {
                syncLiveQuickGuideIndexToCurrentChannel()
                withAnimation(.easeOut(duration: 0.18)) { liveQuickGuideVisible = true }
            } else if !isLivePlayback {
                switch direction {
                case .left:
                    seekRelative(-30, revealControls: false)
                case .right:
                    seekRelative(30, revealControls: false)
                case .up, .down:
                    ensureVODChipsFocused()
                default:
                    break
                }
            }
            return
        }

        vodOverlayLockedForRemoteNavigation = true
        showControlsWithoutChangingFocus()
        let order = visiblePlayerControlOrder
        let current = focusedControl ?? lastKnownControlFocus
        let idx = order.firstIndex(of: current) ?? 1
        switch direction {
        case .left:
            focusedControl = order[(idx - 1 + order.count) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .right:
            focusedControl = order[(idx + 1) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .up, .down:
            if isLivePlayback {
                syncLiveQuickGuideIndexToCurrentChannel()
                withAnimation(.easeOut(duration: 0.18)) { liveQuickGuideVisible = true }
            } else {
                focusedControl = current
            }
        default:
            break
        }
    }

    private func panelOptionsList(_ panel: PlayerPanel) -> [PlayerPanelOption] {
        switch panel {
        case .audio:
            return [.audioAuto, .audioEnglish, .audioOriginal, .audioNext, .findAlternateAudio] + store.alternateAudioSources.indices.map { PlayerPanelOption.alternateAudio($0) } + [.alternateAudioMinus250, .alternateAudioPlus250, .alternateAudioReset, .alternateAudioClear, .closePanel]
        case .subtitles: return [.subtitlesOff, .subtitlesEnglish, .subtitlesAuto, .subtitlesNext, .closePanel]
        case .episodes: return (1...8).map { PlayerPanelOption.season($0) } + [.episodesOpen, .closePanel]
        case .settings: return [.cache5, .cache10, .cacheUnlimited, .frameRateInfo, .settingsDiagnostics, .settingsFindAudio, .settingsInfuse, .settingsVLC, .settingsSenPlayer, .closePanel]
        }
    }

    private func seedPanelFocus(_ panel: PlayerPanel) {
        let first = panelOptionsList(panel).first
        selectedPanelOption = first
        focusedPanelOption = first
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            selectedPanelOption = first
            focusedPanelOption = first
        }
    }

    private func routePanelMove(_ direction: MoveCommandDirection, panel: PlayerPanel) {
        let options = panelOptionsList(panel)
        guard !options.isEmpty else { return }
        let current = selectedPanelOption ?? focusedPanelOption ?? options[0]
        let idx = options.firstIndex(of: current) ?? 0
        let next: PlayerPanelOption
        switch direction {
        case .up:
            next = options[max(0, idx - 1)]
        case .down:
            next = options[min(options.count - 1, idx + 1)]
        case .left, .right:
            // While a chip submenu is open, UP/DOWN moves inside that submenu only.
            // LEFT/RIGHT are reserved for the bottom VOD chip rail before a submenu opens.
            return
        default:
            return
        }
        selectedPanelOption = next
        focusedPanelOption = next
    }

    private func activateFocusedPanelOption() {
        guard let panel = activePanel else { return }
        let option = selectedPanelOption ?? focusedPanelOption ?? panelOptionsList(panel).first
        switch option {
        case .audioAuto:
            selectedAudioMode = "Auto"; selectAudioOverlayOption("Auto / English preferred")
        case .audioEnglish:
            selectedAudioMode = "English"; selectAudioOverlayOption("English")
        case .audioOriginal:
            selectedAudioMode = "Original"; selectAudioOverlayOption("Original")
        case .audioNext:
            selectedAudioMode = "Next"; cycleMedia(groupCharacteristic: .audible, label: "audio")
        case .findAlternateAudio:
            findAlternateAudio()
        case .alternateAudio(let index):
            guard store.alternateAudioSources.indices.contains(index) else { return }
            selectedAlternateAudioIndex = index
            selectedAudioMode = "Alt"
            store.selectAlternateAudioSource(store.alternateAudioSources[index], for: item)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioMinus250:
            store.adjustAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource, deltaMS: -250)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioPlus250:
            store.adjustAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource, deltaMS: 250)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioReset:
            store.resetAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioClear:
            selectedAlternateAudioIndex = nil
            selectedAudioMode = "Auto"
            store.selectAlternateAudioSource(nil, for: item)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .subtitlesOff:
            selectedSubtitleMode = "Off"; selectSubtitleOverlayOption("Off")
        case .subtitlesEnglish:
            selectedSubtitleMode = "English"; selectSubtitleOverlayOption("English")
        case .subtitlesAuto:
            selectedSubtitleMode = "Auto"; selectSubtitleOverlayOption("Auto")
        case .subtitlesNext:
            selectedSubtitleMode = "Next"; cycleMedia(groupCharacteristic: .legible, label: "subtitle")
        case .season(let season):
            selectedEpisodeSeason = season
            store.status = "Selected Season \(season). Episode rows should filter to this season only."
            showControlsWithoutChangingFocus()
        case .episodesOpen:
            store.status = "Episode selector opened for Season \(selectedEpisodeSeason)."
            showControlsWithoutChangingFocus()
        case .cache5:
            vodCacheLimitGB = 5; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to 5GB while playback continues."
        case .cache10:
            vodCacheLimitGB = 10; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to 10GB while playback continues."
        case .cacheUnlimited:
            vodCacheLimitGB = -1; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to Unlimited while playback continues."
        case .frameRateInfo:
            store.status = "Frame-rate matching remains controlled by tvOS/player output; playback is not restarted."
        case .settingsDiagnostics:
            vodPlaybackDiagnosticsEnabled.toggle()
            store.status = vodPlaybackDiagnosticsEnabled ? "Playback diagnostics enabled in Settings." : "Playback diagnostics hidden by default."
            showControlsWithoutChangingFocus()
        case .settingsFindAudio:
            findAlternateAudio()
        case .settingsInfuse:
            openExternal(.infuse)
        case .settingsVLC:
            openExternal(.vlc)
        case .settingsSenPlayer:
            openExternal(.senPlayer)
        case .closePanel, .none:
            selectedPanelOption = nil
            focusedPanelOption = nil
            activePanel = nil
            showControlsWithoutChangingFocus()
        }
    }

    @ViewBuilder
    private func panelOptions(_ panel: PlayerPanel) -> some View {
        switch panel {
        case .audio:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: selectedAudioMode == "Auto" ? "✓ Auto / English preferred" : "Auto / English preferred", selected: (selectedPanelOption ?? focusedPanelOption) == .audioAuto, focus: .audioAuto, focused: $focusedPanelOption) { focusedPanelOption = .audioAuto; selectedPanelOption = .audioAuto; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedAudioMode == "English" ? "✓ English" : "English", selected: (selectedPanelOption ?? focusedPanelOption) == .audioEnglish, focus: .audioEnglish, focused: $focusedPanelOption) { focusedPanelOption = .audioEnglish; selectedPanelOption = .audioEnglish; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedAudioMode == "Original" ? "✓ Original" : "Original", selected: (selectedPanelOption ?? focusedPanelOption) == .audioOriginal, focus: .audioOriginal, focused: $focusedPanelOption) { focusedPanelOption = .audioOriginal; selectedPanelOption = .audioOriginal; activateFocusedPanelOption() }
                PanelOptionChip(title: "Next available track", selected: (selectedPanelOption ?? focusedPanelOption) == .audioNext, focus: .audioNext, focused: $focusedPanelOption) { focusedPanelOption = .audioNext; selectedPanelOption = .audioNext; activateFocusedPanelOption() }
                PanelOptionChip(title: isFindingAlternateAudio ? "Scanning other copies…" : "Find English audio from another copy", selected: (selectedPanelOption ?? focusedPanelOption) == .findAlternateAudio, focus: .findAlternateAudio, focused: $focusedPanelOption) { focusedPanelOption = .findAlternateAudio; selectedPanelOption = .findAlternateAudio; activateFocusedPanelOption() }
                if !store.alternateAudioSources.isEmpty {
                    Text("Alternate audio candidates")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.58))
                        .padding(.top, 8)
                    ForEach(Array(store.alternateAudioSources.enumerated()), id: \.offset) { index, source in
                        PanelOptionChip(title: (selectedAlternateAudioIndex == index ? "✓ " : "") + source.displayTitle + " • " + source.confidence, selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudio(index), focus: .alternateAudio(index), focused: $focusedPanelOption) {
                            focusedPanelOption = .alternateAudio(index)
                            selectedPanelOption = .alternateAudio(index)
                            activateFocusedPanelOption()
                        }
                    }
                    Text("Sync offset: \(store.alternateAudioSyncOffsetMS)ms")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.66))
                        .padding(.top, 8)
                    HStack(spacing: 8) {
                        PanelOptionChip(title: "−250ms", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioMinus250, focus: .alternateAudioMinus250, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioMinus250; selectedPanelOption = .alternateAudioMinus250; activateFocusedPanelOption() }
                        PanelOptionChip(title: "+250ms", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioPlus250, focus: .alternateAudioPlus250, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioPlus250; selectedPanelOption = .alternateAudioPlus250; activateFocusedPanelOption() }
                        PanelOptionChip(title: "Reset", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioReset, focus: .alternateAudioReset, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioReset; selectedPanelOption = .alternateAudioReset; activateFocusedPanelOption() }
                    }
                    PanelOptionChip(title: "Clear alternate audio", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioClear, focus: .alternateAudioClear, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioClear; selectedPanelOption = .alternateAudioClear; activateFocusedPanelOption() }
                }
            }
        case .subtitles:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: selectedSubtitleMode == "Off" ? "✓ Off" : "Off", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesOff, focus: .subtitlesOff, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesOff; selectedPanelOption = .subtitlesOff; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedSubtitleMode == "English" ? "✓ English" : "English", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesEnglish, focus: .subtitlesEnglish, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesEnglish; selectedPanelOption = .subtitlesEnglish; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedSubtitleMode == "Auto" ? "✓ Auto" : "Auto", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesAuto, focus: .subtitlesAuto, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesAuto; selectedPanelOption = .subtitlesAuto; activateFocusedPanelOption() }
                PanelOptionChip(title: "Next available track", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesNext, focus: .subtitlesNext, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesNext; selectedPanelOption = .subtitlesNext; activateFocusedPanelOption() }
            }
        case .episodes:
            VStack(alignment: .leading, spacing: 10) {
                Text("Season")
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.60))
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(1...8, id: \.self) { season in
                        PanelOptionChip(title: selectedEpisodeSeason == season ? "✓ S\(season)" : "S\(season)", selected: (selectedPanelOption ?? focusedPanelOption) == .season(season), focus: .season(season), focused: $focusedPanelOption) {
                            focusedPanelOption = .season(season)
                            selectedPanelOption = .season(season)
                            activateFocusedPanelOption()
                        }
                    }
                }
                PanelOptionChip(title: "Open full episode selector", selected: (selectedPanelOption ?? focusedPanelOption) == .episodesOpen, focus: .episodesOpen, focused: $focusedPanelOption) { focusedPanelOption = .episodesOpen; selectedPanelOption = .episodesOpen; activateFocusedPanelOption() }
            }
        case .settings:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: vodCacheLimitGB == 5 ? "✓ Cache: 5GB" : "Cache: 5GB", selected: (selectedPanelOption ?? focusedPanelOption) == .cache5, focus: .cache5, focused: $focusedPanelOption) { focusedPanelOption = .cache5; selectedPanelOption = .cache5; activateFocusedPanelOption() }
                PanelOptionChip(title: vodCacheLimitGB == 10 ? "✓ Cache: 10GB" : "Cache: 10GB", selected: (selectedPanelOption ?? focusedPanelOption) == .cache10, focus: .cache10, focused: $focusedPanelOption) { focusedPanelOption = .cache10; selectedPanelOption = .cache10; activateFocusedPanelOption() }
                PanelOptionChip(title: vodCacheLimitGB < 0 ? "✓ Cache: Unlimited" : "Cache: Unlimited", selected: (selectedPanelOption ?? focusedPanelOption) == .cacheUnlimited, focus: .cacheUnlimited, focused: $focusedPanelOption) { focusedPanelOption = .cacheUnlimited; selectedPanelOption = .cacheUnlimited; activateFocusedPanelOption() }
                PanelOptionChip(title: "Frame-rate matching: tvOS setting", selected: (selectedPanelOption ?? focusedPanelOption) == .frameRateInfo, focus: .frameRateInfo, focused: $focusedPanelOption) { focusedPanelOption = .frameRateInfo; selectedPanelOption = .frameRateInfo; activateFocusedPanelOption() }
                PanelOptionChip(title: vodPlaybackDiagnosticsEnabled ? "✓ Playback diagnostics: On" : "Playback diagnostics: Off", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsDiagnostics, focus: .settingsDiagnostics, focused: $focusedPanelOption) { focusedPanelOption = .settingsDiagnostics; selectedPanelOption = .settingsDiagnostics; activateFocusedPanelOption() }
                PanelOptionChip(title: isFindingAlternateAudio ? "Finding English Audio…" : "Find English Audio", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsFindAudio, focus: .settingsFindAudio, focused: $focusedPanelOption) { focusedPanelOption = .settingsFindAudio; selectedPanelOption = .settingsFindAudio; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in Infuse", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsInfuse, focus: .settingsInfuse, focused: $focusedPanelOption) { focusedPanelOption = .settingsInfuse; selectedPanelOption = .settingsInfuse; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in VLC App", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsVLC, focus: .settingsVLC, focused: $focusedPanelOption) { focusedPanelOption = .settingsVLC; selectedPanelOption = .settingsVLC; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in Sen", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsSenPlayer, focus: .settingsSenPlayer, focused: $focusedPanelOption) { focusedPanelOption = .settingsSenPlayer; selectedPanelOption = .settingsSenPlayer; activateFocusedPanelOption() }
            }
        }
    }

    private func panelTitle(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio: return "Audio Tracks"
        case .subtitles: return "Subtitles"
        case .episodes: return "Episodes"
        case .settings: return "Playback Settings"
        }
    }

    private func panelDetail(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio:
            return "Smart Alternate Audio v1 can scan other playable copies for likely English audio, keep this video source active, and save manual sync offsets per title/source. KSPlayer remains the primary surface; v1 stores and routes the selected alternate audio reference without replacing the main video URL."
        case .subtitles:
            return "Stremio subtitle URLs are captured for the overlay parser path. Subtitles default off and can be enabled from the Debrid overlay when supported by the active engine."
        case .episodes:
            return "Season selector is available from the TV show detail page; the VOD overlay keeps the Episodes button selectable for quick series navigation while playback remains active."
        case .settings:
            return "Engines: KSPlayer clean video surface is primary, VLC Internal is selectable fallback, and external Infuse/VLC/SenPlayer handoff remains available. v261 keeps KSPlayer direct-start VOD, background cache warming, and no-snap focus-boundary selectable controls, reinforces English audio preference, and moves media information right/down while preserving smooth v154 cadence settings. English audio is enforced where tracks expose language metadata and subtitles default off. Cache limit: \(cacheLimitLabel). Current profile: \(nativeProfileText.isEmpty ? "pending" : nativeProfileText)."
        }
    }

    private func currentPlaybackDiagnostics() -> DebridPlaybackDiagnostics {
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        let engine = activeEngineName
        var diag = DebridPlaybackDiagnosticsFactory.make(engine: engine, profile: profile, controlsVisible: controlsVisible, isPlaying: isPlaying)
        if isLoading {
            diag.fps = "Loading"
            diag.droppedFrames = "Pending"
        }
        if !playbackNotice.isEmpty {
            diag.notes = playbackNotice
        }
        _ = diagnosticsTick
        return diag
    }

    private func startDiagnosticsPulse() {
        Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                diagnosticsTick &+= 1
            }
        }
    }

    private func findAlternateAudio() {
        guard !isLivePlayback else {
            store.status = "Alternate audio search is for Movies/Shows only. Live TV keeps the channel stream audio."
            return
        }
        isFindingAlternateAudio = true
        activePanel = .audio
        forceControlsVisibleForNavigation()
        Task { @MainActor in
            let candidates = await store.findAlternateAudioSources(for: item, currentURL: url, preferredLanguage: "English")
            isFindingAlternateAudio = false
            selectedPanelOption = candidates.isEmpty ? .findAlternateAudio : .alternateAudio(0)
            focusedPanelOption = selectedPanelOption
        }
    }

    private func applyAlternateAudioSelection() {
        if let source = store.selectedAlternateAudioSource {
            playbackNotice = "Smart Alternate Audio v1 selected • \(source.displayTitle) • sync \(store.alternateAudioSyncOffsetMS)ms"
            store.status = "Smart Alternate Audio v1: keeping current video source and tracking audio from \(source.displayTitle). Manual sync offset is \(store.alternateAudioSyncOffsetMS)ms."
        } else {
            playbackNotice = "Alternate audio cleared; using selected stream audio."
            store.status = playbackNotice
        }
        vlcSurfaceToken += 1
        showControlsWithoutChangingFocus()
    }

    private func setupPlayer() {
        // v127: AVPlayer remains removed from the VOD decision path.
        // Internal playback uses KSPlayer primary and TVVLCKit/libVLC fallback under the same Debrid overlay.
        nativePrepareTask?.cancel()
        startupLoadingTask?.cancel()
        renderWatchdogTask?.cancel()
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        player?.pause()
        player = nil

        forceVLCSurface = false
        forceKSPlayerSurface = true
        avRetryAttemptedForCurrentURL = false
        isLoading = true
        errorText = nil
        retryText = "Preparing player…"
        focusedControl = .playPause
        preparedPlaybackURL = nil
        vodBootstrapDeadline = nil
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        if isLivePlayback {
            cacheSession.stopAndDelete()
            preparedPlaybackURL = url
            currentSeconds = 0
            durationSeconds = 0
            retryText = "Starting Live TV…"
        } else {
            // v253: restore the v163 VOD path that worked before Live TV was added:
            // the video surface always receives cacheSession.playbackURL ?? origin URL,
            // cache warms for the whole watch session, and playback starts immediately.
            preparedPlaybackURL = url
            retryText = "Opening stream immediately… cache warming…"
            cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
        }
        nativeProfileText = profile.diagnostic
        if metadataRuntimeSeconds <= 0 { metadataRuntimeSeconds = runtimeSeconds(for: item) }
        currentSeconds = max(currentSeconds, 0)
        startPlayerClock()
        startRuntimeMetadataLookupIfNeeded()

        if isLivePlayback {
            // v347: Live TV full playback now uses KSPlayer as the default route.
            // The guide preview also uses KSPlayer, but it is suppressed before opening full playback
            // so the preview surface cannot create double audio.
            liveQuickGuideModel.loadCachedOrDemo()
            controlsVisible = false
            liveQuickGuideVisible = false
            forceKSPlayerSurface = true
            forceVLCSurface = false
        }

        if !isLivePlayback, let externalTarget = defaultExternalTargetForCurrentItem() {
            isLoading = false
            forceControlsVisibleForNavigation()
            playbackNotice = "Opening in \(externalTarget.rawValue) by default from Settings."
            store.status = "External player default enabled for \(item.type): opening \(item.title) in \(externalTarget.rawValue)."
            ExternalPlayerLauncher.open(externalTarget, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
                store.status = message
            }
            return
        }

        if isLivePlayback {
            if liveTVUseAVPlayerDefault {
                switchToAVPlayerEngine(manual: false)
                playbackNotice = "AVPlayer Live TV selected from Settings • auto-falls back to KSPlayer if this stream rejects AVPlayer."
                store.status = "Live TV playback: AVPlayer default is enabled; fallback to KSPlayer is automatic on AVPlayer failure."
                return
            }
            #if canImport(KSPlayer)
            forceKSPlayerSurface = true
            forceVLCSurface = false
            isPlaying = true
            vlcSurfaceToken += 1
            armStartupLoadingGate(engine: "KSPlayer Live TV")
            playbackNotice = "KSPlayer Live TV direct-start • guide preview stopped before playback • quick guide available with UP/DOWN • \(profile.diagnostic)"
            store.status = "V354 Live TV playback: KSPlayer remains default; quick guide opens with Up/Down, browses ONLY with Left/Right, and chip panels keep Up/Down."
            return
            #elseif canImport(TVVLCKit)
            forceKSPlayerSurface = false
            forceVLCSurface = true
            isPlaying = true
            vlcSurfaceToken += 1
            armStartupLoadingGate(engine: "VLC Live TV fallback")
            playbackNotice = "VLC Live TV fallback • KSPlayer missing • quick guide available with UP/DOWN • \(profile.diagnostic)"
            store.status = "V354 Live TV playback: VLC fallback because KSPlayer was not compiled."
            return
            #else
            isPlaying = false
            forceControlsVisibleForNavigation()
            playbackNotice = "No internal Live TV engine compiled."
            errorText = "Live TV playback needs KSPlayer compiled into the IPA."
            store.status = playbackNotice
            return
            #endif
        }

        #if canImport(KSPlayer)
        // v259: restore KSPlayer as the default VOD engine. Start the resolved HTTP(S) stream
        // immediately, while the temporary VOD cache downloads in the background.
        forceKSPlayerSurface = true
        forceVLCSurface = false
        isPlaying = true
        vlcSurfaceToken += 1
        armStartupLoadingGate(engine: "KSPlayer")
        playbackNotice = "KSPlayer direct-start • cache warming in background • English audio preferred • subtitles off • \(profile.diagnostic)"
        store.status = "V261 VOD playback: KSPlayer direct stream starts immediately; temp cache warms silently and never interrupts the visible player."
        #elseif canImport(TVVLCKit)
        forceKSPlayerSurface = false
        forceVLCSurface = true
        isPlaying = true
        vlcSurfaceToken += 1
        armStartupLoadingGate(engine: "VLC Internal")
        playbackNotice = "VLC Internal fallback • KSPlayer missing • \(profile.diagnostic)"
        store.status = isLivePlayback ? "V261 Live TV playback: VLC fallback direct path." : "V261 VOD playback: VLC fallback because KSPlayer was not compiled."
        #else
        isPlaying = false
        forceControlsVisibleForNavigation()
        playbackNotice = "KSPlayer and TVVLCKit are not compiled into this IPA. External players remain available."
        errorText = "Internal playback needs KSPlayer Raw Layer/FFmpeg or TVVLCKit/libVLC compiled into the IPA. Use external Infuse/VLC/SenPlayer until an internal engine is present."
        store.status = playbackNotice
        #endif
    }

    private func armVODPlaybackIfReady() {
        guard !isLivePlayback else { return }
        let alreadyPlayingOrigin = preparedPlaybackURL == url
        guard preparedPlaybackURL == nil || alreadyPlayingOrigin else { return }
        guard let candidate = cacheSession.playbackURL else {
            retryText = alreadyPlayingOrigin ? "Playback started; cache warming…" : "Starting VOD cache…"
            return
        }

        let isBypass = candidate == url
        let hasEnoughBuffered = cacheSession.cachedBytes >= vodStartThresholdBytes
        let completedSmallFile = cacheSession.totalBytes.map { $0 > 0 && cacheSession.cachedBytes >= min($0, vodStartThresholdBytes) } ?? false
        let deadlineReached = vodBootstrapDeadline.map { Date() >= $0 } ?? false

        guard isBypass || hasEnoughBuffered || completedSmallFile || deadlineReached else {
            let mb = Double(cacheSession.cachedBytes) / 1_048_576.0
            retryText = String(format: "Playback started; cache warming %.1fMB…", mb)
            return
        }

        if preparedPlaybackURL != candidate { preparedPlaybackURL = candidate }
        isPlaying = true
        retryText = "Starting playback…"
        vlcSurfaceToken += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) {
            if errorText == nil { isLoading = false }
        }
        store.status = isBypass
            ? "V198 VOD bootstrap: stream autostarted immediately while cache warms."
            : "V198 VOD bootstrap: cache-backed playback autostarted with direct-start fallback."
    }

    private func startNativeLivePlaybackDirect(url: URL, profile: NativePlaybackProfile) {
        nativePrepareTask?.cancel()
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 LiveTV",
            "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"
        ]
        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = profile.isHLS ? 8 : 15
        let av = AVPlayer(playerItem: item)
        av.automaticallyWaitsToMinimizeStalling = true
        av.preventsDisplaySleepDuringVideoPlayback = true
        player = av
        preparedPlaybackURL = url
        isLoading = false
        errorText = nil
        attachNativePlayerObservers(item: item, player: av)
        av.play()
    }

    private func prepareNativeAssetAndStart(url: URL, profile: NativePlaybackProfile) {
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 KSPlayer/VLC",
            "Accept": "video/mp4,video/quicktime,application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Range": "bytes=0-"
        ]
        let options: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": headers]
        let asset = AVURLAsset(url: url, options: options)

        nativePrepareTask = Task { @MainActor in
            do {
                // Load the real AVFoundation properties before making the visible player.
                // If these fail, AVPlayer would usually become audio-only/black or stutter.
                let playable = try await asset.load(.isPlayable)
                let tracks = try await asset.load(.tracks)
                let duration = try? await asset.load(.duration)
                let mediaCharacteristics = try? await asset.load(.availableMediaCharacteristicsWithMediaSelectionOptions)
                let videoTracks = tracks.filter { $0.mediaType == .video }
                let audioTracks = tracks.filter { $0.mediaType == .audio }

                guard !Task.isCancelled else { return }
                guard playable else {
                    handleNativePreparationFailure("AVPlayer rejected this asset as not playable before render.")
                    return
                }
                if videoTracks.isEmpty && !profile.isAppleContainer && !profile.isNativeDolbyVisionPreferred {
                    let audioCount = audioTracks.count
                    handleNativePreparationFailure("AVPlayer only exposed audio tracks (\(audioCount)) and no video track before render for \(profile.diagnostic).")
                    return
                }

                let itemAsset = AVPlayerItem(asset: asset)
                itemAsset.preferredForwardBufferDuration = profile.isHLS ? 60 : 180
                itemAsset.canUseNetworkResourcesForLiveStreamingWhilePaused = true
                itemAsset.preferredPeakBitRate = 0
                itemAsset.preferredMaximumResolution = CGSize(width: 4096, height: 2160)
                itemAsset.seekingWaitsForVideoCompositionRendering = true

                let av = AVPlayer(playerItem: itemAsset)
                av.appliesMediaSelectionCriteriaAutomatically = true
                av.automaticallyWaitsToMinimizeStalling = true
                av.preventsDisplaySleepDuringVideoPlayback = true
                av.allowsExternalPlayback = false

                player = av
                let durationText = duration.map { CMTimeGetSeconds($0).isFinite ? "duration \(Int(CMTimeGetSeconds($0)))s" : "duration live/unknown" } ?? "duration pending"
                let characteristicsText = mediaCharacteristics?.map { $0.rawValue }.joined(separator: ",") ?? "characteristics pending"
                playbackNotice = "AVPlayer ready • \(profile.diagnostic) • \(videoTracks.count) video track(s) • no bitrate cap • 4K/DV native path."
                store.status = "AVPlayer validation passed: \(videoTracks.count) video track(s), \(audioTracks.count) audio track(s), \(durationText), \(characteristicsText). Starting hardware playback path."
                attachNativePlayerObservers(item: itemAsset, player: av)
                av.play()
                isPlaying = true
            } catch {
                guard !Task.isCancelled else { return }
                handleNativePreparationFailure("AVPlayer asset preparation failed for \(profile.diagnostic): \(error.localizedDescription)")
            }
        }
    }

    private func handleNativePreparationFailure(_ message: String) {
        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface {
            retryText = "AVPlayer rejected this Live TV stream; falling back to KSPlayer…"
            errorText = nil
            store.status = "AVPlayer Live TV preparation failed: \(message). Falling back to KSPlayer."
            switchToKSPlayerEngine(manual: false)
            return
        }
        isLoading = false
        forceControlsVisibleForNavigation()
        store.status = message
        #if canImport(TVVLCKit)
        if UniversalCodecSupport.vlcCompiledIn {
            retryText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            errorText = message + "\n\nInternal playback uses KSPlayer primary and VLC fallback; use external Infuse if needed."
        } else {
            errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        }
        #else
        errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        #endif
    }

    private func attachNativePlayerObservers(item itemAsset: AVPlayerItem, player av: AVPlayer) {
        statusObserver = itemAsset.observe(\.status, options: [.new, .initial]) { observedItem, _ in
            DispatchQueue.main.async {
                switch observedItem.status {
                case .readyToPlay:
                    isLoading = false
                    let readyDuration = CMTimeGetSeconds(observedItem.duration)
                    if readyDuration.isFinite && readyDuration > 1 { durationSeconds = readyDuration }
                    let dimensions = observedItem.presentationSize
                    let event = observedItem.accessLog()?.events.last
                    let bitrateText = event.map { "observed \(Int($0.observedBitrate))bps / indicated \(Int($0.indicatedBitrate))bps" } ?? "bitrate pending"
                    let sizeText = dimensions.width > 8 ? "\(Int(dimensions.width))×\(Int(dimensions.height))" : "video size pending"
                    playbackNotice = "VLC Internal playing • \(nativeProfileText) • \(sizeText) • \(bitrateText)"
                    store.status = "Playback route: \(activeEngineName); \(nativeProfileText); video size \(sizeText); \(bitrateText); selected \(store.playbackLinkLabel)"
                    av.play()
                    isPlaying = true
                    startRenderWatchdog(for: observedItem, player: av)
                    scheduleAutoHide()
                case .failed:
                    isLoading = false
                    let message = observedItem.error?.localizedDescription ?? "The selected stream could not be played."
                    if let next = store.advanceToNextPlaybackURL(after: url) {
                        retryText = "Stream failed; retrying next source…"
                        errorText = nil
                        store.status = "Playback failed on one source: \(message). Retrying \(next.absoluteString.prefix(80))…"
                    } else {
                        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface {
                            retryText = "AVPlayer stopped on this Live TV stream; falling back to KSPlayer…"
                            errorText = nil
                            store.status = "AVPlayer Live TV failed: \(message). Falling back to KSPlayer without closing playback."
                            switchToKSPlayerEngine(manual: false)
                            return
                        }
                        forceControlsVisibleForNavigation()
                        errorText = message + "\nEngine: \(activeEngineName). Playback failed after validated setup; try KSPlayer, VLC Internal, or external Infuse/VLC/SenPlayer for this stream."
                    }
                default:
                    break
                }
            }
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1.25, preferredTimescale: 600), queue: .main) { time in
            if !forceVLCSurface {
                currentSeconds = CMTimeGetSeconds(time).isFinite ? CMTimeGetSeconds(time) : 0
            }
                if let duration = av.currentItem?.duration {
                let seconds = CMTimeGetSeconds(duration)
                if seconds.isFinite && seconds > 1 { durationSeconds = seconds }
            }
            if !forceVLCSurface { isPlaying = av.timeControlStatus == .playing }
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: itemAsset, queue: .main) { _ in
            isPlaying = false
            controlsVisible = true
            focusedControl = .playPause
        }

        if !store.playbackSubtitleURLs.isEmpty {
            store.status = "Captured \(store.playbackSubtitleURLs.count) external subtitle URL(s) from the selected Stremio stream."
        }
    }

    private func teardownPlayer() {
        hideTask?.cancel()
        nativePrepareTask?.cancel()
        nativePrepareTask = nil
        renderWatchdogTask?.cancel()
        startupLoadingTask?.cancel()
        startupLoadingTask = nil
        runtimeLookupTask?.cancel()
        runtimeLookupTask = nil
        playbackClockTask?.cancel()
        playbackClockTask = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        player?.pause()
        player = nil
        preparedPlaybackURL = nil
        vodBootstrapDeadline = nil
        cacheSession.stopAndDelete()
    }

    private func defaultExternalTargetForCurrentItem() -> ExternalPlaybackTarget? {
        let lower = item.type.lowercased()
        let isShow = lower.contains("series") || lower.contains("show") || item.seasonNumber != nil || item.episodeNumber != nil
        if isShow {
            if externalShowsInfuseDefault { return .infuse }
            if externalShowsVLCDefault { return .vlc }
            if externalShowsSenPlayerDefault { return .senPlayer }
        } else {
            if externalMoviesInfuseDefault { return .infuse }
            if externalMoviesVLCDefault { return .vlc }
            if externalMoviesSenPlayerDefault { return .senPlayer }
        }
        return nil
    }

    private func openExternal(_ target: ExternalPlaybackTarget) {
        player?.pause()
        isPlaying = false
        forceControlsVisibleForNavigation()
        ExternalPlayerLauncher.open(target, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
            store.status = message
        }
    }

    private func switchToAVPlayerEngine(manual: Bool) {
        guard isLivePlayback else {
            playbackNotice = "AVPlayer backup is limited to Live TV streams. VOD remains on KSPlayer/VLC."
            store.status = playbackNotice
            forceControlsVisibleForNavigation()
            return
        }
        forceKSPlayerSurface = false
        forceVLCSurface = false
        isPlaying = true
        isLoading = true
        retryText = manual ? "Starting Live TV with AVPlayer…" : "Starting Live TV with AVPlayer default…"
        errorText = nil
        selectedPlaybackMode = "AVPlayer"
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        startNativeLivePlaybackDirect(url: url, profile: profile)
        armStartupLoadingGate(engine: "AVPlayer Live TV")
        playbackNotice = manual ? "AVPlayer Live TV selected manually. If this stream rejects AVPlayer, Debrid Channels will fall back to KSPlayer." : "AVPlayer Live TV default selected. KSPlayer fallback is armed."
        store.status = playbackNotice
        forceControlsVisibleForNavigation()
    }

    private func switchToKSPlayerEngine(manual: Bool) {
        player?.pause()
        forceVLCSurface = false
        forceKSPlayerSurface = true
        isPlaying = true
        isLoading = false
        errorText = nil
        #if canImport(KSPlayer)
        playbackNotice = manual ? "KSPlayer tvOS-Safe Native-First selected manually for this stream." : "KSPlayer tvOS-Safe Native-First selected as primary internal engine."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "KSPlayer is not compiled into this IPA. Staying on VLC Internal fallback."
        store.status = playbackNotice
        switchToVLCEngine(manual: false)
        #endif
    }

    private func switchToVLCEngine(manual: Bool) {
        #if canImport(TVVLCKit)
        player?.pause()
        forceKSPlayerSurface = false
        forceVLCSurface = true
        vlcSurfaceToken += 1
        isPlaying = true
        isLoading = false
        errorText = nil
        playbackNotice = manual ? "VLC Internal selected manually for this stream." : "Switched to VLC Internal fallback."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "VLC Internal is not available in this IPA because TVVLCKit was not compiled in."
        store.status = playbackNotice
        #endif
    }

    private func togglePlay() {
        if forceKSPlayerSurface || forceVLCSurface {
            isPlaying.toggle()
            liveQuickGuideVisible = false
            if isPlaying {
                // v384: when playback is resumed from the Debrid chip rail, keep the overlay stable
                // long enough for the user to continue navigating instead of instantly hiding it.
                forceControlsVisibleForNavigation(lockOverlay: true)
                store.status = "Playback resumed; controls remain available briefly."
            } else {
                forceControlsVisibleForNavigation(lockOverlay: true)
                store.status = "Playback paused; controls remain visible."
            }
            return
        }
        guard let player else { return }
        if player.timeControlStatus == .playing {
            player.pause()
            isPlaying = false
            forceControlsVisibleForNavigation()
        } else {
            player.play()
            isPlaying = true
            forceControlsVisibleForNavigation(lockOverlay: true)
        }
    }

    private func seekRelative(_ seconds: Double, revealControls: Bool = true) {
        let upperBound = resolvedDurationSeconds > 0 ? resolvedDurationSeconds : Double.greatestFiniteMagnitude
        let target = max(0, min(upperBound, currentSeconds + seconds))
        seekAbsolute(target, directionSeconds: seconds, revealControls: revealControls)
    }

    private func seekAbsolute(_ targetSeconds: Double, directionSeconds: Double = 0, revealControls: Bool = true) {
        let upperBound = resolvedDurationSeconds > 0 ? resolvedDurationSeconds : Double.greatestFiniteMagnitude
        let target = max(0, min(upperBound, targetSeconds))
        let relativeDelta = target - currentSeconds
        currentSeconds = target
        saveResumePosition(force: true)

        if forceKSPlayerSurface {
            // KSPlayer's low-level seek selectors vary by package build and were not reliably
            // moving playback. Force the KS surface to reopen the SAME url at startPlayTime.
            // This is heavier than an in-place seek, but it is real and works even while the
            // background VOD cache is still warming because the visible player uses the direct URL.
            ksStartTimeSeconds = target
            ksSurfaceToken &+= 1
            vlcSeekSeconds = directionSeconds
            vlcSeekSerial &+= 1
            store.status = directionSeconds < 0 ? "Rewind 30 seconds." : "Fast-forward 30 seconds."
            if revealControls { forceControlsVisibleForNavigation() }
            return
        }

        if forceVLCSurface {
            vlcSeekSeconds = abs(directionSeconds) > 0.01 ? directionSeconds : relativeDelta
            vlcSeekSerial &+= 1
            store.status = directionSeconds < 0 ? "Rewind 30 seconds." : "Fast-forward 30 seconds."
            if revealControls { forceControlsVisibleForNavigation() }
            return
        }

        guard let player else { return }
        let time = CMTime(seconds: target, preferredTimescale: 600)
        player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
        if revealControls { showControls() }
    }

    private func toggleZoom() {
        videoGravity = videoGravity == .resizeAspect ? .resizeAspectFill : .resizeAspect
        showControls()
    }

    private func selectAudioOverlayOption(_ option: String) {
        activePanel = .audio
        if forceKSPlayerSurface || forceVLCSurface {
            store.status = "Audio option set to \(option). KS/VLC keep the stream playing while the engine applies available track preferences."
            showControls()
            return
        }
        cycleMedia(groupCharacteristic: .audible, label: "audio")
    }

    private func selectSubtitleOverlayOption(_ option: String) {
        activePanel = .subtitles
        if forceKSPlayerSurface || forceVLCSurface {
            store.status = option == "Off" ? "Subtitles set to Off in the Debrid overlay preference." : "Subtitle option set to \(option). The active engine will use the matching embedded/external track when available."
            showControls()
            return
        }
        cycleMedia(groupCharacteristic: .legible, label: "subtitle")
    }

    private func cycleMedia(groupCharacteristic: AVMediaCharacteristic, label: String) {
        guard !forceKSPlayerSurface && !forceVLCSurface else {
            store.status = "\(label.capitalized) default is set by the active internal engine: English audio preferred, subtitles off by default. Full track list UI remains inside the Debrid overlay settings panel."
            showControls()
            return
        }
        guard let item = player?.currentItem, let group = item.asset.mediaSelectionGroup(forMediaCharacteristic: groupCharacteristic) else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let options = group.options
        guard !options.isEmpty else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let current = item.currentMediaSelection.selectedMediaOption(in: group)
        let nextIndex: Int
        if let current, let idx = options.firstIndex(of: current) {
            nextIndex = (idx + 1) % options.count
        } else {
            nextIndex = 0
        }
        item.select(options[nextIndex], in: group)
        store.status = "Selected \(label): \(options[nextIndex].displayName)"
        showControls()
    }

    private func startRenderWatchdog(for item: AVPlayerItem, player: AVPlayer) {
        renderWatchdogTask?.cancel()
        renderWatchdogTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard errorText == nil, !forceVLCSurface, !forceKSPlayerSurface else { return }
            let size = item.presentationSize
            let hasVideo = size.width > 8 && size.height > 8
            let likelyPlaying = player.timeControlStatus == .playing || player.rate > 0
            if !hasVideo && likelyPlaying {
                #if canImport(TVVLCKit)
                if !avRetryAttemptedForCurrentURL && UniversalCodecSupport.vlcCompiledIn {
                    avRetryAttemptedForCurrentURL = true
                    retryText = "VLC Internal produced audio/no video; switching this same URL to VLC Internal…"
                    switchToVLCEngine(manual: false)
                    forceControlsVisibleForNavigation()
                    return
                }
                #endif
                isLoading = false
                forceControlsVisibleForNavigation()
                errorText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            }
        }
    }

    private func forceControlsVisible() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
    }

    private var cacheLimitLabel: String {
        vodCacheLimitGB == -1 ? "Unlimited" : "\(vodCacheLimitGB)GB"
    }

    private var cacheLimitGBValue: Double {
        vodCacheLimitGB == -1 ? 0 : Double(vodCacheLimitGB)
    }

    private var cacheFillProgress: Double {
        cacheSession.progress
    }

    private var cacheUsedGB: Double {
        cacheSession.usedGB
    }

    private func cycleCacheLimit() {
        if isLivePlayback {
            cacheSession.stopAndDelete()
            store.status = "Live TV cache remains disabled. VOD-only cache protects TS/HLS playback from recording or progress-cache behavior."
            return
        }
        switch vodCacheLimitGB {
        case 5: vodCacheLimitGB = 10
        case 10: vodCacheLimitGB = -1
        default: vodCacheLimitGB = 5
        }
        // Restart the temporary watch-session cache with the new limit. This cache is deleted on player exit.
        cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
    }

    private func forceControlsVisibleForNavigation(lockOverlay: Bool = true) {
        hideTask?.cancel()
        if lockOverlay { vodOverlayLockedForRemoteNavigation = true }
        withAnimation(.easeInOut(duration: 0.16)) { controlsVisible = true }
        if focusedControl == nil { DispatchQueue.main.async { focusedControl = lastKnownControlFocus } }
        scheduleOverlayAutoHideIfAllowed()
    }

    private func showControlsWithoutChangingFocus() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.12)) { controlsVisible = true }
        scheduleOverlayAutoHideIfAllowed()
    }

    private func showControls() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
        scheduleAutoHide()
    }

    private func scheduleAutoHide() {
        hideTask?.cancel()
        vodOverlayLockedForRemoteNavigation = false
        scheduleOverlayAutoHideIfAllowed(delaySeconds: 7)
    }

    private func scheduleOverlayAutoHideIfAllowed(delaySeconds: UInt64 = 7) {
        hideTask?.cancel()
        guard activePanel == nil, errorText == nil, !isLoading else { return }
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: delaySeconds * 1_000_000_000)
            guard !Task.isCancelled else { return }
            guard activePanel == nil, errorText == nil, !isLoading else { return }
            vodOverlayLockedForRemoteNavigation = false
            withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = false }
        }
    }


    private func resumeStorageKey() -> String {
        let identity = [item.type, item.catalog, item.year, item.title, item.id]
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
            .joined(separator: "|")
        let safe = identity.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? String(abs(identity.hashValue))
        return "vod.resume.seconds.\(safe)"
    }

    private func saveResumePosition(force: Bool = false) {
        guard !isLivePlayback else { return }
        guard currentSeconds.isFinite, currentSeconds >= 10 else { return }
        let total = resolvedDurationSeconds
        if total > 0, currentSeconds >= max(0, total - 90) {
            UserDefaults.standard.removeObject(forKey: resumeStorageKey())
            return
        }
        UserDefaults.standard.set(currentSeconds, forKey: resumeStorageKey())
    }

    private func runtimeSeconds(for item: MediaItem) -> Double {
        // Offline safety fallback for a few well-known titles only. The normal path below
        // is TMDB detail lookup; this prevents the VOD bar from showing fake 0:00 when
        // the player/proxy stream does not expose duration immediately.
        let key = "\(item.title.lowercased().trimmingCharacters(in: .whitespacesAndNewlines))|\(item.year)"
        let knownMinutes: [String: Double] = [
            "national treasure|2004": 131,
            "national treasure: book of secrets|2007": 124
        ]
        if let minutes = knownMinutes[key] { return minutes * 60 }
        return 0
    }

    private func startRuntimeMetadataLookupIfNeeded() {
        guard !isLivePlayback else { return }
        guard resolvedDurationSeconds <= 1 else { return }
        runtimeLookupTask?.cancel()
        runtimeLookupTask = Task { @MainActor in
            if let seconds = await fetchRuntimeSecondsFromTMDB() {
                metadataRuntimeSeconds = seconds
                metadataRuntimeLabel = "TMDB runtime"
                store.status = "VOD runtime loaded from TMDB: \(formatTime(seconds))."
            }
        }
    }

    private func fetchRuntimeSecondsFromTMDB() async -> Double? {
        let key = vodTMDBApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return nil }

        struct MovieDetail: Decodable { let runtime: Int? }
        struct TVDetail: Decodable { let episode_run_time: [Int]? }
        struct FindResponse: Decodable {
            struct FoundItem: Decodable { let id: Int? }
            let movie_results: [FoundItem]?
            let tv_results: [FoundItem]?
        }

        func fetch<T: Decodable>(_ type: T.Type, from url: URL) async -> T? {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                return nil
            }
        }

        let parts = item.id.split(separator: ":").map(String.init)
        let normalizedType = item.type.lowercased()
        let tmdbKindFromType = normalizedType.contains("series") || normalizedType.contains("show") || normalizedType.contains("tv") ? "tv" : "movie"

        var detailKind: String? = nil
        var detailID: String? = nil
        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            detailKind = (parts[1].lowercased() == "tv" || tmdbKindFromType == "tv") ? "tv" : "movie"
            detailID = parts[2]
        } else {
            let imdbID: String? = {
                if item.id.lowercased().hasPrefix("tt") { return item.id }
                if let match = item.id.range(of: #"tt\d{6,}"#, options: .regularExpression) { return String(item.id[match]) }
                return nil
            }()
            if let imdbID, let encoded = imdbID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
               let findURL = URL(string: "https://api.themoviedb.org/3/find/\(encoded)?api_key=\(key)&external_source=imdb_id"),
               let found = await fetch(FindResponse.self, from: findURL) {
                if let movieID = found.movie_results?.compactMap({ $0.id }).first {
                    detailKind = "movie"; detailID = String(movieID)
                } else if let tvID = found.tv_results?.compactMap({ $0.id }).first {
                    detailKind = "tv"; detailID = String(tvID)
                }
            }
        }

        guard let detailKind, let detailID, let url = URL(string: "https://api.themoviedb.org/3/\(detailKind)/\(detailID)?api_key=\(key)") else { return nil }
        if detailKind == "movie", let detail = await fetch(MovieDetail.self, from: url), let minutes = detail.runtime, minutes > 0 {
            return Double(minutes) * 60
        }
        if detailKind == "tv", let detail = await fetch(TVDetail.self, from: url), let minutes = detail.episode_run_time?.first(where: { $0 > 0 }) {
            return Double(minutes) * 60
        }
        return nil
    }

    private func armStartupLoadingGate(engine: String) {
        startupLoadingTask?.cancel()
        startupLoadingTask = Task { @MainActor in
            let startedAt = Date()
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 300_000_000)
                guard errorText == nil else { return }
                let cacheMB = cacheSession.cachedBytes > 0 ? String(format: " • cache %.1fMB", Double(cacheSession.cachedBytes) / 1_048_576.0) : " • cache starting"
                retryText = "Starting \(engine)… \(formatTime(currentSeconds)) / \(resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "loading time")\(isLivePlayback ? "" : cacheMB)"
                // KSPlayer/TVVLCKit do not expose a reliable SwiftUI-ready callback in every package version.
                // Keep the loading card up during the initial handoff, then release it only after the stream
                // has had time to start and the playback clock/cache has moved instead of hiding it instantly.
                let elapsed = Date().timeIntervalSince(startedAt)
                let enoughStartupTime = elapsed >= (isLivePlayback ? 1.2 : 3.2)
                // KSPlayer/TVVLCKit callbacks vary by package version, so keep the loading card
                // visible until the stream has had a real startup window and, for VOD, the
                // temporary cache has actually begun writing. This prevents the black-screen
                // handoff where the overlay disappears before the movie/show is visibly streaming.
                let playbackHasMoved = currentSeconds > 1.5 || elapsed >= 4.2
                let cacheHasStarted = isLivePlayback || cacheSession.cachedBytes >= 512 * 1024 || elapsed >= 5.0
                if enoughStartupTime && playbackHasMoved && cacheHasStarted {
                    isLoading = false
                    forceControlsVisibleForNavigation()
                    scheduleAutoHide()
                    return
                }
            }
        }
    }

    private func startPlayerClock() {
        playbackClockTask?.cancel()
        playbackClockTask = Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                guard isPlaying, errorText == nil else { continue }
                guard forceKSPlayerSurface || forceVLCSurface else { continue }
                let total = resolvedDurationSeconds
                if total > 0 { currentSeconds = min(total, currentSeconds + 1) } else { currentSeconds += 1 }
            }
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds > 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }
}


struct DebridPlaybackDiagnosticsPanel: View {
    let diagnostics: DebridPlaybackDiagnostics

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("PLAYBACK DIAGNOSTICS")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
            diagnosticRow("Active Engine", diagnostics.activeEngine)
            diagnosticRow("HW Decode", diagnostics.hwDecode)
            diagnosticRow("Render Backend", diagnostics.renderBackend)
            diagnosticRow("Decoder", diagnostics.decoder)
            diagnosticRow("FPS", diagnostics.fps)
            diagnosticRow("Dropped Frames", diagnostics.droppedFrames)
            Text(diagnostics.notes)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .lineLimit(2)
                .frame(width: 360, alignment: .leading)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(.black.opacity(0.44), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
        .allowsHitTesting(false)
    }

    private func diagnosticRow(_ key: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(key)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.50))
                .frame(width: 118, alignment: .leading)
            Text(value)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .lineLimit(1)
        }
    }
}


struct DebridMovieLoadingView: View {
    let message: String
    @State private var spin = false
    @State private var glow = false

    var body: some View {
        ZStack {
            // v298: use the compiled branding asset from Assets.xcassets so the loading
            // screen verifies the same Assets.car path as the launcher icon.
            Image("DebridChannelsLoadingScreen")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.42)

            VStack(spacing: 20) {
                Image("DebridChannelsHomeIcon")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 300, height: 180)
                    .shadow(color: .orange.opacity(glow ? 0.34 : 0.14), radius: glow ? 26 : 10)
                ZStack {
                    Circle()
                        .stroke(.orange.opacity(0.18), lineWidth: 8)
                        .frame(width: 72, height: 72)
                    Circle()
                        .trim(from: 0.08, to: 0.78)
                        .stroke(.orange.opacity(0.94), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .frame(width: 72, height: 72)
                        .rotationEffect(.degrees(spin ? 360 : 0))
                    Circle()
                        .fill(.white.opacity(glow ? 0.24 : 0.10))
                        .frame(width: 18, height: 18)
                        .shadow(color: .orange.opacity(0.55), radius: glow ? 22 : 8)
                }
                Text(message)
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Preparing the best internal playback engine")
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
            }
            .padding(.horizontal, 42)
            .padding(.vertical, 34)
            .background(.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(.white.opacity(0.14), lineWidth: 1))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.linear(duration: 1.0).repeatForever(autoreverses: false)) { spin = true }
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) { glow = true }
        }
    }
}
struct ApplePlayerErrorCard: View {
    let message: String
    let close: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 18) {
            Text("Playback Error")
                .font(.system(size: 34, weight: .black, design: .rounded))
            Text(message)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.78))
            Button(action: close) {
                Text("Close Player")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(focused ? .black : .white)
                    .padding(.horizontal, 34)
                    .padding(.vertical, 15)
                    .background(Capsule().fill(focused ? Color.white : Color.white.opacity(0.16)))
            }
            .buttonStyle(.plain)
            .focused($focused)
        }
        .padding(42)
        .frame(maxWidth: 900)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .foregroundStyle(.white)
        .shadow(color: .black.opacity(0.55), radius: 30)
        .onAppear { focused = true }
    }
}

struct AppleVODPosterCard: View {
    let item: MediaItem

    private var isLivePoster: Bool {
        item.type.lowercased() == "live"
    }

    var body: some View {
        RemoteImageFit(url: item.posterURL, mode: isLivePoster ? .fit : .fill)
            .padding(isLivePoster ? 10 : 0)
            .background(Color.black.opacity(isLivePoster ? 0.24 : 0.0))
            .frame(width: 178, height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.24), lineWidth: 1))
            .shadow(color: .black.opacity(0.68), radius: 18, x: 0, y: 10)
            // v408: VOD playback overlay mini-poster must remain clean artwork only.
            // Ratings still render in detail pages/rows/metadata badges; only this VOD overlay poster badge is removed.
    }
}

struct AppleVODBadge: View {
    let text: String
    let highlighted: Bool

    var body: some View {
        Text(text)
            .font(.system(size: 17, weight: .black, design: .rounded))
            .foregroundStyle(highlighted ? .black : .white.opacity(0.86))
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(highlighted ? Color.white.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(Capsule().stroke(Color.white.opacity(highlighted ? 0.0 : 0.16), lineWidth: 1))
    }
}

struct AppleVODChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.clear, .black.opacity(0.16), .black.opacity(0.92)],
                startPoint: .top,
                endPoint: .bottom
            )
            LinearGradient(
                colors: [.black.opacity(0.18), .clear, .black.opacity(0.16)],
                startPoint: .leading,
                endPoint: .trailing
            )
            VStack { Spacer() }
                .background(
                    Rectangle()
                        .fill(Color.black.opacity(0.22))
                        .background(.ultraThinMaterial)
                        .frame(height: 420),
                    alignment: .bottom
                )
        }
    }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        view.playerLayer.videoGravity = videoGravity
        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        view.playerLayer.player = player
        view.playerLayer.videoGravity = videoGravity
    }
}

struct DebridPlayerPanel<Content: View>: View {
    let title: String
    let detail: String
    var focusedOption: VODPlayerScreen.PlayerPanelOption? = nil
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.system(size: 34, weight: .black))
            Text(detail)
                .font(.system(size: 21, weight: .semibold))
                .foregroundStyle(.white.opacity(0.82))
                .lineLimit(4)
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 10) {
                        content()
                    }
                    .padding(.vertical, 4)
                }
                .frame(maxHeight: 470)
                .onAppear {
                    if let focusedOption {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                            withAnimation(.easeOut(duration: 0.12)) {
                                proxy.scrollTo(focusedOption, anchor: .center)
                            }
                        }
                    }
                }
                .onChange(of: focusedOption) { next in
                    guard let next else { return }
                    withAnimation(.easeOut(duration: 0.12)) {
                        proxy.scrollTo(next, anchor: .center)
                    }
                }
            }
        }
        .foregroundStyle(.white)
        .padding(30)
        .frame(width: 620, alignment: .leading)
        .background(.ultraThinMaterial.opacity(0.92), in: RoundedRectangle(cornerRadius: 30))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.55), radius: 26)
        .focusSection()
    }
}

struct PanelOptionChip: View {
    let title: String
    var selected: Bool = false
    let focus: VODPlayerScreen.PlayerPanelOption
    var focused: FocusState<VODPlayerScreen.PlayerPanelOption?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(selected ? Color.cyan.opacity(0.98) : Color.white.opacity(0.92))
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Capsule().fill(selected ? Color.cyan.opacity(0.16) : Color.white.opacity(0.08)))
                .overlay(Capsule().stroke(selected ? Color.cyan.opacity(0.82) : Color.white.opacity(0.16), lineWidth: selected ? 2 : 1))
                .scaleEffect(selected ? 1.025 : 1.0)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .buttonBorderShape(.capsule)
        .clipShape(Capsule())
        .id(focus)
        .focused(focused, equals: focus)
        .focusable(false)
    }
}

struct PlayerChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.clear, .black.opacity(0.25), .black.opacity(0.92)], startPoint: .top, endPoint: .bottom)
            LinearGradient(colors: [.black.opacity(0.18), .clear, .black.opacity(0.20)], startPoint: .leading, endPoint: .trailing)
        }
    }
}

struct PlayerProgressBar: View {
    let progress: Double

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.18))
                Capsule().fill(Color.white.opacity(0.72)).frame(width: proxy.size.width * min(max(progress, 0), 1))
                Circle().fill(Color.white).frame(width: 18, height: 18).offset(x: max(0, proxy.size.width * min(max(progress, 0), 1) - 9))
            }
        }
    }
}


struct VODRuntimeProgressSummary: View {
    let title: String
    let current: String
    let total: String
    let remaining: String
    let percent: String
    let cacheLabel: String
    let cacheUsed: String
    let cacheLimit: String

    var body: some View {
        HStack(spacing: 18) {
            Text(title)
                .font(.system(size: 20, weight: .black, design: .rounded))
                .lineLimit(1)
                .frame(maxWidth: 520, alignment: .leading)
            Text("Time \(current) / \(total)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Remaining \(remaining)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Progress \(percent)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Cache \(cacheUsed) / \(cacheLimit) (\(cacheLabel))")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .lineLimit(1)
        }
        .foregroundStyle(.white.opacity(0.86))
        .padding(.horizontal, 4)
        .accessibilityLabel("\(title), playback time \(current) of \(total), \(percent) complete, \(remaining) remaining, cache \(cacheUsed) of \(cacheLimit)")
    }
}

struct VODCacheProgressRow: View {
    let cacheLabel: String
    let usedGB: Double
    let limitGB: Double
    let progress: Double
    let status: String

    var body: some View {
        HStack(spacing: 14) {
            Text("Cache")
                .font(.system(size: 16, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.10))
                Capsule().fill(LinearGradient(colors: [.cyan.opacity(0.92), .blue.opacity(0.72)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, 330 * progress))
            }
            .frame(width: 330, height: 8)
            Text(limitGB == 0 ? String(format: "%.2f GB / Unlimited", usedGB) : String(format: "%.2f GB / %@", usedGB, cacheLabel))
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.46))
            Text("• \(status)")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Text("• English audio preferred • Subtitles off")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.34))
        }
        .lineLimit(1)
    }
}

struct VODFocusBoundaryModifier: ViewModifier {
    func body(content: Content) -> some View {
        // tvOS-compatible focus boundary shim: keep the overlay as its own focus section
        // without depending on newer SDK-only focusMovementBoundary symbols.
        content
            .focusSection()
            .contentShape(Rectangle())
    }
}


struct VODOverlayMenuButton<MenuContent: View>: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    @ViewBuilder let menuContent: () -> MenuContent

    var body: some View {
        PlayerControlButton(title: title, focus: focus, focused: focused) { }
    }
}

struct PlayerControlButton: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let action: () -> Void

    private var selected: Bool { focused.wrappedValue == focus }
    private var foregroundColor: Color { selected ? Color.cyan.opacity(0.98) : .white.opacity(0.92) }
    private var fillColor: Color { selected ? Color.cyan.opacity(0.16) : .white.opacity(0.105) }
    private var strokeColor: Color { selected ? Color.cyan.opacity(0.82) : .white.opacity(0.20) }
    private var strokeWidth: CGFloat { selected ? 2 : 1 }
    private var buttonScale: CGFloat { selected ? 1.055 : 1.0 }
    private var glowColor: Color { selected ? Color.cyan.opacity(0.22) : .clear }

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 20, weight: .black, design: .rounded))
                .foregroundStyle(foregroundColor)
                .padding(.horizontal, 21)
                .padding(.vertical, 13)
                .background(Capsule().fill(fillColor))
                .overlay(Capsule().stroke(strokeColor, lineWidth: strokeWidth))
                .scaleEffect(buttonScale)
                .shadow(color: glowColor, radius: 13)
                .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .buttonBorderShape(.capsule)
        .clipShape(Capsule())
        .focused(focused, equals: focus)
        .focusable(false)
        .accessibilityLabel(title)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @AppStorage("liveChannelsDvrBaseURL") private var liveChannelsDvrBaseURL: String = ""
    @AppStorage("liveHDHomeRunManualURL") private var liveHDHomeRunManualURL: String = ""
    @AppStorage("liveHDHomeRunManualGuideURL") private var liveHDHomeRunManualGuideURL: String = ""
    @AppStorage("liveM3UURL") private var liveM3UURL: String = ""
    @AppStorage("liveXMLTVURL") private var liveXMLTVURL: String = ""
    @AppStorage("liveXtreamServer") private var liveXtreamServer: String = ""
    @AppStorage("liveXtreamUsername") private var liveXtreamUsername: String = ""
    @AppStorage("liveXtreamPassword") private var liveXtreamPassword: String = ""
    @AppStorage("liveXtreamAccounts") private var liveXtreamAccounts: String = ""
    @AppStorage("liveXtreamLoginStatus") private var liveXtreamLoginStatus: String = "Not connected"
    @AppStorage("backendBaseURL") private var backendBaseURL: String = "http://192.168.100.55:8181"
    @AppStorage("tmdbApiKey") private var tmdbApiKey: String = ""
    @AppStorage("fanartTvApiKey") private var fanartTvApiKey: String = ""
    @AppStorage("tvdbApiToken") private var tvdbApiToken: String = ""
    @AppStorage("externalMoviesInfuseDefault") private var externalMoviesInfuseDefault: Bool = false
    @AppStorage("externalMoviesVLCDefault") private var externalMoviesVLCDefault: Bool = false
    @AppStorage("externalMoviesSenPlayerDefault") private var externalMoviesSenPlayerDefault: Bool = false
    @AppStorage("externalShowsInfuseDefault") private var externalShowsInfuseDefault: Bool = false
    @AppStorage("externalShowsVLCDefault") private var externalShowsVLCDefault: Bool = false
    @AppStorage("externalShowsSenPlayerDefault") private var externalShowsSenPlayerDefault: Bool = false
    @AppStorage("liveTVUseAVPlayerDefault") private var liveTVUseAVPlayerDefault: Bool = false
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"
    @FocusState private var focused: SettingsFocus?
    @State private var lastSettingsDpadMoveAt: Date = .distantPast
    @State private var isXtreamLoggingIn: Bool = false

    enum SettingsFocus: Hashable { case manifest, add, load, loadAll, reset, liveDvr, liveHDHRManual, liveHDHRGuideURL, liveM3U, liveXMLTV, liveXtreamServer, liveXtreamUsername, liveXtreamPassword, liveXtreamLogin, backendBase, tmdbKey, fanartKey, tvdbToken, saveArtworkKeys, extMovieInfuse, extMovieVLC, extMovieSen, extShowInfuse, extShowVLC, extShowSen, liveAVPlayerDefault, trailerModeAutomatic, trailerModeInApp, trailerModeYouTube, gridLockedMode, home, movies, shows, live }

    var body: some View {
        ZStack {
            StaticAppBackground().ignoresSafeArea()
            settingsScroll
        }
        .onAppear { focused = .manifest }
        // v182: Let the tvOS focus engine own Settings DPAD movement. The prior
        // manual routeSettings() handler fought the native ScrollView/TextField focus
        // movement, causing one Siri Remote click to jump two controls.
    }

    private var settingsScroll: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .leading, spacing: 22) {
                settingsTitle
                stremioCard
                quickNavigationCard
                Spacer(minLength: 80)
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
            .padding(.bottom, 120)
        }
    }

    private var settingsTitle: some View {
        Text("Settings")
            .font(.system(size: 62, weight: .black))
            .foregroundStyle(.white)
            .padding(.top, 132)
    }

    private var stremioCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            stremioHeader
            manifestInput
            manifestButtons
            savedManifestList
            liveTVSourcesSection
            trailerSettingsSection
            externalPlayerDefaultsSection
            artworkKeysSection
            buildStatusSection
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var stremioHeader: some View {
        Text("Stremio JSON Catalogs")
            .font(.system(size: 28, weight: .bold))
            .foregroundStyle(.white)
    }

    private var manifestInput: some View {
        TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
            .font(.system(size: 23, weight: .semibold))
            .foregroundStyle(.white)
            .padding(20)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.cyan : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
            .focused($focused, equals: .manifest)
            .frame(width: 1180)
    }

    private var manifestButtons: some View {
        HStack(spacing: 16) {
            SettingsButton(title: "Add JSON", focus: .add, focused: $focused) {
                store.addManifestURL(manifestURL)
                manifestURL = ""
            }
            SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL", focus: .load, focused: $focused) {
                Task { await store.loadManifest(urlString: manifestURL) }
            }
            SettingsButton(title: "Load All Catalogs", focus: .loadAll, focused: $focused) {
                Task { await store.loadAllManifests() }
            }
            SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                store.resetDemo()
            }
        }
    }

    private var savedManifestList: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Saved JSON URLs")
                .font(.system(size: 20, weight: .black))
                .foregroundStyle(.cyan)
            ForEach(store.manifestURLs.prefix(5), id: \.self) { url in
                SettingsStremioAddonRow(url: url)
                    .environmentObject(store)
            }
        }
        .padding(.top, 4)
    }

    private var liveTVSourcesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Live TV Sources")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            liveTextField("Channels DVR base URL, example http://192.168.1.50:8089", text: $liveChannelsDvrBaseURL, focus: .liveDvr)
            liveTextField("HDHomeRun manual IP or lineup URL, example http://hdhomerun.local/lineup.json", text: $liveHDHomeRunManualURL, focus: .liveHDHRManual)
            liveTextField("HDHomeRun/XMLTV Gracenotes guide URL", text: $liveHDHomeRunManualGuideURL, focus: .liveHDHRGuideURL)
            liveMultiLineField("M3U playlist URLs — paste multiple links, one per line", text: $liveM3UURL, focus: .liveM3U)
            liveMultiLineField("XMLTV guide URLs — paste multiple links, one per line", text: $liveXMLTVURL, focus: .liveXMLTV)
            xtreamFields
            Text("v326 supports multiple M3U playlist URLs, multiple XMLTV guide URLs, and multiple Xtream accounts. Put one per line, or save Xtream accounts with Save / Login.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: 1120, alignment: .leading)
            EmptyView() // v436: Grid Locked Mode removed/disabled while trailer playback is repaired.
        }
        .padding(.top, 6)
    }

    private func liveTextField(_ placeholder: String, text: Binding<String>, focus: SettingsFocus) -> some View {
        TextField(placeholder, text: text)
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(.white)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
            .focused($focused, equals: focus)
            .frame(width: 1120)
    }

    private func liveMultiLineField(_ placeholder: String, text: Binding<String>, focus: SettingsFocus) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(placeholder)
                .font(.system(size: 15, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.68))
            VStack(alignment: .leading, spacing: 6) {
                TextField("Paste one or more links separated by new lines, commas, or spaces", text: text)
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
                    .focused($focused, equals: focus)
                Text("Supports multiple links separated by new lines, commas, or spaces.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
                    .padding(.leading, 4)
            }
            .frame(width: 1120, height: 118)
        }
    }

    private func liveToggleButton(title: String, subtitle: String, isOn: Binding<Bool>, focus: SettingsFocus) -> some View {
        Button {
            isOn.wrappedValue.toggle()
        } label: {
            HStack(spacing: 16) {
                RoundedRectangle(cornerRadius: 16)
                    .fill(isOn.wrappedValue ? Color.cyan.opacity(0.85) : Color.white.opacity(0.12))
                    .frame(width: 86, height: 44)
                    .overlay(alignment: isOn.wrappedValue ? .trailing : .leading) {
                        Circle().fill(Color.white).frame(width: 34, height: 34).padding(5)
                    }
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(title): \(isOn.wrappedValue ? "On" : "Off")")
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.62))
                        .lineLimit(2)
                }
                Spacer()
            }
            .padding(14)
            .frame(width: 1120)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused, equals: focus)
    }

    private var xtreamFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                TextField("Xtream server", text: $liveXtreamServer)
                    .focused($focused, equals: .liveXtreamServer)
                TextField("Username", text: $liveXtreamUsername)
                    .focused($focused, equals: .liveXtreamUsername)
                TextField("Password", text: $liveXtreamPassword)
                    .focused($focused, equals: .liveXtreamPassword)
            }
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(.white)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(isXtreamFieldFocused ? Color.orange : Color.white.opacity(0.12), lineWidth: isXtreamFieldFocused ? 3 : 1))

            HStack(spacing: 14) {
                SettingsButton(title: isXtreamLoggingIn ? "Checking Xtream…" : "Save / Login Xtream", focus: .liveXtreamLogin, focused: $focused) {
                    Task { await saveAndLoginXtream() }
                }
                Text(liveXtreamLoginStatus)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(liveXtreamLoginStatus.lowercased().contains("connected") ? Color.green : Color.white.opacity(0.72))
                    .lineLimit(2)
                    .frame(width: 650, alignment: .leading)
            }
            Text(savedXtreamAccountCount > 0 ? "Saved Xtream accounts: \(savedXtreamAccountCount). Current fields can be saved again to add another account." : "Saved Xtream accounts: none yet. Save/Login adds this Xtream account to the source list.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: 1120, alignment: .leading)
        }
        .frame(width: 1120, alignment: .leading)
    }

    private var savedXtreamAccountCount: Int {
        liveXtreamAccounts
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .count
    }

    @MainActor
    private func saveAndLoginXtream() async {
        liveXtreamServer = liveXtreamServer.trimmingCharacters(in: .whitespacesAndNewlines)
        liveXtreamUsername = liveXtreamUsername.trimmingCharacters(in: .whitespacesAndNewlines)
        liveXtreamPassword = liveXtreamPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !liveXtreamServer.isEmpty, !liveXtreamUsername.isEmpty, !liveXtreamPassword.isEmpty else {
            liveXtreamLoginStatus = "Xtream needs server, username, and password."
            return
        }
        isXtreamLoggingIn = true
        liveXtreamLoginStatus = "Checking Xtream login…"
        let result = await validateXtreamLogin(server: liveXtreamServer, username: liveXtreamUsername, password: liveXtreamPassword)
        isXtreamLoggingIn = false
        liveXtreamLoginStatus = result
        if result.lowercased().contains("connected") {
            saveXtreamAccountToList(server: liveXtreamServer, username: liveXtreamUsername, password: liveXtreamPassword)
        }
    }

    private func saveXtreamAccountToList(server: String, username: String, password: String) {
        let line = [normalizeXtreamSettingsServer(server), username.trimmingCharacters(in: .whitespacesAndNewlines), password.trimmingCharacters(in: .whitespacesAndNewlines)].joined(separator: "|")
        guard !line.replacingOccurrences(of: "|", with: "").isEmpty else { return }
        var lines = liveXtreamAccounts
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        lines.removeAll { $0 == line }
        lines.append(line)
        liveXtreamAccounts = lines.joined(separator: "\n")
    }

    private func validateXtreamLogin(server rawServer: String, username: String, password: String) async -> String {
        let base = normalizeXtreamSettingsServer(rawServer)
        guard let user = username.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let pass = password.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(base)/player_api.php?username=\(user)&password=\(pass)") else {
            return "Xtream URL is invalid."
        }
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("application/json,*/*", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/349", forHTTPHeaderField: "User-Agent")
        do {
            let data: Data
            let statusCode: Int
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,*/*", userAgent: "DebridChannels-tvOS/349", maxBytes: 4 * 1024 * 1024, timeout: 18)
                data = plain.data
                statusCode = plain.statusCode
            } else {
                let (sessionData, response) = try await URLSession.shared.data(for: request)
                data = sessionData
                statusCode = (response as? HTTPURLResponse)?.statusCode ?? 200
            }
            if !(200...299).contains(statusCode) {
                return "Xtream login failed: HTTP \(statusCode)."
            }
            guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return "Xtream login failed: invalid response."
            }
            let userInfo = root["user_info"] as? [String: Any]
            let authValue = userInfo?["auth"]
            let status = (userInfo?["status"] as? String)?.lowercased() ?? ""
            let authorized = (authValue as? NSNumber)?.intValue == 1 || (authValue as? String) == "1" || status == "active"
            if authorized {
                let exp = userInfo?["exp_date"] as? String ?? ""
                let suffix = exp.isEmpty ? "" : " • expires \(exp)"
                return "Xtream connected. Settings saved. Reopen Live TV or use refresh to load Live channels only.\(suffix)"
            }
            return "Xtream login failed: account not authorized."
        } catch {
            return "Xtream login failed: \(error.localizedDescription)"
        }
    }

    private func normalizeXtreamSettingsServer(_ raw: String) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
        return clean
    }


    private var trailerSettingsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Trailer Playback")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Choose how trailers open. Automatic Fallback tries the in-app popup first, then opens YouTube if a direct trailer stream is not ready.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: 1120, alignment: .leading)
            HStack(spacing: 14) {
                SettingsButton(title: trailerPlaybackMode == "automatic" ? "✓ Automatic Fallback" : "Automatic Fallback", focus: .trailerModeAutomatic, focused: $focused) { trailerPlaybackMode = "automatic" }
                SettingsButton(title: trailerPlaybackMode == "inApp" ? "✓ In-App Popup" : "In-App Popup", focus: .trailerModeInApp, focused: $focused) { trailerPlaybackMode = "inApp" }
                SettingsButton(title: trailerPlaybackMode == "youtube" ? "✓ Open in YouTube" : "Open in YouTube", focus: .trailerModeYouTube, focused: $focused) { trailerPlaybackMode = "youtube" }
            }
            Text("In-App Popup is experimental. Open in YouTube remains available as a reliable external fallback.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: 1120, alignment: .leading)
        }
        .padding(.top, 10)
    }

    private var externalPlayerDefaultsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("External Player Defaults")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Optional. Movies/Shows can launch external apps. Live TV can use AVPlayer as a backup/default; KSPlayer remains the normal default and auto-fallback.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: 1120, alignment: .leading)
            liveToggleButton(title: "Movies default to Infuse", subtitle: "Open movie streams in Infuse when a link starts.", isOn: $externalMoviesInfuseDefault, focus: .extMovieInfuse)
            liveToggleButton(title: "Movies default to VLC App", subtitle: "Open movie streams in the external VLC app.", isOn: $externalMoviesVLCDefault, focus: .extMovieVLC)
            liveToggleButton(title: "Movies default to SenPlayer", subtitle: "Open movie streams in SenPlayer when installed.", isOn: $externalMoviesSenPlayerDefault, focus: .extMovieSen)
            liveToggleButton(title: "Shows default to Infuse", subtitle: "Open episode streams in Infuse when a link starts.", isOn: $externalShowsInfuseDefault, focus: .extShowInfuse)
            liveToggleButton(title: "Shows default to VLC App", subtitle: "Open episode streams in the external VLC app.", isOn: $externalShowsVLCDefault, focus: .extShowVLC)
            liveToggleButton(title: "Shows default to SenPlayer", subtitle: "Open episode streams in SenPlayer when installed.", isOn: $externalShowsSenPlayerDefault, focus: .extShowSen)
            liveToggleButton(title: "Live TV default to AVPlayer", subtitle: "Use AVPlayer as Live TV backup/default. If a channel fails, it falls back to KSPlayer automatically.", isOn: $liveTVUseAVPlayerDefault, focus: .liveAVPlayerDefault)
        }
        .padding(.top, 10)
    }

    private var artworkKeysSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Artwork Provider Keys")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Optional. These unlock richer posters, clearlogos, banners, landscape art, and randomized artwork pools for both tvOS and Android through the connected service.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: 1120, alignment: .leading)
            liveTextField("Service Connection URL, example http://192.168.100.55:8181", text: $backendBaseURL, focus: .backendBase)
            liveTextField("TMDB API key", text: $tmdbApiKey, focus: .tmdbKey)
            liveTextField("Fanart.tv API key", text: $fanartTvApiKey, focus: .fanartKey)
            liveTextField("TVDB API bearer token", text: $tvdbApiToken, focus: .tvdbToken)
            SettingsButton(title: "Save Artwork Keys", focus: .saveArtworkKeys, focused: $focused) {
                Task { await saveArtworkKeysToBackend() }
            }
            Text("Keys are stored locally on this Apple TV and synced to the service runtime config so Android TV can use the same artwork pool.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: 1120, alignment: .leading)
        }
        .padding(.top, 10)
    }

    private func saveArtworkKeysToBackend() async {
        let base = backendBaseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !base.isEmpty, let url = URL(string: base + "/api/artwork/provider-keys") else {
            await MainActor.run { store.status = "Artwork key save failed: enter a valid service URL." }
            return
        }
        let body: [String: String] = [
            "tmdbApiKey": tmdbApiKey,
            "fanartTvApiKey": fanartTvApiKey,
            "tvdbApiToken": tvdbApiToken
        ]
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
            let (_, response) = try await URLSession.shared.data(for: request)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            await MainActor.run {
                store.status = (200..<300).contains(code) ? "Artwork provider keys saved to service." : "Artwork key save failed with HTTP \(code)."
            }
        } catch {
            await MainActor.run { store.status = "Artwork key save failed: \(error.localizedDescription)" }
        }
    }

    private var buildStatusSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Build v442_TRAILER_SESSION_COMPILE_FIX")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text(store.status)
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.white.opacity(0.72))
                .frame(width: 1180, alignment: .leading)
        }
    }

    private var quickNavigationCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Quick Navigation")
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white)
            HStack(spacing: 18) {
                SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
            }
            Text("Settings shortcuts")
                .font(.system(size: 20, weight: .black, design: .rounded))
                .foregroundStyle(.cyan)
                .padding(.top, 8)
            HStack(spacing: 18) {
                SettingsButton(title: "Live Sources", focus: .liveDvr, focused: $focused) { focused = .liveDvr }
                SettingsButton(title: "Xtream Login", focus: .liveXtreamServer, focused: $focused) { focused = .liveXtreamServer }
                SettingsButton(title: "Players", focus: .extMovieInfuse, focused: $focused) { focused = .extMovieInfuse }
                SettingsButton(title: "Artwork Keys", focus: .backendBase, focused: $focused) { focused = .backendBase }
            }
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var isXtreamFieldFocused: Bool {
        focused == .liveXtreamServer || focused == .liveXtreamUsername || focused == .liveXtreamPassword
    }

    private func acceptSingleSettingsDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSettingsDpadMoveAt) > 0.32 else { return false }
        lastSettingsDpadMoveAt = now
        return true
    }

    private func routeSettings(_ direction: MoveCommandDirection) {
        switch direction {
        case .right:
            switch focused {
            case .manifest: focused = .add
            case .add: focused = .load
            case .load: focused = .loadAll
            case .loadAll: focused = .reset
            case .liveXtreamServer: focused = .liveXtreamUsername
            case .liveXtreamUsername: focused = .liveXtreamPassword
            case .reset: focused = .liveDvr
            case .home: focused = .movies
            case .movies: focused = .shows
            case .shows: focused = .live
            case .liveXtreamPassword: focused = .liveXtreamLogin
            case .liveXtreamLogin: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeYouTube
            case .trailerModeYouTube: focused = .backendBase
            case .backendBase: focused = .tmdbKey
            case .tmdbKey: focused = .fanartKey
            case .fanartKey: focused = .tvdbToken
            case .tvdbToken: focused = .saveArtworkKeys
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .gridLockedMode, .live, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .saveArtworkKeys, .none: break
            }
        case .left:
            switch focused {
            case .add: focused = .manifest
            case .load: focused = .add
            case .loadAll: focused = .load
            case .reset: focused = .loadAll
            case .liveXtreamUsername: focused = .liveXtreamServer
            case .liveXtreamPassword: focused = .liveXtreamUsername
            case .movies: focused = .home
            case .shows: focused = .movies
            case .live: focused = .shows
            case .backendBase: focused = .trailerModeYouTube
            case .liveXtreamLogin: focused = .liveXtreamPassword
            case .trailerModeAutomatic: focused = .liveXtreamLogin
            case .trailerModeInApp: focused = .trailerModeAutomatic
            case .trailerModeYouTube: focused = .trailerModeInApp
            case .tmdbKey: focused = .backendBase
            case .fanartKey: focused = .tmdbKey
            case .tvdbToken: focused = .fanartKey
            case .saveArtworkKeys: focused = .tvdbToken
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .gridLockedMode, .manifest, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .liveXtreamServer, .home, .none: break
            }
        case .down:
            switch focused {
            case .manifest: focused = .add
            case .add, .load, .loadAll, .reset: focused = .liveDvr
            case .liveDvr: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveM3U
            case .liveM3U: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword, .liveXtreamLogin: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeYouTube
            case .trailerModeYouTube: focused = .backendBase
            case .gridLockedMode: focused = .backendBase
            case .backendBase, .tmdbKey, .fanartKey, .tvdbToken: focused = .saveArtworkKeys
            case .saveArtworkKeys: focused = .home
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .home, .movies, .shows, .live: break
            case .none: focused = .manifest
            }
        case .up:
            switch focused {
            case .home, .movies, .shows, .live: focused = .saveArtworkKeys
            case .saveArtworkKeys: focused = .backendBase
            case .backendBase, .tmdbKey, .fanartKey, .tvdbToken: focused = .trailerModeYouTube
            case .trailerModeYouTube: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .liveXtreamServer
            case .gridLockedMode: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword, .liveXtreamLogin: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveM3U
            case .liveM3U: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveDvr
            case .liveDvr: focused = .add
            case .add, .load, .loadAll, .reset: focused = .manifest
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .manifest: store.menuFocusToken += 1
            case .none: focused = .manifest
            }
        default:
            break
        }
    }
}

struct SettingsStremioAddonRow: View {
    @EnvironmentObject var store: CatalogStore
    let url: String

    private var identity: StremioAddonIdentity? { store.addonIdentities[url] }
    private var label: String {
        if let name = identity?.name, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return name }
        return URL(string: url)?.host ?? "Stremio JSON"
    }
    private var initials: String {
        let text = label.split(separator: " ").prefix(2).compactMap { $0.first }.map(String.init).joined().uppercased()
        return text.isEmpty ? "S" : text
    }

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(Color.black.opacity(0.35))
                if let icon = identity?.iconURL, !icon.isEmpty {
                    RemoteImageFit(url: icon, mode: .fit)
                        .clipShape(Circle())
                } else {
                    Text(initials)
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.92))
                }
            }
            .frame(width: 36, height: 36)

            VStack(alignment: .leading, spacing: 3) {
                Text(label)
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.90))
                    .lineLimit(1)
                Text(url)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .frame(width: 1120, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}



struct LiveTVChannel: Identifiable, Hashable {
    let id: Int
    let logo: String
    let number: String
    let name: String
    let category: String
    let now: String
    let next: String
    let description: String
    let accent: Color
    var streamURL: String = ""
    var iconURL: String = ""
    var tvgID: String = ""
    var source: String = "Demo"
}

struct LiveProgram: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let width: CGFloat
    let isLive: Bool
    var description: String = ""
    var startText: String = ""
    var endText: String = ""
    var imageURL: String = ""
    // v276: keep real guide timing so the renderer uses current/future listings
    // instead of the first programs in the XMLTV file. This fixes partially
    // populated guide rows after real channels load.
    var startDate: Date? = nil
    var endDate: Date? = nil

    var liveProgress: CGFloat {
        guard let startDate, let endDate, endDate > startDate else { return 0.5 }
        let duration = endDate.timeIntervalSince(startDate)
        guard duration > 0 else { return 0.5 }
        let elapsed = Date().timeIntervalSince(startDate)
        return CGFloat(min(max(elapsed / duration, 0.0), 1.0))
    }
}

struct LiveTVLoadedChannel: Identifiable, Hashable, Codable {
    var id: Int
    var logo: String
    var number: String
    var name: String
    var category: String
    var now: String
    var next: String
    var description: String
    var streamURL: String
    var iconURL: String
    var tvgID: String
    var source: String

    func uiChannel() -> LiveTVChannel {
        LiveTVChannel(
            id: id,
            logo: logo,
            number: number,
            name: name,
            category: category,
            now: now,
            next: next,
            description: description,
            accent: LiveTVSourceModel.accent(for: category),
            streamURL: streamURL,
            iconURL: iconURL,
            tvgID: tvgID,
            source: source
        )
    }
}

struct XtreamLiveDraft {
    let streamID: String
    let extensionName: String
    let name: String
    let categoryName: String
    let categoryID: String
    let epgID: String
    let number: String
    let iconURL: String
}

struct XtreamParsedPayload {
    let categoryMap: [String: String]
    let liveRows: [XtreamLiveDraft]
}

@MainActor
final class LiveTVSourceModel: ObservableObject {
    @Published var channels: [LiveTVChannel] = LiveTVScreen.sampleChannels
    @Published var guidePrograms: [String: [LiveProgram]] = [:]
    @Published var status: String = "Live TV demo lineup ready. Configure Channels DVR, M3U/XMLTV, or Xtream in Settings, then reopen Live TV."
    @Published var isLoading: Bool = false

    private let cacheKey = "liveTVLoadedChannelsV165"
    private let guideCacheKey = "liveTVGuideProgramsV191"
    private let lastRefreshKey = "liveTVLastRefreshV191"
    private let refreshTTL: TimeInterval = 3 * 60 * 60
    private let liveGuideDurationSeconds = 43_200
    private let liveGuideMaxProgramRows = 96
    private static var sessionChannels: [LiveTVChannel] = []
    private static var sessionGuidePrograms: [String: [LiveProgram]] = [:]
    private static var sessionStatus: String = ""
    private var hasLoadedThisAppSession = false

    private var shouldRefreshNow: Bool {
        let last = UserDefaults.standard.double(forKey: lastRefreshKey)
        guard last > 0 else { return true }
        return Date().timeIntervalSince1970 - last >= refreshTTL
    }

    func refreshIfNeeded() async {
        loadCachedOrDemo()
        guard !hasLoadedThisAppSession || shouldRefreshNow || channels.isEmpty else {
            status = "Live TV lineup kept loaded • \(channels.count) channels • refreshes after 3 hours or app restart"
            return
        }
        await refreshFromConfiguredSources()
    }

    func forceRefreshGuide() async {
        status = "Force refreshing Live TV guide…"
        UserDefaults.standard.removeObject(forKey: lastRefreshKey)
        Self.sessionChannels = []
        Self.sessionGuidePrograms = [:]
        Self.sessionStatus = ""
        hasLoadedThisAppSession = false
        await refreshFromConfiguredSources()
    }

    nonisolated static func accent(for category: String) -> Color {
        switch category.lowercased() {
        case "sports": return .red
        case "news": return .red
        case "kids": return .orange
        case "movies": return .cyan
        case "hd": return .blue
        case "favorites": return .indigo
        case "comedy": return .mint
        default: return .gray
        }
    }

    func loadCachedOrDemo() {
        // v309: keep Live TV guide/channel state alive while the app process is alive.
        // This prevents the guide from disappearing when opening Settings or switching tabs,
        // but intentionally does not persist the guide across force-quit/relaunch.
        if !Self.sessionChannels.isEmpty {
            channels = Self.sessionChannels
            guidePrograms = Self.sessionGuidePrograms
            hasLoadedThisAppSession = true
            status = Self.sessionStatus.ifEmpty("Live TV session retained • \(channels.count) channels • \(guidePrograms.values.reduce(0) { $0 + $1.count }) guide rows")
            return
        }
        guard let data = UserDefaults.standard.data(forKey: cacheKey),
              let saved = try? JSONDecoder().decode([LiveTVLoadedChannel].self, from: data),
              !saved.isEmpty else { return }
        channels = saved.map { $0.uiChannel() }
        // Disk lineup is only a visual placeholder after app restart; the guide is reloaded.
        hasLoadedThisAppSession = false
        status = "Cached Live TV lineup shown while guide reloads • \(channels.count) channels"
    }

    func refreshFromConfiguredSources() async {
        isLoading = true
        defer { isLoading = false }
        let defaults = UserDefaults.standard
        let dvrBase = defaults.string(forKey: "liveChannelsDvrBaseURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManual = defaults.string(forKey: "liveHDHomeRunManualURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManualGuide = defaults.string(forKey: "liveHDHomeRunManualGuideURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let m3uURLs = Self.parseSourceList(defaults.string(forKey: "liveM3UURL") ?? "")
        let xmltvURLs = Self.parseSourceList(defaults.string(forKey: "liveXMLTVURL") ?? "")
        let xtreamAccounts = Self.parseXtreamAccounts(
            saved: defaults.string(forKey: "liveXtreamAccounts") ?? "",
            currentServer: defaults.string(forKey: "liveXtreamServer") ?? "",
            currentUser: defaults.string(forKey: "liveXtreamUsername") ?? "",
            currentPass: defaults.string(forKey: "liveXtreamPassword") ?? ""
        )

        var loaded: [LiveTVChannel] = []
        var messages: [String] = []
        var xmlGuide = ""
        let previousGuidePrograms = guidePrograms
        // v309: keep the currently visible guide on screen while a refresh is in flight.
        // Only replace it after new guide data has successfully parsed.

        if !dvrBase.isEmpty {
            let result = await loadChannelsDVR(base: dvrBase, allowAutoScan: false)
            loaded.append(contentsOf: result.channels)
            messages.append(result.message)
            let storedDvrBase = UserDefaults.standard.string(forKey: "liveChannelsDvrBaseURL") ?? dvrBase
            let dvrGuideBase = normalizeServerBase(storedDvrBase, defaultPort: 8089)
            if !dvrGuideBase.isEmpty { xmlGuide = await fetchText("\(dvrGuideBase)/devices/ANY/guide/xmltv?duration=\(liveGuideDurationSeconds)", accept: "application/xml,text/xml,*/*", maxBytes: 512 * 1024 * 1024) ?? xmlGuide }
        }

        if !hdhrManual.isEmpty {
            let hdhr = await loadHDHomeRun(manual: hdhrManual, allowAutoScan: false)
            var hdhrChannels = hdhr.channels
            messages.append(hdhr.message)
            if !hdhrManualGuide.isEmpty,
               let hdhrXML = await fetchText(cappedGuideURL(hdhrManualGuide), accept: "application/xml,text/xml,*/*", maxBytes: 512 * 1024 * 1024) {
                hdhrChannels = applyXMLTVIcons(hdhrXML, to: hdhrChannels, baseURL: urlBase(hdhrManualGuide))
                let hdhrGuide = parseXMLTV(hdhrXML, channels: hdhrChannels)
                for (key, value) in hdhrGuide { guidePrograms[key] = value }
                xmlGuide = xmlGuide.isEmpty ? hdhrXML : xmlGuide
                messages.append("HDHomeRun XMLTV/Gracenotes guide matched \(hdhrGuide.count) channel(s)")
            }
            loaded.append(contentsOf: hdhrChannels)
        }

        for (index, m3uURL) in m3uURLs.enumerated() {
            let m3u = await loadM3U(url: m3uURL, source: m3uURLs.count > 1 ? "M3U/XMLTV #\(index + 1)" : "M3U/XMLTV")
            loaded.append(contentsOf: m3u.channels)
            messages.append(m3u.message)
        }

        var xmlGuideFragments: [String] = []
        for (index, xmltvURL) in xmltvURLs.enumerated() {
            if let fragment = await fetchText(cappedGuideURL(xmltvURL), accept: "application/xml,text/xml,*/*", maxBytes: 128 * 1024 * 1024), !fragment.isEmpty {
                xmlGuideFragments.append(fragment)
                messages.append(xmltvURLs.count > 1 ? "XMLTV #\(index + 1) guide loaded" : "XMLTV guide loaded")
            }
        }
        if !xmlGuideFragments.isEmpty { xmlGuide = xmlGuideFragments.joined(separator: "\n") }

        var xtreamGuideJobs: [(server: String, username: String, password: String, channels: [LiveTVChannel])] = []
        for (index, account) in xtreamAccounts.enumerated() {
            let xtream = await loadXtream(server: account.server, username: account.username, password: account.password, sourceName: xtreamAccounts.count > 1 ? "Xtream/IPTV #\(index + 1)" : "Xtream/IPTV")
            loaded.append(contentsOf: xtream.channels)
            messages.append(xtream.message)
            if !xtream.channels.isEmpty {
                await commitXtreamChannelsInVisibleBatches(xtream.channels, existing: loaded.filter { !$0.source.hasPrefix("Xtream/IPTV") }, messages: messages)
                xtreamGuideJobs.append((account.server, account.username, account.password, xtream.channels))
                messages.append(xtreamAccounts.count > 1 ? "Xtream #\(index + 1) guide will load after channels appear" : "Xtream guide will load after channels appear")
            }
        }

        var finalized = dedupe(loaded)
        if !xmlGuide.isEmpty {
            finalized = applyXMLTVIcons(xmlGuide, to: finalized, baseURL: !xmltvURLs.isEmpty ? urlBase(xmltvURLs[0]) : (!dvrBase.isEmpty ? normalizeServerBase(dvrBase, defaultPort: 8089) : ""))
            let parsedGuide = parseXMLTV(xmlGuide, channels: finalized)
            if !parsedGuide.isEmpty { guidePrograms = parsedGuide }
            else if !previousGuidePrograms.isEmpty { guidePrograms = previousGuidePrograms }
            let guideCount = guidePrograms.values.reduce(0) { $0 + $1.count }
            if guideCount > 0 { messages.append("Guide matched \(guidePrograms.count) channel(s) / \(guideCount) program(s)") }
        } else if guidePrograms.isEmpty && !previousGuidePrograms.isEmpty {
            guidePrograms = previousGuidePrograms
        }

        if !finalized.isEmpty {
            channels = finalized.sorted { channelSortKey($0.number) < channelSortKey($1.number) || (channelSortKey($0.number) == channelSortKey($1.number) && $0.name < $1.name) }
            let persist = channels.map { LiveTVLoadedChannel(id: $0.id, logo: $0.logo, number: $0.number, name: $0.name, category: $0.category, now: $0.now, next: $0.next, description: $0.description, streamURL: $0.streamURL, iconURL: $0.iconURL, tvgID: $0.tvgID, source: $0.source) }
            if let data = try? JSONEncoder().encode(persist) { UserDefaults.standard.set(data, forKey: cacheKey) }
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: lastRefreshKey)
            hasLoadedThisAppSession = true
            status = messages.joined(separator: " • ").ifEmpty("Loaded \(channels.count) Live TV channels")
            Self.sessionChannels = channels
            Self.sessionGuidePrograms = guidePrograms
            Self.sessionStatus = status
            for job in xtreamGuideJobs {
                Task { await self.loadDeferredXtreamShortGuide(server: job.server, username: job.username, password: job.password, channels: job.channels) }
            }
        } else {
            status = messages.joined(separator: " • ").ifEmpty("No configured Live TV source returned channels. Demo lineup remains visible.")
        }
    }

    private struct XtreamAccount { let server: String; let username: String; let password: String }

    private static func parseSourceList(_ raw: String) -> [String] {
        raw
            .components(separatedBy: CharacterSet(charactersIn: "\n;"))
            .flatMap { segment in segment.components(separatedBy: ",").map { String($0) } }
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .reduce(into: [String]()) { result, item in
                if !result.contains(item) { result.append(item) }
            }
    }

    private static func parseXtreamAccounts(saved: String, currentServer: String, currentUser: String, currentPass: String) -> [XtreamAccount] {
        var accounts: [XtreamAccount] = []
        func add(server: String, user: String, pass: String) {
            let s = server.trimmingCharacters(in: .whitespacesAndNewlines)
            let u = user.trimmingCharacters(in: .whitespacesAndNewlines)
            let p = pass.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !s.isEmpty, !u.isEmpty, !p.isEmpty else { return }
            let normalized = normalizeXtreamServerStatic(s)
            if !accounts.contains(where: { $0.server == normalized && $0.username == u }) {
                accounts.append(XtreamAccount(server: normalized, username: u, password: p))
            }
        }
        saved.components(separatedBy: .newlines).forEach { line in
            let parts = line.components(separatedBy: "|")
            if parts.count >= 3 { add(server: parts[0], user: parts[1], pass: parts.dropFirst(2).joined(separator: "|")) }
        }
        add(server: currentServer, user: currentUser, pass: currentPass)
        return accounts
    }

    private static func normalizeXtreamServerStatic(_ raw: String) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
        return clean
    }

    private static func retagChannel(_ channel: LiveTVChannel, source: String) -> LiveTVChannel {
        LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: channel.now, next: channel.next, description: channel.description, accent: channel.accent, streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: source)
    }

    private func normalizeServerBase(_ raw: String, defaultPort: Int?) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") {
            clean = "http://" + clean
        }
        guard let defaultPort,
              var components = URLComponents(string: clean),
              components.port == nil,
              let host = components.host,
              !host.isEmpty else { return clean }
        components.port = defaultPort
        return components.string ?? clean
    }

    private func channelsDVRCandidates(rawBase: String, allowAutoScan: Bool) -> [String] {
        let trimmed = rawBase.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        return [normalizeServerBase(trimmed, defaultPort: 8089)]
    }

    private func loadChannelsDVR(base rawBase: String, allowAutoScan: Bool = true) async -> (channels: [LiveTVChannel], message: String) {
        let candidates = channelsDVRCandidates(rawBase: rawBase, allowAutoScan: allowAutoScan)
        var best: ([LiveTVChannel], String)? = nil
        for base in candidates {
        var combined: [LiveTVChannel] = []
        let m3uCandidates = [
            "\(base)/devices/ANY/channels.m3u",
            "\(base)/devices/ANY/channels.m3u?format=ts&codec=copy",
            "\(base)/devices/ANY/channels.m3u?format=ts"
        ]
        for url in m3uCandidates {
            if let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 6 * 1024 * 1024) {
                combined += parseM3U(text, source: "Channels DVR", baseURL: base)
            }
        }

        var devices = await fetchDVRDevices(base: base)
        if !devices.contains("ANY") { devices.append("ANY") }
        for device in devices {
            let encDevice = urlEncode(device)
            if let data = await fetchText("\(base)/devices/\(encDevice)/channels", accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024),
               let list = parseDVRChannelsJSON(data, base: base, device: device), !list.isEmpty {
                combined += list
            }
        }
        let groups = await loadDVRLineupGroups(base: base)
        let mapped = combined.map { channel -> LiveTVChannel in
            let extra = groups.first { _, members in
                members.contains(channel.number.lowercased()) || members.contains(channel.name.lowercased()) || (!channel.tvgID.isEmpty && members.contains(channel.tvgID.lowercased()))
            }?.key
            if let extra, !extra.isEmpty {
                return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: normalizeCategory(extra, fallback: channel.category), now: channel.now, next: channel.next, description: channel.description, accent: Self.accent(for: extra), streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: channel.source)
            }
            return channel
        }
        let out = dedupe(mapped)
        if !out.isEmpty { UserDefaults.standard.set(base, forKey: "liveChannelsDvrBaseURL"); return (out, "Channels DVR native • \(out.count) channel(s) • \(base)") }
        best = (out, "Channels DVR returned no channels at \(base)")
        }
        return best ?? ([], allowAutoScan ? "Channels DVR auto-scan found no server" : "Channels DVR not configured")
    }

    private func loadHDHomeRun(manual: String, allowAutoScan: Bool) async -> (channels: [LiveTVChannel], message: String) {
        var all: [LiveTVChannel] = []
        var messages: [String] = []
        for url in hdHomeRunManualCandidates(manual) {
            if url.lowercased().hasSuffix(".m3u") {
                let m3u = await loadM3U(url: url, source: "HDHomeRun")
                all.append(contentsOf: m3u.channels.map { ch in
                    LiveTVChannel(id: ch.id, logo: ch.logo, number: ch.number, name: ch.name, category: ch.category.ifEmpty("HDHomeRun"), now: ch.now, next: ch.next, description: ch.description, accent: Self.accent(for: ch.category), streamURL: ch.streamURL, iconURL: ch.iconURL, tvgID: ch.tvgID, source: "HDHomeRun")
                })
                messages.append("HDHomeRun manual M3U • \(m3u.channels.count)")
            } else if url.lowercased().hasSuffix(".xml") {
                if let xml = await fetchText(url, accept: "application/xml,text/xml,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunXMLLineup(xml, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual XML • \(parsed.count)")
                }
            } else {
                if let json = await fetchText(url, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual JSON • \(parsed.count)")
                }
            }
        }
        if allowAutoScan {
            let devices = await discoverHDHomeRunDevices()
            for device in devices {
                if let json = await fetchText(device.lineupURL, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: device.baseURL)
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun auto \(device.name) • \(parsed.count)")
                }
            }
            if devices.isEmpty { messages.append("HDHomeRun auto-scan found no devices") }
        }
        let out = dedupe(all)
        return (out, out.isEmpty ? messages.joined(separator: " • ").ifEmpty("HDHomeRun off/no channels") : "HDHomeRun • \(out.count) channel(s) • " + messages.joined(separator: " • "))
    }

    private struct HDHomeRunDeviceCandidate { let name: String; let baseURL: String; let lineupURL: String }

    private func discoverHDHomeRunDevices() async -> [HDHomeRunDeviceCandidate] {
        guard let text = await fetchText("http://my.hdhomerun.com/discover", accept: "application/json,*/*", maxBytes: 512 * 1024),
              let data = text.data(using: .utf8),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.compactMap { obj in
            let base = stringValue(obj, keys: ["BaseURL", "BaseUrl", "baseURL"]).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let lineup = stringValue(obj, keys: ["LineupURL", "LineupUrl", "lineupURL"]).ifEmpty(base.isEmpty ? "" : base + "/lineup.json")
            guard !base.isEmpty, !lineup.isEmpty else { return nil }
            let name = stringValue(obj, keys: ["FriendlyName", "DeviceID", "DeviceId"]).ifEmpty("HDHomeRun")
            return HDHomeRunDeviceCandidate(name: name, baseURL: base, lineupURL: lineup)
        }
    }

    private func hdHomeRunManualCandidates(_ raw: String) -> [String] {
        let tokens = raw.split(whereSeparator: { $0 == "," || $0 == ";" || $0 == "\n" }).map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        var out: [String] = []
        for token in tokens {
            var clean = token
            if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
            let lower = clean.lowercased()
            if lower.hasSuffix("/lineup.json") || lower.hasSuffix("/lineup.m3u") || lower.hasSuffix("/lineup.xml") {
                out.append(clean)
            } else if lower.hasSuffix("/discover.json") {
                let base = String(clean.dropLast("/discover.json".count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            } else {
                let base = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            }
        }
        var seen = Set<String>()
        return out.filter { seen.insert($0).inserted }
    }

    private func parseHDHomeRunJSONLineup(_ json: String, base: String) -> [LiveTVChannel] {
        guard let data = json.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.enumerated().compactMap { index, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Guide", "number", "channel"])
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "CallSign"]).ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = stringValue(obj, keys: ["URL", "StreamURL", "PlayURL", "url"]).ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            guard !stream.isEmpty else { return nil }
            let icon = stringValue(obj, keys: ["ImageURL", "GuideImageURL", "LogoURL", "StationLogo", "IconURL", "logo"])
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func parseHDHomeRunXMLLineup(_ xml: String, base: String) -> [LiveTVChannel] {
        guard let regex = try? NSRegularExpression(pattern: #"<Program[^>]*>(.*?)</Program>"#, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let ns = xml as NSString
        return regex.matches(in: xml, range: NSRange(location: 0, length: ns.length)).enumerated().compactMap { index, match in
            let body = ns.substring(with: match.range(at: 1))
            let number = tagText(body, tag: "GuideNumber")
            let name = tagText(body, tag: "GuideName").ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = tagText(body, tag: "URL").ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            let icon = tagText(body, tag: "ImageURL").ifEmpty(tagText(body, tag: "GuideImageURL")).ifEmpty(tagText(body, tag: "LogoURL")).ifEmpty(tagText(body, tag: "IconURL"))
            guard !stream.isEmpty else { return nil }
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func urlBase(_ raw: String) -> String {
        guard let url = URL(string: raw), let scheme = url.scheme, let host = url.host else { return raw }
        let port = url.port.map { ":\($0)" } ?? ""
        return "\(scheme)://\(host)\(port)"
    }

    private func fetchDVRDevices(base: String) async -> [String] {
        guard let text = await fetchText("\(base)/devices", accept: "application/json,*/*", maxBytes: 512 * 1024), let data = text.data(using: .utf8) else { return [] }
        var names: [String] = []
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            for obj in arr { addDeviceName(from: obj, into: &names) }
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if let arr = obj["devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            if let arr = obj["Devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            addDeviceName(from: obj, into: &names)
        }
        var seen = Set<String>()
        return names.filter { value in
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty && clean.uppercased() != "ANY" else { return false }
            return seen.insert(clean).inserted
        }
    }

    private func addDeviceName(from obj: [String: Any], into names: inout [String]) {
        for key in ["name", "Name", "DeviceID", "DeviceId", "deviceID", "id", "ID"] {
            if let value = obj[key] as? String, !value.isEmpty { names.append(value) }
        }
    }

    private func parseDVRChannelsJSON(_ text: String, base: String, device: String) -> [LiveTVChannel]? {
        guard let data = text.data(using: .utf8) else { return nil }
        let raw: Any?
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            raw = arr
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            raw = obj["channels"] as? [[String: Any]] ?? obj["Channels"] as? [[String: Any]]
        } else { raw = nil }
        guard let arr = raw as? [[String: Any]] else { return nil }
        return arr.enumerated().compactMap { idx, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Number", "number", "channelNumber", "ChannelNumber"])
            let id = stringValue(obj, keys: ["id", "ID", "GuideNumber", "Number", "StationID", "stationID", "TmsId", "tmsId", "GuideID", "guideID"]).ifEmpty(number)
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "channel"]).ifEmpty("Channel \(number.ifEmpty(id.ifEmpty("\(idx+1)")))")
            let playbackKey = number.ifEmpty(id)
            guard !playbackKey.isEmpty else { return nil }
            let url = "\(base)/devices/\(urlEncode(device))/channels/\(urlEncode(playbackKey))/stream.mpg?format=ts&codec=copy"
            let rawIcon = stringValue(obj, keys: ["ImageURL", "Image", "imageUrl", "LogoURL", "logoUrl", "logo", "tvg-logo", "icon", "Icon", "stationLogo", "StationLogo", "Logo", "PreferredImage", "GracenoteLogo", "gracenoteLogo"])
            var icon = absoluteLogoURL(rawIcon, base: base)
            if icon.isEmpty && !id.isEmpty { icon = "\(base)/images/station/\(urlEncode(id))" }
            let category = inferCategory(name: name, explicit: "Channels DVR")
            return makeChannel(name: name, number: number, url: url, source: "Channels DVR", category: category, iconURL: icon, tvgID: id)
        }
    }

    private func loadDVRLineupGroups(base: String) async -> [String: Set<String>] {
        guard let text = await fetchText("\(base)/dvr/lineups", accept: "application/json,*/*", maxBytes: 2 * 1024 * 1024), let data = text.data(using: .utf8) else { return [:] }
        let root = try? JSONSerialization.jsonObject(with: data)
        var entries: [[String: Any]] = []
        if let arr = root as? [[String: Any]] { entries = arr }
        if let obj = root as? [String: Any] {
            entries = (obj["lineups"] as? [[String: Any]]) ?? (obj["Lineups"] as? [[String: Any]]) ?? (obj["items"] as? [[String: Any]]) ?? []
        }
        var result: [String: Set<String>] = [:]
        for obj in entries {
            let name = stringValue(obj, keys: ["name", "Name", "title", "Title", "group", "Group"]).ifEmpty("Channels DVR")
            var members = Set<String>()
            func add(_ any: Any?) {
                if let s = any as? String { members.insert(s.lowercased()) }
                if let n = any as? NSNumber { members.insert(n.stringValue.lowercased()) }
                if let arr = any as? [Any] { arr.forEach { add($0) } }
                if let dict = any as? [String: Any] {
                    for key in ["GuideNumber", "Number", "number", "GuideName", "Name", "name", "id", "ID"] { add(dict[key]) }
                }
            }
            for key in ["channels", "Channels", "members", "Members", "items", "Items"] { add(obj[key]) }
            if !members.isEmpty { result[name] = members }
        }
        return result
    }

    private func loadM3U(url: String, source: String) async -> (channels: [LiveTVChannel], message: String) {
        guard let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 18 * 1024 * 1024) else { return ([], "M3U failed") }
        let channels = parseM3U(text, source: source, baseURL: "")
        return (channels, channels.isEmpty ? "M3U returned no channels" : "M3U/XMLTV • \(channels.count) channel(s)")
    }

    private func parseM3U(_ text: String, source: String, baseURL: String) -> [LiveTVChannel] {
        var out: [LiveTVChannel] = []
        var meta = ""
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("#EXTINF") { meta = line; continue }
            if line.isEmpty || line.hasPrefix("#") { continue }
            guard !meta.isEmpty else { continue }
            let name = meta.components(separatedBy: ",").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Channel \(out.count + 1)"
            let tvgName = attr(meta, "tvg-name")
            let displayName = tvgName.ifEmpty(name)
            let group = attr(meta, "group-title")
            let number = attr(meta, "tvg-chno").ifEmpty(attr(meta, "channel-number")).ifEmpty(attr(meta, "ch-number"))
            let tvgId = attr(meta, "tvc-guide-stationid").ifEmpty(attr(meta, "tvg-id")).ifEmpty(attr(meta, "channel-id"))
            let icon = absoluteLogoURL(attr(meta, "tvg-logo").ifEmpty(attr(meta, "logo")).ifEmpty(attr(meta, "x-tvg-url")), base: baseURL)
            out.append(makeChannel(name: displayName, number: number, url: absoluteStreamURL(line, base: baseURL), source: source, category: inferCategory(name: displayName, explicit: group), iconURL: icon, tvgID: tvgId))
            meta = ""
        }
        return out
    }

    private func loadDeferredXtreamShortGuide(server: String, username: String, password: String, channels xtreamChannels: [LiveTVChannel]) async {
        guard !xtreamChannels.isEmpty else { return }
        status = "Xtream Live loaded • loading guide in safe batches…"
        Self.sessionStatus = status
        let parsed = await loadXtreamShortGuidePrograms(server: server, username: username, password: password, channels: xtreamChannels)
        guard !parsed.isEmpty else {
            status = "Xtream Live loaded • guide unavailable or provider returned no current EPG"
            Self.sessionStatus = status
            return
        }
        for (key, value) in parsed { guidePrograms[key] = value }
        Self.sessionGuidePrograms = guidePrograms
        let rows = parsed.values.reduce(0) { $0 + $1.count }
        status = "Xtream Live • \(xtreamChannels.count) channel(s) • guide matched \(parsed.count) channel(s) / \(rows) row(s)"
        Self.sessionStatus = status
    }

    private func commitXtreamChannelsInVisibleBatches(_ xtreamChannels: [LiveTVChannel], existing loaded: [LiveTVChannel], messages: [String]) async {
        guard !xtreamChannels.isEmpty else { return }
        var staged = dedupe(loaded)
        let batchSize = 120
        var committed = 0
        while committed < xtreamChannels.count {
            let nextEnd = min(committed + batchSize, xtreamChannels.count)
            let slice = xtreamChannels[committed..<nextEnd]
            staged = dedupe(staged + Array(slice))
            channels = staged.sorted { channelSortKey($0.number) < channelSortKey($1.number) || (channelSortKey($0.number) == channelSortKey($1.number) && $0.name < $1.name) }
            status = (messages + ["Xtream Live visible batch \(nextEnd)/\(xtreamChannels.count)"]).joined(separator: " • ")
            Self.sessionChannels = channels
            Self.sessionGuidePrograms = guidePrograms
            Self.sessionStatus = status
            try? await Task.sleep(nanoseconds: 25_000_000)
            committed = nextEnd
        }
    }

    private func loadXtreamShortGuidePrograms(server: String, username: String, password: String, channels xtreamChannels: [LiveTVChannel]) async -> [String: [LiveProgram]] {
        let base = normalizeServerBase(server, defaultPort: nil)
        let user = urlEncode(username)
        let pass = urlEncode(password)
        let now = Date()
        let cutoff = now.addingTimeInterval(TimeInterval(liveGuideDurationSeconds))
        var resolved: [String: [LiveProgram]] = [:]
        // v320: Never pull full Xtream XMLTV during login. Large providers can return
        // tens/hundreds of MB and crash tvOS before channels appear. Load compact
        // per-channel EPG only for the first visible batch, then the guide can expand later.
        let safeChannels = Array(xtreamChannels.prefix(80))
        var processed = 0
        for channel in safeChannels {
            guard let streamId = xtreamStreamID(from: channel.streamURL), !streamId.isEmpty else { continue }
            let encodedStreamID = urlEncode(streamId)
            let urls = [
                "\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_short_epg&stream_id=\(encodedStreamID)&limit=6",
                "\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_simple_data_table&stream_id=\(encodedStreamID)"
            ]
            var programs: [LiveProgram] = []
            for url in urls {
                guard let text = await fetchText(url, accept: "application/json,*/*", maxBytes: 192 * 1024, timeout: 10),
                      let data = text.data(using: .utf8),
                      let parsedPrograms = parseXtreamShortEPG(data: data, now: now, cutoff: cutoff),
                      !parsedPrograms.isEmpty else { continue }
                programs = parsedPrograms
                break
            }
            guard !programs.isEmpty else { continue }
            for key in xtreamGuideStorageKeys(for: channel) { resolved[key] = programs }
            processed += 1
            if processed % 20 == 0 {
                for (key, value) in resolved { guidePrograms[key] = value }
                Self.sessionGuidePrograms = guidePrograms
                status = "Xtream Live loaded • guide loading \(processed)/\(safeChannels.count)…"
                Self.sessionStatus = status
            }
            if resolved.values.reduce(0, { $0 + $1.count }) >= 300 { break }
        }
        return resolved
    }


    private func xtreamGuideStorageKeys(for channel: LiveTVChannel) -> [String] {
        var keys = Set<String>()
        keys.insert(channelKey(channel))
        for key in channelMatchingKeys(channel) { keys.insert(key) }
        if let streamID = xtreamStreamID(from: channel.streamURL), !streamID.isEmpty {
            for key in xmltvLookupKeys(streamID) { keys.insert(key) }
        }
        return Array(keys)
    }

    private func xtreamStreamID(from streamURL: String) -> String? {
        guard let url = URL(string: streamURL) else { return nil }
        let last = url.lastPathComponent
        if let dot = last.firstIndex(of: ".") { return String(last[..<dot]) }
        return last.isEmpty ? nil : last
    }

    private func parseXtreamShortEPG(data: Data, now: Date, cutoff: Date) -> [LiveProgram]? {
        guard let root = try? JSONSerialization.jsonObject(with: data) else { return nil }
        var rows: [[String: Any]] = []
        if let obj = root as? [String: Any] {
            rows = (obj["epg_listings"] as? [[String: Any]]) ?? (obj["listings"] as? [[String: Any]]) ?? (obj["epg"] as? [[String: Any]]) ?? (obj["data"] as? [[String: Any]]) ?? []
        } else if let arr = root as? [[String: Any]] {
            rows = arr
        }
        guard !rows.isEmpty else { return nil }
        let staleCutoff = now.addingTimeInterval(-10 * 60)
        var out: [LiveProgram] = []
        for row in rows.prefix(12) {
            let title = stringValue(row, keys: ["title", "name", "programme", "program"])
                .base64DecodedIfPossible()
                .ifEmpty("No information")
            let desc = stringValue(row, keys: ["description", "desc", "plot"])
                .base64DecodedIfPossible()
            let start = xtreamEPGDate(stringValue(row, keys: ["start", "start_timestamp", "start_time", "start_time_timestamp"]))
            let end = xtreamEPGDate(stringValue(row, keys: ["end", "stop", "end_timestamp", "end_time", "stop_time", "stop_timestamp"]))
            if let end, end < staleCutoff { continue }
            if let start, start > cutoff { continue }
            let minutes: Int
            if let start, let end, end > start { minutes = max(5, Int(end.timeIntervalSince(start) / 60.0)) }
            else { minutes = 30 }
            let isLive = (start ?? .distantFuture) <= now && now < (end ?? .distantPast)
            let width = CGFloat(max(120, min(560, Int((Double(minutes) / 30.0) * 120.0))))
            out.append(LiveProgram(title: title, width: width, isLive: isLive, description: desc, startText: start?.formatted(date: .omitted, time: .shortened) ?? "", endText: end?.formatted(date: .omitted, time: .shortened) ?? "", imageURL: "", startDate: start, endDate: end))
        }
        return out.sorted { ($0.startDate ?? .distantPast) < ($1.startDate ?? .distantPast) }
    }

    private func xtreamEPGDate(_ raw: String) -> Date? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if let seconds = TimeInterval(value) {
            return Date(timeIntervalSince1970: seconds > 10_000_000_000 ? seconds / 1000.0 : seconds)
        }
        let formats = ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.SSSZ"]
        for format in formats {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = format
            if format == "yyyy-MM-dd HH:mm:ss" { formatter.timeZone = .current }
            if let date = formatter.date(from: value) { return date }
        }
        return nil
    }

    private func loadXtream(server: String, username: String, password: String, sourceName: String = "Xtream/IPTV") async -> (channels: [LiveTVChannel], message: String) {
        let base = normalizeServerBase(server, defaultPort: nil)
        let user = urlEncode(username)
        let pass = urlEncode(password)
        async let categoriesText = fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_categories", accept: "application/json,*/*", maxBytes: 2 * 1024 * 1024, timeout: 12)
        async let liveText = fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_streams", accept: "application/json,*/*", maxBytes: 14 * 1024 * 1024, timeout: 22)
        let parsed = await parseXtreamPayloadOffMain(categoriesText: categoriesText, liveText: liveText)
        guard let parsed, !parsed.liveRows.isEmpty else {
            let fallback = await loadXtreamM3UPlaylist(base: base, user: user, pass: pass)
            if !fallback.isEmpty { return (fallback.map { Self.retagChannel($0, source: sourceName) }, "\(sourceName) Live • \(fallback.count) channel(s) via safe M3U fallback") }
            return ([], "Xtream failed or returned a live channel list too large for safe tvOS loading")
        }
        let channels = parsed.liveRows.prefix(900).compactMap { draft -> LiveTVChannel? in
            let cat = draft.categoryName.ifEmpty(parsed.categoryMap[draft.categoryID] ?? "IPTV")
            return makeChannel(name: draft.name, number: draft.number, url: "\(base)/live/\(user)/\(pass)/\(draft.streamID).\(draft.extensionName.ifEmpty("m3u8"))", source: sourceName, category: inferCategory(name: draft.name, explicit: cat), iconURL: draft.iconURL, tvgID: draft.epgID)
        }
        return (channels, channels.isEmpty ? "\(sourceName) returned no live channels" : "\(sourceName) Live • \(channels.count) channel(s)")
    }

    private nonisolated func parseXtreamPayloadOffMain(categoriesText: String?, liveText: String?) async -> XtreamParsedPayload? {
        await Task.detached(priority: .userInitiated) {
            var categoryMap: [String: String] = [:]
            if let categoriesText, let data = categoriesText.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
                for obj in arr.prefix(5000) {
                    let id = Self.jsonString(obj, keys: ["category_id"])
                    let name = Self.jsonString(obj, keys: ["category_name"])
                    if !id.isEmpty && !name.isEmpty { categoryMap[id] = name }
                }
            }
            guard let liveText, let data = liveText.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return nil }
            let drafts: [XtreamLiveDraft] = arr.prefix(900).compactMap { obj in
                let id = Self.jsonString(obj, keys: ["stream_id"])
                guard !id.isEmpty else { return nil }
                return XtreamLiveDraft(
                    streamID: id,
                    extensionName: Self.jsonString(obj, keys: ["container_extension"]).ifEmpty("m3u8"),
                    name: Self.jsonString(obj, keys: ["name"]).ifEmpty("Channel \(id)"),
                    categoryName: Self.jsonString(obj, keys: ["category_name"]),
                    categoryID: Self.jsonString(obj, keys: ["category_id"]),
                    epgID: Self.jsonString(obj, keys: ["epg_channel_id", "epg_id"]),
                    number: Self.jsonString(obj, keys: ["num"]),
                    iconURL: Self.jsonString(obj, keys: ["stream_icon"])
                )
            }
            return XtreamParsedPayload(categoryMap: categoryMap, liveRows: drafts)
        }.value
    }

    private nonisolated static func jsonString(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let value = obj[key] as? String { return value.trimmingCharacters(in: .whitespacesAndNewlines) }
            if let value = obj[key] as? NSNumber { return value.stringValue }
            if let value = obj[key] { return "\(value)".trimmingCharacters(in: .whitespacesAndNewlines) }
        }
        return ""
    }

    private func loadXtreamM3UPlaylist(base: String, user: String, pass: String) async -> [LiveTVChannel] {
        let url = "\(base)/get.php?username=\(user)&password=\(pass)&type=m3u_plus&output=m3u8"
        guard let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 14 * 1024 * 1024, timeout: 22) else { return [] }
        let parsed = parseM3U(text, source: "Xtream/IPTV", baseURL: base)
        return Array(parsed.prefix(900))
    }

    private func makeChannel(name: String, number: String, url: String, source: String, category: String, iconURL: String, tvgID: String) -> LiveTVChannel {
        let cleanLogo = channelLogo(name: name)
        let idSeed = "\(source)|\(number)|\(name)|\(url)".unicodeScalars.reduce(0) { ($0 &* 31 &+ Int($1.value)) & 0x7fffffff }
        return LiveTVChannel(id: max(1, idSeed), logo: cleanLogo, number: number, name: name, category: category, now: name, next: "Guide data loading", description: source, accent: Self.accent(for: category), streamURL: url, iconURL: iconURL, tvgID: tvgID, source: source)
    }

    private func applyXMLTVIcons(_ xml: String, to channels: [LiveTVChannel], baseURL: String = "") -> [LiveTVChannel] {
        let icons = xmltvChannelIcons(xml)
        guard !icons.isEmpty else { return channels }
        return channels.map { channel in
            if !channel.iconURL.isEmpty { return channel }
            let keys = channelMatchingKeys(channel)
            guard let rawIcon = keys.compactMap({ icons[$0] }).first(where: { !$0.isEmpty }) else { return channel }
            let icon = absoluteLogoURL(rawIcon, base: baseURL)
            return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: channel.now, next: channel.next, description: channel.description, accent: channel.accent, streamURL: channel.streamURL, iconURL: icon, tvgID: channel.tvgID, source: channel.source)
        }
    }

    private func xmltvChannelIcons(_ xml: String) -> [String: String] {
        var out: [String: String] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            let icon = firstXMLIcon(in: body)
            guard !icon.isEmpty else { continue }
            var keys = Set<String>()
            for key in xmltvLookupKeys(id) { keys.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { out[key] = icon }
        }
        return out
    }


    private func firstXMLIcon(in body: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<icon[^>]*src=\"([^\"]+)\"[^>]*/?>", options: [.caseInsensitive]) else { return "" }
        let ns = body as NSString
        guard let match = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), match.numberOfRanges > 1 else { return "" }
        return ns.substring(with: match.range(at: 1)).xmlDecoded()
    }

    private func cappedGuideURL(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var components = URLComponents(string: trimmed) else { return trimmed }
        var items = components.queryItems ?? []
        let hasDuration = items.contains { $0.name.lowercased() == "duration" }
        if hasDuration {
            items = items.map { item in
                item.name.lowercased() == "duration" ? URLQueryItem(name: item.name, value: String(liveGuideDurationSeconds)) : item
            }
        } else if trimmed.lowercased().contains("/guide/xmltv") {
            items.append(URLQueryItem(name: "duration", value: String(liveGuideDurationSeconds)))
        }
        components.queryItems = items.isEmpty ? nil : items
        return components.string ?? trimmed
    }

    private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) -> [String: [LiveProgram]] {
        // Ported from Android LiveGuideProgramResolver: do not assume XMLTV
        // attribute order. Channels DVR/XMLTV providers can emit channel/start/stop
        // in different orders, and older tvOS builds missed those programmes.
        var programsByKey: [String: [LiveProgram]] = [:]
        let channelNames = channelLookupNames(xml)
        let programRegex = try? NSRegularExpression(pattern: #"<programme\s+([^>]*)>(.*?)</programme>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        let matches = programRegex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? []
        for match in matches.prefix(1500000) {
            let attrs = ns.substring(with: match.range(at: 1))
            let body = ns.substring(with: match.range(at: 2))
            let channelID = xmlAttr(attrs, "channel")
            guard !channelID.isEmpty else { continue }
            let startRaw = xmlAttr(attrs, "start")
            let stopRaw = xmlAttr(attrs, "stop")
            let title = tagText(body, tag: "title").ifEmpty("No information")
            let desc = tagText(body, tag: "desc")
            let programIcon = firstXMLIcon(in: body)
            let isLive = isProgramLive(startRaw, stopRaw)
            let minutes = durationMinutes(startRaw, stopRaw)
            let width = CGFloat(max(120, min(560, Int((Double(minutes) / 30.0) * 120.0))))
            let startDate = xmltvDate(startRaw)
            let endDate = xmltvDate(stopRaw)
            let program = LiveProgram(title: title, width: width, isLive: isLive, description: desc, startText: guideTimeText(startRaw).ifEmpty(isLive ? "Now" : ""), endText: guideTimeText(stopRaw), imageURL: programIcon, startDate: startDate, endDate: endDate)
            var keys = Set<String>()
            for key in xmltvLookupKeys(channelID) { keys.insert(key) }
            for alias in channelNames[channelID] ?? [] {
                for key in xmltvLookupKeys(alias) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { programsByKey[key, default: []].append(program) }
        }
        var resolved: [String: [LiveProgram]] = [:]
        let now = Date()
        let staleCutoff = now.addingTimeInterval(-10 * 60)
        for channel in channels {
            let keys = channelMatchingKeys(channel)
            if let found = keys.compactMap({ programsByKey[$0] }).first(where: { !$0.isEmpty }) {
                let sorted = found.sorted {
                    ($0.startDate ?? .distantPast) < ($1.startDate ?? .distantPast)
                }
                let guideCutoff = now.addingTimeInterval(TimeInterval(liveGuideDurationSeconds))
                let currentAndUpcoming = sorted.filter { program in
                    if let end = program.endDate, end < staleCutoff { return false }
                    if let start = program.startDate, start > guideCutoff { return false }
                    return true
                }
                resolved[channelKey(channel)] = Array((currentAndUpcoming.isEmpty ? sorted : currentAndUpcoming).prefix(liveGuideMaxProgramRows))
            }
        }
        return resolved
    }


    private func isProgramLive(_ start: String, _ stop: String) -> Bool {
        guard let s = xmltvDate(start), let e = xmltvDate(stop) else { return false }
        let now = Date()
        return s <= now && now < e
    }

    private func guideTimeText(_ raw: String) -> String {
        guard let date = xmltvDate(raw) else { return "" }
        return date.formatted(date: .omitted, time: .shortened)
    }

    private func xmltvDate(_ raw: String) -> Date? {
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }
        if let epoch = Double(cleaned) {
            let seconds = epoch > 100_000_000_000 ? epoch / 1000.0 : epoch
            return Date(timeIntervalSince1970: seconds)
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss Z", "yyyyMMddHHmmssZ", "yyyyMMddHHmmss", "yyyyMMddHHmm Z", "yyyyMMddHHmmZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: cleaned) { return date }
        }
        return nil
    }

    private func durationMinutes(_ start: String, _ stop: String) -> Int {
        guard let s = xmltvDate(start), let e = xmltvDate(stop), e > s else { return 30 }
        return max(15, min(240, Int(e.timeIntervalSince(s) / 60.0)))
    }

    private func xmlAttr(_ attrs: String, _ name: String) -> String {
        let escaped = NSRegularExpression.escapedPattern(for: name)
        guard let regex = try? NSRegularExpression(pattern: "(?:^|\\s)" + escaped + "=\\\"([^\\\"]*)\\\"", options: [.caseInsensitive]) else { return "" }
        let ns = attrs as NSString
        guard let m = regex.firstMatch(in: attrs, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func xmltvLookupKeys(_ raw: String) -> [String] {
        let value = raw.xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return [] }
        var keys = Set<String>()
        func add(_ candidate: String) {
            let clean = candidate.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty else { return }
            keys.insert(clean.lowercased())
            let normalized = normalizeGuideKey(clean)
            if !normalized.isEmpty { keys.insert(normalized) }
        }
        add(value)
        add(value.replacingOccurrences(of: ".", with: "-"))
        add(value.replacingOccurrences(of: "-", with: "."))
        add(value.replacingOccurrences(of: "_", with: "."))
        add(value.components(separatedBy: ".").first ?? value)
        add(value.components(separatedBy: "-").first ?? value)
        if let digitMatch = value.range(of: #"[0-9]{3,}"#, options: .regularExpression) {
            add(String(value[digitMatch]))
        }
        if let match = value.range(of: #"^([0-9]+(?:[.\-_][0-9]+)?)\s+(.+)$"#, options: .regularExpression) {
            let pair = String(value[match]).split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
            if let first = pair.first {
                add(String(first))
                add(String(first).replacingOccurrences(of: "-", with: "."))
                add(String(first).replacingOccurrences(of: ".", with: "-"))
            }
            if pair.count > 1 { add(String(pair[1])) }
        }
        return Array(keys)
    }

    private func normalizeGuideKey(_ value: String) -> String {
        var clean = value.lowercased()
        for token in ["fhd", "uhd", "4k", "hd"] { clean = clean.replacingOccurrences(of: token, with: "") }
        return clean.components(separatedBy: CharacterSet.alphanumerics.inverted).joined()
    }


    private func channelLookupNames(_ xml: String) -> [String: Set<String>] {
        var out: [String: Set<String>] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            var names = Set<String>()
            for key in xmltvLookupKeys(id) { names.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { names.insert(key) }
                let parts = display.split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
                if let first = parts.first { for key in xmltvLookupKeys(String(first)) { names.insert(key) } }
                if parts.count > 1 { for key in xmltvLookupKeys(String(parts[1])) { names.insert(key) } }
            }
            out[id] = names
        }
        return out
    }


    func programs(for channel: LiveTVChannel) -> [LiveProgram] {
        for key in channelMatchingKeys(channel) {
            if let direct = guidePrograms[key], !direct.isEmpty { return direct }
        }
        let legacyKey = channelKey(channel)
        if let direct = guidePrograms[legacyKey], !direct.isEmpty { return direct }
        return [
            LiveProgram(title: channel.now, width: 240, isLive: true, description: channel.description, startText: "Now", endText: ""),
            LiveProgram(title: channel.next, width: 360, isLive: false, description: channel.description, startText: "+30m", endText: ""),
            LiveProgram(title: channel.category == "Sports" ? "Live Sports" : channel.now, width: 300, isLive: false, description: channel.description),
            LiveProgram(title: channel.category == "Movies" ? "Feature Presentation" : channel.next, width: 330, isLive: false, description: channel.description)
        ]
    }

    func currentProgram(for channel: LiveTVChannel) -> LiveProgram? {
        programs(for: channel).first
    }

    private func channelMatchingKeys(_ channel: LiveTVChannel) -> [String] {
        var keys = Set<String>()
        for raw in [channel.tvgID, channel.number, channel.name, channel.logo, "\(channel.number) \(channel.name)", "\(channel.number) \(channel.logo)", "\(channel.logo) \(channel.number)", "\(channel.name) \(channel.number)"] {
            for key in xmltvLookupKeys(raw) { keys.insert(key) }
        }
        return Array(keys)
    }


    private func channelKey(_ channel: LiveTVChannel) -> String { "\(channel.source)|\(channel.number)|\(channel.name)".lowercased() }

    private func dedupe(_ channels: [LiveTVChannel]) -> [LiveTVChannel] {
        var seen = Set<String>()
        var out: [LiveTVChannel] = []
        for channel in channels {
            let key = !channel.number.isEmpty ? "num:\(channel.number)" : (!channel.streamURL.isEmpty ? "url:\(channel.streamURL)" : "name:\(channel.name.lowercased())")
            if seen.insert(key).inserted { out.append(channel) }
        }
        return out
    }

    private func fetchText(_ urlString: String, accept: String = "*/*", maxBytes: Int = 4 * 1024 * 1024, timeout: TimeInterval = 45) async -> String? {
        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/349", forHTTPHeaderField: "User-Agent")
        do {
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: accept, userAgent: "DebridChannels-tvOS/349", maxBytes: maxBytes, timeout: timeout)
                guard (200...299).contains(plain.statusCode) else { return nil }
                return String(data: plain.data, encoding: .utf8)
            }
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            return String(data: Data(data.prefix(maxBytes)), encoding: .utf8)
        } catch { return nil }
    }

    private func attr(_ meta: String, _ key: String) -> String {
        let pattern = "(?:^|\\s)" + NSRegularExpression.escapedPattern(for: key) + "=\"([^\"]*)\""
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return "" }
        let ns = meta as NSString
        guard let m = regex.firstMatch(in: meta, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func stringValue(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let s = obj[key] as? String, !s.isEmpty { return s }
            if let n = obj[key] as? NSNumber { return n.stringValue }
        }
        return ""
    }

    private func tagText(_ body: String, tag: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<\(tag)[^>]*>(.*?)</\(tag)>", options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return "" }
        let ns = body as NSString
        guard let m = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded()
    }

    private func channelLogo(name: String) -> String {
        let words = name.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }
        if words.count >= 2 { return words.prefix(2).compactMap { $0.first.map(String.init) }.joined().uppercased() }
        return String(name.prefix(8)).uppercased()
    }

    private func inferCategory(name: String, explicit: String) -> String {
        let cleaned = explicit.split(separator: ";").first.map(String.init) ?? explicit
        if !cleaned.isEmpty && cleaned.lowercased() != "channels dvr" && cleaned.lowercased() != "iptv" { return normalizeCategory(cleaned, fallback: cleaned) }
        return normalizeCategory("", fallback: name)
    }

    private func normalizeCategory(_ raw: String, fallback: String) -> String {
        let lower = (raw + " " + fallback).lowercased()
        if lower.contains("sport") || lower.contains("espn") { return "Sports" }
        if lower.contains("news") || lower.contains("cnn") || lower.contains("msnbc") { return "News" }
        if lower.contains("kid") || lower.contains("cartoon") || lower.contains("disney") || lower.contains("nick") { return "Kids" }
        if lower.contains("movie") || lower.contains("hbo") || lower.contains("cinema") || lower.contains("starz") { return "Movies" }
        if lower.contains("favorite") { return "Favorites" }
        if lower.contains("hd") { return "HD" }
        if lower.contains("drama") { return "Drama" }
        return raw.isEmpty ? "All" : raw
    }

    private func absoluteLogoURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func absoluteStreamURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func urlEncode(_ value: String) -> String { value.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? value }
    private func channelSortKey(_ value: String) -> Double { Double(value.replacingOccurrences(of: ".", with: ".").components(separatedBy: CharacterSet(charactersIn: "0123456789.").inverted).joined()) ?? Double.greatestFiniteMagnitude }
}

private extension String {
    func ifEmpty(_ replacement: String) -> String { isEmpty ? replacement : self }
    func xmlDecoded() -> String {
        replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
    }
    func base64DecodedIfPossible() -> String {
        let trimmed = trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 8,
              trimmed.range(of: #"^[A-Za-z0-9+/=]+$"#, options: .regularExpression) != nil,
              let data = Data(base64Encoded: trimmed),
              let decoded = String(data: data, encoding: .utf8),
              !decoded.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return self }
        return decoded.xmlDecoded()
    }
}

private enum LiveTVTheme {
    static let glassAccent = Color(red: 0.035, green: 0.043, blue: 0.052)
    static let glassPanel = Color.white.opacity(0.062)
    static let glassPanelFocused = Color.white.opacity(0.118)
    static let glassStroke = Color.white.opacity(0.105)
    static let liveProgram = Color.white.opacity(0.72)
    static let liveProgramText = Color.white.opacity(0.92)
}


struct GridLockedDockPoster: View {
    let item: MediaItem
    let index: Int
    let isFocused: Bool

    private var w: CGFloat { isFocused ? 292 : 258 }
    private var h: CGFloat { isFocused ? 164 : 146 }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black.opacity(0.34)
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            LinearGradient(colors: [.clear, Color.black.opacity(isFocused ? 0.78 : 0.64)], startPoint: .center, endPoint: .bottom)
            Text(item.title)
                .font(.system(size: isFocused ? 16 : 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(1)
                .padding(.horizontal, isFocused ? 14 : 10)
                .padding(.bottom, isFocused ? 12 : 9)
        }
        .frame(width: w, height: h)
        .clipShape(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous).stroke(isFocused ? Color.white.opacity(0.86) : Color.white.opacity(0.10), lineWidth: isFocused ? 3 : 1))
        .shadow(color: .black.opacity(isFocused ? 0.72 : 0.40), radius: isFocused ? 18 : 8, y: isFocused ? 10 : 5)
        .scaleEffect(isFocused ? 1.02 : 1.0)
        .animation(.spring(response: 0.30, dampingFraction: 0.88), value: isFocused)
    }
}
struct LiveTVScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedModeStored: Bool = false
    private var gridLockedMode: Bool { false }
    @StateObject private var liveModel = LiveTVSourceModel()
    private let baseCategories = ["All", "HD", "Favorites", "Sports", "Drama", "News", "Kids"]

    @State private var selectedCategory: String = "All"
    @State private var selectedChannelID: Int = 6003
    @State private var showGuide: Bool = false
    @FocusState private var categoryFocus: String?
    @FocusState private var tileFocus: Int?
    @FocusState private var guideFocus: Int?
    @State private var lastDpadMoveAt: Date = .distantPast
    @State private var lastSelectAt: Date = .distantPast
    @State private var rightEdgeGuideArmedTileID: Int? = nil
    @State private var leftEdgePanelArmedTileID: Int? = nil
    @State private var leftEdgePanelArmedAt: Date = .distantPast
    @State private var quickWindowVisible: Bool = false
    @State private var quickWindowHideToken: Int = 0
    @State private var previewChannelID: Int? = nil
    @State private var previewWarmupToken: Int = 0
    @State private var previewPlaybackSuppressed: Bool = false
    @State private var renderedChannelLimit: Int = 240
    @State private var renderedWindowStart: Int = 0
    @FocusState private var quickPanelFocus: Bool
    @FocusState private var quickPanelItemFocus: Int?
    @State private var quickPanelSelectionIndex: Int = 0
    @State private var lastQuickPanelMoveAt: Date = .distantPast
    @State private var guideHintVisible: Bool = true
    @State private var guideHintHideTask: Task<Void, Never>? = nil
    @FocusState private var gridLockedDockFocus: Int?
    @State private var gridLockedDockRowIndex: Int = 0
    @State private var gridLockedDockLocked: Bool = false

    private var categories: [String] {
        var set = baseCategories
        for cat in liveModel.channels.map(\.category) where !cat.isEmpty && cat != "Movies" && !set.contains(cat) { set.append(cat) }
        return set
    }

    private var visibleChannels: [LiveTVChannel] {
        if selectedCategory == "All" { return liveModel.channels }
        if selectedCategory == "HD" { return liveModel.channels.filter { $0.category == "HD" || Int($0.number) ?? 0 >= 6000 || $0.name.localizedCaseInsensitiveContains("HD") } }
        return liveModel.channels.filter { $0.category == selectedCategory }
    }

    private var renderedChannels: [LiveTVChannel] {
        // v331: keep the tvOS Focus Engine away from thousands of focusable grid cells.
        // The provider/source layer may hold thousands of channels, but the visible SwiftUI
        // grid only receives a moving window around the focused channel.
        let source = visibleChannels
        guard source.count > renderedChannelLimit else { return source }
        let maxStart = max(0, source.count - renderedChannelLimit)
        let start = min(max(renderedWindowStart, 0), maxStart)
        let end = min(source.count, start + renderedChannelLimit)
        return Array(source[start..<end])
    }

    private var selectedChannel: LiveTVChannel {
        liveModel.channels.first(where: { $0.id == selectedChannelID }) ?? liveModel.channels.first ?? LiveTVScreen.sampleChannels[0]
    }

    private var previewChannel: LiveTVChannel {
        liveModel.channels.first(where: { $0.id == previewChannelID }) ?? selectedChannel
    }

    private var isFocusedTileLastBoxInRow: Bool {
        let focused = tileFocus ?? selectedChannelID
        guard let index = visibleChannels.firstIndex(where: { $0.id == focused }) else { return false }
        return ((index + 1) % 4 == 0) || index == visibleChannels.count - 1
    }

    private var isFocusedTileFirstBoxInRow: Bool {
        let focused = tileFocus ?? selectedChannelID
        guard let index = visibleChannels.firstIndex(where: { $0.id == focused }) else { return false }
        return index % 4 == 0
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                liveBackground(channel: selectedChannel)

                VStack(alignment: .leading, spacing: 18) {
                    if showGuide {
                        guideView(size: geo.size)
                            .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .opacity))
                            .padding(.horizontal, 52)
                            .padding(.top, 112)
                    } else {
                        liveGrid(size: geo.size)
                            .padding(.leading, gridLockedMode ? 398 : 72)
                            .padding(.trailing, 76)
                            .padding(.top, gridLockedMode ? 92 : 132)
                    }
                }
                .animation(.spring(response: 0.42, dampingFraction: 0.88), value: quickWindowVisible)
                // v252: when the left guide tools panel is open, freeze the grid behind it.
                // The panel owns DPAD movement so background rows cannot scroll or steal focus.
                .disabled(quickWindowVisible)
                .allowsHitTesting(!quickWindowVisible)

                if !showGuide {
                    gridQuickControlWindow(size: geo.size)
                        .offset(x: quickWindowVisible || gridLockedMode ? 0 : -390)
                        .opacity(quickWindowVisible || gridLockedMode ? 1.0 : 0.0)
                        .allowsHitTesting(quickWindowVisible)
                        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: quickWindowVisible)
                        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: gridLockedMode)
                        .zIndex(1800)
                    if gridLockedMode {
                        gridLockedCatalogDock(size: geo.size)
                            .allowsHitTesting(store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                            .zIndex(1200)
                    }
                }

                if liveModel.isLoading {
                    ProgressView()
                        .tint(.white)
                        .position(x: geo.size.width - 120, y: 92)
                }

                if !showGuide && guideHintVisible {
                    guideHint
                        .position(x: geo.size.width - 210, y: 132)
                        .transition(.opacity.combined(with: .move(edge: .trailing)))
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .focusSection()
            .onAppear {
                gridLockedModeStored = false
                if store.selectedTab != .live { store.selectedTab = .live }
                liveModel.loadCachedOrDemo()
                categoryFocus = selectedCategory
                tileFocus = selectedChannelID
                quickWindowVisible = false
                store.liveQuickPanelOpen = false
                quickPanelFocus = false
                leftEdgePanelArmedTileID = nil
                leftEdgePanelArmedAt = .distantPast
                previewChannelID = nil
                resetVirtualChannelWindow(to: selectedChannelID)
                scheduleGuideHintAutoHide()
                Task {
                    await liveModel.refreshIfNeeded()
                    if let first = visibleChannels.first, selectedChannelID == LiveTVScreen.sampleChannels[0].id {
                        selectedChannelID = first.id
                        tileFocus = first.id
                    }
                }
            }
            .onDisappear {
                guideHintHideTask?.cancel()
            }
            .onMoveCommand { direction in
                routeLiveSpecialMove(direction)
            }
            .onChange(of: selectedChannelID) { _ in
                keepFocusedChannelInVirtualWindow()
                scheduleLivePreviewWarmup()
            }
            .onChange(of: guideFocus) { value in
                guard showGuide, let value else { return }
                selectedChannelID = value
                scheduleLivePreviewWarmup(immediate: false)
            }
            .onChange(of: showGuide) { value in
                if value {
                    scheduleLivePreviewWarmup(immediate: true)
                } else {
                    previewWarmupToken += 1
                    previewChannelID = nil
                }
            }
            .onChange(of: store.selectedTab) { tab in
                guard gridLockedMode else { return }
                if tab == .home || tab == .movies || tab == .shows {
                    quickWindowVisible = false
                    store.liveQuickPanelOpen = false
                    tileFocus = nil
                    gridLockedDockRowIndex = 0
                    gridLockedDockFocus = 0
                    gridLockedDockLocked = true
                } else if tab == .live {
                    gridLockedDockFocus = nil
                    gridLockedDockLocked = false
                    tileFocus = selectedChannelID
                }
            }
        }
        .background(Color.black.ignoresSafeArea())
    }


    private func acceptSingleDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastDpadMoveAt) > 0.32 else { return false }
        lastDpadMoveAt = now
        return true
    }

    private func acceptSingleSelect() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSelectAt) > 0.30 else { return false }
        lastSelectAt = now
        return true
    }

    private func acceptSingleQuickPanelStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastQuickPanelMoveAt) > 0.42 else { return false }
        lastQuickPanelMoveAt = now
        return true
    }

    private func routeLiveSpecialMove(_ direction: MoveCommandDirection) {
        // v182: native tvOS focus owns normal DPAD movement. Debrid Channels only
        // handles intentional mode transitions. RIGHT on the final grid tile now arms
        // the guide on the first edge press and opens it on the second edge press, so
        // landing on the last channel no longer throws the user straight into guide.
        if showGuide {
            guard direction == .left, acceptSingleDpadStep() else { return }
            if let focusedCategory = categoryFocus, focusedCategory != "All" { return }
            withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                showGuide = false
                tileFocus = selectedChannelID
                rightEdgeGuideArmedTileID = nil
            }
            return
        }

        if gridLockedMode, gridLockedDockLocked || ((store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows) && gridLockedDockFocus != nil) {
            guard acceptSingleQuickPanelStep() else { return }
            switch direction {
            case .up:
                // v430: Grid Locked dock owns vertical focus. At the first dock row,
                // UP must not dump focus back into Live TV or make scrolling stop.
                if gridLockedDockRowIndex > 0 {
                    gridLockedDockRowIndex -= 1
                }
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            case .down:
                gridLockedDockRowIndex = min(gridLockedDockRowIndex + 1, 6)
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            case .left:
                gridLockedDockFocus = max(0, (gridLockedDockFocus ?? 0) - 1)
            case .right:
                gridLockedDockFocus = min(7, (gridLockedDockFocus ?? 0) + 1)
            @unknown default:
                break
            }
            return
        }

        if quickWindowVisible {
            guard acceptSingleQuickPanelStep() else { return }
            switch direction {
            case .left, .right:
                closeQuickWindow()
            case .up:
                quickPanelSelectionIndex = max(0, quickPanelSelectionIndex - 1)
                quickPanelItemFocus = quickPanelSelectionIndex
            case .down:
                quickPanelSelectionIndex = min(quickPanelItemCount - 1, quickPanelSelectionIndex + 1)
                quickPanelItemFocus = quickPanelSelectionIndex
            @unknown default:
                break
            }
            return
        }

        if direction == .left {
            rightEdgeGuideArmedTileID = nil
            let focusedID = tileFocus ?? selectedChannelID
            guard isFocusedTileFirstBoxInRow else {
                leftEdgePanelArmedTileID = nil
                leftEdgePanelArmedAt = .distantPast
                return
            }
            selectedChannelID = focusedID
            tileFocus = focusedID
            // v247: restore the older visible left bar, but keep the requested forced action.
            // First LEFT only arms/re-focuses the first tile. The next LEFT on that same
            // first-column tile opens the menu, matching the RIGHT-edge full-guide behavior.
            let isSecondLeft = leftEdgePanelArmedTileID == focusedID && Date().timeIntervalSince(leftEdgePanelArmedAt) < 3.0
            if isSecondLeft {
                openQuickWindow()
                return
            }
            leftEdgePanelArmedTileID = focusedID
            leftEdgePanelArmedAt = Date()
            DispatchQueue.main.async {
                selectedChannelID = focusedID
                tileFocus = focusedID
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
                selectedChannelID = focusedID
                tileFocus = focusedID
            }
            return
        }

        guard direction == .right, isFocusedTileLastBoxInRow, acceptSingleDpadStep() else {
            if direction != .right { rightEdgeGuideArmedTileID = nil; leftEdgePanelArmedTileID = nil; leftEdgePanelArmedAt = .distantPast }
            return
        }

        let focusedID = tileFocus ?? selectedChannelID
        guard rightEdgeGuideArmedTileID == focusedID else {
            rightEdgeGuideArmedTileID = focusedID
            return
        }

        guideHintVisible = false
        guideHintHideTask?.cancel()
        withAnimation(.spring(response: 0.36, dampingFraction: 0.86)) {
            showGuide = true
            leftEdgePanelArmedTileID = nil
            leftEdgePanelArmedAt = .distantPast
            guideFocus = selectedChannelID
            tileFocus = selectedChannelID
            rightEdgeGuideArmedTileID = nil
        }
        scheduleLivePreviewWarmup(immediate: true)
    }

    private func keepFocusedChannelInVirtualWindow() {
        let source = visibleChannels
        guard source.count > renderedChannelLimit else {
            renderedWindowStart = 0
            return
        }
        let focusedID = tileFocus ?? guideFocus ?? selectedChannelID
        guard let index = source.firstIndex(where: { $0.id == focusedID }) else { return }
        let maxStart = max(0, source.count - renderedChannelLimit)
        let safeStart = min(max(renderedWindowStart, 0), maxStart)
        let safeEnd = min(source.count, safeStart + renderedChannelLimit)
        let edgeBuffer = 32
        if index < safeStart + edgeBuffer || index >= safeEnd - edgeBuffer {
            let targetStart = max(0, min(index - renderedChannelLimit / 2, maxStart))
            if targetStart != renderedWindowStart { renderedWindowStart = targetStart }
        }
    }

    private func resetVirtualChannelWindow(to channelID: Int? = nil) {
        let source = visibleChannels
        guard source.count > renderedChannelLimit else {
            renderedWindowStart = 0
            return
        }
        let index = channelID.flatMap { id in source.firstIndex(where: { $0.id == id }) } ?? 0
        renderedWindowStart = max(0, min(index - renderedChannelLimit / 2, max(0, source.count - renderedChannelLimit)))
    }

    private func scheduleLivePreviewWarmup(immediate: Bool = false) {
        keepFocusedChannelInVirtualWindow()
        previewPlaybackSuppressed = false
        guard showGuide else {
            previewWarmupToken += 1
            return
        }
        let targetID = selectedChannelID
        let targetStream = liveModel.channels.first(where: { $0.id == targetID })?.streamURL ?? selectedChannel.streamURL
        guard !targetStream.isEmpty else { return }
        previewWarmupToken += 1
        let token = previewWarmupToken
        if immediate {
            previewChannelID = targetID
            return
        }
        // v308/v299 base: keep the current preview alive during focus/selection changes instead of
        // blanking the view. This prevents Channels DVR streams from starting and then
        // getting torn down before AVPlayer can render video.
        let delay: Double = 0.55
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            guard token == previewWarmupToken, showGuide, selectedChannelID == targetID else { return }
            previewChannelID = targetID
        }
    }

    private func moveGuideFocus(_ delta: Int) {
        guard let current = guideFocus ?? tileFocus ?? visibleChannels.first?.id, let index = visibleChannels.firstIndex(where: { $0.id == current }) else { return }
        let target = min(max(index + delta, 0), visibleChannels.count - 1)
        selectedChannelID = visibleChannels[target].id
        guideFocus = selectedChannelID
    }

    private func liveBackground(channel: LiveTVChannel) -> some View {
        ZStack {
            StaticAppBackground()
                .ignoresSafeArea()
                .allowsHitTesting(false)

            RadialGradient(colors: [channel.accent.opacity(showGuide ? 0.50 : 0.58), .clear], center: .topTrailing, startRadius: 80, endRadius: 980)
                .ignoresSafeArea()
                .allowsHitTesting(false)

            LinearGradient(
                colors: [Color.black.opacity(0.34), Color(red: 0.035, green: 0.045, blue: 0.055).opacity(0.54), Color.black.opacity(0.74)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            Rectangle()
                .fill(Color.black.opacity(0.38))
                .ignoresSafeArea()
                .allowsHitTesting(false)
        }
    }

    private func gridLockedCatalogDock(size: CGSize) -> some View {
        let sourceRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let wantedType: String? = store.selectedTab == .movies ? "movie" : (store.selectedTab == .shows ? "series" : nil)
        let targetRows = sourceRows.filter { row in
            row.items.contains { item in
                if let wantedType { return item.type == wantedType }
                return item.type == "movie" || item.type == "series"
            }
        }
        let fallbackRows = sourceRows.filter { row in row.items.contains { $0.type == "movie" || $0.type == "series" } }
        let rowsForDock = targetRows.isEmpty ? fallbackRows : targetRows
        let safeRowIndex = rowsForDock.isEmpty ? 0 : min(max(gridLockedDockRowIndex, 0), rowsForDock.count - 1)
        let activeRow = rowsForDock.indices.contains(safeRowIndex) ? rowsForDock[safeRowIndex] : sourceRows.first
        let nextIndex = safeRowIndex + 1
        let nextRow = rowsForDock.indices.contains(nextIndex) ? rowsForDock[nextIndex] : nil
        let rawItems = activeRow?.items ?? []
        let filteredItems = wantedType == nil ? rawItems.filter { $0.type == "movie" || $0.type == "series" } : rawItems.filter { $0.type == wantedType }
        let items = Array((filteredItems.isEmpty ? rawItems : filteredItems).prefix(8))
        let dockIsActive = store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows
        let title = store.selectedTab == .shows ? "FEATURED SHOWS" : (store.selectedTab == .movies ? "FEATURED MOVIES" : "FEATURED PICKS")
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .center, spacing: 12) {
                ThemedPanelLogo(title: title)
                    .scaleEffect(0.42, anchor: .leading)
                    .frame(width: 260, height: 36, alignment: .leading)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 30)
            .padding(.top, 16)

            HStack(alignment: .bottom, spacing: 16) {
                ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                    let isFocused = dockIsActive && gridLockedDockFocus == index
                    GridLockedDockPoster(item: item, index: index, isFocused: isFocused)
                        .contentShape(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous))
                        .focusable(dockIsActive)
                        .focused($gridLockedDockFocus, equals: index)
                        .modifier(TransparentTVFocusVisual())
                        .onTapGesture {
                            guard dockIsActive else { return }
                            store.openDetail(item, pushCurrent: false)
                        }
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 30)
            .padding(.top, 2)
            .frame(height: 196, alignment: .bottomLeading)

            Text(nextRow?.title ?? "Continue Watching")
                .font(.system(size: 20, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.44))
                .padding(.horizontal, 32)
                .padding(.bottom, 18)
        }
        .frame(width: max(1060, size.width - 398), height: 318, alignment: .topLeading)
        .background(
            UnevenRoundedRectangle(topLeadingRadius: 34, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 34, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.black.opacity(0.70), Color.black.opacity(0.54), Color(red: 0.015, green: 0.018, blue: 0.026).opacity(0.46)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: .black.opacity(0.62), radius: 34, y: -8)
        .focusSection()
        .onExitCommand {
            gridLockedDockLocked = false
            gridLockedDockFocus = nil
            store.selectedTab = .live
            tileFocus = selectedChannelID
        }
        .onMoveCommand { direction in
            guard dockIsActive else { return }
            if direction == .up {
                // v430: stay inside the bottom dock while browsing rows.
                // Live TV focus is restored only by selecting Live TV/RIGHT/LEFT path, not accidental UP.
                if gridLockedDockRowIndex > 0 { gridLockedDockRowIndex -= 1 }
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            } else if direction == .down {
                gridLockedDockRowIndex = min(gridLockedDockRowIndex + 1, max(0, rowsForDock.count - 1))
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            }
        }
        .position(x: size.width * 0.5 + 158, y: size.height - 158)
    }

    private func gridQuickControlWindow(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            quickPanelHeader
            quickPanelCategorySection
            if !gridLockedMode {
                quickPanelRefreshButton
                quickPanelCloseHint
            }
            Spacer(minLength: 0)
        }
        .frame(width: gridLockedMode ? 302 : 306, height: gridLockedMode ? 850 : 780, alignment: .topLeading)
        .background(quickPanelBackground)
        .shadow(color: .black.opacity(0.48), radius: 22, x: 10, y: 0)
        .padding(.leading, gridLockedMode ? 18 : 18)
        .padding(.top, gridLockedMode ? 72 : 96)
        .focusSection()
        .focusable(quickWindowVisible)
        .focused($quickPanelFocus)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .onTapGesture { activateQuickPanelSelection() }
        .onSubmit { activateQuickPanelSelection() }
        .onMoveCommand { direction in routeLiveSpecialMove(direction) }
        .onPlayPauseCommand { activateQuickPanelSelection() }
        .onAppear {
            quickPanelSelectionIndex = quickPanelInitialIndex
            quickPanelItemFocus = quickPanelSelectionIndex
        }
        .onChange(of: quickWindowVisible) { visible in
            guard visible else { quickPanelItemFocus = nil; return }
            quickPanelSelectionIndex = quickPanelInitialIndex
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
                quickPanelItemFocus = quickPanelSelectionIndex
            }
        }
        .onChange(of: quickPanelItemFocus) { value in
            if let value, quickWindowVisible { quickPanelSelectionIndex = min(max(value, 0), quickPanelItemCount - 1) }
        }
    }


    private var quickPanelItemCount: Int { categories.count + 1 }

    private var quickPanelInitialIndex: Int {
        categories.firstIndex(of: selectedCategory) ?? 0
    }

    private var isQuickPanelRefreshFocused: Bool {
        quickWindowVisible && quickPanelSelectionIndex == categories.count
    }

    private func activateQuickPanelSelection() {
        guard quickWindowVisible else { return }
        if quickPanelSelectionIndex >= categories.count {
            runQuickPanelForceRefresh()
        } else if categories.indices.contains(quickPanelSelectionIndex) {
            selectQuickPanelCategory(categories[quickPanelSelectionIndex])
        }
        quickPanelFocus = true
    }

    private var quickPanelHeader: some View {        VStack(alignment: .leading, spacing: 8) {
            Text(gridLockedMode ? "DEBRID GRID" : "GUIDE TOOLS")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .tracking(1.5)
                .foregroundStyle(.white.opacity(0.46))
            Text(gridLockedMode ? "" : "Refresh Guide")
                .font(.system(size: gridLockedMode ? 1 : 28, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text(gridLockedMode ? "LEFT rail locked visible" : "Press LEFT again from the first card to open this panel.")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.56))
                .lineLimit(2)
                .lineSpacing(3)
        }
        .padding(.horizontal, gridLockedMode ? 16 : 22)
        .padding(.top, gridLockedMode ? 18 : 22)
    }

    private var quickPanelCategorySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("CATEGORIES")
                .font(.system(size: 12, weight: .black, design: .rounded))
                .tracking(1.3)
                .foregroundStyle(.white.opacity(0.42))
                .padding(.horizontal, 22)

            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(categories.enumerated()), id: \.element) { index, category in
                        quickPanelCategoryButton(category, index: index)
                    }
                }
                .padding(.horizontal, gridLockedMode ? 12 : 18)
                .padding(.bottom, 4)
            }
            .frame(maxHeight: gridLockedMode ? 620 : 610)
            .onMoveCommand { direction in routeLiveSpecialMove(direction) }
            .focusable(false)
            .focusEffectDisabled()
            .modifier(TransparentTVFocusVisual())
        }
    }

    private func quickPanelCategoryButton(_ category: String, index: Int) -> some View {
        let isFocused = quickWindowVisible && quickPanelSelectionIndex == index
        let isSelected = category == selectedCategory
        return Button {
            quickPanelSelectionIndex = index
            selectQuickPanelCategory(category)
        } label: {
            quickPanelCategoryLabel(category: category, isFocused: isFocused, isSelected: isSelected)
        }
        .buttonStyle(.plain)
        .focusable(false)
        .focused($quickPanelItemFocus, equals: index)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
    }

    private func quickPanelCategoryLabel(category: String, isFocused: Bool, isSelected: Bool) -> some View {
        HStack(spacing: 14) {
            Image(systemName: iconForGuideCategory(category))
                .font(.system(size: 18, weight: .bold))
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(category == "All" ? "All Channels" : category)
                    .font(.system(size: gridLockedMode ? 18 : 20, weight: .heavy, design: .rounded))
                    .foregroundStyle(Color.white.opacity(isFocused || isSelected ? 0.98 : 0.72))
                Text("\(channelCount(for: category)) channels")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(Color.white.opacity(isFocused ? 0.70 : 0.38))
                    .opacity(1.0)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .frame(width: 248, height: gridLockedMode ? 56 : 48, alignment: .leading)
        .background(quickPanelCategoryBackground(isFocused: isFocused, isSelected: isSelected))
        .overlay(quickPanelCategoryBorder(isFocused: isFocused, isSelected: isSelected))
        .clipShape(Capsule(style: .continuous))
    }

    private func quickPanelCategoryBackground(isFocused: Bool, isSelected: Bool) -> some View {
        Capsule(style: .continuous)
            .fill(isFocused ? Color.white.opacity(0.16) : (isSelected ? Color.orange.opacity(0.16) : Color.white.opacity(0.045)))
    }

    private func quickPanelCategoryBorder(isFocused: Bool, isSelected: Bool) -> some View {
        Capsule(style: .continuous)
            .stroke(isFocused ? Color.white.opacity(0.42) : (isSelected ? Color.orange.opacity(0.72) : Color.white.opacity(0.07)), lineWidth: isFocused || isSelected ? 2 : 1)
    }

    private func selectQuickPanelCategory(_ category: String) {
        selectedCategory = category
        resetVirtualChannelWindow()
        if let first = visibleChannels.first {
            selectedChannelID = first.id
            resetVirtualChannelWindow(to: first.id)
            // v252: keep the side rail as focus owner while open; restore grid focus only after closing.
            if !quickWindowVisible { tileFocus = first.id }
        }
    }

    private var quickPanelRefreshButton: some View {
        Button {
            runQuickPanelForceRefresh()
        } label: {
            quickPanelRefreshLabel
        }
        .buttonStyle(.plain)
        .focusable(false)
        .focused($quickPanelItemFocus, equals: categories.count)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .padding(.horizontal, 18)
        .padding(.top, 4)
        .onPlayPauseCommand { quickPanelSelectionIndex = categories.count; runQuickPanelForceRefresh() }
        .onSubmit { quickPanelSelectionIndex = categories.count; runQuickPanelForceRefresh() }
    }

    private func runQuickPanelForceRefresh() {
        guard acceptSingleSelect() else { return }
        quickPanelFocus = true
        Task {
            await liveModel.forceRefreshGuide()
            selectedCategory = "All"
            if let first = visibleChannels.first {
                selectedChannelID = first.id
                // v252: real guide refresh can update selection, but must not move focus behind the open rail.
                if !quickWindowVisible { tileFocus = first.id }
            }
            DispatchQueue.main.async {
                quickPanelFocus = true
            }
        }
    }

    private var quickPanelRefreshLabel: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle().fill(Color.blue.opacity(0.24))
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 28, weight: .black))
                    .foregroundStyle(Color.cyan.opacity(0.96))
            }
            .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 2) {
                Text("Force Refresh Guide")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Reload listings and artwork")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.56))
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .frame(width: 248, height: 82, alignment: .leading)
        .background(quickPanelRefreshBackground)
        .overlay(quickPanelRefreshBorder)
        .shadow(color: Color.cyan.opacity(isQuickPanelRefreshFocused ? 0.24 : 0.06), radius: isQuickPanelRefreshFocused ? 18 : 6, x: 0, y: 0)
        .scaleEffect(isQuickPanelRefreshFocused ? 1.025 : 1.0)
    }

    private var quickPanelRefreshBackground: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color(red: 0.02, green: 0.06, blue: 0.12).opacity(0.98), Color.black.opacity(0.92)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var quickPanelRefreshBorder: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .stroke(isQuickPanelRefreshFocused ? Color.cyan.opacity(0.95) : Color.white.opacity(0.14), lineWidth: isQuickPanelRefreshFocused ? 3 : 1)
    }

    private var quickPanelCloseHint: some View {
        Text("RIGHT closes panel")
            .font(.system(size: 13, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.50))
            .padding(.leading, 24)
    }

    private var quickPanelBackground: some View {
        RoundedRectangle(cornerRadius: gridLockedMode ? 34 : 28, style: .continuous)
            .fill(
                LinearGradient(
                    colors: gridLockedMode
                        ? [Color.white.opacity(0.075), Color(red: 0.015, green: 0.021, blue: 0.030).opacity(0.90), Color.black.opacity(0.82)]
                        : [Color.black.opacity(0.96), Color(red: 0.018, green: 0.024, blue: 0.032).opacity(0.94)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var quickPanelBorder: some View {
        RoundedRectangle(cornerRadius: gridLockedMode ? 34 : 28, style: .continuous)
            .stroke(gridLockedMode ? Color.white.opacity(0.18) : Color.white.opacity(0.10), lineWidth: gridLockedMode ? 1.4 : 1)
    }

    private var isFocusedFirstGridTile: Bool {
        guard let focused = tileFocus,
              let first = visibleChannels.first else { return false }
        return focused == first.id
    }

    private func openQuickWindow() {
        quickWindowHideToken += 1
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
            quickWindowVisible = true
            store.liveQuickPanelOpen = true
            // v252: move focus ownership fully into the side rail while it is open.
            // selectedChannelID is preserved so closing restores the same grid card.
            tileFocus = nil
            categoryFocus = nil
            guideFocus = nil
            quickPanelFocus = true
            quickPanelItemFocus = quickPanelInitialIndex
            rightEdgeGuideArmedTileID = nil
            leftEdgePanelArmedTileID = nil
            leftEdgePanelArmedAt = .distantPast
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            quickPanelSelectionIndex = quickPanelInitialIndex
            quickPanelItemFocus = quickPanelSelectionIndex
            quickPanelFocus = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) {
            if quickWindowVisible {
                quickPanelSelectionIndex = quickPanelInitialIndex
                quickPanelFocus = true
            }
        }
    }

    private func closeQuickWindow() {
        quickWindowHideToken += 1
        withAnimation(.spring(response: 0.34, dampingFraction: 0.88)) {
            quickWindowVisible = false
            store.liveQuickPanelOpen = false
            quickPanelFocus = false
            quickPanelItemFocus = nil
            tileFocus = selectedChannelID
        }
    }

    private func scheduleQuickWindowHide(delay: Double) {
        // v223: the utility panel is no longer a timed/autoloading hint. It only opens
        // intentionally when the user presses LEFT from the first grid card, and closes
        // when the user presses RIGHT/LEFT from the panel.
        quickWindowHideToken += 1
    }

    private var topCategoryRail: some View {
        HStack(spacing: 34) {
            ForEach(categories, id: \.self) { category in
                let isFocused = categoryFocus == category
                let isSelected = category == selectedCategory
                Text(category)
                    .font(.system(size: 28, weight: isSelected || isFocused ? .heavy : .semibold))
                    .foregroundStyle(isFocused ? Color.black : (isSelected ? .white : .white.opacity(0.58)))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
                    .padding(.horizontal, isFocused ? 28 : 18)
                    .padding(.vertical, isFocused ? 12 : 10)
                    .background(
                        Capsule(style: .continuous)
                            .fill(isFocused ? Color.white.opacity(0.94) : Color.clear)
                    )
                    .overlay(alignment: .bottom) {
                        if isSelected && !isFocused {
                            Capsule().fill(Color.orange.opacity(0.95)).frame(height: 5).offset(y: 8)
                        }
                    }
                    .contentShape(Capsule(style: .continuous))
                    .focusable(!quickWindowVisible)
                    .focused($categoryFocus, equals: category)
                    .modifier(TransparentTVFocusVisual())
                    .onTapGesture {
                        guard !quickWindowVisible else { return }
                        selectedCategory = category
                        resetVirtualChannelWindow()
                        if let first = visibleChannels.first {
                            selectedChannelID = first.id
                            resetVirtualChannelWindow(to: first.id)
                            tileFocus = first.id
                        }
                    }
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .center)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.10)))
    }

    private func liveGrid(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: gridLockedMode ? 20 : 36), count: 4), spacing: gridLockedMode ? 22 : 34) {
                        ForEach(renderedChannels) { channel in
                            liveTile(channel: channel)
                                .id(channel.id)
                        }
                    }
                    .padding(.top, gridLockedMode ? 8 : 8)
                    .padding(.bottom, gridLockedMode ? 10 : 110)
                }
                .frame(height: gridLockedMode ? 606 : size.height - 230)
                .onChange(of: tileFocus) { value in
                    if let value, !quickWindowVisible {
                        keepFocusedChannelInVirtualWindow()
                        DispatchQueue.main.async {
                            withAnimation(.easeOut(duration: 0.10)) {
                                proxy.scrollTo(value, anchor: .center)
                            }
                        }
                    }
                }
            }
        }
    }

    private func liveTile(channel: LiveTVChannel) -> some View {
        let isFocused = tileFocus == channel.id
        let program = liveModel.currentProgram(for: channel)
        return LiveTVGridTileContent(channel: channel, isFocused: isFocused, program: program, loadArtwork: true, gridLockedMode: gridLockedMode)
            .scaleEffect(isFocused ? (gridLockedMode ? 1.045 : 1.115) : 1.0)
            .offset(x: (gridLockedMode && isFocusedTileFirstBoxInRow && isFocused) ? 44 : 0, y: isFocused ? (gridLockedMode ? -2 : -6) : 0)
            .zIndex(isFocused ? 20 : 0)
            .shadow(color: .black.opacity(isFocused ? 0.88 : 0.30), radius: isFocused ? 30 : 8, y: isFocused ? 16 : 4)
            .animation(.spring(response: 0.32, dampingFraction: 0.94), value: isFocused)
            .contentShape(RoundedRectangle(cornerRadius: 4))
            .focusable(!quickWindowVisible)
            .focused($tileFocus, equals: channel.id)
            .modifier(TransparentTVFocusVisual())
            .onTapGesture {
                guard !quickWindowVisible, acceptSingleSelect() else { return }
                selectedChannelID = channel.id
                play(channel: channel)
            }
            .onPlayPauseCommand {
                guard !quickWindowVisible, acceptSingleSelect() else { return }
                selectedChannelID = channel.id
                play(channel: channel)
            }
            .onMoveCommand { direction in
                // v243: catch edge LEFT/RIGHT while the grid tile itself owns focus.
                // This prevents tvOS from escaping the grid before the forced two-press side-panel action can run.
                routeLiveSpecialMove(direction)
            }
            .onChange(of: tileFocus) { value in
                rightEdgeGuideArmedTileID = nil
                // v247: do not clear the armed-left-panel state when tvOS briefly tries to
                // move focus away after the first LEFT. The first card is re-focused so the
                // second LEFT can open the panel instead of disabling the action.
                if let value, !quickWindowVisible {
                    selectedChannelID = value
                    keepFocusedChannelInVirtualWindow()
                }
            }
    }

    private func shouldLoadArtwork(for channel: LiveTVChannel) -> Bool {
        guard let focused = tileFocus ?? guideFocus else { return false }
        if focused == channel.id { return true }
        guard let focusedIndex = visibleChannels.firstIndex(where: { $0.id == focused }),
              let channelIndex = visibleChannels.firstIndex(where: { $0.id == channel.id }) else { return false }
        return abs(focusedIndex - channelIndex) <= 4
    }

    private func scheduleGuideHintAutoHide() {
        guideHintHideTask?.cancel()
        guideHintVisible = true
        guideHintHideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.24)) { guideHintVisible = false }
        }
    }

    private var guideHint: some View {
        HStack(spacing: 10) {
            Image(systemName: "arrow.right.circle.fill")
            Text("Press RIGHT for full guide")
        }
        .font(.system(size: 22, weight: .bold))
        .foregroundStyle(Color.white.opacity(0.96))
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .background(BlackGlassGuideButtonBackground())
    }

    private func guideView(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            googleGuideHero(channel: selectedChannel, size: size)
                .frame(maxWidth: .infinity, minHeight: 260, maxHeight: 260, alignment: .topLeading)

            VStack(alignment: .leading, spacing: 0) {
                googleGuideTimelineHeader
                    .padding(.bottom, 8)
                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: true) {
                        LazyVStack(spacing: 8) {
                            ForEach(renderedChannels) { channel in
                                googleGuideTimelineRow(channel: channel, rowWidth: size.width - 160)
                                    .id(channel.id)
                            }
                        }
                        .padding(.bottom, 130)
                    }
                    .frame(maxWidth: .infinity, maxHeight: size.height - 455, alignment: .topLeading)
                    .onChange(of: guideFocus) { value in
                        if let value {
                            withAnimation(.easeOut(duration: 0.16)) {
                                proxy.scrollTo(value, anchor: .center)
                            }
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: size.height - 120, alignment: .topLeading)
    }

    private func googleGuideHero(channel: LiveTVChannel, size: CGSize) -> some View {
        let currentProgram = liveModel.currentProgram(for: channel)
        let artURL = currentProgram?.imageURL ?? ""
        // v347: safe-area hero redesign.  No absolute left/right positioning.
        // The preview and info cards now live inside one responsive HStack with fixed
        // inner padding, so neither side can be clipped by the screen edge or guide scroll area.
        let heroHeight: CGFloat = 252

        return GeometryReader { heroGeo in
            let heroWidth = heroGeo.size.width
            // v347: compute the cards from the real safe content width.  v347 padded
            // a full-width HStack, which made the preview/info cards overflow and clip
            // on opposite screen edges.  Here the card widths plus the gap always fit
            // inside heroWidth - safe margins.
            let outerPad = max(72, min(112, heroWidth * 0.060))
            let gap: CGFloat = max(28, min(44, heroWidth * 0.024))
            let contentWidth = max(780, heroWidth - (outerPad * 2))
            let previewCardWidth = min(560, max(430, contentWidth * 0.43))
            let infoWidth = max(430, contentWidth - previewCardWidth - gap)
            let previewWidth = max(360, previewCardWidth - 28)

            HStack(alignment: .top, spacing: gap) {
                VStack(alignment: .leading, spacing: 10) {
                    livePreviewWindow(
                        channel: previewChannel,
                        program: liveModel.currentProgram(for: previewChannel) ?? currentProgram,
                        active: showGuide && !previewPlaybackSuppressed && !previewChannel.streamURL.isEmpty
                    )
                    .frame(width: previewWidth, height: 206)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                    // v361: keep muted preview video, remove the bottom "Live Preview" caption.
                }
                .padding(14)
                .frame(width: previewCardWidth, height: heroHeight, alignment: .topLeading)

                HStack(alignment: .center, spacing: 22) {
                    guideHeroChannelLogo(channel: channel)
                        .frame(width: 118, height: 118)
                        .layoutPriority(2)

                    VStack(alignment: .leading, spacing: 9) {
                        Text(currentProgram?.title ?? channel.now)
                            .font(.system(size: 37, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.58)
                        Text("\(currentProgram?.startText ?? "Now") - \((currentProgram?.endText ?? "").ifEmpty("Next"))  •  \(channel.category)")
                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.82))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                        HStack(spacing: 10) {
                            guideHeroMiniChannelIcon(channel: channel)
                                .frame(width: 42, height: 30)
                            Text("\(channel.number)  •  \(channel.source)  •  \(channel.name)")
                                .font(.system(size: 17, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white.opacity(0.70))
                                .lineLimit(1)
                                .minimumScaleFactor(0.70)
                        }
                        Text((currentProgram?.description ?? "").ifEmpty(channel.description))
                            .font(.system(size: 18, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.62))
                            .lineLimit(2)
                            .minimumScaleFactor(0.78)
                    }
                    .layoutPriority(1)

                    Spacer(minLength: 6)

                    guideHeroProgramArtwork(artURL: artURL, channel: channel)
                        .frame(width: min(140, max(112, infoWidth * 0.18)), height: 198)
                }
                .padding(.horizontal, 22)
                .frame(width: infoWidth, height: heroHeight, alignment: .leading)
                .background(guideHeroCardBackground(accent: channel.accent.opacity(0.22)))
                // v361: keep dynamic channel/program gradient tint but remove visible boxed border.
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .shadow(color: .black.opacity(0.25), radius: 18, x: 0, y: 10)
            }
            .frame(width: contentWidth, height: heroHeight, alignment: .topLeading)
            .padding(.horizontal, outerPad)
        }
        .frame(maxWidth: .infinity, minHeight: heroHeight, maxHeight: heroHeight, alignment: .topLeading)
    }

    private func guideHeroCardBackground(accent: Color) -> some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color.white.opacity(0.075), accent, Color.black.opacity(0.32)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var guideHeroCardBorder: some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .stroke(Color.white.opacity(0.16), lineWidth: 1.2)
    }

    private func guideHeroProgramArtwork(artURL: String, channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.black.opacity(0.20))
            if let url = URL(string: artURL), !artURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(6)
                    default: guideHeroLogoFallback(channel: channel)
                    }
                }
            } else {
                guideHeroLogoFallback(channel: channel)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.15), lineWidth: 1))
    }

    private func guideHeroLogoFallback(channel: LiveTVChannel) -> some View {
        Text(channel.logo)
            .font(.system(size: 31, weight: .black, design: .rounded))
            .foregroundStyle(.white.opacity(0.88))
            .lineLimit(1)
            .minimumScaleFactor(0.42)
            .padding(10)
    }

    private func guideHeroChannelLogo(channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18).fill(Color.black.opacity(0.24))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(18)
                    default: Text(channel.logo).font(.system(size: 46, weight: .black)).foregroundStyle(.white)
                    }
                }
            } else {
                Text(channel.logo).font(.system(size: 46, weight: .black)).foregroundStyle(.white)
            }
        }
    }

    private func guideHeroMiniChannelIcon(channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7).fill(Color.black.opacity(0.22))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(3)
                    default: Text(channel.logo).font(.system(size: 13, weight: .black)).foregroundStyle(.white.opacity(0.9))
                    }
                }
            } else {
                Text(channel.logo).font(.system(size: 13, weight: .black)).foregroundStyle(.white.opacity(0.9))
            }
        }
        .overlay(RoundedRectangle(cornerRadius: 7).stroke(Color.white.opacity(0.14), lineWidth: 1))
    }

    private func activePreviewCaption(channel: LiveTVChannel) -> String {
        if previewPlaybackSuppressed { return "Opening Live TV…" }
        if channel.streamURL.isEmpty { return "Live Preview Unavailable" }
        return "Live Preview • \(channel.number) • \(channel.name)"
    }

    private func livePreviewWindow(channel: LiveTVChannel, program: LiveProgram?, active: Bool) -> some View {
        ZStack(alignment: .bottomLeading) {
            Color.black
            if active, let streamURL = URL(string: channel.streamURL), !channel.streamURL.isEmpty {
                #if canImport(KSPlayer)
                KSPlayerVideoSurface(url: streamURL, shouldPlay: true, seekSerial: 0, seekSeconds: 0, reloadToken: 0, startTimeSeconds: 0, externalAudioURL: nil, externalAudioOffsetMS: 0, muteAudio: true)
                    .id("live-preview-ks-\(channel.streamURL)")
                    .allowsHitTesting(false)
                #else
                SilentVideoBackground(url: streamURL, isMuted: true)
                    .id("live-preview-avfallback-\(channel.streamURL)")
                    .allowsHitTesting(false)
                #endif
            } else if let url = URL(string: program?.imageURL ?? ""), !(program?.imageURL ?? "").isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFit().padding(10)
                    default:
                        Color.black
                    }
                }
            }
            // v348: no text/channel caption on the preview surface. Keep it a plain
            // blended video box so labels do not overlap or look like a second info row.
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private var googleGuideTimelineHeader: some View {
        HStack(spacing: 10) {
            Text(Date().formatted(.dateTime.weekday(.abbreviated).month().day()))
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: 350, alignment: .leading)
            ForEach(guideTimeSlots, id: \.self) { time in
                Text(time)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.white.opacity(time == guideTimeSlots.first ? 0.72 : 0.48))
                    .frame(width: 295, alignment: .leading)
            }
        }
        .frame(height: 42)
    }

    private func googleGuideTimelineRow(channel: LiveTVChannel, rowWidth: CGFloat) -> some View {
        let isFocused = guideFocus == channel.id
        let programs = Array(liveModel.programs(for: channel).prefix(10))
        let minProgramWidth: CGFloat = 170
        return HStack(spacing: 8) {
            guideChannelPill(channel: channel, isFocused: isFocused)
                .frame(width: 330, height: 82)

            ForEach(programs) { program in
                GoogleGuideProgramCell(program: program, width: max(minProgramWidth, program.width))
            }

            if programs.count < 10 {
                ForEach(0..<(10 - programs.count), id: \.self) { _ in
                    GuideEmptyProgramCell(width: 295)
                }
            }
        }
        .frame(width: rowWidth, alignment: .leading)
        .contentShape(Rectangle())
        .focusable(true)
        .focused($guideFocus, equals: channel.id)
        .modifier(TransparentTVFocusVisual())
        .onTapGesture {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onChange(of: guideFocus) { value in if let value { selectedChannelID = value } }
    }

    private func guideChannelPill(channel: LiveTVChannel, isFocused: Bool) -> some View {
        HStack(spacing: 18) {
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 28, weight: .black)) }
                }
                .frame(width: 96, height: 54)
            } else {
                Text(channel.logo).font(.system(size: 28, weight: .black)).lineLimit(1).frame(width: 96, alignment: .leading)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(channel.number).font(.system(size: 22, weight: .bold)).foregroundStyle(.white.opacity(0.76))
                Text(channel.name).font(.system(size: 18, weight: .medium)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(isFocused ? 0.38 : 0.30)))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.clear, lineWidth: 1))
    }

    private var googleGuideSideRail: some View {
        VStack(alignment: .leading, spacing: 20) {
            googleGuideSideRailHeader

            ForEach(categories, id: \.self) { category in
                googleGuideSideRailButton(category: category)
            }

            Spacer(minLength: 0)
        }
        .padding(.top, 8)
        .padding(.horizontal, 18)
        .background(googleGuideSideRailBackground)
        .overlay(googleGuideSideRailBorder)
    }

    private var googleGuideSideRailHeader: some View {
        Text("YOUR CHANNELS")
            .font(.system(size: 17, weight: .heavy))
            .tracking(1.6)
            .foregroundStyle(.white.opacity(0.48))
            .padding(.leading, 12)
    }

    private var googleGuideSideRailBackground: some View {
        RoundedRectangle(cornerRadius: 30).fill(Color.black.opacity(0.34))
    }

    private var googleGuideSideRailBorder: some View {
        RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.08), lineWidth: 1)
    }

    private func googleGuideSideRailButton(category: String) -> some View {
        let isSelected = category == selectedCategory
        return Button {
            selectGuideCategory(category)
        } label: {
            googleGuideSideRailButtonContent(category: category, isSelected: isSelected)
        }
        .buttonStyle(.plain)
        .focused($categoryFocus, equals: category)
    }

    private func googleGuideSideRailButtonContent(category: String, isSelected: Bool) -> some View {
        HStack(spacing: 18) {
            googleGuideSideRailIcon(category: category, isSelected: isSelected)
            googleGuideSideRailText(category: category, isSelected: isSelected)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .frame(height: 92)
        .background(googleGuideSideRailButtonBackground(isSelected: isSelected))
    }

    private func googleGuideSideRailIcon(category: String, isSelected: Bool) -> some View {
        ZStack {
            Circle().fill(isSelected ? Color.white.opacity(0.16) : Color.white.opacity(0.07))
            Image(systemName: iconForGuideCategory(category))
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(isSelected ? .black : .white.opacity(0.76))
        }
        .frame(width: 58, height: 58)
    }

    private func googleGuideSideRailText(category: String, isSelected: Bool) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(category == "All" ? "All Channels" : category)
                .font(.system(size: 29, weight: .semibold))
                .foregroundStyle(isSelected ? .black : .white.opacity(0.88))
            Text("\(channelCount(for: category)) channels")
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(isSelected ? .black.opacity(0.58) : .white.opacity(0.42))
        }
    }

    private func googleGuideSideRailButtonBackground(isSelected: Bool) -> some View {
        RoundedRectangle(cornerRadius: 25).fill(isSelected ? Color.white.opacity(0.92) : Color.white.opacity(0.04))
    }

    private func selectGuideCategory(_ category: String) {
        selectedCategory = category
        resetVirtualChannelWindow()
        if let first = visibleChannels.first {
            selectedChannelID = first.id
            resetVirtualChannelWindow(to: first.id)
            guideFocus = first.id
            tileFocus = first.id
        }
    }

    private func channelCount(for category: String) -> Int {
        if category == "All" { return liveModel.channels.count }
        if category == "HD" { return liveModel.channels.filter { $0.category == "HD" || Int($0.number) ?? 0 >= 6000 || $0.name.localizedCaseInsensitiveContains("HD") }.count }
        return liveModel.channels.filter { $0.category == category }.count
    }

    private func iconForGuideCategory(_ category: String) -> String {
        switch category.lowercased() {
        case "favorites": return "star.fill"
        case "movies": return "movieclapper.fill"
        case "sports": return "sportscourt.fill"
        case "news": return "newspaper.fill"
        case "kids": return "face.smiling.fill"
        case "hd": return "tv.fill"
        default: return "rectangle.grid.2x2.fill"
        }
    }

    private var guideSideRail: some View {
        VStack(spacing: 24) {
            VStack(spacing: 26) {
                Image(systemName: "heart")
                Image(systemName: "list.bullet")
                Image(systemName: "rectangle.grid.2x2")
                Image(systemName: "circle")
                Image(systemName: "book")
                Image(systemName: "magnifyingglass")
            }
            .font(.system(size: 30, weight: .semibold))
            .foregroundStyle(.white.opacity(0.56))
            .frame(maxWidth: .infinity)
            .padding(.top, 26)
            VStack(alignment: .trailing, spacing: 22) {
                ForEach(categories, id: \.self) { category in
                    Text(category == "All" ? "All Channels" : category == "HD" ? "HD Channels" : category)
                        .font(.system(size: 26, weight: category == selectedCategory ? .bold : .medium))
                        .foregroundStyle(category == selectedCategory ? .white : .white.opacity(0.56))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .onTapGesture { selectedCategory = category }
                }
            }
            Spacer()
        }
        .padding(.top, 68)
        .padding(.horizontal, 14)
        .background(Color.black.opacity(0.18))
    }

    private func guidePreview(channel: LiveTVChannel) -> some View {
        let currentProgram = liveModel.programs(for: channel).first
        let artURL = currentProgram?.imageURL ?? ""
        return HStack(alignment: .top, spacing: 34) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 22).fill(Color.black.opacity(0.58))
                if let url = URL(string: artURL), !artURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFit().padding(8)
                        default:
                            guideLogoCard(channel: channel)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                } else {
                    guideLogoCard(channel: channel)
                }
                LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .center, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                HStack(spacing: 10) {
                    if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                        AsyncImage(url: url) { phase in
                            switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 22, weight: .black)) }
                        }.frame(width: 70, height: 38)
                    } else {
                        Text(channel.logo).font(.system(size: 22, weight: .black)).frame(width: 64, alignment: .leading)
                    }
                    Text(channel.number).font(.system(size: 22, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(18)
            }
            .frame(width: 470, height: 246)
            .background(Color.black.opacity(0.46))
            .clipShape(RoundedRectangle(cornerRadius: 22))

            VStack(alignment: .leading, spacing: 12) {
                Text(channel.source.uppercased() + "  |  " + channel.logo)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white.opacity(0.58))
                Text(currentProgram?.title ?? channel.now)
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text((currentProgram?.startText ?? "Now") + ((currentProgram?.endText ?? "").isEmpty ? "" : " - \(currentProgram?.endText ?? "")") + "   " + channel.category)
                    .font(.system(size: 27, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.82))
                Text((currentProgram?.description ?? "").ifEmpty(channel.description))
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(2)
                HStack(spacing: 10) { guideBadge("LIVE"); guideBadge("HD"); guideBadge(channel.category) }
            }
            Spacer(minLength: 0)
        }
        .padding(.top, 8)
        .padding(.bottom, 6)
    }

    private func guideLogoCard(channel: LiveTVChannel) -> some View {
        ZStack {
            LinearGradient(colors: [Color.white.opacity(0.92), channel.accent.opacity(0.28)], startPoint: .topLeading, endPoint: .bottomTrailing)
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit().padding(34); default: Text(channel.logo).font(.system(size: 62, weight: .black, design: .rounded)).foregroundStyle(.black.opacity(0.78)).padding(26) }
                }
            } else {
                Text(channel.logo).font(.system(size: 62, weight: .black, design: .rounded)).minimumScaleFactor(0.5).foregroundStyle(.black.opacity(0.78)).padding(26)
            }
        }
    }

    private func guideBadge(_ text: String) -> some View {
        Text(text).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 8).background(RoundedRectangle(cornerRadius: 2).fill(Color.black.opacity(0.58)).overlay(RoundedRectangle(cornerRadius: 2).stroke(Color.white.opacity(0.16), lineWidth: 1)))
    }

    private var guideTimeSlots: [String] {
        let calendar = Calendar.current
        let now = Date()
        let minute = calendar.component(.minute, from: now)
        let flooredMinute = minute < 30 ? 0 : 30
        let base = calendar.date(bySettingHour: calendar.component(.hour, from: now), minute: flooredMinute, second: 0, of: now) ?? now
        return (0..<6).compactMap { offset in
            calendar.date(byAdding: .minute, value: offset * 30, to: base)?.formatted(date: .omitted, time: .shortened)
        }
    }

    private var timeHeader: some View {
        HStack(spacing: 10) {
            Text("").frame(width: 230)
            ForEach(guideTimeSlots, id: \.self) { time in
                Text(time).font(.system(size: 24, weight: .bold)).foregroundStyle(.white.opacity(0.48)).frame(width: 260, alignment: .leading)
            }
        }
    }

    private func guideRow(channel: LiveTVChannel, rowWidth: CGFloat) -> some View {
        let isFocused = guideFocus == channel.id
        let channelColumnWidth: CGFloat = 230
        let programCount = 6
        let programWidth = max(190, (rowWidth - channelColumnWidth - 54) / CGFloat(programCount))
        let programs = Array(liveModel.programs(for: channel).prefix(programCount))

        return HStack(spacing: 10) {
            HStack(spacing: 12) {
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFit()
                        default: Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1)
                        }
                    }
                    .frame(width: 86, height: 46)
                } else {
                    Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1).frame(width: 86, alignment: .leading)
                }
                Text(channel.number).font(.system(size: 25, weight: .bold)).foregroundStyle(.white.opacity(0.78))
            }
            .padding(.horizontal, 14)
            .frame(width: channelColumnWidth, height: 74, alignment: .leading)
            .background((isFocused ? Color.white.opacity(0.035) : LiveTVTheme.glassPanel))
            .clipShape(RoundedRectangle(cornerRadius: 4))

            ForEach(programs) { program in
                GuideProgramCell(program: program, width: programWidth)
            }

            if programs.count < programCount {
                ForEach(0..<(programCount - programs.count), id: \.self) { _ in
                    GuideEmptyProgramCell(width: 210)
                }
            }
        }
        .frame(width: rowWidth, alignment: .leading)
        .clipped()
        .contentShape(Rectangle())
        .focusable(true)
        .focused($guideFocus, equals: channel.id)
        .modifier(TransparentTVFocusVisual())
        .onTapGesture {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onChange(of: guideFocus) { value in if let value { selectedChannelID = value } }
    }



private struct BlackGlassGuideButtonBackground: View {
    var body: some View {
        Capsule(style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color.white.opacity(0.11), Color.white.opacity(0.045), Color.black.opacity(0.20)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(
                Capsule(style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.34), radius: 14, x: 0, y: 8)
    }
}

private struct GoogleGuideProgramCell: View {
    let program: LiveProgram
    let width: CGFloat

    var body: some View {
        HStack(spacing: 14) {
            if let url = URL(string: program.imageURL), !program.imageURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFill()
                    default: Color.white.opacity(0.05)
                    }
                }
                .frame(width: 58, height: 58)
                .clipShape(RoundedRectangle(cornerRadius: 7))
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(program.title)
                    .font(.system(size: 23, weight: program.isLive ? .bold : .semibold))
                    .lineLimit(1)
                    .foregroundStyle(.white.opacity(program.isLive ? 0.96 : 0.82))
                if !program.startText.isEmpty {
                    HStack(spacing: 8) {
                        Text(program.startText)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.46))
                        if program.isLive {
                            Text("LIVE")
                                .font(.system(size: 12, weight: .heavy))
                                .foregroundStyle(.red)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .overlay(RoundedRectangle(cornerRadius: 3).stroke(Color.red, lineWidth: 1))
                        }
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .frame(width: width, height: 86, alignment: .leading)
        .padding(.horizontal, 18)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(LinearGradient(colors: [Color.white.opacity(program.isLive ? 0.13 : 0.075), Color.white.opacity(program.isLive ? 0.07 : 0.035)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(program.isLive ? 0.12 : 0.055), lineWidth: 1))
        )
        .overlay {
            if program.isLive {
                GeometryReader { proxy in
                    let x = max(0, min(proxy.size.width - 3, proxy.size.width * program.liveProgress))
                    Rectangle()
                        .fill(Color.red.opacity(0.96))
                        .frame(width: 3, height: proxy.size.height - 10)
                        .position(x: x, y: proxy.size.height / 2)
                        .shadow(color: .red.opacity(0.72), radius: 5)
                }
                .allowsHitTesting(false)
            }
        }
    }
}

private struct GuideProgramCell: View {
    let program: LiveProgram
    let width: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(program.title)
                .font(.system(size: 22, weight: program.isLive ? .bold : .semibold))
                .lineLimit(1)
                .foregroundStyle(program.isLive ? .black : .white.opacity(0.84))
            if !program.startText.isEmpty {
                Text(program.startText)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(program.isLive ? .black.opacity(0.62) : .white.opacity(0.42))
            }
        }
        .frame(width: width, height: 74, alignment: .leading)
        .padding(.horizontal, 14)
        .background(program.isLive ? Color.white.opacity(0.82) : LiveTVTheme.glassPanel)
        .clipShape(RoundedRectangle(cornerRadius: 4))
        .overlay(alignment: .leading) {
            if program.isLive {
                VStack(spacing: 0) {
                    Circle().fill(Color.red).frame(width: 9, height: 9)
                    Rectangle().fill(Color.red.opacity(0.95)).frame(width: 3, height: 58)
                }
                .offset(x: 6)
            }
        }
    }
}

private struct GuideEmptyProgramCell: View {
    let width: CGFloat

    var body: some View {
        Text("No guide data")
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(.white.opacity(0.36))
            .frame(width: width, height: 86, alignment: .leading)
            .padding(.horizontal, 14)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.035)))
    }
}

    private func play(channel: LiveTVChannel) {
        guard let url = URL(string: channel.streamURL), !channel.streamURL.isEmpty else { liveModel.status = "No playable URL for \(channel.name). Configure Channels DVR/M3U/Xtream source."; return }
        // v347: stop/suppress the KS guide preview before routing into full KS Live TV playback.
        // This keeps the preview surface from continuing audio while the full channel opens.
        previewPlaybackSuppressed = true
        previewWarmupToken += 1
        previewChannelID = nil
        store.liveQuickPanelOpen = false
        let item = MediaItem(id: "live-\(channel.id)-\(channel.streamURL.hashValue)", title: channel.name, year: "Live", type: "live", catalog: channel.source, description: channel.description, genres: [channel.category, channel.source], rating: "", posterURL: channel.iconURL, landscapeURL: nil, logoURL: nil, previewURL: nil)
        store.startPlayback(item: item, url: url, alternates: [], subtitles: [], label: "Live TV direct stream: \(channel.name) • \(channel.source) • \(channel.number) • KS Live TV route")
    }

    static let sampleChannels: [LiveTVChannel] = [
        LiveTVChannel(id: 6003, logo: "CBS", number: "6003", name: "The Talk", category: "Drama", now: "The Young and the Restless", next: "The Bold and the Beautiful", description: "A live daytime lineup with drama, interviews, and entertainment news.", accent: .gray),
        LiveTVChannel(id: 6011, logo: "COMEDY", number: "6011", name: "South Park", category: "Favorites", now: "South Park", next: "Catfish: The TV Show", description: "South Park goes gluten free in this animated comedy block.", accent: .indigo),
        LiveTVChannel(id: 6013, logo: "MTV", number: "6013", name: "Catfish", category: "Favorites", now: "Catfish: The TV Show", next: "Catfish: The TV Show", description: "Online relationships, mysteries, and reveals.", accent: .gray),
        LiveTVChannel(id: 6017, logo: "CMT", number: "6017", name: "Mike & Molly", category: "Comedy", now: "Mike & Molly", next: "Mom", description: "Classic sitcom blocks and comfort comedy favorites.", accent: .mint),
        LiveTVChannel(id: 6019, logo: "BET", number: "6019", name: "black-ish", category: "Drama", now: "black-ish", next: "Tyler Perry's Meet the Browns", description: "Comedy, family stories, and drama favorites.", accent: .gray),
        LiveTVChannel(id: 6021, logo: "TV LAND", number: "6021", name: "Bonanza", category: "Drama", now: "Bonanza", next: "Gunsmoke", description: "Classic TV westerns and vintage drama blocks.", accent: .green),
        LiveTVChannel(id: 6022, logo: "PARAMOUNT", number: "6022", name: "Mom", category: "HD", now: "Mom", next: "Two and a Half Men", description: "HD sitcom favorites with back-to-back episodes.", accent: .blue),
        LiveTVChannel(id: 6031, logo: "ESPN", number: "6031", name: "SportsCenter", category: "Sports", now: "SportsCenter", next: "NFL Live", description: "Live sports news, highlights, and analysis.", accent: .red),
        LiveTVChannel(id: 6044, logo: "CNN", number: "6044", name: "CNN Newsroom", category: "News", now: "CNN Newsroom", next: "The Lead", description: "Breaking news and live national coverage.", accent: .red),
        LiveTVChannel(id: 6052, logo: "NICK", number: "6052", name: "SpongeBob", category: "Kids", now: "SpongeBob SquarePants", next: "The Loud House", description: "Animated favorites for kids and family viewing.", accent: .orange),
        LiveTVChannel(id: 6060, logo: "HBO", number: "6060", name: "Feature Movie", category: "Movies", now: "Feature Presentation", next: "Behind the Scenes", description: "Premium movie presentation with cinematic artwork.", accent: .cyan),
        LiveTVChannel(id: 6070, logo: "WEATHER", number: "6070", name: "Weather Headlines", category: "News", now: "Weather Headlines", next: "Local Forecast", description: "Regional weather headlines, storms, and local forecast updates.", accent: .teal)
    ]
}

private struct LiveTVGridTileContent: View {
    let channel: LiveTVChannel
    let isFocused: Bool
    let program: LiveProgram?
    let loadArtwork: Bool
    let gridLockedMode: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottomLeading) {
                LiveTVGridTileArtwork(channel: channel, program: program, loadArtwork: loadArtwork, gridLockedMode: gridLockedMode)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

                LiveTVGridTileFooter(channel: channel, isFocused: isFocused, program: program)
                    .frame(width: geo.size.width, height: 82)
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
            .background(Color.black.opacity(0.50))
            .clipShape(RoundedRectangle(cornerRadius: 7))
            .overlay(tileBorder)
            .scaleEffect(isFocused ? 1.035 : 1.0)
            .overlay(focusPopOverlay)
            .shadow(color: .black.opacity(isFocused ? 0.58 : 0.18), radius: isFocused ? 18 : 4, y: isFocused ? 10 : 2)
            .animation(.easeOut(duration: 0.16), value: isFocused)
        }
        .aspectRatio(gridLockedMode ? 1.22 : (16.0 / 9.0), contentMode: .fit)
        .frame(height: gridLockedMode ? 372 : 278)
    }

    private var tileBorder: some View {
        RoundedRectangle(cornerRadius: 7)
            .stroke(isFocused ? Color.white.opacity(0.96) : Color.clear, lineWidth: isFocused ? 3.5 : 1)
    }

    private var focusPopOverlay: some View {
        RoundedRectangle(cornerRadius: 7)
            .stroke(isFocused ? Color.cyan.opacity(0.38) : Color.clear, lineWidth: isFocused ? 8 : 0)
            .blur(radius: isFocused ? 1.5 : 0)
    }
}

private struct LiveTVGridTileArtwork: View {
    let channel: LiveTVChannel
    let program: LiveProgram?
    let loadArtwork: Bool
    let gridLockedMode: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .center) {
                programArtBackground(size: geo.size)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                LinearGradient(colors: [.black.opacity(0.02), .black.opacity(0.24)], startPoint: .center, endPoint: .bottom)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
    }

    @ViewBuilder
    private func programArtBackground(size: CGSize) -> some View {
        if loadArtwork, let art = program?.imageURL, !art.isEmpty, let url = URL(string: art) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    ZStack {
                        // v279: fill the landscape card with artwork color/texture while keeping the usable image visible.
                        // This avoids the old letterboxed fit look without restoring hard top/right logo badges.
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(width: size.width, height: size.height)
                            .clipped()
                            .blur(radius: 10)
                            .opacity(0.52)
                            .saturation(1.10)
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(width: size.width, height: size.height)
                            .clipped()
                    }
                default:
                    gradientBackground
                }
            }
        } else {
            gradientBackground
        }
    }

    private var gradientBackground: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(
                LinearGradient(
                    colors: [Color.black.opacity(0.86), channel.accent.opacity(0.20), Color.black.opacity(0.94)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }
}

private struct LiveTVGridTileFooter: View {
    let channel: LiveTVChannel
    let isFocused: Bool
    let program: LiveProgram?

    @ViewBuilder
    private var footerChannelIcon: some View {
        if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFit()
                default:
                    Text(channel.logo)
                        .font(.system(size: channel.logo.count > 6 ? 10 : 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.35)
                }
            }
        } else {
            Text(channel.logo)
                .font(.system(size: channel.logo.count > 6 ? 10 : 14, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.35)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                footerChannelIcon
                    .frame(width: 38, height: 24, alignment: .leading)
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
                Text(channel.number)
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
                    .lineLimit(1)
                    .minimumScaleFactor(0.45)
            }
            .frame(width: 52, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text(program?.title ?? channel.now)
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .tracking(-0.15)
                    .lineLimit(2)
                    .minimumScaleFactor(0.42)
                    .fixedSize(horizontal: false, vertical: true)
                    .shadow(color: .black.opacity(0.92), radius: 4, x: 0, y: 2)
                Text(channel.name)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(1)
                    .minimumScaleFactor(0.50)
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
            }
            Spacer()
        }
        .foregroundStyle(.white.opacity(0.96))
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
        .frame(height: 78, alignment: .bottomLeading)
    }
}


// MARK: - v221 Compile Recovery Shared UI Helpers
// Restores helper views referenced by the grid/overlay rebuild so the project compiles cleanly in GitHub Actions.

struct TransparentTVFocusVisual: ViewModifier {
    func body(content: Content) -> some View {
        content
            .buttonStyle(.plain)
            .focusEffectDisabled()
    }
}

struct SafeCardScrollMotion: ViewModifier {
    let isFocused: Bool
    var intensity: CGFloat = 1.0

    func body(content: Content) -> some View {
        content
            .scaleEffect(isFocused ? 1.0 + (0.065 * intensity) : 1.0)
            .shadow(color: isFocused ? Color.black.opacity(0.34) : Color.black.opacity(0.18), radius: isFocused ? 22 : 8, x: 0, y: isFocused ? 16 : 5)
            .zIndex(isFocused ? 10 : 0)
            .animation(.spring(response: 0.34, dampingFraction: 0.82), value: isFocused)
    }
}




struct FocusedPanelBackdropArtwork: View {
    let item: MediaItem

    private var url: String? {
        item.landscapeURL ?? item.posterURL
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.96)

                // v250: single-panel backdrop only. No duplicate fitted layer, no blurred edge layer,
                // and no split/dark-side composition. The selected card artwork owns the panel and
                // scales to cover the actual panel bounds.
                RemoteImageFit(url: url, mode: .fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .opacity(0.88)
                    .saturation(1.06)
                    .contrast(1.04)
                    .allowsHitTesting(false)

                LinearGradient(
                    colors: [Color.black.opacity(0.54), Color.black.opacity(0.18), Color.black.opacity(0.50)],
                    startPoint: .leading,
                    endPoint: .trailing
                )

                LinearGradient(
                    colors: [Color.black.opacity(0.18), Color.clear, Color.black.opacity(0.40)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
    }
}

struct DetailPoster: View {
    let item: MediaItem

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
            // v252: remove only the remaining media-popup poster title label.
            // Keep poster artwork, top themed logo/header, metadata, buttons, and More Like This unchanged.
            LinearGradient(colors: [.clear, .black.opacity(0.34)], startPoint: .top, endPoint: .bottom)
        }
    }
}

struct DetailBackdropArtwork: View {
    let item: MediaItem

    var body: some View {
        ZStack {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            Color.black.opacity(0.18)
        }
    }
}

struct ThemedPanelLogo: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.system(size: 50, weight: .black, design: .rounded))
            .kerning(0.8)
            .foregroundStyle(
                LinearGradient(
                    colors: [Color.white, Color.white.opacity(0.92), Color.cyan.opacity(0.80)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .shadow(color: .black.opacity(0.55), radius: 2, x: 0, y: 3)
            .shadow(color: .cyan.opacity(0.14), radius: 10, x: 0, y: 0)
            .overlay(alignment: .bottom) {
                LinearGradient(colors: [.clear, .white.opacity(0.18), .clear], startPoint: .leading, endPoint: .trailing)
                    .frame(height: 2)
                    .padding(.horizontal, 6)
                    .offset(y: 2)
            }
    }
}

struct CardThemedLogo: View {
    let item: MediaItem
    let focused: Bool

    private var fallbackTitle: String {
        let clean = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !clean.isEmpty { return clean.uppercased() }
        return item.catalog.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: .black.opacity(0.55), radius: 4, y: 3)
            } else {
                Text(fallbackTitle)
                    .font(.system(size: focused ? 30 : 22, weight: .black, design: .rounded))
                    .kerning(1.0)
                    .lineLimit(2)
                    .minimumScaleFactor(0.35)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [Color.white, Color.white.opacity(0.92), Color.cyan.opacity(0.74)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: .black.opacity(0.68), radius: 3, x: 0, y: 3)
                    .shadow(color: .cyan.opacity(focused ? 0.22 : 0.10), radius: focused ? 12 : 6)
            }
        }
    }
}

struct PopupArtworkLogoOnly: View {
    let item: MediaItem

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: .black.opacity(0.58), radius: 6, y: 3)
            } else {
                // v251: no generated text-logo fallback on media information popup.
                EmptyView()
            }
        }
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    var pulse: Bool = false
    @State private var glow = false

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: Color.white.opacity(glow ? 0.18 : 0.05), radius: glow ? 18 : 4)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: 58, weight: .black, design: .rounded))
                    .kerning(1.6)
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.35)
                    .shadow(color: Color.cyan.opacity(glow ? 0.20 : 0.07), radius: glow ? 18 : 5)
            }
        }
        .scaleEffect(pulse && glow ? 1.012 : 1.0)
        .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: glow)
        .onAppear {
            guard pulse else { return }
            glow = true
        }
    }
}
