"""Debrid Channels Phase 3 Alternate Audio bridge runtime.

The bridge keeps video from the user's selected high-quality source and takes one
verified English audio stream from a compatible Phase 2 discovery candidate. Video
is always stream-copied. Audio is stream-copied when HLS/timing compatibility allows,
and is encoded to AAC only when offset correction, drift correction, or HLS codec
compatibility requires it.

Production endpoint:
    POST /api/alternate-audio/bridge

The returned HLS URL is intentionally *not* handed to KSPlayer in Phase 3. The tvOS
client may prepare and inspect a short-lived bridge session, while Phase 4 owns the
session-safe player handoff.
"""

from __future__ import annotations

import json
import os
import re
import signal
import shutil
import subprocess
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional, Sequence, Tuple
from urllib.parse import urlparse

try:
    from alternate_audio_discovery_runtime import (
        AudioTrack,
        MediaProbe,
        ProbeConfig,
        probe_media,
        verify_identity,
    )
except ImportError:  # package-style backend integration
    from BackendAlternateAudioRuntime.alternate_audio_discovery_runtime import (
        AudioTrack,
        MediaProbe,
        ProbeConfig,
        probe_media,
        verify_identity,
    )

SCHEMA_VERSION = 1
SUPPORTED_CLASSIFICATIONS = {"Exact Match", "Offset Match", "Drift Correctable"}
HLS_AUDIO_COPY_CODECS = {"aac", "ac3", "eac3"}
SAFE_ASSET_PATTERN = re.compile(r"^(?:master\.m3u8|media\.m3u8|init\.mp4|segment_\d{6}\.m4s)$")


class BridgeError(RuntimeError):
    """A client-safe bridge preparation failure."""


@dataclass(frozen=True)
class BridgeConfig:
    root_directory: str = os.environ.get(
        "DEBRID_CHANNELS_ALT_AUDIO_ROOT", "/tmp/debridchannels-alternate-audio"
    )
    public_base_url: str = os.environ.get(
        "DEBRID_CHANNELS_ALT_AUDIO_PUBLIC_BASE", "/api/alternate-audio/bridge"
    )
    ffmpeg_binary: str = os.environ.get("FFMPEG_BINARY", "ffmpeg")
    ffprobe_binary: str = os.environ.get("FFPROBE_BINARY", "ffprobe")
    ttl_seconds: int = 30 * 60
    segment_seconds: int = 4
    maximum_offset_ms: int = 120_000
    maximum_asset_bytes: int = 64 * 1024 * 1024


@dataclass(frozen=True)
class BridgePlan:
    command: Tuple[str, ...]
    video_mode: str
    audio_mode: str
    audio_reason: str
    selected_stream_index: int
    selected_audio_codec: str


@dataclass(frozen=True)
class BridgeAsset:
    data: bytes
    content_type: str
    cache_control: str


def _safe_http_url(raw: str) -> bool:
    try:
        parsed = urlparse(raw)
    except Exception:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def _required_string(mapping: Mapping[str, Any], key: str, limit: int = 4096) -> str:
    value = str(mapping.get(key) or "").strip()
    if not value:
        raise BridgeError(f"{key} is required")
    return value[:limit]


def _identity(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    value = payload.get("identity")
    if not isinstance(value, Mapping):
        raise BridgeError("identity is required")
    media_id = str(value.get("mediaID") or value.get("media_id") or "").strip()
    title = str(value.get("title") or "").strip()
    media_type = str(value.get("mediaType") or value.get("media_type") or "").strip().lower()
    if not media_id or not title or media_type not in {"movie", "series", "show", "episode", "tv"}:
        raise BridgeError("identity must include mediaID, title, and movie/series mediaType")
    if media_type != "movie":
        season = value.get("seasonNumber", value.get("season_number"))
        episode = value.get("episodeNumber", value.get("episode_number"))
        if season is None or episode is None:
            raise BridgeError("television bridge sessions require exact seasonNumber and episodeNumber")
        try:
            if int(season) < 0 or int(episode) < 0:
                raise ValueError
        except (TypeError, ValueError):
            raise BridgeError("seasonNumber and episodeNumber must be non-negative integers")
    return value


def _source(payload: Mapping[str, Any], *keys: str) -> Mapping[str, Any]:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, Mapping):
            return value
    raise BridgeError(f"{keys[0]} is required")


def _selected_stream_index(source: Mapping[str, Any]) -> int:
    track = source.get("selectedAudioTrack") or source.get("selected_audio_track")
    if isinstance(track, Mapping):
        value = track.get("streamIndex", track.get("stream_index"))
    else:
        value = source.get("audioTrackIndex", source.get("audio_track_index"))
    try:
        index = int(value)
    except (TypeError, ValueError):
        raise BridgeError("alternateAudioSource.selectedAudioTrack.streamIndex is required")
    if index < 0:
        raise BridgeError("selected audio stream index must be non-negative")
    return index


def _classification(source: Mapping[str, Any]) -> str:
    value = str(source.get("classification") or source.get("matchClassification") or "").strip()
    if value not in SUPPORTED_CLASSIFICATIONS:
        raise BridgeError("only Exact Match, Offset Match, or Drift Correctable candidates can create a bridge")
    return value


def _offset_ms(payload: Mapping[str, Any], config: BridgeConfig) -> int:
    raw = payload.get("offsetMS", payload.get("offset_ms", 0))
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise BridgeError("offsetMS must be an integer")
    if abs(value) > config.maximum_offset_ms:
        raise BridgeError(f"offsetMS exceeds the {config.maximum_offset_ms}ms safety limit")
    return value


def _find_track(probe: MediaProbe, stream_index: int) -> AudioTrack:
    for track in probe.audio_tracks:
        if track.stream_index == stream_index:
            if track.language != "eng":
                raise BridgeError("the selected stream is not tagged as English")
            if track.is_commentary or track.is_descriptive:
                raise BridgeError("commentary or descriptive audio requires an explicit future opt-in")
            return track
    raise BridgeError("the selected English audio stream no longer exists on the candidate source")


def _filter_chain(stream_index: int, offset_ms: int, drift: bool) -> Optional[str]:
    filters = []
    if offset_ms > 0:
        filters.append(f"adelay={offset_ms}:all=1")
    elif offset_ms < 0:
        filters.extend([
            f"atrim=start={abs(offset_ms) / 1000.0:.3f}",
            "asetpts=PTS-STARTPTS",
        ])
    if drift:
        filters.append("aresample=async=1:min_hard_comp=0.100:first_pts=0")
    if not filters:
        return None
    return f"[1:{stream_index}]" + ",".join(filters) + "[aout]"


def build_bridge_plan(
    *,
    video_url: str,
    audio_url: str,
    stream_index: int,
    audio_codec: str,
    classification: str,
    offset_ms: int,
    session_directory: Path,
    config: BridgeConfig,
) -> BridgePlan:
    """Build the deterministic ffmpeg plan without launching it."""
    if not _safe_http_url(video_url) or not _safe_http_url(audio_url):
        raise BridgeError("bridge inputs must be resolved HTTP(S) media URLs")
    if video_url == audio_url:
        raise BridgeError("alternate audio must come from a different resolved source")
    if classification not in SUPPORTED_CLASSIFICATIONS:
        raise BridgeError("candidate classification is not bridge-compatible")

    normalized_codec = audio_codec.lower().strip()
    drift = classification == "Drift Correctable"
    requires_filter = offset_ms != 0 or drift
    codec_requires_encode = normalized_codec not in HLS_AUDIO_COPY_CODECS
    copy_audio = not requires_filter and not codec_requires_encode

    if requires_filter:
        reason = "offset correction" if offset_ms != 0 and not drift else (
            "drift correction" if offset_ms == 0 else "offset and drift correction"
        )
    elif codec_requires_encode:
        reason = f"{normalized_codec or 'unknown'} is not HLS fMP4 audio-copy compatible"
    else:
        reason = "compatible English audio stream copied"

    media_playlist = session_directory / "media.m3u8"
    segment_pattern = session_directory / "segment_%06d.m4s"
    command = [
        config.ffmpeg_binary,
        "-nostdin", "-hide_banner", "-loglevel", "warning", "-y",
        "-thread_queue_size", "2048", "-i", video_url,
        "-thread_queue_size", "2048", "-i", audio_url,
        "-map", "0:v:0",
    ]

    filter_chain = _filter_chain(stream_index, offset_ms, drift)
    if filter_chain:
        command += ["-filter_complex", filter_chain, "-map", "[aout]"]
    else:
        command += ["-map", f"1:{stream_index}"]

    command += [
        "-map_metadata", "0", "-map_chapters", "0",
        "-c:v", "copy",
    ]
    if copy_audio:
        command += ["-c:a", "copy"]
    else:
        command += ["-c:a", "aac", "-b:a", "384k"]

    command += [
        "-sn", "-dn", "-shortest",
        "-avoid_negative_ts", "make_zero",
        "-max_interleave_delta", "0",
        "-f", "hls",
        "-hls_time", str(max(2, config.segment_seconds)),
        "-hls_list_size", "0",
        "-hls_segment_type", "fmp4",
        "-hls_fmp4_init_filename", "init.mp4",
        "-hls_segment_filename", str(segment_pattern),
        "-hls_flags", "independent_segments+temp_file",
        str(media_playlist),
    ]

    return BridgePlan(
        command=tuple(command),
        video_mode="stream-copy",
        audio_mode="stream-copy" if copy_audio else "AAC re-encode",
        audio_reason=reason,
        selected_stream_index=stream_index,
        selected_audio_codec=normalized_codec or "unknown",
    )


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)


def _process_exists(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _terminate_process_group(pid: int, grace_seconds: float = 0.75) -> bool:
    if pid <= 1:
        return False
    signalled = False
    try:
        os.killpg(pid, signal.SIGTERM)
        signalled = True
    except OSError:
        try:
            os.kill(pid, signal.SIGTERM)
            signalled = True
        except OSError:
            return False
    deadline = time.time() + max(0.05, grace_seconds)
    while time.time() < deadline:
        if not _process_exists(pid):
            return signalled
        time.sleep(0.05)
    try:
        os.killpg(pid, signal.SIGKILL)
    except OSError:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    return signalled


def cancel_bridge_directory(directory: Path, reason: str = "cancelled") -> bool:
    metadata_path = directory / "session.json"
    metadata: Dict[str, Any] = {}
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except Exception:
        metadata = {}
    try:
        pid = int(metadata.get("ffmpegPID") or 0)
    except (TypeError, ValueError):
        pid = 0
    if pid > 1:
        _terminate_process_group(pid)
    metadata["status"] = "cancelled"
    metadata["cancelReason"] = str(reason)[:240]
    metadata["cancelledAtEpoch"] = time.time()
    try:
        _write_json(metadata_path, metadata)
    except Exception:
        pass
    shutil.rmtree(directory, ignore_errors=True)
    return True


def _launch_ffmpeg(command: Sequence[str], session_directory: Path) -> subprocess.Popen[bytes]:
    stderr_handle = (session_directory / "ffmpeg.stderr.log").open("ab", buffering=0)
    try:
        process = subprocess.Popen(
            list(command),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=stderr_handle,
            cwd=str(session_directory),
            # Stay in the Node-owned detached process group. If playback exits while
            # bridge preparation is between ffmpeg launch and session publication,
            # backend v668 can still terminate Python and ffmpeg atomically. Once the
            # response is published, the recorded ffmpeg PID remains available for
            # direct lifecycle cancellation.
            start_new_session=False,
        )
        stderr_handle.close()
        return process
    except Exception:
        stderr_handle.close()
        raise


def cleanup_expired_sessions(config: BridgeConfig = BridgeConfig(), now: Optional[float] = None) -> int:
    root = Path(config.root_directory)
    if not root.exists():
        return 0
    current = time.time() if now is None else now
    removed = 0
    for child in root.iterdir():
        if not child.is_dir():
            continue
        metadata_path = child / "session.json"
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            expires_at = float(metadata.get("expiresAtEpoch") or 0)
        except Exception:
            expires_at = child.stat().st_mtime + config.ttl_seconds
        if expires_at <= current:
            cancel_bridge_directory(child, "bridge session expired")
            removed += 1
    return removed


def prepare_alternate_audio_bridge(
    payload: Mapping[str, Any],
    config: BridgeConfig = BridgeConfig(),
    *,
    probe_fn: Callable[[str, str, ProbeConfig], MediaProbe] = probe_media,
    identity_fn: Callable[[Mapping[str, Any], str], Tuple[bool, str, int]] = verify_identity,
    launcher: Callable[[Sequence[str], Path], Any] = _launch_ffmpeg,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """Validate, plan, and launch one short-lived bridge session."""
    cleanup_expired_sessions(config, now=now)
    identity = _identity(payload)
    current = _source(payload, "currentSource", "current_source")
    alternate = _source(payload, "alternateAudioSource", "alternate_audio_source")
    video_url = _required_string(current, "url")
    audio_url = _required_string(alternate, "url")
    if not _safe_http_url(video_url) or not _safe_http_url(audio_url):
        raise BridgeError("only backend-resolved HTTP(S) source URLs are accepted")

    classification = _classification(alternate)
    stream_index = _selected_stream_index(alternate)
    offset_ms = _offset_ms(payload, config)
    current_filename = str(current.get("filename") or identity.get("title") or "Current source")[:512]
    alternate_filename = str(alternate.get("filename") or "Alternate source")[:512]

    identity_ok, identity_reason, _ = identity_fn(identity, alternate_filename)
    if not identity_ok:
        raise BridgeError(f"alternate source ownership failed: {identity_reason}")

    probe_config = ProbeConfig(
        ffprobe_binary=config.ffprobe_binary,
        ffmpeg_binary=config.ffmpeg_binary,
    )
    current_probe = probe_fn(video_url, current_filename, probe_config)
    alternate_probe = probe_fn(audio_url, alternate_filename, probe_config)
    if not current_probe.video_codec:
        raise BridgeError("the selected high-quality source has no usable video stream")
    track = _find_track(alternate_probe, stream_index)

    if current_probe.duration_seconds and alternate_probe.duration_seconds:
        duration_delta = abs(current_probe.duration_seconds - alternate_probe.duration_seconds)
        if duration_delta > 45:
            raise BridgeError("candidate duration changed and is no longer bridge-compatible")

    bridge_uuid = str(uuid.uuid4())
    root = Path(config.root_directory)
    root.mkdir(parents=True, exist_ok=True)
    session_directory = root / bridge_uuid
    session_directory.mkdir(mode=0o700)
    created_epoch = time.time() if now is None else now
    expires_epoch = created_epoch + max(60, config.ttl_seconds)

    try:
        plan = build_bridge_plan(
            video_url=video_url,
            audio_url=audio_url,
            stream_index=stream_index,
            audio_codec=track.codec,
            classification=classification,
            offset_ms=offset_ms,
            session_directory=session_directory,
            config=config,
        )
        # The master playlist exists immediately. KSPlayer handoff remains Phase 4,
        # but the URL is stable while ffmpeg fills media.m3u8 and fMP4 segments.
        (session_directory / "master.m3u8").write_text(
            "#EXTM3U\n#EXT-X-VERSION:7\n"
            "#EXT-X-STREAM-INF:BANDWIDTH=16000000\nmedia.m3u8\n",
            encoding="utf-8",
        )
        metadata = {
            "schemaVersion": SCHEMA_VERSION,
            "bridgeUUID": bridge_uuid,
            "status": "preparing",
            "createdAtEpoch": created_epoch,
            "expiresAtEpoch": expires_epoch,
            "mediaID": str(identity.get("mediaID") or identity.get("media_id") or ""),
            "mediaType": str(identity.get("mediaType") or identity.get("media_type") or ""),
            "seasonNumber": identity.get("seasonNumber", identity.get("season_number")),
            "episodeNumber": identity.get("episodeNumber", identity.get("episode_number")),
            "classification": classification,
            "offsetMS": offset_ms,
            "videoMode": plan.video_mode,
            "audioMode": plan.audio_mode,
            "audioReason": plan.audio_reason,
            "selectedStreamIndex": stream_index,
            "selectedAudioCodec": track.codec,
            "originalSourceURL": video_url,
            "alternateAudioSourceURL": audio_url,
            "playbackPresentationID": str(payload.get("playbackPresentationID") or payload.get("playback_presentation_id") or ""),
            "requestUUID": str(payload.get("requestUUID") or payload.get("request_uuid") or ""),
        }
        _write_json(session_directory / "session.json", metadata)
        process = launcher(plan.command, session_directory)
        pid = getattr(process, "pid", None)
        metadata["ffmpegPID"] = int(pid) if isinstance(pid, int) else None
        _write_json(session_directory / "session.json", metadata)
    except Exception:
        shutil.rmtree(session_directory, ignore_errors=True)
        raise

    public_base = config.public_base_url.rstrip("/")
    hls_url = f"{public_base}/{bridge_uuid}/master.m3u8"
    return {
        "schemaVersion": SCHEMA_VERSION,
        "status": "preparing",
        "bridgeUUID": bridge_uuid,
        "hlsURL": hls_url,
        "expiresAt": datetime.fromtimestamp(expires_epoch, tz=timezone.utc).isoformat(),
        "expiresAtEpoch": expires_epoch,
        "originalSourceURL": video_url,
        "originalSourceAvailable": True,
        "classification": classification,
        "offsetMS": offset_ms,
        "videoMode": plan.video_mode,
        "audioMode": plan.audio_mode,
        "audioReason": plan.audio_reason,
        "selectedStreamIndex": stream_index,
        "selectedAudioCodec": track.codec,
        "phase4HandoffRequired": True,
    }


def bridge_status(bridge_uuid: str, config: BridgeConfig = BridgeConfig()) -> Dict[str, Any]:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", bridge_uuid):
        raise BridgeError("invalid bridge UUID")
    directory = Path(config.root_directory) / bridge_uuid
    metadata_path = directory / "session.json"
    if not metadata_path.exists():
        raise BridgeError("bridge session not found")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    now = time.time()
    if float(metadata.get("expiresAtEpoch") or 0) <= now:
        cancel_bridge_directory(directory, "bridge session expired")
        raise BridgeError("bridge session expired")
    if (directory / "media.m3u8").exists():
        status = "ready"
    elif (directory / "ffmpeg.stderr.log").exists() and (directory / "ffmpeg.stderr.log").stat().st_size > 0:
        status = "preparing"
    else:
        status = "preparing"
    return {
        "schemaVersion": SCHEMA_VERSION,
        "bridgeUUID": bridge_uuid,
        "status": status,
        "expiresAtEpoch": metadata.get("expiresAtEpoch"),
        "videoMode": metadata.get("videoMode"),
        "audioMode": metadata.get("audioMode"),
        "audioReason": metadata.get("audioReason"),
        "selectedStreamIndex": metadata.get("selectedStreamIndex"),
    }


def read_bridge_asset(
    bridge_uuid: str,
    asset_name: str,
    config: BridgeConfig = BridgeConfig(),
) -> BridgeAsset:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", bridge_uuid):
        raise BridgeError("invalid bridge UUID")
    if not SAFE_ASSET_PATTERN.fullmatch(asset_name):
        raise BridgeError("invalid bridge asset")
    directory = Path(config.root_directory) / bridge_uuid
    metadata_path = directory / "session.json"
    if not metadata_path.exists():
        raise BridgeError("bridge session not found")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if float(metadata.get("expiresAtEpoch") or 0) <= time.time():
        cancel_bridge_directory(directory, "bridge session expired")
        raise BridgeError("bridge session expired")
    path = directory / asset_name
    if not path.exists() or not path.is_file():
        raise BridgeError("bridge asset is still preparing")
    size = path.stat().st_size
    if size > config.maximum_asset_bytes:
        raise BridgeError("bridge asset exceeds the safe response limit")
    if asset_name.endswith(".m3u8"):
        content_type = "application/vnd.apple.mpegurl"
        cache_control = "no-store"
    elif asset_name.endswith(".mp4") or asset_name.endswith(".m4s"):
        content_type = "video/mp4"
        cache_control = "private, max-age=60"
    else:
        content_type = "application/octet-stream"
        cache_control = "no-store"
    return BridgeAsset(path.read_bytes(), content_type, cache_control)


def create_fastapi_router(config: BridgeConfig = BridgeConfig()):
    """Optional registration helper; importing this module does not require FastAPI."""
    try:
        from fastapi import APIRouter, HTTPException
        from fastapi.responses import Response
    except ImportError as exc:  # pragma: no cover - deployment integration guard
        raise RuntimeError("FastAPI is required to create the bridge router") from exc

    router = APIRouter()

    @router.post("/api/alternate-audio/bridge")
    async def create_bridge_endpoint(body: Dict[str, Any]):
        try:
            return prepare_alternate_audio_bridge(body, config)
        except BridgeError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @router.get("/api/alternate-audio/bridge/{bridge_uuid}/status")
    async def bridge_status_endpoint(bridge_uuid: str):
        try:
            return bridge_status(bridge_uuid, config)
        except BridgeError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.get("/api/alternate-audio/bridge/{bridge_uuid}/{asset_name}")
    async def bridge_asset_endpoint(bridge_uuid: str, asset_name: str):
        try:
            asset = read_bridge_asset(bridge_uuid, asset_name, config)
            return Response(
                content=asset.data,
                media_type=asset.content_type,
                headers={"Cache-Control": asset.cache_control},
            )
        except BridgeError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    return router
