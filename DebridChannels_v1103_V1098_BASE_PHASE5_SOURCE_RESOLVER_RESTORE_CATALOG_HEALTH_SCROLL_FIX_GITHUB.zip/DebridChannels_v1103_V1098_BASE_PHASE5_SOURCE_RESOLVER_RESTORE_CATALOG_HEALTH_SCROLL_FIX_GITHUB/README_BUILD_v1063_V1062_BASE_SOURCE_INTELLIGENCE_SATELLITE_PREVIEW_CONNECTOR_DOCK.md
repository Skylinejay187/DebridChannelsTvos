# Debrid Channels tvOS v1063

Release: v1063 (1.0.591 / 591)  
Base: v1062

## Implemented

### Source Intelligence satellite panel
- Source Intelligence no longer presents as a separate full-screen layer.
- The existing source resolver, provider filtering, ranking, cached/direct indicators, five-link paging, DPAD routing, selection, playback handoff, and return-from-playback state remain unchanged.
- Results are rendered inside a compact attached satellite panel at approximately 75% transparency.
- A short connector leaves the Find Links control and remains visible while the panel is open.
- Up/Down continues through links; Left/Right continues through the existing result pages; provider chips retain their current behavior.
- Back closes only Source Intelligence and restores focus to Find Links while the media-information popup stays open.

### Focused-card preview continuity
- The exact originating focused-card preview remains active beneath its connected media-information popup.
- Opening the popup no longer destroys and recreates an already-playing preview session.
- Preview eligibility is pinned to catalog origin plus canonical media identity and the originating row/index.
- Search-owned details, identity mismatches, VOD playback, trailers, Live TV playback, and memory-pressure teardown still stop the preview.
- No neighboring card or stale previous title can become the active preview behind the popup.

### Connector and popup spine continuity
- The catalog connector now docks into the exact bottom coordinate of the popup's illuminated left-side spine.
- The popup spine and connector share the same cyan-to-white-to-orange material direction, thickness language, glow, and endpoint.
- The Search connector docks into the top of the same spine.
- The existing fast draw, seven-second hold, and reverse retraction behavior remains unchanged.

## Preserved
- v1062 exact episode cast resolution and Search-owned detail presentation.
- v1061 stale hero/logo handoff protection and dissolving popup glass.
- v1060 long-row pagination and force catalog loading.
- Built-in trailer playback, advisory, VOD handoff, episode alerts, Live TV, catalog, focus, and playback systems.

## Validation completed in this package
- All Swift source files passed `swiftc -frontend -parse`.
- App and Top Shelf plists parse and report 1.0.591 (591).
- `project.yml` parses and reports 1.0.591 (591) for both targets.
- Backend trailer helper passed Python bytecode compilation.
- Static release checks confirm satellite Source Intelligence presentation, existing paging logic, focused-preview identity guards, and exact connector/spine docking geometry.
- Final ZIP extraction and file-hash comparison are recorded in `VALIDATION_RESULTS_v1063.json`.

GitHub Actions remains the authoritative Xcode/tvOS SDK type-check, link, archive, and signing validation.
