# Debrid Channels v1042 — Full Profile Backup/Restore Regression Fix

Base: v1041 Phase 11
Version: 1.0.570
Build: 570

## Root cause

Phase 8 introduced a security allowlist that intentionally excluded credentials, private Live TV source URLs, Xtream account data, metadata-provider API keys, debrid keys, and credential-bearing add-on manifests. Phase 11 improved the backup transport but retained that filtering policy. The restore code still contained assignments for many of those fields, which made the implementation look complete while the uploaded profile did not contain the values.

## Corrected behavior

v1042 restores full-profile backup semantics. A newly created or refreshed backup now includes the operational configuration required to rebuild Debrid Channels on another Apple TV:

- Channels DVR address
- HDHomeRun address and manual guide URL
- All multiline M3U and XMLTV source entries
- Xtream server, username, password, and multi-account data
- Sports-only M3U/source organization and channel selections
- User add-on manifest URLs, including configured token-bearing manifests
- TMDB, OMDb, Fanart.tv, and TVDB credentials
- Real-Debrid, TorBox, Torrentio Real-Debrid, and Torrentio TorBox credentials
- Source Intelligence result limit and built-in add-on filters
- Catalog visibility/order and personal catalog manifests
- Favorites, followed shows, alerts, playback defaults, and presentation settings

The hidden official All-in-One catalog endpoint, membership/entitlement state, owner state, diagnostics, migrations, and backup bookkeeping are still excluded.

## Backup verification

After upload, the app immediately downloads the profile again and compares all 79 exported settings value-for-value. The UI reports the number of verified settings or the number of missing/changed settings. It no longer treats any nonempty response as a successful full verification.

## Compatibility

- v1042 can restore older v1 and v2 profile envelopes.
- Old v1041 backup codes cannot contain values that v1041 never uploaded. Install v1042 and create a new backup or refresh the existing code before testing on a clean device.
- The backup code now protects private source URLs and credentials and should be treated like a password.

## Preserved

No VOD overlay, KSPlayer, PlaybackKit, Live TV parsing/playback, catalog-row recovery, cast hydration, Search, trailer, preview, Source Intelligence ranking, or focus implementation was changed.

GitHub Actions remains the authoritative Apple SDK compile/archive gate.
