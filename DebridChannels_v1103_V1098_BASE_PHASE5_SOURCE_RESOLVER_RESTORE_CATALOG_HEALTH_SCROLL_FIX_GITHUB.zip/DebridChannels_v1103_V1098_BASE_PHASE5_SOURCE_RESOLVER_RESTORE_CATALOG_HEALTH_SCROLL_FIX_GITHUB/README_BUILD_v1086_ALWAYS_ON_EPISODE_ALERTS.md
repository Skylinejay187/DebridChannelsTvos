# Debrid Channels v1086 — Always-On Episode Alerts During VOD

Base: v1085 performance-isolation build.
Marketing version: 1.0.614
Build: 614

## Correction

Episode-alert heartbeat and network scans remain active whenever the app scene is active, including during VOD playback. VOD no longer stops or postpones the alert scheduler. Alerts discovered during playback remain eligible for immediate root-overlay presentation.

## Performance protection retained

- Scheduler task runs at utility priority.
- Scanner yields cooperatively between followed shows.
- Catalog status strings are not published during VOD, avoiding unnecessary catalog UI invalidation.
- Membership, bootstrap, entitlement, sports, catalog watchdog, artwork, metadata, and other unrelated work remain suspended or isolated during VOD as established by v1085.
- The working v1084 trailer path and all other v1085 optimizations remain unchanged.

## Platform boundary

This guarantees continuous checking while the tvOS app process is active, including playback. tvOS may suspend an app after it is backgrounded or terminated; server push would be required for truly continuous checks while the app is not running.
