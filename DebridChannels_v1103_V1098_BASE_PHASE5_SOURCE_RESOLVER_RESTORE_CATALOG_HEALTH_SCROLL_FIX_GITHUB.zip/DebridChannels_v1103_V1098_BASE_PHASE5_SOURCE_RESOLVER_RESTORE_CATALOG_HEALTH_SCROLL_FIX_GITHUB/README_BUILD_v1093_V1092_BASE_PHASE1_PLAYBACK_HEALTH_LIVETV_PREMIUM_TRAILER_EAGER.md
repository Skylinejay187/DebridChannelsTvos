# Debrid Channels v1093 — Phase 1

**Base:** v1092 Phase 0 only  
**Marketing version:** 1.0.621  
**Build:** 621

## Phase 1 contents

### Playback Health
A hidden VOD diagnostics page is available from the VOD overlay Settings panel. It captures a point-in-time snapshot only when opened or manually refreshed, avoiding a continuously updating diagnostics model in the full overlay.

The snapshot reports the session UUID, presentation/surface generation, provider and filename, video/audio codecs, resolution, HDR/Dolby Vision hint, frame rate, hardware-decoder state, buffer duration, dropped frames/stalls, A/V clock state, active audio/subtitle selections, first-frame state, source-handoff state, Alternate Audio state, and trailer-resolver state.

### Premium Live TV Quick Guide
- Removed the blue guide shadow/haze.
- Uses a neutral transparent black gradient.
- Increased selected and neighboring card sizes.
- Added channel number/name, program title, source, start/end time, description, and next-program information.
- Preserves existing horizontal guide navigation and channel-selection behavior.

### Dedicated Live TV playback overlay
Live TV no longer uses the VOD chrome presentation. The new restrained Live TV overlay includes current program artwork with channel-logo fallback, program title, description, channel metadata, current program times, progress, next-program information, current time, and subtle Guide/Play/Audio/Subtitles/Settings/Close chips.

### v1073 eager trailer restoration
The exact v1073 CatalogStore trailer resolver block and exact v1073 backend trailer runtime were restored into the v1092-based Phase 1 project. This returns to the earlier eager-start behavior while the trailer stream is still filling. The previously known mid-trailer audio cutoff is intentionally accepted for now and remains a later isolated fix.

## Protected systems
KSPlayer and the Tapframe KSPNUVIO fork are unchanged. Phase 0 stable protections remain unchanged. No Movie Mode code was added. No project source was rebuilt from v1073.

## Validation boundary
Swift syntax parsing, Python compilation, plist parsing, project-version validation, enum-switch coverage, donor equality, protected-file equality, baseline hash comparison, ZIP extraction, and package hash verification are performed locally. GitHub Actions remains the authoritative Xcode/tvOS compilation test, followed by physical Apple TV testing.
