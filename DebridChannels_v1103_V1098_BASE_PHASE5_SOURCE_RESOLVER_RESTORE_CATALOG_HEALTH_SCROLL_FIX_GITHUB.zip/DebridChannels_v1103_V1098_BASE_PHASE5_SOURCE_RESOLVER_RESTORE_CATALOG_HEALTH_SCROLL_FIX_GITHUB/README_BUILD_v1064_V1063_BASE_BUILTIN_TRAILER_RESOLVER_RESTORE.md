# Debrid Channels tvOS v1064

Release: v1064 (1.0.592 / 592)  
Base: v1063

## Scope

This release restores the built-in trailer resolver without restoring the external YouTube action.

## Correct separation

- The removed **YouTube** chip/app launcher remains removed.
- The visible **Trailer** action still opens only the Debrid Channels in-app KSPlayer trailer popup.
- The backend may continue using YouTube invisibly through yt-dlp to locate/extract trailer media.
- Raw YouTube watch, shorts, and youtu.be pages are still rejected by the app; only direct media or a finalized backend remux may reach KSPlayer.

## Trailer loading repair

v1059 introduced an app-side AVURLAsset track/duration gate. Signed extractor URLs can refuse or under-report AVFoundation preflight even though KSPlayer/FFmpeg can play them. That gate could reject every valid trailer before the popup opened.

v1064:

1. Removes AVURLAsset as a blocking trailer admission test.
2. Accepts proven direct muxed media returned under `playbackUrl`, `url`, `streamUrl`, or `trailerUrl`.
3. Keeps raw split video/audio responses blocked whenever the backend reports remux pending/required.
4. Keeps the remux-cache file-size settling guard before KSPlayer opens a backend-generated MP4.
5. Simplifies resolver query compatibility while still requesting complete muxed audio.
6. Restores cache/poll compatibility for older backend response shapes.
7. Invalidates the broken v1059 app trailer cache namespace.
8. Updates the included backend helper so already-muxed progressive yt-dlp formats are immediately playable/cacheable, while split formats still require a finalized duration-verified remux.

## Preserved

- v1063 Source Intelligence satellite panel and existing source scrolling/selection logic
- focused-card preview beneath the media popup
- connector docking to the popup spine
- v1062 exact episode cast and search-origin presentation
- external YouTube button/chip/launcher removal
- full-audio remux policy (`apad` to video duration) for split streams
- VOD, Live TV, catalogs, search, favorites, alerts, and Top Shelf

## Validation boundary

- all Swift source files pass `swiftc -parse` (one pre-existing indentation warning remains in PlaybackKit)
- backend helper passes Python bytecode compilation
- synthetic backend tests verify muxed progressive acceptance, unresolved split rejection, and duration verification for remux-cache files
- app and Top Shelf plists parse and match 1.0.592 (592)
- `project.yml` parses as YAML and matches the same version/build
- release ZIP is round-trip extracted and hash compared

GitHub Actions/Xcode remains the authoritative tvOS compile/archive gate. Apple TV testing and the active backend resolver are required to confirm real trailer extraction and playback.
