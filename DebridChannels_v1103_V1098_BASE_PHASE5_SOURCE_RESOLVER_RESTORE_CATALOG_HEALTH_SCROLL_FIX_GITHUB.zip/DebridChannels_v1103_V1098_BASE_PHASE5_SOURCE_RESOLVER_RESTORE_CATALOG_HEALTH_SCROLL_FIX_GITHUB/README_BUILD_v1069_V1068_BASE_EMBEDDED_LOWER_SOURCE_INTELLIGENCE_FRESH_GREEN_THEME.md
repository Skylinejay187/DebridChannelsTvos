# Debrid Channels v1069 — Embedded Lower Source Intelligence

Base: v1068
Version: 1.0.597 (597)

## Scope
- Source Intelligence remains inside the existing media-information popup.
- It occupies the lower section directly beneath Play / Trailer / Find Links.
- The existing popup size and bottom glass dissolve are preserved; the new Source Intelligence glass also fades before the poster rail.
- New emerald/mint/graphite visual theme. Green is reserved for the best/cached links.
- Top Recommended Link remains prominent.
- Provider filtering, ranking, five-link paging, Up/Down navigation, Left/Right paging, resolver state, and playback handoff remain unchanged.
- Selecting a link opens a compact centered details/confirmation card. Play Source uses the existing source launch path; Back returns to the exact link.
- No Source Intelligence connector line and no separate full-screen Source Intelligence page.

## Validation
- Swift syntax parse for all source files.
- project.yml and both Info.plist version checks.
- ZIP extraction and SHA-256 round-trip verification.
