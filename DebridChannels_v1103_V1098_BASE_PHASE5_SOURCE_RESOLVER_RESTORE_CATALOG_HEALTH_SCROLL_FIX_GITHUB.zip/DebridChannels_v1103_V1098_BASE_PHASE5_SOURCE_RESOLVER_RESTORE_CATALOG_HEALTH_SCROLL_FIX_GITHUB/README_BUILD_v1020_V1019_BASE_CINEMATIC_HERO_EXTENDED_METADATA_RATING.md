# Debrid Channels v1020 — Cinematic Hero Extended Metadata + Themed Rating

Base: `DebridChannels_v1019_V1018_BASE_CINEMATIC_HERO_TYPOGRAPHY_CLEANUP_GITHUB.zip`

Version: `1.0.548`
Build: `548`

## Scope

This build keeps the clean v1019 hero typography and adds the strongest metadata ideas from the supplied Apple TV-style references without returning to a large metadata pill or changing the focused-card presentation.

### Extended hero metadata

The large artwork-theme hero can now show:

- Full release date when TMDB provides it, with year fallback before metadata hydration.
- Runtime or episode runtime.
- Movie / TV Series type.
- Up to two genres.
- Season count for TV series.
- Movie budget when TMDB provides a non-zero value.
- US certification when available, with another available region as fallback.
- A compact theme-matched star score only when the catalog contains a valid numeric 0–10 rating.

The main metadata line remains unboxed and editorial. Certification is a restrained outline tag, while the optional rating is the only filled accent element. No rating is fabricated and no placeholder badge appears when the source has no valid score.

### Synopsis and logo

- The complete untruncated movie/show description remains beneath the metadata.
- The large themed logo remains in its v1019 position.
- The focused-card logo, rating, preview hide/restore behavior, and card artwork remain unchanged.

### Lightweight metadata behavior

- Release date, budget, and certification are fetched through the existing single TMDB detail request by using `append_to_response`.
- No extra request is added after the existing detail lookup.
- Existing 650 ms focus-settle delay, cancellation, six-hour memory cache, and playback suspension behavior remain intact.

## Playback and feature preservation

No changes were made to:

- Live TV first-frame/loading-screen repair from v1016
- The current Live TV loading-screen design
- PlaybackKit, KSPlayer, FFmpeg, VideoToolbox, cadence, clock, audio, or subtitles
- VOD decoded-frame queues (24 / 24 / 16)
- Trailer playback or focused-card preview playback
- Preview disk caching or auxiliary-player handoff
- CatalogStore, Phase 4A customization, Phase 4B Search, Favorites, Source Intelligence, guide, or VOD overlay

## Changed files

1. `Sources/CatalogHeroMetadataCache.swift`
2. `Sources/DebridChannelsTVOSApp.swift`
3. `Sources/Info.plist`
4. `README_BUILD_v1020_V1019_BASE_CINEMATIC_HERO_EXTENDED_METADATA_RATING.md`
5. `AUDIT_v1020_CHANGED_FILES.txt`

## Validation

- All Swift source files passed Swift frontend syntax parsing.
- `CatalogHeroMetadataCache.swift` passed standalone Swift type checking.
- `Sources/Info.plist` passed plist validation.
- `project.yml` passed YAML parsing.
- Static assertions confirmed the new release-date, certification, budget, and optional rating paths.
- Playback, resolver, preview, Search, Live TV, and queue files remain byte-for-byte identical to v1019.
- The final ZIP passed compressed-data integrity and extraction round-trip comparison.

GitHub Actions remains the authoritative full tvOS/iOS SDK compilation environment.
