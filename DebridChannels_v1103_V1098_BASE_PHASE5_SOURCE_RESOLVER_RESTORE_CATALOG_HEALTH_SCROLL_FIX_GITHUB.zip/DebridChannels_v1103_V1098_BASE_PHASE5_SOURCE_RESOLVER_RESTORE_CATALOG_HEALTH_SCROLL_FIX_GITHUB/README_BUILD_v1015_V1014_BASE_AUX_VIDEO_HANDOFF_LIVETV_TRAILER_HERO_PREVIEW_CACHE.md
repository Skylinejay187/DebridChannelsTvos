# Debrid Channels tvOS/iOS v1015

Base: `DebridChannels_v1014_V1013_BASE_LIVETV_V999_RESTORE_PREVIEW_RELEASE_HERO_DESCRIPTION_GITHUB.zip`

Version: `1.0.543`
Build: `543`

## Purpose

Fix the shared decoder/render-resource regression seen after focused-card previews were added:

- Live TV played audio but did not present video.
- Normal in-app trailers became choppy even though their resolver and popup code had not changed.
- Focused-card previews repeatedly resolved/downloaded the same media.
- Artwork hero information needed a cleaner visual hierarchy.

## Confirmed comparison

- `TrailerServiceManager.swift` is byte-for-byte identical to v999.
- The `TrailerPopup` implementation is unchanged from v999 except for the new pre-playback auxiliary handoff call at the two action entry points.
- `PlaybackKitKSPlayerSurface.swift` is byte-for-byte identical to v1014.
- Live TV therefore keeps the restored v999 KSPlayer constructor-autoplay route and the existing upstream live decoded-frame queue.
- VOD decoded-frame queues remain 24 / 24 / 16.

## Auxiliary video handoff

Added `AuxiliaryVideoPlaybackCoordinator`:

- Focused-card AVPlayer previews register a real release closure.
- The full-guide muted live preview marks itself as an auxiliary video surface.
- `CatalogStore.startPlayback` cancels pending preview-cache staging and releases all auxiliary video work before setting the main playback URL.
- When a preview was active recently, RootView waits 400 ms before mounting the full-screen player surface. The old catalog/guide render tree is already removed during this interval.
- In-app trailer actions perform the same release/cooldown handoff before opening `TrailerPopup`.
- Auxiliary preview creation is suppressed briefly during the handoff so a SwiftUI update cannot recreate the preview between release and full playback.

This is intended to stop an auxiliary AVPlayer/KS preview from retaining the VideoToolbox/Metal presentation lane while Live TV, VOD, or the normal trailer player starts.

## Focused-card preview cache

Added a bounded system-Caches media cache:

- Existing local preview media is checked before the resolver/memory cache.
- Progressive MP4/MOV/M4V previews can be stored locally after the one-shot 20-second preview has finished.
- Disk staging waits 22 seconds, preventing simultaneous first-play streaming and duplicate background downloading.
- Only the latest settled preview is staged; a new focused preview cancels the prior pending stage.
- Full playback and trailer playback cancel pending staging immediately.
- Maximum 18 files, 768 MB total, 96 MB per file, with oldest-file pruning.
- HLS/DASH/transport-stream manifests are not copied incorrectly as single files; they continue using the backend `reuseCache=true` and `singleFlight=true` path.

## Artwork hero redesign

For Artwork hero themes only:

- The large themed logo is centered over the synopsis information width.
- The focused-card logo is unchanged.
- Description uses the standard Apple system face instead of the rounded face.
- Description is slightly smaller, medium weight, higher contrast, three lines maximum, with improved line spacing.
- No new metadata chips, icons, or provider branding were added.

## Changed files

1. `Sources/AuxiliaryVideoPlaybackCoordinator.swift` (new)
2. `Sources/FocusedCardPreviewDiskCache.swift` (new)
3. `Sources/CatalogStore.swift`
4. `Sources/DebridChannelsTVOSApp.swift`
5. `Sources/Info.plist`
6. `project.yml`
7. `README_BUILD_v1015_V1014_BASE_AUX_VIDEO_HANDOFF_LIVETV_TRAILER_HERO_PREVIEW_CACHE.md` (new)
8. `AUDIT_v1015_CHANGED_FILES.txt` (new)

## Validation

- All Swift source files passed `swiftc -frontend -parse`.
- Existing unrelated PlaybackKit line-95 warning remains unchanged.
- `Info.plist` passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- New Swift files are explicitly listed in the XcodeGen target sources.
- PlaybackKit hash matches v1014 exactly.
- Trailer service hash matches v999 exactly.
- Archive integrity and extraction round-trip are validated during packaging.

A full tvOS SDK compile must be performed by GitHub Actions/Xcode.
