# Debrid Channels v1068

Base: v1067  
Marketing version: 1.0.596  
Build: 596

## Purpose

Return Source Intelligence to a centered presentation while preserving the premium transparent-glass style and the complete original information/navigation experience.

## Presentation correction

- Replaced the active compact satellite placement with the existing full Source Intelligence overlay.
- Centers the overlay over the media-information popup and active catalog/preview stage.
- Keeps the media popup, catalog, artwork, and focused-card preview mounted behind Source Intelligence.
- Adds only a light stage dim so the background remains visible.
- Uses an ultra-thin transparent glass material with a restrained dark readability layer.
- Uses a quick centered glass expansion/fade rather than a separate full-screen route.
- No Source Intelligence connector line is restored.

## Original Source Intelligence hierarchy restored

- Top Recommended Link is prominent at the top.
- Provider picker/statuses remain visible.
- Resolution, HDR, codec, audio, language, size, cached state, confidence, safety, and track probing remain present.
- Remaining ranked links stay below the recommendation.
- The footer explicitly displays Left/Right page navigation, Up/Down link browsing, Select to play, and Menu/Back to close.
- Current result range remains visible.

## Logic preserved

This build does not change Source Intelligence resolution, ranking, filtering, paging, scrolling, focus routing, source selection, playback handoff, or return-from-playback behavior. The page size remains five links.

## Preserved from v1067

- Focused-card preview identity/startup correction.
- Continuous preview ownership through popup interactions.
- Built-in trailer resolver restoration.
- Popup colored accent removed.
- Find Links-to-Source Intelligence connector removed.
- Episode-specific cast, advisory, catalog loading, VOD handoff, and episode-alert reliability changes.
