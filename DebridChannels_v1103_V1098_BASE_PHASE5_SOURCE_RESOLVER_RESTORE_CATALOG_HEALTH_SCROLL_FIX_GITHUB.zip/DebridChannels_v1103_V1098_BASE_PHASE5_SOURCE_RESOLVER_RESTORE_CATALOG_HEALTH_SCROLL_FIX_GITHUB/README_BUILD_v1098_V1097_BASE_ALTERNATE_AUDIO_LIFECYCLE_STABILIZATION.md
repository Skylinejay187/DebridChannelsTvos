# Debrid Channels tvOS/iOS v1098

## Alternate Audio lifecycle stabilization

- **Base:** v1097 only
- **Marketing version:** 1.0.626
- **Build:** 626
- **Required backend:** v668
- **Phase status:** corrective stabilization before Phase 5

## Why this pass exists

v1096/v1097 could leave backend `ffprobe` or bridge `ffmpeg` work running after the movie/show player closed. The earlier Scan action also enabled experimental flags automatically, so an existing installation could continue using Alternate Audio without a clear master opt-in.

## App changes

- Adds a persistent **Alternate Audio: Off/On** master control in both the VOD Audio/Settings overlay and app Settings > VOD Player.
- The master control defaults to **Off**. The safe feature migration resets prior automatically-enabled Alternate Audio flags Off once when upgrading to v1098.
- Turning the control On only exposes the controls. No probe or bridge work starts until **Find English Audio** or bridge preparation is selected manually.
- Turning it Off immediately cancels local discovery/bridge tasks, restores the original playback source, and sends a presentation-owned backend cancellation request.
- Playback exit, app backgrounding, and movie/episode/source replacement send the same cancellation request.
- Discovery and bridge requests now carry a request UUID and playback-presentation UUID.
- Discovery considers the direct Source Intelligence links still visible in the panel plus all ranked direct fallback URLs retained by the active playback session. This fixes the common zero-candidate case after the visible list was compacted.
- App-side discovery is capped at 16 unique resolved candidates.
- The bundled bridge-runtime reference is synchronized with backend v668 lifecycle cancellation behavior.

## Preserved

- Tapframe KSPNUVIO KSPlayer
- v1097 Phase 4 session-owned handoff and original-source restoration
- v1093 eager trailer path
- v1094 Live TV Gracenote persistence and slow catalog pulse
- premium Live TV overlay and Quick Guide
- Search, Favorites, catalog focus, full-width rows, episode alerts, and VOD layout
- Featured Cast image-only cleanup

## Required pairing

The app can build without backend v668, but immediate process termination requires the new `/api/alternate-audio/cancel` backend route. Deploy backend v668 before testing Alternate Audio with v1098.

## Validation performed locally

- 43 Swift files parsed successfully.
- Alternate Audio discovery, bridge, and cancellation clients type-checked with contract stubs.
- Settings focus routing type-checked exhaustively with the new master toggle.
- Safe migration test confirmed all four Alternate Audio flags reset Off while unrelated account/favorite keys remain untouched.
- 19 app lifecycle source contracts passed.
- Bundled bridge runtime passed all 9 bridge regression tests.
- Both plists and project YAML validated.
- Complete baseline hash comparison and clean archive extraction comparison were produced.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing with backend v668 is required before making v1098 the stable app base.
