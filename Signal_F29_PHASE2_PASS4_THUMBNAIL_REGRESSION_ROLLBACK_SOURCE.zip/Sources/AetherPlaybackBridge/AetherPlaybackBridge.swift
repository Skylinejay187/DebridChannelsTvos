import Foundation
import UIKit
import AVFoundation
import Combine
@_implementationOnly import AetherEngine

private enum AetherBridgeNotification {
    static let time = Notification.Name("DebridChannels.Aether.time")
    static let buffer = Notification.Name("DebridChannels.Aether.buffer")
    static let buffering = Notification.Name("DebridChannels.Aether.buffering")
    static let firstFrame = Notification.Name("DebridChannels.Aether.firstFrame")
    static let failure = Notification.Name("DebridChannels.Aether.failure")
    static let ended = Notification.Name("DebridChannels.Aether.ended")
    static let liveReset = Notification.Name("DebridChannels.Aether.liveReset")
    static let route = Notification.Name("DebridChannels.Aether.route")
    static let tracks = Notification.Name("DebridChannels.Aether.tracks")
    static let subtitleText = Notification.Name("DebridChannels.Aether.subtitleText")
    static let liveWindow = Notification.Name("DebridChannels.Aether.liveWindow")
}

/// Dynamic-framework boundary between Debrid Channels and AetherEngine.
///
/// vBRDC252 keeps this bridge under Xcode/SwiftPM native linking + embedding so its transitive
/// Aether runtime frameworks are packaged and signed correctly.
/// Debrid Channels `dlopen`s the signed framework only when an Aether playback surface is
/// actually requested. That keeps AetherEngine + its namespaced FFmpeg graph completely cold
/// while the user is browsing catalogs or the Live TV grid, while KSPlayer keeps its original
/// FFmpegKit graph in the app executable.
@MainActor
public final class AetherPlaybackHostView: UIView {
    /// vBRDC259: keep recovery inside Aether before conceding the source to KSPlayer.
    /// A healthy route still starts immediately; these rungs are entered only when the
    /// previous Aether route fails or produces no displayable frame.
    private enum LiveRoute: Int {
        case automaticURL
        case hlsIngest
        case softwareDecode

        var label: String {
            switch self {
            case .automaticURL: return "automatic-url"
            case .hlsIngest: return "hls-ingest"
            case .softwareDecode: return "software-decode"
            }
        }
    }

    private enum LiveSourceProfile: String {
        case hdHomeRun = "hdhomerun-ts"
        case fiosHLS = "fios-hls"
        case genericHLS = "generic-hls"
        case genericTransport = "generic-transport"
    }
    // KVC/Objective-C runtime configuration surface. The app intentionally does not import
    // this Swift module, so every runtime command crosses only Foundation/UIKit values.
    @objc public dynamic var configuredURLString: String = ""
    @objc public dynamic var configuredStartTimeSeconds: Double = 0
    @objc public dynamic var configuredIsLiveStream: Bool = false
    // Explicit per-surface opt-in; never infer FastZap from a global setting.
    // Standard startup remains the default for full-screen Live TV.
    @objc public dynamic var configuredFastLiveJoin: Bool = false
    @objc public dynamic var configuredHTTPHeaders: NSDictionary = [:]
    @objc public dynamic var configuredEnableDisplayMatch: Bool = true
    // vBRDC389R2: true means preserve the display mode already owned by the paused VOD session.
    @objc public dynamic var configuredInheritCurrentDisplayMode: Bool = false
    @objc public dynamic var configuredVideoGravityRaw: String = "resizeAspect"
    @objc public dynamic var configuredAutoplay: Bool = true
    @objc public dynamic var configuredSourceHint: String = ""
    @objc public dynamic var configuredSeekSeconds: Double = 0
    @objc public dynamic var configuredAudioTrackID: Int = -1
    @objc public dynamic var configuredSubtitleTrackID: Int = -1
    @objc public dynamic var configuredAudioGainDB: Double = 0
    // vBRDC385R1: host-selected VOD disk prefetch profile. This controls Aether's
    // disk-backed race-ahead window; Live TV never consults this value.
    @objc public dynamic var configuredVODCachePolicy: String = "auto"
    @objc public dynamic var configuredSubtitleDelayMS: Int = 0

    private let playerView = AetherPlayerView()
    private var engine: AetherEngine?
    private var cancellables = Set<AnyCancellable>()
    private var loadTask: Task<Void, Never>?
    private var seekTask: Task<Void, Never>?
    private var seekSerial: UInt64 = 0
    private var generation: UInt64 = 0
    private var duration: Double = 0
    private var currentTime: Double = 0
    private var firstFramePublished = false
    private var failed = false
    // vBRDC280: Aether can surface EOF through more than one state/clock edge.
    // Publish one deterministic completion event per loaded VOD session so the app-side
    // Up Next pipeline is not dependent on one exact enum string from AetherEngine.
    private var endedPublished = false
    private var lastBufferingState: Bool?
    private var lastTimeNotificationAt: TimeInterval = 0
    private var lastTimeNotificationValue: Double = -1
    private var lastBufferNotificationAt: TimeInterval = 0
    private var lastBufferNotificationValue: Double = -1
    private var loadedURL: URL?
    private var loadedOptions: LoadOptions?
    private var liveBaseOptions: LoadOptions?
    private var liveRoute: LiveRoute = .automaticURL
    private var liveSourceLooksHLS = false
    private var liveSourceProfile: LiveSourceProfile = .genericTransport
    private var liveAttemptSerial: UInt64 = 0
    // Monotonic tune timing; never persist stream URLs or user credentials.
    private var liveAttemptStartedAt: TimeInterval?
    private var liveAttemptFastJoin = false
    private var liveRecoveryTask: Task<Void, Never>?
    private var liveRecoveryInFlight = false
    private var liveRetuneTask: Task<Void, Never>?
    private var liveRetuneInFlight = false
    private var liveRetuneCount = 0
    private var lastLiveRetuneAt: TimeInterval = 0
    // vBRDC383R6: retain an explicitly selected Live TV audio track across an internal
    // Aether retune/route reload. This is session-local and is cleared on a real stop.
    private var preservedLiveAudioTrackID: Int = -1
    private var gainForcedSoftwareDecode = false
    private var latestSubtitleCues: [SubtitleCue] = []
    // Restore F27 cache-backed still extraction for remote Debrid scrubbing.
    private var scrubThumbnailTask: Task<Void, Never>?


    public override init(frame: CGRect) {
        super.init(frame: frame)
        bootstrapView()
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        bootstrapView()
    }

    private func bootstrapView() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleScrubThumbnailRequest(_:)), name: Notification.Name("DebridChannels.Aether.requestScrubThumbnail"), object: nil)
        backgroundColor = .black
        isOpaque = true
        clipsToBounds = true
        layer.backgroundColor = UIColor.black.cgColor
        layer.masksToBounds = true
        layer.shadowOpacity = 0
        layer.shadowRadius = 0
        layer.shadowOffset = .zero
        layer.compositingFilter = nil
        layer.filters = nil

        playerView.backgroundColor = .black
        playerView.isOpaque = true
        playerView.clipsToBounds = true
        playerView.layer.backgroundColor = UIColor.black.cgColor
        playerView.layer.masksToBounds = true
        playerView.layer.shadowOpacity = 0
        playerView.layer.shadowRadius = 0
        playerView.layer.shadowOffset = .zero
        playerView.layer.compositingFilter = nil
        playerView.layer.filters = nil
        playerView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(playerView)
        NSLayoutConstraint.activate([
            playerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            playerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            playerView.topAnchor.constraint(equalTo: topAnchor),
            playerView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])
    }

    public override func layoutSubviews() {
        super.layoutSubviews()
        // vBRDC255 Phase 4: keep the Aether presentation host a true opaque-black island.
        // Aether may rebuild its renderer while loading/seeking, so reassert only the outer
        // UIKit containers here. Do not mutate the renderer's internal Metal/video layers.
        backgroundColor = .black
        layer.backgroundColor = UIColor.black.cgColor
        layer.shadowOpacity = 0
        layer.compositingFilter = nil
        layer.filters = nil
        playerView.backgroundColor = .black
        playerView.layer.backgroundColor = UIColor.black.cgColor
        playerView.layer.shadowOpacity = 0
        playerView.layer.compositingFilter = nil
        playerView.layer.filters = nil
    }

    @objc private func handleScrubThumbnailRequest(_ note: Notification) {
        guard !configuredIsLiveStream,
              let requestedURL = note.userInfo?["url"] as? String,
              requestedURL == configuredURLString,
              let seconds = note.userInfo?["seconds"] as? Double,
              seconds.isFinite, seconds >= 0,
              let engine, engine.supportsCacheBackedStills else { return }
        scrubThumbnailTask?.cancel()
        let requestedGeneration = generation
        scrubThumbnailTask = Task { @MainActor [weak self, weak engine] in
            guard let self, let engine else { return }
            let image = await engine.scrubThumbnail(atSeconds: seconds, maxWidth: 360)
            guard !Task.isCancelled, self.engine === engine,
                  self.generation == requestedGeneration,
                  self.configuredURLString == requestedURL else { return }
            var info: [String: Any] = ["url": requestedURL, "seconds": seconds]
            if let image { info["image"] = UIImage(cgImage: image) }
            NotificationCenter.default.post(name: Notification.Name("DebridChannels.Aether.scrubThumbnail"),
                                            object: nil, userInfo: info)
        }
    }

    @objc public func aetherLoadConfiguredMedia() {
        guard let url = URL(string: configuredURLString), !configuredURLString.isEmpty else {
            publishFailure("AetherEngine received an invalid playback URL.")
            return
        }
        var headers: [String: String] = [:]
        for (key, value) in configuredHTTPHeaders {
            guard let key = key as? String else { continue }
            headers[key] = String(describing: value)
        }
        load(
            url: url,
            startTimeSeconds: configuredStartTimeSeconds,
            isLiveStream: configuredIsLiveStream,
            httpHeaders: headers,
            enableDisplayMatch: configuredEnableDisplayMatch,
            inheritCurrentDisplayMode: configuredInheritCurrentDisplayMode,
            autoplay: configuredAutoplay
        )
    }

    @objc public func aetherSeekConfiguredPosition() {
        seek(to: configuredSeekSeconds)
    }

    @objc public func aetherPlay() { play() }
    @objc public func aetherPause() { pause() }
    @objc public func aetherGoLive() {
        guard let engine, loadedOptions?.isLive == true else { return }
        let sessionGeneration = generation
        Task { @MainActor [weak self, weak engine] in
            guard let self, let engine, self.generation == sessionGeneration, self.engine === engine else { return }
            await engine.seekToLiveEdge()
            // A seek may suspend across a channel change or exit. Never report completion
            // or mutate a subsequent session from the old asynchronous operation.
            guard !Task.isCancelled, self.generation == sessionGeneration, self.engine === engine else { return }
            self.liveDiagnostic("timeshift go-live requested")
        }
    }
    @objc public func aetherStop() { stop() }
    @objc public func aetherApplyTrackSelection() {
        guard let engine else { return }
        if configuredAudioTrackID >= 0 {
            if loadedOptions?.isLive == true { preservedLiveAudioTrackID = configuredAudioTrackID }
            engine.selectAudioTrack(index: configuredAudioTrackID)
            if loadedOptions?.isLive != true {
                // F28: the software host now retains gain across audio-decoder replacement.
                // Reapply synchronously rather than scheduling a delayed 900 ms task that
                // can race a subsequent track change or leave a new track briefly unamplified.
                engine.setDecodedAudioGainDB(max(0, min(12, configuredAudioGainDB)))
            }
        }
        if configuredSubtitleTrackID >= 0 {
            engine.selectSubtitleTrack(index: configuredSubtitleTrackID)
        } else {
            engine.clearSubtitle()
            NotificationCenter.default.post(name: AetherBridgeNotification.subtitleText, object: self, userInfo: ["text": ""])
        }
    }

    @objc public func aetherApplyAudioGain() {
        guard loadedOptions?.isLive != true else { return }
        // vBRDC386R1: Gain changes are an in-session audio parameter. Never reload the
        // VOD source merely because the user moved between Off/+3/+6/+9/+12 dB; a reload
        // visibly pauses playback and can disturb the authoritative playhead/cache state.
        let requested = max(0, min(12, configuredAudioGainDB))
        engine?.setDecodedAudioGainDB(requested)
    }

    @objc public func aetherRefreshSubtitlePresentation() {
        publishActiveSubtitleText()
    }

    public func load(
        url: URL,
        startTimeSeconds: Double,
        isLiveStream: Bool,
        httpHeaders: [String: String],
        enableDisplayMatch: Bool,
        inheritCurrentDisplayMode: Bool = false,
        autoplay: Bool
    ) {
        stopSession(advanceGeneration: true)
        failed = false
        endedPublished = false
        firstFramePublished = false
        duration = 0
        currentTime = 0
        lastTimeNotificationAt = 0
        lastTimeNotificationValue = -1
        lastBufferNotificationAt = 0
        lastBufferNotificationValue = -1
        lastBufferingState = nil

        let localGeneration = generation
        do {
            let engine = try AetherEngine()
            self.engine = engine
            switch configuredVideoGravityRaw {
            case "resizeAspectFill":
                engine.videoGravity = .resizeAspectFill
            case "resize":
                engine.videoGravity = .resize
            default:
                engine.videoGravity = .resizeAspect
            }
            engine.bind(view: playerView)
            // Phase 4: binding must not introduce a translucent/elevated-black host around
            // the actual video image. Renderer internals remain owned exclusively by Aether.
            setNeedsLayout()
            layoutIfNeeded()
            installObservers(engine: engine, generation: localGeneration)

            // vBRDC383R3: physical Apple TV testing split the Live TV failure by provider:
            // HDHomeRun/direct transport streams can lose audio while video continues, while
            // Verizon FiOS/HLS keeps audio but can stutter when forced through custom ingest.
            // Keep native HLS available and choose the initial route from the provider hint.
            let nativeRemoteHLS = isLiveStream && Self.looksLikeRemoteHLS(url)
            // vBRDC389R2 display policy:
            // - normal VOD: Aether/tvOS may match content normally;
            // - VOD-overlay trailer: keep HDR/content-aware rendering enabled but suppress
            //   a second display-criteria negotiation, inheriting the paused VOD HDMI mode;
            // - standalone trailer / Live: do not request display matching.
            let suppressDisplayCriteria = isLiveStream || inheritCurrentDisplayMode || !enableDisplayMatch
            let matchContentEnabled = isLiveStream ? false : (enableDisplayMatch || inheritCurrentDisplayMode)
            var options = LoadOptions(
                suppressDisplayCriteria: suppressDisplayCriteria,
                httpHeaders: httpHeaders,
                matchContentEnabled: matchContentEnabled,
                isLive: isLiveStream,
                liveJoinProfile: .standard,
                nativeRemoteHLS: nativeRemoteHLS,
                nativeRemoteHLSIngestFallback: true,
                preferredAudioLanguages: ["en", "eng"],
                autoplay: autoplay
            )
            if isLiveStream {
                // vBRDC383 Phase 1: reliability first. Do not expose the live renderer/audio
                // path through the shallow fast-zap window; allow Aether to establish stable
                // timestamp/audio continuity before presentation.
                options.liveJoinStartsImmediately = configuredFastLiveJoin
                options.preferredDecodePath = .automatic
                // Bound FFmpeg's live open so a sparse/broken channel cannot spend the engine's
                // 50 MB / 60 s default probe budget before the recovery ladder gets a decision.
                // This remains substantially more generous than the proven KSPlayer live probe.
                options.probesize = 15 * 1024 * 1024
                options.maxAnalyzeDuration = 15 * 1_000_000
            }
            if !isLiveStream {
                // vBRDC385 Phase 3: disk-backed VOD race-ahead. Aether owns the byte budget,
                // eviction and session teardown; Signal only selects a forward-window profile.
                options.forwardBufferSegments = Self.vodForwardBufferSegments(sourceHint: configuredSourceHint, cachePolicy: configuredVODCachePolicy)
                let gainDB = max(0, min(12, configuredAudioGainDB))
                gainForcedSoftwareDecode = gainDB > 0.01
                if gainForcedSoftwareDecode { options.preferredDecodePath = .software }
            } else {
                gainForcedSoftwareDecode = false
            }
            loadedURL = url
            loadedOptions = options
            liveBaseOptions = isLiveStream ? options : nil
            liveSourceLooksHLS = isLiveStream && Self.looksLikeRemoteHLS(url)
            liveSourceProfile = isLiveStream
                ? Self.classifyLiveSource(url: url, hint: configuredSourceHint, looksHLS: liveSourceLooksHLS)
                : .genericTransport
            liveRoute = .automaticURL
            liveAttemptSerial = 0
            liveAttemptStartedAt = nil
            liveAttemptFastJoin = false
            liveRetuneCount = 0
            lastLiveRetuneAt = 0
            // The bridge is also called directly outside the SwiftUI surface. A
            // malformed restored resume position must never enter Aether's
            // timeline or CMTime conversion, even when the UI guard is bypassed.
            let requestedStart = isLiveStream ? 0 : (startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0)

            if isLiveStream {
                let initialRoute = initialLiveRoute(for: liveSourceProfile)
                liveDiagnostic("sourceProfile=\(liveSourceProfile.rawValue) hintPresent=\(!configuredSourceHint.isEmpty) hls=\(liveSourceLooksHLS) url=\(Self.redactedLiveURL(url))")
                startLiveAttempt(
                    engine: engine,
                    url: url,
                    baseOptions: options,
                    route: initialRoute,
                    generation: localGeneration,
                    reason: "vBRDC383R3 provider-aware initial live tune (\(liveSourceProfile.rawValue))"
                )
            } else {
                loadTask = Task { @MainActor [weak self, weak engine] in
                    guard let self, let engine else { return }
                    do {
                        try await engine.load(url: url, options: options)
                        guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                        engine.setDecodedAudioGainDB(max(0, min(12, self.configuredAudioGainDB)))
                        if requestedStart > 0.25 {
                            await engine.seek(to: requestedStart)
                        }
                        guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                        if autoplay { engine.play() } else { engine.pause() }
                    } catch is CancellationError {
                        return
                    } catch {
                        guard !Task.isCancelled, self.generation == localGeneration else { return }
                        self.publishFailure(error.localizedDescription)
                    }
                }
            }
        } catch {
            publishFailure("AetherEngine initialization failed: \(error.localizedDescription)")
        }
    }

    public func seek(to seconds: Double) {
        // The bridge is a public entry point used by resume, DVR and timeline
        // paths. Reject non-finite input here too, even if a caller regresses.
        guard seconds.isFinite, seconds >= 0, let engine else { return }
        let localGeneration = generation
        // Cancellation is cooperative. Track a separate seek identity so a retired
        // seek cannot become current merely because the player session survived.
        seekSerial &+= 1
        let localSeekSerial = seekSerial
        seekTask?.cancel()
        seekTask = Task { @MainActor [weak self, weak engine] in
            guard let self, let engine,
                  !Task.isCancelled,
                  self.generation == localGeneration,
                  self.seekSerial == localSeekSerial,
                  self.engine === engine else { return }
            await engine.seek(to: max(0, seconds))
            // A seek can suspend while the user switches channels, leaves playback,
            // or starts a newer seek. The retired session must never publish work.
            guard !Task.isCancelled,
                  self.generation == localGeneration,
                  self.seekSerial == localSeekSerial,
                  self.engine === engine else { return }
            self.seekTask = nil
        }
    }

    public func play() { engine?.play() }
    public func pause() { engine?.pause() }
    public func stop() { stopSession(advanceGeneration: true) }

    private func stopSession(advanceGeneration: Bool) {
        if advanceGeneration {
            generation &+= 1
            preservedLiveAudioTrackID = -1
        }
        loadTask?.cancel()
        loadTask = nil
        seekSerial &+= 1
        seekTask?.cancel()
        seekTask = nil
        liveRecoveryTask?.cancel()
        liveRecoveryTask = nil
        liveRecoveryInFlight = false
        liveRetuneTask?.cancel()
        liveRetuneTask = nil
        liveRetuneInFlight = false
        liveAttemptSerial &+= 1
        // A stopped session must not retain a previous channel's tune clock.
        liveAttemptStartedAt = nil
        liveAttemptFastJoin = false
        liveBaseOptions = nil
        liveSourceLooksHLS = false
        liveSourceProfile = .genericTransport
        loadedURL = nil
        loadedOptions = nil
        latestSubtitleCues = []
        gainForcedSoftwareDecode = false
        // Invalidate per-session publication state on exit, not only on the next load.
        // This prevents a reused host view from retaining stale timing/EOF flags.
        firstFramePublished = false
        endedPublished = false
        failed = false
        duration = 0
        currentTime = 0
        lastTimeNotificationAt = 0
        lastTimeNotificationValue = -1
        lastBufferNotificationAt = 0
        lastBufferNotificationValue = -1
        lastBufferingState = nil
        cancellables.removeAll()
        engine?.stop()
        engine = nil
        // Leave a deterministic black presentation island behind during teardown/source
        // transitions so a stale HDR/renderer surface cannot bloom through SwiftUI chrome.
        backgroundColor = .black
        playerView.backgroundColor = .black
        layer.backgroundColor = UIColor.black.cgColor
        playerView.layer.backgroundColor = UIColor.black.cgColor
        setNeedsLayout()
    }

    private func installObservers(engine: AetherEngine, generation observedGeneration: UInt64) {
        engine.$duration
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.duration = value.isFinite ? max(0, value) : 0
                self.publishTimeNotification(force: true)
            }
            .store(in: &cancellables)

        engine.clock.$currentTime
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.currentTime = max(0, value)
                self.publishTimeNotification(force: false)
                // vBRDC280: some Aether routes finish at the media clock without ever
                // publishing a literal state description of "ended". Use the same
                // decoder clock as a bounded EOF fallback for non-live VOD. This only
                // fires within 150 ms of a known duration and is one-shot per load.
                self.publishEndedIfNeeded(reason: "clock")
            }
            .store(in: &cancellables)

        // vBRDC384: publish Aether's authoritative DVR window instead of inventing
        // seek bounds in SwiftUI. All values are on Aether's session timeline.
        Publishers.CombineLatest4(
            engine.clock.$liveEdgeTime,
            engine.clock.$seekableLiveRange,
            engine.clock.$isAtLiveEdge,
            engine.clock.$behindLiveSeconds
        )
        .receive(on: RunLoop.main)
        .sink { [weak self, weak engine] edge, range, atEdge, behind in
            guard let self, let engine, self.engine === engine, self.generation == observedGeneration,
                  self.loadedOptions?.isLive == true else { return }
            var info: [String: Any] = [
                "edge": max(0, edge),
                "atEdge": atEdge,
                "behind": max(0, behind)
            ]
            if let range {
                info["lower"] = range.lowerBound
                info["upper"] = range.upperBound
            }
            NotificationCenter.default.post(name: AetherBridgeNotification.liveWindow, object: self, userInfo: info)
        }
        .store(in: &cancellables)

        engine.clock.$bufferedPosition
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.publishBufferNotification(position: max(0, value))
            }
            .store(in: &cancellables)

        // vBRDC386 Phase 4: Aether's VOD producer can continue filling its disk-backed
        // reservoir while presentation is paused. Some engine paths do not emit a fresh
        // bufferedPosition Combine tick until playback advances again, which left Signal's
        // cache-ahead scrubber visually stale. Poll the authoritative Aether clock at a low
        // 2 Hz cadence for VOD only. publishBufferNotification keeps its existing movement/
        // cadence coalescing, and this subscription dies with the playback session.
        if loadedOptions?.isLive != true {
            // Keep the cache UI current while idle, but never inject polling work
            // into tracking/common run-loop modes during remote-driven scrolling.
            // The next default-mode tick catches up after navigation settles.
            Timer.publish(every: 0.25, on: .main, in: .default)
                .autoconnect()
                .sink { [weak self, weak engine] _ in
                    guard let self, let engine, self.engine === engine,
                          self.generation == observedGeneration else { return }
                    let value = engine.clock.bufferedPosition
                    guard value.isFinite else { return }
                    self.publishBufferNotification(position: max(0, value))
                }
                .store(in: &cancellables)
        }

        // Aether's own LiveHost reference explicitly warns that session-ready/state=playing
        // is not first-frame readiness. Lifting Debrid Channels' loading cover from that
        // earlier signal can expose a permanent black surface on live startup.
        engine.$hasFirstFrameReadyForDisplay
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] ready in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration,
                      ready, !self.firstFramePublished else { return }
                self.firstFramePublished = true
                if self.loadedOptions?.isLive == true {
                    if let started = self.liveAttemptStartedAt {
                        let elapsedMS = Int(max(0, (ProcessInfo.processInfo.systemUptime - started) * 1000))
                        self.liveDiagnostic("firstFrame route=\(self.liveRoute.label) join=\(self.liveAttemptFastJoin ? "fast" : "standard") elapsedMs=\(elapsedMS) attempt=\(self.liveAttemptSerial)")
                    } else {
                        self.liveDiagnostic("firstFrame route=\(self.liveRoute.label)")
                    }
                    self.liveAttemptStartedAt = nil
                }
                self.liveRecoveryTask?.cancel()
                self.liveRecoveryTask = nil
                self.liveRecoveryInFlight = false
                NotificationCenter.default.post(name: AetherBridgeNotification.firstFrame, object: self)
            }
            .store(in: &cancellables)

        // 6.81 host contract: liveSourceReset is a required retune signal, not a terminal
        // engine error. If it is ignored a channel can sit black/stalled forever while the
        // engine still owns a session. Retune the exact source under a bounded guard.
        engine.liveSourceReset
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                NotificationCenter.default.post(name: AetherBridgeNotification.liveReset, object: self)
                self.liveDiagnostic("liveSourceReset route=\(self.liveRoute.label) firstFrame=\(self.firstFramePublished)")
                if self.firstFramePublished {
                    self.scheduleLiveRetune(engine: engine, generation: observedGeneration, reason: "liveSourceReset")
                } else {
                    self.advanceLiveRecovery(
                        engine: engine, generation: observedGeneration,
                        reason: "Aether liveSourceReset before first frame"
                    )
                }
            }
            .store(in: &cancellables)

        engine.$playbackPhase
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] phase in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                let value = String(describing: phase).lowercased()
                if self.loadedOptions?.isLive == true { self.liveDiagnostic("playbackPhase=\(value) route=\(self.liveRoute.label)") }
                let buffering = value.contains("loading") || value.contains("rebuffer") || value.contains("stall") || value.contains("seeking")
                self.publishBufferingNotification(buffering)
            }
            .store(in: &cancellables)

        // vBRDC383 Phase 1: Aether 6.89.x exposes the actual audio-delivery result.
        // A live session with source audio but no delivery pipeline is unhealthy even if video
        // has rendered; recover on the same bounded Aether route instead of masking the cutout.
        engine.$audioDelivery
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] delivery in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.liveDiagnostic("audioDelivery=\(delivery) route=\(self.liveRoute.label) source=\(self.liveSourceProfile.rawValue) firstFrame=\(self.firstFramePublished)")
                guard delivery == .droppedNoPipeline else { return }
                if self.loadedOptions?.isLive == true {
                    if self.firstFramePublished {
                        self.scheduleLiveRetune(engine: engine, generation: observedGeneration, reason: "audioDelivery droppedNoPipeline")
                    } else {
                        self.advanceLiveRecovery(engine: engine, generation: observedGeneration, reason: "Aether audio delivery dropped before first frame")
                    }
                } else {
                    self.publishFailure("AetherEngine found source audio but could not construct an audio delivery pipeline.")
                }
            }
            .store(in: &cancellables)

        engine.$audioTracks
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] _ in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.publishTracks(engine: engine)
            }
            .store(in: &cancellables)

        engine.$subtitleTracks
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] _ in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.publishTracks(engine: engine)
            }
            .store(in: &cancellables)

        engine.$subtitleCues
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] cues in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.latestSubtitleCues = cues
                self.publishActiveSubtitleText()
            }
            .store(in: &cancellables)

        engine.clock.$sourceTime
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] _ in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.publishActiveSubtitleText()
            }
            .store(in: &cancellables)

        engine.$videoRoute
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] route in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                NotificationCenter.default.post(
                    name: AetherBridgeNotification.route,
                    object: self,
                    userInfo: ["route": String(describing: route)]
                )
            }
            .store(in: &cancellables)

        engine.$state
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] state in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                let value = String(describing: state).lowercased()
                if value.hasPrefix("error") {
                    let detail = engine.errorInfo.map { " | \($0)" } ?? ""
                    if self.loadedOptions?.isLive == true {
                        if self.firstFramePublished {
                            self.scheduleLiveRetune(engine: engine, generation: observedGeneration, reason: "Aether state error: \(state)\(detail)")
                        } else {
                            self.advanceLiveRecovery(
                                engine: engine, generation: observedGeneration,
                                reason: "Aether state error: \(state)\(detail)"
                            )
                        }
                    } else {
                        self.publishFailure("AetherEngine playback error: \(state)\(detail)")
                    }
                } else if value.contains("ended") || value.contains("finished") || value.contains("completed") {
                    self.publishEndedIfNeeded(reason: "state=\(value)", force: true)
                }
            }
            .store(in: &cancellables)
    }

    private func publishEndedIfNeeded(reason: String, force: Bool = false) {
        guard !endedPublished, loadedOptions?.isLive != true else { return }
        if !force {
            guard duration.isFinite, duration > 30, currentTime.isFinite, currentTime > 5 else { return }
            let remaining = max(0, duration - currentTime)
            guard remaining <= 0.15 else { return }
        }
        endedPublished = true
        publishTimeNotification(force: true)
        NotificationCenter.default.post(
            name: AetherBridgeNotification.ended,
            object: self,
            userInfo: ["reason": reason]
        )
    }

    private func publishActiveSubtitleText() {
        guard let engine else { return }
        let delay = Double(configuredSubtitleDelayMS) / 1000.0
        let playhead = engine.clock.sourceTime - delay
        let active = latestSubtitleCues.filter { cue in
            cue.startTime <= playhead && playhead < cue.endTime
        }
        let text = active.compactMap { Self.extractSubtitleText(from: $0) }
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: "\n")
        NotificationCenter.default.post(name: AetherBridgeNotification.subtitleText, object: self, userInfo: ["text": text])
    }

    private static func vodForwardBufferSegments(sourceHint: String, cachePolicy: String) -> Int {
        // Aether 6.89.1 stores VOD race-ahead on disk and applies its own free-volume safety
        // clamp. Signal selects a cache target by widening the producer window; it never
        // allocates gigabytes in RAM. Exact resident bytes remain engine-owned because
        // segment sizes vary by bitrate/container.
        switch cachePolicy.lowercased() {
        case "1gb": return 100
        case "2gb": return 180
        case "3gb": return 270
        case "unlimited": return 2700
        default:
            let hint = sourceHint.lowercased()
            let uncached = hint.contains("cache-health=uncached") || hint.contains(" uncached")
            let seeders: Int? = {
                guard let range = hint.range(of: #"seeders[=: ]+([0-9]+)"#, options: .regularExpression) else { return nil }
                return Int(hint[range].filter(\.isNumber))
            }()
            if uncached, let seeders, seeders <= 10 { return 180 }
            if uncached { return 150 }
            if hint.contains("remux") || hint.contains("2160") || hint.contains("4k") || hint.contains("uhd") { return 120 }
            return 90
        }
    }

    private func publishTracks(engine: AetherEngine) {
        let audio = engine.audioTracks.enumerated().map { offset, track in
            Self.trackDictionary(track, fallback: "Audio \(offset + 1)")
        }
        let subtitles = engine.subtitleTracks.enumerated().map { offset, track in
            Self.trackDictionary(track, fallback: "Subtitle \(offset + 1)")
        }
        NotificationCenter.default.post(
            name: AetherBridgeNotification.tracks,
            object: self,
            userInfo: ["audio": audio, "subtitles": subtitles]
        )
    }

    private static func trackDictionary(_ track: Any, fallback: String) -> [String: Any] {
        let mirror = Mirror(reflecting: track)
        var id = -1
        var label = fallback
        var language = ""
        var codec = ""
        var isDefault = false
        var isForced = false
        var isHearingImpaired = false
        for child in mirror.children {
            guard let raw = child.label?.lowercased() else { continue }
            if raw == "id", let value = child.value as? Int { id = value }
            if ["title", "name", "displayname", "label"].contains(raw), let value = child.value as? String, !value.isEmpty { label = value }
            if raw == "language", let value = child.value as? String { language = value }
            if raw == "codec", let value = child.value as? String { codec = value }
            if raw == "isdefault", let value = child.value as? Bool { isDefault = value }
            if raw == "isforced", let value = child.value as? Bool { isForced = value }
            if raw == "ishearingimpaired", let value = child.value as? Bool { isHearingImpaired = value }
        }
        return [
            "id": id, "label": label, "language": language, "codec": codec,
            "isDefault": isDefault, "isForced": isForced, "isSDH": isHearingImpaired
        ]
    }

    private static func extractSubtitleText(from value: Any) -> String? {
        var strings: [String] = []
        func walk(_ candidate: Any, depth: Int) {
            guard depth < 8 else { return }
            if let text = candidate as? String {
                let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
                if !clean.isEmpty { strings.append(clean) }
                return
            }
            let mirror = Mirror(reflecting: candidate)
            for child in mirror.children {
                let label = child.label?.lowercased() ?? ""
                if label.contains("font") || label.contains("color") || label.contains("face") { continue }
                walk(child.value, depth: depth + 1)
            }
        }
        walk(value, depth: 0)
        let unique = strings.reduce(into: [String]()) { result, value in
            if result.last != value { result.append(value) }
        }
        return unique.isEmpty ? nil : unique.joined(separator: "")
    }

    private static func classifyLiveSource(url: URL, hint: String, looksHLS: Bool) -> LiveSourceProfile {
        let lowerHint = hint.lowercased()
        let raw = url.absoluteString.lowercased()
        // An explicit provider name wins over URL heuristics. This lets a FiOS route stay
        // on its cadence-friendly HLS policy even when a local tuner/proxy appears in the URL.
        if lowerHint.contains("verizon") || lowerHint.contains("fios") {
            return looksHLS ? .fiosHLS : .genericTransport
        }
        if lowerHint.contains("hdhomerun") || raw.contains("hdhomerun") || raw.contains("/auto/") || raw.contains(":5004/") {
            return .hdHomeRun
        }
        return looksHLS ? .genericHLS : .genericTransport
    }

    private static func redactedLiveURL(_ url: URL) -> String {
        // IPTV credentials may appear in URL path components as well as query/userinfo.
        // Diagnostics need only the transport and host; never log the stream path.
        let scheme = url.scheme?.lowercased() ?? "unknown"
        let host = url.host ?? "unknown"
        return "\(scheme)://\(host)"
    }

    private func initialLiveRoute(for profile: LiveSourceProfile) -> LiveRoute {
        switch profile {
        case .hdHomeRun:
            // The prior KSPlayer route that behaved best on tuner MPEG-TS was FFmpeg-first.
            // Use Aether's software/FFmpeg path first for this source instead of generic auto.
            return .softwareDecode
        case .fiosHLS, .genericHLS:
            // FiOS retained audio but physically stuttered through forced HLS ingest. Native
            // HLS gets first shot; ingest/software remain bounded recovery rungs.
            return .automaticURL
        case .genericTransport:
            return .automaticURL
        }
    }

    private static func looksLikeRemoteHLS(_ url: URL) -> Bool {
        let raw = url.absoluteString.lowercased()
        if url.pathExtension.lowercased() == "m3u8" { return true }
        if raw.contains(".m3u8") { return true }
        if raw.contains("format=m3u8") || raw.contains("type=m3u8") || raw.contains("extension=m3u8") { return true }
        return false
    }

    private func liveOptions(base: LoadOptions, route: LiveRoute) -> LoadOptions {
        var options = base
        options.isLive = true
        options.liveJoinProfile = .standard
        options.liveJoinStartsImmediately = false
        options.nativeRemoteHLSIngestFallback = true

        // vBRDC383R7: Aether #107's stable tuner architecture is the live
        // reader/feeder path with an independent audio look-ahead pump. R5/R6
        // proved the audio starvation diagnosis by enabling the VOD decoupling
        // FIFO for live, but that FIFO can deliberately sacrifice late video
        // when 1080i decode/deinterlace runs near realtime. Give raw transport
        // live sources a small internal ring so Aether uses its purpose-built
        // live feeder instead. This is transport stabilization only: Signal
        // exposes no pause/rewind/seek UI until the dedicated Timeshift phase.
        // vBRDC384 Phase 2: every Aether Live route requests a device-local 30-minute
        // rolling DVR. Native HLS uses Aether's segment-cache Live window; raw transport
        // uses the #107 packet-ring reader/feeder path proven by R7. Aether owns disk
        // budgeting/eviction and teardown, so no provider media crosses Signal's server.
        options.dvrWindowSeconds = 1800
        if liveSourceProfile == .hdHomeRun || liveSourceProfile == .genericTransport {
            options.deinterlaceMode = .auto
            options.deinterlaceFieldRate = .field
        }

        switch route {
        case .automaticURL:
            options.nativeRemoteHLS = liveSourceLooksHLS
            options.preferredDecodePath = .automatic
        case .hlsIngest:
            options.nativeRemoteHLS = false
            options.preferredDecodePath = .automatic
        case .softwareDecode:
            options.nativeRemoteHLS = false
            options.preferredDecodePath = .software
        }
        return options
    }

    private func liveWatchdogSeconds(for route: LiveRoute) -> Double {
        switch route {
        case .automaticURL: return 7.5
        case .hlsIngest: return 9.0
        case .softwareDecode: return 10.0
        }
    }

    private func postLiveRoute(_ route: LiveRoute, reason: String) {
        liveDiagnostic("route=\(route.label) reason=\(reason)")
        NotificationCenter.default.post(
            name: AetherBridgeNotification.route,
            object: self,
            userInfo: ["route": "live/\(route.label)", "reason": reason]
        )
    }

    private func startLiveAttempt(
        engine: AetherEngine,
        url: URL,
        baseOptions: LoadOptions,
        route: LiveRoute,
        generation expectedGeneration: UInt64,
        reason: String
    ) {
        guard self.engine === engine, generation == expectedGeneration else { return }
        liveAttemptSerial &+= 1
        let attempt = liveAttemptSerial
        liveRoute = route
        liveRecoveryInFlight = false
        failed = false
        firstFramePublished = false
        publishBufferingNotification(true)

        var options = liveOptions(base: baseOptions, route: route)
        // FastZap applies to the first tune only. Recovery and retune attempts must
        // return to the stable join path even when the user's preference is enabled.
        // liveOptions intentionally resets this flag for every route by default.
        options.liveJoinStartsImmediately = attempt == 1 && baseOptions.liveJoinStartsImmediately
        loadedOptions = options
        liveAttemptStartedAt = ProcessInfo.processInfo.systemUptime
        liveAttemptFastJoin = options.liveJoinStartsImmediately
        liveDiagnostic("tuneStart route=\(route.label) join=\(liveAttemptFastJoin ? "fast" : "standard") attempt=\(attempt)")
        postLiveRoute(route, reason: reason)

        loadTask?.cancel()
        loadTask = Task { @MainActor [weak self, weak engine] in
            guard let self, let engine,
                  self.engine === engine,
                  self.generation == expectedGeneration,
                  self.liveAttemptSerial == attempt else { return }
            do {
                if route == .hlsIngest || (route == .softwareDecode && self.liveSourceLooksHLS) {
                    // Explicit ingest is the header-safe IPTV route. Headers ride the master/media
                    // playlists, every segment and AES key instead of depending on AVURLAsset's
                    // redirect behavior. The software rung uses the same ingest but forces Aether's
                    // per-session SoftwarePlaybackHost when VideoToolbox produces ready-but-black.
                    let reader = HLSLiveIngestReader(playlistURL: url, httpHeaders: options.httpHeaders)
                    _ = try await engine.load(
                        source: .custom(reader, formatHint: "mpegts"),
                        options: options
                    )
                } else {
                    _ = try await engine.load(url: url, options: options)
                }
                guard !Task.isCancelled,
                      self.engine === engine,
                      self.generation == expectedGeneration,
                      self.liveAttemptSerial == attempt else { return }
                if self.preservedLiveAudioTrackID >= 0 {
                    engine.selectAudioTrack(index: self.preservedLiveAudioTrackID)
                    self.liveDiagnostic("reapplied explicit audio track=\(self.preservedLiveAudioTrackID) after route load")
                }
                if options.autoplay { engine.play() } else { engine.pause() }
            } catch is CancellationError {
                return
            } catch {
                guard !Task.isCancelled,
                      self.engine === engine,
                      self.generation == expectedGeneration,
                      self.liveAttemptSerial == attempt else { return }
                self.advanceLiveRecovery(
                    engine: engine,
                    generation: expectedGeneration,
                    reason: "\(route.label) load failed: domain=\((error as NSError).domain) code=\((error as NSError).code)"
                )
            }
        }

        armLiveFirstFrameWatchdog(
            engine: engine,
            generation: expectedGeneration,
            attempt: attempt,
            route: route
        )
    }

    private func armLiveFirstFrameWatchdog(
        engine: AetherEngine,
        generation expectedGeneration: UInt64,
        attempt: UInt64,
        route: LiveRoute
    ) {
        liveRecoveryTask?.cancel()
        let delay = liveWatchdogSeconds(for: route)
        liveRecoveryTask = Task { @MainActor [weak self, weak engine] in
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled,
                  let self, let engine,
                  self.engine === engine,
                  self.generation == expectedGeneration,
                  self.liveAttemptSerial == attempt,
                  !self.firstFramePublished else { return }
            self.advanceLiveRecovery(
                engine: engine,
                generation: expectedGeneration,
                reason: "\(route.label) produced no displayable frame in \(String(format: "%.1f", delay))s"
            )
        }
    }

    private func nextLiveRoute(after route: LiveRoute) -> LiveRoute? {
        switch liveSourceProfile {
        case .hdHomeRun:
            switch route {
            case .softwareDecode: return .automaticURL
            case .automaticURL, .hlsIngest: return nil
            }
        case .fiosHLS, .genericHLS:
            switch route {
            case .automaticURL: return .hlsIngest
            case .hlsIngest: return .softwareDecode
            case .softwareDecode: return nil
            }
        case .genericTransport:
            switch route {
            case .automaticURL: return .softwareDecode
            case .softwareDecode, .hlsIngest: return nil
            }
        }
    }

    private func advanceLiveRecovery(
        engine: AetherEngine,
        generation expectedGeneration: UInt64,
        reason: String
    ) {
        guard self.engine === engine,
              generation == expectedGeneration,
              loadedOptions?.isLive == true,
              !firstFramePublished,
              !liveRecoveryInFlight else { return }
        liveRecoveryInFlight = true
        liveRecoveryTask?.cancel()
        liveRecoveryTask = nil

        // Record time spent waiting for the failed route's first frame before
        // moving to a fallback. Keep this separate from successful tune timings.
        if let started = liveAttemptStartedAt {
            let elapsedMS = Int(max(0, (ProcessInfo.processInfo.systemUptime - started) * 1000))
            liveDiagnostic("noFirstFrame route=\(liveRoute.label) join=\(liveAttemptFastJoin ? "fast" : "standard") elapsedMs=\(elapsedMS) attempt=\(liveAttemptSerial)")
            liveAttemptStartedAt = nil
        }
        // A fast initial join may fail on a stream that works with the same
        // decoder route in Standard mode. Retry that route once without FastZap
        // before paying the cost of switching to a different decode pipeline.
        // startLiveAttempt enables FastZap only for attempt 1, so this retry
        // cannot accidentally repeat the aggressive join policy.
        let retryStandardOnSameRoute = liveAttemptSerial == 1 && liveAttemptFastJoin
        guard let base = liveBaseOptions, let url = loadedURL,
              let next = retryStandardOnSameRoute ? liveRoute : nextLiveRoute(after: liveRoute) else {
            liveRecoveryInFlight = false
            publishFailure("AetherEngine Live TV exhausted native/ingest/software routes. \(reason)")
            return
        }
        if retryStandardOnSameRoute {
            liveDiagnostic("fastJoinFallback sameRoute=\(liveRoute.label) nextJoin=standard")
        }

        startLiveAttempt(
            engine: engine,
            url: url,
            baseOptions: base,
            route: next,
            generation: expectedGeneration,
            reason: reason
        )
    }

    private func scheduleLiveRetune(engine: AetherEngine, generation expectedGeneration: UInt64, reason: String) {
        guard let url = loadedURL, let base = liveBaseOptions, loadedOptions?.isLive == true else { return }
        guard !liveRetuneInFlight else { return }

        let now = ProcessInfo.processInfo.systemUptime
        let cooldownRemaining = max(0, 20 - (now - lastLiveRetuneAt))
        // A second audio-drop/reset during cooldown is not a reason to abandon
        // recovery. Coalesce the notifications into ONE deferred retune, and
        // revalidate session ownership before touching the decoder.
        liveRetuneInFlight = true
        liveRetuneTask?.cancel()
        let route = liveRoute
        liveDiagnostic("retune queued route=\(route.label) delay=\(cooldownRemaining) reason=\(reason)")
        liveRetuneTask = Task { @MainActor [weak self, weak engine] in
            if cooldownRemaining > 0 {
                try? await Task.sleep(nanoseconds: UInt64(cooldownRemaining * 1_000_000_000))
            }
            guard !Task.isCancelled, let self, let engine,
                  self.engine === engine, self.generation == expectedGeneration,
                  self.loadedURL == url, self.loadedOptions?.isLive == true else { return }
            self.liveRetuneInFlight = false
            self.liveRetuneTask = nil
            guard self.liveRetuneCount < 3 else {
                self.liveDiagnostic("retune budget exhausted reason=\(reason) count=\(self.liveRetuneCount)")
                self.publishFailure("AetherEngine live recovery was exhausted. reason=\(reason)")
                return
            }
            self.liveRetuneCount += 1
            self.lastLiveRetuneAt = ProcessInfo.processInfo.systemUptime
            self.liveDiagnostic("retune scheduled #\(self.liveRetuneCount) route=\(route.label) reason=\(reason)")
            self.startLiveAttempt(
                engine: engine, url: url, baseOptions: base, route: route,
                generation: expectedGeneration,
                reason: "retune #\(self.liveRetuneCount): \(reason)"
            )
        }
    }


    private func liveDiagnostic(_ message: String) {
        guard loadedOptions?.isLive == true || liveBaseOptions != nil else { return }
        NSLog("[Signal][AetherLive][vBRDC383R6] %@", message)
    }

    private func publishTimeNotification(force: Bool) {
        let uptime = ProcessInfo.processInfo.systemUptime
        // vBRDC256 Phase 5: decoder clocks can publish at frame cadence. The app only
        // needs a smooth UI/session clock, not 30–60 MainActor invalidations per second.
        // Coalesce to roughly 3 Hz while still forcing duration/seek boundary updates.
        let movedEnough = abs(currentTime - lastTimeNotificationValue) >= 0.30
        guard force || movedEnough || uptime - lastTimeNotificationAt >= 0.34 else { return }
        lastTimeNotificationAt = uptime
        lastTimeNotificationValue = currentTime
        NotificationCenter.default.post(
            name: AetherBridgeNotification.time,
            object: self,
            userInfo: ["current": currentTime, "duration": duration]
        )
    }

    private func publishBufferNotification(position: Double) {
        let uptime = ProcessInfo.processInfo.systemUptime
        // Buffer progress is presentation metadata; it does not need decoder-rate
        // publication. A slower cadence removes avoidable SwiftUI/Now Playing pressure.
        // Never rebroadcast an unchanged buffer position on the VOD polling timer.
        // The former 0.8 s cadence posted identical values indefinitely while paused,
        // driving unnecessary SwiftUI/Now Playing work even after the cache stopped growing.
        let delta = abs(position - lastBufferNotificationValue)
        guard lastBufferNotificationValue < 0 || delta >= 0.25 ||
              (delta >= 0.01 && uptime - lastBufferNotificationAt >= 0.35) else { return }
        lastBufferNotificationAt = uptime
        lastBufferNotificationValue = position
        NotificationCenter.default.post(
            name: AetherBridgeNotification.buffer,
            object: self,
            userInfo: ["buffered": position, "duration": duration]
        )
    }

    private func publishBufferingNotification(_ buffering: Bool) {
        guard lastBufferingState != buffering else { return }
        lastBufferingState = buffering
        NotificationCenter.default.post(
            name: AetherBridgeNotification.buffering,
            object: self,
            userInfo: ["isBuffering": buffering]
        )
    }

    private func publishFailure(_ message: String) {
        guard !failed else { return }
        failed = true
        NotificationCenter.default.post(
            name: AetherBridgeNotification.failure,
            object: self,
            userInfo: ["message": message]
        )
    }
}

/// C ABI factory used by the app after `dlopen`. Returning an opaque retained UIView keeps
/// the app target free of any Swift symbol reference to AetherPlaybackBridge.
@_cdecl("DebridAetherCreateHostView")
public func DebridAetherCreateHostView() -> UnsafeMutableRawPointer {
    let view = MainActor.assumeIsolated { AetherPlaybackHostView(frame: .zero) }
    return Unmanaged.passRetained(view).toOpaque()
}
