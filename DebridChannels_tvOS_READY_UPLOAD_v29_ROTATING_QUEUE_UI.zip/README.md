# Debrid Channels tvOS v29 Motion Layout

Ready-to-upload GitHub repo package. The workflow recursively extracts `source_zip/DebridChannelsTVOS_Source.zip`, generates the Xcode project with XcodeGen, builds a tvOS IPA artifact, and uploads it.

v29 changes:
- New fixed-left hero card + rotating right-side queue layout.
- Press RIGHT to promote the next right-side card into the anchored left hero slot.
- Press DOWN/UP to move between rows while preserving the same layout structure.
- Preserves Stremio/Cinemeta catalog loading in Settings.
- Real-Debrid/Torbox intentionally not wired yet.
