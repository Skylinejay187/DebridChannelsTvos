Debrid Channels tvOS v64
- Focus Float animation replaces the old card switch/slide system.
- Extra visible smoke layer is enabled with lighter GPU cost.
- Debrid Channels Premium logo pulse stays off.
- Focused poster logo pulse stays always on.
- Universal device build workflow included.
