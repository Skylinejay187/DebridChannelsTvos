# Debrid Channels v998 — v997 Base, Real Subtitle Renderer Bridge

## Scope

This build keeps the v997 playback/cadence/metadata/lifecycle lineage and replaces the old one-time KSPlayer subtitle UIView scan with a real PlaybackKit-owned subtitle pipeline for main VOD.

## Embedded subtitles

- Uses the active KSPlayer subtitle track from the actual KSMEPlayer instance.
- Connects KSPlayer's decoded `SubtitleInfo` / `SubtitlePart` output to a dedicated transparent renderer.
- Supports text/ASS cues and KSPlayer-decoded bitmap subtitle images.
- Uses the exact KSPlayer current-time callback for cue timing.
- Mounts subtitles above the video surface and below the SwiftUI VOD controls.

## External subtitles

- Keeps external subtitle URLs separate from embedded KSPlayer track indexes.
- Parses the selected external subtitle with KSPlayer's `KSSubtitle` parser.
- Supports parser formats available in the pinned KSPNUVIO package, including SRT/WebVTT/ASS-style text sources.
- Cancels stale asynchronous subtitle loads when the URL, selection, or playback session changes.

## Selection behavior

- Subtitle-only selection no longer performs a same-position seek or restarts playback.
- The existing one-shot decoder flush remains limited to explicit audio-track changes.
- `Off` disables all embedded subtitle tracks, cancels external loading, clears the selected subtitle model, and removes the current visible cue immediately.
- Saved subtitle preferences are restored against the combined embedded/external menu while preserving their separate engine identities.

## Removed workaround

- Removed the class-name-based scan that tried to find hidden KSPlayer subtitle/caption/text UIViews inside the raw render hierarchy.
- The custom Debrid Channels VOD surface now owns the guaranteed subtitle renderer directly.

## Preserved

- v997 compile fix and v996 loading/metadata/timeline authority changes.
- v995 local KSPNUVIO production manifest.
- v993 FFmpeg HEVC/HDR trap patch.
- `asynchronousDecompression = false` for main VOD.
- `syncDecodeVideo = false` and `syncDecodeAudio = false`.
- v990 cadence refinements and v992 catalog lifecycle recovery.
- Existing decoded-frame queues, buffer profile, Source Intelligence limits, fallback count, VOD overlay, Live TV, trailers, and catalog layout.

## Version

- App: 1.0.526 (526)
- Top Shelf extension: 1.0.526 (526)
