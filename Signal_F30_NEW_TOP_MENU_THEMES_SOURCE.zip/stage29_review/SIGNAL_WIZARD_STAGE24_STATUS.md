# Stage 24 — Membership-aware first Settings visit

- On the first eligible Settings appearance, an authorized paid/admin user with no configured Live TV, Debrid, Torrentio or custom Stremio provider is offered Find Signal automatically.
- If authorization becomes valid while Settings is open, the same eligibility check runs.
- Existing first-run tour, restore sheet, configured users, and dismissed users are protected.
- The automatic offer is recorded once; Find Signal remains manually accessible.
- **Limitation:** This is not automatic presentation from the app root immediately after entitlement activation. Root-level integration and full tvOS compile remain outstanding.
