# Stage 27 — Cold launch and entitlement transitions

- Route existing paid/admin first-launch members into the guarded Settings wizard after the legacy onboarding completes.
- Handle trial-to-paid/admin entitlement changes even when membershipLocked does not change.
- Preserve membership gating, configured-provider detection, dismissal, and Settings-owned presentation.
- Source checks are not an Apple SDK compilation; GitHub Actions build and Apple TV tests remain outstanding.
- DebridChannels.app remains a deferred idea only.
