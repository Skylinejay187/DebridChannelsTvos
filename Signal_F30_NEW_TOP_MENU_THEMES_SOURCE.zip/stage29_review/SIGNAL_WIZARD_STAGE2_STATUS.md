# Signal Acquisition Wizard — Stage 2 source checkpoint

## Implemented
- Embedded wizard configuration inputs for Channels DVR, HDHomeRun, M3U/XMLTV, Xtream, Real-Debrid, TorBox, Premiumize, and custom Stremio manifest.
- Dedicated drafts for each selected provider; Save Connection commits to the existing app-scoped settings keys.
- Existing real connection verifier is preserved on the verification step.
- Advanced Settings fallback remains for unsupported or complex provider flows.
- Stage 1 transmitter visuals, restore flow, membership system and AetherEngine are not changed.

## Not completed
- Full tvOS compile / GitHub Actions / device tests.
- Dedicated embedded Torrentio option configuration.
- Live channel import / EPG stage event reporting.
- Transactional backup restore and detailed restore engine stage events.
- First-run entitlement-gated auto-presentation and direct entry from every Add Source button.

## Validation
- `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed.
- Syntax parsing is not tvOS typechecking or full compilation.
