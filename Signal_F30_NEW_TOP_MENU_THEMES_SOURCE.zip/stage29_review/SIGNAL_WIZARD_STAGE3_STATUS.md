# Signal Acquisition Wizard — Stage 3 source checkpoint

## Implemented in this checkpoint
- Embedded provider form now offers **Verify Signal**: save supported configuration, then move to verification and call existing `ConnectedServicesHealthClient.verifyAll()`.
- Restore UI exposes a checklist whose labels follow existing real restore engine state transitions (validation, application, history refresh), with no invented percentage.
- Existing confirmation and cancellation behavior is unchanged.

## Outstanding (do not call wizard complete)
- Full Xcode/tvOS compilation, GitHub Actions and Apple TV testing.
- Granular channel import / EPG progress events are not available in this UI.
- Detailed per-provider configuration, Torrentio embedded options, first-run entitlement gating and all Settings deep links.
- Transactional restore rollback and verified post-restore service reconnection.
- Full backend event stream and final animation polish.

## Validation
- `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed.
- Syntax parse is not full compilation or device validation.
