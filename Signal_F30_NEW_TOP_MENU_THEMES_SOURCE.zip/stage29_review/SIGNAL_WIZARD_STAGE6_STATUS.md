# Stage 6 — Torrentio controls and input validation

- Added in-wizard account-scoped Torrentio enable switches for Real-Debrid, TorBox, Premiumize and AllDebrid, backed by the existing stored toggle bindings. Unlike the other provider forms, these switches take effect immediately; this is disclosed in the UI.
- Added HTTP(S) URL syntax validation for Channels DVR, HDHomeRun, M3U, Xtream and custom Stremio addon manifest fields before saving.
- Torrentio verification now uses the existing connected-service verification flow rather than a misleading 'Save Connection' action.

## Still outstanding
- Full tvOS compilation and device testing; verification of account-toggle side effects against the existing Torrentio bridge.
- First-run entitlement gating, complete restore rollback/recovery, detailed channel/EPG progress events, and richer provider-specific configuration.
- This is NOT the final installable wizard build.

## Validation
- `swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed.
