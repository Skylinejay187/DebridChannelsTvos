# Signal F29 — Setup Center Pass 4 (source checkpoint)

Patch-forward from Pass 3. One targeted runtime-lifecycle hardening change: setup connection verification is retained as a cancellable Swift concurrency task; leaving the guided setup while verification is active cancels the request, resets the busy state, and prevents canceled results from being published. Existing restore confirmation and playback/navigation paths unchanged.

## Performance baseline and findings
- Source contains selectable `Native Smooth` (described in Settings as low-overhead default) and `Classic Spring` catalog-row motion. This is **catalog row motion**, not evidence that all grid/navigation scrolling is Apple-native.
- Prior `requestPlayerDismissal` / `teardownPlayer` guards exist in source; no evidence here of device-level lag reduction.
- No Classic dashboard removal or scroll-engine rewrite in this pass. Do not remove until A/B measurement.
- Compare native/custom scroll using tvOS Instruments: Time Profiler, SwiftUI body invalidations, Core Animation frame hitches, Allocations/Leaks, Energy Log; test 10 cycles catalog > Live TV > exit > settings > catalog, and background/foreground. Record median/p95 frame time, resident memory and live task/player counts.
- Playlist/EPG granular progress, transactional restore rollback, embedded provider credentials and full integration verification remain open.

## Validation
Swift frontend syntax parse passed for modified primary app source. ZIP integrity checked. No macOS/Xcode/tvOS SDK available here; **not** an Xcode build, GitHub Actions build or Apple TV performance verification. Do not treat the Setup Center as production-certified until those tests pass.
