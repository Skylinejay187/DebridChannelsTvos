# vBRDC383R5 — Phase 1 rollback patch

Base: vBRDC383R3 (R4 rejected). Version/build remain 1.0.1085 / 1085.

Scope only:
1. Ambient Classic/Cinematic/Heavy/Orbs/Deadlight overlay is mounted only while the Live tab is active and scene is foreground-active. Persistent LiveTVScreen may remain behind catalogs for navigation continuity, but the ambient animation view itself is removed, so its TimelineView/Canvas work cannot continue underneath catalogs or other app surfaces.
2. AetherEngine 6.89.1 fetch patch enables its existing bounded decoded-audio look-ahead/rebuffer arm on software Live sessions. Phase 1 does not enable dvrWindowSeconds/timeshift. This targets raw HDHomeRun MPEG-TS audio starvation caused by video-renderer lockstep.

Regression locks:
- No R4 top-menu changes.
- No R4 Signal-logo changes.
- No navigation/exit changes.
- VOD behavior untouched.
- FiOS native-HLS-first provider routing from R3 retained.
- Physical Apple TV verification remains authoritative; Phase 2 remains blocked.
