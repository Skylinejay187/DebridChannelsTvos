import SwiftUI

// vBRDC066: presentation-only visual system for catalog/search/media-info surfaces.
// It deliberately does not own navigation, focus, playback, catalog geometry, or metadata.
// The goal is to make the existing UI feel like one coherent "Unity" surface without
// moving rows, replacing the Live TV root, or adding heavyweight image-processing work.
enum UnityMediaVisualAccent {
    private static let palette: [Color] = [
        Color(red: 0.22, green: 0.76, blue: 1.00),
        Color(red: 0.98, green: 0.50, blue: 0.20),
        Color(red: 0.60, green: 0.42, blue: 1.00),
        Color(red: 0.20, green: 0.88, blue: 0.72),
        Color(red: 1.00, green: 0.32, blue: 0.48),
        Color(red: 0.96, green: 0.76, blue: 0.22)
    ]

    static func accent(for item: MediaItem) -> Color {
        // Never use Swift's randomized Hashable seed for appearance. This stable scalar
        // signature keeps a title's subtle accent consistent between launches/devices.
        var signature: UInt64 = 1469598103934665603
        for scalar in "\(item.title)|\(item.year)|\(item.type)".unicodeScalars {
            signature ^= UInt64(scalar.value)
            signature &*= 1099511628211
        }
        return palette[Int(signature % UInt64(palette.count))]
    }
}

struct UnityCatalogCardChrome: View {
    let item: MediaItem
    let focused: Bool
    var cornerRadius: CGFloat = 24
    var compact: Bool = false

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(focused ? 0.075 : 0.025),
                            accent.opacity(focused ? 0.045 : 0.012),
                            Color.clear,
                            Color.black.opacity(focused ? 0.05 : 0.12)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )

            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .strokeBorder(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(focused ? 0.90 : 0.18),
                            accent.opacity(focused ? 0.78 : 0.18),
                            Color.white.opacity(focused ? 0.20 : 0.07)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: focused ? (compact ? 1.8 : 2.2) : 0.8
                )

            // One restrained specular sweep makes the cards feel like a physical glass
            // object. Static gradients are intentionally used instead of perpetual shaders.
            LinearGradient(
                colors: [Color.white.opacity(focused ? 0.13 : 0.035), Color.clear, Color.clear],
                startPoint: .topLeading,
                endPoint: .center
            )
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))

            VStack(spacing: 0) {
                HStack {
                    Capsule()
                        .fill(
                            LinearGradient(
                                colors: [Color.white.opacity(focused ? 0.92 : 0.45), accent.opacity(focused ? 0.98 : 0.56)],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: focused ? (compact ? 34 : 48) : (compact ? 20 : 28), height: focused ? 3.0 : 2.0)
                        .shadow(color: accent.opacity(focused ? 0.55 : 0.10), radius: focused ? 7 : 2)
                    Spacer(minLength: 0)
                    if focused {
                        Circle()
                            .fill(Color.white.opacity(0.82))
                            .frame(width: compact ? 4 : 5, height: compact ? 4 : 5)
                            .shadow(color: accent.opacity(0.75), radius: 6)
                    }
                }
                .padding(.horizontal, compact ? 10 : 14)
                .padding(.top, compact ? 9 : 12)

                Spacer(minLength: 0)

                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [accent.opacity(focused ? 0.0 : 0.0), accent.opacity(focused ? 0.64 : 0.16), Color.white.opacity(focused ? 0.22 : 0.04), Color.clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(height: focused ? 1.4 : 0.7)
                    .padding(.horizontal, compact ? 8 : 12)
                    .padding(.bottom, compact ? 7 : 9)
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct UnityCatalogHeroAura: View {
    let item: MediaItem
    var intensity: Double = 1.0

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }

    var body: some View {
        ZStack {
            RadialGradient(
                colors: [accent.opacity(0.14 * intensity), accent.opacity(0.035 * intensity), Color.clear],
                center: .leading,
                startRadius: 10,
                endRadius: 720
            )
            RadialGradient(
                colors: [Color.white.opacity(0.035 * intensity), Color.clear],
                center: .topLeading,
                startRadius: 0,
                endRadius: 520
            )
        }
        .blendMode(.screen)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct UnityCompactFranchiseRibbon: View {
    let item: MediaItem
    let visibleItems: [MediaItem]
    let totalCount: Int
    let baseIndex: Int
    let focusedIndex: Int?

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }
    private var expanded: Bool { focusedIndex != nil }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            collapsedRibbon

            if expanded {
                expandedShelf
                    .offset(y: -82)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                    .zIndex(4)
            }
        }
        .frame(width: 808, height: 66, alignment: .bottomLeading)
        .animation(.spring(response: 0.30, dampingFraction: 0.88), value: expanded)
        .accessibilityElement(children: .contain)
    }

    private var collapsedRibbon: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(accent.opacity(expanded ? 0.22 : 0.13))
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(Color.white.opacity(0.94))
            }
            .frame(width: 42, height: 42)

            VStack(alignment: .leading, spacing: 2) {
                Text("EXPLORE THE FRANCHISE")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(1.15)
                    .foregroundStyle(.white.opacity(0.94))
                    .lineLimit(1)
                Text(totalCount == 1 ? "1 linked title" : "\(totalCount) linked titles")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.52))
                    .lineLimit(1)
            }

            Spacer(minLength: 8)

            HStack(spacing: -11) {
                ForEach(Array(visibleItems.prefix(4).enumerated()), id: \.element.id) { offset, franchiseItem in
                    ZStack {
                        Color.black.opacity(0.44)
                        RemoteImageFit(url: franchiseItem.posterURL ?? franchiseItem.landscapeURL, mode: .fill, showPlaceholder: false)
                    }
                    .frame(width: 31, height: 43)
                    .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 7, style: .continuous)
                            .stroke(Color.white.opacity(0.22), lineWidth: 0.8)
                    )
                    .rotationEffect(.degrees(Double(offset - 1) * 2.3))
                    .zIndex(Double(10 - offset))
                }
            }
            .frame(width: 98, alignment: .trailing)

            Image(systemName: expanded ? "chevron.up" : "chevron.right")
                .font(.system(size: 12, weight: .black))
                .foregroundStyle(accent.opacity(0.92))
                .frame(width: 22)
        }
        .padding(.horizontal, 12)
        .frame(width: 808, height: 62)
        .background(
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.white.opacity(expanded ? 0.085 : 0.052), accent.opacity(expanded ? 0.080 : 0.030), Color.black.opacity(0.20)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(expanded ? 0.44 : 0.16), accent.opacity(expanded ? 0.58 : 0.18), Color.white.opacity(0.05)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: expanded ? 1.5 : 0.8
                )
        )
        .shadow(color: accent.opacity(expanded ? 0.18 : 0.04), radius: expanded ? 14 : 6, y: 4)
    }

    private var expandedShelf: some View {
        HStack(spacing: 10) {
            ForEach(Array(visibleItems.enumerated()), id: \.element.id) { offset, franchiseItem in
                let absoluteIndex = baseIndex + offset
                UnityFranchiseMiniCard(
                    item: franchiseItem,
                    selected: focusedIndex == absoluteIndex,
                    accent: accent
                )
            }
        }
        .padding(10)
        .frame(width: 808, height: 132, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(Color.black.opacity(0.40))
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.34), accent.opacity(0.48), Color.white.opacity(0.06)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1.0
                )
        )
        .shadow(color: .black.opacity(0.58), radius: 24, y: 12)
        .shadow(color: accent.opacity(0.16), radius: 18, y: 4)
    }
}

private struct UnityFranchiseMiniCard: View {
    let item: MediaItem
    let selected: Bool
    let accent: Color

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black.opacity(0.42)
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill, showPlaceholder: false)
                .saturation(selected ? 1.08 : 0.90)
                .contrast(1.04)
            LinearGradient(colors: [Color.clear, Color.black.opacity(0.82)], startPoint: .center, endPoint: .bottom)

            Group {
                if let logo = item.logoURL, !logo.isEmpty {
                    RemoteImageFit(url: logo, mode: .fit, showPlaceholder: false)
                        .frame(width: 118, height: 34, alignment: .leading)
                } else {
                    Text(item.title.uppercased())
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.94))
                        .lineLimit(2)
                        .minimumScaleFactor(0.62)
                        .frame(width: 118, height: 34, alignment: .bottomLeading)
                }
            }
            .padding(9)
        }
        .frame(width: 146, height: 108)
        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .stroke(selected ? accent.opacity(0.96) : Color.white.opacity(0.10), lineWidth: selected ? 2.4 : 0.8)
        )
        .scaleEffect(selected ? 1.045 : 1.0)
        .shadow(color: selected ? accent.opacity(0.28) : .black.opacity(0.20), radius: selected ? 14 : 5, y: selected ? 6 : 2)
        .animation(.spring(response: 0.24, dampingFraction: 0.84), value: selected)
    }
}
