import SwiftUI
import AVKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack(alignment: .top) {
            switch store.selectedTab {
            case .home:
                NineSlotHome(filter: nil)
            case .movies:
                NineSlotHome(filter: "movie")
            case .shows:
                NineSlotHome(filter: "series")
            case .live:
                LiveTVPlaceholder()
            case .settings:
                SettingsScreen()
            }

            TopMenuBar()
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V59_ABSOLUTE_SNAP_GRID") }
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                HStack(spacing: 48) {
                    ForEach(AppTab.allCases) { tab in
                        Button {
                            withAnimation(.spring(response: 0.36, dampingFraction: 0.82)) {
                                store.selectedTab = tab
                            }
                        } label: {
                            VStack(spacing: 7) {
                                Text(tab.rawValue)
                                    .font(.system(size: 28, weight: .black))
                                    .foregroundStyle(store.selectedTab == tab ? Color.white : Color.white.opacity(0.72))
                                Capsule()
                                    .fill(store.selectedTab == tab ? Color.cyan : Color.clear)
                                    .frame(width: tab.rawValue.count > 6 ? 78 : 54, height: 5)
                            }
                            .scaleEffect(focusedTab == tab ? 1.10 : 1.0)
                            .shadow(color: focusedTab == tab ? .cyan.opacity(0.85) : .clear, radius: 16)
                        }
                        .buttonStyle(.plain)
                        .focused($focusedTab, equals: tab)
                    }
                }
                .position(x: geo.size.width * 0.56, y: 45)
                .focusSection()

                Button {
                    store.status = "Search UI shell selected. Search wiring is preserved for the next pass."
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(searchFocused ? Color.cyan : Color.white.opacity(0.94))
                        .scaleEffect(searchFocused ? 1.18 : 1.0)
                        .shadow(color: searchFocused ? .cyan.opacity(0.8) : .clear, radius: 16)
                }
                .buttonStyle(.plain)
                .focused($searchFocused)
                // Search sits alone on the far right, matching the approved reference.
                .position(x: geo.size.width - max(64, geo.size.width * 0.055), y: 45)
            }
            .frame(width: geo.size.width, height: 92, alignment: .top)
        }
        .frame(height: 92)
        .padding(.top, 8)
        .zIndex(999)
        .onChange(of: store.menuFocusToken) { _ in
            focusedTab = store.selectedTab
        }
    }
}

struct NineSlotHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex = 0
    @State private var selectedIndex = 0
    @FocusState private var isCanvasFocused: Bool

    var activeRows: [MediaRow] {
        let rows = store.rows
        guard let filter else { return rows }
        return rows.map { row in
            MediaRow(id: row.id, title: row.title, items: row.items.filter { $0.type.lowercased().contains(filter) })
        }.filter { !$0.items.isEmpty }
    }

    var currentRow: MediaRow {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        return rows[min(rowIndex, rows.count - 1)]
    }

    var items: [MediaItem] {
        currentRow.items.isEmpty ? CatalogStore.demoRows()[0].items : currentRow.items
    }

    var focused: MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        return items[normalized(selectedIndex)]
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                // Full-screen cinematic card board. The focused item is the large left card;
                // all logo/metadata/info is INSIDE that card, matching the reference layout.
                NineSlotDeck(items: items, selectedIndex: selectedIndex, rowTitle: currentRow.title)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

            }
            .contentShape(Rectangle())
            .focusable(true)
            .focused($isCanvasFocused)
            .onAppear { isCanvasFocused = true }
            .onMoveCommand { direction in
                switch direction {
                case .right:
                    nextItem()
                case .left:
                    previousItem()
                case .down:
                    nextRow()
                case .up:
                    if rowIndex > 0 { previousRow() } else { store.menuFocusToken += 1; isCanvasFocused = false }
                default:
                    break
                }
            }
        }
    }

    func normalized(_ value: Int) -> Int {
        guard !items.isEmpty else { return 0 }
        return (value % items.count + items.count) % items.count
    }

    func nextItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.83)) {
            selectedIndex = normalized(selectedIndex + 1)
        }
    }

    func previousItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.83)) {
            selectedIndex = normalized(selectedIndex - 1)
        }
    }

    func nextRow() {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        guard rows.count > 1 else { return }
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = min(rowIndex + 1, rows.count - 1)
            selectedIndex = 0
        }
    }

    func previousRow() {
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}


struct NineSlotDeck: View {
    let items: [MediaItem]
    let selectedIndex: Int
    let rowTitle: String
    @State private var pulse = false

    // v59 ABSOLUTE SNAP GRID:
    // No HStack/VStack flexible sizing is allowed for the main deck.
    // Every card is placed by explicit x/y coordinates from one shared grid.
    // The split line is the exact same y for left and right cards.
    // The left boxes are wider than the poster cells, but their heights are identical
    // to the top/bottom poster rows. Landscape art is clipped inside the fixed frame.
    struct Layout {
        let edge: CGFloat
        let top: CGFloat
        let gap: CGFloat
        let leftW: CGFloat
        let rowH: CGFloat
        let posterW: CGFloat
        let topY: CGFloat
        let bottomY: CGFloat
        let leftX: CGFloat
        let rightStartX: CGFloat
    }

    func layout(in size: CGSize) -> Layout {
        let W = size.width
        let H = size.height

        let edge = max(28, min(W, H) * 0.020)
        let top = max(112, H * 0.122)
        let bottom = max(24, H * 0.030)
        let gap = max(14, min(W, H) * 0.014)

        let boardW = W - edge * 2
        let boardH = H - top - bottom
        let rowH = max(180, (boardH - gap) / 2)

        // The right grid owns 4 poster columns. The left split card is intentionally
        // wider than two poster columns so it matches the approved mockup, while still
        // sharing the same row heights. This also makes the right cards slightly smaller
        // so the far-right column does not crowd or overflow.
        let leftRatio: CGFloat = 2.72
        let posterW = max(90, (boardW - gap * 5) / (leftRatio + 4.0))
        let leftW = posterW * leftRatio

        let topY = top + rowH / 2
        let bottomY = top + rowH + gap + rowH / 2
        let leftX = edge + leftW / 2
        let rightStartX = edge + leftW + gap

        return Layout(edge: edge, top: top, gap: gap, leftW: leftW, rowH: rowH, posterW: posterW, topY: topY, bottomY: bottomY, leftX: leftX, rightStartX: rightStartX)
    }

    var body: some View {
        GeometryReader { geo in
            let L = layout(in: geo.size)

            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                BrandMark(pulse: pulse)
                    .frame(width: min(geo.size.width * 0.17, 320), height: 74)
                    .position(x: L.edge + min(geo.size.width * 0.17, 320) / 2, y: 48)
                    .zIndex(130)

                // LEFT TOP: fixed-width landscape hero. Same height as every right poster.
                LandscapeHeroCard(item: itemFor(0), rowTitle: rowTitle, pulse: pulse)
                    .frame(width: L.leftW, height: L.rowH)
                    .clipped()
                    .position(x: L.leftX, y: L.topY)
                    .zIndex(70)

                // LEFT BOTTOM: fixed-width Continue Watching. Same size as top-left.
                ContinueWatchingCard(item: itemFor(0), pulse: pulse)
                    .frame(width: L.leftW, height: L.rowH)
                    .clipped()
                    .position(x: L.leftX, y: L.bottomY)
                    .zIndex(65)

                // RIGHT SIDE: 4 x 2 poster grid, explicit coordinates, equal heights.
                ForEach(1...8, id: \.self) { slot in
                    let col = (slot - 1) % 4
                    let row = (slot - 1) / 4
                    let x = L.rightStartX + CGFloat(col) * (L.posterW + L.gap) + L.posterW / 2
                    let y = row == 0 ? L.topY : L.bottomY
                    PosterQueueCard(item: itemFor(slot))
                        .frame(width: L.posterW, height: L.rowH)
                        .clipped()
                        .position(x: x, y: y)
                        .zIndex(60)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.35).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
        }
    }

    func itemFor(_ slot: Int) -> MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        let index = (selectedIndex + slot) % items.count
        return items[index]
    }
}

struct BrandMark: View {
    let pulse: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "waveform.path.ecg")
                .font(.system(size: 42, weight: .bold))
                .foregroundStyle(Color.cyan)
                .shadow(color: .cyan.opacity(pulse ? 0.88 : 0.36), radius: pulse ? 18 : 6)
            VStack(alignment: .leading, spacing: -2) {
                Text("DEBRID")
                    .font(.system(size: 32, weight: .black))
                Text("CHANNELS")
                    .font(.system(size: 25, weight: .black))
                    .foregroundStyle(Color.cyan)
                Text("PREMIUM")
                    .font(.system(size: 13, weight: .bold))
                    .tracking(8)
                    .foregroundStyle(.white.opacity(0.68))
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .scaleEffect(pulse ? 1.015 : 1.0)
        .allowsHitTesting(false)
    }
}

struct LandscapeHeroCard: View {
    let item: MediaItem
    let rowTitle: String
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            HeroLandscapeArtwork(item: item)
                .overlay(
                    ZStack {
                        LinearGradient(colors: [.black.opacity(0.64), .black.opacity(0.12), .clear], startPoint: .leading, endPoint: .trailing)
                        LinearGradient(colors: [.clear, .black.opacity(0.48)], startPoint: .top, endPoint: .bottom)
                    }
                )

            VStack(alignment: .leading, spacing: 10) {
                HeroLogoText(item: item, pulse: pulse)
                    .frame(maxWidth: 360, maxHeight: 88, alignment: .leading)
                    .padding(.bottom, 8)

                HStack(spacing: 10) {
                    Text(item.year)
                    Text("•")
                    Text(item.type.capitalized)
                    Text("•")
                    Text(item.catalog.isEmpty ? rowTitle : item.catalog)
                }
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white.opacity(0.93))

                HStack(spacing: 10) {
                    ForEach(item.genres.prefix(2), id: \.self) { genre in
                        Text(genre)
                            .font(.system(size: 13, weight: .bold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.42)))
                            .overlay(Capsule().stroke(.white.opacity(0.14), lineWidth: 1))
                    }
                }

                HStack(spacing: 14) {
                    Text("IMDb")
                        .font(.system(size: 16, weight: .black))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.yellow))
                    Text(item.rating)
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(.white)
                }

                Text(item.description)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(3)
                    .frame(maxWidth: 560, alignment: .leading)
            }
            .padding(.leading, 28)
            .padding(.bottom, 22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .overlay(
            RoundedRectangle(cornerRadius: 28)
                .stroke(Color.cyan.opacity(pulse ? 1.0 : 0.72), lineWidth: 4)
        )
        .shadow(color: .cyan.opacity(pulse ? 0.72 : 0.30), radius: pulse ? 30 : 16)
    }
}

struct HeroLandscapeArtwork: View {
    let item: MediaItem

    private var url: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
            RemoteImageFit(url: url, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .clipped()
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    let pulse: Bool

    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 13 ? 40 : 58, weight: .black, design: .rounded))
                    .italic()
                    .minimumScaleFactor(0.38)
                    .lineLimit(2)
                    .foregroundStyle(LinearGradient(colors: [.white, .cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
        }
        .shadow(color: .cyan.opacity(pulse ? 0.92 : 0.32), radius: pulse ? 18 : 7)
        .scaleEffect(pulse ? 1.018 : 1.0)
    }
}

struct ContinueWatchingCard: View {
    let item: MediaItem
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // For now this uses landscape artwork as a last-scene preview placeholder.
            // When resume capture is wired, this same card will load the real saved frame thumbnail.
            HeroLandscapeArtwork(item: item)
                .overlay(Color.black.opacity(0.22))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom))

            Image(systemName: "play.circle.fill")
                .font(.system(size: 84, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .shadow(color: .black.opacity(0.85), radius: 8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            VStack(alignment: .leading, spacing: 8) {
                Text("Continue Watching")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(Color.cyan)
                HStack {
                    Text(item.title)
                        .font(.system(size: 20, weight: .bold))
                        .lineLimit(1)
                    Spacer()
                    Text("35m left")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundStyle(.white)

                GeometryReader { proxy in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.18))
                        Capsule().fill(Color.cyan).frame(width: proxy.size.width * 0.62)
                    }
                }
                .frame(height: 8)
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .shadow(color: .black.opacity(0.75), radius: 18)
    }
}

struct PosterQueueCard: View {
    let item: MediaItem

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .gray.opacity(0.16)], startPoint: .top, endPoint: .bottom)
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.13), lineWidth: 1))
        .shadow(color: .black.opacity(0.68), radius: 14)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @FocusState private var focused: SettingsFocus?

    enum SettingsFocus: Hashable { case manifest, load, reset, home, movies, shows, live }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .black, .orange.opacity(0.16)], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 24) {
                Text("Settings")
                    .font(.system(size: 62, weight: .black))
                    .foregroundStyle(.white)
                    .padding(.top, 132)

                VStack(alignment: .leading, spacing: 18) {
                    Text("Stremio Catalog Manifest")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)

                    TextField("Manifest URL", text: $manifestURL)
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(22)
                        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
                        .focused($focused, equals: .manifest)
                        .frame(width: 1180)

                    HStack(spacing: 18) {
                        SettingsButton(title: store.isLoading ? "Loading..." : "Load Catalog", focus: .load, focused: $focused) {
                            Task { await store.loadManifest(urlString: manifestURL) }
                        }
                        SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                            store.resetDemo()
                        }
                    }

                    Text("Build v59 ABSOLUTE SNAP GRID")
                        .font(.system(size: 22, weight: .black))
                        .foregroundStyle(Color.cyan)
                    Text(store.status)
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .frame(width: 1180, alignment: .leading)
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                VStack(alignment: .leading, spacing: 14) {
                    Text("Quick Navigation")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)
                    HStack(spacing: 18) {
                        SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                        SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                        SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                        SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
                    }
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                Spacer()
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
        }
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct LiveTVPlaceholder: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 24) {
                Text("Live TV")
                    .font(.system(size: 76, weight: .black))
                Text("Live TV layout is preserved for the next native tvOS guide pass.")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            }
            .foregroundStyle(.white)
        }
    }
}
