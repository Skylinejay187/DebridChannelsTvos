# DebridChannels tvOS v56

Half-split geometry fix: left column is two equal locked boxes; top landscape cannot stretch; right grid remains 4x2 portrait.
