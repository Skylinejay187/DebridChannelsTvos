import SwiftUI
import AVFoundation
import AVKit

#if canImport(TVVLCKit)
import TVVLCKit
#endif

// v95 universal-codec boundary:
// - AVFoundation remains the fast/default Apple-native path.
// - TVVLCKit is used automatically when the framework is present and the URL/container
//   looks like an MKV/DTS/unsupported-codec edge case.
// - Raw magnet/torrent streaming still requires a separate torrent framework/service;
//   this file exposes diagnostics so the app does not claim a magnet is directly playable.

enum UniversalCodecSupport {
    static let buildMarker = "DEBRID_CHANNELS_TVOS_BUILD_V116_NATIVE_PIPELINE_CAREFUL_REBUILD"

    static var vlcCompiledIn: Bool {
        #if canImport(TVVLCKit)
        return true
        #else
        return false
        #endif
    }

    static func shouldPreferVLC(for url: URL, hint: String = "") -> Bool {
        let value = (url.absoluteString + " " + hint).lowercased()
        if value.hasPrefix("magnet:") { return false }

        // Known Apple-native paths should stay on AVFoundation/AVKit first. This preserves the
        // Apple TV hardware decode, HDR/Dolby Vision, and frame-pacing path whenever the stream is
        // in an Apple-friendly container.
        if value.contains(".m3u8") || value.contains("application/vnd.apple.mpegurl") { return false }
        if value.contains(".mp4") || value.contains("%2emp4") || value.contains(".m4v") || value.contains("%2em4v") || value.contains(".mov") || value.contains("%2emov") { return false }

        // Known non-Apple or often-problematic direct-file containers/codecs should enter VLC
        // immediately. Previously these still opened in AV first, causing audio-only/no-video.
        let vlcContainerHints = [
            ".mkv", "%2emkv", "matroska", ".avi", "%2eavi", ".webm", "%2ewebm",
            ".ts", "%2ets", ".m2ts", "%2em2ts", ".mts", "%2emts", ".vob", "%2evob"
        ]
        let vlcCodecHints = [
            " dts", "dts-hd", "dtshd", "truehd", "mlp", "eac3 7.1", "atmos truehd",
            "vp9", "av1", "profile 7", "dvhe.07", "dolby vision profile 7"
        ]
        return vlcContainerHints.contains { value.contains($0) }
            || vlcCodecHints.contains { value.contains($0) }
    }

    static func playbackEngineName(for url: URL, hint: String = "") -> String {
        if shouldPreferVLC(for: url, hint: hint) && vlcCompiledIn { return "TVVLCKit/libVLC fallback" }
        if shouldPreferVLC(for: url, hint: hint) && !vlcCompiledIn { return "AVFoundation fallback; TVVLCKit pod missing" }
        return "AVFoundation hardware path"
    }

    static func magnetDiagnostic(for value: String) -> String? {
        let lower = value.lowercased()
        guard lower.hasPrefix("magnet:") || lower.contains("infohash") else { return nil }
        return "Magnet/infoHash items require the torrent framework/service path before playback. Direct TorBox/debrid HTTP(S) stream URLs play in-app; raw torrent streaming is isolated from AVFoundation."
    }
}

struct UniversalVideoSurface: View {
    let url: URL
    let avPlayer: AVPlayer?
    let videoGravity: AVLayerVideoGravity
    var forceVLC: Bool = false
    var routeHint: String = ""
    var vlcShouldPlay: Bool = true
    var vlcSeekSerial: Int = 0
    var vlcSeekSeconds: Double = 0

    var body: some View {
        Group {
            #if canImport(TVVLCKit)
            // v112: true dual internal render path. AVKit is the native Apple hardware/HDR path;
            // TVVLCKit is the embedded fallback path for containers/codecs that AVKit cannot render.
            // The Debrid Channels VOD overlay is drawn above either surface by VODPlayerScreen.
            if forceVLC {
                TVVLCKitVideoSurface(url: url, shouldPlay: vlcShouldPlay, seekSerial: vlcSeekSerial, seekSeconds: vlcSeekSeconds)
            } else {
                AVPlayerControllerSurface(player: avPlayer, videoGravity: videoGravity)
            }
            #else
            AVPlayerControllerSurface(player: avPlayer, videoGravity: videoGravity)
            #endif
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
    }
}

#if canImport(TVVLCKit)
struct TVVLCKitVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double

    final class Coordinator {
        let player = VLCMediaPlayer()
        var currentURL: URL?
        var lastSeekSerial: Int = 0
    }

    final class VLCView: UIView {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> VLCView {
        let view = VLCView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: VLCView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func configure(view: VLCView, coordinator: Coordinator) {
        if coordinator.currentURL != url {
            coordinator.currentURL = url
            coordinator.lastSeekSerial = seekSerial
            coordinator.player.drawable = view
            coordinator.player.media = VLCMedia(url: url)
            if shouldPlay { coordinator.player.play() }
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = max(0, coordinator.player.time.intValue + Int32(seekSeconds * 1000.0))
            coordinator.player.time = VLCTime(int: target)
        }

        if shouldPlay {
            if !coordinator.player.isPlaying { coordinator.player.play() }
        } else {
            if coordinator.player.isPlaying { coordinator.player.pause() }
        }
    }

    static func dismantleUIView(_ uiView: VLCView, coordinator: Coordinator) {
        coordinator.player.stop()
    }
}
#endif


// v106: AVPlayerViewController-backed surface used only as a rendering container.
// Apple transport controls remain disabled; Debrid Channels draws its own overlay.
// resizeAspect is the default so video keeps the source aspect ratio and does not crop/stretch.
struct AVPlayerControllerSurface: UIViewControllerRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player {
            controller.player = player
        }
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.player = nil
    }
}
