# vBRDC299 — Top Shelf / Grid compile fix

- Version: 1.0.1002 (1002)
- Baseline: vBRDC298.
- Fixes the GitHub/Xcode compiler error in `DebridChannelsTVOSApp.swift` where a non-optional `URLResponse` returned by `URLSession.data(for:)` was incorrectly used with optional binding (`if let response`).
- No UI, scrolling, poster-cache, playback, preview, Top Shelf, Grid Peek, or player-selection behavior was otherwise changed in this patch.
