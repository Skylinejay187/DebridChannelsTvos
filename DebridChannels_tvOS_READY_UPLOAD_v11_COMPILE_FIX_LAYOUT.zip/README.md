# Debrid Channels tvOS v0.11 Ready Upload Package

Upload this zip to GitHub and run: `00 Build tvOS IPA From Source ZIP`.

Fixes:
- Swift compile errors in RemoteImage and CatalogStore actor access.
- Landscape poster/card defaults.
- Basic Layout Editor controls for row cards, logo text, card text, spacing, focus scale, and hero height.
- Catalog/Stremio artwork wiring remains enabled.
- RD/Torbox remains intentionally disabled for now.
