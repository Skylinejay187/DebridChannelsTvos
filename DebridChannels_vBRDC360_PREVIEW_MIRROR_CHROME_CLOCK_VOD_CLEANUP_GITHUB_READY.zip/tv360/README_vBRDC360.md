# vBRDC360 — Preview Mirror Catalog Chrome + Clock + VOD Overlay Cleanup

Patch-forward base: vBRDC359 (itself patched only from uploaded vBRDC358B).

- Fix Preview Mirror catalog/detail overlay chrome leakage when selectedTab changes away from Live TV.
- Suppress the still-mounted Preview Mirror header/footer while catalog/detail layers own the screen.
- Live clock now uses TimelineView wall-clock updates every second instead of a 30-second Combine timer.
- Preview Mirror footer now shows UP NEXT only; NOW ON AIR/channel label removed.
- VOD overlay Player Engine chip removed; engine ownership remains internal and Aether behavior is unchanged.
- Removed generated cache/junk files only; no speculative playback-source deletion.
- Version 1.0.1062 / build 1062.
