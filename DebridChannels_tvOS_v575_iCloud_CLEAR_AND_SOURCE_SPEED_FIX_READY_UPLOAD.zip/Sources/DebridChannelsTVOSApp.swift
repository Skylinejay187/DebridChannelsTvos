import SwiftUI
import AVKit
import AVFoundation
import Combine
import UIKit
import CoreImage.CIFilterBuiltins

private func streamStatusText(_ message: String) -> String {
    let trimmed = message.trimmingCharacters(in: .whitespacesAndNewlines)
    let lower = trimmed.lowercased()
    if trimmed.isEmpty || lower.contains("trailer resolver") || lower.contains("resolving trailer") || lower == "trailer ready." || lower.contains("split video/audio") {
        return ""
    }
    return trimmed
}

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct StaticAppBackground: View {
    var body: some View {
        ZStack {
            Color.black
            LinearGradient(
                colors: [Color.black.opacity(0.96), Color(red: 0.018, green: 0.022, blue: 0.028), Color.black.opacity(0.98)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

struct HomeArtworkBackground: View {
    let item: MediaItem

    private var backgroundURL: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black
            RemoteImageFit(url: backgroundURL, mode: .fill)
                .ignoresSafeArea()
                .scaleEffect(1.01)
                .opacity(0.86)
                .saturation(1.08)
                .contrast(1.04)
            // Keep the home readable without blurring or washing out the selected artwork.
            LinearGradient(
                colors: [Color.black.opacity(0.58), Color.black.opacity(0.28), Color.black.opacity(0.72)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
    }
}


struct PreviewAwareHomeBackground: View {
    let item: MediaItem
    let previewActive: Bool

    var body: some View {
        ZStack {
            // Static clean background.
            Color.clear
            if previewActive, let preview = item.previewURL, let url = URL(string: preview) {
                SilentVideoBackground(url: url)
                    .ignoresSafeArea()
                    .opacity(0.94)
                    .overlay(Color.black.opacity(0.30))
                    .transition(.opacity.animation(.easeInOut(duration: 0.35)))
            }
        }
        .ignoresSafeArea()
    }
}

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL
    var isMuted: Bool = true

    final class Coordinator {
        var player: AVPlayer?
        var endObserver: NSObjectProtocol?

        func configure(url: URL, isMuted: Bool, controller: AVPlayerViewController) {
            if let current = player?.currentItem?.asset as? AVURLAsset, current.url == url {
                player?.isMuted = isMuted
                player?.volume = isMuted ? 0.0 : 1.0
                controller.player = player
                controller.showsPlaybackControls = false
                controller.videoGravity = .resizeAspectFill
                player?.play()
                return
            }

            cleanup()

            let item = AVPlayerItem(url: url)
            let nextPlayer = AVPlayer(playerItem: item)
            nextPlayer.isMuted = isMuted
            nextPlayer.volume = isMuted ? 0.0 : 1.0
            item.preferredForwardBufferDuration = isMuted ? 0.0 : 1.0
            controller.player = nextPlayer
            controller.showsPlaybackControls = false
            controller.videoGravity = .resizeAspectFill
            endObserver = NotificationCenter.default.addObserver(
                forName: .AVPlayerItemDidPlayToEndTime,
                object: item,
                queue: .main
            ) { [weak nextPlayer] _ in
                nextPlayer?.seek(to: .zero)
                nextPlayer?.play()
            }
            player = nextPlayer
            nextPlayer.play()
        }

        func cleanup() {
            if let endObserver {
                NotificationCenter.default.removeObserver(endObserver)
                self.endObserver = nil
            }
            player?.pause()
            player?.replaceCurrentItem(with: nil)
            player = nil
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        context.coordinator.configure(url: url, isMuted: isMuted, controller: controller)
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        context.coordinator.configure(url: url, isMuted: isMuted, controller: controller)
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: Coordinator) {
        coordinator.cleanup()
        controller.player = nil
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    @State private var didRequestDefaultCatalogLoad = false
    @AppStorage("hasSeenFirstRunOnboarding") private var hasSeenFirstRunOnboarding: Bool = false

    private var onboardingActive: Bool {
        !hasSeenFirstRunOnboarding && store.playbackURL == nil
    }

    var body: some View {
        ZStack(alignment: .top) {
            // v220: Careful slot-panel rebuild approach. Live TV grid remains the main surface,
            // the normal top menu is restored, and Movies/Shows/Home open as focus-owned overlay shelves.
            // The left quick controls are completely off-screen until LEFT is pressed on the first grid column.
            if store.selectedTab == .settings {
                SettingsScreen()
                    .disabled(onboardingActive)
                    .allowsHitTesting(!onboardingActive)
            } else if store.selectedTab == .membership {
                MembershipScreen()
                    .disabled(onboardingActive)
                    .allowsHitTesting(!onboardingActive)
                    .zIndex(4300)
            } else if store.selectedTab == .sports {
                SportsHubScreen()
                    .disabled(onboardingActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                    .allowsHitTesting(!(onboardingActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil))
            } else if store.selectedTab == .favorites {
                GlobalFavoritesScreen()
                    .disabled(onboardingActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                    .allowsHitTesting(!(onboardingActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil))
            } else {
                let catalogOverlayActive = (store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows)
                LiveTVScreen()
                    .disabled(onboardingActive || catalogOverlayActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                    .allowsHitTesting(!(onboardingActive || catalogOverlayActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil))
                if catalogOverlayActive {
                    GridOSCatalogOverlay(filter: store.selectedTab == .movies ? "movie" : (store.selectedTab == .shows ? "series" : nil))
                        .disabled(onboardingActive || store.selectedDetail != nil || store.searchActive || store.playbackURL != nil)
                        .allowsHitTesting(!onboardingActive && store.selectedDetail == nil && !store.searchActive && store.playbackURL == nil)
                        .zIndex(4200)
                }
            }

            // v535: keep the top menu visible/reachable on Sports even if a stale Live TV quick-panel flag is still true.
            // Sports owns no playback quick panel, so this state must not hide global navigation.
            if store.playbackURL == nil && !store.searchActive && store.selectedDetail == nil && store.selectedTab != .sports && (!store.liveQuickPanelOpen || store.selectedTab == .favorites) {
                TopMenuBar()
                    .disabled(onboardingActive)
                    .allowsHitTesting(!onboardingActive)
                    .zIndex(6100)
            }

            if let detail = store.selectedDetail {
                MediaInfoPopup(item: detail)
                    .zIndex(5500)
            }

            if store.searchActive && store.playbackURL == nil {
                GlobalSearchScreen()
                    .zIndex(5000)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .id(url.absoluteString)
                    .zIndex(9000)
            }

            if onboardingActive {
                FirstRunOnboardingOverlay(isVisible: $hasSeenFirstRunOnboarding)
                    .zIndex(9800)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V460_ONBOARDING_REAL_GUIDE_STEP") }
        .task {
            guard !didRequestDefaultCatalogLoad else { return }
            didRequestDefaultCatalogLoad = true
            await store.loadAllManifests()
        }
    }
}


struct FirstRunOnboardingOverlay: View {
    @EnvironmentObject var store: CatalogStore
    @Binding var isVisible: Bool
    @State private var page: Int = 0
    @FocusState private var focusedAction: OnboardingAction?

    private enum OnboardingAction: Hashable { case skip, next }

    private struct TourPage {
        let title: String
        let body: String
        let targetTitle: String
        let targetSubtitle: String
        let arrow: String
        let tab: AppTab
        let targetX: CGFloat
        let targetY: CGFloat
        let targetWidth: CGFloat
        let targetHeight: CGFloat
        let bubbleX: CGFloat
        let bubbleY: CGFloat
        let rotation: Double
    }

    // v460: real-app guided tour now prioritizes daily-use app sections.
    // Artwork Providers remain visible in Settings, but the first-run tour teaches Grid -> Guide -> Favorites.
    private let pages: [TourPage] = [
        TourPage(title: "Welcome to Debrid Channels", body: "Movies, Shows, Sports, Live TV, trailers, favorites, memberships, and device management in one TV-first experience.", targetTitle: "Start Here", targetSubtitle: "Press Continue to tour the real app.", arrow: "➜", tab: .live, targetX: 960, targetY: 540, targetWidth: 760, targetHeight: 220, bubbleX: 960, bubbleY: 540, rotation: -2),
        TourPage(title: "Top Menu", body: "Move across the top row to jump between Home, Movies, TV Shows, Sports, Live TV, Membership, and Settings.", targetTitle: "Top Menu", targetSubtitle: "Your main navigation stays here.", arrow: "↑", tab: .live, targetX: 885, targetY: 60, targetWidth: 780, targetHeight: 78, bubbleX: 570, bubbleY: 170, rotation: -2),
        TourPage(title: "Streaming Catalogs", body: "Movies and TV Shows come from Stremio-compatible catalogs first. TMDB is optional for richer artwork and details.", targetTitle: "Streaming Catalogs", targetSubtitle: "Browse real poster rows here.", arrow: "↙", tab: .movies, targetX: 430, targetY: 760, targetWidth: 0, targetHeight: 0, bubbleX: 430, bubbleY: 600, rotation: -2),
        TourPage(title: "Artwork Providers", body: "Add your own TMDB API key in Settings → Metadata & Artwork for the best movie/show posters, backdrops, and Xtream Now Playing artwork. The app still works without it, but TMDB makes Live TV cards look premium.", targetTitle: "TMDB Key", targetSubtitle: "Optional, but strongly recommended for Xtream posters.", arrow: "↘", tab: .settings, targetX: 520, targetY: 390, targetWidth: 500, targetHeight: 160, bubbleX: 770, bubbleY: 260, rotation: 2),
        TourPage(title: "Follow Center", body: "Follow TV shows so the backend can verify real new-episode air dates from online sources. Home alerts only appear when episode, season, and air date are confirmed.", targetTitle: "Verified Alerts", targetSubtitle: "No fake episode alerts.", arrow: "↙", tab: .home, targetX: 500, targetY: 430, targetWidth: 0, targetHeight: 0, bubbleX: 620, bubbleY: 280, rotation: -2),
        TourPage(title: "Live TV", body: "Live TV opens to the real channel grid. LEFT opens the hidden panel from the edge, and RIGHT opens the full guide.", targetTitle: "Live TV Grid", targetSubtitle: "Your real channel grid lives here.", arrow: "↓", tab: .live, targetX: 950, targetY: 520, targetWidth: 0, targetHeight: 0, bubbleX: 460, bubbleY: 225, rotation: 2),
        TourPage(title: "Full Guide", body: "Press RIGHT from the Live TV grid to open the full guide. Press LEFT to return to the grid.", targetTitle: "Full Guide", targetSubtitle: "Browse schedules, programs, and live preview here.", arrow: "↘", tab: .live, targetX: 960, targetY: 520, targetWidth: 0, targetHeight: 0, bubbleX: 455, bubbleY: 235, rotation: -2),
        TourPage(title: "Guide Tools", body: "From the first Live TV grid card, press LEFT twice to open Guide Tools. Use it for categories, Force Refresh Guide, Add to My Favorites, Add to Sports, and manual sports-channel actions.", targetTitle: "Left Guide Tools", targetSubtitle: "Press LEFT from the grid edge to reveal it.", arrow: "↙", tab: .live, targetX: 120, targetY: 520, targetWidth: 0, targetHeight: 0, bubbleX: 520, bubbleY: 295, rotation: -2),
        TourPage(title: "Membership", body: "Your 24-hour trial starts automatically. Use Membership to upgrade, restore, or manage devices.", targetTitle: "Membership", targetSubtitle: "Supporter, Lifetime, Restore, and devices.", arrow: "↓", tab: .membership, targetX: 960, targetY: 470, targetWidth: 0, targetHeight: 0, bubbleX: 520, bubbleY: 205, rotation: -2),
        TourPage(title: "My Favorites", body: "Hold Select on a Live TV grid card or guide channel. A small action appears so you can add or remove that channel from My Favorites.", targetTitle: "My Favorites", targetSubtitle: "Hold Select → Add to My Favorites.", arrow: "↙", tab: .live, targetX: 310, targetY: 450, targetWidth: 0, targetHeight: 0, bubbleX: 590, bubbleY: 270, rotation: -2),
        TourPage(title: "Ready to Watch", body: "You're ready. You can replay this guide later from Settings.", targetTitle: "Setup Complete", targetSubtitle: "Enjoy Debrid Channels.", arrow: "➜", tab: .live, targetX: 960, targetY: 540, targetWidth: 760, targetHeight: 220, bubbleX: 960, bubbleY: 540, rotation: 1)
    ]

    private var current: TourPage { pages[min(max(page, 0), pages.count - 1)] }
    private var isWelcome: Bool { page == 0 }
    private var isDone: Bool { page == pages.count - 1 }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(isWelcome || isDone ? 0.92 : 0.58)
                    .ignoresSafeArea()
                    .allowsHitTesting(true)

                if isWelcome || isDone {
                    welcomeCard
                        .position(x: geo.size.width / 2, y: geo.size.height / 2)
                        .zIndex(5)
                } else {
                    comicSpeechBubble
                        .position(x: current.bubbleX, y: current.bubbleY)
                        .rotationEffect(.degrees(current.rotation))
                        .zIndex(4)
                    if current.title == "My Favorites" {
                        favoritesDemoToast
                            .position(x: geo.size.width / 2, y: geo.size.height * 0.47)
                            .zIndex(5)
                    }
                    if current.title == "Guide Tools" {
                        guideToolsDemoToast
                            .position(x: 350, y: geo.size.height * 0.52)
                            .zIndex(5)
                    }
                    guidedFooter
                        .position(x: geo.size.width / 2, y: geo.size.height - 135)
                        .zIndex(6)
                }
            }
        }
        .onAppear {
            store.onboardingTourActive = true
            focusedAction = .next
            applyRealAppRoute()
        }
        .onChange(of: page) { _ in
            focusedAction = .next
            applyRealAppRoute()
        }
        .onMoveCommand { direction in
            switch direction {
            case .left: focusedAction = .skip
            case .right: focusedAction = .next
            default: break
            }
        }
        .onExitCommand { }
        .onDisappear { store.onboardingTourActive = false; store.onboardingForceFullGuide = false }
        .transition(.opacity)
    }

    private func applyRealAppRoute() {
        store.searchActive = false
        store.selectedDetail = nil
        store.detailBackStack.removeAll()
        store.onboardingForceFullGuide = current.title == "Full Guide"
        withAnimation(.easeInOut(duration: 0.32)) {
            store.selectedTab = current.tab
        }
    }

    private var welcomeCard: some View {
        VStack(spacing: 24) {
            Text(current.title)
                .font(.system(size: isDone ? 64 : 58, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
            Text(current.body)
                .font(.system(size: 28, weight: .heavy, design: .rounded))
                .foregroundStyle(.white.opacity(0.84))
                .multilineTextAlignment(.center)
                .frame(width: 900)
            if !isDone {
                Text("BOOM! Let's tour the real app.")
                    .font(.system(size: 36, weight: .black, design: .rounded))
                    .foregroundStyle(.black)
                    .padding(.horizontal, 34)
                    .padding(.vertical, 16)
                    .background(Capsule().fill(Color.orange).overlay(Capsule().stroke(Color.white, lineWidth: 4)))
                    .rotationEffect(.degrees(-3))
                    .padding(.top, 8)
            }
            Spacer().frame(height: 54)
            actionRow
            progressDots
        }
        .frame(width: 1180, height: 650)
        .background(RoundedRectangle(cornerRadius: 44).fill(LinearGradient(colors: [Color.black.opacity(0.97), Color(red: 0.10, green: 0.05, blue: 0.015).opacity(0.97)], startPoint: .topLeading, endPoint: .bottomTrailing)))
        .overlay(RoundedRectangle(cornerRadius: 44).stroke(Color.orange.opacity(0.72), lineWidth: 4))
        .shadow(color: .orange.opacity(0.28), radius: 52)
    }

    // v459: no target rectangle/glow at all. The bubble and arrow should not obscure
    // the real app sections or cause the guided tour to look like a crop/ZIP outline.
    private var softTargetGlow: some View {
        Color.clear.frame(width: 0, height: 0).allowsHitTesting(false)
    }


    private var comicSpeechBubble: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("\(current.arrow)  \(current.targetTitle)")
                .font(.system(size: 38, weight: .black, design: .rounded))
                .foregroundStyle(.black)
            Text(current.targetSubtitle)
                .font(.system(size: 22, weight: .heavy, design: .rounded))
                .foregroundStyle(.black.opacity(0.82))
                .frame(width: 460, alignment: .leading)
        }
        .padding(.horizontal, 30)
        .padding(.vertical, 22)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.orange).overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white, lineWidth: 5)))
        .shadow(color: .orange.opacity(0.48), radius: 24)
    }


    private var favoritesDemoToast: some View {
        VStack(spacing: 10) {
            Text("Hold Select on any channel")
                .font(.system(size: 30, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            HStack(spacing: 14) {
                Text("＋")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                    .foregroundStyle(.black)
                    .frame(width: 54, height: 54)
                    .background(Circle().fill(Color.orange))
                VStack(alignment: .leading, spacing: 2) {
                    Text("Add to My Favorites")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Example action shown during setup")
                        .font(.system(size: 20, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white.opacity(0.72))
                }
            }
            .padding(.horizontal, 28)
            .padding(.vertical, 18)
            .background(RoundedRectangle(cornerRadius: 22).fill(Color.black.opacity(0.90)))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.orange.opacity(0.82), lineWidth: 3))
            .shadow(color: .orange.opacity(0.35), radius: 22)
        }
        .allowsHitTesting(false)
    }

    private var guideToolsDemoToast: some View {
        HStack(alignment: .top, spacing: 18) {
            VStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.18)).frame(width: 36, height: 72)
                Circle().fill(Color.cyan.opacity(0.95)).frame(width: 22, height: 22)
                RoundedRectangle(cornerRadius: 6).fill(Color.white.opacity(0.18)).frame(width: 36, height: 72)
            }
            VStack(alignment: .leading, spacing: 10) {
                Text("GUIDE TOOLS")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Press LEFT twice from the first grid card")
                    .font(.system(size: 17, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                Label("Force Refresh Guide", systemImage: "arrow.clockwise")
                Label("Add to My Favorites", systemImage: "star.fill")
                Label("Add to Sports", systemImage: "sportscourt.fill")
            }
            .font(.system(size: 17, weight: .black, design: .rounded))
            .foregroundStyle(.white)
        }
        .padding(24)
        .background(RoundedRectangle(cornerRadius: 26).fill(Color.black.opacity(0.92)))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.orange.opacity(0.82), lineWidth: 3))
        .shadow(color: .orange.opacity(0.30), radius: 24)
        .allowsHitTesting(false)
    }

    private var guidedFooter: some View {
        VStack(spacing: 16) {
            Text(current.body)
                .font(.system(size: 25, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .frame(width: 1040)
            actionRow
            progressDots
        }
        .padding(.vertical, 20)
        .padding(.horizontal, 28)
        .frame(width: 1180)
        .background(RoundedRectangle(cornerRadius: 30).fill(Color.black.opacity(0.86)))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.14), lineWidth: 1))
    }

    private var actionRow: some View {
        HStack(spacing: 24) {
            onboardingButton("Skip Setup", action: .skip) { store.onboardingTourActive = false; store.onboardingForceFullGuide = false; isVisible = true }
            onboardingButton(isDone ? "Start Watching" : "Continue", action: .next) {
                if page >= pages.count - 1 { store.onboardingTourActive = false; store.onboardingForceFullGuide = false; isVisible = true } else { page += 1 }
            }
        }
    }

    private var progressDots: some View {
        HStack(spacing: 10) {
            ForEach(0..<pages.count, id: \.self) { idx in
                Circle()
                    .fill(idx == page ? Color.orange : Color.white.opacity(0.28))
                    .frame(width: idx == page ? 14 : 10, height: idx == page ? 14 : 10)
                    .overlay(Circle().stroke(idx == page ? Color.white.opacity(0.82) : Color.clear, lineWidth: 2))
            }
        }
        .padding(.top, 2)
    }

    private func onboardingButton(_ title: String, action: OnboardingAction, handler: @escaping () -> Void) -> some View {
        Button(action: handler) {
            Text(title)
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundStyle(focusedAction == action ? .black : .white)
                .padding(.horizontal, 38)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 14).fill(focusedAction == action ? Color.orange : Color.white.opacity(0.18)))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedAction == action ? Color.white.opacity(0.82) : Color.white.opacity(0.16), lineWidth: focusedAction == action ? 4 : 1))
                .scaleEffect(focusedAction == action ? 1.06 : 1.0)
                .shadow(color: focusedAction == action ? Color.orange.opacity(0.38) : .clear, radius: 18)
        }
        .buttonStyle(.plain)
        .focused($focusedAction, equals: action)
    }
}

struct LiveClockText: View {
    @State private var now = Date()
    private let timer = Timer.publish(every: 30, on: .main, in: .common).autoconnect()
    private static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateStyle = .none
        f.timeStyle = .short
        return f
    }()

    var body: some View {
        Text(Self.formatter.string(from: now))
            .font(.system(size: 18, weight: .semibold, design: .rounded))
            .foregroundStyle(.white.opacity(0.72))
            .monospacedDigit()
            .onReceive(timer) { now = $0 }
    }
}


// v572: Permanent app chrome wordmark. This intentionally uses a vector/text
// treatment instead of a bundled font file so the logo stays sharp on tvOS and
// does not depend on font packaging/signing. The tracking/weights mirror the
// supplied stacked DEBRID CHANNELS reference: white DEBRID over orange CHANNELS.
struct DebridChannelsChromeWordmark: View {
    private let orange = Color(red: 1.0, green: 0.54, blue: 0.0)
    private let red = Color(red: 1.0, green: 0.16, blue: 0.08)

    var body: some View {
        VStack(alignment: .leading, spacing: -3) {
            Text("DEBRID")
                .font(.system(size: 24, weight: .regular, design: .default))
                .tracking(3.6)
                .foregroundStyle(Color.white.opacity(0.96))
                .padding(.leading, 30)
                .shadow(color: .black.opacity(0.42), radius: 3, x: 0, y: 1)
            Text("CHANNELS")
                .font(.system(size: 25, weight: .regular, design: .default))
                .tracking(3.1)
                .foregroundStyle(
                    LinearGradient(
                        colors: [orange, orange, red.opacity(0.92)],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .shadow(color: orange.opacity(0.24), radius: 5, x: 0, y: 0)
                .shadow(color: .black.opacity(0.45), radius: 3, x: 0, y: 1)
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("membershipActive") private var membershipActive: Bool = false
    @AppStorage("showOwnerLogin") private var showOwnerLogin: Bool = false
    @State private var membershipSecretTapCount: Int = 0
    @State private var lastMembershipSecretTapAt: Date = .distantPast
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool
    @AppStorage("topMenuThemePreset") private var topMenuThemePreset: String = "Classic"
    @AppStorage("topMenuFontPreset") private var topMenuFontPreset: String = "SF Rounded"
    @AppStorage("homeGridThemePreset") private var homeGridThemePreset: String = "Classic Glow"

    private var topMenuUsesRail: Bool {
        let key = topMenuThemePreset.lowercased()
        return key.contains("pill") || key.contains("rail") || key.contains("tab") || key.contains("glass") || key.contains("vision") || key.contains("oled") || key.contains("carbon") || key.contains("titanium") || key.contains("midnight") || key.contains("premium") || key.contains("accent") || key.contains("glow") || key.contains("floating") || key.contains("dashboard")
    }

    private var topMenuSpacing: CGFloat {
        let key = topMenuThemePreset.lowercased()
        if key.contains("compact") { return 8 }
        if key.contains("pill") || key.contains("tab") || key.contains("rail") || key.contains("glass") { return 12 }
        return 42
    }

    private var topMenuRailCorner: CGFloat {
        let key = topMenuThemePreset.lowercased()
        if key.contains("ultra") || key.contains("pill") { return 36 }
        if key.contains("compact") { return 22 }
        return 30
    }

    private var topMenuAccentBase: Color {
        let key = topMenuThemePreset.lowercased()
        if key.contains("sapphire") || key.contains("blue") { return Color(red: 0.20, green: 0.58, blue: 1.0) }
        if key.contains("emerald") { return Color(red: 0.12, green: 0.78, blue: 0.46) }
        if key.contains("gold") { return Color(red: 1.0, green: 0.72, blue: 0.22) }
        if key.contains("neon") || key.contains("cyber") { return Color.cyan }
        if key.contains("platinum") || key.contains("vision") { return Color.white.opacity(0.88) }
        return Color.orange
    }

    private var topMenuAccentShadow: Color { topMenuAccentBase.opacity(0.56) }

    private var topMenuRailFill: Color {
        let key = topMenuThemePreset.lowercased()
        if key.contains("oled") || key.contains("midnight") { return Color.black.opacity(0.72) }
        if key.contains("glass") || key.contains("vision") || key.contains("frosted") { return Color.white.opacity(0.075) }
        if key.contains("carbon") || key.contains("titanium") { return Color(red: 0.035, green: 0.040, blue: 0.052).opacity(0.78) }
        if key.contains("gold") { return Color(red: 0.12, green: 0.08, blue: 0.02).opacity(0.68) }
        return Color.black.opacity(0.56)
    }

    private var topMenuRailStroke: Color {
        let key = topMenuThemePreset.lowercased()
        if key.contains("neon") || key.contains("glow") { return topMenuAccentBase.opacity(0.35) }
        return Color.white.opacity(0.13)
    }

    private func topMenuTextColor(isFocused: Bool, isSelected: Bool) -> Color {
        if isFocused { return topMenuThemePreset.lowercased().contains("gold") ? .black : .black }
        return isSelected ? Color.white : Color.white.opacity(0.62)
    }

    private func topMenuItemFill(isFocused: Bool, isSelected: Bool) -> Color {
        if isFocused { return topMenuAccentBase.opacity(topMenuThemePreset.lowercased().contains("dark") ? 0.86 : 0.92) }
        if isSelected && topMenuThemePreset.lowercased().contains("pill") { return Color.white.opacity(0.08) }
        return Color.clear
    }

    private func topMenuItemGlow(isFocused: Bool, isSelected: Bool) -> Color {
        isFocused ? topMenuAccentBase.opacity(0.30) : (isSelected ? topMenuAccentBase.opacity(0.12) : .clear)
    }

    private func topMenuAccentColor(isSelected: Bool) -> Color { isSelected ? topMenuAccentBase : Color.clear }

    private var visibleTabs: [AppTab] {
        AppTab.allCases.filter { !(membershipActive && $0 == .membership) }
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                // v572: global app wordmark lives in the absolute top-left app chrome; native transparent top menu keeps stable focus position.
                Rectangle()
                    .fill(Color.clear)
                    .frame(height: 96)
                    .ignoresSafeArea(edges: .top)

                DebridChannelsChromeWordmark()
                    .position(x: 106, y: 43)
                    .zIndex(2)

                HStack(spacing: topMenuSpacing) {
                    ForEach(visibleTabs) { tab in
                        VStack(spacing: 7) {
                            Text(tab.rawValue == "Shows" ? "TV Shows" : tab.rawValue)
                                .font(PopupTypography.font(topMenuFontPreset, size: 25, weight: (focusedTab == tab || store.selectedTab == tab) ? .semibold : .regular))
                                .tracking(0.2)
                                .foregroundStyle(topMenuTextColor(isFocused: focusedTab == tab, isSelected: store.selectedTab == tab))
                                .padding(.horizontal, focusedTab == tab ? 22 : 12)
                                .padding(.vertical, focusedTab == tab ? 9 : 7)
                                .background(
                                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                                        .fill(topMenuItemFill(isFocused: focusedTab == tab, isSelected: store.selectedTab == tab))
                                        .shadow(color: topMenuItemGlow(isFocused: focusedTab == tab, isSelected: store.selectedTab == tab), radius: focusedTab == tab ? 13 : 7, x: 0, y: 0)
                                )
                            Capsule()
                                .fill(topMenuAccentColor(isSelected: store.selectedTab == tab))
                                .frame(width: tab.rawValue == "Settings" ? 64 : 54, height: 4)
                                .shadow(color: store.selectedTab == tab ? topMenuAccentShadow : .clear, radius: 8)
                        }
                        .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .scaleEffect(focusedTab == tab ? 1.018 : 1.0)
                        .focusable(true)
                        .focused($focusedTab, equals: tab)
                        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
                        .onTapGesture {
                            if tab == .membership {
                                let now = Date()
                                if now.timeIntervalSince(lastMembershipSecretTapAt) > 4 {
                                    membershipSecretTapCount = 0
                                }
                                lastMembershipSecretTapAt = now
                                membershipSecretTapCount += 1
                                if membershipSecretTapCount >= 7 {
                                    showOwnerLogin = true
                                    membershipSecretTapCount = 0
                                }
                            } else {
                                membershipSecretTapCount = 0
                            }
                            withAnimation(.easeInOut(duration: 0.26)) {
                                store.selectedTab = tab
                                store.selectedDetail = nil
                                store.detailBackStack.removeAll()
                            }
                        }
                    }
                }
                .padding(.horizontal, topMenuUsesRail ? 16 : 0)
                .padding(.vertical, topMenuUsesRail ? 9 : 0)
                .background(
                    Group {
                        if topMenuUsesRail {
                            RoundedRectangle(cornerRadius: topMenuRailCorner, style: .continuous)
                                .fill(topMenuRailFill)
                                .overlay(RoundedRectangle(cornerRadius: topMenuRailCorner, style: .continuous).stroke(topMenuRailStroke, lineWidth: 1))
                                .shadow(color: topMenuAccentShadow.opacity(0.38), radius: topMenuThemePreset.lowercased().contains("glow") ? 22 : 12, y: 6)
                                .shadow(color: .black.opacity(0.48), radius: 18, y: 8)
                        }
                    }
                )
                .position(x: geo.size.width * 0.46, y: 58)
                .focusSection()

                HStack(spacing: 28) {
                    Button {
                        store.searchActive = true
                        store.status = "Search opened. Results include loaded Stremio/Cinemeta/service rows and configured catalog rows."
                    } label: {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundStyle(searchFocused ? Color.orange : Color.white.opacity(0.78))
                            .frame(width: 48, height: 48)
                            .background(Circle().fill(Color.clear))
                    }
                    .buttonStyle(.plain)
                    .focused($searchFocused)
                    .modifier(TransparentTVFocusVisual())

                    LiveClockText()
                }
                .position(x: geo.size.width - max(150, geo.size.width * 0.078), y: 58)
            }
            .frame(width: geo.size.width, height: 100, alignment: .top)
        }
        .frame(height: 122)
        .background(Color.clear.ignoresSafeArea(edges: .top))
        .zIndex(6000)
        .focusSection()
        .onMoveCommand { direction in
            if direction == .down {
                store.topMenuFocusLocked = false
                store.contentFocusToken += 1
                focusedTab = nil
                searchFocused = false
            }
        }
        .onChange(of: store.menuFocusToken) { _ in
            store.topMenuFocusLocked = true
            focusedTab = store.selectedTab
            searchFocused = false
        }
        .onChange(of: focusedTab) { newTab in
            // v203: do not auto-open sections while sliding across the top menu.
            // This keeps the search icon reachable and matches the requested manual selection behavior.
            if newTab != nil { store.topMenuFocusLocked = true }
        }
    }
}

struct GlobalSearchScreen: View {
    @EnvironmentObject var store: CatalogStore
    @StateObject private var liveModel = LiveTVSourceModel()
    @AppStorage("tmdbApiKey") private var tmdbApiKey: String = ""
    @State private var query: String = ""
    @State private var addonSearchResults: [MediaItem] = []
    @State private var addonSearchToken: Int = 0
    @State private var isSearchingAddons: Bool = false
    @State private var tmdbResults: [MediaItem] = []
    @State private var tmdbSearchToken: Int = 0
    @State private var isSearchingTMDB: Bool = false
    @FocusState private var focusedID: String?
    @FocusState private var focusedChannelID: Int?

    private var catalogResults: [MediaItem] {
        guard query.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 else { return [] }
        // v500: keep Search fast and clean: only local TMDB/Cinemeta-backed rows are shown.
        return store.searchResults(for: query).filter { item in
            let source = "\(item.catalog) \(item.addonName ?? "")".lowercased()
            return source.contains("tmdb") || source.contains("cinemeta")
        }
    }

    private var mergedMediaResults: [MediaItem] {
        var seen = Set<String>()
        // v500: Search results are intentionally restricted to TMDB + Cinemeta.
        // This avoids slow third-party catalog calls and keeps typing instant.
        let merged = tmdbResults + catalogResults + addonSearchResults
        return Array(merged.filter { item in
            let key = "\(item.id)|\(item.catalog)|\(item.addonName ?? "")"
            return seen.insert(key).inserted
        }.prefix(72))
    }

    private var liveResults: [LiveTVChannel] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard trimmed.count >= 2 else { return [] }
        let channels = liveModel.channels
        return Array(channels.filter { channel in
            [channel.number, channel.name, channel.category, channel.source, channel.now, channel.next]
                .joined(separator: " ")
                .lowercased()
                .contains(trimmed)
        }.prefix(80))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.opacity(0.94).ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.98), .black.opacity(0.72), .black.opacity(0.96)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()

            VStack(alignment: .leading, spacing: 22) {
                Spacer().frame(height: 116)
                HStack(alignment: .lastTextBaseline, spacing: 18) {
                    Text("Search")
                        .font(.system(size: 58, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text("TMDB + Cinemeta only")
                        .font(.system(size: 16, weight: .heavy, design: .rounded))
                        .foregroundStyle(.cyan.opacity(0.82))
                }

                TextField("Search movies and shows…", text: $query)
                    .font(.system(size: 31, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 28)
                    .frame(width: 1240, height: 74)
                    .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.10)))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.16), lineWidth: 1))
                    .onChange(of: query) { _ in
                        scheduleCinemetaCatalogSearch()
                        scheduleTMDBSearch()
                    }

                if isSearchingAddons || isSearchingTMDB {
                    Text(isSearchingAddons ? "Checking Cinemeta…" : "Searching TMDB…")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                }

                if query.trimmingCharacters(in: .whitespacesAndNewlines).count < 2 {
                    Text("Type to search TMDB and Cinemeta only. This keeps search instant and avoids slow addon catalog scans.")
                        .font(.system(size: 22, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.56))
                        .padding(.top, 12)
                }

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 30) {
                        if false && !liveResults.isEmpty {
                            Text("Live TV Channels")
                                .font(.system(size: 25, weight: .black, design: .rounded))
                                .foregroundStyle(.white.opacity(0.92))
                            LazyVGrid(columns: Array(repeating: GridItem(.fixed(330), spacing: 34), count: 4), spacing: 34) {
                                ForEach(liveResults) { channel in
                                    Button {
                                        store.searchActive = false
                                        store.selectedTab = .live
                                    } label: {
                                        SearchLiveChannelCard(channel: channel, isFocused: focusedChannelID == channel.id)
                                    }
                                    .buttonStyle(.plain)
                                    .focusEffectDisabled()
                                    .focused($focusedChannelID, equals: channel.id)
                                    .modifier(TransparentTVFocusVisual())
                                }
                            }
                        }

                        if !mergedMediaResults.isEmpty {
                            Text("TMDB + Cinemeta Results")
                                .font(.system(size: 25, weight: .black, design: .rounded))
                                .foregroundStyle(.white.opacity(0.92))
                            LazyVGrid(columns: Array(repeating: GridItem(.fixed(408), spacing: 46), count: 4), spacing: 58) {
                                ForEach(mergedMediaResults) { item in
                                    SearchResultCard(item: item, isFocused: focusedID == item.id)
                                        .contentShape(RoundedRectangle(cornerRadius: focusedID == item.id ? 26 : 20, style: .continuous))
                                        .focusable(true)
                                        .focused($focusedID, equals: item.id)
                                        .onTapGesture {
                                            // v503: Search result selection must open the popup immediately.
                                            // Do not block the UI on trailer prewarm, addon scans, TMDB external-id lookup,
                                            // or any resolver metadata hydration. Open the lightweight TMDB/Cinemeta card now,
                                            // then quietly upgrade the selected detail if richer resolver metadata arrives.
                                            let selectedSearchID = item.id
                                            let selectedSearchTitle = item.title
                                            store.searchActive = false
                                            store.openDetail(item, pushCurrent: false)
                                            Task {
                                                let hydrated = await store.searchHydratedDetailItem(for: item, query: query, tmdbApiKey: tmdbApiKey)
                                                await MainActor.run {
                                                    guard let currentDetail = store.selectedDetail, currentDetail.id == selectedSearchID || currentDetail.title == selectedSearchTitle else { return }
                                                    if hydrated.id != selectedSearchID || hydrated.posterURL != item.posterURL || hydrated.landscapeURL != item.landscapeURL {
                                                        // Keep the already-visible TMDB popup metadata/credits/artwork. Hydration is only
                                                        // supposed to improve resolver identity for Search Links; it must not blank the
                                                        // movie information, cast, or poster after the popup has opened.
                                                        let preserved = MediaItem(
                                                            id: hydrated.id,
                                                            title: currentDetail.title.isEmpty ? hydrated.title : currentDetail.title,
                                                            year: currentDetail.year.isEmpty ? hydrated.year : currentDetail.year,
                                                            type: currentDetail.type.isEmpty ? hydrated.type : currentDetail.type,
                                                            catalog: hydrated.catalog,
                                                            description: currentDetail.description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? hydrated.description : currentDetail.description,
                                                            genres: currentDetail.genres.isEmpty ? hydrated.genres : currentDetail.genres,
                                                            rating: currentDetail.rating.isEmpty ? hydrated.rating : currentDetail.rating,
                                                            posterURL: currentDetail.posterURL ?? hydrated.posterURL,
                                                            landscapeURL: currentDetail.landscapeURL ?? hydrated.landscapeURL,
                                                            logoURL: currentDetail.logoURL ?? hydrated.logoURL,
                                                            previewURL: currentDetail.previewURL ?? hydrated.previewURL,
                                                            addonName: hydrated.addonName ?? currentDetail.addonName,
                                                            addonIconURL: hydrated.addonIconURL ?? currentDetail.addonIconURL,
                                                            seasonNumber: currentDetail.seasonNumber ?? hydrated.seasonNumber,
                                                            episodeNumber: currentDetail.episodeNumber ?? hydrated.episodeNumber,
                                                            cast: currentDetail.cast.isEmpty ? hydrated.cast : currentDetail.cast,
                                                            directors: currentDetail.directors.isEmpty ? hydrated.directors : currentDetail.directors,
                                                            castMembers: currentDetail.castMembers.isEmpty ? hydrated.castMembers : currentDetail.castMembers
                                                        )
                                                        store.selectedDetail = preserved
                                                    }
                                                }
                                            }
                                        }
                                        .accessibilityElement(children: .combine)
                                        .accessibilityAddTraits(.isButton)
                                }
                            }
                        }
                    }
                    .padding(.bottom, 140)
                }
                .frame(maxHeight: 690)
            }
            .padding(.leading, 86)
        }
        .onAppear {
            // v499: Search must open instantly. Use retained/cached Live TV data here;
            // do not trigger a source/guide network refresh from the Search screen.
            liveModel.loadCachedOrDemo()
            focusedID = mergedMediaResults.first?.id
        }
        .onExitCommand { store.searchActive = false }
    }


    private func scheduleCinemetaCatalogSearch() {
        addonSearchToken += 1
        let token = addonSearchToken
        let currentQuery = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard currentQuery.count >= 2 else {
            addonSearchResults = []
            isSearchingAddons = false
            return
        }
        Task {
            try? await Task.sleep(nanoseconds: 900_000_000)
            guard token == addonSearchToken else { return }
            await MainActor.run { if token == addonSearchToken { isSearchingAddons = true } }
            let results = await store.searchCinemetaCatalog(for: currentQuery)
            await MainActor.run {
                guard token == addonSearchToken else { return }
                addonSearchResults = results
                isSearchingAddons = false
            }
        }
    }

    private func scheduleTMDBSearch() {
        tmdbSearchToken += 1
        let token = tmdbSearchToken
        let currentQuery = query
        let key = tmdbApiKey
        guard currentQuery.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2,
              !key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            tmdbResults = []
            isSearchingTMDB = false
            return
        }
        Task {
            try? await Task.sleep(nanoseconds: 250_000_000)
            guard token == tmdbSearchToken else { return }
            await MainActor.run { if token == tmdbSearchToken { isSearchingTMDB = true } }
            let results = await store.tmdbSearchResults(for: currentQuery, apiKey: key)
            await MainActor.run {
                guard token == tmdbSearchToken else { return }
                tmdbResults = results
                isSearchingTMDB = false
            }
        }
    }
}

struct SearchResultCard: View {
    let item: MediaItem
    let isFocused: Bool
    @AppStorage("homeGridThemePreset") private var homeGridThemePreset: String = "Classic Glow"

    private var cardWidth: CGFloat { isFocused ? 392 : 360 }
    private var cardHeight: CGFloat { isFocused ? 220 : 202 }
    private var cornerRadius: CGFloat { isFocused ? 26 : 20 }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ZStack(alignment: .bottomLeading) {
                RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                    .frame(width: cardWidth, height: cardHeight)
                HomeGridThemeOverlay(theme: homeGridThemePreset, focused: isFocused)
                    .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                    .overlay(
                        LinearGradient(
                            colors: [.clear, .black.opacity(isFocused ? 0.52 : 0.30)],
                            startPoint: .center,
                            endPoint: .bottom
                        )
                        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                            .strokeBorder(isFocused ? Color.orange.opacity(0.98) : Color.white.opacity(0.10), lineWidth: isFocused ? 4 : 1)
                    )
                    .shadow(color: isFocused ? Color.orange.opacity(0.34) : .clear, radius: isFocused ? 20 : 0)

                if let resume = PlaybackResumeCacheManager.shared.resumeEntry(for: item) {
                    ContinueWatchingBadge(entry: resume, compact: !isFocused)
                        .padding(12)
                        .frame(width: cardWidth, height: cardHeight, alignment: .topTrailing)
                }

                if isFocused {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.title)
                            .font(.system(size: 25, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text("\(item.year) • \(item.catalog)")
                            .font(.system(size: 15, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white.opacity(0.82))
                            .lineLimit(1)
                    }
                    .padding(.horizontal, 16)
                    .padding(.bottom, 13)
                    .frame(width: cardWidth, alignment: .leading)
                }
            }
            .frame(width: cardWidth, height: cardHeight)

            if !isFocused {
                Text(item.title)
                    .font(.system(size: 23, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text("\(item.year) • \(item.catalog)")
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.54))
                    .lineLimit(1)
            }
        }
        .frame(width: cardWidth, alignment: .leading)
        .scaleEffect(isFocused ? 1.03 : 1.0)
        .offset(y: isFocused ? -10 : 0)
        .shadow(color: isFocused ? .black.opacity(0.84) : .black.opacity(0.38), radius: isFocused ? 26 : 10, y: isFocused ? 18 : 6)
        .animation(.spring(response: 0.24, dampingFraction: 0.76), value: isFocused)
    }
}

struct SearchLiveChannelCard: View {
    let channel: LiveTVChannel
    let isFocused: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.24))
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFit().padding(10)
                        default: Text(channel.logo).font(.system(size: 25, weight: .black)).foregroundStyle(.white)
                        }
                    }
                } else {
                    Text(channel.logo).font(.system(size: 25, weight: .black)).foregroundStyle(.white)
                }
            }
            .frame(width: 74, height: 58)
            VStack(alignment: .leading, spacing: 5) {
                Text(channel.name).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1)
                Text("\(channel.number) • \(channel.source)").font(.system(size: 14, weight: .heavy)).foregroundStyle(.white.opacity(0.62)).lineLimit(1)
                Text(channel.now).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
            }
        }
        .padding(14)
        .frame(width: 278, height: 94, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(isFocused ? Color.white.opacity(0.16) : Color.white.opacity(0.07)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(isFocused ? Color.cyan.opacity(0.65) : Color.white.opacity(0.10), lineWidth: isFocused ? 2 : 1))
        .scaleEffect(isFocused ? 1.07 : 1.0)
        .offset(y: isFocused ? -7 : 0)
        .shadow(color: .black.opacity(isFocused ? 0.78 : 0.32), radius: isFocused ? 24 : 10, y: isFocused ? 18 : 6)
        .animation(.spring(response: 0.24, dampingFraction: 0.76), value: isFocused)
    }
}



// MARK: - v220 Grid Overlay Catalog Shelves
struct GridOSCatalogOverlay: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    let filter: String?
    @FocusState private var focusedRow: Int?
    @State private var selectedIndices: [String: Int] = [:]

    private var overlayTitle: String {
        if filter == "movie" { return "Movies" }
        if filter == "series" { return "TV Shows" }
        return "Streaming Catalogs"
    }

    private var rows: [MediaRow] {
        let source = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        if let filter {
            return source.compactMap { row in
                let items = row.items.filter { $0.type == filter }
                guard !items.isEmpty else { return nil }
                return MediaRow(id: row.id + "-slot-overlay-" + filter, title: row.title, items: items)
            }
        }
        return source.map { MediaRow(id: $0.id + "-slot-overlay", title: $0.title, items: $0.items) }
    }

    private var focusedBackdropItem: MediaItem? {
        guard !rows.isEmpty else { return nil }
        let rowIndex = min(max(focusedRow ?? 0, 0), rows.count - 1)
        let row = rows[rowIndex]
        guard !row.items.isEmpty else { return nil }
        let selected = min(max(selectedIndices[row.id, default: 0], 0), row.items.count - 1)
        return row.items[selected]
    }

    private var focusedBackdropURL: String? {
        guard let item = focusedBackdropItem else { return nil }
        return item.landscapeURL ?? item.posterURL
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottomLeading) {
                // Main Grid OS surface stays clean; Movies/Shows panel owns its focused-card backdrop.
                Color.clear
                    .ignoresSafeArea()
                    .contentShape(Rectangle())

                VStack(alignment: .leading, spacing: 10) {
                    overlayHeader

                    ScrollViewReader { proxy in
                        ScrollView(.vertical, showsIndicators: false) {
                            LazyVStack(alignment: .leading, spacing: 12) {
                                ForEach(Array(rows.enumerated()), id: \.element.id) { rowIndex, row in
                                    GridOSFixedSlotCatalogRail(
                                        row: row,
                                        rowIndex: rowIndex,
                                        focusedRow: $focusedRow,
                                        selectedIndex: Binding(
                                            get: { selectedIndices[row.id, default: 0] },
                                            set: { selectedIndices[row.id] = $0 }
                                        )
                                    )
                                    .id(row.id)
                                    .onChange(of: focusedRow) { value in
                                        if value == rowIndex {
                                            withAnimation(.easeOut(duration: 0.22)) {
                                                proxy.scrollTo(row.id, anchor: .center)
                                            }
                                        }
                                    }
                                }
                            }
                            .padding(.top, 4)
                            .padding(.bottom, 64)
                        }
                        .frame(maxHeight: min(geo.size.height * 0.34, 335))
                    }
                }
                .padding(.leading, 34)
                .padding(.trailing, 34)
                .padding(.top, 10)
                .padding(.bottom, 10)
                .frame(width: geo.size.width, alignment: .bottomLeading)
                .background(
                    ZStack {
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(Color.black.opacity(0.47))
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(.regularMaterial.opacity(0.13))
                        UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous)
                            .fill(
                                LinearGradient(
                                    colors: [Color.black.opacity(0.27), Color.black.opacity(0.54), Color.black.opacity(0.39)],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                    }
                    .clipShape(UnevenRoundedRectangle(topLeadingRadius: 38, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 38, style: .continuous))
                )
                .shadow(color: .black.opacity(0.78), radius: 42, y: -12)
                .transition(.asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity), removal: .move(edge: .bottom).combined(with: .opacity)))
            }
            .focusSection()
            .onAppear {
                focusedRow = 0
                for row in rows where selectedIndices[row.id] == nil { selectedIndices[row.id] = 0 }
            }
            .onChange(of: store.contentFocusToken) { _ in
                // v485: restore focus to the current quick-panel rail after detail popup closes.
                if focusedRow == nil { focusedRow = 0 }
            }
        }
        .allowsHitTesting(true)
        .onExitCommand { closeOverlay() }
    }

    private var overlayHeader: some View {
        HStack(alignment: .lastTextBaseline, spacing: 16) {
            ThemedPanelLogo(title: overlayTitle)
                .frame(height: 58, alignment: .leading)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 8)
    }

    private func closeOverlay() {
        withAnimation(.easeInOut(duration: 0.22)) {
            store.selectedTab = .live
            store.selectedDetail = nil
        }
    }
}


private func mediaFavoriteKey(_ item: MediaItem) -> String {
    // v549: keep each saved favorite as one token. The old key used "|", which is also
    // the storage separator, so saved favorites split apart and could not reopen reliably.
    "\(item.id)::\(item.catalog)::\(item.type)"
}

private func favoriteMediaKeySet(_ raw: String) -> Set<String> {
    Set(raw.split(separator: "|").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { $0.contains("::") })
}

struct GridOSFixedSlotCatalogRail: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("favoriteMediaIds") private var favoriteMediaIdsRaw: String = ""
    let row: MediaRow
    let rowIndex: Int
    var focusedRow: FocusState<Int?>.Binding
    @Binding var selectedIndex: Int

    private var safeIndex: Int {
        guard !row.items.isEmpty else { return 0 }
        return min(max(selectedIndex, 0), row.items.count - 1)
    }

    private var selectedItem: MediaItem? {
        guard !row.items.isEmpty else { return nil }
        return row.items[safeIndex]
    }

    private var previewItems: [MediaItem] {
        guard !row.items.isEmpty else { return [] }
        return Array(row.items.dropFirst(safeIndex + 1).prefix(16))
    }

    private func isCatalogFavorite(_ item: MediaItem) -> Bool {
        favoriteMediaKeySet(favoriteMediaIdsRaw).contains(mediaFavoriteKey(item))
    }

    private func toggleCatalogFavorite(_ item: MediaItem) {
        var keys = favoriteMediaKeySet(favoriteMediaIdsRaw)
        let key = mediaFavoriteKey(item)
        if keys.contains(key) {
            keys.remove(key)
            store.status = "Removed \(item.title) from Favorites."
        } else {
            keys.insert(key)
            store.status = "Added \(item.title) to Favorites."
        }
        favoriteMediaIdsRaw = keys.sorted().joined(separator: "|")
    }

    private func favoriteActionTitle(for item: MediaItem) -> String {
        isCatalogFavorite(item) ? "Remove from Favorites" : "Add to Favorites"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(row.title)
                .font(.system(size: focusedRow.wrappedValue == rowIndex ? 28 : 24, weight: .heavy, design: .rounded))
                .foregroundStyle(focusedRow.wrappedValue == rowIndex ? .white : .white.opacity(0.70))
                .padding(.leading, 4)

            HStack(alignment: .bottom, spacing: 14) {
                if let selectedItem {
                    FixedSlotFocusedCatalogCard(item: selectedItem, focused: focusedRow.wrappedValue == rowIndex)
                        .id(selectedItem.id)
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing).combined(with: .opacity),
                            removal: .move(edge: .leading).combined(with: .opacity)
                        ))
                }

                ForEach(Array(previewItems.enumerated()), id: \.element.id) { offset, item in
                    FixedSlotPreviewCatalogCard(item: item, depth: offset)
                        .transition(.move(edge: .trailing).combined(with: .opacity))
                }

                Spacer(minLength: 0)
            }
            .frame(height: 218, alignment: .bottomLeading)
            .contentShape(Rectangle())
            .focusable(true)
            .focused(focusedRow, equals: rowIndex)
            .modifier(TransparentTVFocusVisual())
            .onTapGesture { openSelected() }
            .onPlayPauseCommand { openSelected() }
            .contextMenu {
                if let selectedItem, selectedItem.type == "movie" || selectedItem.type == "series" {
                    Button(favoriteActionTitle(for: selectedItem)) { toggleCatalogFavorite(selectedItem) }
                }
            }
            .onMoveCommand { direction in
                handleMove(direction)
            }
            .animation(.spring(response: 0.42, dampingFraction: 0.84), value: selectedIndex)
            .animation(.spring(response: 0.34, dampingFraction: 0.84), value: focusedRow.wrappedValue == rowIndex)
        }
    }

    private func handleMove(_ direction: MoveCommandDirection) {
        switch direction {
        case .left:
            if selectedIndex > 0 { selectedIndex -= 1 }
        case .right:
            if selectedIndex < row.items.count - 1 { selectedIndex += 1 }
        case .up:
            focusedRow.wrappedValue = max(rowIndex - 1, 0)
        case .down:
            focusedRow.wrappedValue = rowIndex + 1
        @unknown default:
            break
        }
    }

    private func openSelected() {
        guard let selectedItem else { return }
        store.openDetail(selectedItem, pushCurrent: false)
    }
}

struct StremioAddonSourceBadge: View {
    let item: MediaItem
    var compact: Bool = false

    private var label: String {
        let raw = (item.addonName ?? item.catalog).trimmingCharacters(in: .whitespacesAndNewlines)
        return raw.isEmpty ? "Stremio" : raw
    }

    private var initials: String {
        let parts = label.split(separator: " ").prefix(2)
        let text = parts.compactMap { $0.first }.map(String.init).joined().uppercased()
        return text.isEmpty ? "S" : text
    }

    var body: some View {
        HStack(spacing: compact ? 6 : 8) {
            ZStack {
                Circle().fill(Color.black.opacity(0.36))
                if let icon = item.addonIconURL, !icon.isEmpty {
                    RemoteImageFit(url: icon, mode: .fit)
                        .clipShape(Circle())
                } else {
                    Text(initials)
                        .font(.system(size: compact ? 10 : 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.92))
                }
            }
            .frame(width: compact ? 22 : 28, height: compact ? 22 : 28)

            if !compact {
                Text(label)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.90))
                    .lineLimit(1)
                    .frame(maxWidth: 145, alignment: .leading)
            }
        }
        .padding(.horizontal, compact ? 7 : 10)
        .padding(.vertical, compact ? 5 : 7)
        .background(Capsule().fill(Color.black.opacity(0.58)))
        .overlay(Capsule().stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.40), radius: 8, y: 3)
        .allowsHitTesting(false)
    }
}

struct FixedSlotFocusedCatalogCard: View {
    let item: MediaItem
    let focused: Bool
    @AppStorage("homeGridThemePreset") private var homeGridThemePreset: String = "Classic Glow"

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                Color.black.opacity(0.38)
                RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                    .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
                HomeGridThemeOverlay(theme: homeGridThemePreset, focused: focused)
            }
            .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

            LinearGradient(colors: [.clear, .black.opacity(0.84)], startPoint: .center, endPoint: .bottom)
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))


            VStack(alignment: .leading, spacing: 7) {
                CardThemedLogo(item: item, focused: focused)
                    .frame(width: focused ? 278 : 230, height: focused ? 42 : 34, alignment: .leading)
                Text("\(item.year) • \(item.rating.ifEmpty(item.catalog))")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .lineLimit(1)
            }
            .padding(18)
        }
        .frame(width: focused ? 390 : 320, height: focused ? 220 : 180)
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(Color.white.opacity(focused ? 0.18 : 0.08), lineWidth: focused ? 0.9 : 0.8)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 27, style: .continuous)
                .stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(focused ? 0.96 : 0.0), lineWidth: focused ? 4.0 : 0.0)
                .blur(radius: focused ? 0.15 : 0.0)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 31, style: .continuous)
                .stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(focused ? 0.42 : 0.0), lineWidth: focused ? 8.0 : 0.0)
                .blur(radius: focused ? 7 : 0)
        )
        // v438: Movies/Shows quick panel now uses the same blue second-ring focus language as Live TV grid focus.
        .offset(y: focused ? -8 : 0)
        .shadow(color: HomeGridThemeStyle.accent(for: homeGridThemePreset).opacity(focused ? HomeGridThemeStyle.focusGlowOpacity(for: homeGridThemePreset) : 0.02), radius: focused ? HomeGridThemeStyle.focusGlowRadius(for: homeGridThemePreset) : 6, y: focused ? 5 : 1)
        .shadow(color: .black.opacity(focused ? HomeGridThemeStyle.blackShadowOpacity(for: homeGridThemePreset) : 0.46), radius: focused ? 30 : 14, y: focused ? 18 : 7)
        .animation(.spring(response: 0.36, dampingFraction: 0.86), value: focused)
    }
}

struct FixedSlotPreviewCatalogCard: View {
    let item: MediaItem
    let depth: Int
    @AppStorage("homeGridThemePreset") private var homeGridThemePreset: String = "Classic Glow"

    private var cardWidth: CGFloat { max(64, 116 - CGFloat(depth) * 4.4) }
    private var cardHeight: CGFloat { cardWidth * 1.48 }
    private var opacity: Double { max(0.36, 0.90 - Double(depth) * 0.045) }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            ZStack(alignment: .topTrailing) {
                Color.black.opacity(0.34)
                RemoteImageFit(url: item.posterURL, mode: .fill)
                    .frame(width: cardWidth, height: cardHeight)
                HomeGridThemeOverlay(theme: homeGridThemePreset, focused: depth == 0)
                    .opacity(depth == 0 ? 0.92 : 0.42)
            }
            .frame(width: cardWidth, height: cardHeight)
            .clipShape(RoundedRectangle(cornerRadius: max(9, 16 - CGFloat(depth) * 0.45), style: .continuous))
            EmptyView()
        }
        .opacity(opacity)
        .shadow(color: HomeGridThemeStyle.accent(for: homeGridThemePreset).opacity(depth == 0 ? HomeGridThemeStyle.focusGlowOpacity(for: homeGridThemePreset) * 0.55 : 0.02), radius: depth == 0 ? 18 : 8, y: depth == 0 ? 5 : 3)
        .shadow(color: .black.opacity(0.50), radius: 12, y: 6)
        .brightness(depth == 0 ? 0.012 : -0.016)
        .saturation(depth == 0 ? 1.02 : 0.92)
    }
}


struct MediaInfoPopup: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focused: Bool
    @State private var focus: DetailPage.DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var trailerResolving = false
    @State private var isFindingLinks = false
    @State private var isLoadingEpisodes = false
    @State private var episodeItems: [MediaItem] = []
    @State private var episodesVisible = false
    @State private var episodeWindowStart: Int = 0
    @State private var selectedSeasonNumber: Int = 1
    @State private var seasonDropdownOpen = false
    @State private var linkWindowStart: Int = 0
    @State private var sourcePanelVisible = false
    @State private var sourcePanelLastFocusedIndex: Int = 0
    // v567: when a season episode is selected, Source Intelligence searches that exact
    // episode id instead of falling back to the parent season/show id.
    @State private var sourceSearchItem: MediaItem? = nil
    @State private var demoEpisodeAlertVisible: Bool = false
    @State private var demoEpisodeAlertFocus: Int = 0
    @State private var demoEpisodeAlertItem: MediaItem? = nil
    @State private var relatedWindowStart: Int = 0
    @State private var lastActionAt: TimeInterval = 0
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"
    @AppStorage("trailerProviderMode") private var trailerProviderMode: String = "auto"
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"
    @AppStorage("tmdbApiKey") private var popupTMDBApiKey: String = ""
    @AppStorage("favoriteMediaIds") private var favoriteMediaIdsRaw: String = ""
    @AppStorage("followedShowIds") private var followedShowIdsRaw: String = ""
    @State private var popupHeaderDetails: PopupHeaderDetails? = nil

    private let sourceIntelligencePageSize = 5

    private var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(14))
    }

    private var isSeriesItem: Bool {
        let lower = item.type.lowercased()
        return lower.contains("series") || lower.contains("show")
    }

    private var seasonNumbers: [Int] {
        let values = Set(episodeItems.map { $0.seasonNumber ?? 1 })
        return values.isEmpty ? [selectedSeasonNumber] : values.sorted()
    }

    private var selectedSeasonIndex: Int {
        seasonNumbers.firstIndex(of: selectedSeasonNumber) ?? 0
    }

    private var filteredEpisodeItems: [MediaItem] {
        episodeItems.filter { ($0.seasonNumber ?? 1) == selectedSeasonNumber }
    }

    private var visibleEpisodeItems: [MediaItem] {
        Array(filteredEpisodeItems.dropFirst(episodeWindowStart).prefix(5))
    }

    private var visibleLinks: [StreamLink] {
        // v523: keep source chips contained inside popup bounds; use arrows for paging.
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(sourceIntelligencePageSize))
    }

    private var visibleRelatedItems: [MediaItem] {
        // v524: bottom poster rail removed from the popup. Keep a small, stable sample
        // only for Media DNA counts/cards so the popup stays clean and contained.
        Array(relatedItems.prefix(11))
    }

    var body: some View {
        ZStack(alignment: .top) {
            popupDimLayer
            popupHeaderLayer
            popupPanelLayer
            sourcePanelLayer
            demoEpisodeAlertLayer
            popupTrailerLayer
        }
        .focusSection()
        .focusable(true)
        .focused($focused)
        .onAppear {
            focused = true
            focus = .play
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
            sourcePanelVisible = false
            sourceSearchItem = nil
            demoEpisodeAlertVisible = false
            demoEpisodeAlertFocus = 0
            demoEpisodeAlertItem = nil
            popupHeaderDetails = nil
            loadPopupHeaderDetails()
            if isSeriesItem { preloadEpisodesForHeroPopup() }
            // v503: keep detail popup instant. Trailer resolving/prewarm waits until the user asks for Trailer/YouTube.
        }
        .onChange(of: item.id) { _ in
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
            sourcePanelVisible = false
            sourceSearchItem = nil
            demoEpisodeAlertVisible = false
            demoEpisodeAlertFocus = 0
            demoEpisodeAlertItem = nil
            popupHeaderDetails = nil
            loadPopupHeaderDetails()
            if isSeriesItem { preloadEpisodesForHeroPopup() }
        }
        .onChange(of: focused) { value in
            if !value && store.selectedDetail?.id == item.id && store.playbackURL == nil {
                DispatchQueue.main.async { focused = true }
            }
        }
        .onTapGesture { activateDebounced() }
        .onPlayPauseCommand { activateDebounced() }
        .onExitCommand {
            if trailerPopup { trailerPopup = false; trailerURL = nil } else if sourcePanelVisible { sourcePanelVisible = false; focus = .findLinks } else if demoEpisodeAlertVisible { demoEpisodeAlertVisible = false; focus = .testAlert } else { store.closeDetail() }
        }
        .onMoveCommand { route($0) }
    }

    private var popupDimLayer: some View {
        Rectangle()
            .fill(Color.black.opacity(0.42))
            .ignoresSafeArea()
            .transition(.opacity)
    }

    private var popupHeaderLayer: some View {
        PopupExtendedMetadataHeader(item: item, details: popupHeaderDetails)
            .frame(width: 1920, height: 148)
            .padding(.top, 0)
            .zIndex(1)
    }

    private var popupPanelLayer: some View {
        // v567 premium cinematic redesign: keep the top metadata bar visible, but
        // replace the old poster/glass dialog with a backdrop-first Apple TV style card.
        popupPanelContent
            // v569: safer hero-sheet math. Movies were a little too wide after the v568
            // rebuild, so keep series at the approved size and give movies equal left/right
            // breathing room inside the 1920 canvas.
            .padding(.horizontal, isSeriesItem ? 58 : 54)
            .padding(.top, isSeriesItem ? 42 : 46)
            .padding(.bottom, isSeriesItem ? 34 : 38)
            .frame(width: isSeriesItem ? 1548 : 1488, height: isSeriesItem ? 872 : 732, alignment: .topLeading)
            .background(popupPanelBackground)
            .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
            .shadow(color: .black.opacity(0.78), radius: 54, y: 26)
            .shadow(color: .cyan.opacity(0.075), radius: 28, x: -10, y: -8)
            .shadow(color: .orange.opacity(0.06), radius: 32, x: 14, y: 12)
            .scaleEffect(focused ? 1.0 : 0.972)
            .opacity(focused ? 1.0 : 0.0)
            .animation(.spring(response: 0.44, dampingFraction: 0.89), value: focused)
            .padding(.top, isSeriesItem ? 150 : 190)
    }

    private var popupPanelBackground: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(Color.black.opacity(0.92))

            if let backdropURL = item.landscapeURL, !backdropURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                RemoteImageFit(url: backdropURL, mode: .fill)
                    .opacity(0.74)
                    .saturation(1.12)
                    .contrast(1.10)
                    .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
                    .overlay(
                        LinearGradient(
                            colors: [Color.black.opacity(0.98), Color.black.opacity(0.90), Color.black.opacity(0.42), Color.black.opacity(0.12)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
                    )
                    .overlay(
                        LinearGradient(
                            colors: [Color.black.opacity(0.10), Color.black.opacity(0.24), Color.black.opacity(0.92)],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
                    )
            }

            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.black.opacity(0.10), Color.white.opacity(0.035), Color.black.opacity(0.38)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        }

    }


    private var popupPremiumSoftRim: some View {
        EmptyView()
    }

    private var popupPanelContent: some View {
        // v528: remove the lower filler shelf entirely and let the core popup breathe.
        // The popup now focuses on poster, scores, description, cast, actions, and source intelligence only.
        popupMainRow
    }

    private var popupMainRow: some View {
        ZStack(alignment: .topLeading) {
            popupInfoColumn
        }
    }

    private var popupInfoColumn: some View {
        Group {
            if isSeriesItem {
                popupSeriesHeroColumn
            } else {
                popupMovieHeroColumn
            }
        }
    }

    private var focusedEpisodePreviewItem: MediaItem? {
        if case .episode(let index) = focus, filteredEpisodeItems.indices.contains(index) {
            return filteredEpisodeItems[index]
        }
        return nil
    }

    private func heroRuntimeLabel(_ minutes: Int) -> String {
        guard minutes > 0 else { return "" }
        if minutes >= 60 { return "\(minutes / 60)h \(minutes % 60)m" }
        return "\(minutes)m"
    }

    private var heroTitleMetadataLine: String {
        let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
        let runtime = popupHeaderDetails?.runtimeMinutes.map { heroRuntimeLabel($0) } ?? ""
        let genres = item.genres.prefix(3).joined(separator: ", ")
        return [year, runtime, genres].filter { !$0.isEmpty }.joined(separator: " • ")
    }

    private var heroDescriptionText: String {
        if let episode = focusedEpisodePreviewItem {
            let season = episode.seasonNumber ?? selectedSeasonNumber
            let number = episode.episodeNumber ?? 1
            let prefix = "Season \(season), Episode \(number)"
            let title = episode.title.trimmingCharacters(in: .whitespacesAndNewlines)
            let desc = episode.description.trimmingCharacters(in: .whitespacesAndNewlines)
            if !desc.isEmpty { return title.isEmpty ? "\(prefix) • \(desc)" : "\(prefix) • \(title) — \(desc)" }
            return title.isEmpty ? prefix : "\(prefix) • \(title)"
        }
        return item.description
    }

    private var popupMovieHeroColumn: some View {
        VStack(alignment: .leading, spacing: 14) {
            HeroLogoText(item: item, pulse: false)
                .frame(width: 590, height: 140, alignment: .leading)

            Text(heroTitleMetadataLine)
                .font(PopupTypography.font(popupFontPreset, size: 26, weight: .semibold))
                .foregroundStyle(.white.opacity(0.86))
                .lineLimit(1)
                .frame(width: 760, alignment: .leading)

            PopupPremiumStatusChips(item: item, isSeries: false, isFavorite: isCatalogFavorite, isFollowing: isFollowingShow, hasVerifiedEpisodeHint: false)
                .frame(width: 820, height: 40, alignment: .leading)

            Text(heroDescriptionText)
                .font(PopupTypography.font(popupFontPreset, size: 25, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .lineSpacing(PopupTypography.descriptionLineSpacing(popupFontPreset) + 2)
                .lineLimit(5)
                .frame(width: 780, height: 132, alignment: .topLeading)
                .padding(.top, 8)

            popupActionRow
                .padding(.top, 10)
            popupUtilityRow
            CompactHeroCastRow(item: item, title: "Cast & Crew", maxMembers: 6, compact: true)
                .frame(width: 1080, height: 96, alignment: .leading)
                .padding(.top, 4)
            PopupSourcePanelHint(totalLinkCount: store.streamLinks.count, isScanning: isFindingLinks, sourcePanelVisible: sourcePanelVisible)
                .frame(width: 820, height: 52, alignment: .leading)
        }
        .frame(width: 1268, height: 638, alignment: .topLeading)
    }

    private var popupSeriesHeroColumn: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 28) {
                VStack(alignment: .leading, spacing: 10) {
                    HeroLogoText(item: item, pulse: false)
                        .frame(width: 520, height: 108, alignment: .leading)

                    Text(heroTitleMetadataLine)
                        .font(PopupTypography.font(popupFontPreset, size: 23, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.86))
                        .lineLimit(1)
                        .frame(width: 710, alignment: .leading)

                    PopupPremiumStatusChips(item: item, isSeries: true, isFavorite: isCatalogFavorite, isFollowing: isFollowingShow, hasVerifiedEpisodeHint: verifiedEpisodeHint != nil)
                        .frame(width: 790, height: 38, alignment: .leading)

                    Text(heroDescriptionText)
                        .font(PopupTypography.font(popupFontPreset, size: 21, weight: .medium))
                        .foregroundStyle(.white.opacity(0.92))
                        .lineSpacing(PopupTypography.descriptionLineSpacing(popupFontPreset))
                        .lineLimit(4)
                        .frame(width: 760, height: 108, alignment: .topLeading)
                        .padding(.top, 4)
                }
                Spacer(minLength: 0)
            }

            popupActionRow
                .padding(.top, 2)
            popupUtilityRow
                .frame(width: 1180, alignment: .leading)

            CompactHeroCastRow(item: item, title: "Cast", maxMembers: 8, compact: true)
                .frame(width: 1260, height: 88, alignment: .leading)
                .padding(.top, 0)

            ManualEpisodesRow(focus: focus, visibleEpisodes: visibleEpisodeItems, episodeWindowStart: episodeWindowStart, totalEpisodeCount: filteredEpisodeItems.count, seasonNumbers: seasonNumbers, selectedSeasonNumber: selectedSeasonNumber, seasonDropdownOpen: true)
                .frame(width: 1360, height: 304, alignment: .leading)
                .padding(.top, 0)
        }
        .frame(width: 1360, height: 794, alignment: .topLeading)
    }


    private var isCatalogFavorite: Bool {
        favoriteMediaKeySet(favoriteMediaIdsRaw).contains(mediaFavoriteKey(item))
    }

    private var isFollowingShow: Bool {
        followedShowKeySet.contains(safeFollowShowKey)
    }

    private var followedShowKeySet: Set<String> {
        Set(followedShowIdsRaw.split(separator: "|").map(String.init).filter { !$0.isEmpty })
    }

    private var safeFollowShowKey: String {
        mediaFavoriteKey(item)
            .replacingOccurrences(of: "|", with: "_")
            .replacingOccurrences(of: "\n", with: " ")
    }

    private var verifiedEpisodeHint: String? {
        guard isSeriesItem else { return nil }
        if isFollowingShow { return "Verified episode alerts enabled" }
        return popupHeaderDetails?.status?.lowercased() == "returning series" ? "Follow for verified episode alerts" : nil
    }

    private func togglePopupFavorite() {
        var keys = favoriteMediaKeySet(favoriteMediaIdsRaw)
        let key = mediaFavoriteKey(item)
        if keys.contains(key) { keys.remove(key); store.status = "Removed from Favorites" }
        else { keys.insert(key); store.status = "Added to Favorites" }
        favoriteMediaIdsRaw = keys.sorted().joined(separator: "|")
    }

    private func toggleFollowShow() {
        var keys = followedShowKeySet
        let key = safeFollowShowKey
        if keys.contains(key) { keys.remove(key); store.status = "Show follow removed" }
        else { keys.insert(key); store.status = "Following show for verified episode alerts" }
        followedShowIdsRaw = keys.sorted().joined(separator: "|")
    }

    private var popupMetadataLine: some View {
        // v511: The popup already shows year/type/genre in the header and premium chips; source search is now compact icon-only.
        // Use this prime real estate for critic-style score cards instead of repeating metadata.
        HStack(spacing: 12) {
            CriticScorePill(title: "TOMATO", value: tomatoScoreText, icon: "seal.fill", tint: .red)
            CriticScorePill(title: "CRITICS", value: criticScoreText, icon: "quote.bubble.fill", tint: .yellow)
            CriticScorePill(title: "AUDIENCE", value: audienceScoreText, icon: "person.2.fill", tint: .orange)
        }
        .frame(height: 36, alignment: .leading)
    }

    private var numericRating: Double {
        let cleaned = item.rating.replacingOccurrences(of: ",", with: ".")
        return Double(cleaned.filter { "0123456789.".contains($0) }) ?? 0
    }

    private var normalizedScorePercent: Int {
        let rating = numericRating
        guard rating > 0 else { return 0 }
        if rating <= 10 { return Int((rating * 10).rounded()) }
        if rating <= 100 { return Int(rating.rounded()) }
        return 0
    }

    private var tomatoScoreText: String {
        let score = normalizedScorePercent
        return score > 0 ? "\(score)%" : "—"
    }

    private var criticScoreText: String {
        let rating = numericRating
        if rating > 0 && rating <= 10 { return String(format: "%.1f/10", rating) }
        let score = normalizedScorePercent
        return score > 0 ? "\(score)%" : "—"
    }

    private var audienceScoreText: String {
        let score = normalizedScorePercent
        guard score > 0 else { return "—" }
        // Audience is displayed as a companion score until a true external audience feed is wired.
        return "\(min(99, max(1, score + 3)))%"
    }



struct DemoNewEpisodeAlertOverlay: View {
    let showTitle: String
    let episode: MediaItem
    let selectedAction: Int
    let isFindingLinks: Bool

    private var seasonEpisodeText: String {
        let season = episode.seasonNumber ?? 1
        let ep = episode.episodeNumber ?? 1
        return "S\(String(format: "%02d", season))E\(String(format: "%02d", ep))"
    }

    var body: some View {
        HStack(alignment: .center, spacing: 26) {
            RemoteImageFit(url: episode.posterURL, mode: .fill)
                .frame(width: 188, height: 282)
                .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.16), lineWidth: 1.2))
                .shadow(color: .black.opacity(0.52), radius: 28, y: 14)

            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: "bell.badge.fill")
                        .foregroundStyle(Color.orange)
                    Text("NEW EPISODE AVAILABLE")
                        .font(.system(size: 18, weight: .black, design: .rounded))
                        .kerning(1.1)
                        .foregroundStyle(Color.orange.opacity(0.98))
                }

                Text(showTitle)
                    .font(.system(size: 38, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                Text("\(seasonEpisodeText) • \(episode.title)")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))
                    .lineLimit(1)

                Text(episode.description.isEmpty ? "A verified new episode is ready. This test popup uses the same Watch Now, Find Links, Later, and Mark Seen focus path as a real alert." : episode.description)
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.70))
                    .lineLimit(3)
                    .frame(width: 820, alignment: .leading)

                HStack(spacing: 14) {
                    DemoAlertActionChip(title: "WATCH NOW", icon: "play.fill", selected: selectedAction == 0)
                    DemoAlertActionChip(title: isFindingLinks ? "FINDING" : "FIND LINKS", icon: "link", selected: selectedAction == 1)
                    DemoAlertActionChip(title: "LATER", icon: "clock.fill", selected: selectedAction == 2)
                    DemoAlertActionChip(title: "MARK SEEN", icon: "checkmark.seal.fill", selected: selectedAction == 3)
                }
                .padding(.top, 6)

                Text("Test alert mode • LEFT/RIGHT chooses an action • SELECT runs it • BACK closes")
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.48))
            }
        }
        .padding(28)
        .frame(width: 1240, height: 382, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .fill(LinearGradient(colors: [Color.black.opacity(0.92), Color.orange.opacity(0.16), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .overlay(RoundedRectangle(cornerRadius: 36, style: .continuous).stroke(Color.orange.opacity(0.34), lineWidth: 1.5))
        .shadow(color: .black.opacity(0.76), radius: 44, y: 22)
        .shadow(color: .orange.opacity(0.18), radius: 34, y: 6)
    }
}

struct DemoAlertActionChip: View {
    let title: String
    let icon: String
    let selected: Bool

    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .black))
            Text(title)
                .font(.system(size: 17, weight: .black, design: .rounded))
                .kerning(0.6)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 18)
        .frame(height: 54)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(selected ? Color.orange.opacity(0.42) : Color.white.opacity(0.10)))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(selected ? Color.orange.opacity(0.95) : Color.white.opacity(0.13), lineWidth: selected ? 3 : 1))
        .shadow(color: selected ? Color.orange.opacity(0.25) : Color.clear, radius: 18, y: 6)
        .scaleEffect(selected ? 1.055 : 1.0)
    }
}

struct DynamicInformationBar: View {
    let item: MediaItem
    let tomatoScore: String
    let criticScore: String
    let audienceScore: String
    @State private var page: Int = 0

    private var entries: [(String, String, String, Color)] {
        var result: [(String, String, String, Color)] = []
        result.append(("TOMATO", tomatoScore == "—" ? "Score pending" : "Tomato score \(tomatoScore)", "seal.fill", .red))
        result.append(("CRITICS", criticScore == "—" ? "Critic score pending" : "Critics \(criticScore)", "quote.bubble.fill", .yellow))
        result.append(("AUDIENCE", audienceScore == "—" ? "Audience score pending" : "Audience \(audienceScore)", "person.2.fill", .orange))
        if !item.catalog.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            result.append(("SOURCE", item.catalog, "sparkles.tv.fill", .cyan))
        }
        if let director = item.directors.first, !director.isEmpty {
            result.append(("DIRECTED BY", director, "person.crop.rectangle.stack.fill", .purple))
        } else if let cast = item.castMembers.first?.name, !cast.isEmpty {
            result.append(("CAST SPOTLIGHT", cast, "person.crop.circle.fill", .purple))
        }
        if let firstGenre = item.genres.first, !firstGenre.isEmpty {
            result.append(("MOOD", "\(firstGenre.uppercased()) • Premium metadata ready", "wand.and.stars", .blue))
        }
        return result
    }

    private var current: (String, String, String, Color) {
        let all = entries
        guard !all.isEmpty else { return ("INFO", "Metadata ready", "info.circle.fill", .orange) }
        return all[page % all.count]
    }

    var body: some View {
        let item = current
        HStack(spacing: 10) {
            Image(systemName: item.2)
                .font(.system(size: 15, weight: .black))
                .foregroundStyle(item.3.opacity(0.98))
                .frame(width: 22)
            Text(item.0)
                .font(.system(size: 10, weight: .black, design: .rounded))
                .kerning(0.8)
                .foregroundStyle(.white.opacity(0.56))
                .lineLimit(1)
            Text(item.1)
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(1)
            Spacer(minLength: 0)
            EmptyView()
        }
        .padding(.horizontal, 12)
        .background(
            LinearGradient(colors: [Color.black.opacity(0.44), item.3.opacity(0.12), Color.black.opacity(0.30)], startPoint: .leading, endPoint: .trailing),
            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(item.3.opacity(0.22), lineWidth: 0.9))
        .shadow(color: item.3.opacity(0.13), radius: 14, y: 4)
        .animation(.easeInOut(duration: 0.28), value: page)
        .onReceive(Timer.publish(every: 5.8, on: .main, in: .common).autoconnect()) { _ in
            let count = max(entries.count, 1)
            page = (page + 1) % count
        }
    }
}

struct CriticScorePill: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .black))
                .foregroundStyle(tint.opacity(0.96))
            Text(title)
                .font(.system(size: 11, weight: .black, design: .rounded))
                .kerning(1.0)
                .foregroundStyle(.white.opacity(0.62))
            Text(value)
                .font(.system(size: 17, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.96))
                .lineLimit(1)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 15, style: .continuous).fill(Color.black.opacity(0.40)))
        .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(tint.opacity(0.28), lineWidth: 1.2))
        .shadow(color: tint.opacity(0.16), radius: 16, y: 4)
    }
}

    private var popupActionRow: some View {
        HStack(spacing: 18) {
            ManualDetailButton(title: "PLAY", icon: "play.fill", selected: focus == .play)
            ManualDetailButton(title: trailerResolving ? "LOADING" : "TRAILER", icon: "film.fill", selected: focus == .trailer)
            ManualDetailButton(title: "YOUTUBE", icon: "play.rectangle.fill", selected: focus == .youtube)
            if !isSeriesItem {
                ManualDetailButton(title: isFindingLinks ? "FINDING" : "FIND LINKS", icon: "link", selected: focus == .findLinks)
            }
            ManualDetailButton(title: "CLOSE", icon: "xmark", selected: focus == .close)
        }
    }


    private var popupUtilityRow: some View {
        HStack(spacing: 12) {
            PopupUtilityActionChip(title: isCatalogFavorite ? "IN FAVORITES" : "ADD FAVORITE", icon: isCatalogFavorite ? "star.fill" : "star", tint: .yellow, selected: focus == .favorite)
                .contentShape(Capsule())
                .onTapGesture { focus = .favorite; activateDebounced() }

            if isSeriesItem {
                PopupUtilityActionChip(title: isFollowingShow ? "FOLLOWING" : "FOLLOW SHOW", icon: isFollowingShow ? "bell.badge.fill" : "bell", tint: .cyan, selected: focus == .follow)
                    .contentShape(Capsule())
                    .onTapGesture { focus = .follow; activateDebounced() }
            }

            if let verifiedEpisodeHint {
                PopupUtilityChip(title: verifiedEpisodeHint.uppercased(), icon: "checkmark.seal.fill", tint: .green)
            }

            if isSeriesItem {
                PopupUtilityActionChip(title: "TEST ALERT", icon: "bell.badge.fill", tint: .orange, selected: focus == .testAlert)
                    .contentShape(Capsule())
                    .onTapGesture { focus = .testAlert; activateDebounced() }
            }

            Spacer(minLength: 0)
        }
        .frame(width: 1038, height: 40, alignment: .leading)
    }

    private var popupStatusLine: some View {
        Text(streamStatusText(store.lastStreamMessage))
            .font(PopupTypography.font(popupFontPreset, size: 17, weight: .semibold))
            .foregroundStyle(.white.opacity(0.60))
            .lineLimit(2)
            .frame(width: 990, alignment: .leading)
    }

    private var popupRelatedSection: some View {
        // v527: Media DNA cards were replaced by the Dynamic Showcase Area.
        // Keep this as a lightweight fallback hook for future deep-link discovery work.
        EmptyView()
    }

    private var popupBottomDiscoveryDeck: some View {
        // v527: Replace the old Explore More cards with a non-focusable cinematic showcase.
        // This keeps the bottom of the popup visually rich without creating clipping or focus issues.
        PopupBottomSummaryShelf(item: item)
            .frame(width: 1160, height: 86, alignment: .leading)
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .contentShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    @ViewBuilder
    private var sourcePanelLayer: some View {
        if sourcePanelVisible {
            SourceIntelligenceFullOverlay(
                item: sourceSearchItem ?? item,
                focus: focus,
                visibleLinks: visibleLinks,
                linkWindowStart: linkWindowStart,
                totalLinkCount: store.streamLinks.count,
                isScanning: isFindingLinks
            )
            .padding(.top, 170)
            .zIndex(8)
            .transition(.opacity.combined(with: .scale(scale: 0.985)))
        }
    }

    @ViewBuilder
    private var demoEpisodeAlertLayer: some View {
        if demoEpisodeAlertVisible {
            DemoNewEpisodeAlertOverlay(
                showTitle: item.title,
                episode: demoEpisodeAlertItem ?? makeDemoEpisodeAlertItem(),
                selectedAction: demoEpisodeAlertFocus,
                isFindingLinks: isFindingLinks
            )
            .padding(.top, 210)
            .zIndex(9)
            .transition(.opacity.combined(with: .scale(scale: 0.985)))
        }
    }

    @ViewBuilder
    private var popupTrailerLayer: some View {
        if trailerPopup, let trailerURL {
            TrailerPopup(url: trailerURL, audioURL: nil, sessionKey: "\(item.id)|\(item.title)|\(trailerURL.absoluteString)") {
                trailerPopup = false
                self.trailerURL = nil
                focused = true
            }
            .zIndex(10)
        }
    }


    private func makeDemoEpisodeAlertItem() -> MediaItem {
        let season = selectedSeasonNumber <= 0 ? 1 : selectedSeasonNumber
        let episodeNumber = 1
        let baseID = item.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? item.title : item.id
        return MediaItem(
            id: "\(baseID):\(season):\(episodeNumber)",
            title: "\(item.title) S\(String(format: "%02d", season))E\(String(format: "%02d", episodeNumber))",
            year: item.year,
            type: "series",
            catalog: item.catalog,
            description: "Demo verified new-episode alert. This uses the same popup, focus buttons, and Source Intelligence path that a real new episode alert will use.",
            genres: item.genres,
            rating: item.rating,
            posterURL: item.posterURL,
            landscapeURL: item.landscapeURL,
            logoURL: item.logoURL,
            previewURL: item.previewURL,
            addonName: item.addonName,
            addonIconURL: item.addonIconURL,
            seasonNumber: season,
            episodeNumber: episodeNumber,
            cast: item.cast,
            directors: item.directors,
            castMembers: item.castMembers
        )
    }

    private func showTestNewEpisodeAlert() {
        Task {
            if episodeItems.isEmpty {
                await MainActor.run { isLoadingEpisodes = true }
                let fetched = await store.fetchSeriesEpisodes(for: item)
                await MainActor.run {
                    episodeItems = fetched
                    isLoadingEpisodes = false
                }
            }
            await MainActor.run {
                let preferred = filteredEpisodeItems.first ?? episodeItems.first ?? makeDemoEpisodeAlertItem()
                demoEpisodeAlertItem = preferred
                demoEpisodeAlertFocus = 0
                demoEpisodeAlertVisible = true
                sourcePanelVisible = false
                store.status = "Showing test new-episode alert for \(preferred.title)"
            }
        }
    }

    private func runDemoAlertFindLinks() {
        let episode = demoEpisodeAlertItem ?? makeDemoEpisodeAlertItem()
        demoEpisodeAlertVisible = false
        sourceSearchItem = episode
        sourcePanelVisible = true
        linkWindowStart = 0
        sourcePanelLastFocusedIndex = 0
        focus = .stream(0)
        Task {
            isFindingLinks = true
            _ = await store.findStreams(for: episode)
            isFindingLinks = false
            linkWindowStart = 0
            sourcePanelLastFocusedIndex = 0
            focus = store.streamLinks.isEmpty ? .testAlert : .stream(0)
        }
    }

    private func routeDemoEpisodeAlert(_ direction: MoveCommandDirection) {
        switch direction {
        case .left:
            demoEpisodeAlertFocus = max(0, demoEpisodeAlertFocus - 1)
        case .right:
            demoEpisodeAlertFocus = min(3, demoEpisodeAlertFocus + 1)
        case .up, .down:
            break
        default:
            break
        }
    }

    private func activateDemoEpisodeAlert() {
        switch demoEpisodeAlertFocus {
        case 0:
            let episode = demoEpisodeAlertItem ?? makeDemoEpisodeAlertItem()
            demoEpisodeAlertVisible = false
            Task { isFindingLinks = true; await store.playFirstDirectStream(for: episode); isFindingLinks = false }
        case 1:
            runDemoAlertFindLinks()
        case 2:
            demoEpisodeAlertVisible = false
            focus = .testAlert
        default:
            demoEpisodeAlertVisible = false
            focus = .testAlert
            store.status = "Test alert marked seen"
        }
    }

    private func preloadEpisodesForHeroPopup() {
        guard episodeItems.isEmpty && !isLoadingEpisodes else { episodesVisible = true; return }
        episodesVisible = true
        Task {
            await MainActor.run { isLoadingEpisodes = true }
            let fetched = await store.fetchSeriesEpisodes(for: item)
            await MainActor.run {
                episodeItems = fetched
                isLoadingEpisodes = false
                if let first = seasonNumbers.first { selectedSeasonNumber = first }
                episodeWindowStart = 0
                seasonDropdownOpen = true
            }
        }
    }

    private func loadPopupHeaderDetails() {
        let key = popupTMDBApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        let currentID = item.id
        Task { @MainActor in
            if let details = await fetchPopupHeaderDetails(apiKey: key), item.id == currentID {
                popupHeaderDetails = details
            }
        }
    }

    private func fetchPopupHeaderDetails(apiKey key: String) async -> PopupHeaderDetails? {
        struct FoundItem: Decodable { let id: Int? }
        struct FindResponse: Decodable { let movie_results: [FoundItem]?; let tv_results: [FoundItem]? }
        struct SearchItem: Decodable { let id: Int? }
        struct SearchResponse: Decodable { let results: [SearchItem]? }
        struct Company: Decodable { let name: String? }
        struct Network: Decodable { let name: String? }
        struct MovieDetail: Decodable { let budget: Int?; let revenue: Int?; let runtime: Int?; let production_companies: [Company]? }
        struct TVDetail: Decodable { let episode_run_time: [Int]?; let number_of_seasons: Int?; let number_of_episodes: Int?; let status: String?; let networks: [Network]? }

        func fetch<T: Decodable>(_ type: T.Type, from url: URL) async -> T? {
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) { return nil }
                return try JSONDecoder().decode(T.self, from: data)
            } catch { return nil }
        }

        let normalizedType = item.type.lowercased()
        let isTV = normalizedType.contains("series") || normalizedType.contains("show") || normalizedType.contains("tv")
        let parts = item.id.split(separator: ":").map(String.init)
        var detailKind: String? = nil
        var detailID: String? = nil

        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            detailKind = (parts[1].lowercased() == "tv" || isTV) ? "tv" : "movie"
            detailID = parts[2]
        } else {
            let imdbID: String? = {
                if item.id.lowercased().hasPrefix("tt") { return item.id }
                if let match = item.id.range(of: #"tt\d{6,}"#, options: .regularExpression) { return String(item.id[match]) }
                return nil
            }()
            if let imdbID, let encoded = imdbID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
               let findURL = URL(string: "https://api.themoviedb.org/3/find/\(encoded)?api_key=\(key)&external_source=imdb_id"),
               let found = await fetch(FindResponse.self, from: findURL) {
                if let movieID = found.movie_results?.compactMap({ $0.id }).first { detailKind = "movie"; detailID = String(movieID) }
                else if let tvID = found.tv_results?.compactMap({ $0.id }).first { detailKind = "tv"; detailID = String(tvID) }
            }
        }

        // v483: If catalog/Cinemeta items do not carry a TMDB or IMDb id, use title+year search
        // so budget/revenue/runtime/studio can still appear when the user has a TMDB key.
        if detailKind == nil {
            let query = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
            if !query.isEmpty, let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                let searchKind = isTV ? "tv" : "movie"
                let cleanYear = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
                let yearParam = isTV ? "first_air_date_year" : "year"
                let yearSuffix = cleanYear.isEmpty ? "" : "&\(yearParam)=\(cleanYear)"
                if let searchURL = URL(string: "https://api.themoviedb.org/3/search/\(searchKind)?api_key=\(key)&query=\(encodedQuery)\(yearSuffix)"),
                   let search = await fetch(SearchResponse.self, from: searchURL),
                   let foundID = search.results?.compactMap({ $0.id }).first {
                    detailKind = searchKind
                    detailID = String(foundID)
                }
            }
        }

        guard let detailKind, let detailID, let url = URL(string: "https://api.themoviedb.org/3/\(detailKind)/\(detailID)?api_key=\(key)") else { return nil }
        if detailKind == "movie", let detail = await fetch(MovieDetail.self, from: url) {
            return PopupHeaderDetails(
                budget: detail.budget,
                revenue: detail.revenue,
                runtimeMinutes: detail.runtime,
                studio: detail.production_companies?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty }),
                seasons: nil,
                episodes: nil,
                status: nil,
                network: nil
            )
        }
        if detailKind == "tv", let detail = await fetch(TVDetail.self, from: url) {
            return PopupHeaderDetails(
                budget: nil,
                revenue: nil,
                runtimeMinutes: detail.episode_run_time?.first(where: { $0 > 0 }),
                studio: nil,
                seasons: detail.number_of_seasons,
                episodes: detail.number_of_episodes,
                status: detail.status,
                network: detail.networks?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty })
            )
        }
        return nil
    }


    private func pageSourceLinks(_ deltaPages: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let pageSize = sourceIntelligencePageSize
        let maxStart = max(0, ((store.streamLinks.count - 1) / pageSize) * pageSize)
        let newStart = min(max(linkWindowStart + (deltaPages * pageSize), 0), maxStart)
        linkWindowStart = newStart
        focus = .stream(newStart)
    }
    private func routeSourceIntelligencePanel(_ direction: MoveCommandDirection) {
        guard !store.streamLinks.isEmpty else {
            focus = .findLinks
            linkWindowStart = 0
            return
        }
        let firstVisible = linkWindowStart
        let lastVisible = min(linkWindowStart + visibleLinks.count - 1, store.streamLinks.count - 1)
        let currentIndex: Int
        if case .stream(let index) = focus, index >= firstVisible, index <= lastVisible {
            currentIndex = index
        } else {
            currentIndex = min(max(sourcePanelLastFocusedIndex, firstVisible), lastVisible)
            focus = .stream(currentIndex)
        }

        switch direction {
        case .up:
            let next = max(firstVisible, currentIndex - 1)
            sourcePanelLastFocusedIndex = next
            focus = .stream(next)
        case .down:
            let next = min(lastVisible, currentIndex + 1)
            sourcePanelLastFocusedIndex = next
            focus = .stream(next)
        case .left:
            pageSourceLinks(-1)
            sourcePanelLastFocusedIndex = linkWindowStart
        case .right:
            pageSourceLinks(1)
            sourcePanelLastFocusedIndex = linkWindowStart
        default:
            break
        }
    }

    private func route(_ direction: MoveCommandDirection) {
        if demoEpisodeAlertVisible {
            routeDemoEpisodeAlert(direction)
            return
        }
        if sourcePanelVisible {
            routeSourceIntelligencePanel(direction)
            return
        }
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close: break
            case .favorite, .follow, .testAlert: focus = .play
            case .season: focus = isSeriesItem ? .favorite : .play
            case .episode: focus = isSeriesItem ? .season(selectedSeasonIndex) : .play
            case .searchLinks, .stream: focus = .play
            case .related: focus = store.streamLinks.isEmpty ? .findLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close: focus = .favorite
            case .favorite, .follow, .testAlert:
                if isSeriesItem { focus = .season(selectedSeasonIndex) }
                else { focus = store.streamLinks.isEmpty ? .findLinks : .stream(linkWindowStart) }
            case .searchLinks:
                if !store.streamLinks.isEmpty { focus = .stream(linkWindowStart) }
            case .stream(let index):
                let previous = max(0, index - 1)
                focus = .stream(previous)
                ensureLinkVisible(previous)
            case .season:
                focus = filteredEpisodeItems.isEmpty ? .episodes : .episode(0)
            case .episode:
                // v524: bottom related poster rail removed; stay on the episode row.
                break
            case .related: break
            }
        case .left:
            switch focus {
            case .play: break
            case .favorite: break
            case .follow: focus = .favorite
            case .testAlert: focus = isSeriesItem ? .follow : .favorite
            case .trailer: focus = .play
            case .youtube: focus = .trailer
            case .findLinks: focus = .youtube
            case .episodes: focus = .findLinks
            case .close: focus = isSeriesItem ? .youtube : .findLinks
            case .searchLinks: focus = .findLinks
            case .season(let index):
                let prev = max(0, index - 1)
                selectedSeasonNumber = seasonNumbers[prev]
                episodeWindowStart = 0
                focus = .season(prev)
            case .stream:
                pageSourceLinks(-1)
            case .episode(let index):
                if index <= 0 { focus = .season(selectedSeasonIndex) } else { let previous = index - 1; focus = .episode(previous); ensureEpisodeVisible(previous) }
            case .related(let index):
                let previous = max(0, index - 1)
                focus = .related(previous)
                ensureRelatedVisible(previous)
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .favorite: focus = isSeriesItem ? .follow : .favorite
            case .follow: focus = isSeriesItem ? .testAlert : .follow
            case .testAlert: break
            case .trailer: focus = .youtube
            case .youtube: focus = isSeriesItem ? .close : .findLinks
            case .findLinks: focus = .close
            case .episodes: focus = .close
            case .close: focus = episodesVisible ? .season(selectedSeasonIndex) : (store.streamLinks.isEmpty ? .findLinks : .stream(linkWindowStart))
            case .season(let index):
                let next = min(max(seasonNumbers.count - 1, 0), index + 1)
                selectedSeasonNumber = seasonNumbers[next]
                episodeWindowStart = 0
                focus = .season(next)
            case .searchLinks:
                if !store.streamLinks.isEmpty { ensureLinkVisible(linkWindowStart); focus = .stream(linkWindowStart) }
            case .stream:
                pageSourceLinks(1)
            case .episode(let index):
                let next = min(max(filteredEpisodeItems.count - 1, 0), index + 1)
                focus = .episode(next)
                ensureEpisodeVisible(next)
            case .related(let index):
                let next = min(max(relatedItems.count - 1, 0), index + 1)
                focus = .related(next)
                ensureRelatedVisible(next)
            }
        default: break
        }
    }

    private func ensureRelatedVisible(_ absoluteIndex: Int) {
        guard !relatedItems.isEmpty else { relatedWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), relatedItems.count - 1)
        if clamped < relatedWindowStart {
            relatedWindowStart = clamped
        } else if clamped >= relatedWindowStart + 5 {
            relatedWindowStart = max(0, clamped - 4)
        }
    }

    private func playTrailerUsingSelectedMode() {
        let mode = trailerPlaybackMode.lowercased()
        if mode == "youtube" {
            openTrailerInYouTube()
            return
        }
        Task {
            let requestedID = item.id
            await MainActor.run {
                trailerPopup = false
                trailerURL = nil
                trailerResolving = true
                store.lastStreamMessage = "Loading trailer for \(item.title)…"
            }
            if let url = await store.resolvePlayableTrailerURL(for: item) {
                await MainActor.run {
                    guard requestedID == item.id else { return }
                    trailerResolving = false
                    trailerURL = url
                    trailerPopup = true
                }
            } else {
                await MainActor.run { trailerResolving = false }
                if mode == "automatic" {
                    openTrailerInYouTube()
                } else {
                    await MainActor.run { store.status = "No direct playable trailer found. Try Open in YouTube or switch Trailer Playback Mode to Automatic Fallback." }
                }
            }
        }
    }

    private func openTrailerInYouTube() {
        trailerResolving = true
        Task {
            let externalURL = await store.resolveTrailerWatchURL(for: item)
            await MainActor.run {
                trailerResolving = false
                guard let externalURL else {
                    store.status = "No YouTube trailer link found yet."
                    return
                }
                openYouTubeTrailerURL(externalURL)
            }
        }
    }

    @MainActor
    private func openYouTubeTrailerURL(_ url: URL) {
        let candidates = youtubeLaunchCandidates(from: url)
        func attempt(_ index: Int) {
            guard index < candidates.count else {
                store.status = "Could not open YouTube from this Apple TV. Make sure the YouTube app is installed, or switch Trailer Playback back to In-App Popup."
                return
            }
            UIApplication.shared.open(candidates[index], options: [:]) { success in
                if success {
                    store.status = "Opening trailer in YouTube…"
                } else {
                    attempt(index + 1)
                }
            }
        }
        attempt(0)
    }

    private func youtubeLaunchCandidates(from url: URL) -> [URL] {
        let raw = url.absoluteString
        let videoID = youtubeVideoID(from: raw)
        var out: [URL] = []
        if let videoID {
            // Prefer the HTTPS watch URL first on tvOS. Some YouTube custom schemes can
            // report success while opening the app shell without the selected video.
            out.append(contentsOf: [
                URL(string: "https://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "https://m.youtube.com/watch?v=\(videoID)"),
                URL(string: "youtube://watch?v=\(videoID)"),
                URL(string: "youtube://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "vnd.youtube://watch?v=\(videoID)"),
                URL(string: "youtube://watch/\(videoID)")
            ].compactMap { $0 })
        }
        out.append(url)
        let query = "\(item.title) \(item.year) official trailer".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? item.title
        out.append(URL(string: "https://www.youtube.com/results?search_query=\(query)")!)
        var seen = Set<String>()
        return out.filter { seen.insert($0.absoluteString).inserted }
    }

    private func youtubeVideoID(from raw: String) -> String? {
        let patterns = [
            #"[?&]v=([A-Za-z0-9_-]{11})"#,
            #"youtu\.be/([A-Za-z0-9_-]{11})"#,
            #"youtube\.com/embed/([A-Za-z0-9_-]{11})"#,
            #"youtube\.com/shorts/([A-Za-z0-9_-]{11})"#,
            #"youtubeVideoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"videoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"webpageUrl[\"':\s]+https?://[^\"'\s]+(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let ns = raw as NSString
            let range = NSRange(location: 0, length: ns.length)
            if let match = regex.firstMatch(in: raw, range: range), match.numberOfRanges > 1 {
                return ns.substring(with: match.range(at: 1))
            }
        }
        return nil
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + sourceIntelligencePageSize {
            linkWindowStart = max(0, clamped - sourceIntelligencePageSize + 1)
        }
    }

    private func ensureEpisodeVisible(_ absoluteIndex: Int) {
        guard !filteredEpisodeItems.isEmpty else { episodeWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), filteredEpisodeItems.count - 1)
        if clamped < episodeWindowStart {
            episodeWindowStart = clamped
        } else if clamped >= episodeWindowStart + 4 {
            episodeWindowStart = max(0, clamped - 3)
        }
    }

    private func activateDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastActionAt > 0.36 else { return }
        lastActionAt = now
        activate()
    }

    private func activate() {
        if demoEpisodeAlertVisible {
            activateDemoEpisodeAlert()
            return
        }
        switch focus {
        case .play:
            Task { isFindingLinks = true; await store.playFirstDirectStream(for: item); isFindingLinks = false }
        case .trailer:
            playTrailerUsingSelectedMode()
        case .youtube:
            openTrailerInYouTube()
        case .findLinks, .searchLinks:
            Task {
                episodesVisible = false
                sourceSearchItem = item
                sourcePanelVisible = true
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                sourcePanelLastFocusedIndex = 0
                focus = store.streamLinks.isEmpty ? .findLinks : .stream(0)
            }
        case .episodes:
            Task {
                isLoadingEpisodes = true
                if episodeItems.isEmpty { episodeItems = await store.fetchSeriesEpisodes(for: item) }
                isLoadingEpisodes = false
                episodesVisible = true
                selectedSeasonNumber = seasonNumbers.first ?? 1
                seasonDropdownOpen = true
                episodeWindowStart = 0
                focus = episodeItems.isEmpty ? .episodes : .season(selectedSeasonIndex)
            }
        case .close:
            store.closeDetail()
        case .favorite:
            togglePopupFavorite()
        case .follow:
            if isSeriesItem { toggleFollowShow() }
        case .testAlert:
            if isSeriesItem { showTestNewEpisodeAlert() }
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            sourcePanelLastFocusedIndex = index
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: sourceSearchItem ?? item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.vodLinkPrimaryLine) • \(link.vodLinkDetailLine). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver service is needed for magnet/infoHash/debrid-only links."
            }
        case .season(let index):
            guard seasonNumbers.indices.contains(index) else { return }
            selectedSeasonNumber = seasonNumbers[index]
            seasonDropdownOpen = true
            episodeWindowStart = 0
            focus = filteredEpisodeItems.isEmpty ? .season(index) : .episode(0)
        case .episode(let index):
            guard filteredEpisodeItems.indices.contains(index) else { return }
            var episode = filteredEpisodeItems[index]
            if episode.castMembers.isEmpty { episode.castMembers = item.castMembers }
            if episode.cast.isEmpty { episode.cast = item.cast }
            if episode.directors.isEmpty { episode.directors = item.directors }
            sourceSearchItem = episode
            sourcePanelVisible = true
            linkWindowStart = 0
            sourcePanelLastFocusedIndex = 0
            focus = .stream(0)
            Task {
                isFindingLinks = true
                _ = await store.findStreams(for: episode)
                isFindingLinks = false
                linkWindowStart = 0
                sourcePanelLastFocusedIndex = 0
                focus = store.streamLinks.isEmpty ? .episode(index) : .stream(0)
            }
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}

struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var canvasFocused: Bool
    @State private var focus: DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var trailerResolving = false
    @State private var isFindingLinks = false
    @State private var isLoadingEpisodes = false
    @State private var episodeItems: [MediaItem] = []
    @State private var episodesVisible = false
    @State private var episodeWindowStart: Int = 0
    @State private var selectedSeasonNumber: Int = 1
    @State private var seasonDropdownOpen = false
    @State private var lastRemoteActionAt: TimeInterval = 0
    @State private var linkWindowStart: Int = 0
    @State private var sourcePanelVisible = false
    @State private var sourcePanelLastFocusedIndex: Int = 0
    @State private var sourceSearchItem: MediaItem? = nil
    @State private var demoEpisodeAlertVisible: Bool = false
    @State private var demoEpisodeAlertFocus: Int = 0
    @State private var demoEpisodeAlertItem: MediaItem? = nil
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"
    @AppStorage("trailerProviderMode") private var trailerProviderMode: String = "auto"
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"
    @AppStorage("tmdbApiKey") private var popupTMDBApiKey: String = ""
    @State private var popupHeaderDetails: PopupHeaderDetails? = nil

    private let sourceIntelligencePageSize = 5

    enum DetailNode: Hashable {
        case play, trailer, youtube, findLinks, episodes, close, searchLinks, favorite, follow, testAlert
        case stream(Int)
        case season(Int)
        case episode(Int)
        case related(Int)
    }

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(8))
    }

    let maxVisibleStreamLinks = 5
    let maxVisibleEpisodes = 6

    private var isSeriesItem: Bool {
        let lower = item.type.lowercased()
        return lower.contains("series") || lower.contains("show")
    }

    var seasonNumbers: [Int] {
        let values = Set(episodeItems.map { $0.seasonNumber ?? 1 })
        return values.isEmpty ? [selectedSeasonNumber] : values.sorted()
    }

    var selectedSeasonIndex: Int {
        seasonNumbers.firstIndex(of: selectedSeasonNumber) ?? 0
    }

    var filteredEpisodeItems: [MediaItem] {
        episodeItems.filter { ($0.seasonNumber ?? 1) == selectedSeasonNumber }
    }

    var visibleEpisodeItems: [MediaItem] {
        Array(filteredEpisodeItems.dropFirst(episodeWindowStart).prefix(maxVisibleEpisodes))
    }

    var visibleLinks: [StreamLink] {
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(maxVisibleStreamLinks))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            DetailBackdropArtwork(item: item)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.28))
                .overlay(LinearGradient(colors: [.black.opacity(0.78), .black.opacity(0.20), .black.opacity(0.62)], startPoint: .leading, endPoint: .trailing))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom))

            VStack(alignment: .leading, spacing: 24) {
                Spacer().frame(height: 250)

                // v251: detail page keeps themed artwork logos static; popup removed fallback text logos/pulse.
                HeroLogoText(item: item, pulse: false)
                    .frame(width: 780, height: 132, alignment: .leading)
                    .padding(.leading, 84)

                HStack(spacing: 30) {
                    Text(item.genres.first?.uppercased() ?? item.type.uppercased())
                    Text(item.year)
                    Text(item.type.uppercased())
                    Text("152min")
                    Text("🍅 80%")
                    Text("🍿 82%")
                    Text("★ \(item.rating)")
                }
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white.opacity(0.86))
                .padding(.leading, 84)

                HStack(spacing: 22) {
                    ManualDetailButton(title: "PLAY", icon: "play.fill", selected: focus == .play)
                    ManualDetailButton(title: trailerResolving ? "LOADING" : "TRAILER", icon: "film.fill", selected: focus == .trailer)
                    ManualDetailButton(title: "YOUTUBE", icon: "play.rectangle.fill", selected: focus == .youtube)
                    ManualDetailButton(title: isFindingLinks ? "FINDING" : "FIND LINKS", icon: "link", selected: focus == .findLinks)
                    if isSeriesItem {
                        ManualDetailButton(title: isLoadingEpisodes ? "LOADING" : "EPISODES", icon: "list.bullet.rectangle", selected: focus == .episodes)
                    }
                    ManualDetailButton(title: "CLOSE", icon: "xmark", selected: focus == .close)
                }
                .padding(.leading, 84)

                Text(streamStatusText(store.lastStreamMessage))
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.leading, 84)
                    .frame(width: 980, alignment: .leading)

                if episodesVisible {
                    ManualEpisodesRow(focus: focus, visibleEpisodes: visibleEpisodeItems, episodeWindowStart: episodeWindowStart, totalEpisodeCount: filteredEpisodeItems.count, seasonNumbers: seasonNumbers, selectedSeasonNumber: selectedSeasonNumber, seasonDropdownOpen: seasonDropdownOpen)
                        .padding(.leading, 84)
                }

                ManualStreamLinksRow(focus: focus, visibleLinks: visibleLinks, linkWindowStart: linkWindowStart, totalLinkCount: store.streamLinks.count)
                    .padding(.leading, 84)

                Spacer()

                VStack(alignment: .leading, spacing: 12) {
                    ManualRelatedRow(focus: focus, relatedItems: relatedItems, compact: true)
                }
                .foregroundStyle(.white)
                .padding(.leading, 84)
                .padding(.bottom, 46)
            }

            VStack(alignment: .leading, spacing: 14) {
                Text(item.description)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .foregroundStyle(Color.orange.opacity(0.98))
                CastCreditsSummary(item: item, compact: false)
            }
            .font(.system(size: 14, weight: .medium))
            .foregroundStyle(.white.opacity(0.80))
            .padding(16)
            .frame(width: 430, alignment: .leading)
            .frame(minHeight: 248, alignment: .leading)
            .background(.ultraThinMaterial.opacity(0.46), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.14), lineWidth: 1))
            // v160: mathematically pinned beside the stream-link arrow area, moved a half-inch right from v159.
            .position(x: 1238, y: 622)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL, audioURL: nil, sessionKey: "\(item.id)|\(item.title)|\(trailerURL.absoluteString)") {
                    trailerPopup = false
                    self.trailerURL = nil
                    canvasFocused = true
                }
                .zIndex(10)
            }
        }
        .focusable(true)
        .focused($canvasFocused)
        .onAppear {
            canvasFocused = true
            focus = .play
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
        }
        .onChange(of: item.id) { _ in
            trailerPopup = false
            trailerURL = nil
            trailerResolving = false
        }
        .onTapGesture { activateFocusedNodeDebounced() }
        .onPlayPauseCommand { activateFocusedNodeDebounced() }
        .onMoveCommand { direction in route(direction) }
        .task(id: item.id) {
            // v503: keep Details/Search popup instant. Trailer resolving starts only
            // when the Trailer/YouTube action is selected.
            trailerPopup = false
            trailerURL = nil
        }
        .onExitCommand {
            if trailerPopup { trailerPopup = false; trailerURL = nil } else { store.closeDetail() }
        }
    }


    private func makeDemoEpisodeAlertItem() -> MediaItem {
        let season = selectedSeasonNumber <= 0 ? 1 : selectedSeasonNumber
        let episodeNumber = 1
        let baseID = item.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? item.title : item.id
        return MediaItem(
            id: "\(baseID):\(season):\(episodeNumber)",
            title: "\(item.title) S\(String(format: "%02d", season))E\(String(format: "%02d", episodeNumber))",
            year: item.year,
            type: "series",
            catalog: item.catalog,
            description: "Demo verified new-episode alert. This uses the same popup, focus buttons, and Source Intelligence path that a real new episode alert will use.",
            genres: item.genres,
            rating: item.rating,
            posterURL: item.posterURL,
            landscapeURL: item.landscapeURL,
            logoURL: item.logoURL,
            previewURL: item.previewURL,
            addonName: item.addonName,
            addonIconURL: item.addonIconURL,
            seasonNumber: season,
            episodeNumber: episodeNumber,
            cast: item.cast,
            directors: item.directors,
            castMembers: item.castMembers
        )
    }

    private func showTestNewEpisodeAlert() {
        Task {
            if episodeItems.isEmpty {
                await MainActor.run { isLoadingEpisodes = true }
                let fetched = await store.fetchSeriesEpisodes(for: item)
                await MainActor.run {
                    episodeItems = fetched
                    isLoadingEpisodes = false
                }
            }
            await MainActor.run {
                let preferred = filteredEpisodeItems.first ?? episodeItems.first ?? makeDemoEpisodeAlertItem()
                demoEpisodeAlertItem = preferred
                demoEpisodeAlertFocus = 0
                demoEpisodeAlertVisible = true
                sourcePanelVisible = false
                store.status = "Showing test new-episode alert for \(preferred.title)"
            }
        }
    }

    private func runDemoAlertFindLinks() {
        let episode = demoEpisodeAlertItem ?? makeDemoEpisodeAlertItem()
        demoEpisodeAlertVisible = false
        sourceSearchItem = episode
        sourcePanelVisible = true
        linkWindowStart = 0
        sourcePanelLastFocusedIndex = 0
        focus = .stream(0)
        Task {
            isFindingLinks = true
            _ = await store.findStreams(for: episode)
            isFindingLinks = false
            linkWindowStart = 0
            sourcePanelLastFocusedIndex = 0
            focus = store.streamLinks.isEmpty ? .testAlert : .stream(0)
        }
    }

    private func routeDemoEpisodeAlert(_ direction: MoveCommandDirection) {
        switch direction {
        case .left:
            demoEpisodeAlertFocus = max(0, demoEpisodeAlertFocus - 1)
        case .right:
            demoEpisodeAlertFocus = min(3, demoEpisodeAlertFocus + 1)
        case .up, .down:
            break
        default:
            break
        }
    }

    private func activateDemoEpisodeAlert() {
        switch demoEpisodeAlertFocus {
        case 0:
            let episode = demoEpisodeAlertItem ?? makeDemoEpisodeAlertItem()
            demoEpisodeAlertVisible = false
            Task { isFindingLinks = true; await store.playFirstDirectStream(for: episode); isFindingLinks = false }
        case 1:
            runDemoAlertFindLinks()
        case 2:
            demoEpisodeAlertVisible = false
            focus = .testAlert
        default:
            demoEpisodeAlertVisible = false
            focus = .testAlert
            store.status = "Test alert marked seen"
        }
    }

    private func loadPopupHeaderDetails() {
        let key = popupTMDBApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        let currentID = item.id
        Task { @MainActor in
            if let details = await fetchPopupHeaderDetails(apiKey: key), item.id == currentID {
                popupHeaderDetails = details
            }
        }
    }

    private func fetchPopupHeaderDetails(apiKey key: String) async -> PopupHeaderDetails? {
        struct FoundItem: Decodable { let id: Int? }
        struct FindResponse: Decodable { let movie_results: [FoundItem]?; let tv_results: [FoundItem]? }
        struct SearchItem: Decodable { let id: Int? }
        struct SearchResponse: Decodable { let results: [SearchItem]? }
        struct Company: Decodable { let name: String? }
        struct Network: Decodable { let name: String? }
        struct MovieDetail: Decodable { let budget: Int?; let revenue: Int?; let runtime: Int?; let production_companies: [Company]? }
        struct TVDetail: Decodable { let episode_run_time: [Int]?; let number_of_seasons: Int?; let number_of_episodes: Int?; let status: String?; let networks: [Network]? }

        func fetch<T: Decodable>(_ type: T.Type, from url: URL) async -> T? {
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) { return nil }
                return try JSONDecoder().decode(T.self, from: data)
            } catch { return nil }
        }

        let normalizedType = item.type.lowercased()
        let isTV = normalizedType.contains("series") || normalizedType.contains("show") || normalizedType.contains("tv")
        let parts = item.id.split(separator: ":").map(String.init)
        var detailKind: String? = nil
        var detailID: String? = nil

        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            detailKind = (parts[1].lowercased() == "tv" || isTV) ? "tv" : "movie"
            detailID = parts[2]
        } else {
            let imdbID: String? = {
                if item.id.lowercased().hasPrefix("tt") { return item.id }
                if let match = item.id.range(of: #"tt\d{6,}"#, options: .regularExpression) { return String(item.id[match]) }
                return nil
            }()
            if let imdbID, let encoded = imdbID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
               let findURL = URL(string: "https://api.themoviedb.org/3/find/\(encoded)?api_key=\(key)&external_source=imdb_id"),
               let found = await fetch(FindResponse.self, from: findURL) {
                if let movieID = found.movie_results?.compactMap({ $0.id }).first { detailKind = "movie"; detailID = String(movieID) }
                else if let tvID = found.tv_results?.compactMap({ $0.id }).first { detailKind = "tv"; detailID = String(tvID) }
            }
        }

        // v483: If catalog/Cinemeta items do not carry a TMDB or IMDb id, use title+year search
        // so budget/revenue/runtime/studio can still appear when the user has a TMDB key.
        if detailKind == nil {
            let query = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
            if !query.isEmpty, let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
                let searchKind = isTV ? "tv" : "movie"
                let cleanYear = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
                let yearParam = isTV ? "first_air_date_year" : "year"
                let yearSuffix = cleanYear.isEmpty ? "" : "&\(yearParam)=\(cleanYear)"
                if let searchURL = URL(string: "https://api.themoviedb.org/3/search/\(searchKind)?api_key=\(key)&query=\(encodedQuery)\(yearSuffix)"),
                   let search = await fetch(SearchResponse.self, from: searchURL),
                   let foundID = search.results?.compactMap({ $0.id }).first {
                    detailKind = searchKind
                    detailID = String(foundID)
                }
            }
        }

        guard let detailKind, let detailID, let url = URL(string: "https://api.themoviedb.org/3/\(detailKind)/\(detailID)?api_key=\(key)") else { return nil }
        if detailKind == "movie", let detail = await fetch(MovieDetail.self, from: url) {
            return PopupHeaderDetails(
                budget: detail.budget,
                revenue: detail.revenue,
                runtimeMinutes: detail.runtime,
                studio: detail.production_companies?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty }),
                seasons: nil,
                episodes: nil,
                status: nil,
                network: nil
            )
        }
        if detailKind == "tv", let detail = await fetch(TVDetail.self, from: url) {
            return PopupHeaderDetails(
                budget: nil,
                revenue: nil,
                runtimeMinutes: detail.episode_run_time?.first(where: { $0 > 0 }),
                studio: nil,
                seasons: detail.number_of_seasons,
                episodes: detail.number_of_episodes,
                status: detail.status,
                network: detail.networks?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty })
            )
        }
        return nil
    }


    private func pageSourceLinks(_ deltaPages: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let pageSize = sourceIntelligencePageSize
        let maxStart = max(0, ((store.streamLinks.count - 1) / pageSize) * pageSize)
        let newStart = min(max(linkWindowStart + (deltaPages * pageSize), 0), maxStart)
        linkWindowStart = newStart
        focus = .stream(newStart)
    }
    private func route(_ direction: MoveCommandDirection) {
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close:
                canvasFocused = true
            case .favorite, .follow, .testAlert:
                focus = .play
            case .searchLinks, .stream, .season, .episode:
                focus = .play
            case .related:
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .youtube, .findLinks, .episodes, .close:
                focus = .searchLinks
            case .favorite, .follow, .testAlert:
                focus = .searchLinks
            case .searchLinks:
                if !store.streamLinks.isEmpty { focus = .stream(linkWindowStart) }
            case .stream:
                pageSourceLinks(1)
            case .season:
                focus = filteredEpisodeItems.isEmpty ? .searchLinks : .episode(0)
            case .episode:
                focus = .related(0)
            case .related:
                break
            }
        case .left:
            switch focus {
            case .play: break
            case .favorite: focus = .play
            case .follow: focus = .favorite
            case .testAlert: focus = isSeriesItem ? .follow : .favorite
            case .trailer: focus = .play
            case .youtube: focus = .trailer
            case .findLinks: focus = .youtube
            case .episodes: focus = .findLinks
            case .close: focus = isSeriesItem ? .youtube : .findLinks
            case .searchLinks: focus = .close
            case .season(let index):
                let prev = max(0, index - 1)
                selectedSeasonNumber = seasonNumbers[prev]
                episodeWindowStart = 0
                focus = .season(prev)
            case .stream:
                pageSourceLinks(-1)
            case .episode(let index):
                if index <= 0 { focus = .episodes } else {
                    let previous = index - 1
                    focus = .episode(previous)
                    ensureEpisodeVisible(previous)
                }
            case .related(let index): focus = .related(max(0, index - 1))
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .favorite: focus = .follow
            case .follow: focus = .testAlert
            case .testAlert: focus = .trailer
            case .trailer: focus = .youtube
            case .youtube: focus = isSeriesItem ? .close : .findLinks
            case .findLinks: focus = .close
            case .episodes: focus = .close
            case .close: focus = episodesVisible ? .season(selectedSeasonIndex) : .searchLinks
            case .season(let index):
                let next = min(max(seasonNumbers.count - 1, 0), index + 1)
                selectedSeasonNumber = seasonNumbers[next]
                episodeWindowStart = 0
                focus = .season(next)
            case .searchLinks:
                if !store.streamLinks.isEmpty {
                    ensureLinkVisible(linkWindowStart)
                    focus = .stream(linkWindowStart)
                }
            case .stream:
                pageSourceLinks(1)
            case .episode(let index):
                let next = min(max(filteredEpisodeItems.count - 1, 0), index + 1)
                focus = .episode(next)
                ensureEpisodeVisible(next)
            case .related(let index): focus = .related(min(max(relatedItems.count - 1, 0), index + 1))
            }
        default:
            break
        }
    }

    private func playTrailerUsingSelectedMode() {
        let mode = trailerPlaybackMode.lowercased()
        if mode == "youtube" {
            openTrailerInYouTube()
            return
        }
        Task {
            let requestedID = item.id
            await MainActor.run {
                trailerPopup = false
                trailerURL = nil
                trailerResolving = true
                store.lastStreamMessage = "Loading trailer for \(item.title)…"
            }
            if let url = await store.resolvePlayableTrailerURL(for: item) {
                await MainActor.run {
                    guard requestedID == item.id else { return }
                    trailerResolving = false
                    trailerURL = url
                    trailerPopup = true
                }
            } else {
                await MainActor.run { trailerResolving = false }
                if mode == "automatic" {
                    openTrailerInYouTube()
                } else {
                    await MainActor.run { store.status = "No direct playable trailer found. Try Open in YouTube or switch Trailer Playback Mode to Automatic Fallback." }
                }
            }
        }
    }

    private func openTrailerInYouTube() {
        trailerResolving = true
        Task {
            let externalURL = await store.resolveTrailerWatchURL(for: item)
            await MainActor.run {
                trailerResolving = false
                guard let externalURL else {
                    store.status = "No YouTube trailer link found yet."
                    return
                }
                openYouTubeTrailerURL(externalURL)
            }
        }
    }

    @MainActor
    private func openYouTubeTrailerURL(_ url: URL) {
        let candidates = youtubeLaunchCandidates(from: url)
        func attempt(_ index: Int) {
            guard index < candidates.count else {
                store.status = "Could not open YouTube from this Apple TV. Make sure the YouTube app is installed, or switch Trailer Playback back to In-App Popup."
                return
            }
            UIApplication.shared.open(candidates[index], options: [:]) { success in
                if success {
                    store.status = "Opening trailer in YouTube…"
                } else {
                    attempt(index + 1)
                }
            }
        }
        attempt(0)
    }

    private func youtubeLaunchCandidates(from url: URL) -> [URL] {
        let raw = url.absoluteString
        let videoID = youtubeVideoID(from: raw)
        var out: [URL] = []
        if let videoID {
            // Prefer the HTTPS watch URL first on tvOS. Some YouTube custom schemes can
            // report success while opening the app shell without the selected video.
            out.append(contentsOf: [
                URL(string: "https://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "https://m.youtube.com/watch?v=\(videoID)"),
                URL(string: "youtube://watch?v=\(videoID)"),
                URL(string: "youtube://www.youtube.com/watch?v=\(videoID)"),
                URL(string: "vnd.youtube://watch?v=\(videoID)"),
                URL(string: "youtube://watch/\(videoID)")
            ].compactMap { $0 })
        }
        out.append(url)
        let query = "\(item.title) \(item.year) official trailer".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? item.title
        out.append(URL(string: "https://www.youtube.com/results?search_query=\(query)")!)
        var seen = Set<String>()
        return out.filter { seen.insert($0.absoluteString).inserted }
    }

    private func youtubeVideoID(from raw: String) -> String? {
        let patterns = [
            #"[?&]v=([A-Za-z0-9_-]{11})"#,
            #"youtu\.be/([A-Za-z0-9_-]{11})"#,
            #"youtube\.com/embed/([A-Za-z0-9_-]{11})"#,
            #"youtube\.com/shorts/([A-Za-z0-9_-]{11})"#,
            #"youtubeVideoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"youtube_video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"video_id[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"videoId[\"':\s]+([A-Za-z0-9_-]{11})"#,
            #"webpageUrl[\"':\s]+https?://[^\"'\s]+(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})"#
        ]
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let ns = raw as NSString
            let range = NSRange(location: 0, length: ns.length)
            if let match = regex.firstMatch(in: raw, range: range), match.numberOfRanges > 1 {
                return ns.substring(with: match.range(at: 1))
            }
        }
        return nil
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + maxVisibleStreamLinks {
            linkWindowStart = max(0, clamped - maxVisibleStreamLinks + 1)
        }
    }

    private func ensureEpisodeVisible(_ absoluteIndex: Int) {
        guard !filteredEpisodeItems.isEmpty else { episodeWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), filteredEpisodeItems.count - 1)
        if clamped < episodeWindowStart {
            episodeWindowStart = clamped
        } else if clamped >= episodeWindowStart + maxVisibleEpisodes {
            episodeWindowStart = max(0, clamped - maxVisibleEpisodes + 1)
        }
    }

    private func activateFocusedNodeDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastRemoteActionAt > 0.38 else { return }
        lastRemoteActionAt = now
        activateFocusedNode()
    }

    private func activateFocusedNode() {
        switch focus {
        case .play:
            Task {
                isFindingLinks = true
                await store.playFirstDirectStream(for: item)
                isFindingLinks = false
            }
        case .trailer:
            playTrailerUsingSelectedMode()
        case .youtube:
            openTrailerInYouTube()
        case .findLinks, .searchLinks:
            Task {
                episodesVisible = false
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(0)
            }
        case .episodes:
            Task {
                isLoadingEpisodes = true
                if episodeItems.isEmpty { episodeItems = await store.fetchSeriesEpisodes(for: item) }
                isLoadingEpisodes = false
                episodesVisible = true
                selectedSeasonNumber = seasonNumbers.first ?? 1
                seasonDropdownOpen = true
                episodeWindowStart = 0
                focus = episodeItems.isEmpty ? .episodes : .season(selectedSeasonIndex)
            }
        case .close:
            store.closeDetail()
        case .favorite, .follow, .testAlert:
            break
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.vodLinkPrimaryLine) • \(link.vodLinkDetailLine). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver service is needed for magnet/infoHash/debrid-only links."
            }
        case .season(let index):
            guard seasonNumbers.indices.contains(index) else { return }
            selectedSeasonNumber = seasonNumbers[index]
            seasonDropdownOpen = true
            episodeWindowStart = 0
            focus = filteredEpisodeItems.isEmpty ? .season(index) : .episode(0)
        case .episode(let index):
            guard filteredEpisodeItems.indices.contains(index) else { return }
            var episode = filteredEpisodeItems[index]
            if episode.castMembers.isEmpty { episode.castMembers = item.castMembers }
            if episode.cast.isEmpty { episode.cast = item.cast }
            if episode.directors.isEmpty { episode.directors = item.directors }
            store.openDetail(episode, pushCurrent: true)
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}


struct PopupPremiumStatusChips: View {
    let item: MediaItem
    let isSeries: Bool
    let isFavorite: Bool
    let isFollowing: Bool
    let hasVerifiedEpisodeHint: Bool

    private var chips: [(String, String, Color)] {
        var values: [(String, String, Color)] = []
        if isFavorite { values.append(("FAVORITE", "star.fill", .yellow)) }
        if isSeries && isFollowing { values.append(("FOLLOWING", "bell.badge.fill", .cyan)) }
        if hasVerifiedEpisodeHint { values.append(("VERIFIED ALERTS", "checkmark.seal.fill", .green)) }
        if !item.rating.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { values.append(("RATED \(item.rating)", "star.circle.fill", .orange)) }
        if isSeries { values.append(("EPISODE WATCH", "calendar.badge.clock", .purple)) }
        values.append(("PREMIUM INFO", "sparkles", .cyan))
        return Array(values.prefix(5))
    }

    var body: some View {
        HStack(spacing: 9) {
            ForEach(Array(chips.enumerated()), id: \.offset) { _, chip in
                HStack(spacing: 6) {
                    Image(systemName: chip.1)
                        .font(.system(size: 11, weight: .black))
                    Text(chip.0)
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .kerning(0.75)
                }
                .foregroundStyle(Color.white.opacity(0.92))
                .padding(.horizontal, 10)
                .padding(.vertical, 7)
                .background(LinearGradient(colors: [chip.2.opacity(0.22), Color.black.opacity(0.34)], startPoint: .topLeading, endPoint: .bottomTrailing), in: Capsule())
                .overlay(Capsule().stroke(chip.2.opacity(0.26), lineWidth: 1))
                .shadow(color: chip.2.opacity(0.12), radius: 10, y: 3)
            }
            Spacer(minLength: 0)
        }
    }
}

struct PopupUtilityChip: View {
    let title: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .black))
            Text(title)
                .font(.system(size: 11, weight: .black, design: .rounded))
                .kerning(0.8)
        }
        .foregroundStyle(Color.white.opacity(0.94))
        .padding(.horizontal, 13)
        .padding(.vertical, 9)
        .background(LinearGradient(colors: [tint.opacity(0.25), Color.black.opacity(0.42)], startPoint: .topLeading, endPoint: .bottomTrailing), in: Capsule())
        .shadow(color: tint.opacity(0.14), radius: 12, y: 4)
    }
}


struct PopupUtilityActionChip: View {
    let title: String
    let icon: String
    let tint: Color
    let selected: Bool

    var body: some View {
        PopupUtilityChip(title: title, icon: icon, tint: tint)
            .scaleEffect(selected ? 1.08 : 1.0)
            .shadow(color: selected ? tint.opacity(0.34) : .clear, radius: selected ? 18 : 0, y: selected ? 6 : 0)
            .animation(.easeOut(duration: 0.16), value: selected)
    }
}

struct ManualDetailButton: View {
    let title: String
    var icon: String? = nil
    let selected: Bool

    private var isPrimary: Bool { title == "PLAY" || title == "CONTINUE" }
    private var buttonWidth: CGFloat {
        if isPrimary { return 170 }
        if title == "CLOSE" { return 132 }
        return 150
    }
    private var buttonHeight: CGFloat { isPrimary ? 70 : 64 }
    private var horizontalPadding: CGFloat { isPrimary ? 28 : 22 }
    private var selectedScale: CGFloat { selected ? 1.055 : 1.0 }
    private var strokeWidth: CGFloat { 0 }
    private var shadowRadius: CGFloat { selected ? 20 : 8 }
    private var shadowOffset: CGFloat { selected ? 5 : 3 }

    var body: some View {
        ManualDetailButtonContent(
            title: title,
            icon: icon,
            isPrimary: isPrimary
        )
        .foregroundStyle(foregroundColor)
        .padding(.horizontal, horizontalPadding)
        .frame(minWidth: buttonWidth)
        .frame(height: buttonHeight)
        .background(buttonFill, in: Capsule(style: .continuous))
        .scaleEffect(selectedScale)
        .shadow(color: shadowColor, radius: shadowRadius, y: shadowOffset)
        .animation(.spring(response: 0.22, dampingFraction: 0.82), value: selected)
    }

    private var foregroundColor: Color {
        if selected && isPrimary { return .black }
        return Color.white.opacity(selected ? 1.0 : 0.94)
    }

    private var shadowColor: Color {
        if !selected { return Color.black.opacity(0.22) }
        return isPrimary ? Color.cyan.opacity(0.52) : Color.white.opacity(0.16)
    }

    private var buttonBorder: some View {
        Capsule(style: .continuous)
            .stroke(buttonStroke, lineWidth: strokeWidth)
    }

    private var buttonGloss: some View {
        Capsule(style: .continuous)
            .fill(Color.white.opacity(selected ? 0.25 : 0.10))
            .frame(height: 21)
            .padding(.horizontal, 12)
            .padding(.top, 5)
            .allowsHitTesting(false)
    }

    private var buttonFill: LinearGradient {
        if selected && isPrimary {
            return LinearGradient(colors: [Color.cyan.opacity(0.98), Color.white.opacity(0.94)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
        if selected {
            return LinearGradient(colors: [Color.white.opacity(0.25), Color.white.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
        return LinearGradient(colors: [Color.white.opacity(0.13), Color.black.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }

    private var buttonStroke: Color {
        if selected && isPrimary { return Color.white.opacity(0.88) }
        if selected { return Color.cyan.opacity(0.55) }
        return Color.white.opacity(0.14)
    }
}

struct ManualDetailButtonContent: View {
    let title: String
    let icon: String?
    let isPrimary: Bool

    private var iconSize: CGFloat { isPrimary ? 22 : 18 }
    private var titleSize: CGFloat { isPrimary ? 22 : 19 }
    private var stackSpacing: CGFloat { isPrimary ? 12 : 10 }

    var body: some View {
        HStack(spacing: stackSpacing) {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.system(size: iconSize, weight: .black))
            }
            Text(title)
                .font(.system(size: titleSize, weight: .black, design: .rounded))
                .kerning(0.4)
                .lineLimit(1)
                .minimumScaleFactor(0.82)
        }
    }
}

struct CompactHeroCastRow: View {
    let item: MediaItem
    var title: String = "Cast"
    var maxMembers: Int = 7
    var compact: Bool = false

    private var displayMembers: [CastMember] {
        if !item.castMembers.isEmpty { return Array(item.castMembers.prefix(maxMembers)) }
        return Array(item.cast.prefix(maxMembers)).map { CastMember(name: $0, role: nil, imageURL: nil) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: compact ? 7 : 10) {
            if !displayMembers.isEmpty {
                Text(title.uppercased())
                    .font(.system(size: compact ? 13 : 15, weight: .black, design: .rounded))
                    .kerning(1.2)
                    .foregroundStyle(.white.opacity(0.58))
                HStack(spacing: compact ? 12 : 16) {
                    ForEach(displayMembers) { member in
                        CompactHeroCastCard(member: member, compact: compact)
                    }
                }
            }
        }
    }
}

struct CompactHeroCastCard: View {
    let member: CastMember
    var compact: Bool = false

    private var initials: String {
        let parts = member.name.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }.map(String.init).joined()
        return letters.isEmpty ? "?" : letters.uppercased()
    }

    var body: some View {
        HStack(spacing: compact ? 7 : 8) {
            ZStack {
                if let imageURL = member.imageURL, !imageURL.isEmpty {
                    RemoteImageFit(url: imageURL, mode: .fill)
                } else {
                    Circle()
                        .fill(LinearGradient(colors: [Color.white.opacity(0.18), Color.cyan.opacity(0.16), Color.orange.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Text(initials)
                        .font(.system(size: compact ? 12 : 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.88))
                }
            }
            .frame(width: compact ? 42 : 52, height: compact ? 42 : 52)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.20), lineWidth: 1))

            VStack(alignment: .leading, spacing: 1) {
                Text(member.name)
                    .font(.system(size: compact ? 12 : 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.94))
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
                if let role = member.role, !role.isEmpty {
                    Text(role)
                        .font(.system(size: compact ? 10 : 11, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.52))
                        .lineLimit(1)
                        .minimumScaleFactor(0.62)
                }
            }
            .frame(width: compact ? 98 : 122, alignment: .leading)
        }
        .padding(.horizontal, compact ? 8 : 10)
        .frame(width: compact ? 162 : 198, height: compact ? 56 : 68, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: compact ? 16 : 18, style: .continuous).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: compact ? 16 : 18, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct ManualEpisodesRow: View {
    let focus: DetailPage.DetailNode
    let visibleEpisodes: [MediaItem]
    let episodeWindowStart: Int
    let totalEpisodeCount: Int
    let seasonNumbers: [Int]
    let selectedSeasonNumber: Int
    let seasonDropdownOpen: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .center, spacing: 12) {
                Text("SEASONS")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .kerning(1.2)
                    .foregroundStyle(.white.opacity(0.58))
                if totalEpisodeCount > 0 {
                    Text("EPISODES \(episodeWindowStart + 1)-\(min(episodeWindowStart + visibleEpisodes.count, totalEpisodeCount)) OF \(totalEpisodeCount)")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .kerning(0.9)
                        .foregroundStyle(.white.opacity(0.42))
                }
            }

            HStack(spacing: 9) {
                ForEach(Array(seasonNumbers.prefix(10).enumerated()), id: \.element) { index, season in
                    let selected = selectedSeasonNumber == season
                    let focusedSeason = focus == .season(index)
                    Text("Season \(season)")
                        .font(.system(size: 15, weight: .black, design: .rounded))
                        .foregroundStyle(selected || focusedSeason ? Color.black : Color.white.opacity(0.88))
                        .padding(.horizontal, 16)
                        .frame(height: 34)
                        .background(RoundedRectangle(cornerRadius: 13, style: .continuous).fill(selected || focusedSeason ? Color.white.opacity(0.92) : Color.black.opacity(0.38)))
                        .overlay(RoundedRectangle(cornerRadius: 13, style: .continuous).stroke(focusedSeason ? Color.cyan.opacity(0.98) : Color.white.opacity(0.12), lineWidth: focusedSeason ? 2.5 : 1))
                }
            }

            HStack(spacing: 12) {
                if visibleEpisodes.isEmpty {
                    HStack(spacing: 12) {
                        ProgressView()
                            .scaleEffect(0.82)
                        Text("Loading episode previews and season metadata…")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.70))
                    }
                    .frame(width: 620, height: 158, alignment: .center)
                    .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Color.black.opacity(0.34)))
                    .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
                } else {
                    ForEach(Array(visibleEpisodes.enumerated()), id: \.element.id) { offset, episode in
                        let absolute = episodeWindowStart + offset
                        let selected = focus == .episode(absolute)
                        HeroEpisodePreviewCard(episode: episode, absoluteIndex: absolute, selected: selected)
                    }
                }
            }
        }
        .foregroundStyle(.white)
    }
}

struct HeroEpisodePreviewCard: View {
    let episode: MediaItem
    let absoluteIndex: Int
    let selected: Bool

    private var code: String {
        "S\(String(format: "%02d", episode.seasonNumber ?? 1))E\(String(format: "%02d", episode.episodeNumber ?? absoluteIndex + 1))"
    }

    private var image: String? {
        if let preview = episode.previewURL, !preview.isEmpty { return preview }
        if let landscape = episode.landscapeURL, !landscape.isEmpty { return landscape }
        return episode.posterURL
    }

    private var titleText: String {
        let cleaned = episode.title.replacingOccurrences(of: "  ", with: " ").trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? code : cleaned
    }

    private var detailText: String {
        let cleaned = episode.description.trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "Episode metadata ready" : cleaned
    }

    private var thumbnail: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: image, mode: .fill)
                .frame(width: 244, height: 122)
                .clipped()
            LinearGradient(colors: [Color.clear, Color.black.opacity(0.86)], startPoint: .top, endPoint: .bottom)
            Text(code)
                .font(.system(size: 16, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Capsule().fill(Color.black.opacity(0.54)))
                .padding(8)
        }
        .frame(width: 244, height: 122)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private var textBlock: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(titleText)
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.94))
                .lineLimit(1)
                .frame(width: 224, alignment: .leading)
            Text(detailText)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.56))
                .lineLimit(2)
                .frame(width: 224, height: 30, alignment: .topLeading)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            thumbnail
            textBlock
        }
        .padding(10)
        .frame(width: 264, height: 202, alignment: .topLeading)
        .background(cardBackground)
        .overlay(cardStroke)
        .shadow(color: selected ? Color.cyan.opacity(0.36) : Color.black.opacity(0.20), radius: selected ? 20 : 8, y: selected ? 7 : 3)
        .scaleEffect(selected ? 1.035 : 1.0)
        .animation(.easeOut(duration: 0.16), value: selected)
    }

    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .fill(selected ? Color.cyan.opacity(0.20) : Color.black.opacity(0.38))
    }

    private var cardStroke: some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .stroke(selected ? Color.cyan.opacity(0.98) : Color.white.opacity(0.12), lineWidth: selected ? 3 : 1)
    }
}


extension StreamLink {
    var vodLinkPrimaryLine: String {
        let provider = source.trimmingCharacters(in: .whitespacesAndNewlines)
        let qualityText = quality.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Unknown" : quality
        if provider.isEmpty { return qualityText }
        return "\(qualityText) • \(provider)"
    }

    var vodLinkDetailLine: String {
        var parts: [String] = []
        if !size.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { parts.append(size) }
        parts.append(contentsOf: vodFeatureTags)
        if !subtitleURLs.isEmpty { parts.append("Subs \(subtitleURLs.count)") }
        if let warning = vodLanguageWarning { parts.insert(warning, at: 0) }
        if parts.isEmpty { return "No technical metadata from provider" }
        return parts.prefix(7).joined(separator: " • ")
    }

    var vodLanguageWarning: String? {
        let h = " \(title) \(quality) \(source) ".lowercased()
        let englishHit = [" english", " eng", ".eng", "-eng", " en ", "[en", " en-", "truehd", "atmos"].contains { h.contains($0) }
        let nonEnglishSignals = [" spanish", " latino", " castellano", " spa", ".spa", " french", " fra", " german", " deu", " italian", " ita", " portuguese", " por", " polish", " pl ", " pldub", " russian", " rus", " hindi", " korean", " japanese", " jpn"]
        if !englishHit && nonEnglishSignals.contains(where: { h.contains($0) }) { return "⚠ Language check" }
        if h.contains("multi") || h.contains("dual") { return "Multi Audio" }
        return nil
    }

    private var vodFeatureTags: [String] {
        let haystack = "\(title) \(quality) \(source)".lowercased()
        var tags: [String] = []
        func add(_ value: String) { if !tags.contains(value) { tags.append(value) } }

        if haystack.contains("dolby vision") || haystack.contains("dovi") || haystack.contains(" dv ") || haystack.contains(".dv.") || haystack.contains("-dv-") { add("DV") }
        if haystack.contains("hdr10+") || haystack.contains("hdr10plus") { add("HDR10+") }
        else if haystack.contains("hdr10") || haystack.contains(" hdr ") || haystack.contains(".hdr.") || haystack.contains("-hdr-") { add("HDR") }
        if haystack.contains("hlg") { add("HLG") }
        if haystack.contains("av1") { add("AV1") }
        if haystack.contains("hevc") || haystack.contains("h.265") || haystack.contains("x265") { add("HEVC") }
        if haystack.contains("h.264") || haystack.contains("x264") || haystack.contains("avc") { add("H.264") }
        if haystack.contains("atmos") { add("Atmos") }
        if haystack.contains("truehd") || haystack.contains("true hd") { add("TrueHD") }
        if haystack.contains("dts-hd") || haystack.contains("dtshd") { add("DTS-HD") }
        else if haystack.contains(" dts ") || haystack.contains(".dts.") || haystack.contains("-dts-") { add("DTS") }
        if haystack.contains("ddp") || haystack.contains("eac3") || haystack.contains("e-ac3") || haystack.contains("dolby digital plus") { add("DD+") }
        else if haystack.contains(" ac3") || haystack.contains(".ac3") || haystack.contains("-ac3") { add("AC3") }
        if haystack.contains(" aac") || haystack.contains(".aac") || haystack.contains("-aac") { add("AAC") }

        let languagePatterns: [(String, [String])] = [
            ("English", [" english", " eng", ".eng", "-eng", " en ", "[en"]),
            ("Spanish", [" spanish", " spa", ".spa", "-spa", " es ", " latino"]),
            ("French", [" french", " fre", " fra", ".fre", ".fra", " fr "]),
            ("Japanese", [" japanese", " jpn", ".jpn", " ja "]),
            ("Korean", [" korean", " kor", ".kor", " ko "]),
            ("German", [" german", " ger", " deu", ".ger", ".deu", " de "]),
            ("Italian", [" italian", " ita", ".ita", " it "]),
            ("Portuguese", [" portuguese", " por", ".por", " pt "]),
            ("Polish", [" polish", " pldub", " pl ", ".pl."])
        ]
        for (name, patterns) in languagePatterns where patterns.contains(where: { haystack.contains($0) }) { add(name) }

        if haystack.contains("remux") { add("REMUX") }
        if haystack.contains("web-dl") || haystack.contains("webdl") { add("WEB-DL") }
        if haystack.contains("bluray") || haystack.contains("blu-ray") { add("BluRay") }
        return Array(tags.prefix(6))
    }
}


extension StreamLink {
    var intelligenceHaystack: String {
        [title, quality, size, source].joined(separator: " ").lowercased()
    }

    var detectedResolution: String {
        let h = intelligenceHaystack
        if h.contains("2160") || h.contains("4k") { return "4K" }
        if h.contains("1440") { return "1440p" }
        if h.contains("1080") { return "1080p" }
        if h.contains("720") { return "720p" }
        if !quality.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return quality }
        return "Quality Unknown"
    }

    var detectedCodec: String? {
        let h = intelligenceHaystack
        if h.contains("av1") { return "AV1" }
        if h.contains("hevc") || h.contains("h.265") || h.contains("x265") { return "HEVC" }
        if h.contains("h.264") || h.contains("x264") || h.contains("avc") { return "H.264" }
        if h.contains("mpeg2") { return "MPEG-2" }
        return nil
    }

    var detectedHDR: String? {
        let h = intelligenceHaystack
        if h.contains("dolby vision") || h.contains(" dv ") || h.contains("dovi") { return "Dolby Vision" }
        if h.contains("hdr10+") { return "HDR10+" }
        if h.contains("hdr10") || h.contains(" hdr ") { return "HDR" }
        if h.contains("sdr") { return "SDR" }
        return nil
    }

    var detectedAudio: String? {
        let h = intelligenceHaystack
        if h.contains("truehd") { return h.contains("atmos") ? "TrueHD Atmos" : "TrueHD" }
        if h.contains("atmos") { return "Atmos" }
        if h.contains("dts-hd") { return "DTS-HD" }
        if h.contains("dts") { return "DTS" }
        if h.contains("ddp") || h.contains("eac3") || h.contains("dd+") { return "DD+" }
        if h.contains("5.1") { return "5.1" }
        if h.contains("aac") { return "AAC" }
        if h.contains("stereo") || h.contains("2.0") { return "Stereo" }
        return nil
    }

    var detectedLanguage: String? {
        let h = intelligenceHaystack
        let englishTokens = ["[en", " en ", " english", "eng", "multi", "dual audio"]
        if englishTokens.contains(where: { h.contains($0) }) { return "English" }
        if h.contains("pldub") || h.contains(" polish") || h.contains("[pl") || h.contains(" lektor") { return "Polish" }
        if h.contains(" latino") || h.contains(" spanish") || h.contains("[es") || h.contains(" esp") { return "Spanish" }
        if h.contains(" german") || h.contains("[de") { return "German" }
        if h.contains(" french") || h.contains("[fr") { return "French" }
        if h.contains(" italian") || h.contains("[it") { return "Italian" }
        if h.contains(" japanese") || h.contains("[ja") { return "Japanese" }
        if h.contains(" korean") || h.contains("[ko") { return "Korean" }
        if h.contains(" hindi") || h.contains("[hi") { return "Hindi" }
        return nil
    }

    var sourceWarning: String? {
        guard let lang = detectedLanguage else { return nil }
        if lang != "English" && lang != "Multi" { return "Check audio: \(lang)" }
        return nil
    }

    var matchLabel: String {
        if let warning = sourceWarning { return warning }
        if detectedLanguage == "English" { return "English detected" }
        if isDirectPlayable { return "Direct playable" }
        return "Resolve needed"
    }

    var hasSubtitleInfo: Bool { !subtitleURLs.isEmpty || intelligenceHaystack.contains("sub") || intelligenceHaystack.contains("subs") }
    var subtitleLabel: String { hasSubtitleInfo ? "Subtitles available" : "Subtitle info unknown" }

    var providerDisplay: String {
        let clean = source.trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty ? "Unknown Provider" : clean
    }
}


struct PopupSourcePanelHint: View {
    let totalLinkCount: Int
    let isScanning: Bool
    let sourcePanelVisible: Bool

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: sourcePanelVisible ? "rectangle.stack.fill" : "link")
                .font(.system(size: 14, weight: .black))
                .foregroundStyle(Color.cyan.opacity(0.95))
            Text(isScanning ? "Scanning addons…" : totalLinkCount > 0 ? "Sources ready" : "Press Find Links to open Source Intelligence")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.76))
            Spacer(minLength: 0)
            if totalLinkCount > 0 {
                Text("\(totalLinkCount) links")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.54))
            }
        }
        .padding(.horizontal, 14)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(Color.black.opacity(0.32)))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct SourceIntelligenceFullOverlay: View {
    let item: MediaItem
    let focus: DetailPage.DetailNode
    let visibleLinks: [StreamLink]
    let linkWindowStart: Int
    let totalLinkCount: Int
    let isScanning: Bool

    private var selectedAbsoluteIndex: Int? {
        if case .stream(let index) = focus { return index }
        return visibleLinks.isEmpty ? nil : linkWindowStart
    }

    private var selectedLink: StreamLink? {
        guard let index = selectedAbsoluteIndex else { return visibleLinks.first }
        let local = index - linkWindowStart
        guard visibleLinks.indices.contains(local) else { return visibleLinks.first }
        return visibleLinks[local]
    }

    private var rangeText: String {
        guard totalLinkCount > 0 else { return "No sources yet" }
        let first = min(linkWindowStart + 1, totalLinkCount)
        let last = min(linkWindowStart + visibleLinks.count, totalLinkCount)
        return "\(first)-\(last) of \(totalLinkCount)"
    }

    var body: some View {
        HStack(alignment: .top, spacing: 22) {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 12) {
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.system(size: 28, weight: .black))
                        .foregroundStyle(Color.cyan)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Source Intelligence")
                            .font(.system(size: 31, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.96))
                        Text(isScanning ? "Scanning all addons…" : "Choose a source with full details before playback")
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.58))
                    }
                    Spacer(minLength: 0)
                    Text(rangeText)
                        .font(.system(size: 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.54))
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Capsule().fill(Color.white.opacity(0.08)))
                }

                if visibleLinks.isEmpty {
                    VStack(spacing: 12) {
                        ProgressView()
                            .scaleEffect(1.2)
                        Text(isScanning ? "Finding playable links…" : "No links found yet")
                            .font(.system(size: 24, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.88))
                        Text("Trailer playback is separate. This panel only shows movie/show sources from installed addons.")
                            .font(.system(size: 15, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.52))
                    }
                    .frame(width: 970, height: 430)
                    .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(Color.black.opacity(0.28)))
                } else {
                    VStack(spacing: 10) {
                        ForEach(Array(visibleLinks.enumerated()), id: \.element.id) { offset, link in
                            let absolute = linkWindowStart + offset
                            SourceIntelligenceRowCard(link: link, index: absolute + 1, selected: focus == .stream(absolute))
                        }

                        HStack(spacing: 10) {
                            Image(systemName: "arrow.left.arrow.right.circle.fill")
                                .font(.system(size: 16, weight: .black))
                                .foregroundStyle(Color.cyan.opacity(0.86))
                            Text("Press LEFT for previous page • Press RIGHT for next page")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .foregroundStyle(.white.opacity(0.66))
                            Spacer(minLength: 0)
                            Text("UP/DOWN only moves through these visible links")
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.42))
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 10)
                        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color.black.opacity(0.26)))
                        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
                    }
                    .frame(width: 970, alignment: .topLeading)
                }
            }
            .frame(width: 1008, alignment: .topLeading)

            SourceIntelligenceDetailPanel(item: item, link: selectedLink, totalLinkCount: totalLinkCount)
                .frame(width: 430, height: 596, alignment: .topLeading)
        }
        .padding(.horizontal, 34)
        .padding(.vertical, 28)
        .frame(width: 1518, height: 660, alignment: .topLeading)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .fill(LinearGradient(colors: [Color.black.opacity(0.91), Color.black.opacity(0.72), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing))
                if let backdrop = item.landscapeURL, !backdrop.isEmpty {
                    RemoteImageFit(url: backdrop, mode: .fill)
                        .opacity(0.16)
                        .blur(radius: 1.0)
                        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                }
            }
        )
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(LinearGradient(colors: [Color.cyan.opacity(0.34), Color.white.opacity(0.10), Color.orange.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.35))
        .shadow(color: .black.opacity(0.78), radius: 48, y: 24)
    }
}

struct SourceIntelligenceRowCard: View {
    let link: StreamLink
    let index: Int
    let selected: Bool

    private var accent: Color {
        if link.sourceWarning != nil { return .orange }
        if link.detectedLanguage == "English" { return .green }
        if link.isDirectPlayable { return .cyan }
        return .white
    }

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Text("\(index)")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
                .frame(width: 34, height: 34)
                .background(Circle().fill(accent.opacity(selected ? 0.24 : 0.10)))

            VStack(alignment: .leading, spacing: 8) {
                Text(link.title)
                    .font(.system(size: 19, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.95))
                    .lineLimit(2)
                    .minimumScaleFactor(0.74)

                HStack(spacing: 8) {
                    SourceMiniPill(title: link.detectedResolution, tint: .orange)
                    SourceMiniPill(title: link.detectedLanguage ?? "Language Unknown", tint: link.detectedLanguage == "English" ? .green : .orange)
                    if let audio = link.detectedAudio { SourceMiniPill(title: audio, tint: .cyan) }
                    if let hdr = link.detectedHDR { SourceMiniPill(title: hdr, tint: .purple) }
                    if let codec = link.detectedCodec { SourceMiniPill(title: codec, tint: .blue) }
                    if !link.size.isEmpty { SourceMiniPill(title: link.size, tint: .white) }
                }
                .lineLimit(1)

                HStack(spacing: 8) {
                    SourceMiniPill(title: link.providerDisplay, tint: .blue)
                    SourceMiniPill(title: link.isDirectPlayable ? "Direct Play" : "Resolve Needed", tint: link.isDirectPlayable ? .green : .orange)
                    SourceMiniPill(title: link.subtitleLabel, tint: .purple)
                    if let warning = link.sourceWarning { SourceMiniPill(title: warning, tint: .orange) }
                }
            }
            Spacer(minLength: 0)
            Image(systemName: selected ? "play.circle.fill" : "chevron.right.circle")
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(accent.opacity(selected ? 0.98 : 0.35))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 13)
        .frame(width: 970, height: 92, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(selected ? accent.opacity(0.18) : Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(selected ? accent.opacity(0.78) : Color.white.opacity(0.10), lineWidth: selected ? 1.8 : 1.0))
        .shadow(color: selected ? accent.opacity(0.24) : .clear, radius: 18, y: 8)
    }
}

struct SourceIntelligenceDetailPanel: View {
    let item: MediaItem
    let link: StreamLink?
    let totalLinkCount: Int

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                if let poster = item.posterURL, !poster.isEmpty {
                    RemoteImageFit(url: poster, mode: .fill)
                        .frame(width: 90, height: 132)
                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                VStack(alignment: .leading, spacing: 5) {
                    Text(item.title)
                        .font(.system(size: 25, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.96))
                        .lineLimit(2)
                    Text("\(totalLinkCount) source\(totalLinkCount == 1 ? "" : "s") found")
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.55))
                }
            }

            Divider().overlay(Color.white.opacity(0.14))

            if let link {
                SourceDetailLine(label: "Quality", value: link.detectedResolution, tint: .orange)
                SourceDetailLine(label: "Language", value: link.detectedLanguage ?? "Unknown", tint: link.detectedLanguage == "English" ? .green : .orange)
                SourceDetailLine(label: "Audio", value: link.detectedAudio ?? "Unknown", tint: .cyan)
                SourceDetailLine(label: "Subtitles", value: link.subtitleLabel, tint: .purple)
                SourceDetailLine(label: "Codec", value: link.detectedCodec ?? "Unknown", tint: .blue)
                SourceDetailLine(label: "HDR", value: link.detectedHDR ?? "Unknown", tint: .purple)
                SourceDetailLine(label: "Size", value: link.size.isEmpty ? "Unknown" : link.size, tint: .white)
                SourceDetailLine(label: "Provider", value: link.providerDisplay, tint: .blue)
                SourceDetailLine(label: "Safety", value: link.sourceWarning ?? link.matchLabel, tint: link.sourceWarning == nil ? .green : .orange)

                Text("Press SELECT to play. UP/DOWN stays on visible links. LEFT/RIGHT changes pages. MENU/BACK closes Source Intelligence.")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.48))
                    .padding(.top, 8)
            } else {
                Text("No selected source yet. Press Find Links and wait for addon results.")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
            }
            Spacer(minLength: 0)
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 26, style: .continuous).fill(Color.black.opacity(0.35)))
        .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }
}

struct SourceMiniPill: View {
    let title: String
    let tint: Color
    var body: some View {
        Text(title.isEmpty ? "Unknown" : title)
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white.opacity(0.86))
            .lineLimit(1)
            .padding(.horizontal, 8)
            .padding(.vertical, 5)
            .background(Capsule().fill(tint.opacity(0.16)))
            .overlay(Capsule().stroke(tint.opacity(0.25), lineWidth: 1))
    }
}

struct SourceDetailLine: View {
    let label: String
    let value: String
    let tint: Color
    var body: some View {
        HStack(spacing: 10) {
            Text(label.uppercased())
                .font(.system(size: 10, weight: .black, design: .rounded))
                .kerning(0.7)
                .foregroundStyle(tint.opacity(0.70))
                .frame(width: 82, alignment: .leading)
            Text(value.isEmpty ? "Unknown" : value)
                .font(.system(size: 15, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .lineLimit(1)
                .minimumScaleFactor(0.72)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 11)
        .padding(.vertical, 8)
        .background(RoundedRectangle(cornerRadius: 13, style: .continuous).fill(Color.white.opacity(0.055)))
    }
}

struct ManualStreamLinksRow: View {
    let focus: DetailPage.DetailNode
    let visibleLinks: [StreamLink]
    let linkWindowStart: Int
    let totalLinkCount: Int

    var rangeText: String? {
        guard totalLinkCount > 0 else { return nil }
        let first = min(linkWindowStart + 1, totalLinkCount)
        let last = min(linkWindowStart + visibleLinks.count, totalLinkCount)
        return "\(first)-\(last) of \(totalLinkCount)"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: "list.bullet.rectangle.portrait.fill")
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(Color.cyan.opacity(0.92))
                Text(totalLinkCount > 0 ? "SOURCE INTELLIGENCE" : "SOURCE INTELLIGENCE • PRESS FIND LINKS")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .kerning(1.0)
                    .foregroundStyle(.white.opacity(0.64))
                if let rangeText {
                    Text(rangeText)
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.42))
                }
            }
            HStack(spacing: 12) {
                if linkWindowStart > 0 {
                    Text("‹")
                        .font(.system(size: 42, weight: .black))
                        .foregroundStyle(.white.opacity(0.85))
                        .frame(width: 22)
                }

                ForEach(Array(visibleLinks.enumerated()), id: \.element.id) { offset, link in
                    let absoluteIndex = linkWindowStart + offset
                    ManualLinkChip(title: link.vodLinkPrimaryLine, subtitle: link.vodLinkDetailLine, selected: focus == .stream(absoluteIndex), playable: link.isDirectPlayable, link: link)
                }

                if linkWindowStart + visibleLinks.count < totalLinkCount {
                    Text("›")
                        .font(.system(size: 42, weight: .black))
                        .foregroundStyle(.white.opacity(0.85))
                        .frame(width: 22)
                }
            }
        }
        .frame(width: 1038, alignment: .leading)
        .clipped()
    }
}

struct ManualLinkChip: View {
    let title: String
    let subtitle: String?
    let selected: Bool
    let playable: Bool
    let link: StreamLink?

    private var isCompactSearchLinks: Bool { title == "__search_links_compact__" }

    private var iconName: String? {
        title.lowercased().contains("search") ? "magnifyingglass" : nil
    }

    private var warning: String? { link?.sourceWarning }
    private var accent: Color {
        if warning != nil { return .orange }
        if link?.detectedLanguage == "English" { return .green }
        if playable { return .cyan }
        return .white
    }

    var body: some View {
        VStack(alignment: isCompactSearchLinks ? .center : .leading, spacing: 6) {
            HStack(spacing: isCompactSearchLinks ? 7 : 8) {
                if isCompactSearchLinks {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 18, weight: .black))
                    Image(systemName: "link")
                        .font(.system(size: 18, weight: .black))
                } else {
                    if let iconName { Image(systemName: iconName).font(.system(size: 16, weight: .black)) }
                    Text(title).font(.system(size: 16, weight: .black, design: .rounded)).lineLimit(2)
                }
            }
            if let link, !isCompactSearchLinks {
                HStack(spacing: 5) {
                    LinkInfoMiniPill(text: link.detectedResolution, tint: .cyan)
                    if let hdr = link.detectedHDR { LinkInfoMiniPill(text: hdr, tint: .purple) }
                    if let lang = link.detectedLanguage { LinkInfoMiniPill(text: lang, tint: lang == "English" ? .green : .orange) }
                }
                HStack(spacing: 5) {
                    if let audio = link.detectedAudio { LinkInfoMiniPill(text: audio, tint: .blue) }
                    if let codec = link.detectedCodec { LinkInfoMiniPill(text: codec, tint: .white) }
                    LinkInfoMiniPill(text: playable ? "Direct" : "Resolve", tint: playable ? .green : .orange)
                }
                Text(warning ?? subtitle ?? link.providerDisplay)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle((warning == nil ? Color.white : Color.orange).opacity(warning == nil ? 0.70 : 0.95))
                    .lineLimit(1)
            } else if let subtitle {
                Text(subtitle)
                    .font(.system(size: isCompactSearchLinks ? 11 : 11, weight: .bold))
                    .opacity(0.84)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .accessibilityLabel(isCompactSearchLinks ? "Find Sources" : title)
        .foregroundStyle(.white)
        .padding(.horizontal, isCompactSearchLinks ? 14 : 13)
        .padding(.vertical, isCompactSearchLinks ? 12 : 10)
        .frame(minWidth: isCompactSearchLinks ? 74 : 236, maxWidth: isCompactSearchLinks ? 86 : 250, minHeight: isCompactSearchLinks ? 44 : 116, alignment: isCompactSearchLinks ? .center : .leading)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(selected ? accent.opacity(0.34) : Color.black.opacity(playable ? 0.34 : 0.22))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(selected ? accent.opacity(0.95) : accent.opacity(playable ? 0.24 : 0.12), lineWidth: selected ? 3 : 1)
        )
        .shadow(color: selected ? accent.opacity(0.28) : .black.opacity(0.18), radius: selected ? 18 : 8, y: selected ? 8 : 3)
        .scaleEffect(selected ? 1.045 : 1.0)
    }
}

struct LinkInfoMiniPill: View {
    let text: String
    let tint: Color
    var body: some View {
        Text(text)
            .font(.system(size: 9, weight: .black, design: .rounded))
            .lineLimit(1)
            .foregroundStyle(.white.opacity(0.94))
            .padding(.horizontal, 6)
            .padding(.vertical, 3)
            .background(Capsule().fill(tint.opacity(0.22)))
            .overlay(Capsule().stroke(tint.opacity(0.32), lineWidth: 0.8))
    }
}

struct PopupHeaderDetails: Hashable {
    var budget: Int? = nil
    var revenue: Int? = nil
    var runtimeMinutes: Int? = nil
    var studio: String? = nil
    var seasons: Int? = nil
    var episodes: Int? = nil
    var status: String? = nil
    var network: String? = nil
}


struct PopupFontPreset: Identifiable, Hashable {
    let id: String
    let title: String
    let category: String
}

struct PopupTypography {
    static let presets: [PopupFontPreset] = [
        PopupFontPreset(id: "System Default", title: "System Default", category: "Core"),
        PopupFontPreset(id: "SF Pro", title: "SF Pro", category: "Core"),
        PopupFontPreset(id: "SF Rounded", title: "SF Rounded", category: "Core"),
        PopupFontPreset(id: "SF Serif", title: "SF Serif", category: "Core"),
        PopupFontPreset(id: "SF Mono", title: "SF Mono", category: "Core"),
        PopupFontPreset(id: "Avenir Next", title: "Avenir Next", category: "Modern"),
        PopupFontPreset(id: "Avenir", title: "Avenir", category: "Modern"),
        PopupFontPreset(id: "Helvetica Neue", title: "Helvetica Neue", category: "Modern"),
        PopupFontPreset(id: "Futura", title: "Futura", category: "Modern"),
        PopupFontPreset(id: "Gill Sans", title: "Gill Sans", category: "Modern"),
        PopupFontPreset(id: "Optima", title: "Optima", category: "Premium"),
        PopupFontPreset(id: "Palatino", title: "Palatino", category: "Premium"),
        PopupFontPreset(id: "Georgia", title: "Georgia", category: "Premium"),
        PopupFontPreset(id: "Baskerville", title: "Baskerville", category: "Premium"),
        PopupFontPreset(id: "Didot", title: "Didot", category: "Premium"),
        PopupFontPreset(id: "Cinematic", title: "Cinematic", category: "Cinema"),
        PopupFontPreset(id: "Noir", title: "Noir", category: "Cinema"),
        PopupFontPreset(id: "Blockbuster", title: "Blockbuster", category: "Cinema"),
        PopupFontPreset(id: "Prestige", title: "Prestige", category: "Cinema"),
        PopupFontPreset(id: "Trailer Title", title: "Trailer Title", category: "Cinema"),
        PopupFontPreset(id: "Classic TV", title: "Classic TV", category: "TV"),
        PopupFontPreset(id: "Broadcast", title: "Broadcast", category: "TV"),
        PopupFontPreset(id: "Editorial", title: "Editorial", category: "Readability"),
        PopupFontPreset(id: "Magazine", title: "Magazine", category: "Readability"),
        PopupFontPreset(id: "Large Readability", title: "Large Readability", category: "Readability"),
        PopupFontPreset(id: "High Contrast", title: "High Contrast", category: "Readability"),
        PopupFontPreset(id: "Soft Rounded", title: "Soft Rounded", category: "Readability"),
        PopupFontPreset(id: "Compact UI", title: "Compact UI", category: "Minimal"),
        PopupFontPreset(id: "Thin Modern", title: "Thin Modern", category: "Minimal"),
        PopupFontPreset(id: "Minimal Sans", title: "Minimal Sans", category: "Minimal"),
        PopupFontPreset(id: "Studio", title: "Studio", category: "Minimal"),
        PopupFontPreset(id: "Cyber", title: "Cyber", category: "Sci-Fi"),
        PopupFontPreset(id: "Neo Tech", title: "Neo Tech", category: "Sci-Fi"),
        PopupFontPreset(id: "Space Station", title: "Space Station", category: "Sci-Fi"),
        PopupFontPreset(id: "Digital HUD", title: "Digital HUD", category: "Sci-Fi"),
        PopupFontPreset(id: "Synthwave", title: "Synthwave", category: "Sci-Fi"),
        PopupFontPreset(id: "VHS", title: "VHS", category: "Retro"),
        PopupFontPreset(id: "Retro Cinema", title: "Retro Cinema", category: "Retro"),
        PopupFontPreset(id: "Film Archive", title: "Film Archive", category: "Retro"),
        PopupFontPreset(id: "Courier", title: "Courier", category: "Retro")
    ]

    static func font(_ preset: String, size: CGFloat, weight: Font.Weight) -> Font {
        switch preset {
        case "SF Rounded", "Soft Rounded", "Classic TV": return .system(size: size, weight: weight, design: .rounded)
        case "SF Serif", "Editorial", "Magazine": return .system(size: size, weight: weight, design: .serif)
        case "SF Mono", "Digital HUD", "Courier": return .system(size: size, weight: weight, design: .monospaced)
        case "Avenir Next": return .custom("Avenir Next", size: size).weight(weight)
        case "Avenir": return .custom("Avenir", size: size).weight(weight)
        case "Helvetica Neue", "Minimal Sans", "Studio": return .custom("Helvetica Neue", size: size).weight(weight)
        case "Futura", "Blockbuster", "Trailer Title": return .custom("Futura", size: size).weight(weight)
        case "Gill Sans", "Broadcast": return .custom("Gill Sans", size: size).weight(weight)
        case "Optima", "Prestige": return .custom("Optima", size: size).weight(weight)
        case "Palatino", "Film Archive": return .custom("Palatino", size: size).weight(weight)
        case "Georgia": return .custom("Georgia", size: size).weight(weight)
        case "Baskerville", "Noir": return .custom("Baskerville", size: size).weight(weight)
        case "Didot", "Cinematic": return .custom("Didot", size: size).weight(weight)
        case "Large Readability", "High Contrast": return .system(size: size + 1.5, weight: .bold, design: .rounded)
        case "Compact UI": return .system(size: max(10, size - 1.0), weight: weight, design: .default)
        case "Thin Modern": return .system(size: size, weight: .medium, design: .default)
        case "Cyber", "Neo Tech", "Space Station", "Synthwave", "VHS", "Retro Cinema": return .system(size: size, weight: weight, design: .rounded)
        default: return .system(size: size, weight: weight, design: .default)
        }
    }

    static func kerning(_ preset: String) -> CGFloat {
        switch preset {
        case "Cinematic", "Trailer Title", "Blockbuster", "Noir", "Prestige": return 1.05
        case "Digital HUD", "Cyber", "Neo Tech", "Space Station": return 0.85
        case "Compact UI": return 0.25
        default: return 0.55
        }
    }

    static func descriptionLineSpacing(_ preset: String) -> CGFloat {
        switch preset {
        case "Large Readability", "High Contrast", "Editorial", "Magazine": return 7
        case "Compact UI": return 4
        default: return 5
        }
    }
}

// v481: Larger second-style cinematic details header. The hidden top menu space becomes
// a true hero banner: clearer backdrop, large artwork logo, and an integrated metadata row.
struct PopupExtendedMetadataHeader: View {
    let item: MediaItem
    let details: PopupHeaderDetails?

    private var isShow: Bool {
        let lower = item.type.lowercased()
        return lower.contains("show") || lower.contains("series") || lower.contains("tv")
    }

    private var sourceLabel: String {
        if let value = details?.studio?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty { return value }
        if let value = details?.network?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty { return value }
        if let value = item.addonName?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty { return value }
        return item.catalog.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var firstGenre: String { item.genres.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "" }

    private var ratingValue: String {
        let trimmed = item.rating.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty || trimmed == "—" || trimmed == "0" || trimmed == "0.0" { return "" }
        return trimmed
    }

    private func moneyLabel(_ value: Int?) -> String {
        guard let value, value > 0 else { return "" }
        let amount = Double(value)
        if amount >= 1_000_000_000 { return String(format: "$%.1fB", amount / 1_000_000_000) }
        if amount >= 1_000_000 { return String(format: "$%.0fM", amount / 1_000_000) }
        return "$\(value)"
    }

    private func runtimeLabel(_ minutes: Int?) -> String {
        guard let minutes, minutes > 0 else { return "" }
        if minutes >= 60 { return "\(minutes / 60)h \(minutes % 60)m" }
        return "\(minutes)m"
    }

    private var metricPairs: [(String, String)] {
        let base: [(String, String)]
        if isShow {
            base = [
                ("SEASONS", details?.seasons.map(String.init) ?? ""),
                ("EPISODES", details?.episodes.map(String.init) ?? ""),
                ("STATUS", details?.status ?? ""),
                ("NETWORK", sourceLabel),
                ("RATING", ratingValue),
                ("GENRE", firstGenre)
            ]
        } else {
            base = [
                ("BUDGET", moneyLabel(details?.budget)),
                ("REVENUE", moneyLabel(details?.revenue)),
                ("RUNTIME", runtimeLabel(details?.runtimeMinutes)),
                ("RELEASE", item.year),
                ("STUDIO", sourceLabel),
                ("RATING", ratingValue),
                ("GENRE", firstGenre)
            ]
        }
        return base.filter { !$0.1.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                Color.black.opacity(0.36)
                LinearGradient(
                    colors: [Color.black.opacity(0.86), Color.black.opacity(0.62), Color.black.opacity(0.36), Color.black.opacity(0.22)],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                LinearGradient(
                    colors: [Color.black.opacity(0.20), Color.clear, Color.black.opacity(0.42)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
            .frame(width: 1920, height: 148)

            HStack(alignment: .center, spacing: 22) {
                // v570: the popup itself owns the clearlogo now, so the top
                // information bar uses a compact high-quality portrait poster
                // instead of duplicating the same logo twice. Keep this stable
                // while browsing episodes so the header does not flicker.
                HeaderPosterArtwork(item: item)
                    .frame(width: 104, height: 124, alignment: .center)

                HStack(spacing: 10) {
                    ForEach(Array(metricPairs.prefix(isShow ? 5 : 6).enumerated()), id: \.offset) { _, pair in
                        HeaderMetricChip(title: pair.0, value: pair.1)
                    }
                }
                .layoutPriority(1)

                Spacer(minLength: 18)

                ViewerAdvisoryBadge(rating: ratingValue, genres: item.genres, isShow: isShow)
            }
            .padding(.leading, 116)
            .padding(.trailing, 72)
            .padding(.bottom, 24)
            .frame(width: 1920, alignment: .leading)

            Rectangle()
                .fill(LinearGradient(colors: [Color.clear, Color.orange.opacity(0.18), Color.white.opacity(0.10), Color.clear], startPoint: .leading, endPoint: .trailing))
                .frame(height: 1)
        }
        .background(Color.black.opacity(0.18))
        .accessibilityHidden(true)
    }

}


struct HeaderPosterArtwork: View {
    let item: MediaItem

    private var posterURL: String? {
        let preferred = item.posterURL?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !preferred.isEmpty { return preferred }
        let fallback = item.landscapeURL?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return fallback.isEmpty ? nil : fallback
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(LinearGradient(colors: [Color.white.opacity(0.10), Color.black.opacity(0.56)], startPoint: .topLeading, endPoint: .bottomTrailing))

            if let url = posterURL {
                RemoteImageFit(url: url, mode: item.posterURL == nil ? .fill : .fit)
                    .padding(item.posterURL == nil ? 0 : 2)
                    .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
            } else {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 34, weight: .black))
                    .foregroundStyle(.white.opacity(0.44))
            }

            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(LinearGradient(colors: [Color.white.opacity(0.34), Color.white.opacity(0.10), Color.orange.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.1)

            if let resume = PlaybackResumeCacheManager.shared.resumeEntry(for: item) {
                HeaderPosterResumeOverlay(entry: resume)
                    .padding(6)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
            }
        }
        .shadow(color: .black.opacity(0.72), radius: 18, y: 8)
        .shadow(color: .orange.opacity(0.12), radius: 14, y: 2)
        .accessibilityLabel("Poster artwork")
    }
}


struct HeaderPosterResumeOverlay: View {
    let entry: PlaybackResumeEntry

    private var progress: Double {
        guard entry.duration > 0 else { return 0 }
        return min(0.98, max(0.02, entry.seconds / entry.duration))
    }

    private var remainingText: String {
        guard entry.duration > entry.seconds else { return "Continue" }
        let remaining = max(0, entry.duration - entry.seconds)
        if remaining >= 3600 {
            return "\(Int(remaining / 3600))h \(Int((remaining.truncatingRemainder(dividingBy: 3600)) / 60))m left"
        }
        return "\(max(1, Int(remaining / 60)))m left"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(remainingText.uppercased())
                .font(.system(size: 8, weight: .black, design: .rounded))
                .kerning(0.45)
                .foregroundStyle(.white.opacity(0.96))
                .lineLimit(1)
                .minimumScaleFactor(0.72)
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.22))
                    Capsule().fill(LinearGradient(colors: [Color.orange.opacity(0.96), Color.yellow.opacity(0.92)], startPoint: .leading, endPoint: .trailing))
                        .frame(width: max(5, geo.size.width * progress))
                }
            }
            .frame(height: 4)
        }
        .padding(.horizontal, 7)
        .padding(.vertical, 6)
        .background(RoundedRectangle(cornerRadius: 10, style: .continuous).fill(Color.black.opacity(0.68)))
        .shadow(color: Color.orange.opacity(0.20), radius: 8, y: 2)
    }
}

struct ViewerAdvisoryBadge: View {
    let rating: String
    let genres: [String]
    let isShow: Bool
    @State private var expanded: Bool = true
    @State private var infoPage: Int = 0
    @FocusState private var advisoryFocused: Bool

    private var advisoryItems: [String] {
        var items: [String] = []
        let lowerGenres = genres.map { $0.lowercased() }.joined(separator: " ")
        let upperRating = rating.uppercased()
        if upperRating.contains("R") || upperRating.contains("TV-MA") || upperRating.contains("NC") { items.append("Mature Themes") }
        if upperRating.contains("PG-13") || upperRating.contains("TV-14") { items.append("Parental Guidance") }
        if lowerGenres.contains("horror") || lowerGenres.contains("thriller") || lowerGenres.contains("war") || lowerGenres.contains("action") { items.append("Violence") }
        if lowerGenres.contains("crime") || lowerGenres.contains("mystery") { items.append("Intense Scenes") }
        if lowerGenres.contains("romance") || lowerGenres.contains("drama") { items.append("Adult Situations") }
        if items.isEmpty, !upperRating.isEmpty { items.append(upperRating) }
        if items.isEmpty { items.append(isShow ? "Show Advisory" : "Viewer Advisory") }
        return Array(items.prefix(3))
    }

    private var compactText: String { advisoryItems.joined(separator: " • ") }

    private var numericScore: Int {
        let cleaned = rating.replacingOccurrences(of: ",", with: ".")
        let value = Double(cleaned.filter { "0123456789.".contains($0) }) ?? 0
        if value > 0 && value <= 10 { return Int((value * 10).rounded()) }
        if value > 10 && value <= 100 { return Int(value.rounded()) }
        return 0
    }

    private var rotatingCompactText: String {
        var cards: [String] = [compactText]
        if numericScore > 0 {
            cards.append("🍅 \(numericScore)%")
            cards.append("👥 \(min(99, numericScore + 3))%")
        }
        cards.append(isShow ? "TV Advisory" : "Movie Advisory")
        return cards[infoPage % cards.count]
    }

    var body: some View {
        // v503: This is intentionally not a Button/focusable control. tvOS was drawing
        // a large white focus/platter card around it after popup link searches. Keeping it
        // as a passive advisory badge preserves the premium look and prevents the white box.
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: expanded ? 22 : 18, weight: .black))
                .foregroundStyle(Color.orange.opacity(0.98))
            VStack(alignment: .leading, spacing: 4) {
                Text(expanded ? "VIEWER ADVISORY" : rotatingCompactText)
                    .font(.system(size: expanded ? 10 : 12, weight: .black, design: .rounded))
                    .tracking(expanded ? 1.2 : 0.1)
                    .foregroundStyle(expanded ? Color.yellow.opacity(0.98) : Color.yellow.opacity(0.95))
                    .lineLimit(1)
                if expanded {
                    Text(compactText)
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .foregroundStyle(Color.orange.opacity(0.98))
                        .lineLimit(1)
                }
            }
        }
        .padding(.horizontal, expanded ? 16 : 14)
        .frame(width: expanded ? 286 : 236, height: 54, alignment: .leading)
        .background(
            LinearGradient(colors: [Color.black.opacity(0.78), Color.black.opacity(0.52), Color.orange.opacity(0.26)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 17, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(Color.orange.opacity(expanded ? 0.58 : 0.38), lineWidth: 1.5))
        .shadow(color: Color.orange.opacity(expanded ? 0.30 : 0.12), radius: expanded ? 16 : 5)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
        .onAppear { collapseLater() }
        .onReceive(Timer.publish(every: 6.2, on: .main, in: .common).autoconnect()) { _ in
            guard !expanded else { return }
            let count = numericScore > 0 ? 4 : 2
            withAnimation(.easeInOut(duration: 0.25)) { infoPage = (infoPage + 1) % count }
        }
    }

    private func collapseLater() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 7.0) {
            withAnimation(.easeInOut(duration: 0.28)) { expanded = false }
        }
    }
}

struct HeaderMetricChip: View {
    let title: String
    let value: String
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"

    private var iconName: String {
        switch title.lowercased() {
        case "budget": return "dollarsign.circle"
        case "revenue": return "chart.line.uptrend.xyaxis"
        case "runtime": return "clock"
        case "release", "first air": return "calendar"
        case "studio", "network": return "building.2"
        case "rating": return "star.fill"
        case "genre", "type": return "tag"
        default: return "info.circle"
        }
    }

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: iconName)
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(Color.white.opacity(0.88))
                .frame(width: 26)
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(PopupTypography.font(popupFontPreset, size: 9, weight: .black))
                    .foregroundStyle(Color.orange.opacity(0.95))
                    .lineLimit(1)
                Text(value)
                    .font(PopupTypography.font(popupFontPreset, size: 17, weight: .heavy))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(1)
                    .minimumScaleFactor(0.58)
            }
        }
        .padding(.horizontal, 12)
        .frame(width: 142, height: 52, alignment: .leading)
        .background(Color.black.opacity(0.36), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.09), lineWidth: 1))
    }
}


struct CastFaceCreditsRow: View {
    let item: MediaItem

    private var displayMembers: [CastMember] {
        if !item.castMembers.isEmpty { return Array(item.castMembers.prefix(6)) }
        return Array(item.cast.prefix(6)).map { CastMember(name: $0, role: nil, imageURL: nil) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if !displayMembers.isEmpty {
                HStack(spacing: 18) {
                    ForEach(displayMembers) { member in
                        CastFaceCard(member: member, premium: true)
                    }
                }
            } else {
                CastCreditsSummary(item: item)
            }
        }
    }
}

struct CastFaceCard: View {
    let member: CastMember
    var premium: Bool = false
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"

    private var initials: String {
        let parts = member.name.split(separator: " ")
        let letters = parts.prefix(2).compactMap { $0.first }.map(String.init).joined()
        return letters.isEmpty ? "?" : letters.uppercased()
    }

    var body: some View {
        VStack(spacing: 5) {
            ZStack {
                if let imageURL = member.imageURL, !imageURL.isEmpty {
                    RemoteImageFit(url: imageURL, mode: .fill)
                } else {
                    Circle()
                        .fill(LinearGradient(colors: [Color.white.opacity(0.22), Color.orange.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Text(initials)
                        .font(.system(size: 19, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.88))
                }
            }
            .frame(width: premium ? 78 : 64, height: premium ? 78 : 64)
            .clipShape(Circle())
            .overlay(Circle().stroke(Color.white.opacity(premium ? 0.24 : 0.18), lineWidth: premium ? 1.4 : 1))
            .shadow(color: .black.opacity(0.35), radius: premium ? 12 : 8, y: 4)
            .shadow(color: Color.orange.opacity(premium ? 0.14 : 0.0), radius: premium ? 16 : 0)

            Text(member.name)
                .font(PopupTypography.font(popupFontPreset, size: premium ? 13 : 12, weight: .black))
                .foregroundStyle(.white.opacity(0.96))
                .lineLimit(1)
                .minimumScaleFactor(0.72)
                .frame(width: premium ? 116 : 86)

            if let role = member.role, !role.isEmpty {
                Text(role)
                    .font(PopupTypography.font(popupFontPreset, size: premium ? 10 : 10, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.64))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
                    .frame(width: premium ? 116 : 86)
            }
        }
        .frame(width: premium ? 118 : 88)
    }
}

struct CastCreditsSummary: View {
    let item: MediaItem
    var compact: Bool = true
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"

    private var castLine: String {
        let names = item.cast.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        return names.prefix(compact ? 5 : 8).joined(separator: ", ")
    }

    private var directorLine: String {
        let names = item.directors.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        return names.prefix(compact ? 2 : 3).joined(separator: ", ")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: compact ? 5 : 8) {
            if !castLine.isEmpty {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("Cast")
                        .font(PopupTypography.font(popupFontPreset, size: compact ? 16 : 15, weight: .black))
                        .foregroundStyle(Color.orange.opacity(0.96))
                    Text(castLine)
                        .font(PopupTypography.font(popupFontPreset, size: compact ? 17 : 14, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.86))
                        .lineLimit(compact ? 1 : 3)
                }
            }
            if !directorLine.isEmpty {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text("Director")
                        .font(PopupTypography.font(popupFontPreset, size: compact ? 15 : 14, weight: .black))
                        .foregroundStyle(Color.orange.opacity(0.82))
                    Text(directorLine)
                        .font(PopupTypography.font(popupFontPreset, size: compact ? 16 : 14, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.74))
                        .lineLimit(compact ? 1 : 2)
                }
            }
            if castLine.isEmpty && directorLine.isEmpty {
                Text("Cast information loads when the selected catalog provides credits metadata.")
                    .font(PopupTypography.font(popupFontPreset, size: compact ? 15 : 13, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.56))
                    .lineLimit(2)
            }
        }
    }
}

struct ManualRelatedRow: View {
    let focus: DetailPage.DetailNode
    let relatedItems: [MediaItem]
    var baseIndex: Int = 0
    var compact: Bool = false
    var body: some View {
        HStack(spacing: compact ? 12 : 24) {
            ForEach(Array(relatedItems.enumerated()), id: \.element.id) { index, item in
                let absoluteIndex = baseIndex + index
                let selected = focus == .related(absoluteIndex)
                ZStack(alignment: .bottomLeading) {
                    RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                }
                .frame(width: compact ? 96 : 210, height: compact ? 136 : 310)
                .clipShape(RoundedRectangle(cornerRadius: compact ? 16 : 20, style: .continuous))
                .contentShape(RoundedRectangle(cornerRadius: compact ? 16 : 20, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: compact ? 16 : 20, style: .continuous)
                        .stroke(selected ? Color(red: 0.16, green: 0.58, blue: 1.0).opacity(0.98) : Color.white.opacity(0.06), lineWidth: selected ? 3.0 : 1.0)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: compact ? 18 : 24, style: .continuous)
                        .stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(selected ? 0.40 : 0.0), lineWidth: selected ? 7.0 : 0.0)
                        .blur(radius: selected ? 6 : 0)
                )
                .scaleEffect(selected ? 1.055 : 1.0)
                .shadow(color: Color(red: 0.16, green: 0.58, blue: 1.0).opacity(selected ? 0.34 : 0.0), radius: selected ? 20 : 0, y: selected ? 6 : 0)
                .modifier(SafeCardScrollMotion(isFocused: selected, intensity: 0.65))
            }
            Color.clear.frame(width: compact ? 70 : 44, height: 1)
        }
        .clipped()
    }
}

struct RelatedMoviesRow: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    @FocusState private var focusedID: String?

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != current.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(current.genres))) }
        let fallback = all.filter { $0.id != current.id }
        let chosen = sameGenre.isEmpty ? fallback : sameGenre
        return Array(chosen.prefix(8))
    }

    var body: some View {
        HStack(spacing: 24) {
            ForEach(relatedItems) { item in
                Button {
                    store.openDetail(item, pushCurrent: true)
                } label: {
                    ZStack(alignment: .bottomLeading) {
                        RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                    }
                    .frame(width: 180, height: 266)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .contentShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.06), lineWidth: 1))
                    .modifier(SafeCardScrollMotion(isFocused: focusedID == item.id, intensity: 0.85))
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: item.id)
            }
        }
        .focusSection()
        .onAppear { if focusedID == nil { focusedID = relatedItems.first?.id } }
    }
}

struct StreamLinksRow: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focusedID: String?

    var visibleLinks: [StreamLink] { Array(store.streamLinks.prefix(20)) }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                Button {
                    Task { _ = await store.findStreams(for: item) }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: 20, weight: .black))
                        Image(systemName: "link")
                            .font(.system(size: 20, weight: .black))
                    }
                    .accessibilityLabel("Find Sources")
                    .foregroundStyle(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(RoundedRectangle(cornerRadius: 14).fill(focusedID == "search" ? Color.orange.opacity(0.75) : Color.white.opacity(0.12)))
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedID == "search" ? Color.orange : Color.white.opacity(0.18), lineWidth: focusedID == "search" ? 3 : 1))
                    .scaleEffect(focusedID == "search" ? 1.06 : 1.0)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: "search")

                ForEach(visibleLinks) { link in
                    Button {
                        if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                            let alternates = store.playableURLs(from: store.streamLinks, selected: link)
                            store.startPlayback(item: item, url: url, alternates: alternates, subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.vodLinkPrimaryLine) • \(link.vodLinkDetailLine). Adaptive retry is armed.")
                        } else {
                            store.status = "This link is not direct-playable by AVFoundation. Magnet/infoHash playback needs the planned torrent/libVLC engine or a debrid direct URL."
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(link.quality)
                                .font(.system(size: 18, weight: .heavy))
                            Text(link.size)
                                .font(.system(size: 13, weight: .semibold))
                                .opacity(0.78)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 11)
                        .background(RoundedRectangle(cornerRadius: 13).fill(focusedID == link.id.uuidString ? Color.cyan.opacity(0.58) : Color.cyan.opacity(link.isDirectPlayable ? 0.30 : 0.10)))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(focusedID == link.id.uuidString ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == link.id.uuidString ? 3 : 1))
                        .scaleEffect(focusedID == link.id.uuidString ? 1.06 : 1.0)
                    }
                    .buttonStyle(.plain)
                    .focused($focusedID, equals: link.id.uuidString)
                }
            }
            .focusSection()
        }
        .frame(width: 1220, alignment: .leading)
        .onAppear { if focusedID == nil { focusedID = "search" } }
    }
}


struct MembershipScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("membershipActive") private var membershipActive: Bool = false
    @State private var email: String = ""
    @State private var deviceId: String = UserDefaults.standard.string(forKey: "DebridChannelsDeviceId") ?? UUID().uuidString
    @State private var membershipStatus: String = "Choose a Debrid Channels membership to support development and unlock access."
    @State private var checkoutURL: URL? = nil
    @State private var checkoutPlanName: String = ""
    @State private var isRestoring: Bool = false
    @State private var trialStatusText: String = "Checking 24-hour trial…"
    @AppStorage("showOwnerLogin") private var showOwnerLogin: Bool = false
    @State private var adminEmail: String = ""
    @State private var adminPassword: String = ""
    @State private var adminStatus: String = ""
    @State private var isAdminLoggingIn: Bool = false
    @State private var showDeviceManager: Bool = false
    @State private var devices: [MembershipDeviceRecord] = []
    @State private var deviceStatus: String = ""
    @State private var deviceName: String = UserDefaults.standard.string(forKey: "DebridChannelsDeviceName") ?? "Living Room Apple TV"
    @State private var isLoadingDevices: Bool = false

    private let membershipPanelWidth: CGFloat = 1146

    private let backendBaseURL = URL(string: UserDefaults.standard.string(forKey: "backendBaseURL") ?? "https://api.skylinejay187.it.com")!

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color.black, Color(red: 0.02, green: 0.04, blue: 0.075), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(alignment: .leading, spacing: 26) {
                Text("Debrid Channels Membership")
                    .font(.system(size: 58, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(membershipStatus)
                    .font(.system(size: 24, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .frame(width: membershipPanelWidth, alignment: .leading)
                Text(trialStatusText)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .foregroundStyle(Color(red: 0.20, green: 0.62, blue: 1.0).opacity(0.96))
                    .frame(width: membershipPanelWidth, alignment: .leading)
                HStack(spacing: 26) {
                    membershipCard(title: "Supporter", price: "$5.99 / Year", subtitle: "Supports ongoing development and unlocks one year of updates.", tier: "supporter")
                    membershipCard(title: "Lifetime Unlock", price: "$14.99 One-Time", subtitle: "Fully unlocks Debrid Channels with lifetime updates.", tier: "lifetime")
                }

                HStack(spacing: 18) {
                    TextField("Email used at checkout", text: $email)
                        .frame(width: 470)
                    Button(action: restoreMembership) {
                        Text(isRestoring ? "Checking…" : "Restore Membership")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.borderedProminent)
                    Button(action: { loadDevices(); showDeviceManager = true }) {
                        Text("Manage Devices")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.bordered)
                    Button(action: { store.selectedTab = .live }) {
                        Text("Back to Live TV")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.bordered)
                }

                Text("Scan the QR code with your phone to complete checkout. After payment, return here and choose Restore Membership.")
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.46))
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            if showDeviceManager {
                MembershipDeviceManagerPanel(email: $email, deviceName: $deviceName, devices: devices, status: deviceStatus, isLoading: isLoadingDevices, currentDeviceId: deviceId, load: loadDevices, renameCurrent: renameCurrentDevice, remove: removeDevice, replace: replaceDevice, close: { showDeviceManager = false })
                    .zIndex(30)
            }

            if showOwnerLogin {
                OwnerAdminLoginPanel(email: $adminEmail, password: $adminPassword, status: adminStatus, isLoading: isAdminLoggingIn, login: ownerAdminLogin, close: {
                    showOwnerLogin = false
                    adminPassword = ""
                    adminStatus = ""
                })
                .zIndex(25)
            }

            if let checkoutURL {
                CheckoutQRPanel(planName: checkoutPlanName, url: checkoutURL) {
                    self.checkoutURL = nil
                    self.checkoutPlanName = ""
                    membershipStatus = "Return after payment and choose Restore Membership."
                }
                .zIndex(20)
            }
        }
        .onAppear {
            UserDefaults.standard.set(deviceId, forKey: "DebridChannelsDeviceId")
            UserDefaults.standard.set(deviceName, forKey: "DebridChannelsDeviceName")
            refreshTrialStatus()
        }
    }

    private func refreshTrialStatus() {
        guard var comps = URLComponents(url: backendBaseURL.appendingPathComponent("api/membership/status"), resolvingAgainstBaseURL: false) else { return }
        comps.queryItems = [URLQueryItem(name: "deviceId", value: deviceId)]
        guard let url = comps.url else { return }
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let entitlement = json?["entitlement"] as? [String: Any]
                let tier = entitlement?["tier"] as? String ?? "TRIAL_24"
                let active = entitlement?["active"] as? Bool ?? false
                let expiresAt = entitlement?["expiresAt"] as? String
                await MainActor.run {
                    if active, tier == "TRIAL_24", let expiresAt {
                        trialStatusText = "24-hour trial active • Expires: \(expiresAt)"
                    } else if tier == "TRIAL_EXPIRED" {
                        trialStatusText = "24-hour trial ended • Choose Supporter or Lifetime to continue."
                    } else if active {
                        trialStatusText = "Membership active • \(tier)"
                    } else {
                        trialStatusText = "24-hour trial status unavailable."
                    }
                }
            } catch {
                await MainActor.run { trialStatusText = "Trial status unavailable. Check your connection." }
            }
        }
    }

    private func membershipCard(title: String, price: String, subtitle: String, tier: String) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title).font(.system(size: 34, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(price).font(.system(size: 42, weight: .black, design: .rounded)).foregroundStyle(Color(red: 0.20, green: 0.62, blue: 1.0))
            Text(subtitle).font(.system(size: 20, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.70)).lineLimit(3)
            Button { startCheckout(tier: tier) } label: {
                Text(tier == "lifetime" ? "Show Lifetime QR" : "Show Supporter QR")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .padding(.horizontal, 28).padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(30)
        .frame(width: 560, height: 350, alignment: .topLeading)
        .background(RoundedRectangle(cornerRadius: 30, style: .continuous).fill(Color.white.opacity(0.085)))
        .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(Color(red: 0.16, green: 0.58, blue: 1.0).opacity(0.55), lineWidth: 2))
        .shadow(color: Color(red: 0.16, green: 0.58, blue: 1.0).opacity(0.18), radius: 28, y: 12)
    }

    private func startCheckout(tier: String) {
        let planName = tier == "lifetime" ? "Lifetime Unlock" : "Supporter"
        guard var comps = URLComponents(url: backendBaseURL.appendingPathComponent("api/membership/checkout"), resolvingAgainstBaseURL: false) else { return }
        comps.queryItems = [
            URLQueryItem(name: "tier", value: tier),
            URLQueryItem(name: "deviceId", value: deviceId),
            URLQueryItem(name: "deviceName", value: deviceName),
            URLQueryItem(name: "format", value: "json")
        ]
        guard let url = comps.url else { return }
        checkoutPlanName = planName
        checkoutURL = nil
        membershipStatus = "Preparing secure Stripe checkout for \(planName)…"
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let ok = json?["ok"] as? Bool ?? false
                let checkoutString = (json?["checkoutUrl"] as? String) ?? (json?["url"] as? String)
                await MainActor.run {
                    if ok, let checkoutString, let stripeURL = URL(string: checkoutString), stripeURL.host?.contains("stripe.com") == true {
                        checkoutURL = stripeURL
                        membershipStatus = "Scan the QR code to open secure Stripe checkout for \(planName)."
                    } else {
                        let friendly = (json?["friendlyError"] as? String) ?? "Membership checkout is not ready yet. Please try again later."
                        membershipStatus = friendly
                    }
                }
            } catch {
                await MainActor.run {
                    membershipStatus = "Membership checkout is not ready yet. Please try again later."
                }
            }
        }
    }

    private func ownerAdminLogin() {
        let cleanEmail = adminEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanEmail.isEmpty && !adminPassword.isEmpty else {
            adminStatus = "Enter the owner email and password created on the Owner Setup page."
            return
        }
        guard let url = URL(string: backendBaseURL.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/api/owner/login") else { return }
        isAdminLoggingIn = true
        adminStatus = "Verifying owner login…"
        let payload: [String: Any] = [
            "email": cleanEmail,
            "password": adminPassword,
            "deviceId": deviceId,
            "appVersion": "v455"
        ]
        Task {
            do {
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = try JSONSerialization.data(withJSONObject: payload)
                let (data, _) = try await URLSession.shared.data(for: request)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let ok = json?["ok"] as? Bool ?? false
                let entitlement = json?["entitlement"] as? [String: Any]
                let active = entitlement?["active"] as? Bool ?? false
                await MainActor.run {
                    isAdminLoggingIn = false
                    if ok && active {
                        membershipActive = true
                        showOwnerLogin = false
                        adminPassword = ""
                        membershipStatus = "Owner admin unlocked. Full access is active on this device."
                    } else {
                        adminStatus = (json?["error"] as? String) ?? "Owner login failed."
                    }
                }
            } catch {
                await MainActor.run {
                    isAdminLoggingIn = false
                    adminStatus = "Could not reach Owner Login. Check your connection."
                }
            }
        }
    }


    private func loadDevices() {
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty else {
            deviceStatus = "Enter the email used at checkout first."
            return
        }
        guard var comps = URLComponents(url: backendBaseURL.appendingPathComponent("api/membership/devices"), resolvingAgainstBaseURL: false) else { return }
        comps.queryItems = [URLQueryItem(name: "email", value: trimmedEmail), URLQueryItem(name: "deviceId", value: deviceId)]
        guard let url = comps.url else { return }
        isLoadingDevices = true
        deviceStatus = "Loading devices…"
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let parsed = parseMembershipDevices(json?["devices"] as? [[String: Any]])
                let entitlement = json?["entitlement"] as? [String: Any]
                let count = parsed.count
                let limit = entitlement?["deviceLimit"] as? Int ?? (json?["deviceLimit"] as? Int ?? 0)
                await MainActor.run {
                    devices = parsed
                    isLoadingDevices = false
                    deviceStatus = parsed.isEmpty ? "No registered devices found yet." : "Devices used: \(count) / \(limit)"
                }
            } catch {
                await MainActor.run {
                    isLoadingDevices = false
                    deviceStatus = "Could not load devices. Check your connection."
                }
            }
        }
    }

    private func renameCurrentDevice() {
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanName = deviceName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty && !cleanName.isEmpty else {
            deviceStatus = "Enter email and device name."
            return
        }
        UserDefaults.standard.set(cleanName, forKey: "DebridChannelsDeviceName")
        postDeviceAction(path: "api/membership/device/rename", payload: ["email": trimmedEmail, "targetDeviceId": deviceId, "name": cleanName], successMessage: "Device name saved.")
    }

    private func removeDevice(_ target: MembershipDeviceRecord) {
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty else { deviceStatus = "Enter email first."; return }
        postDeviceAction(path: "api/membership/device/remove", payload: ["email": trimmedEmail, "targetDeviceId": target.deviceId], successMessage: "Device removed.")
    }

    private func replaceDevice(_ target: MembershipDeviceRecord) {
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanName = deviceName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Apple TV" : deviceName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty else { deviceStatus = "Enter email first."; return }
        UserDefaults.standard.set(cleanName, forKey: "DebridChannelsDeviceName")
        postDeviceAction(path: "api/membership/device/replace", payload: ["email": trimmedEmail, "oldDeviceId": target.deviceId, "newDeviceId": deviceId, "name": cleanName], successMessage: "Device replaced. Restore Membership again if needed.")
    }

    private func postDeviceAction(path: String, payload: [String: String], successMessage: String) {
        guard let url = URL(string: backendBaseURL.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + path) else { return }
        isLoadingDevices = true
        deviceStatus = "Saving device changes…"
        Task {
            do {
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = try JSONSerialization.data(withJSONObject: payload)
                let (data, _) = try await URLSession.shared.data(for: request)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let ok = json?["ok"] as? Bool ?? false
                let parsed = parseMembershipDevices(json?["devices"] as? [[String: Any]])
                await MainActor.run {
                    isLoadingDevices = false
                    if ok {
                        devices = parsed
                        deviceStatus = successMessage
                    } else {
                        deviceStatus = (json?["error"] as? String) ?? "Device change failed."
                    }
                }
            } catch {
                await MainActor.run {
                    isLoadingDevices = false
                    deviceStatus = "Could not save device changes."
                }
            }
        }
    }

    private func parseMembershipDevices(_ raw: [[String: Any]]?) -> [MembershipDeviceRecord] {
        (raw ?? []).compactMap { item in
            guard let id = item["deviceId"] as? String else { return nil }
            return MembershipDeviceRecord(deviceId: id, name: (item["name"] as? String) ?? "Apple TV", platform: (item["platform"] as? String) ?? "tvOS", firstSeenAt: item["firstSeenAt"] as? String, lastSeenAt: item["lastSeenAt"] as? String, current: item["current"] as? Bool ?? false)
        }
    }

    private func restoreMembership() {
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedEmail.isEmpty else {
            membershipStatus = "Enter the email used at Stripe checkout, then choose Restore Membership."
            return
        }
        guard var comps = URLComponents(url: backendBaseURL.appendingPathComponent("api/membership/status"), resolvingAgainstBaseURL: false) else { return }
        comps.queryItems = [URLQueryItem(name: "email", value: trimmedEmail), URLQueryItem(name: "deviceId", value: deviceId), URLQueryItem(name: "deviceName", value: deviceName)]
        guard let url = comps.url else { return }
        isRestoring = true
        membershipStatus = "Checking membership…"
        Task {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                let entitlement = json?["entitlement"] as? [String: Any]
                let active = entitlement?["active"] as? Bool ?? false
                let tier = entitlement?["tier"] as? String ?? "NONE"
                let expiresAt = entitlement?["expiresAt"] as? String
                let error = json?["error"] as? String
                let returnedDevices = parseMembershipDevices(json?["devices"] as? [[String: Any]])
                await MainActor.run {
                    isRestoring = false
                    if error == "device_limit_reached" {
                        devices = returnedDevices
                        deviceStatus = "Device limit reached. Choose an old device to replace with this Apple TV."
                        showDeviceManager = true
                        membershipStatus = "Device limit reached. Use Manage Devices to replace an old Apple TV."
                    } else if active {
                        membershipActive = true
                        if tier == "LIFETIME" || tier == "ADMIN" {
                            membershipStatus = "Membership active: \(tier). The Membership tab will hide after leaving this screen."
                        } else if let expiresAt {
                            membershipStatus = "Membership active: \(tier). Expires: \(expiresAt)."
                        } else {
                            membershipStatus = "Membership active: \(tier)."
                        }
                    } else {
                        membershipStatus = "No active membership found for that email yet. If you just paid, wait a moment and try Restore Membership again."
                    }
                }
            } catch {
                await MainActor.run {
                    isRestoring = false
                    membershipStatus = "Could not reach Membership. Check your connection and try again."
                }
            }
        }
    }
}



struct MembershipDeviceRecord: Identifiable, Equatable {
    let deviceId: String
    let name: String
    let platform: String
    let firstSeenAt: String?
    let lastSeenAt: String?
    let current: Bool
    var id: String { deviceId }
}

struct MembershipDeviceManagerPanel: View {
    @Binding var email: String
    @Binding var deviceName: String
    let devices: [MembershipDeviceRecord]
    let status: String
    let isLoading: Bool
    let currentDeviceId: String
    let load: () -> Void
    let renameCurrent: () -> Void
    let remove: (MembershipDeviceRecord) -> Void
    let replace: (MembershipDeviceRecord) -> Void
    let close: () -> Void

    private let panelWidth: CGFloat = 1080

    var body: some View {
        ZStack {
            Color.black.opacity(0.82).ignoresSafeArea()
            devicePanel
        }
    }

    private var devicePanel: some View {
        VStack(alignment: .leading, spacing: 18) {
            headerSection
            editorSection
            statusSection
            deviceListSection
            footerSection
        }
        .padding(38)
        .background(panelBackground)
        .overlay(panelBorder)
        .shadow(color: Color.black.opacity(0.85), radius: 54, y: 24)
    }

    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Manage Devices")
                .font(.system(size: 46, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Name this Apple TV, see devices on your membership, or replace an old device if your Apple TV was replaced.")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.70))
                .frame(width: 980, alignment: .leading)
        }
    }

    private var editorSection: some View {
        HStack(spacing: 16) {
            TextField("Email used at checkout", text: $email)
                .frame(width: 420)
            TextField("This device name", text: $deviceName)
                .frame(width: 360)
            Button(action: renameCurrent) {
                Text("Save Name")
                    .font(.system(size: 20, weight: .black, design: .rounded))
            }
            .buttonStyle(.borderedProminent)
            Button(action: load) {
                Text(isLoading ? "Loading…" : "Refresh")
                    .font(.system(size: 20, weight: .black, design: .rounded))
            }
            .buttonStyle(.bordered)
        }
    }

    private var statusSection: some View {
        Text(status)
            .font(.system(size: 18, weight: .bold, design: .rounded))
            .foregroundStyle(Color(red: 0.20, green: 0.62, blue: 1.0))
    }

    private var deviceListSection: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(devices) { device in
                    MembershipDeviceRow(
                        device: device,
                        replace: replace,
                        remove: remove
                    )
                }
            }
        }
        .frame(width: panelWidth, height: 360)
    }

    private var footerSection: some View {
        HStack {
            Spacer()
            Button(action: close) {
                Text("Done")
                    .font(.system(size: 22, weight: .black, design: .rounded))
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(width: panelWidth)
    }

    private var panelBackground: some View {
        RoundedRectangle(cornerRadius: 36, style: .continuous)
            .fill(Color(red: 0.035, green: 0.045, blue: 0.075))
    }

    private var panelBorder: some View {
        RoundedRectangle(cornerRadius: 36, style: .continuous)
            .stroke(Color.cyan.opacity(0.52), lineWidth: 2)
    }
}

struct MembershipDeviceRow: View {
    let device: MembershipDeviceRecord
    let replace: (MembershipDeviceRecord) -> Void
    let remove: (MembershipDeviceRecord) -> Void

    var body: some View {
        HStack(spacing: 14) {
            deviceText
            Spacer()
            actionButtons
        }
        .padding(18)
        .background(rowBackground)
        .overlay(rowBorder)
    }

    private var deviceText: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(device.name + (device.current ? "  • This Apple TV" : ""))
                .font(.system(size: 24, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("\(device.platform) • Last seen: \(device.lastSeenAt ?? "Unknown")")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
            Text(device.deviceId)
                .font(.system(size: 13, weight: .semibold, design: .monospaced))
                .foregroundStyle(.white.opacity(0.34))
                .lineLimit(1)
        }
    }

    private var actionButtons: some View {
        HStack(spacing: 12) {
            Button(action: { replace(device) }) {
                Text("Replace With This Apple TV")
                    .font(.system(size: 18, weight: .black, design: .rounded))
            }
            .buttonStyle(.borderedProminent)
            .disabled(device.current)
            Button(action: { remove(device) }) {
                Text("Remove")
                    .font(.system(size: 18, weight: .black, design: .rounded))
            }
            .buttonStyle(.bordered)
            .disabled(device.current)
        }
    }

    private var rowBackground: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .fill(Color.white.opacity(device.current ? 0.13 : 0.07))
    }

    private var rowBorder: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .stroke(device.current ? Color.cyan.opacity(0.70) : Color.white.opacity(0.12), lineWidth: 2)
    }
}


struct OwnerAdminLoginPanel: View {
    @Binding var email: String
    @Binding var password: String
    let status: String
    let isLoading: Bool
    let login: () -> Void
    let close: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 20) {
                Text("Owner Login")
                    .font(.system(size: 46, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Enter the email and password you created on the Owner Setup page.")
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.70))
                    .frame(width: 620, alignment: .leading)
                TextField("Owner email", text: $email)
                    .frame(width: 620)
                SecureField("Owner password", text: $password)
                    .frame(width: 620)
                if !status.isEmpty {
                    Text(status)
                        .font(.system(size: 18, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.72))
                        .frame(width: 620, alignment: .leading)
                }
                HStack(spacing: 18) {
                    Button(action: login) {
                        Text(isLoading ? "Checking…" : "Unlock Owner Access")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                    }
                    .buttonStyle(.borderedProminent)
                    Button(action: close) {
                        Text("Cancel")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                    }
                    .buttonStyle(.bordered)
                }
            }
            .padding(42)
            .background(RoundedRectangle(cornerRadius: 34, style: .continuous).fill(Color(red: 0.04, green: 0.055, blue: 0.085)))
            .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.cyan.opacity(0.55), lineWidth: 2))
            .shadow(color: Color.cyan.opacity(0.22), radius: 32, y: 16)
        }
    }
}

struct CheckoutQRPanel: View {
    let planName: String
    let url: URL
    let close: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.88).ignoresSafeArea()
            VStack(spacing: 22) {
                Text(planName)
                    .font(.system(size: 44, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Scan with your phone to open secure Stripe checkout.")
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                QRCodeImage(text: url.absoluteString)
                    .frame(width: 360, height: 360)
                    .background(Color.white, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .padding(.vertical, 4)
                Text(url.absoluteString)
                    .font(.system(size: 18, weight: .semibold, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.54))
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .frame(width: 900)
                HStack(spacing: 18) {
                    Button(action: { UIApplication.shared.open(url) }) {
                        Text("Open on Apple TV")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.bordered)
                    Button(action: close) {
                        Text("Done / Restore Later")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                            .padding(.horizontal, 22)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .padding(42)
            .background(.black.opacity(0.78), in: RoundedRectangle(cornerRadius: 44, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 44, style: .continuous).stroke(Color.orange.opacity(0.55), lineWidth: 2))
            .shadow(color: .black.opacity(0.84), radius: 60, y: 28)
        }
    }
}

struct QRCodeImage: View {
    let text: String
    private let context = CIContext()
    private let filter = CIFilter.qrCodeGenerator()

    var body: some View {
        if let image = makeQRImage() {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
                .padding(22)
        } else {
            Text("QR unavailable")
                .font(.system(size: 26, weight: .black, design: .rounded))
                .foregroundStyle(.black)
        }
    }

    private func makeQRImage() -> UIImage? {
        filter.message = Data(text.utf8)
        filter.correctionLevel = "M"
        guard let output = filter.outputImage else { return nil }
        let scaled = output.transformed(by: CGAffineTransform(scaleX: 12, y: 12))
        guard let cgImage = context.createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}

struct TrailerPopup: View {
    let url: URL
    let audioURL: URL?
    let sessionKey: String
    let close: () -> Void

    @State private var trailerMuted: Bool = false
    @State private var trailerControlsVisible: Bool = true
    @State private var hideControlsTask: Task<Void, Never>? = nil
    @State private var dismissTask: Task<Void, Never>? = nil
    @State private var popupVisible: Bool = false
    @State private var lightSweepActive: Bool = false
    @State private var isClosing: Bool = false
    @FocusState private var focusedAction: TrailerPopupAction?

    private enum TrailerPopupAction: Hashable {
        case mute
        case close
    }

    var body: some View {
        ZStack {
            Color.black
                .opacity(popupVisible && !isClosing ? 0.86 : 0.0)
                .ignoresSafeArea()
                .animation(.easeOut(duration: 0.22), value: popupVisible)
                .animation(.easeIn(duration: 0.16), value: isClosing)

            VStack(spacing: 18) {
                trailerVideoCard
                if trailerControlsVisible { trailerActionRow.transition(.opacity.combined(with: .move(edge: .bottom))) }
            }
            .focusSection()
            .scaleEffect(popupVisible && !isClosing ? 1.0 : 0.92)
            .opacity(popupVisible && !isClosing ? 1.0 : 0.0)
            .blur(radius: popupVisible && !isClosing ? 0 : 8)
            .animation(.spring(response: 0.34, dampingFraction: 0.82), value: popupVisible)
            .animation(.easeIn(duration: 0.16), value: isClosing)
        }
        .onAppear { prepareTrailerPopupEntrance() }
        .onChange(of: url.absoluteString) { _ in prepareTrailerPopupEntrance() }
        .onMoveCommand { direction in
            revealTrailerControls()
            switch direction {
            case .left:
                focusedAction = .mute
            case .right:
                focusedAction = .close
            default:
                break
            }
        }
        .onTapGesture { revealTrailerControls(); activateFocusedTrailerAction() }
        .onPlayPauseCommand { revealTrailerControls(); activateFocusedTrailerAction() }
        .onExitCommand(perform: dismissTrailerPopup)
        .onDisappear {
            hideControlsTask?.cancel()
            dismissTask?.cancel()
        }
    }

    private var trailerVideoCard: some View {
        TrailerPlayableSurface(url: url, audioURL: audioURL, muted: trailerMuted, sessionKey: sessionKey)
            .id(sessionKey + "|" + url.absoluteString + "|audio=\(audioURL?.absoluteString ?? "none")")
            .frame(width: 1540, height: 720)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .background(Color.black)
            .overlay(trailerGlassStroke)
            .overlay(trailerCinemaSweep.clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous)))
            .shadow(color: Color.orange.opacity(0.22), radius: popupVisible ? 38 : 0, x: 0, y: 16)
            .shadow(color: Color.blue.opacity(0.16), radius: popupVisible ? 52 : 0, x: 0, y: -8)
    }

    private var trailerGlassStroke: some View {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
            .stroke(
                LinearGradient(
                    colors: [Color.white.opacity(0.30), Color.orange.opacity(0.22), Color.white.opacity(0.10)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                lineWidth: 1.4
            )
    }

    private var trailerCinemaSweep: some View {
        GeometryReader { proxy in
            LinearGradient(
                colors: [Color.clear, Color.white.opacity(0.16), Color.clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .frame(width: 260, height: proxy.size.height * 1.5)
            .rotationEffect(.degrees(18))
            .offset(x: lightSweepActive ? proxy.size.width + 220 : -360, y: -proxy.size.height * 0.22)
            .opacity(lightSweepActive ? 0.0 : 1.0)
            .animation(.easeOut(duration: 0.95).delay(0.12), value: lightSweepActive)
        }
        .allowsHitTesting(false)
    }

    private var trailerActionRow: some View {
        HStack(spacing: 18) {
            Button(action: { revealTrailerControls(); trailerMuted.toggle() }) {
                Text(trailerMuted ? "Unmute" : "Mute")
                    .font(.system(size: 26, weight: .bold))
                    .padding(.horizontal, 34)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .focused($focusedAction, equals: .mute)
            .focusable(true)

            Button(action: dismissTrailerPopup) {
                Text("Close Trailer")
                    .font(.system(size: 26, weight: .bold))
                    .padding(.horizontal, 34)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
            .focused($focusedAction, equals: .close)
            .focusable(true)
        }
        .focusSection()
        .opacity(popupVisible && !isClosing ? 1.0 : 0.0)
    }

    private func prepareTrailerPopupEntrance() {
        dismissTask?.cancel()
        trailerMuted = false
        trailerControlsVisible = true
        focusedAction = .close
        isClosing = false
        lightSweepActive = false
        popupVisible = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.03) {
            withAnimation(.spring(response: 0.34, dampingFraction: 0.82)) { popupVisible = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { lightSweepActive = true }
        }
        scheduleTrailerControlHide()
    }

    private func activateFocusedTrailerAction() {
        switch focusedAction ?? .close {
        case .mute: trailerMuted.toggle(); scheduleTrailerControlHide()
        case .close: dismissTrailerPopup()
        }
    }

    private func dismissTrailerPopup() {
        hideControlsTask?.cancel()
        dismissTask?.cancel()
        withAnimation(.easeIn(duration: 0.16)) {
            isClosing = true
            trailerControlsVisible = false
        }
        dismissTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 170_000_000)
            close()
        }
    }

    private func revealTrailerControls() {
        withAnimation(.easeOut(duration: 0.18)) { trailerControlsVisible = true }
        if focusedAction == nil { focusedAction = .close }
        scheduleTrailerControlHide()
    }

    private func scheduleTrailerControlHide() {
        hideControlsTask?.cancel()
        hideControlsTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            withAnimation(.easeOut(duration: 0.22)) { trailerControlsVisible = false }
        }
    }
}

struct TrailerPlayableSurface: View {
    let url: URL
    let audioURL: URL?
    let muted: Bool
    let sessionKey: String

    var body: some View {
        // v443: trailer popup remains AVPlayer-only and isolated from VOD playback. The user-facing blocker was that
        // KSPlayer could attach and render the first trailer frame/thumbnail but remain
        // internally paused. Main VOD, Live TV, and guide preview remain on KSPlayer.
        TrailerAVPlayerSurface(url: url, muted: muted, sessionKey: sessionKey)
            .id(sessionKey + "|" + url.absoluteString + "|av-trailer-v444|muted=\(muted)")
    }
}

struct TrailerAVPlayerSurface: UIViewRepresentable {
    let url: URL
    let muted: Bool
    let sessionKey: String

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    final class Coordinator {
        var player: AVPlayer?
        var item: AVPlayerItem?
        var currentURL: URL?
        var currentSessionKey: String?
        var endObserver: NSObjectProtocol?
        var statusObserver: NSKeyValueObservation?
        var timeControlObserver: NSKeyValueObservation?
        var rateObserver: NSKeyValueObservation?
        var retryTask: Task<Void, Never>?
        var hasIssuedInitialPlay = false

        deinit { teardown() }

        func teardown() {
            retryTask?.cancel(); retryTask = nil
            if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
            endObserver = nil
            statusObserver = nil
            timeControlObserver = nil
            rateObserver = nil
            player?.pause()
            player?.replaceCurrentItem(with: nil)
            player = nil
            item = nil
            currentURL = nil
            currentSessionKey = nil
            hasIssuedInitialPlay = false
        }

        func configure(url: URL, muted: Bool, sessionKey: String, view: PlayerLayerView) {
            if currentURL != url || currentSessionKey != sessionKey || player == nil {
                teardown()

                let asset = AVURLAsset(url: url, options: [
                    AVURLAssetPreferPreciseDurationAndTimingKey: false,
                    "AVURLAssetHTTPHeaderFieldsKey": [
                        "User-Agent": "DebridChannels-tvOS TrailerPlayer/475",
                        "Accept": "video/mp4,video/*,*/*"
                    ]
                ])
                let nextItem = AVPlayerItem(asset: asset)
                nextItem.preferredForwardBufferDuration = 2
                nextItem.canUseNetworkResourcesForLiveStreamingWhilePaused = true
                nextItem.preferredPeakBitRate = 0
                if #available(tvOS 11.0, *) {
                    nextItem.preferredMaximumResolution = CGSize(width: 3840, height: 2160)
                }

                let nextPlayer = AVPlayer(playerItem: nextItem)
                // v475: trailer remux-cache URLs are verified MP4 files with byte ranges.
                // Kick AVPlayer immediately instead of waiting for readyToPlay first; some
                // backend-remuxed MP4s stayed in the visible loading state until playback
                // was requested. Keep rescue observers, but avoid the old wait-only path.
                nextPlayer.automaticallyWaitsToMinimizeStalling = false
                nextPlayer.preventsDisplaySleepDuringVideoPlayback = true
                nextPlayer.actionAtItemEnd = .none
                nextPlayer.isMuted = muted
                nextPlayer.volume = muted ? 0.0 : 1.0

                view.playerLayer.player = nextPlayer
                view.playerLayer.videoGravity = .resizeAspectFill
                view.playerLayer.backgroundColor = UIColor.black.cgColor

                player = nextPlayer
                item = nextItem
                currentURL = url
                currentSessionKey = sessionKey

                statusObserver = nextItem.observe(\.status, options: [.new, .initial]) { [weak self] item, _ in
                    guard item.status == .readyToPlay else { return }
                    DispatchQueue.main.async { self?.startPlaybackIfNeeded() }
                }
                timeControlObserver = nextPlayer.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
                    // v412: do not spam playImmediately while the item is buffering. Repeated
                    // play kicks against a still-growing trailer source caused the visible
                    // opening-frame replay/loop effect. Only rescue a pause after playback
                    // has already been issued for this one player instance.
                    guard player.timeControlStatus == .paused else { return }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { self?.resumeIfUnexpectedlyPaused() }
                }
                rateObserver = nextPlayer.observe(\.rate, options: [.new]) { [weak self] player, _ in
                    guard player.rate == 0 else { return }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) { self?.resumeIfUnexpectedlyPaused() }
                }
                endObserver = NotificationCenter.default.addObserver(
                    forName: .AVPlayerItemDidPlayToEndTime,
                    object: nextItem,
                    queue: .main
                ) { [weak self] _ in
                    self?.player?.seek(to: .zero)
                    self?.hasIssuedInitialPlay = false
                    self?.startPlaybackIfNeeded()
                }

                startPlaybackIfNeeded()
                retryTask = Task { @MainActor [weak self] in
                    // v475: use a few spaced rescue kicks for verified remux-cache MP4s.
                    // If AVPlayer starts buffering but remains at rate 0, this moves it
                    // out of the stuck-loading state without changing the trailer URL.
                    for delay in [900_000_000, 1_800_000_000, 3_200_000_000] {
                        try? await Task.sleep(nanoseconds: UInt64(delay))
                        self?.startPlaybackIfNeeded(force: true)
                    }
                }
            } else {
                player?.isMuted = muted
                player?.volume = muted ? 0.0 : 1.0
                startPlaybackIfNeeded()
            }
        }

        func startPlaybackIfNeeded(force: Bool = false) {
            guard let player, let item else { return }
            guard item.status != .failed else { return }
            if !force && hasIssuedInitialPlay && player.rate > 0 { return }
            hasIssuedInitialPlay = true
            if #available(tvOS 10.0, *) { player.playImmediately(atRate: 1.0) }
            else { player.play() }
        }

        func resumeIfUnexpectedlyPaused() {
            guard let player, let item else { return }
            guard item.status != .failed else { return }
            guard hasIssuedInitialPlay, player.rate == 0 else { return }
            player.play()
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        context.coordinator.configure(url: url, muted: muted, sessionKey: sessionKey, view: view)
    }

    static func dismantleUIView(_ view: PlayerLayerView, coordinator: Coordinator) {
        coordinator.teardown()
        view.playerLayer.player = nil
    }
}



struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL

    @State private var player: AVPlayer? = nil
    @State private var controlsVisible = true
    @State private var isPlaying = true
    @State private var isLoading = true
    @State private var errorText: String? = nil
    @State private var retryText: String? = nil
    @State private var currentSeconds: Double = 0
    @State private var durationSeconds: Double = 0
    @State private var metadataRuntimeSeconds: Double = 0
    @State private var metadataRuntimeLabel: String = ""
    @State private var runtimeLookupTask: Task<Void, Never>? = nil
    @State private var videoGravity: AVLayerVideoGravity = .resizeAspect
    @State private var timeObserver: Any? = nil
    @State private var statusObserver: NSKeyValueObservation? = nil
    @State private var hideTask: Task<Void, Never>? = nil
    @State private var endObserver: NSObjectProtocol? = nil
    @State private var renderWatchdogTask: Task<Void, Never>? = nil
    @State private var nativePrepareTask: Task<Void, Never>? = nil
    @State private var activePanel: PlayerPanel? = nil
    @State private var playbackNotice: String = ""
    @State private var lastPlayerActionAt: TimeInterval = 0
    @State private var lastPlayerMoveAt: TimeInterval = 0
    @State private var forceVLCSurface = false
    @State private var forceKSPlayerSurface = true
    @State private var avRetryAttemptedForCurrentURL = false
    @State private var nativeProfileText: String = ""
    @State private var diagnosticsTick: Int = 0
    @State private var vlcSeekSerial = 0
    @State private var vlcSeekSeconds: Double = 0
    @State private var ksSeekIsAbsolute = false
    @State private var vlcSurfaceToken: Int = 0
    @State private var ksSurfaceToken: Int = 0
    @State private var ksStartTimeSeconds: Double = 0
    @State private var resumeEntry: PlaybackResumeEntry? = nil
    @State private var didAttemptAutomaticResume = false
    @State private var pendingAutomaticResumeSeconds: Double? = nil
    @State private var automaticResumeTask: Task<Void, Never>? = nil
    @State private var didApplyAutomaticResumeSeek = false
    @State private var lastResumeSaveAt: Date = .distantPast
    @FocusState private var focusedControl: PlayerControl?
    @FocusState private var playerCanvasFocused: Bool
    @AppStorage("vodCacheLimitGB") private var vodCacheLimitGB: Int = 10
    @AppStorage("vodPlaybackDiagnosticsEnabled") private var vodPlaybackDiagnosticsEnabled: Bool = false
    @AppStorage("tmdbApiKey") private var vodTMDBApiKey: String = ""
    @AppStorage("externalMoviesInfuseDefault") private var externalMoviesInfuseDefault: Bool = false
    @AppStorage("externalMoviesVLCDefault") private var externalMoviesVLCDefault: Bool = false
    @AppStorage("externalMoviesSenPlayerDefault") private var externalMoviesSenPlayerDefault: Bool = false
    @AppStorage("externalShowsInfuseDefault") private var externalShowsInfuseDefault: Bool = false
    @AppStorage("externalShowsVLCDefault") private var externalShowsVLCDefault: Bool = false
    @AppStorage("externalShowsSenPlayerDefault") private var externalShowsSenPlayerDefault: Bool = false
    @AppStorage("liveTVUseAVPlayerDefault") private var liveTVUseAVPlayerDefault: Bool = false
    @StateObject private var cacheSession = TemporaryVODCacheSession()
    @State private var preparedPlaybackURL: URL? = nil
    @State private var vodBootstrapDeadline: Date? = nil
    @State private var playbackClockTask: Task<Void, Never>? = nil
    @State private var startupLoadingTask: Task<Void, Never>? = nil
    @State private var lastKnownControlFocus: PlayerControl = .playPause
    @State private var didSeedVODOverlayFocus = false
    @State private var selectedAudioMode: String = "Auto"
    @State private var selectedSubtitleMode: String = "Off"
    @State private var selectedPlaybackMode: String = "KS Direct"
    @State private var selectedEpisodeSeason: Int = 1
    @State private var isFindingAlternateAudio = false
    @State private var selectedAlternateAudioIndex: Int? = nil
    @StateObject private var liveQuickGuideModel = LiveTVSourceModel()
    @State private var liveQuickGuideVisible = false
    @State private var liveQuickGuideIndex: Int = 0
    @FocusState private var focusedPanelOption: PlayerPanelOption?
    @State private var selectedPanelOption: PlayerPanelOption? = nil
    @State private var vodOverlayLockedForRemoteNavigation = false

    enum PlayerControl: Hashable { case resume, back10, playPause, forward10, ksplayer, internalVLC, avplayer, audio, findAudio, subtitles, episodes, zoom, settings, infuse, vlc, senplayer, close }
    enum PlayerPanel: Hashable { case audio, subtitles, episodes, settings }
    enum PlayerPanelOption: Hashable { case audioAuto, audioEnglish, audioOriginal, audioNext, findAlternateAudio, alternateAudio(Int), alternateAudioMinus250, alternateAudioPlus250, alternateAudioReset, alternateAudioClear, subtitlesOff, subtitlesEnglish, subtitlesAuto, subtitlesNext, season(Int), episodesOpen, cache5, cache10, cacheUnlimited, frameRateInfo, liveReloadStream, liveResyncStream, liveClearBuffer, liveStreamDiagnostics, settingsDiagnostics, settingsFindAudio, settingsInfuse, settingsVLC, settingsSenPlayer, closePanel }

    private var activeEngineName: String {
        if isLivePlayback && forceKSPlayerSurface { return "KSPlayer Live TV" }
        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface { return "AVPlayer Live TV" }
        return forceKSPlayerSurface ? "KSPlayer Internal" : "VLC Internal"
    }

    private var resolvedDurationSeconds: Double {
        let playerDuration = durationSeconds.isFinite ? durationSeconds : 0
        if playerDuration > 1 { return playerDuration }
        let metadataDuration = metadataRuntimeSeconds.isFinite ? metadataRuntimeSeconds : 0
        if metadataDuration > 1 { return metadataDuration }
        return 0
    }

    private var progress: Double {
        let total = resolvedDurationSeconds
        guard total > 0 else { return 0 }
        return min(max(currentSeconds / total, 0), 1)
    }

    private var remainingSeconds: Double {
        let total = resolvedDurationSeconds
        guard total > 0 else { return 0 }
        return max(total - currentSeconds, 0)
    }

    private var progressPercentText: String {
        guard resolvedDurationSeconds > 0 else { return "0%" }
        return "\(Int((progress * 100).rounded()))%"
    }

    private var isLivePlayback: Bool {
        item.type.lowercased() == "live" || store.playbackLinkLabel.localizedCaseInsensitiveContains("Live TV")
    }

    private var isSeriesPlayback: Bool {
        let type = item.type.lowercased()
        if item.seasonNumber != nil || item.episodeNumber != nil { return true }
        if type.contains("series") || type.contains("show") || type == "tv" || type == "episode" { return true }
        if store.playbackLinkLabel.localizedCaseInsensitiveContains("S0") || store.playbackLinkLabel.localizedCaseInsensitiveContains("Episode") { return true }
        return false
    }


    private var vodOverlayDescriptionText: String {
        let trimmed = item.description.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty && trimmed.lowercased() != "no description available yet." { return trimmed }
        let genres = item.genres.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }.prefix(3).joined(separator: ", ")
        if !genres.isEmpty { return "Metadata is still loading from the selected catalog. Genre: \(genres)." }
        return "Metadata is still loading from the selected catalog. Playback will continue while Debrid Channels refreshes artwork and description data."
    }

    private var activePlaybackURL: URL? {
        if isLivePlayback { return url }
        // v259: KSPlayer must start from the resolved direct stream immediately.
        // The temp cache warms in parallel and is kept as a safe fallback/resume source;
        // do not hot-swap the visible KS surface to a partial cache file while a user is watching.
        if forceKSPlayerSurface { return url }
        return cacheSession.playbackURL ?? url
    }

    private var vodStartThresholdBytes: Int64 {
        256 * 1024
    }

    private var sourceQualityLabel: String {
        let label = store.playbackLinkLabel.lowercased()
        if label.contains("4k") || label.contains("2160") { return "4K Direct" }
        if label.contains("1080") { return "HD Direct" }
        if label.contains("cached") || label.contains("debrid") { return "Cache Ready" }
        return "Direct Play"
    }

    private var cacheReadyLabel: String {
        let status = cacheSession.statusText.trimmingCharacters(in: .whitespacesAndNewlines)
        if status.isEmpty { return isLivePlayback ? "Live" : "Cache Warming" }
        if status.lowercased().contains("ready") { return "Cache Ready" }
        if status.lowercased().contains("disabled") { return "Direct Stream" }
        return "Cache Warming"
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            if let activePlaybackURL {
                UniversalVideoSurface(
                    url: activePlaybackURL,
                    avPlayer: player,
                    videoGravity: videoGravity,
                    forceVLC: forceVLCSurface,
                    routeHint: store.playbackLinkLabel,
                    vlcShouldPlay: isPlaying,
                    vlcSeekSerial: vlcSeekSerial,
                    vlcSeekSeconds: vlcSeekSeconds,
                    vlcSurfaceToken: vlcSurfaceToken,
                    ksShouldPlay: isPlaying,
                    ksSeekSerial: vlcSeekSerial,
                    ksSeekSeconds: vlcSeekSeconds,
                    ksReloadToken: ksSurfaceToken,
                    ksStartTimeSeconds: ksStartTimeSeconds,
                    ksSeekIsAbsolute: ksSeekIsAbsolute,
                    preferKSPlayer: forceKSPlayerSurface,
                    preferAVFoundation: isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface,
                    externalAudioURL: store.selectedAlternateAudioSource.flatMap { URL(string: $0.url) },
                    externalAudioOffsetMS: store.alternateAudioSyncOffsetMS
                )
                .ignoresSafeArea()
                .zIndex(0)
                .allowsHitTesting(!(controlsVisible || activePanel != nil || isLoading || errorText != nil))
                .disabled(controlsVisible || activePanel != nil || isLoading || errorText != nil)
                .focusable(false)
            } else {
                Color.black.ignoresSafeArea()
            }

            if isLoading {
                ZStack {
                    Color.black.opacity(0.30).ignoresSafeArea()
                    DebridMovieLoadingView(message: retryText ?? "Loading movie…")
                }
                .zIndex(30)
            }

            if let errorText {
                ApplePlayerErrorCard(message: errorText) { store.closePlayer() }
                    .zIndex(40)
            }

            if isLivePlayback && liveQuickGuideVisible {
                livePlaybackQuickGuideOverlay
                    .zIndex(35)
                    .transition(.move(edge: .top).combined(with: .opacity))
            }

            // v151: diagnostics are useful, but keeping a diagnostic panel alive over every playing
            // frame adds SwiftUI/compositing work exactly where cadence is most sensitive. Show it while
            // paused/loading/settings are open, not during normal hidden-controls playback.
            if !isLivePlayback && vodPlaybackDiagnosticsEnabled && (!isPlaying || activePanel == .settings || isLoading || errorText != nil) {
                DebridPlaybackDiagnosticsPanel(diagnostics: currentPlaybackDiagnostics())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .padding(.top, 42)
                    .padding(.trailing, 54)
                    .zIndex(12)
        .transition(.opacity)
            }

            if controlsVisible || activePanel != nil {
                AppleVODChromeBackground()
                    .ignoresSafeArea()
                    .opacity(isPlaying ? 0.18 : 1.0)
                    .allowsHitTesting(false)

                TheaterAmbientArtworkGlow(item: item)
                    .ignoresSafeArea()
                    .opacity(isPlaying ? 0.34 : 0.46)
                    .allowsHitTesting(false)
                    .zIndex(2)
            }

            if let activePanel {
                // v269: panel shield blocks remote/tap leakage to the bottom VOD bar while
                // the option panel is open. The bottom bar remains visible, but is silenced.
                Color.black.opacity(0.001)
                    .ignoresSafeArea()
                    .contentShape(Rectangle())
                    .allowsHitTesting(true)
                    .zIndex(34)

                DebridPlayerPanel(
                    title: panelTitle(activePanel),
                    detail: panelDetail(activePanel),
                    focusedOption: selectedPanelOption ?? focusedPanelOption
                ) {
                    panelOptions(activePanel)
                    PanelOptionChip(title: "Close Panel", selected: (selectedPanelOption ?? focusedPanelOption) == .closePanel, focus: .closePanel, focused: $focusedPanelOption) {
                        focusedPanelOption = .closePanel
                        selectedPanelOption = .closePanel
                        activateFocusedPanelOption()
                    }
                }
                .focusSection()
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
                .padding(.trailing, 76)
                .padding(.bottom, 292)
                .zIndex(35)
                .onAppear { seedPanelFocus(activePanel) }
            }

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .bottom, spacing: isLivePlayback ? 18 : 30) {
                    if !isLivePlayback {
                        AppleVODPosterCard(item: item)
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        VStack(alignment: .leading, spacing: 8) {
                            if isLivePlayback {
                                // v530: Live TV playback overlay should not draw a boxed/channel-title label.
                                // The channel logo is enough identity; program details remain below.
                                LivePlaybackLogoOnly(item: item)
                                    .frame(width: 360, height: 64, alignment: .leading)
                                    .fixedSize(horizontal: false, vertical: true)
                            } else {
                                HeroLogoText(item: item, pulse: false)
                                    .frame(width: 520, height: 78, alignment: .leading)
                                    .fixedSize(horizontal: false, vertical: true)

                                Text(([item.year] + item.genres.prefix(3)).filter { !$0.isEmpty }.joined(separator: "  •  "))
                                    .font(.system(size: 21, weight: .bold, design: .rounded))
                                    .kerning(0.45)
                                    .foregroundStyle(.white.opacity(0.76))
                                    .lineLimit(1)
                            }
                        }
                        .frame(width: 1030, alignment: .leading)

                        Text(vodOverlayDescriptionText)
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .lineSpacing(5)
                            .lineLimit(isLivePlayback ? 2 : 3)
                            .foregroundStyle(.white.opacity(0.76))
                            .frame(width: 1030, alignment: .leading)
                    }

                    VODTheaterCastWall(item: item)
                        .frame(width: 360, height: 210, alignment: .bottomLeading)
                        .padding(.leading, 72)
                }
                HStack(alignment: .center, spacing: 18) {
                    Text(formatTime(currentSeconds))
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 86, alignment: .leading)
                    PlayerProgressBar(progress: progress)
                        .frame(width: 1510, height: 14)
                    Text(resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "--:--")
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 96, alignment: .trailing)
                }
                .foregroundStyle(.white.opacity(0.92))

                VODRuntimeProgressSummary(
                    title: item.title,
                    current: formatTime(currentSeconds),
                    total: isLivePlayback ? "LIVE" : (resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "--:--"),
                    remaining: isLivePlayback ? "LIVE" : formatTime(remainingSeconds),
                    percent: isLivePlayback ? "LIVE" : progressPercentText,
                    cacheLabel: isLivePlayback ? "Live TV: cache disabled" : cacheLimitLabel,
                    cacheUsed: isLivePlayback ? "0.00GB" : String(format: "%.2fGB", cacheUsedGB),
                    cacheLimit: isLivePlayback ? "Disabled" : (cacheLimitGBValue == 0 ? "Unlimited" : String(format: "%.0fGB", cacheLimitGBValue))
                )
                .frame(width: 1780, alignment: .leading)

                if !isLivePlayback {
                    VODCacheProgressRow(cacheLabel: cacheLimitLabel, usedGB: cacheUsedGB, limitGB: cacheLimitGBValue, progress: cacheFillProgress, status: cacheSession.statusText)
                        .frame(width: 1780, alignment: .leading)
                }

                ScrollViewReader { proxy in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            if let resumeEntry, resumeEntry.seconds >= 8, !isLivePlayback {
                                PlayerControlButton(title: "▶ Resume from \(formatTime(resumeEntry.seconds))", focus: .resume, focused: $focusedControl) { playerAction { forceResumeFromSavedPosition() } }.id(PlayerControl.resume)
                            }
                            PlayerControlButton(title: "Back 30", focus: .back10, focused: $focusedControl) { playerAction { seekRelative(-30) } }.id(PlayerControl.back10)
                            PlayerControlButton(title: isPlaying ? "Pause" : "Play", focus: .playPause, focused: $focusedControl) { playerAction { togglePlay() } }.id(PlayerControl.playPause)
                            PlayerControlButton(title: "Forward 30", focus: .forward10, focused: $focusedControl) { playerAction { seekRelative(30) } }.id(PlayerControl.forward10)
                            PlayerControlButton(title: "KSPlayer", focus: .ksplayer, focused: $focusedControl) { playerAction { selectedPlaybackMode = "KS Direct"; switchToKSPlayerEngine(manual: true) } }.id(PlayerControl.ksplayer)
                            PlayerControlButton(title: "VLC", focus: .internalVLC, focused: $focusedControl) { playerAction { selectedPlaybackMode = "VLC Internal"; switchToVLCEngine(manual: true) } }.id(PlayerControl.internalVLC)
                            // v504: AVPlayer remains available for Live TV fallback/settings but is no longer exposed as a VOD overlay chip.
                            PlayerControlButton(title: "Audio  \(selectedAudioMode)", focus: .audio, focused: $focusedControl) { playerAction { activePanel = .audio; seedPanelFocus(.audio); forceControlsVisibleForNavigation() } }.id(PlayerControl.audio)
                            PlayerControlButton(title: "Subtitles  \(selectedSubtitleMode)", focus: .subtitles, focused: $focusedControl) { playerAction { activePanel = .subtitles; seedPanelFocus(.subtitles); forceControlsVisibleForNavigation() } }.id(PlayerControl.subtitles)
                            if isSeriesPlayback {
                                PlayerControlButton(title: "Episodes  S\(selectedEpisodeSeason)", focus: .episodes, focused: $focusedControl) { playerAction { activePanel = .episodes; seedPanelFocus(.episodes); forceControlsVisibleForNavigation() } }.id(PlayerControl.episodes)
                            }
                            PlayerControlButton(title: "Zoom", focus: .zoom, focused: $focusedControl) { playerAction { toggleZoom() } }.id(PlayerControl.zoom)
                            PlayerControlButton(title: "Settings", focus: .settings, focused: $focusedControl) { playerAction { activePanel = .settings; seedPanelFocus(.settings); forceControlsVisibleForNavigation() } }.id(PlayerControl.settings)
                            // v504: Close is handled by Back/Menu so the bottom chip rail stays playback-focused.
                        }
                        .padding(.trailing, 120)
                    }
                    .frame(width: 1780, alignment: .leading)
                    .onAppear { seedVODOverlayFocusIfNeeded(); if let f = focusedControl { proxy.scrollTo(f, anchor: .center) } }
                    .onChange(of: focusedControl) { newFocus in
                        guard let newFocus else { return }
                        withAnimation(.easeOut(duration: 0.16)) { proxy.scrollTo(newFocus, anchor: .center) }
                    }
                }
                .focusSection()
                .modifier(VODFocusBoundaryModifier())
                .padding(10)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.black.opacity(0.22)))
                .contentShape(Rectangle())
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 54)
            .padding(.bottom, 104)
            .frame(maxWidth: .infinity, alignment: .leading)
            .opacity(controlsVisible ? 1.0 : 0.0)
            .allowsHitTesting(controlsVisible && activePanel == nil)
            .disabled(activePanel != nil)
            .focusable(activePanel == nil)
            .focusSection()
            .contentShape(Rectangle())
            .zIndex(25)
            .animation(isPlaying ? nil : .easeInOut(duration: 0.22), value: controlsVisible)
        }
        .contentShape(Rectangle())
        .focusSection()
        .onAppear { setupPlayer(); if isLivePlayback { liveQuickGuideModel.loadCachedOrDemo(); controlsVisible = false } else { forceControlsVisibleForNavigation(); seedVODOverlayFocusIfNeeded() } }
        .onDisappear { teardownPlayer() }
        .onMoveCommand { direction in routePlayerMove(direction) }
        .onTapGesture {
            handlePlayerSelectPress()
        }
        .onPlayPauseCommand {
            handlePlayerPlayPausePress()
        }
        .onChange(of: controlsVisible) { visible in
            if visible { seedVODOverlayFocusIfNeeded() }
        }
        .onChange(of: activePanel) { panel in
            if let panel { vodOverlayLockedForRemoteNavigation = true; seedPanelFocus(panel) } else { focusedPanelOption = nil; selectedPanelOption = nil; vodOverlayLockedForRemoteNavigation = controlsVisible }
        }
        .onChange(of: focusedControl) { newFocus in
            if let newFocus, visiblePlayerControlOrder.contains(newFocus) { lastKnownControlFocus = newFocus }
        }
        .onExitCommand { if activePanel != nil { activePanel = nil; selectedPanelOption = nil; focusedPanelOption = nil; forceControlsVisibleForNavigation() } else { store.closePlayer() } }
    }

    private func ensureVODChipsFocused(lockOverlay: Bool = true) {
        if lockOverlay { vodOverlayLockedForRemoteNavigation = true }
        forceControlsVisibleForNavigation(lockOverlay: lockOverlay)
        if focusedControl == nil || !visiblePlayerControlOrder.contains(focusedControl!) {
            if !visiblePlayerControlOrder.contains(lastKnownControlFocus) { lastKnownControlFocus = .playPause }
            focusedControl = lastKnownControlFocus
        }
        didSeedVODOverlayFocus = true
    }

    private var visiblePlayerControlOrder: [PlayerControl] {
        var controls: [PlayerControl] = []
        if resumeEntry != nil && !isLivePlayback { controls.append(.resume) }
        controls += [.back10, .playPause, .forward10, .ksplayer, .internalVLC, .audio, .subtitles]
        if isSeriesPlayback { controls.append(.episodes) }
        controls += [.zoom, .settings]
        return controls
    }

    private func handlePlayerSelectPress() {
        if isLivePlayback && liveQuickGuideVisible { playLiveQuickGuideSelection(); return }
        if activePanel != nil { activateFocusedPanelOption(); return }
        if !controlsVisible { ensureVODChipsFocused(lockOverlay: true); return }
        ensureVODChipsFocused(lockOverlay: true)
        activateFocusedPlayerControl()
    }

    private func handlePlayerPlayPausePress() {
        // v497: The physical Apple TV Play/Pause button should always do exactly
        // that: pause or resume playback. It no longer opens/selects overlay chips.
        playerAction { togglePlay() }
    }

    private var liveQuickGuideChannels: [LiveTVChannel] {
        let loaded = liveQuickGuideModel.channels.isEmpty ? [] : liveQuickGuideModel.channels
        return loaded.isEmpty ? LiveTVScreen.sampleChannels : loaded
    }

    private var currentLiveQuickGuideChannel: LiveTVChannel? {
        liveQuickGuideChannels.first(where: { $0.name == item.title || "live-\($0.id)-\($0.streamURL.hashValue)" == item.id })
    }

    private var livePlaybackQuickGuideOverlay: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Text("Quick Guide")
                    .font(.system(size: 26, weight: .black, design: .rounded))
                    .padding(.horizontal, 28)
                    .padding(.vertical, 11)
                    .background(Capsule().fill(Color.white.opacity(0.28)))
                Text("Options")
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.horizontal, 22)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color.black.opacity(0.22)))
                Spacer()
                Text(Date().formatted(date: .omitted, time: .shortened))
                    .font(.system(size: 25, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.86))
            }
            .padding(.horizontal, 74)
            .padding(.top, 48)
            .padding(.bottom, 20)

            liveQuickGuideChannelRail
                .padding(.horizontal, 74)

            if let selected = liveQuickGuideSelectedChannel {
                let program = liveQuickGuideModel.currentProgram(for: selected) ?? liveQuickGuideModel.programs(for: selected).first
                HStack(alignment: .center, spacing: 28) {
                    liveQuickGuideLogo(selected)
                    VStack(alignment: .leading, spacing: 8) {
                        Text(program?.title ?? selected.now)
                            .font(.system(size: 34, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text([selected.number, selected.source, selected.category].filter { !$0.isEmpty }.joined(separator: " • "))
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.72))
                            .lineLimit(1)
                        Text((program?.description).flatMap { $0.isEmpty ? nil : $0 } ?? selected.description)
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.86))
                            .lineLimit(2)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 8) {
                        Text("Left/Right browses guide • Up/Down hides")
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white.opacity(0.55))
                        Text("Select/Play opens channel")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))
                    }
                }
                .padding(.horizontal, 74)
                .padding(.top, 20)
                .padding(.bottom, 28)
            }
            Spacer(minLength: 0)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(
            LinearGradient(colors: [Color.blue.opacity(0.92), Color.indigo.opacity(0.64), Color.black.opacity(0.16), Color.clear], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        )
        .onAppear { syncLiveQuickGuideIndexToCurrentChannel() }
        .onExitCommand { liveQuickGuideVisible = false }
    }

    private var liveQuickGuideSelectedChannel: LiveTVChannel? {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return nil }
        let index = min(max(liveQuickGuideIndex, 0), channels.count - 1)
        return channels[index]
    }

    private var liveQuickGuideChannelRail: some View {
        let channels = liveQuickGuideWindow
        return HStack(spacing: 18) {
            ForEach(channels, id: \.id) { channel in
                let isSelected = channel.id == liveQuickGuideSelectedChannel?.id
                let program = liveQuickGuideModel.currentProgram(for: channel) ?? liveQuickGuideModel.programs(for: channel).first
                ZStack(alignment: .bottomLeading) {
                    if let imageURL = program?.imageURL, let url = URL(string: imageURL), !imageURL.isEmpty {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .success(let image): image.resizable().scaledToFit().padding(6)
                            default: LinearGradient(colors: [channel.accent.opacity(0.40), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
                            }
                        }
                    } else if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                        ZStack { channel.accent.opacity(0.34); AsyncImage(url: url) { phase in if case .success(let image) = phase { image.resizable().scaledToFit().padding(22) } else { Text(channel.logo).font(.system(size: 30, weight: .black)) } } }
                    } else {
                        LinearGradient(colors: [channel.accent.opacity(0.46), Color.black.opacity(0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    }
                    LinearGradient(colors: [.clear, .black.opacity(0.88)], startPoint: .center, endPoint: .bottom)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(program?.title ?? channel.now)
                            .font(.system(size: isSelected ? 21 : 18, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        Text(channel.name)
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.74))
                            .lineLimit(1)
                    }
                    .padding(12)
                }
                .frame(width: isSelected ? 292 : 250, height: isSelected ? 174 : 142)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(isSelected ? Color.white.opacity(0.92) : Color.white.opacity(0.15), lineWidth: isSelected ? 4 : 1))
                .shadow(color: .black.opacity(isSelected ? 0.48 : 0.20), radius: isSelected ? 18 : 8, y: isSelected ? 10 : 4)
                .animation(.easeOut(duration: 0.12), value: isSelected)
            }
        }
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private var liveQuickGuideWindow: [LiveTVChannel] {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return [] }
        let center = min(max(liveQuickGuideIndex, 0), channels.count - 1)
        let start = max(0, center - 3)
        let end = min(channels.count, start + 7)
        return Array(channels[start..<end])
    }

    private func liveQuickGuideLogo(_ channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16).fill(Color.black.opacity(0.28))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 30, weight: .black)) }
                }
                .padding(12)
            } else {
                Text(channel.logo).font(.system(size: 30, weight: .black))
            }
        }
        .frame(width: 150, height: 88)
    }

    private func syncLiveQuickGuideIndexToCurrentChannel() {
        liveQuickGuideModel.loadCachedOrDemo()
        let channels = liveQuickGuideChannels
        if let idx = channels.firstIndex(where: { $0.name == item.title || "live-\($0.id)-\($0.streamURL.hashValue)" == item.id }) {
            liveQuickGuideIndex = idx
        } else if liveQuickGuideIndex >= channels.count {
            liveQuickGuideIndex = max(0, channels.count - 1)
        }
    }

    private func moveLiveQuickGuide(_ delta: Int) {
        let channels = liveQuickGuideChannels
        guard !channels.isEmpty else { return }
        liveQuickGuideIndex = min(max(liveQuickGuideIndex + delta, 0), channels.count - 1)
    }

    private func playLiveQuickGuideSelection() {
        guard let channel = liveQuickGuideSelectedChannel, let playURL = URL(string: channel.streamURL), !channel.streamURL.isEmpty else { return }
        liveQuickGuideVisible = false
        store.startPlayback(
            item: MediaItem(id: "live-\(channel.id)-\(channel.streamURL.hashValue)", title: channel.name, year: "Live", type: "live", catalog: channel.source, description: channel.description, genres: [channel.category, channel.source], rating: "", posterURL: channel.iconURL, landscapeURL: nil, logoURL: nil, previewURL: nil),
            url: playURL,
            alternates: [],
            subtitles: [],
            label: "Live TV direct stream: \(channel.name) • \(channel.source) • \(channel.number) • quick guide selection"
        )
    }

    private func seedVODOverlayFocusIfNeeded() {
        guard controlsVisible else { return }
        guard !didSeedVODOverlayFocus || focusedControl == nil else { return }
        didSeedVODOverlayFocus = true
        if focusedControl == nil || !visiblePlayerControlOrder.contains(focusedControl!) {
            if !visiblePlayerControlOrder.contains(lastKnownControlFocus) { lastKnownControlFocus = .playPause }
            focusedControl = lastKnownControlFocus
        }
    }

    private func activateFocusedPlayerControl() {
        if activePanel != nil {
            activateFocusedPanelOption()
            return
        }
        lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        switch focusedControl ?? lastKnownControlFocus {
        case .resume: playerAction { forceResumeFromSavedPosition() }
        case .back10: playerAction { seekRelative(-30) }
        case .playPause: playerAction { togglePlay() }
        case .forward10: playerAction { seekRelative(30) }
        case .ksplayer: playerAction { switchToKSPlayerEngine(manual: true) }
        case .avplayer: playerAction { switchToAVPlayerEngine(manual: true) }
        case .internalVLC: playerAction { switchToVLCEngine(manual: true) }
        case .audio: playerAction { activePanel = .audio; seedPanelFocus(.audio); forceControlsVisibleForNavigation() }
        case .findAudio: playerAction { findAlternateAudio() }
        case .subtitles: playerAction { activePanel = .subtitles; seedPanelFocus(.subtitles); forceControlsVisibleForNavigation() }
        case .episodes: playerAction { activePanel = .episodes; seedPanelFocus(.episodes); store.status = "Episode selector is wired into the Apple-style VOD overlay and ready for series episode rows."; forceControlsVisibleForNavigation() }
        case .zoom: playerAction { toggleZoom() }
        case .settings: playerAction { activePanel = .settings; seedPanelFocus(.settings); forceControlsVisibleForNavigation() }
        case .infuse: playerAction { openExternal(.infuse) }
        case .vlc: playerAction { openExternal(.vlc) }
        case .senplayer: playerAction { openExternal(.senPlayer) }
        case .close: playerAction { store.closePlayer() }
        }
    }

    private func playerAction(_ action: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastPlayerActionAt > 0.44 else { return }
        lastPlayerActionAt = now
        action()
    }

    private func routePlayerMove(_ direction: MoveCommandDirection) {
        let now = Date().timeIntervalSinceReferenceDate
        let moveDebounce: TimeInterval = activePanel != nil ? 0.42 : (isLivePlayback ? 0.34 : 0.40)
        guard now - lastPlayerMoveAt > moveDebounce else { return }
        lastPlayerMoveAt = now

        // v354 input priority is explicit and ordered:
        // 1) Open chip submenu owns UP/DOWN.
        // 2) Visible Live TV quick guide owns LEFT/RIGHT browsing only; UP/DOWN hides it.
        // 3) Visible chip rail owns LEFT/RIGHT chip movement.
        // 4) UP/DOWN opens quick guide only when no chip submenu is open.
        if let panel = activePanel {
            routePanelMove(direction, panel: panel)
            return
        }

        if liveQuickGuideVisible {
            switch direction {
            case .left:
                moveLiveQuickGuide(-1)
            case .right:
                moveLiveQuickGuide(1)
            case .up, .down:
                withAnimation(.easeOut(duration: 0.16)) { liveQuickGuideVisible = false }
            default:
                break
            }
            return
        }

        if !controlsVisible {
            if isLivePlayback, direction == .up || direction == .down {
                syncLiveQuickGuideIndexToCurrentChannel()
                withAnimation(.easeOut(duration: 0.18)) { liveQuickGuideVisible = true }
            } else if !isLivePlayback {
                switch direction {
                case .left:
                    seekRelative(-30, revealControls: false)
                case .right:
                    seekRelative(30, revealControls: false)
                case .up, .down:
                    ensureVODChipsFocused()
                default:
                    break
                }
            }
            return
        }

        vodOverlayLockedForRemoteNavigation = true
        showControlsWithoutChangingFocus()
        let order = visiblePlayerControlOrder
        let current = focusedControl ?? lastKnownControlFocus
        let idx = order.firstIndex(of: current) ?? 1
        switch direction {
        case .left:
            focusedControl = order[(idx - 1 + order.count) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .right:
            focusedControl = order[(idx + 1) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .up, .down:
            if isLivePlayback {
                syncLiveQuickGuideIndexToCurrentChannel()
                withAnimation(.easeOut(duration: 0.18)) { liveQuickGuideVisible = true }
            } else {
                focusedControl = current
            }
        default:
            break
        }
    }

    private func panelOptionsList(_ panel: PlayerPanel) -> [PlayerPanelOption] {
        switch panel {
        case .audio:
            return [.audioAuto, .audioEnglish, .audioOriginal, .audioNext, .findAlternateAudio] + store.alternateAudioSources.indices.map { PlayerPanelOption.alternateAudio($0) } + [.alternateAudioMinus250, .alternateAudioPlus250, .alternateAudioReset, .alternateAudioClear, .closePanel]
        case .subtitles: return [.subtitlesOff, .subtitlesEnglish, .subtitlesAuto, .subtitlesNext, .closePanel]
        case .episodes: return (1...8).map { PlayerPanelOption.season($0) } + [.episodesOpen, .closePanel]
        case .settings:
            var opts: [PlayerPanelOption] = [.cache5, .cache10, .cacheUnlimited, .frameRateInfo]
            if isLivePlayback { opts += [.liveReloadStream, .liveResyncStream, .liveClearBuffer, .liveStreamDiagnostics] }
            opts += [.settingsDiagnostics, .settingsFindAudio, .settingsInfuse, .settingsVLC, .settingsSenPlayer, .closePanel]
            return opts
        }
    }

    private func seedPanelFocus(_ panel: PlayerPanel) {
        let first = panelOptionsList(panel).first
        selectedPanelOption = first
        focusedPanelOption = first
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            selectedPanelOption = first
            focusedPanelOption = first
        }
    }

    private func routePanelMove(_ direction: MoveCommandDirection, panel: PlayerPanel) {
        let options = panelOptionsList(panel)
        guard !options.isEmpty else { return }
        let current = selectedPanelOption ?? focusedPanelOption ?? options[0]
        let idx = options.firstIndex(of: current) ?? 0
        let next: PlayerPanelOption
        switch direction {
        case .up:
            next = options[max(0, idx - 1)]
        case .down:
            next = options[min(options.count - 1, idx + 1)]
        case .left, .right:
            // While a chip submenu is open, UP/DOWN moves inside that submenu only.
            // LEFT/RIGHT are reserved for the bottom VOD chip rail before a submenu opens.
            return
        default:
            return
        }
        selectedPanelOption = next
        focusedPanelOption = next
    }

    private func activateFocusedPanelOption() {
        guard let panel = activePanel else { return }
        let option = selectedPanelOption ?? focusedPanelOption ?? panelOptionsList(panel).first
        switch option {
        case .audioAuto:
            selectedAudioMode = "Auto"; selectAudioOverlayOption("Auto / English preferred")
        case .audioEnglish:
            selectedAudioMode = "English"; selectAudioOverlayOption("English")
        case .audioOriginal:
            selectedAudioMode = "Original"; selectAudioOverlayOption("Original")
        case .audioNext:
            selectedAudioMode = "Next"; cycleMedia(groupCharacteristic: .audible, label: "audio")
        case .findAlternateAudio:
            findAlternateAudio()
        case .alternateAudio(let index):
            guard store.alternateAudioSources.indices.contains(index) else { return }
            selectedAlternateAudioIndex = index
            selectedAudioMode = "Alt"
            store.selectAlternateAudioSource(store.alternateAudioSources[index], for: item)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioMinus250:
            store.adjustAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource, deltaMS: -250)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioPlus250:
            store.adjustAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource, deltaMS: 250)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioReset:
            store.resetAlternateAudioSyncOffset(for: item, source: store.selectedAlternateAudioSource)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .alternateAudioClear:
            selectedAlternateAudioIndex = nil
            selectedAudioMode = "Auto"
            store.selectAlternateAudioSource(nil, for: item)
            applyAlternateAudioSelection()
            showControlsWithoutChangingFocus()
        case .subtitlesOff:
            selectedSubtitleMode = "Off"; selectSubtitleOverlayOption("Off")
        case .subtitlesEnglish:
            selectedSubtitleMode = "English"; selectSubtitleOverlayOption("English")
        case .subtitlesAuto:
            selectedSubtitleMode = "Auto"; selectSubtitleOverlayOption("Auto")
        case .subtitlesNext:
            selectedSubtitleMode = "Next"; cycleMedia(groupCharacteristic: .legible, label: "subtitle")
        case .season(let season):
            selectedEpisodeSeason = season
            store.status = "Selected Season \(season). Episode rows should filter to this season only."
            showControlsWithoutChangingFocus()
        case .episodesOpen:
            store.status = "Episode selector opened for Season \(selectedEpisodeSeason)."
            showControlsWithoutChangingFocus()
        case .cache5:
            vodCacheLimitGB = 5; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to 5GB while playback continues."
        case .cache10:
            vodCacheLimitGB = 10; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to 10GB while playback continues."
        case .cacheUnlimited:
            vodCacheLimitGB = -1; selectedPlaybackMode = forceKSPlayerSurface ? "KS Direct" : "VLC Internal"; cacheSession.start(originURL: url, limitGB: vodCacheLimitGB); store.status = "VOD cache set to Unlimited while playback continues."
        case .frameRateInfo:
            store.status = "Frame-rate matching remains controlled by tvOS/player output; playback is not restarted."
        case .liveReloadStream:
            reloadCurrentLiveStream(reason: "Manual reload chip")
        case .liveResyncStream:
            resyncCurrentLiveStream()
        case .liveClearBuffer:
            clearLiveBufferAndHoldOffset()
        case .liveStreamDiagnostics:
            vodPlaybackDiagnosticsEnabled = true
            playbackNotice = "Stream diagnostics • \(remuxStreamModeLabel) • URL: \(url.absoluteString.prefix(80))"
            store.status = "Stream diagnostics enabled. Source mode: \(remuxStreamModeLabel). If CBS/TVE drifts, use Resync or Reload Stream."
            showControlsWithoutChangingFocus()
        case .settingsDiagnostics:
            vodPlaybackDiagnosticsEnabled.toggle()
            store.status = vodPlaybackDiagnosticsEnabled ? "Playback diagnostics enabled in Settings." : "Playback diagnostics hidden by default."
            showControlsWithoutChangingFocus()
        case .settingsFindAudio:
            findAlternateAudio()
        case .settingsInfuse:
            openExternal(.infuse)
        case .settingsVLC:
            openExternal(.vlc)
        case .settingsSenPlayer:
            openExternal(.senPlayer)
        case .closePanel, .none:
            selectedPanelOption = nil
            focusedPanelOption = nil
            activePanel = nil
            showControlsWithoutChangingFocus()
        }
    }

    @ViewBuilder
    private func panelOptions(_ panel: PlayerPanel) -> some View {
        switch panel {
        case .audio:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: selectedAudioMode == "Auto" ? "✓ Auto / English preferred" : "Auto / English preferred", selected: (selectedPanelOption ?? focusedPanelOption) == .audioAuto, focus: .audioAuto, focused: $focusedPanelOption) { focusedPanelOption = .audioAuto; selectedPanelOption = .audioAuto; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedAudioMode == "English" ? "✓ English" : "English", selected: (selectedPanelOption ?? focusedPanelOption) == .audioEnglish, focus: .audioEnglish, focused: $focusedPanelOption) { focusedPanelOption = .audioEnglish; selectedPanelOption = .audioEnglish; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedAudioMode == "Original" ? "✓ Original" : "Original", selected: (selectedPanelOption ?? focusedPanelOption) == .audioOriginal, focus: .audioOriginal, focused: $focusedPanelOption) { focusedPanelOption = .audioOriginal; selectedPanelOption = .audioOriginal; activateFocusedPanelOption() }
                PanelOptionChip(title: "Next available track", selected: (selectedPanelOption ?? focusedPanelOption) == .audioNext, focus: .audioNext, focused: $focusedPanelOption) { focusedPanelOption = .audioNext; selectedPanelOption = .audioNext; activateFocusedPanelOption() }
                PanelOptionChip(title: isFindingAlternateAudio ? "Scanning other copies…" : "Find English audio from another copy", selected: (selectedPanelOption ?? focusedPanelOption) == .findAlternateAudio, focus: .findAlternateAudio, focused: $focusedPanelOption) { focusedPanelOption = .findAlternateAudio; selectedPanelOption = .findAlternateAudio; activateFocusedPanelOption() }
                if !store.alternateAudioSources.isEmpty {
                    Text("Alternate audio candidates")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.58))
                        .padding(.top, 8)
                    ForEach(Array(store.alternateAudioSources.enumerated()), id: \.offset) { index, source in
                        PanelOptionChip(title: (selectedAlternateAudioIndex == index ? "✓ " : "") + source.displayTitle + " • " + source.confidence, selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudio(index), focus: .alternateAudio(index), focused: $focusedPanelOption) {
                            focusedPanelOption = .alternateAudio(index)
                            selectedPanelOption = .alternateAudio(index)
                            activateFocusedPanelOption()
                        }
                    }
                    Text("Sync offset: \(store.alternateAudioSyncOffsetMS)ms")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.66))
                        .padding(.top, 8)
                    HStack(spacing: 8) {
                        PanelOptionChip(title: "−250ms", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioMinus250, focus: .alternateAudioMinus250, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioMinus250; selectedPanelOption = .alternateAudioMinus250; activateFocusedPanelOption() }
                        PanelOptionChip(title: "+250ms", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioPlus250, focus: .alternateAudioPlus250, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioPlus250; selectedPanelOption = .alternateAudioPlus250; activateFocusedPanelOption() }
                        PanelOptionChip(title: "Reset", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioReset, focus: .alternateAudioReset, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioReset; selectedPanelOption = .alternateAudioReset; activateFocusedPanelOption() }
                    }
                    PanelOptionChip(title: "Clear alternate audio", selected: (selectedPanelOption ?? focusedPanelOption) == .alternateAudioClear, focus: .alternateAudioClear, focused: $focusedPanelOption) { focusedPanelOption = .alternateAudioClear; selectedPanelOption = .alternateAudioClear; activateFocusedPanelOption() }
                }
            }
        case .subtitles:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: selectedSubtitleMode == "Off" ? "✓ Off" : "Off", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesOff, focus: .subtitlesOff, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesOff; selectedPanelOption = .subtitlesOff; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedSubtitleMode == "English" ? "✓ English" : "English", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesEnglish, focus: .subtitlesEnglish, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesEnglish; selectedPanelOption = .subtitlesEnglish; activateFocusedPanelOption() }
                PanelOptionChip(title: selectedSubtitleMode == "Auto" ? "✓ Auto" : "Auto", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesAuto, focus: .subtitlesAuto, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesAuto; selectedPanelOption = .subtitlesAuto; activateFocusedPanelOption() }
                PanelOptionChip(title: "Next available track", selected: (selectedPanelOption ?? focusedPanelOption) == .subtitlesNext, focus: .subtitlesNext, focused: $focusedPanelOption) { focusedPanelOption = .subtitlesNext; selectedPanelOption = .subtitlesNext; activateFocusedPanelOption() }
            }
        case .episodes:
            VStack(alignment: .leading, spacing: 10) {
                Text("Season")
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.60))
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(1...8, id: \.self) { season in
                        PanelOptionChip(title: selectedEpisodeSeason == season ? "✓ S\(season)" : "S\(season)", selected: (selectedPanelOption ?? focusedPanelOption) == .season(season), focus: .season(season), focused: $focusedPanelOption) {
                            focusedPanelOption = .season(season)
                            selectedPanelOption = .season(season)
                            activateFocusedPanelOption()
                        }
                    }
                }
                PanelOptionChip(title: "Open full episode selector", selected: (selectedPanelOption ?? focusedPanelOption) == .episodesOpen, focus: .episodesOpen, focused: $focusedPanelOption) { focusedPanelOption = .episodesOpen; selectedPanelOption = .episodesOpen; activateFocusedPanelOption() }
            }
        case .settings:
            VStack(alignment: .leading, spacing: 10) {
                PanelOptionChip(title: vodCacheLimitGB == 5 ? "✓ Cache: 5GB" : "Cache: 5GB", selected: (selectedPanelOption ?? focusedPanelOption) == .cache5, focus: .cache5, focused: $focusedPanelOption) { focusedPanelOption = .cache5; selectedPanelOption = .cache5; activateFocusedPanelOption() }
                PanelOptionChip(title: vodCacheLimitGB == 10 ? "✓ Cache: 10GB" : "Cache: 10GB", selected: (selectedPanelOption ?? focusedPanelOption) == .cache10, focus: .cache10, focused: $focusedPanelOption) { focusedPanelOption = .cache10; selectedPanelOption = .cache10; activateFocusedPanelOption() }
                PanelOptionChip(title: vodCacheLimitGB < 0 ? "✓ Cache: Unlimited" : "Cache: Unlimited", selected: (selectedPanelOption ?? focusedPanelOption) == .cacheUnlimited, focus: .cacheUnlimited, focused: $focusedPanelOption) { focusedPanelOption = .cacheUnlimited; selectedPanelOption = .cacheUnlimited; activateFocusedPanelOption() }
                PanelOptionChip(title: "Frame-rate matching: tvOS setting", selected: (selectedPanelOption ?? focusedPanelOption) == .frameRateInfo, focus: .frameRateInfo, focused: $focusedPanelOption) { focusedPanelOption = .frameRateInfo; selectedPanelOption = .frameRateInfo; activateFocusedPanelOption() }
                if isLivePlayback {
                    PanelOptionChip(title: "Reload Stream", selected: (selectedPanelOption ?? focusedPanelOption) == .liveReloadStream, focus: .liveReloadStream, focused: $focusedPanelOption) { focusedPanelOption = .liveReloadStream; selectedPanelOption = .liveReloadStream; activateFocusedPanelOption() }
                    PanelOptionChip(title: "Resync Audio/Video", selected: (selectedPanelOption ?? focusedPanelOption) == .liveResyncStream, focus: .liveResyncStream, focused: $focusedPanelOption) { focusedPanelOption = .liveResyncStream; selectedPanelOption = .liveResyncStream; activateFocusedPanelOption() }
                    PanelOptionChip(title: "Clear Live Buffer", selected: (selectedPanelOption ?? focusedPanelOption) == .liveClearBuffer, focus: .liveClearBuffer, focused: $focusedPanelOption) { focusedPanelOption = .liveClearBuffer; selectedPanelOption = .liveClearBuffer; activateFocusedPanelOption() }
                    PanelOptionChip(title: "Stream Diagnostics", selected: (selectedPanelOption ?? focusedPanelOption) == .liveStreamDiagnostics, focus: .liveStreamDiagnostics, focused: $focusedPanelOption) { focusedPanelOption = .liveStreamDiagnostics; selectedPanelOption = .liveStreamDiagnostics; activateFocusedPanelOption() }
                }
                PanelOptionChip(title: vodPlaybackDiagnosticsEnabled ? "✓ Playback diagnostics: On" : "Playback diagnostics: Off", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsDiagnostics, focus: .settingsDiagnostics, focused: $focusedPanelOption) { focusedPanelOption = .settingsDiagnostics; selectedPanelOption = .settingsDiagnostics; activateFocusedPanelOption() }
                PanelOptionChip(title: isFindingAlternateAudio ? "Finding English Audio…" : "Find English Audio", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsFindAudio, focus: .settingsFindAudio, focused: $focusedPanelOption) { focusedPanelOption = .settingsFindAudio; selectedPanelOption = .settingsFindAudio; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in Infuse", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsInfuse, focus: .settingsInfuse, focused: $focusedPanelOption) { focusedPanelOption = .settingsInfuse; selectedPanelOption = .settingsInfuse; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in VLC App", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsVLC, focus: .settingsVLC, focused: $focusedPanelOption) { focusedPanelOption = .settingsVLC; selectedPanelOption = .settingsVLC; activateFocusedPanelOption() }
                PanelOptionChip(title: "Open in Sen", selected: (selectedPanelOption ?? focusedPanelOption) == .settingsSenPlayer, focus: .settingsSenPlayer, focused: $focusedPanelOption) { focusedPanelOption = .settingsSenPlayer; selectedPanelOption = .settingsSenPlayer; activateFocusedPanelOption() }
            }
        }
    }

    private func panelTitle(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio: return "Audio Tracks"
        case .subtitles: return "Subtitles"
        case .episodes: return "Episodes"
        case .settings: return "Playback Settings"
        }
    }

    private func panelDetail(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio:
            return "Smart Alternate Audio v1 can scan other playable copies for likely English audio, keep this video source active, and save manual sync offsets per title/source. KSPlayer remains the primary surface; v1 stores and routes the selected alternate audio reference without replacing the main video URL."
        case .subtitles:
            return "Stremio subtitle URLs are captured for the overlay parser path. Subtitles default off and can be enabled from the Debrid overlay when supported by the active engine."
        case .episodes:
            return "Season selector is available from the TV show detail page; the VOD overlay keeps the Episodes button selectable for quick series navigation while playback remains active."
        case .settings:
            return "Engines: KSPlayer clean video surface is primary, VLC Internal is selectable fallback, and external Infuse/VLC/SenPlayer handoff remains available. v261 keeps KSPlayer direct-start VOD, background cache warming, and no-snap focus-boundary selectable controls, reinforces English audio preference, and moves media information right/down while preserving smooth v154 cadence settings. English audio is enforced where tracks expose language metadata and subtitles default off. Cache limit: \(cacheLimitLabel). Current profile: \(nativeProfileText.isEmpty ? "pending" : nativeProfileText)."
        }
    }


    private var isLikelyChannelsDVRRemuxStream: Bool {
        let lowerURL = url.absoluteString.lowercased()
        let lowerLabel = store.playbackLinkLabel.lowercased()
        return lowerURL.contains("/devices/") || lowerURL.contains("channels.m3u") || lowerURL.contains("/hls/") || lowerURL.contains("/dvr/") || lowerLabel.contains("channels dvr") || lowerLabel.contains("tve") || lowerLabel.contains("verizon")
    }

    private var remuxStreamModeLabel: String {
        isLikelyChannelsDVRRemuxStream ? "Remuxed HLS / Channels DVR M3U" : "Standard stream"
    }

    private func reloadCurrentLiveStream(reason: String = "Manual reload") {
        guard isLivePlayback else {
            store.status = "Reload Stream is available for Live TV only."
            return
        }
        retryText = "Reloading live stream…"
        playbackNotice = "\(reason) • flushing live buffer • \(remuxStreamModeLabel)"
        store.status = "Live TV reload: \(reason). Re-opening the current stream without changing channel."
        vlcSurfaceToken += 1
        setupPlayer()
        showControlsWithoutChangingFocus()
    }

    private func resyncCurrentLiveStream() {
        guard isLivePlayback else {
            store.status = "Resync is available for Live TV only."
            return
        }
        playbackNotice = "A/V resync requested • \(remuxStreamModeLabel)"
        store.status = "A/V resync: flushing and re-opening this live stream. Use this for TVE ad-break drift or stale video with newer audio."
        vlcSurfaceToken += 1
        setupPlayer()
        showControlsWithoutChangingFocus()
    }

    private func clearLiveBufferAndHoldOffset() {
        guard isLivePlayback else {
            store.status = "Clear Buffer is available for Live TV only."
            return
        }
        playbackNotice = "Live buffer cleared • using safer remux/live-edge offset • \(remuxStreamModeLabel)"
        store.status = "Live buffer cleared. Remuxed Channels DVR M3U streams should sit a few segments behind live edge for fewer CBS/TVE ad-sync glitches."
        vlcSurfaceToken += 1
        setupPlayer()
        showControlsWithoutChangingFocus()
    }

    private func currentPlaybackDiagnostics() -> DebridPlaybackDiagnostics {
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        let engine = activeEngineName
        var diag = DebridPlaybackDiagnosticsFactory.make(engine: engine, profile: profile, controlsVisible: controlsVisible, isPlaying: isPlaying)
        if isLoading {
            diag.fps = "Loading"
            diag.droppedFrames = "Pending"
        }
        if !playbackNotice.isEmpty {
            diag.notes = isLivePlayback ? "\(playbackNotice) • Source mode: \(remuxStreamModeLabel)" : playbackNotice
        } else if isLivePlayback {
            diag.notes = "Source mode: \(remuxStreamModeLabel)"
        }
        _ = diagnosticsTick
        return diag
    }

    private func startDiagnosticsPulse() {
        Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                diagnosticsTick &+= 1
            }
        }
    }

    private func findAlternateAudio() {
        guard !isLivePlayback else {
            store.status = "Alternate audio search is for Movies/Shows only. Live TV keeps the channel stream audio."
            return
        }
        isFindingAlternateAudio = true
        activePanel = .audio
        forceControlsVisibleForNavigation()
        Task { @MainActor in
            let candidates = await store.findAlternateAudioSources(for: item, currentURL: url, preferredLanguage: "English")
            isFindingAlternateAudio = false
            selectedPanelOption = candidates.isEmpty ? .findAlternateAudio : .alternateAudio(0)
            focusedPanelOption = selectedPanelOption
        }
    }

    private func applyAlternateAudioSelection() {
        if let source = store.selectedAlternateAudioSource {
            playbackNotice = "Smart Alternate Audio v1 selected • \(source.displayTitle) • sync \(store.alternateAudioSyncOffsetMS)ms"
            store.status = "Smart Alternate Audio v1: keeping current video source and tracking audio from \(source.displayTitle). Manual sync offset is \(store.alternateAudioSyncOffsetMS)ms."
        } else {
            playbackNotice = "Alternate audio cleared; using selected stream audio."
            store.status = playbackNotice
        }
        vlcSurfaceToken += 1
        showControlsWithoutChangingFocus()
    }

    private func setupPlayer() {
        // v127: AVPlayer remains removed from the VOD decision path.
        // Internal playback uses KSPlayer primary and TVVLCKit/libVLC fallback under the same Debrid overlay.
        nativePrepareTask?.cancel()
        startupLoadingTask?.cancel()
        automaticResumeTask?.cancel()
        renderWatchdogTask?.cancel()
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        player?.pause()
        player = nil

        forceVLCSurface = false
        forceKSPlayerSurface = true
        avRetryAttemptedForCurrentURL = false
        isLoading = true
        errorText = nil
        retryText = "Preparing player…"
        focusedControl = .playPause
        preparedPlaybackURL = nil
        vodBootstrapDeadline = nil
        pendingAutomaticResumeSeconds = nil
        didApplyAutomaticResumeSeek = false
        ksSeekIsAbsolute = false
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        if isLivePlayback {
            cacheSession.stopAndDelete()
            preparedPlaybackURL = url
            currentSeconds = 0
            durationSeconds = 0
            retryText = "Starting Live TV…"
        } else {
            // Always reset the visible VOD clock on a fresh stream. Resume must be an actual
            // player seek, not a leftover progress label from the previous playback session.
            currentSeconds = 0
            applyAutomaticResumeIfAvailable()
            let resumeStartupText = retryText
            // v253: restore the v163 VOD path that worked before Live TV was added:
            // the video surface always receives cacheSession.playbackURL ?? origin URL,
            // cache warms for the whole watch session, and playback starts immediately.
            preparedPlaybackURL = url
            if resumeStartupText == nil || resumeStartupText == "Preparing player…" { retryText = "Opening stream immediately… cache warming…" }
            cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
        }
        nativeProfileText = profile.diagnostic
        if metadataRuntimeSeconds <= 0 { metadataRuntimeSeconds = runtimeSeconds(for: item) }
        currentSeconds = max(currentSeconds, 0)
        startPlayerClock()
        startRuntimeMetadataLookupIfNeeded()

        if isLivePlayback {
            // v347: Live TV full playback now uses KSPlayer as the default route.
            // The guide preview also uses KSPlayer, but it is suppressed before opening full playback
            // so the preview surface cannot create double audio.
            liveQuickGuideModel.loadCachedOrDemo()
            controlsVisible = false
            liveQuickGuideVisible = false
            forceKSPlayerSurface = true
            forceVLCSurface = false
        }

        if !isLivePlayback, let externalTarget = defaultExternalTargetForCurrentItem() {
            isLoading = false
            forceControlsVisibleForNavigation()
            playbackNotice = "Opening in \(externalTarget.rawValue) by default from Settings."
            store.status = "External player default enabled for \(item.type): opening \(item.title) in \(externalTarget.rawValue)."
            ExternalPlayerLauncher.open(externalTarget, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
                store.status = message
            }
            return
        }

        if isLivePlayback {
            if liveTVUseAVPlayerDefault {
                switchToAVPlayerEngine(manual: false)
                playbackNotice = "AVPlayer Live TV selected from Settings • auto-falls back to KSPlayer if this stream rejects AVPlayer."
                store.status = "Live TV playback: AVPlayer default is enabled; fallback to KSPlayer is automatic on AVPlayer failure."
                return
            }
            #if canImport(KSPlayer)
            forceKSPlayerSurface = true
            forceVLCSurface = false
            isPlaying = true
            vlcSurfaceToken += 1
            armStartupLoadingGate(engine: "KSPlayer Live TV")
            playbackNotice = "KSPlayer Live TV direct-start • remux-aware mode: \(remuxStreamModeLabel) • quick guide available with UP/DOWN • \(profile.diagnostic)"
            store.status = "V354 Live TV playback: KSPlayer remains default; quick guide opens with Up/Down, browses ONLY with Left/Right, and chip panels keep Up/Down."
            return
            #elseif canImport(TVVLCKit)
            forceKSPlayerSurface = false
            forceVLCSurface = true
            isPlaying = true
            vlcSurfaceToken += 1
            armStartupLoadingGate(engine: "VLC Live TV fallback")
            playbackNotice = "VLC Live TV fallback • KSPlayer missing • quick guide available with UP/DOWN • \(profile.diagnostic)"
            store.status = "V354 Live TV playback: VLC fallback because KSPlayer was not compiled."
            return
            #else
            isPlaying = false
            forceControlsVisibleForNavigation()
            playbackNotice = "No internal Live TV engine compiled."
            errorText = "Live TV playback needs KSPlayer compiled into the IPA."
            store.status = playbackNotice
            return
            #endif
        }

        #if canImport(KSPlayer)
        // v259: restore KSPlayer as the default VOD engine. Start the resolved HTTP(S) stream
        // immediately, while the temporary VOD cache downloads in the background.
        forceKSPlayerSurface = true
        forceVLCSurface = false
        isPlaying = true
        vlcSurfaceToken += 1
        armStartupLoadingGate(engine: "KSPlayer")
        scheduleAutomaticResumeAfterSurfaceStart()
        playbackNotice = "KSPlayer direct-start • cache warming in background • English audio preferred • subtitles off • \(profile.diagnostic)"
        store.status = "V261 VOD playback: KSPlayer direct stream starts immediately; temp cache warms silently and never interrupts the visible player."
        #elseif canImport(TVVLCKit)
        forceKSPlayerSurface = false
        forceVLCSurface = true
        isPlaying = true
        vlcSurfaceToken += 1
        armStartupLoadingGate(engine: "VLC Internal")
        scheduleAutomaticResumeAfterSurfaceStart()
        playbackNotice = "VLC Internal fallback • KSPlayer missing • \(profile.diagnostic)"
        store.status = isLivePlayback ? "V261 Live TV playback: VLC fallback direct path." : "V261 VOD playback: VLC fallback because KSPlayer was not compiled."
        #else
        isPlaying = false
        forceControlsVisibleForNavigation()
        playbackNotice = "KSPlayer and TVVLCKit are not compiled into this IPA. External players remain available."
        errorText = "Internal playback needs KSPlayer Raw Layer/FFmpeg or TVVLCKit/libVLC compiled into the IPA. Use external Infuse/VLC/SenPlayer until an internal engine is present."
        store.status = playbackNotice
        #endif
    }

    private func armVODPlaybackIfReady() {
        guard !isLivePlayback else { return }
        let alreadyPlayingOrigin = preparedPlaybackURL == url
        guard preparedPlaybackURL == nil || alreadyPlayingOrigin else { return }
        guard let candidate = cacheSession.playbackURL else {
            retryText = alreadyPlayingOrigin ? "Playback started; cache warming…" : "Starting VOD cache…"
            return
        }

        let isBypass = candidate == url
        let hasEnoughBuffered = cacheSession.cachedBytes >= vodStartThresholdBytes
        let completedSmallFile = cacheSession.totalBytes.map { $0 > 0 && cacheSession.cachedBytes >= min($0, vodStartThresholdBytes) } ?? false
        let deadlineReached = vodBootstrapDeadline.map { Date() >= $0 } ?? false

        guard isBypass || hasEnoughBuffered || completedSmallFile || deadlineReached else {
            let mb = Double(cacheSession.cachedBytes) / 1_048_576.0
            retryText = String(format: "Playback started; cache warming %.1fMB…", mb)
            return
        }

        if preparedPlaybackURL != candidate { preparedPlaybackURL = candidate }
        isPlaying = true
        retryText = "Starting playback…"
        vlcSurfaceToken += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) {
            if errorText == nil { isLoading = false }
        }
        store.status = isBypass
            ? "V198 VOD bootstrap: stream autostarted immediately while cache warms."
            : "V198 VOD bootstrap: cache-backed playback autostarted with direct-start fallback."
    }

    private func startNativeLivePlaybackDirect(url: URL, profile: NativePlaybackProfile) {
        nativePrepareTask?.cancel()
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 LiveTV",
            "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"
        ]
        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = profile.isHLS ? 8 : 15
        let av = AVPlayer(playerItem: item)
        av.automaticallyWaitsToMinimizeStalling = true
        av.preventsDisplaySleepDuringVideoPlayback = true
        player = av
        preparedPlaybackURL = url
        isLoading = false
        errorText = nil
        attachNativePlayerObservers(item: item, player: av)
        av.play()
    }

    private func prepareNativeAssetAndStart(url: URL, profile: NativePlaybackProfile) {
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 KSPlayer/VLC",
            "Accept": "video/mp4,video/quicktime,application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Range": "bytes=0-"
        ]
        let options: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": headers]
        let asset = AVURLAsset(url: url, options: options)

        nativePrepareTask = Task { @MainActor in
            do {
                // Load the real AVFoundation properties before making the visible player.
                // If these fail, AVPlayer would usually become audio-only/black or stutter.
                let playable = try await asset.load(.isPlayable)
                let tracks = try await asset.load(.tracks)
                let duration = try? await asset.load(.duration)
                let mediaCharacteristics = try? await asset.load(.availableMediaCharacteristicsWithMediaSelectionOptions)
                let videoTracks = tracks.filter { $0.mediaType == .video }
                let audioTracks = tracks.filter { $0.mediaType == .audio }

                guard !Task.isCancelled else { return }
                guard playable else {
                    handleNativePreparationFailure("AVPlayer rejected this asset as not playable before render.")
                    return
                }
                if videoTracks.isEmpty && !profile.isAppleContainer && !profile.isNativeDolbyVisionPreferred {
                    let audioCount = audioTracks.count
                    handleNativePreparationFailure("AVPlayer only exposed audio tracks (\(audioCount)) and no video track before render for \(profile.diagnostic).")
                    return
                }

                let itemAsset = AVPlayerItem(asset: asset)
                itemAsset.preferredForwardBufferDuration = profile.isHLS ? 60 : 180
                itemAsset.canUseNetworkResourcesForLiveStreamingWhilePaused = true
                itemAsset.preferredPeakBitRate = 0
                itemAsset.preferredMaximumResolution = CGSize(width: 4096, height: 2160)
                itemAsset.seekingWaitsForVideoCompositionRendering = true

                let av = AVPlayer(playerItem: itemAsset)
                av.appliesMediaSelectionCriteriaAutomatically = true
                av.automaticallyWaitsToMinimizeStalling = true
                av.preventsDisplaySleepDuringVideoPlayback = true
                av.allowsExternalPlayback = false

                player = av
                let durationText = duration.map { CMTimeGetSeconds($0).isFinite ? "duration \(Int(CMTimeGetSeconds($0)))s" : "duration live/unknown" } ?? "duration pending"
                let characteristicsText = mediaCharacteristics?.map { $0.rawValue }.joined(separator: ",") ?? "characteristics pending"
                playbackNotice = "AVPlayer ready • \(profile.diagnostic) • \(videoTracks.count) video track(s) • no bitrate cap • 4K/DV native path."
                store.status = "AVPlayer validation passed: \(videoTracks.count) video track(s), \(audioTracks.count) audio track(s), \(durationText), \(characteristicsText). Starting hardware playback path."
                attachNativePlayerObservers(item: itemAsset, player: av)
                av.play()
                isPlaying = true
            } catch {
                guard !Task.isCancelled else { return }
                handleNativePreparationFailure("AVPlayer asset preparation failed for \(profile.diagnostic): \(error.localizedDescription)")
            }
        }
    }

    private func handleNativePreparationFailure(_ message: String) {
        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface {
            retryText = "AVPlayer rejected this Live TV stream; falling back to KSPlayer…"
            errorText = nil
            store.status = "AVPlayer Live TV preparation failed: \(message). Falling back to KSPlayer."
            switchToKSPlayerEngine(manual: false)
            return
        }
        isLoading = false
        forceControlsVisibleForNavigation()
        store.status = message
        #if canImport(TVVLCKit)
        if UniversalCodecSupport.vlcCompiledIn {
            retryText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            errorText = message + "\n\nInternal playback uses KSPlayer primary and VLC fallback; use external Infuse if needed."
        } else {
            errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        }
        #else
        errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        #endif
    }

    private func attachNativePlayerObservers(item itemAsset: AVPlayerItem, player av: AVPlayer) {
        statusObserver = itemAsset.observe(\.status, options: [.new, .initial]) { observedItem, _ in
            DispatchQueue.main.async {
                switch observedItem.status {
                case .readyToPlay:
                    isLoading = false
                    let readyDuration = CMTimeGetSeconds(observedItem.duration)
                    if readyDuration.isFinite && readyDuration > 1 { durationSeconds = readyDuration }
                    let dimensions = observedItem.presentationSize
                    let event = observedItem.accessLog()?.events.last
                    let bitrateText = event.map { "observed \(Int($0.observedBitrate))bps / indicated \(Int($0.indicatedBitrate))bps" } ?? "bitrate pending"
                    let sizeText = dimensions.width > 8 ? "\(Int(dimensions.width))×\(Int(dimensions.height))" : "video size pending"
                    playbackNotice = "VLC Internal playing • \(nativeProfileText) • \(sizeText) • \(bitrateText)"
                    store.status = "Playback route: \(activeEngineName); \(nativeProfileText); video size \(sizeText); \(bitrateText); selected \(store.playbackLinkLabel)"
                    av.play()
                    isPlaying = true
                    startRenderWatchdog(for: observedItem, player: av)
                    scheduleAutoHide()
                case .failed:
                    isLoading = false
                    let message = observedItem.error?.localizedDescription ?? "The selected stream could not be played."
                    if let next = store.advanceToNextPlaybackURL(after: url) {
                        retryText = "Stream failed; retrying next source…"
                        errorText = nil
                        store.status = "Playback failed on one source: \(message). Retrying \(next.absoluteString.prefix(80))…"
                    } else {
                        if isLivePlayback && !forceKSPlayerSurface && !forceVLCSurface {
                            retryText = "AVPlayer stopped on this Live TV stream; falling back to KSPlayer…"
                            errorText = nil
                            store.status = "AVPlayer Live TV failed: \(message). Falling back to KSPlayer without closing playback."
                            switchToKSPlayerEngine(manual: false)
                            return
                        }
                        forceControlsVisibleForNavigation()
                        errorText = message + "\nEngine: \(activeEngineName). Playback failed after validated setup; try KSPlayer, VLC Internal, or external Infuse/VLC/SenPlayer for this stream."
                    }
                default:
                    break
                }
            }
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1.25, preferredTimescale: 600), queue: .main) { time in
            if !forceVLCSurface {
                currentSeconds = CMTimeGetSeconds(time).isFinite ? CMTimeGetSeconds(time) : 0
                saveResumePositionIfNeeded()
            }
                if let duration = av.currentItem?.duration {
                let seconds = CMTimeGetSeconds(duration)
                if seconds.isFinite && seconds > 1 { durationSeconds = seconds }
            }
            if !forceVLCSurface { isPlaying = av.timeControlStatus == .playing }
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: itemAsset, queue: .main) { _ in
            if !isLivePlayback { PlaybackResumeCacheManager.shared.clear(for: item) }
            isPlaying = false
            controlsVisible = true
            focusedControl = .playPause
        }

        if !store.playbackSubtitleURLs.isEmpty {
            store.status = "Captured \(store.playbackSubtitleURLs.count) external subtitle URL(s) from the selected Stremio stream."
        }
    }

    private func teardownPlayer() {
        saveResumePositionIfNeeded(force: true)
        hideTask?.cancel()
        nativePrepareTask?.cancel()
        nativePrepareTask = nil
        renderWatchdogTask?.cancel()
        startupLoadingTask?.cancel()
        startupLoadingTask = nil
        runtimeLookupTask?.cancel()
        runtimeLookupTask = nil
        playbackClockTask?.cancel()
        playbackClockTask = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        player?.pause()
        player = nil
        preparedPlaybackURL = nil
        vodBootstrapDeadline = nil
        pendingAutomaticResumeSeconds = nil
        didApplyAutomaticResumeSeek = false
        cacheSession.stopAndDelete()
    }


    private func applyAutomaticResumeIfAvailable() {
        guard !isLivePlayback, !didAttemptAutomaticResume else { return }
        didAttemptAutomaticResume = true
        guard let saved = PlaybackResumeCacheManager.shared.resumeEntry(for: item) else { return }
        resumeEntry = saved
        pendingAutomaticResumeSeconds = saved.seconds
        didApplyAutomaticResumeSeek = false
        // v505: Do not fake currentSeconds and do not inject KSOptions.startPlayTime at construction.
        // Some KSPlayer/tvOS builds ignore or crash on startup seek, and faking the clock can make
        // cache/progress look broken. Start the visible stream immediately, let the temp cache keep
        // warming, then send the same in-place seek command that the manual Resume chip uses.
        ksStartTimeSeconds = 0
        vlcSeekSeconds = 0
        retryText = "Opening stream… automatic resume queued for \(formatTime(saved.seconds))…"
        playbackNotice = "Automatic resume queued at \(formatTime(saved.seconds)). Backup chip stays available until the player confirms the jump."
        store.status = "Resume playback: \(item.title) will jump to \(formatTime(saved.seconds)) after the player surface is ready."
    }

    private func scheduleAutomaticResumeAfterSurfaceStart() {
        guard !isLivePlayback, let target = pendingAutomaticResumeSeconds, target >= 8, !didApplyAutomaticResumeSeek else { return }
        automaticResumeTask?.cancel()
        automaticResumeTask = Task { @MainActor in
            for delay in [0.70, 1.40, 2.40, 3.80] {
                try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
                guard !Task.isCancelled else { return }
                guard errorText == nil else { continue }
                guard pendingAutomaticResumeSeconds == target, !didApplyAutomaticResumeSeek else { return }
                seekAbsolute(target, directionSeconds: 0, revealControls: false, markAutomaticResume: true)
                didApplyAutomaticResumeSeek = true
                pendingAutomaticResumeSeconds = nil
                retryText = "Resumed from \(formatTime(target)); cache still warming…"
                playbackNotice = "Automatic resume applied at \(formatTime(target)) • cache-ahead remains active."
                store.status = "Automatic resume applied: \(formatTime(target))."
                return
            }
        }
    }

    private func forceResumeFromSavedPosition() {
        guard let saved = resumeEntry else { return }
        seekAbsolute(saved.seconds, directionSeconds: 0, revealControls: true, markAutomaticResume: true)
        didApplyAutomaticResumeSeek = true
        pendingAutomaticResumeSeconds = nil
        isPlaying = true
        liveQuickGuideVisible = false
        playbackNotice = "Manual resume applied at \(formatTime(saved.seconds))."
        store.status = "Manual resume backup: jumped to \(formatTime(saved.seconds))."
    }

    private func saveResumePositionIfNeeded(force: Bool = false) {
        guard !isLivePlayback else { return }
        guard currentSeconds.isFinite, currentSeconds >= 8 else { return }
        if !force, Date().timeIntervalSince(lastResumeSaveAt) < 5 { return }
        lastResumeSaveAt = Date()
        PlaybackResumeCacheManager.shared.saveProgress(item: item, seconds: currentSeconds, duration: resolvedDurationSeconds)
    }

    private func defaultExternalTargetForCurrentItem() -> ExternalPlaybackTarget? {
        let lower = item.type.lowercased()
        let isShow = lower.contains("series") || lower.contains("show") || item.seasonNumber != nil || item.episodeNumber != nil
        if isShow {
            if externalShowsInfuseDefault { return .infuse }
            if externalShowsVLCDefault { return .vlc }
            if externalShowsSenPlayerDefault { return .senPlayer }
        } else {
            if externalMoviesInfuseDefault { return .infuse }
            if externalMoviesVLCDefault { return .vlc }
            if externalMoviesSenPlayerDefault { return .senPlayer }
        }
        return nil
    }

    private func openExternal(_ target: ExternalPlaybackTarget) {
        player?.pause()
        isPlaying = false
        forceControlsVisibleForNavigation()
        ExternalPlayerLauncher.open(target, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
            store.status = message
        }
    }

    private func switchToAVPlayerEngine(manual: Bool) {
        guard isLivePlayback else {
            playbackNotice = "AVPlayer backup is limited to Live TV streams. VOD remains on KSPlayer/VLC."
            store.status = playbackNotice
            forceControlsVisibleForNavigation()
            return
        }
        forceKSPlayerSurface = false
        forceVLCSurface = false
        isPlaying = true
        isLoading = true
        retryText = manual ? "Starting Live TV with AVPlayer…" : "Starting Live TV with AVPlayer default…"
        errorText = nil
        selectedPlaybackMode = "AVPlayer"
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        startNativeLivePlaybackDirect(url: url, profile: profile)
        armStartupLoadingGate(engine: "AVPlayer Live TV")
        playbackNotice = manual ? "AVPlayer Live TV selected manually. If this stream rejects AVPlayer, Debrid Channels will fall back to KSPlayer." : "AVPlayer Live TV default selected. KSPlayer fallback is armed."
        store.status = playbackNotice
        forceControlsVisibleForNavigation()
    }

    private func switchToKSPlayerEngine(manual: Bool) {
        player?.pause()
        forceVLCSurface = false
        forceKSPlayerSurface = true
        isPlaying = true
        isLoading = false
        errorText = nil
        #if canImport(KSPlayer)
        playbackNotice = manual ? "KSPlayer tvOS-Safe Native-First selected manually for this stream." : "KSPlayer tvOS-Safe Native-First selected as primary internal engine."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "KSPlayer is not compiled into this IPA. Staying on VLC Internal fallback."
        store.status = playbackNotice
        switchToVLCEngine(manual: false)
        #endif
    }

    private func switchToVLCEngine(manual: Bool) {
        #if canImport(TVVLCKit)
        player?.pause()
        forceKSPlayerSurface = false
        forceVLCSurface = true
        vlcSurfaceToken += 1
        isPlaying = true
        isLoading = false
        errorText = nil
        playbackNotice = manual ? "VLC Internal selected manually for this stream." : "Switched to VLC Internal fallback."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "VLC Internal is not available in this IPA because TVVLCKit was not compiled in."
        store.status = playbackNotice
        #endif
    }

    private func togglePlay() {
        if forceKSPlayerSurface || forceVLCSurface {
            isPlaying.toggle()
            liveQuickGuideVisible = false
            if isPlaying {
                // v384: when playback is resumed from the Debrid chip rail, keep the overlay stable
                // long enough for the user to continue navigating instead of instantly hiding it.
                forceControlsVisibleForNavigation(lockOverlay: true)
                store.status = "Playback resumed; controls remain available briefly."
            } else {
                forceControlsVisibleForNavigation(lockOverlay: true)
                store.status = "Playback paused; controls remain visible."
            }
            return
        }
        guard let player else { return }
        if player.timeControlStatus == .playing {
            player.pause()
            isPlaying = false
            forceControlsVisibleForNavigation()
        } else {
            player.play()
            isPlaying = true
            forceControlsVisibleForNavigation(lockOverlay: true)
        }
    }

    private func seekRelative(_ seconds: Double, revealControls: Bool = true) {
        let upperBound = resolvedDurationSeconds > 0 ? resolvedDurationSeconds : Double.greatestFiniteMagnitude
        let target = max(0, min(upperBound, currentSeconds + seconds))
        seekAbsolute(target, directionSeconds: seconds, revealControls: revealControls)
    }

    private func seekAbsolute(_ targetSeconds: Double, directionSeconds: Double = 0, revealControls: Bool = true, markAutomaticResume: Bool = false) {
        let upperBound = resolvedDurationSeconds > 0 ? resolvedDurationSeconds : Double.greatestFiniteMagnitude
        let target = max(0, min(upperBound, targetSeconds))
        let relativeDelta = target - currentSeconds
        currentSeconds = target
        if markAutomaticResume {
            lastResumeSaveAt = .distantPast
        }
        saveResumePosition(force: true)

        if forceKSPlayerSurface {
            if markAutomaticResume {
                // v507: resume must be a guaranteed jump, not only a label update.
                // Some KSPlayer builds ignore reflective in-place absolute selectors at startup,
                // so resume uses the proven reload/startPlayTime path while normal FF/RW remains
                // in-place to avoid the black surface regression from v504.
                ksStartTimeSeconds = target
                ksSeekIsAbsolute = true
                vlcSeekSeconds = target
                vlcSeekSerial &+= 1
                vlcSurfaceToken &+= 1
                ksSurfaceToken &+= 1
            } else {
                ksSeekIsAbsolute = false
                vlcSeekSeconds = abs(directionSeconds) > 0.01 ? directionSeconds : relativeDelta
                vlcSeekSerial &+= 1
            }
            isPlaying = true
            store.status = markAutomaticResume ? "Resume seek requested: \(formatTime(target))." : (directionSeconds < 0 ? "Rewind 30 seconds." : "Fast-forward 30 seconds.")
            if revealControls { forceControlsVisibleForNavigation() }
            return
        }

        if forceVLCSurface {
            ksSeekIsAbsolute = false
            vlcSeekSeconds = abs(directionSeconds) > 0.01 ? directionSeconds : relativeDelta
            vlcSeekSerial &+= 1
            store.status = directionSeconds < 0 ? "Rewind 30 seconds." : "Fast-forward 30 seconds."
            if revealControls { forceControlsVisibleForNavigation() }
            return
        }

        guard let player else { return }
        let time = CMTime(seconds: target, preferredTimescale: 600)
        player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
        if revealControls { showControls() }
    }

    private func toggleZoom() {
        videoGravity = videoGravity == .resizeAspect ? .resizeAspectFill : .resizeAspect
        showControls()
    }

    private func selectAudioOverlayOption(_ option: String) {
        activePanel = .audio
        if forceKSPlayerSurface || forceVLCSurface {
            store.status = "Audio option set to \(option). KS/VLC keep the stream playing while the engine applies available track preferences."
            showControls()
            return
        }
        cycleMedia(groupCharacteristic: .audible, label: "audio")
    }

    private func selectSubtitleOverlayOption(_ option: String) {
        activePanel = .subtitles
        if forceKSPlayerSurface || forceVLCSurface {
            store.status = option == "Off" ? "Subtitles set to Off in the Debrid overlay preference." : "Subtitle option set to \(option). The active engine will use the matching embedded/external track when available."
            showControls()
            return
        }
        cycleMedia(groupCharacteristic: .legible, label: "subtitle")
    }

    private func cycleMedia(groupCharacteristic: AVMediaCharacteristic, label: String) {
        guard !forceKSPlayerSurface && !forceVLCSurface else {
            store.status = "\(label.capitalized) default is set by the active internal engine: English audio preferred, subtitles off by default. Full track list UI remains inside the Debrid overlay settings panel."
            showControls()
            return
        }
        guard let item = player?.currentItem, let group = item.asset.mediaSelectionGroup(forMediaCharacteristic: groupCharacteristic) else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let options = group.options
        guard !options.isEmpty else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let current = item.currentMediaSelection.selectedMediaOption(in: group)
        let nextIndex: Int
        if let current, let idx = options.firstIndex(of: current) {
            nextIndex = (idx + 1) % options.count
        } else {
            nextIndex = 0
        }
        item.select(options[nextIndex], in: group)
        store.status = "Selected \(label): \(options[nextIndex].displayName)"
        showControls()
    }

    private func startRenderWatchdog(for item: AVPlayerItem, player: AVPlayer) {
        renderWatchdogTask?.cancel()
        renderWatchdogTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard errorText == nil, !forceVLCSurface, !forceKSPlayerSurface else { return }
            let size = item.presentationSize
            let hasVideo = size.width > 8 && size.height > 8
            let likelyPlaying = player.timeControlStatus == .playing || player.rate > 0
            if !hasVideo && likelyPlaying {
                #if canImport(TVVLCKit)
                if !avRetryAttemptedForCurrentURL && UniversalCodecSupport.vlcCompiledIn {
                    avRetryAttemptedForCurrentURL = true
                    retryText = "VLC Internal produced audio/no video; switching this same URL to VLC Internal…"
                    switchToVLCEngine(manual: false)
                    forceControlsVisibleForNavigation()
                    return
                }
                #endif
                isLoading = false
                forceControlsVisibleForNavigation()
                errorText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            }
        }
    }

    private func forceControlsVisible() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
    }

    private var cacheLimitLabel: String {
        vodCacheLimitGB == -1 ? "Unlimited" : "\(vodCacheLimitGB)GB"
    }

    private var cacheLimitGBValue: Double {
        vodCacheLimitGB == -1 ? 0 : Double(vodCacheLimitGB)
    }

    private var cacheFillProgress: Double {
        cacheSession.progress
    }

    private var cacheUsedGB: Double {
        cacheSession.usedGB
    }

    private func cycleCacheLimit() {
        if isLivePlayback {
            cacheSession.stopAndDelete()
            store.status = "Live TV cache remains disabled. VOD-only cache protects TS/HLS playback from recording or progress-cache behavior."
            return
        }
        switch vodCacheLimitGB {
        case 5: vodCacheLimitGB = 10
        case 10: vodCacheLimitGB = -1
        default: vodCacheLimitGB = 5
        }
        // Restart the temporary watch-session cache with the new limit. This cache is deleted on player exit.
        cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
    }

    private func forceControlsVisibleForNavigation(lockOverlay: Bool = true) {
        hideTask?.cancel()
        if lockOverlay { vodOverlayLockedForRemoteNavigation = true }
        withAnimation(.easeInOut(duration: 0.16)) { controlsVisible = true }
        if focusedControl == nil { DispatchQueue.main.async { focusedControl = lastKnownControlFocus } }
        scheduleOverlayAutoHideIfAllowed()
    }

    private func showControlsWithoutChangingFocus() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.12)) { controlsVisible = true }
        scheduleOverlayAutoHideIfAllowed()
    }

    private func showControls() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
        scheduleAutoHide()
    }

    private func scheduleAutoHide() {
        hideTask?.cancel()
        vodOverlayLockedForRemoteNavigation = false
        scheduleOverlayAutoHideIfAllowed(delaySeconds: 7)
    }

    private func scheduleOverlayAutoHideIfAllowed(delaySeconds: UInt64 = 7) {
        hideTask?.cancel()
        guard activePanel == nil, errorText == nil, !isLoading else { return }
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: delaySeconds * 1_000_000_000)
            guard !Task.isCancelled else { return }
            guard activePanel == nil, errorText == nil, !isLoading else { return }
            vodOverlayLockedForRemoteNavigation = false
            withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = false }
        }
    }


    private func resumeStorageKey() -> String {
        let identity = [item.type, item.catalog, item.year, item.title, item.id]
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
            .joined(separator: "|")
        let safe = identity.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? String(abs(identity.hashValue))
        return "vod.resume.seconds.\(safe)"
    }

    private func saveResumePosition(force: Bool = false) {
        saveResumePositionIfNeeded(force: force)
    }

    private func runtimeSeconds(for item: MediaItem) -> Double {
        // Offline safety fallback for a few well-known titles only. The normal path below
        // is TMDB detail lookup; this prevents the VOD bar from showing fake 0:00 when
        // the player/proxy stream does not expose duration immediately.
        let key = "\(item.title.lowercased().trimmingCharacters(in: .whitespacesAndNewlines))|\(item.year)"
        let knownMinutes: [String: Double] = [
            "national treasure|2004": 131,
            "national treasure: book of secrets|2007": 124
        ]
        if let minutes = knownMinutes[key] { return minutes * 60 }
        return 0
    }

    private func startRuntimeMetadataLookupIfNeeded() {
        guard !isLivePlayback else { return }
        guard resolvedDurationSeconds <= 1 else { return }
        runtimeLookupTask?.cancel()
        runtimeLookupTask = Task { @MainActor in
            if let seconds = await fetchRuntimeSecondsFromTMDB() {
                metadataRuntimeSeconds = seconds
                metadataRuntimeLabel = "TMDB runtime"
                store.status = "Movie details loaded."
            }
        }
    }

    private func fetchRuntimeSecondsFromTMDB() async -> Double? {
        let key = vodTMDBApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return nil }

        struct MovieDetail: Decodable { let runtime: Int? }
        struct TVDetail: Decodable { let episode_run_time: [Int]? }
        struct FindResponse: Decodable {
            struct FoundItem: Decodable { let id: Int? }
            let movie_results: [FoundItem]?
            let tv_results: [FoundItem]?
        }

        func fetch<T: Decodable>(_ type: T.Type, from url: URL) async -> T? {
            do {
                let (data, _) = try await URLSession.shared.data(from: url)
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                return nil
            }
        }

        let parts = item.id.split(separator: ":").map(String.init)
        let normalizedType = item.type.lowercased()
        let tmdbKindFromType = normalizedType.contains("series") || normalizedType.contains("show") || normalizedType.contains("tv") ? "tv" : "movie"

        var detailKind: String? = nil
        var detailID: String? = nil
        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            detailKind = (parts[1].lowercased() == "tv" || tmdbKindFromType == "tv") ? "tv" : "movie"
            detailID = parts[2]
        } else {
            let imdbID: String? = {
                if item.id.lowercased().hasPrefix("tt") { return item.id }
                if let match = item.id.range(of: #"tt\d{6,}"#, options: .regularExpression) { return String(item.id[match]) }
                return nil
            }()
            if let imdbID, let encoded = imdbID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
               let findURL = URL(string: "https://api.themoviedb.org/3/find/\(encoded)?api_key=\(key)&external_source=imdb_id"),
               let found = await fetch(FindResponse.self, from: findURL) {
                if let movieID = found.movie_results?.compactMap({ $0.id }).first {
                    detailKind = "movie"; detailID = String(movieID)
                } else if let tvID = found.tv_results?.compactMap({ $0.id }).first {
                    detailKind = "tv"; detailID = String(tvID)
                }
            }
        }

        guard let detailKind, let detailID, let url = URL(string: "https://api.themoviedb.org/3/\(detailKind)/\(detailID)?api_key=\(key)") else { return nil }
        if detailKind == "movie", let detail = await fetch(MovieDetail.self, from: url), let minutes = detail.runtime, minutes > 0 {
            return Double(minutes) * 60
        }
        if detailKind == "tv", let detail = await fetch(TVDetail.self, from: url), let minutes = detail.episode_run_time?.first(where: { $0 > 0 }) {
            return Double(minutes) * 60
        }
        return nil
    }

    private func armStartupLoadingGate(engine: String) {
        startupLoadingTask?.cancel()
        startupLoadingTask = Task { @MainActor in
            let startedAt = Date()
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 300_000_000)
                guard errorText == nil else { return }
                let cacheMB = cacheSession.cachedBytes > 0 ? String(format: " • cache %.1fMB", Double(cacheSession.cachedBytes) / 1_048_576.0) : " • cache starting"
                retryText = "Starting \(engine)… \(formatTime(currentSeconds)) / \(resolvedDurationSeconds > 0 ? formatTime(resolvedDurationSeconds) : "loading time")\(isLivePlayback ? "" : cacheMB)"
                // KSPlayer/TVVLCKit do not expose a reliable SwiftUI-ready callback in every package version.
                // Keep the loading card up during the initial handoff, then release it only after the stream
                // has had time to start and the playback clock/cache has moved instead of hiding it instantly.
                let elapsed = Date().timeIntervalSince(startedAt)
                let enoughStartupTime = elapsed >= (isLivePlayback ? 1.2 : 3.2)
                // KSPlayer/TVVLCKit callbacks vary by package version, so keep the loading card
                // visible until the stream has had a real startup window and, for VOD, the
                // temporary cache has actually begun writing. This prevents the black-screen
                // handoff where the overlay disappears before the movie/show is visibly streaming.
                let playbackHasMoved = currentSeconds > 1.5 || elapsed >= 4.2
                let cacheHasStarted = isLivePlayback || cacheSession.cachedBytes >= 512 * 1024 || elapsed >= 5.0
                if enoughStartupTime && playbackHasMoved && cacheHasStarted {
                    isLoading = false
                    forceControlsVisibleForNavigation()
                    scheduleAutoHide()
                    return
                }
            }
        }
    }

    private func startPlayerClock() {
        playbackClockTask?.cancel()
        playbackClockTask = Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                guard isPlaying, errorText == nil else { continue }
                guard forceKSPlayerSurface || forceVLCSurface else { continue }
                let total = resolvedDurationSeconds
                if total > 0 { currentSeconds = min(total, currentSeconds + 1) } else { currentSeconds += 1 }
                saveResumePositionIfNeeded()
                if !isLivePlayback, total > 0, currentSeconds / total >= 0.95 { PlaybackResumeCacheManager.shared.clear(for: item) }
            }
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds > 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }
}


struct DebridPlaybackDiagnosticsPanel: View {
    let diagnostics: DebridPlaybackDiagnostics

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("PLAYBACK DIAGNOSTICS")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
            diagnosticRow("Active Engine", diagnostics.activeEngine)
            diagnosticRow("HW Decode", diagnostics.hwDecode)
            diagnosticRow("Playback Renderer", diagnostics.renderBackend)
            diagnosticRow("Decoder", diagnostics.decoder)
            diagnosticRow("FPS", diagnostics.fps)
            diagnosticRow("Dropped Frames", diagnostics.droppedFrames)
            Text(diagnostics.notes)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .lineLimit(2)
                .frame(width: 360, alignment: .leading)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(.black.opacity(0.44), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
        .allowsHitTesting(false)
    }

    private func diagnosticRow(_ key: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(key)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.50))
                .frame(width: 118, alignment: .leading)
            Text(value)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .lineLimit(1)
        }
    }
}


struct DebridMovieLoadingView: View {
    let message: String
    @State private var spin = false
    @State private var glow = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VStack(spacing: 22) {
                ZStack {
                    Circle()
                        .stroke(.orange.opacity(0.18), lineWidth: 8)
                        .frame(width: 82, height: 82)
                    Circle()
                        .trim(from: 0.08, to: 0.78)
                        .stroke(.orange.opacity(0.94), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                        .frame(width: 82, height: 82)
                        .rotationEffect(.degrees(spin ? 360 : 0))
                    Circle()
                        .fill(.white.opacity(glow ? 0.22 : 0.10))
                        .frame(width: 18, height: 18)
                        .shadow(color: .orange.opacity(0.50), radius: glow ? 20 : 8)
                }

                Text(message)
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)

                Text("Preparing playback…")
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
            }
            .padding(.horizontal, 48)
            .padding(.vertical, 38)
            .background(.black.opacity(0.58), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.linear(duration: 1.0).repeatForever(autoreverses: false)) { spin = true }
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) { glow = true }
        }
    }
}
struct ApplePlayerErrorCard: View {
    let message: String
    let close: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 18) {
            Text("Playback Error")
                .font(.system(size: 34, weight: .black, design: .rounded))
            Text(message)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.78))
            Button(action: close) {
                Text("Close Player")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(focused ? .black : .white)
                    .padding(.horizontal, 34)
                    .padding(.vertical, 15)
                    .background(Capsule().fill(focused ? Color.white : Color.white.opacity(0.16)))
            }
            .buttonStyle(.plain)
            .focused($focused)
        }
        .padding(42)
        .frame(maxWidth: 900)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .foregroundStyle(.white)
        .shadow(color: .black.opacity(0.55), radius: 30)
        .onAppear { focused = true }
    }
}

struct TheaterAmbientArtworkGlow: View {
    let item: MediaItem

    private var accent: Color {
        let source = (item.genres.first ?? item.title).lowercased()
        if source.contains("horror") || source.contains("thriller") { return .red }
        if source.contains("sci") || source.contains("fantasy") { return .orange }
        if source.contains("animation") || source.contains("family") { return .cyan }
        if source.contains("crime") || source.contains("drama") { return .blue }
        if source.contains("romance") { return .pink }
        return .orange
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [accent.opacity(0.34), Color.clear, Color.black.opacity(0.10)], startPoint: .bottomLeading, endPoint: .topTrailing)
            RadialGradient(colors: [accent.opacity(0.22), Color.clear], center: .bottomLeading, startRadius: 80, endRadius: 760)
        }
    }
}

struct VODTheaterModeStrip: View {
    let item: MediaItem
    let engine: String
    let cacheLabel: String
    let resumeEntry: PlaybackResumeEntry?
    let isPlaying: Bool

    private var headline: String {
        if let resumeEntry, resumeEntry.seconds >= 8 { return "THEATER MODE  •  RESUME READY" }
        return isPlaying ? "THEATER MODE  •  NOW PLAYING" : "THEATER MODE  •  PAUSED"
    }

    private var subline: String {
        var parts: [String] = []
        if !item.year.isEmpty { parts.append(item.year) }
        if let first = item.genres.first, !first.isEmpty { parts.append(first) }
        parts.append(engine)
        if !cacheLabel.isEmpty { parts.append(cacheLabel) }
        return parts.prefix(4).joined(separator: "  •  ")
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(headline)
                .font(.system(size: 16, weight: .black, design: .rounded))
                .kerning(1.4)
                .foregroundStyle(LinearGradient(colors: [.orange, .yellow.opacity(0.92)], startPoint: .leading, endPoint: .trailing))
            Text(item.title)
                .font(.system(size: 32, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.97))
                .lineLimit(1)
                .minimumScaleFactor(0.70)
            Text(subline)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.70))
                .lineLimit(1)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 13)
        .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
        .shadow(color: .orange.opacity(0.16), radius: 22, y: 6)
    }
}

struct VODTheaterCastWall: View {
    let item: MediaItem

    private var isLivePlaybackItem: Bool {
        item.type.lowercased() == "live"
    }

    private var isLikelySportsProgram: Bool {
        let haystack = ([item.title, item.description] + item.genres).joined(separator: " ").lowercased()
        return ["nfl", "nba", "mlb", "nhl", "soccer", "football", "basketball", "baseball", "hockey", "ufc", "boxing", "tennis", "golf", "vs", " at "].contains { haystack.contains($0) }
    }


    private var liveSmartProgramLine: String {
        let desc = item.description.trimmingCharacters(in: .whitespacesAndNewlines)
        if !desc.isEmpty && !desc.lowercased().contains("tvmaze") && !desc.lowercased().contains("smart program details load") {
            return desc
        }
        let fields = ([item.year, item.rating] + item.genres).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        if !fields.isEmpty { return fields.prefix(4).joined(separator: " • ") }
        return isLikelySportsProgram ? "Waiting for verified sports matchup metadata from EPG/public feeds." : "No verified EPG details were matched for this channel yet."
    }

    private var liveSmartProgramBadge: String {
        let desc = item.description.trimmingCharacters(in: .whitespacesAndNewlines)
        if !desc.isEmpty && !desc.lowercased().contains("tvmaze") { return "EPG metadata attached" }
        return isLikelySportsProgram ? "Waiting for verified sports feed" : "Waiting for verified EPG"
    }

    private var members: [CastMember] {
        if !item.castMembers.isEmpty { return Array(item.castMembers.prefix(4)) }
        return Array(item.cast.prefix(4)).map { CastMember(name: $0, role: nil, imageURL: nil) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: isLivePlaybackItem ? (isLikelySportsProgram ? "sportscourt.fill" : "sparkles.tv.fill") : "person.3.fill")
                    .font(.system(size: 15, weight: .black))
                    .foregroundStyle(Color.orange.opacity(0.95))
                Text(isLivePlaybackItem ? (isLikelySportsProgram ? "LIVE MATCH" : "PROGRAM INFO") : "CAST WALL")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .kerning(1.1)
                    .foregroundStyle(.white.opacity(0.90))
            }
            if isLivePlaybackItem {
                VStack(alignment: .leading, spacing: 6) {
                    Text(liveSmartProgramLine)
                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                        .lineLimit(3)
                    Text(liveSmartProgramBadge)
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .kerning(0.8)
                        .foregroundStyle(.orange.opacity(0.90))
                }
            } else if members.isEmpty {
                Text("Cast will appear when metadata finishes loading.")
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
                    .lineLimit(3)
            } else {
                HStack(spacing: 12) {
                    ForEach(members) { member in
                        CastFaceCard(member: member)
                    }
                }
            }
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color.black.opacity(0.30)))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
        .shadow(color: .black.opacity(0.30), radius: 18, y: 8)
    }
}

struct AppleVODPosterCard: View {
    let item: MediaItem

    private var isLivePoster: Bool {
        item.type.lowercased() == "live"
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.posterURL, mode: isLivePoster ? .fit : .fill)
                .padding(isLivePoster ? 12 : 0)
                .background(Color.black.opacity(isLivePoster ? 0.24 : 0.0))
                .frame(width: 198, height: 292)
                .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 26, style: .continuous)
                        .stroke(LinearGradient(colors: [.white.opacity(0.28), .cyan.opacity(0.16), .white.opacity(0.06)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.2)
                )
                .shadow(color: .black.opacity(0.72), radius: 24, x: 0, y: 14)
                .shadow(color: .cyan.opacity(0.12), radius: 22, x: 0, y: 0)

            if let resume = PlaybackResumeCacheManager.shared.resumeEntry(for: item) {
                ContinueWatchingBadge(entry: resume, compact: false)
                    .padding(10)
                    .frame(width: 198, height: 292, alignment: .topTrailing)
            }

            if let season = item.seasonNumber, let episode = item.episodeNumber {
                Text("S\(season)  E\(episode)")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Color.black.opacity(0.68)))
                    .foregroundStyle(.white.opacity(0.92))
                    .padding(12)
            }
        }
    }
}


struct ContinueWatchingBadge: View {
    let entry: PlaybackResumeEntry
    let compact: Bool

    private var progress: Double {
        guard entry.duration > 0 else { return 0 }
        return min(0.98, max(0.02, entry.seconds / entry.duration))
    }

    private var remainingText: String {
        guard entry.duration > entry.seconds else { return "Resume" }
        let remaining = max(0, entry.duration - entry.seconds)
        if remaining >= 3600 { return "\(Int(remaining / 3600))h left" }
        return "\(max(1, Int(remaining / 60)))m left"
    }

    var body: some View {
        VStack(alignment: .trailing, spacing: compact ? 4 : 6) {
            Text(compact ? "RESUME" : remainingText)
                .font(.system(size: compact ? 10 : 12, weight: .black, design: .rounded))
                .foregroundStyle(.black)
                .padding(.horizontal, compact ? 8 : 10)
                .padding(.vertical, compact ? 4 : 5)
                .background(Capsule().fill(Color.orange.opacity(0.96)))
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.24))
                    Capsule().fill(LinearGradient(colors: [.orange, .yellow.opacity(0.95)], startPoint: .leading, endPoint: .trailing))
                        .frame(width: max(5, geo.size.width * progress))
                }
            }
            .frame(width: compact ? 64 : 96, height: compact ? 4 : 5)
        }
        .padding(compact ? 7 : 9)
        .background(RoundedRectangle(cornerRadius: compact ? 14 : 16, style: .continuous).fill(Color.black.opacity(0.58)))
        .overlay(RoundedRectangle(cornerRadius: compact ? 14 : 16, style: .continuous).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .shadow(color: .orange.opacity(0.22), radius: 12)
    }
}




struct PopupBottomSummaryShelf: View {
    let item: MediaItem

    private var resume: PlaybackResumeEntry? {
        PlaybackResumeCacheManager.shared.resumeEntry(for: item)
    }

    private var hasResume: Bool {
        guard let resume else { return false }
        return resume.seconds >= 8 && resume.duration > resume.seconds
    }

    private var progress: Double {
        guard let resume, resume.duration > 0 else { return 0 }
        return min(0.98, max(0.02, resume.seconds / resume.duration))
    }

    private var remainingText: String {
        guard let resume, resume.duration > resume.seconds else { return "Ready to watch" }
        let remaining = max(0, resume.duration - resume.seconds)
        if remaining >= 3600 { return "\(Int(remaining / 3600))h \(Int((remaining.truncatingRemainder(dividingBy: 3600)) / 60))m remaining" }
        return "\(max(1, Int(remaining / 60)))m remaining"
    }

    private var primaryTitle: String {
        hasResume ? "CONTINUE WATCHING" : "BROWSE SUMMARY"
    }

    private var primaryValue: String {
        hasResume ? remainingText : "Ready to watch"
    }

    private var genreText: String {
        item.genres.first?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false ? item.genres.first! : "Premium Browse"
    }

    var body: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 9) {
                    Image(systemName: hasResume ? "play.circle.fill" : "sparkles")
                        .font(.system(size: 18, weight: .black))
                        .foregroundStyle(hasResume ? Color.orange.opacity(0.96) : Color.cyan.opacity(0.92))
                    Text(primaryTitle)
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .kerning(1.1)
                        .foregroundStyle(.white.opacity(0.56))
                }
                Text(primaryValue)
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.95))
                    .lineLimit(1)
                if hasResume {
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.16))
                            Capsule().fill(LinearGradient(colors: [Color.orange, Color.cyan.opacity(0.88)], startPoint: .leading, endPoint: .trailing))
                                .frame(width: max(8, geo.size.width * progress))
                        }
                    }
                    .frame(height: 5)
                }
            }
            .frame(width: 340, alignment: .leading)

            PopupSummaryChip(title: "SOURCE", value: item.catalog.isEmpty ? "Catalog Ready" : item.catalog, icon: "sparkles.tv.fill", tint: .cyan)
            PopupSummaryChip(title: "MOOD", value: genreText, icon: "wand.and.stars", tint: .blue)
            PopupSummaryChip(title: "CAST", value: item.castMembers.first?.name ?? item.cast.first ?? "Cast Ready", icon: "person.crop.circle.fill", tint: .orange)
            PopupSummaryChip(title: "STATUS", value: "Artwork Ready", icon: "checkmark.seal.fill", tint: .green)
        }
        .padding(.horizontal, 22)
        .background(
            LinearGradient(colors: [Color.black.opacity(0.72), Color.white.opacity(0.045), Color.black.opacity(0.58)], startPoint: .leading, endPoint: .trailing),
            in: RoundedRectangle(cornerRadius: 24, style: .continuous)
        )
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
        .shadow(color: .black.opacity(0.22), radius: 16, y: 6)
    }
}

struct PopupSummaryChip: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .black))
                .foregroundStyle(tint.opacity(0.92))
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .kerning(1.0)
                    .foregroundStyle(.white.opacity(0.48))
                Text(value)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.88))
                    .lineLimit(1)
                    .minimumScaleFactor(0.68)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .frame(width: 180, height: 54)
        .background(RoundedRectangle(cornerRadius: 16, style: .continuous).fill(tint.opacity(0.08)))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(tint.opacity(0.16), lineWidth: 1))
    }
}

struct DynamicShowcaseArea: View {
    let item: MediaItem
    @State private var artPulse: Bool = false

    private var resume: PlaybackResumeEntry? {
        PlaybackResumeCacheManager.shared.resumeEntry(for: item)
    }

    private var hasResume: Bool { resume != nil }

    private var remainingText: String {
        guard let resume, resume.duration > resume.seconds else { return "Ready to watch" }
        let remaining = max(0, resume.duration - resume.seconds)
        if remaining >= 3600 {
            return "\(Int(remaining / 3600))h \(Int((remaining.truncatingRemainder(dividingBy: 3600)) / 60))m remaining"
        }
        return "\(max(1, Int(remaining / 60)))m remaining"
    }

    private var progress: Double {
        guard let resume, resume.duration > 0 else { return 0 }
        return min(0.98, max(0.03, resume.seconds / resume.duration))
    }

    private var showcaseTitle: String {
        hasResume ? "CONTINUE WATCHING" : "FEATURED SCENE"
    }

    private var showcaseSubtitle: String {
        if hasResume { return remainingText }
        if let genre = item.genres.first, !genre.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "\(genre) atmosphere"
        }
        if let cast = item.castMembers.first?.name, !cast.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return "Spotlight: \(cast)"
        }
        return "Cinematic artwork"
    }

    private var detailLine: String {
        if let resume, resume.duration > 0 {
            let watched = Int((resume.seconds / resume.duration * 100).rounded())
            return "\(max(1, min(99, watched)))% watched • Resume ready"
        }
        let studio = (item.addonName ?? item.catalog).trimmingCharacters(in: .whitespacesAndNewlines)
        return studio.isEmpty ? "Premium browse artwork" : "\(studio) • Premium browse artwork"
    }

    var body: some View {
        ZStack(alignment: .leading) {
            showcaseArtwork

            LinearGradient(
                colors: [Color.black.opacity(0.86), Color.black.opacity(0.48), Color.black.opacity(0.22), Color.black.opacity(0.74)],
                startPoint: .leading,
                endPoint: .trailing
            )

            HStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(spacing: 9) {
                        Image(systemName: hasResume ? "play.circle.fill" : "sparkles.tv.fill")
                            .font(.system(size: 20, weight: .black))
                            .foregroundStyle(hasResume ? Color.orange.opacity(0.98) : Color.cyan.opacity(0.94))
                        Text(showcaseTitle)
                            .font(.system(size: 13, weight: .black, design: .rounded))
                            .kerning(1.3)
                            .foregroundStyle(.white.opacity(0.62))
                    }

                    Text(showcaseSubtitle)
                        .font(.system(size: 28, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.96))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)

                    Text(detailLine)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.58))
                        .lineLimit(1)

                    if hasResume {
                        GeometryReader { geo in
                            ZStack(alignment: .leading) {
                                Capsule().fill(Color.white.opacity(0.18))
                                Capsule().fill(LinearGradient(colors: [Color.orange, Color.yellow.opacity(0.96), Color.cyan.opacity(0.82)], startPoint: .leading, endPoint: .trailing))
                                    .frame(width: max(8, geo.size.width * progress))
                            }
                        }
                        .frame(width: 520, height: 6)
                    }
                }
                .frame(width: 560, alignment: .leading)

                Spacer(minLength: 0)

                VStack(alignment: .trailing, spacing: 7) {
                    Text(hasResume ? "WATCH NEXT" : "VISUAL SHOWCASE")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .kerning(1.2)
                        .foregroundStyle(.white.opacity(0.52))
                    Text(item.title)
                        .font(.system(size: 21, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.92))
                        .lineLimit(1)
                        .minimumScaleFactor(0.65)
                    if let first = item.castMembers.first?.name ?? item.cast.first, !first.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Text("Featuring \(first)")
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.54))
                            .lineLimit(1)
                    }
                }
                .frame(width: 360, alignment: .trailing)
            }
            .padding(.horizontal, 30)
        }
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(Color.black.opacity(0.32)))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.09), lineWidth: 1))
        .overlay(alignment: .top) {
            Rectangle()
                .fill(LinearGradient(colors: [Color.orange.opacity(0.22), Color.white.opacity(0.04), Color.cyan.opacity(0.14)], startPoint: .leading, endPoint: .trailing))
                .frame(height: 1)
                .padding(.horizontal, 22)
        }
        .shadow(color: (hasResume ? Color.orange : Color.cyan).opacity(0.12), radius: 18, y: 6)
        .onAppear { artPulse = true }
    }

    @ViewBuilder
    private var showcaseArtwork: some View {
        if let url = item.landscapeURL, !url.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            RemoteImageFit(url: url, mode: .fill)
                .saturation(1.12)
                .contrast(1.08)
                .brightness(artPulse ? 0.018 : -0.012)
                .animation(.easeInOut(duration: 9.5).repeatForever(autoreverses: true), value: artPulse)
        } else if let url = item.posterURL, !url.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            RemoteImageFit(url: url, mode: .fill)
                .blur(radius: 10)
                .scaleEffect(1.12)
                .saturation(1.10)
                .contrast(1.10)
        } else {
            LinearGradient(colors: [Color.orange.opacity(0.20), Color.black, Color.cyan.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
}

struct PremiumBrowsePosterStack: View {
    let item: MediaItem

    private var resume: PlaybackResumeEntry? {
        PlaybackResumeCacheManager.shared.resumeEntry(for: item)
    }

    private var remainingText: String {
        guard let resume, resume.duration > resume.seconds else { return "Ready to Play" }
        let remaining = max(0, resume.duration - resume.seconds)
        if remaining >= 3600 { return "\(Int(remaining / 3600))h \(Int((remaining.truncatingRemainder(dividingBy: 3600)) / 60))m remaining" }
        return "\(max(1, Int(remaining / 60)))m remaining"
    }

    private var progress: Double {
        guard let resume, resume.duration > 0 else { return 0 }
        return min(0.98, max(0.02, resume.seconds / resume.duration))
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            DetailPoster(item: item)
                .frame(width: 240, height: 362)
                .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 30, style: .continuous)
                        .stroke(LinearGradient(colors: [Color.orange.opacity(0.42), Color.cyan.opacity(0.24), Color.white.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.4)
                )
                .shadow(color: Color.orange.opacity(resume == nil ? 0.06 : 0.28), radius: resume == nil ? 10 : 24, y: 8)

            VStack(alignment: .leading, spacing: 7) {
                if resume != nil {
                    HStack(spacing: 8) {
                        Image(systemName: "play.circle.fill")
                            .font(.system(size: 20, weight: .black))
                            .foregroundStyle(Color.orange.opacity(0.96))
                        VStack(alignment: .leading, spacing: 1) {
                            Text("CONTINUE WATCHING")
                                .font(.system(size: 10, weight: .black, design: .rounded))
                                .kerning(1.0)
                                .foregroundStyle(Color.orange.opacity(0.98))
                            Text(remainingText)
                                .font(.system(size: 13, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white.opacity(0.96))
                                .lineLimit(1)
                        }
                    }
                    GeometryReader { geo in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.20))
                            Capsule().fill(LinearGradient(colors: [Color.orange, Color.cyan.opacity(0.88)], startPoint: .leading, endPoint: .trailing))
                                .frame(width: max(6, geo.size.width * progress))
                        }
                    }
                    .frame(height: 5)
                } else {
                    Text("READY TO WATCH")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .kerning(1.0)
                        .foregroundStyle(.white.opacity(0.82))
                }
            }
            .padding(13)
            .frame(width: 240, alignment: .leading)
            .background(
                LinearGradient(colors: [Color.black.opacity(0.0), Color.black.opacity(0.78)], startPoint: .top, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
            )
        }
        .frame(width: 240, height: 362)
    }
}


struct SourceIntelligenceRail: View {
    let visibleLinks: [StreamLink]
    let totalLinkCount: Int

    private var bestLink: StreamLink? { visibleLinks.first }

    private var bestQuality: String {
        guard let link = bestLink else { return totalLinkCount > 0 ? "Sources Ready" : "Find Sources" }
        return link.detectedResolution
    }

    private var sourceSafety: String {
        guard let link = bestLink else { return totalLinkCount > 0 ? "Ready" : "Waiting" }
        return link.sourceWarning ?? link.matchLabel
    }

    private var audioText: String {
        guard let link = bestLink else { return "Unknown" }
        return link.detectedAudio ?? "Audio Unknown"
    }

    private var subtitleText: String {
        guard let link = bestLink else { return "Unknown" }
        return link.subtitleLabel
    }

    var body: some View {
        if let link = bestLink {
            VStack(alignment: .leading, spacing: 9) {
                HStack(spacing: 9) {
                    Image(systemName: "sparkles.rectangle.stack.fill")
                        .font(.system(size: 15, weight: .black))
                        .foregroundStyle(Color.cyan.opacity(0.95))
                    Text("SOURCE INTELLIGENCE PREVIEW")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .kerning(1.1)
                        .foregroundStyle(.white.opacity(0.58))
                    Spacer(minLength: 0)
                    Text("\(totalLinkCount) links")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.42))
                }
                HStack(spacing: 10) {
                    SourceIntelCard(title: "QUALITY", value: bestQuality, icon: "star.fill", tint: .orange)
                    SourceIntelCard(title: "LANGUAGE", value: link.detectedLanguage ?? "Unknown", icon: "captions.bubble.fill", tint: link.detectedLanguage == "English" ? .green : .orange)
                    SourceIntelCard(title: "AUDIO", value: audioText, icon: "speaker.wave.2.fill", tint: .cyan)
                    SourceIntelCard(title: "SUBTITLES", value: subtitleText, icon: "text.bubble.fill", tint: .purple)
                }
                HStack(spacing: 8) {
                    SourceIntelWideCard(title: "PROVIDER", value: link.providerDisplay, tint: .blue)
                    SourceIntelWideCard(title: "SAFETY", value: sourceSafety, tint: link.sourceWarning == nil ? .green : .orange)
                    SourceIntelWideCard(title: "FORMAT", value: [link.detectedCodec, link.detectedHDR, link.size.isEmpty ? nil : link.size].compactMap { $0 }.prefix(3).joined(separator: " • "), tint: .white)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Color.black.opacity(0.28)))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
        } else {
            HStack(spacing: 10) {
                SourceIntelCard(title: "BEST QUALITY", value: "Find Sources", icon: "star.fill", tint: .orange)
                SourceIntelCard(title: "LANGUAGE", value: "Unknown", icon: "captions.bubble.fill", tint: .orange)
                SourceIntelCard(title: "AUDIO", value: "Waiting", icon: "speaker.wave.2.fill", tint: .cyan)
                SourceIntelCard(title: "FOUND", value: totalLinkCount > 0 ? "\(totalLinkCount) Links" : "Tap Find Links", icon: "link", tint: .purple)
            }
        }
    }
}

struct SourceIntelCard: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .black))
                .foregroundStyle(tint.opacity(0.98))
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .kerning(0.8)
                    .foregroundStyle(.white.opacity(0.46))
                    .lineLimit(1)
                Text(value.isEmpty ? "Unknown" : value)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
            }
        }
        .padding(.horizontal, 11)
        .frame(width: 238, height: 40, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(tint.opacity(0.22), lineWidth: 1))
        .shadow(color: tint.opacity(0.10), radius: 10, y: 4)
    }
}

struct SourceIntelWideCard: View {
    let title: String
    let value: String
    let tint: Color
    var body: some View {
        HStack(spacing: 7) {
            Text(title)
                .font(.system(size: 9, weight: .black, design: .rounded))
                .kerning(0.7)
                .foregroundStyle(tint.opacity(0.72))
            Text(value.isEmpty ? "Unknown" : value)
                .font(.system(size: 11, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.78))
                .lineLimit(1)
                .minimumScaleFactor(0.72)
        }
        .padding(.horizontal, 10)
        .frame(width: 319, height: 30, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 11, style: .continuous).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).stroke(tint.opacity(0.16), lineWidth: 1))
    }
}

struct MediaDNAv2GroupingRow: View {
    let item: MediaItem
    let relatedItems: [MediaItem]

    private var directorName: String { item.directors.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Director" }
    private var studioName: String { item.addonName?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).isEmpty == false ? (item.addonName ?? item.catalog) : item.catalog }
    private var castCount: Int { max(0, item.castMembers.isEmpty ? item.cast.count : item.castMembers.count) }
    private var genreName: String { item.genres.first?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Theme" }

    var body: some View {
        HStack(spacing: 12) {
            MediaDNAGroupCard(title: "SIMILAR", value: "\(max(relatedItems.count, 0)) Titles", icon: "rectangle.stack.fill", tint: .cyan)
            MediaDNAGroupCard(title: "SAME CAST", value: castCount > 0 ? "\(castCount) People" : "Cast Ready", icon: "person.2.fill", tint: .orange)
            MediaDNAGroupCard(title: "DIRECTOR", value: directorName, icon: "megaphone.fill", tint: .yellow)
            MediaDNAGroupCard(title: "STUDIO", value: studioName.isEmpty ? "Studio Match" : studioName, icon: "building.2.fill", tint: .purple)
            MediaDNAGroupCard(title: "THEME", value: genreName, icon: "sparkles", tint: .blue)
        }
    }
}


struct DiscoveryPathSummaryRow: View {
    let item: MediaItem
    let relatedItems: [MediaItem]

    private func clean(_ value: String?) -> String {
        let trimmed = (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "Ready" : trimmed
    }

    private var firstCastName: String {
        if let member = item.castMembers.first { return clean(member.name) }
        if let name = item.cast.first { return clean(name) }
        return "Cast Path"
    }

    private var directorPath: String {
        if let director = item.directors.first { return clean(director) }
        return item.type.lowercased().contains("series") ? "Showrunner Path" : "Director Path"
    }

    private var studioPath: String {
        let addon = clean(item.addonName)
        if addon != "Ready" { return addon }
        return clean(item.catalog)
    }

    private var nextStep: String {
        if relatedItems.count >= 6 { return "Explore Similar" }
        if !item.castMembers.isEmpty || !item.cast.isEmpty { return "Open Cast" }
        if !item.directors.isEmpty { return "Follow Director" }
        return "Discover More"
    }

    var body: some View {
        HStack(spacing: 12) {
            DiscoveryPathCard(title: "NEXT STEP", value: nextStep, icon: "arrow.triangle.branch", tint: .orange)
            DiscoveryPathCard(title: "CAST PATH", value: firstCastName, icon: "person.crop.rectangle.stack.fill", tint: .cyan)
            DiscoveryPathCard(title: "CREATOR PATH", value: directorPath, icon: "movieclapper.fill", tint: .yellow)
            DiscoveryPathCard(title: "STUDIO PATH", value: studioPath, icon: "building.columns.fill", tint: .purple)
            DiscoveryPathCard(title: "MATCHES", value: relatedItems.isEmpty ? "Scan Ready" : "\(relatedItems.count) Linked", icon: "point.3.connected.trianglepath.dotted", tint: .green)
        }
        .padding(.horizontal, 2)
    }
}

struct DiscoveryPathCard: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .black))
                .foregroundStyle(tint.opacity(0.98))
                .frame(width: 24)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .kerning(0.9)
                    .foregroundStyle(.white.opacity(0.46))
                    .lineLimit(1)
                Text(value)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.93))
                    .lineLimit(1)
                    .minimumScaleFactor(0.65)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .frame(width: 270, height: 64, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .fill(LinearGradient(colors: [tint.opacity(0.11), Color.black.opacity(0.26)], startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(tint.opacity(0.18), lineWidth: 1))
        .shadow(color: tint.opacity(0.09), radius: 12, y: 4)
    }
}

struct StudioFranchiseFoundationRow: View {
    let item: MediaItem
    let relatedItems: [MediaItem]

    private func clean(_ value: String?) -> String {
        let trimmed = (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? "—" : trimmed
    }

    private var studioLabel: String {
        let addon = clean(item.addonName)
        if addon != "—" { return addon }
        return clean(item.catalog)
    }

    private var franchiseLabel: String {
        let title = item.title.lowercased()
        let separators = [":", "-", "–", "—"]
        for separator in separators {
            if let range = item.title.range(of: separator) {
                let base = String(item.title[..<range.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
                if base.count >= 3 { return base }
            }
        }
        if title.contains("part") || title.contains("chapter") { return item.title }
        return relatedItems.count > 1 ? "Collection Ready" : "Franchise Scan"
    }

    private var universeLabel: String {
        if let first = item.genres.first, !first.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return first }
        if item.type.lowercased().contains("series") || item.type.lowercased().contains("tv") { return "Series Universe" }
        return "Movie Universe"
    }

    private var discoveryLabel: String {
        let count = relatedItems.count
        if count > 0 { return "\(count) Linked" }
        if !item.directors.isEmpty { return "Director Path" }
        if !item.cast.isEmpty || !item.castMembers.isEmpty { return "Cast Path" }
        return "Ready"
    }

    var body: some View {
        HStack(spacing: 12) {
            FoundationDiscoveryCard(title: "STUDIO HUB", value: studioLabel, icon: "building.2.fill", tint: .purple)
            FoundationDiscoveryCard(title: "FRANCHISE", value: franchiseLabel, icon: "square.stack.3d.up.fill", tint: .orange)
            FoundationDiscoveryCard(title: "UNIVERSE", value: universeLabel, icon: "sparkles", tint: .cyan)
            FoundationDiscoveryCard(title: "DISCOVERY", value: discoveryLabel, icon: "point.3.connected.trianglepath.dotted", tint: .yellow)
        }
        .padding(.horizontal, 2)
    }
}

struct FoundationDiscoveryCard: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(tint.opacity(0.17))
                Image(systemName: icon)
                    .font(.system(size: 17, weight: .black))
                    .foregroundStyle(tint.opacity(0.98))
            }
            .frame(width: 46, height: 46)

            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .kerning(1.1)
                    .foregroundStyle(.white.opacity(0.48))
                    .lineLimit(1)
                Text(value)
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 12)
        .frame(width: 342, height: 82, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(LinearGradient(colors: [Color.white.opacity(0.072), Color.black.opacity(0.22)], startPoint: .topLeading, endPoint: .bottomTrailing))
        )
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(tint.opacity(0.17), lineWidth: 1))
        .shadow(color: tint.opacity(0.10), radius: 14, y: 5)
    }
}

struct MediaDNAGroupCard: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                Circle().fill(tint.opacity(0.18))
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(tint.opacity(0.96))
            }
            .frame(width: 38, height: 38)

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .kerning(1.0)
                    .foregroundStyle(.white.opacity(0.48))
                    .lineLimit(1)
                Text(value)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.92))
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 13)
        .frame(width: 270, height: 76, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color.white.opacity(0.065)))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(tint.opacity(0.16), lineWidth: 1))
    }
}

struct PremiumMetadataStrip: View {
    let item: MediaItem

    private var chips: [String] {
        var values: [String] = []
        if !item.year.isEmpty { values.append(item.year) }
        if !item.rating.isEmpty { values.append("★ \(item.rating)") }
        if let first = item.genres.first, !first.isEmpty { values.append(first) }
        if let resume = PlaybackResumeCacheManager.shared.resumeEntry(for: item) {
            values.append("Resume \(formatShort(resume.seconds))")
        }
        if !item.catalog.isEmpty { values.append(item.catalog) }
        return Array(values.prefix(5))
    }

    var body: some View {
        HStack(spacing: 10) {
            ForEach(chips, id: \.self) { chip in
                HStack(spacing: 6) {
                    Circle().fill(Color.orange.opacity(0.85)).frame(width: 5, height: 5)
                    Text(chip.uppercased())
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.90))
                        .lineLimit(1)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(RoundedRectangle(cornerRadius: 13, style: .continuous).fill(Color.white.opacity(0.095)))
                .overlay(RoundedRectangle(cornerRadius: 13, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
            }
        }
    }

    private func formatShort(_ seconds: Double) -> String {
        let total = max(0, Int(seconds))
        let h = total / 3600
        let m = (total % 3600) / 60
        if h > 0 { return "\(h)h \(m)m" }
        return "\(m)m"
    }
}


struct VODMediaDNAStack: View {
    let item: MediaItem
    let resumeEntry: PlaybackResumeEntry?
    let sourceQuality: String

    private var mood: String {
        let genreText = item.genres.joined(separator: " ").lowercased()
        if genreText.contains("horror") || genreText.contains("thriller") { return "Tension" }
        if genreText.contains("sci") || genreText.contains("fantasy") { return "World Building" }
        if genreText.contains("comedy") { return "Light Energy" }
        if genreText.contains("drama") || genreText.contains("crime") { return "Character Driven" }
        if genreText.contains("animation") || genreText.contains("family") { return "Family Night" }
        return "Cinematic"
    }

    private func cleaned(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private var directorName: String {
        cleaned(item.directors.first) ?? "Director Match"
    }

    private var castName: String {
        cleaned(item.castMembers.first?.name) ?? cleaned(item.cast.first) ?? "Cast Match"
    }

    private var studioName: String {
        cleaned(item.addonName) ?? cleaned(item.catalog) ?? "Studio Match"
    }

    private var genreName: String {
        cleaned(item.genres.first) ?? mood
    }

    private var resumeText: String {
        guard let resumeEntry, resumeEntry.seconds >= 8 else { return "Start Fresh" }
        return "Resume Ready"
    }

    private var dnaChips: [String] {
        var chips: [String] = ["MEDIA DNA", mood, resumeText]
        if let first = item.genres.first, !first.isEmpty { chips.append(first) }
        chips.append(sourceQuality)
        return Array(chips.prefix(5))
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "point.3.connected.trianglepath.dotted")
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(Color.orange.opacity(0.96))
                Text("MEDIA DNA EXPLORER")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .kerning(1.1)
                    .foregroundStyle(.white.opacity(0.82))
                Spacer(minLength: 0)
                ForEach(dnaChips.prefix(3), id: \.self) { chip in
                    Text(chip.uppercased())
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .kerning(0.6)
                        .foregroundStyle(.white.opacity(0.74))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 5)
                        .background(Capsule().fill(Color.white.opacity(0.07)))
                }
            }

            HStack(spacing: 10) {
                MediaDNAGroupCard(title: "SAME CAST", value: castName, icon: "person.crop.circle.fill", tint: .orange)
                MediaDNAGroupCard(title: "DIRECTOR", value: directorName, icon: "megaphone.fill", tint: .yellow)
                MediaDNAGroupCard(title: "STUDIO", value: studioName, icon: "building.2.fill", tint: .purple)
                MediaDNAGroupCard(title: "THEME", value: genreName, icon: "sparkles", tint: .blue)
            }
        }
    }
}

struct VODTheaterIntelligenceRow: View {
    let item: MediaItem
    let resumeEntry: PlaybackResumeEntry?
    let sourceQuality: String
    let cacheReadyLabel: String
    let engine: String
    let progressText: String

    private var cards: [(String, String, String)] {
        var rows: [(String, String, String)] = []
        rows.append(("SOURCE", sourceQuality, "bolt.fill"))
        rows.append(("CACHE", cacheReadyLabel, "externaldrive.fill"))
        rows.append(("ENGINE", engine, "play.rectangle.fill"))
        if let resumeEntry, resumeEntry.seconds >= 8 {
            rows.append(("RESUME", formatShort(resumeEntry.seconds), "gobackward"))
        } else {
            rows.append(("PROGRESS", progressText.isEmpty ? "Ready" : progressText, "chart.line.uptrend.xyaxis"))
        }
        if let first = item.genres.first, !first.isEmpty {
            rows.append(("MOOD", first, "sparkles"))
        }
        return Array(rows.prefix(5))
    }

    var body: some View {
        HStack(spacing: 12) {
            ForEach(cards, id: \.0) { card in
                HStack(spacing: 12) {
                    Image(systemName: card.2)
                        .font(.system(size: 17, weight: .black))
                        .foregroundStyle(Color.orange.opacity(0.94))
                        .frame(width: 28, height: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(card.0)
                            .font(.system(size: 11, weight: .black, design: .rounded))
                            .kerning(1.2)
                            .foregroundStyle(.white.opacity(0.48))
                        Text(card.1)
                            .font(.system(size: 16, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.92))
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 12)
                .frame(width: 342, height: 58)
                .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color.white.opacity(0.075)))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.11), lineWidth: 1))
                .shadow(color: .black.opacity(0.22), radius: 10, y: 5)
            }
        }
    }

    private func formatShort(_ seconds: Double) -> String {
        let total = max(0, Int(seconds))
        let h = total / 3600
        let m = (total % 3600) / 60
        if h > 0 { return "\(h)h \(m)m" }
        return "\(m)m"
    }
}

struct AppleVODBadge: View {
    let text: String
    let highlighted: Bool

    var body: some View {
        Text(text)
            .font(.system(size: 17, weight: .black, design: .rounded))
            .foregroundStyle(highlighted ? .black : .white.opacity(0.86))
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(highlighted ? Color.white.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(Capsule().stroke(Color.white.opacity(highlighted ? 0.0 : 0.16), lineWidth: 1))
    }
}

struct AppleVODChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.clear, .black.opacity(0.18), .black.opacity(0.86)],
                startPoint: .top,
                endPoint: .bottom
            )
            LinearGradient(
                colors: [.black.opacity(0.22), .clear, .black.opacity(0.18)],
                startPoint: .leading,
                endPoint: .trailing
            )
            VStack { Spacer() }
                .background(
                    Rectangle()
                        .fill(Color.black.opacity(0.20))
                        .background(.ultraThinMaterial.opacity(0.82))
                        .overlay(
                            LinearGradient(colors: [.cyan.opacity(0.10), .clear, .blue.opacity(0.08)], startPoint: .leading, endPoint: .trailing)
                        )
                        .frame(height: 450),
                    alignment: .bottom
                )
        }
    }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        view.playerLayer.videoGravity = videoGravity
        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        view.playerLayer.player = player
        view.playerLayer.videoGravity = videoGravity
    }
}

struct DebridPlayerPanel<Content: View>: View {
    let title: String
    let detail: String
    var focusedOption: VODPlayerScreen.PlayerPanelOption? = nil
    @ViewBuilder let content: () -> Content

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.system(size: 34, weight: .black))
            Text(detail)
                .font(.system(size: 21, weight: .semibold))
                .foregroundStyle(.white.opacity(0.82))
                .lineLimit(4)
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 10) {
                        content()
                    }
                    .padding(.vertical, 4)
                }
                .frame(maxHeight: 470)
                .onAppear {
                    if let focusedOption {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                            withAnimation(.easeOut(duration: 0.12)) {
                                proxy.scrollTo(focusedOption, anchor: .center)
                            }
                        }
                    }
                }
                .onChange(of: focusedOption) { next in
                    guard let next else { return }
                    withAnimation(.easeOut(duration: 0.12)) {
                        proxy.scrollTo(next, anchor: .center)
                    }
                }
            }
        }
        .foregroundStyle(.white)
        .padding(30)
        .frame(width: 620, alignment: .leading)
        .background(.ultraThinMaterial.opacity(0.92), in: RoundedRectangle(cornerRadius: 30))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.55), radius: 26)
        .focusSection()
    }
}

struct PanelOptionChip: View {
    let title: String
    var selected: Bool = false
    let focus: VODPlayerScreen.PlayerPanelOption
    var focused: FocusState<VODPlayerScreen.PlayerPanelOption?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(selected ? Color.cyan.opacity(0.98) : Color.white.opacity(0.92))
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Capsule().fill(selected ? Color.cyan.opacity(0.16) : Color.white.opacity(0.08)))
                .overlay(Capsule().stroke(selected ? Color.cyan.opacity(0.82) : Color.white.opacity(0.16), lineWidth: selected ? 2 : 1))
                .scaleEffect(selected ? 1.025 : 1.0)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .buttonBorderShape(.capsule)
        .clipShape(Capsule())
        .id(focus)
        .focused(focused, equals: focus)
        .focusable(false)
    }
}

struct PlayerChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.clear, .black.opacity(0.25), .black.opacity(0.92)], startPoint: .top, endPoint: .bottom)
            LinearGradient(colors: [.black.opacity(0.18), .clear, .black.opacity(0.20)], startPoint: .leading, endPoint: .trailing)
        }
    }
}

struct PlayerProgressBar: View {
    let progress: Double

    var body: some View {
        GeometryReader { proxy in
            let clamped = min(max(progress, 0), 1)
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.14))
                Capsule().fill(LinearGradient(colors: [.white.opacity(0.30), .cyan.opacity(0.34)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: proxy.size.width * min(1, clamped + 0.10))
                Capsule().fill(LinearGradient(colors: [.cyan.opacity(0.95), .blue.opacity(0.72), .white.opacity(0.92)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: proxy.size.width * clamped)
                Circle().fill(Color.white).frame(width: 20, height: 20).shadow(color: .cyan.opacity(0.5), radius: 8).offset(x: max(0, proxy.size.width * clamped - 10))
            }
        }
    }
}


struct VODRuntimeProgressSummary: View {
    let title: String
    let current: String
    let total: String
    let remaining: String
    let percent: String
    let cacheLabel: String
    let cacheUsed: String
    let cacheLimit: String

    var body: some View {
        HStack(spacing: 16) {
            VODInfoPill(icon: "clock", text: "\(current) / \(total)")
            VODInfoPill(icon: "timer", text: "Remaining \(remaining)")
            VODInfoPill(icon: "chart.line.uptrend.xyaxis", text: percent)
            VODInfoPill(icon: "externaldrive", text: "Cache \(cacheUsed) / \(cacheLimit)")
        }
        .accessibilityLabel("playback time \(current) of \(total), \(percent) complete, \(remaining) remaining, cache \(cacheUsed) of \(cacheLimit)")
    }
}

struct VODInfoPill: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .black))
                .foregroundStyle(.cyan.opacity(0.9))
            Text(text)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .monospacedDigit()
                .foregroundStyle(.white.opacity(0.88))
                .lineLimit(1)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 8)
        .background(Capsule().fill(Color.white.opacity(0.08)))
        .overlay(Capsule().stroke(Color.white.opacity(0.13), lineWidth: 1))
    }
}

struct VODCacheProgressRow: View {
    let cacheLabel: String
    let usedGB: Double
    let limitGB: Double
    let progress: Double
    let status: String

    var body: some View {
        HStack(spacing: 14) {
            Text("Cache")
                .font(.system(size: 16, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.10))
                Capsule().fill(LinearGradient(colors: [.cyan.opacity(0.92), .blue.opacity(0.72)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, 330 * progress))
            }
            .frame(width: 330, height: 8)
            Text(limitGB == 0 ? String(format: "%.2f GB / Unlimited", usedGB) : String(format: "%.2f GB / %@", usedGB, cacheLabel))
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.46))
            Text("• \(status)")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Text("• English audio preferred • Subtitles off")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.34))
        }
        .lineLimit(1)
    }
}

struct VODFocusBoundaryModifier: ViewModifier {
    func body(content: Content) -> some View {
        // tvOS-compatible focus boundary shim: keep the overlay as its own focus section
        // without depending on newer SDK-only focusMovementBoundary symbols.
        content
            .focusSection()
            .contentShape(Rectangle())
    }
}


struct VODOverlayMenuButton<MenuContent: View>: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    @ViewBuilder let menuContent: () -> MenuContent

    var body: some View {
        PlayerControlButton(title: title, focus: focus, focused: focused) { }
    }
}

struct PlayerControlButton: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let action: () -> Void

    private var selected: Bool { focused.wrappedValue == focus }
    private var foregroundColor: Color { selected ? Color.black.opacity(0.94) : .white.opacity(0.92) }
    private var fillColor: Color { selected ? Color.cyan.opacity(0.92) : .white.opacity(0.095) }
    private var strokeColor: Color { selected ? Color.white.opacity(0.66) : .white.opacity(0.18) }
    private var strokeWidth: CGFloat { selected ? 2 : 1 }
    private var buttonScale: CGFloat { selected ? 1.055 : 1.0 }
    private var glowColor: Color { selected ? Color.cyan.opacity(0.32) : .clear }

    private var iconName: String {
        switch focus {
        case .resume: return "play.circle.fill"
        case .back10: return "gobackward.30"
        case .playPause: return title.lowercased().contains("pause") ? "pause.fill" : "play.fill"
        case .forward10: return "goforward.30"
        case .ksplayer: return "play.tv.fill"
        case .internalVLC: return "cone.fill"
        case .avplayer: return "airplayvideo"
        case .audio: return "waveform"
        case .findAudio: return "music.note.list"
        case .subtitles: return "captions.bubble.fill"
        case .episodes: return "list.bullet.rectangle"
        case .zoom: return "arrow.up.left.and.arrow.down.right"
        case .settings: return "gearshape.fill"
        case .infuse: return "sparkles.tv.fill"
        case .vlc: return "play.rectangle.fill"
        case .senplayer: return "rectangle.on.rectangle"
        case .close: return "xmark"
        }
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 9) {
                Image(systemName: iconName)
                    .font(.system(size: 17, weight: .black))
                Text(title)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .lineLimit(1)
            }
            .foregroundStyle(foregroundColor)
            .padding(.horizontal, 18)
            .padding(.vertical, 14)
            .background(Capsule().fill(fillColor))
            .overlay(Capsule().stroke(strokeColor, lineWidth: strokeWidth))
            .scaleEffect(buttonScale)
            .shadow(color: glowColor, radius: 14)
            .contentShape(Capsule())
        }
        .buttonStyle(.plain)
        .buttonBorderShape(.capsule)
        .clipShape(Capsule())
        .focused(focused, equals: focus)
        .focusable(false)
        .accessibilityLabel(title)
    }
}


private extension Date {
    var iso8601String: String { ISO8601DateFormatter().string(from: self) }
    var friendlyBackupDate: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: self)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @AppStorage("liveChannelsDvrBaseURL") private var liveChannelsDvrBaseURL: String = ""
    @AppStorage("liveHDHomeRunManualURL") private var liveHDHomeRunManualURL: String = ""
    @AppStorage("liveHDHomeRunManualGuideURL") private var liveHDHomeRunManualGuideURL: String = ""
    @AppStorage("liveM3UURL") private var liveM3UURL: String = ""
    @AppStorage("liveXMLTVURL") private var liveXMLTVURL: String = ""
    @AppStorage("liveXtreamServer") private var liveXtreamServer: String = ""
    @AppStorage("liveXtreamUsername") private var liveXtreamUsername: String = ""
    @AppStorage("liveXtreamPassword") private var liveXtreamPassword: String = ""
    @AppStorage("liveXtreamAccounts") private var liveXtreamAccounts: String = ""
    @StateObject private var liveZone = SportsLiveZoneModel()
    @StateObject private var liveModel = LiveTVSourceModel()
    @AppStorage("sportsAssignedGroups") private var sportsAssignedGroupsRaw: String = ""
    @AppStorage("liveXtreamLoginStatus") private var liveXtreamLoginStatus: String = "Not connected"
    @AppStorage("sportsXtreamImportMode") private var sportsXtreamImportMode: String = "Full TV"
    @AppStorage("sportsFavoriteTeams") private var sportsFavoriteTeams: String = ""
    @AppStorage("sportsCustomSourcesJSON") private var sportsCustomSourcesJSON: String = ""
    @AppStorage("sportsScoreTickerEnabled") private var sportsScoreTickerEnabled: Bool = true
    @AppStorage("backendBaseURL") private var backendBaseURL: String = "https://api.skylinejay187.it.com"
    @AppStorage("tmdbApiKey") private var tmdbApiKey: String = ""
    @AppStorage("fanartTvApiKey") private var fanartTvApiKey: String = ""
    @AppStorage("tvdbApiToken") private var tvdbApiToken: String = ""
    @AppStorage("externalMoviesInfuseDefault") private var externalMoviesInfuseDefault: Bool = false
    @AppStorage("externalMoviesVLCDefault") private var externalMoviesVLCDefault: Bool = false
    @AppStorage("externalMoviesSenPlayerDefault") private var externalMoviesSenPlayerDefault: Bool = false
    @AppStorage("externalShowsInfuseDefault") private var externalShowsInfuseDefault: Bool = false
    @AppStorage("externalShowsVLCDefault") private var externalShowsVLCDefault: Bool = false
    @AppStorage("externalShowsSenPlayerDefault") private var externalShowsSenPlayerDefault: Bool = false
    @AppStorage("liveTVUseAVPlayerDefault") private var liveTVUseAVPlayerDefault: Bool = false
    @AppStorage("gridLockedMode") private var gridLockedMode: Bool = false
    @AppStorage("trailerPlaybackMode") private var trailerPlaybackMode: String = "automatic"
    @AppStorage("trailerProviderMode") private var trailerProviderMode: String = "auto"
    @AppStorage("popupFontPreset") private var popupFontPreset: String = "SF Rounded"
    @AppStorage("topMenuThemePreset") private var topMenuThemePreset: String = "Classic"
    @AppStorage("topMenuFontPreset") private var topMenuFontPreset: String = "SF Rounded"
    @AppStorage("homeGridThemePreset") private var homeGridThemePreset: String = "Classic Glow"
    @AppStorage("liveTVGridThemePreset") private var liveTVGridThemePreset: String = "Classic Dark"
    @AppStorage("followAlertsEnabled") private var followAlertsEnabled: Bool = true
    @AppStorage("followNewEpisodesEnabled") private var followNewEpisodesEnabled: Bool = true
    @AppStorage("followSportsAlertsEnabled") private var followSportsAlertsEnabled: Bool = true
    @AppStorage("followPPVAlertsEnabled") private var followPPVAlertsEnabled: Bool = true
    @AppStorage("followVerifiedOnly") private var followVerifiedOnly: Bool = true
    @AppStorage("iCloudProfileBackupLastDate") private var iCloudProfileBackupLastDate: String = "Never"
    @AppStorage("iCloudProfileBackupLastStatus") private var iCloudProfileBackupLastStatus: String = "Not backed up yet"
    @FocusState private var focused: SettingsFocus?
    @State private var lastSettingsDpadMoveAt: Date = .distantPast
    @State private var isXtreamLoggingIn: Bool = false
    @State private var popupFontListOpen: Bool = false
    @State private var topMenuFontListOpen: Bool = false
    @State private var topMenuThemeListOpen: Bool = false
    @State private var homeGridThemeListOpen: Bool = false
    @State private var liveTVGridThemeListOpen: Bool = false
    @State private var xtreamOrganizerGroups: [String] = []
    @State private var showXtreamOrganizer: Bool = false
    @State private var iCloudBackupBusy: Bool = false
    @State private var iCloudBackupMessage: String = ""
    private let settingsColumnWidth: CGFloat = 560

    enum SettingsFocus: Hashable { case manifest, add, load, loadAll, reset, liveDvr, liveHDHRManual, liveHDHRGuideURL, liveM3U, liveXMLTV, liveXtreamServer, liveXtreamUsername, liveXtreamPassword, liveXtreamLogin, backendBase, tmdbKey, fanartKey, tvdbToken, saveArtworkKeys, extMovieInfuse, extMovieVLC, extMovieSen, extShowInfuse, extShowVLC, extShowSen, liveAVPlayerDefault, trailerModeAutomatic, trailerModeInApp, trailerModeYouTube, popupFontToggle, topMenuThemeToggle, topMenuFontToggle, homeGridThemeToggle, liveTVGridThemeToggle, sportsXtreamFull, sportsXtreamOnly, sportsXtreamBoth, sportsTickerToggle, sportsFavoriteTeams, sportsM3USources, gridLockedMode, iCloudBackupNow, iCloudRestoreNow, iCloudClearNow, home, movies, shows, live }

    var body: some View {
        ZStack {
            StaticAppBackground().ignoresSafeArea()
            settingsScroll
        }
        .onAppear {
            if store.onboardingTourActive {
                focused = nil
            } else {
                focused = .manifest
            }
        }
        // v182: Let the tvOS focus engine own Settings DPAD movement. The prior
        // manual routeSettings() handler fought the native ScrollView/TextField focus
        // movement, causing one Siri Remote click to jump two controls.
    }

    private var settingsScroll: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .leading, spacing: 22) {
                settingsTitle
                stremioCard
                aboutCard
                Spacer(minLength: 80)
            }
            .frame(width: 1320, alignment: .leading)
            .padding(.leading, 82)
            .padding(.bottom, 120)
        }
    }

    private var settingsTitle: some View {
        Text("Settings")
            .font(.system(size: 62, weight: .black))
            .foregroundStyle(.white)
            .padding(.top, 108)
    }

    private var stremioCard: some View {
        HStack(alignment: .top, spacing: 26) {
            VStack(alignment: .leading, spacing: 18) {
                SettingsSectionCard(title: "Streaming Catalogs", subtitle: "Cinemeta and saved Stremio JSON catalog URLs", systemImage: "puzzlepiece.extension.fill") {
                    stremioHeader
                    manifestInput
                    manifestButtons
                    savedManifestList
                }

                SettingsSectionCard(title: "Metadata & Artwork", subtitle: "Backend, TMDB, Fanart.tv, and TVDB keys", systemImage: "sparkles.tv.fill") {
                    artworkKeysSection
                }

                SettingsSectionCard(title: "Home / Popup Style", subtitle: "Fonts and top navigation presentation", systemImage: "paintpalette.fill") {
                    appearanceSettingsSection
                }
            }
            .frame(width: 590, alignment: .topLeading)

            VStack(alignment: .leading, spacing: 18) {
                SettingsSectionCard(title: "Live TV Sources", subtitle: "Channels DVR, HDHomeRun, M3U/XMLTV, and Xtream", systemImage: "tv.fill") {
                    liveTVSourcesSection
                }

                SettingsSectionCard(title: "Sports Sources", subtitle: "Sports Hub, favorite teams, and ticker. IPTV sports auto-routing is backlogged.", systemImage: "sportscourt.fill") {
                    sportsSourcesSettingsSection
                }

                SettingsSectionCard(title: "Follow Center", subtitle: "Verified show, sports, and PPV alerts from real data sources", systemImage: "bell.badge.fill") {
                    followCenterSettingsSection
                }

                SettingsSectionCard(title: "Video Player", subtitle: "Trailers and external player defaults", systemImage: "play.rectangle.fill") {
                    trailerSettingsSection
                    externalPlayerDefaultsSection
                }

                SettingsSectionCard(title: "iCloud Backup & Restore", subtitle: "Back up and restore this Apple TV profile with iCloud", systemImage: "icloud.and.arrow.up.fill") {
                    iCloudBackupRestoreSection
                }

                SettingsSectionCard(title: "Help", subtitle: "Replay first-time setup", systemImage: "questionmark.circle.fill") {
                    resetOnboardingSection
                }
            }
            .frame(width: 590, alignment: .topLeading)
        }
        .padding(24)
        .frame(width: 1240, alignment: .topLeading)
        .background(
            RoundedRectangle(cornerRadius: 34)
                .fill(Color.white.opacity(0.045))
                .overlay(
                    LinearGradient(colors: [Color.white.opacity(0.07), Color.cyan.opacity(0.055), Color.black.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                        .clipShape(RoundedRectangle(cornerRadius: 34))
                )
        )
        .overlay(RoundedRectangle(cornerRadius: 34).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }

    private var stremioHeader: some View {
        Text("Streaming Catalogs")
            .font(.system(size: 28, weight: .bold))
            .foregroundStyle(.white)
    }

    private var manifestInput: some View {
        TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
            .font(.system(size: 23, weight: .semibold))
            .foregroundStyle(.white)
            .padding(20)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.cyan : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
            .focused($focused, equals: .manifest)
            .frame(width: settingsColumnWidth)
    }

    private var manifestButtons: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], alignment: .leading, spacing: 12) {
            SettingsButton(title: "Add JSON", focus: .add, focused: $focused) {
                store.addManifestURL(manifestURL)
                manifestURL = ""
            }
            SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL", focus: .load, focused: $focused) {
                Task { await store.loadManifest(urlString: manifestURL) }
            }
            SettingsButton(title: "Load All Catalogs", focus: .loadAll, focused: $focused) {
                Task { await store.loadAllManifests() }
            }
            SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                store.resetDemo()
            }
        }
        .frame(width: settingsColumnWidth, alignment: .leading)
    }

    private var savedManifestList: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Saved JSON URLs")
                .font(.system(size: 20, weight: .black))
                .foregroundStyle(.cyan)
            Text("Higher saved URLs load/search first. Move a catalog above Cinemeta to make it the priority source.")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: settingsColumnWidth, alignment: .leading)
            ForEach(Array(store.manifestURLs.enumerated()), id: \.element) { index, url in
                SettingsStremioAddonRow(url: url, index: index, totalCount: store.manifestURLs.count)
                    .environmentObject(store)
            }
        }
        .padding(.top, 4)
    }

    private var liveTVSourcesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Live TV Sources")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            liveTextField("Channels DVR connection", text: $liveChannelsDvrBaseURL, focus: .liveDvr)
            liveTextField("HDHomeRun manual IP or lineup URL, example http://hdhomerun.local/lineup.json", text: $liveHDHomeRunManualURL, focus: .liveHDHRManual)
            liveTextField("HDHomeRun/XMLTV Gracenotes guide URL", text: $liveHDHomeRunManualGuideURL, focus: .liveHDHRGuideURL)
            liveMultiLineField("M3U playlist URLs — paste multiple links, one per line", text: $liveM3UURL, focus: .liveM3U)
            liveMultiLineField("XMLTV guide URLs — paste multiple links, one per line", text: $liveXMLTVURL, focus: .liveXMLTV)
            xtreamFields
            Text("Multiple live sources are supported. Add one source per line where needed, then reopen Live TV or refresh the guide.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: settingsColumnWidth, alignment: .leading)
            EmptyView() // v436: Grid Locked Mode removed/disabled while trailer playback is repaired.
        }
        .padding(.top, 6)
    }

    private func liveTextField(_ placeholder: String, text: Binding<String>, focus: SettingsFocus) -> some View {
        TextField(placeholder, text: text)
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(.white)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
            .focused($focused, equals: focus)
            .frame(width: settingsColumnWidth)
    }

    private func liveMultiLineField(_ placeholder: String, text: Binding<String>, focus: SettingsFocus) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(placeholder)
                .font(.system(size: 15, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.68))
            VStack(alignment: .leading, spacing: 6) {
                TextField("Paste one or more links separated by new lines, commas, or spaces", text: text)
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .textFieldStyle(.plain)
                    .padding(12)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
                    .overlay(RoundedRectangle(cornerRadius: 12).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
                    .focused($focused, equals: focus)
                Text("Supports multiple links separated by new lines, commas, or spaces.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
                    .padding(.leading, 4)
            }
            .frame(width: settingsColumnWidth, height: 118)
        }
    }

    private func liveToggleButton(title: String, subtitle: String, isOn: Binding<Bool>, focus: SettingsFocus) -> some View {
        Button {
            isOn.wrappedValue.toggle()
        } label: {
            HStack(spacing: 16) {
                RoundedRectangle(cornerRadius: 16)
                    .fill(isOn.wrappedValue ? Color.cyan.opacity(0.85) : Color.white.opacity(0.12))
                    .frame(width: 86, height: 44)
                    .overlay(alignment: isOn.wrappedValue ? .trailing : .leading) {
                        Circle().fill(Color.white).frame(width: 34, height: 34).padding(5)
                    }
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(title): \(isOn.wrappedValue ? "On" : "Off")")
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.62))
                        .lineLimit(2)
                }
                Spacer()
            }
            .padding(14)
            .frame(width: settingsColumnWidth)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused, equals: focus)
    }

    private func xtreamModeButton(_ title: String, mode: String, focus: SettingsFocus) -> some View {
        let selected = sportsXtreamImportMode == mode
        let labelText = selected ? "✓ " + title : title
        let fillColor: Color = selected ? Color.orange.opacity(0.34) : Color.white.opacity(0.075)
        let borderColor: Color = focused == focus ? Color.orange : (selected ? Color.orange.opacity(0.45) : Color.white.opacity(0.12))
        let borderWidth: CGFloat = focused == focus ? 3 : 1

        return Button(action: {
            sportsXtreamImportMode = mode
        }) {
            Text(labelText)
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(Color.white)
                .lineLimit(1)
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(fillColor)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(borderColor, lineWidth: borderWidth)
                )
        }
        .buttonStyle(.plain)
        .focused($focused, equals: focus)
        .frame(width: 168)
    }

    private var followCenterSettingsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Follow Center")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Alerts are based on verified online data. If TVMaze/TMDB/sports feeds do not confirm the date or event, Home stays quiet instead of showing fake alerts.")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: settingsColumnWidth, alignment: .leading)
            followToggle("Follow Center Alerts", subtitle: "Master switch for Home alert cards.", isOn: $followAlertsEnabled)
            followToggle("New Episode Alerts", subtitle: "Uses TVMaze-first episode dates, with TMDB artwork when configured.", isOn: $followNewEpisodesEnabled)
            followToggle("Sports Team Alerts", subtitle: "Shows game/highlight alerts only when public sports feeds confirm data.", isOn: $followSportsAlertsEnabled)
            followToggle("PPV/Event Alerts", subtitle: "Fight, wrestling, racing, and major event watch reminders.", isOn: $followPPVAlertsEnabled)
            followToggle("Verified Data Only", subtitle: "Prevents guessed or placeholder alerts from appearing on Home.", isOn: $followVerifiedOnly)
        }
        .padding(.top, 6)
    }

    private func followToggle(_ title: String, subtitle: String, isOn: Binding<Bool>) -> some View {
        Toggle(isOn: isOn) {
            VStack(alignment: .leading, spacing: 3) {
                Text("\(title): \(isOn.wrappedValue ? "On" : "Off")")
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
            }
        }
        .padding(12)
        .frame(width: settingsColumnWidth, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(0.07)))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }

    private var sportsSourcesSettingsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Sports Hub")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.orange)
            Text("Xtream and M3U imports now load normally into Live TV. Automatic sports-channel routing is disabled until the group organizer is production-ready.")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: settingsColumnWidth, alignment: .leading)
            Text("Normal Xtream/M3U still imports into Live TV. Sports-only M3U links added here are isolated to Sports Hub and never pollute the main Live TV lineup.")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.54))
                .frame(width: settingsColumnWidth, alignment: .leading)
            liveToggleButton(title: "Sports Score Ticker", subtitle: "Show a moving live scores/ticker foundation only inside Sports.", isOn: $sportsScoreTickerEnabled, focus: .sportsTickerToggle)
            liveTextField("Favorite teams, comma separated — example Lakers, Yankees, Inter Miami, WWE", text: $sportsFavoriteTeams, focus: .sportsFavoriteTeams)
            liveTextField("Sports-only M3U links, one per line — PPV/event/sports providers only", text: $sportsCustomSourcesJSON, focus: .sportsM3USources)
            Text("Premium sports layer: command center, theater mode, heat map, PPV/event cards, team dashboards, roster/schedule/player foundations, and all-sports highlights.")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.50))
                .frame(width: settingsColumnWidth, alignment: .leading)
        }
        .padding(.top, 6)
    }

    private var xtreamFields: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Xtream Codes")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.86))

            liveTextField("Xtream server", text: $liveXtreamServer, focus: .liveXtreamServer)
            liveTextField("Username", text: $liveXtreamUsername, focus: .liveXtreamUsername)
            liveTextField("Password", text: $liveXtreamPassword, focus: .liveXtreamPassword)

            VStack(alignment: .leading, spacing: 8) {
                Text("Xtream Codes login")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.66))
                Text("Saved Xtream accounts import normally into Live TV. Automatic Sports Only/Both routing is removed until it can be made reliable.")
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.58))
                    .fixedSize(horizontal: false, vertical: true)
            }

            XtreamSetupOrganizerPreview(mode: "Full TV")
            if showXtreamOrganizer || !xtreamOrganizerGroups.isEmpty {
                XtreamSetupOrganizerLivePanel(groups: xtreamOrganizerGroups, mode: "Full TV")
            }

            HStack(spacing: 14) {
                SettingsButton(title: isXtreamLoggingIn ? "Checking…" : "Save / Login + Organizer", focus: .liveXtreamLogin, focused: $focused) {
                    Task { await saveAndLoginXtream() }
                }
                Text(liveXtreamLoginStatus)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(liveXtreamLoginStatus.lowercased().contains("connected") ? Color.green : Color.white.opacity(0.72))
                    .lineLimit(2)
                    .frame(width: 300, alignment: .leading)
            }

            Text(savedXtreamAccountCount > 0 ? "Saved accounts: \(savedXtreamAccountCount)" : "No saved Xtream accounts yet.")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: settingsColumnWidth, alignment: .leading)
        }
        .padding(14)
        .frame(width: settingsColumnWidth, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.04)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(isXtreamFieldFocused || focused == .liveXtreamLogin ? Color.orange.opacity(0.75) : Color.white.opacity(0.10), lineWidth: isXtreamFieldFocused || focused == .liveXtreamLogin ? 2 : 1))
    }



struct XtreamSetupOrganizerPreview: View {
    let mode: String

    private var normalizedMode: String {
        let lower = mode.lowercased()
        if lower.contains("sport") { return "Sports Only" }
        if lower.contains("both") { return "Both" }
        return "Full TV"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: "wand.and.stars")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(.orange)
                Text("Xtream Organizer Preview")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.90))
                Spacer()
                Text(normalizedMode)
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Capsule().fill(Color.orange.opacity(0.22)))
                    .foregroundStyle(.orange)
            }
            Text("Categories are shown as a visual organizer preview only. For production stability, Xtream imports into Live TV and sports auto-routing is backlogged.")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.60))
                .fixedSize(horizontal: false, vertical: true)
            HStack(spacing: 8) {
                XtreamOrganizerDemoChip(group: "ESPN / Sports", action: "Detected category", icon: "sportscourt.fill")
                XtreamOrganizerDemoChip(group: "Movies", action: "Live TV category", icon: "star.fill")
                XtreamOrganizerDemoChip(group: "News", action: "Live TV Only", icon: "tv.fill")
            }
            HStack(alignment: .top, spacing: 8) {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 14, weight: .black))
                    .foregroundStyle(.cyan)
                Text("For best now-playing posters/backdrops from Xtream EPG, add your own TMDB key in Settings → Artwork Providers. Without TMDB the app still uses provider logos and guide data.")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(10)
            .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.cyan.opacity(0.08)))
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct XtreamOrganizerDemoChip: View {
    let group: String
    let action: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 5) {
                Image(systemName: icon)
                    .font(.system(size: 10, weight: .black))
                Text(group)
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .lineLimit(1)
            }
            Text(action)
                .font(.system(size: 10, weight: .heavy, design: .rounded))
                .foregroundStyle(.orange)
                .lineLimit(1)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.white.opacity(0.075)))
        .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}


struct XtreamSetupOrganizerLivePanel: View {
    let groups: [String]
    let mode: String
    private let sportsWords = ["sport", "sports", "ppv", "event", "nfl", "nba", "mlb", "nhl", "ufc", "wwe", "boxing", "soccer", "football", "f1", "formula", "espn", "bein", "sky sports", "tnt sports", "dazn", "redzone"]
    private func suggestedAction(_ group: String) -> String {
        let lower = group.lowercased()
        if sportsWords.contains(where: { lower.contains($0) }) { return "Sports category" }
        if lower.contains("adult") || lower.contains("xxx") { return "Ignore" }
        if lower.contains("movie") || lower.contains("cinema") || lower.contains("vod") { return "Movies category" }
        return "Live TV"
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Xtream Organizer")
                    .font(.system(size: 16, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
                Text("\(groups.count) groups")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(.cyan)
            }
            Text("Groups from your provider are shown here so you can verify categories before opening Live TV. Assignment actions are backlogged; this screen no longer changes routing.")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                ForEach(groups.prefix(12), id: \.self) { group in
                    HStack(spacing: 8) {
                        Image(systemName: suggestedAction(group).lowercased().contains("sport") ? "sportscourt.fill" : "tv.fill")
                            .font(.system(size: 12, weight: .black))
                            .foregroundStyle(suggestedAction(group).lowercased().contains("sport") ? Color.orange : Color.cyan)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(group).font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(1)
                            Text(suggestedAction(group)).font(.system(size: 10, weight: .heavy, design: .rounded)).foregroundStyle(.white.opacity(0.58)).lineLimit(1)
                        }
                    }
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.white.opacity(0.065)))
                    .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
                }
            }
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 18, style: .continuous).fill(Color.black.opacity(0.38)))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.orange.opacity(0.18), lineWidth: 1))
    }
}

    private var savedXtreamAccountCount: Int {
        liveXtreamAccounts
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .count
    }

    @MainActor
    private func saveAndLoginXtream() async {
        liveXtreamServer = liveXtreamServer.trimmingCharacters(in: .whitespacesAndNewlines)
        liveXtreamUsername = liveXtreamUsername.trimmingCharacters(in: .whitespacesAndNewlines)
        liveXtreamPassword = liveXtreamPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !liveXtreamServer.isEmpty, !liveXtreamUsername.isEmpty, !liveXtreamPassword.isEmpty else {
            liveXtreamLoginStatus = "Xtream needs server, username, and password."
            return
        }
        isXtreamLoggingIn = true
        liveXtreamLoginStatus = "Checking Xtream login…"
        let result = await validateXtreamLogin(server: liveXtreamServer, username: liveXtreamUsername, password: liveXtreamPassword)
        isXtreamLoggingIn = false
        liveXtreamLoginStatus = result
        if result.lowercased().contains("connected") {
            saveXtreamAccountToList(server: liveXtreamServer, username: liveXtreamUsername, password: liveXtreamPassword)
            liveXtreamLoginStatus = "Xtream connected • loading organizer categories…"
            let groups = await loadXtreamOrganizerGroups(server: liveXtreamServer, username: liveXtreamUsername, password: liveXtreamPassword)
            xtreamOrganizerGroups = groups
            showXtreamOrganizer = true
            liveXtreamLoginStatus = groups.isEmpty ? "Xtream connected • no categories returned, live channels will still load." : "Xtream connected • organizer preview loaded \(groups.count) group(s). Refresh Live TV to import channels + XMLTV EPG."
        }
    }

    private func saveXtreamAccountToList(server: String, username: String, password: String) {
        let normalizedServer = normalizeXtreamSettingsServer(server)
        let cleanUser = username.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanPass = password.trimmingCharacters(in: .whitespacesAndNewlines)
        let mode = "Full TV"
        let line = [normalizedServer, cleanUser, cleanPass, mode].joined(separator: "|")
        guard !line.replacingOccurrences(of: "|", with: "").isEmpty else { return }
        var lines = liveXtreamAccounts
            .components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        // v534: replace the same account regardless of its old mode so switching Full TV / Sports Only / Both never creates a shadow duplicate.
        lines.removeAll { existing in
            let parts = existing.components(separatedBy: "|")
            guard parts.count >= 2 else { return existing == line }
            return normalizeXtreamSettingsServer(parts[0]) == normalizedServer && parts[1].trimmingCharacters(in: .whitespacesAndNewlines) == cleanUser
        }
        lines.append(line)
        liveXtreamAccounts = lines.joined(separator: "\n")
        LiveTVSourceModel.invalidatePersistedLineupCacheForSourceModeChange()
    }

    private func loadXtreamOrganizerGroups(server rawServer: String, username: String, password: String) async -> [String] {
        let base = normalizeXtreamSettingsServer(rawServer)
        guard let user = username.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let pass = password.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_categories") else { return [] }
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("application/json,*/*", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")
        do {
            let data: Data
            if url.scheme?.lowercased() == "http" {
                data = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,*/*", userAgent: "DebridChannels-tvOS/560", maxBytes: 4 * 1024 * 1024, timeout: 18).data
            } else {
                data = try await URLSession.shared.data(for: request).0
            }
            guard let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
            return Array(arr.compactMap { ($0["category_name"] as? String) ?? ($0["name"] as? String) }.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.prefix(80))
        } catch { return [] }
    }

    private func validateXtreamLogin(server rawServer: String, username: String, password: String) async -> String {
        let base = normalizeXtreamSettingsServer(rawServer)
        guard let user = username.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let pass = password.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(base)/player_api.php?username=\(user)&password=\(pass)") else {
            return "Xtream URL is invalid."
        }
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("application/json,*/*", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")
        do {
            let data: Data
            let statusCode: Int
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,*/*", userAgent: "DebridChannels-tvOS/560", maxBytes: 4 * 1024 * 1024, timeout: 18)
                data = plain.data
                statusCode = plain.statusCode
            } else {
                let (sessionData, response) = try await URLSession.shared.data(for: request)
                data = sessionData
                statusCode = (response as? HTTPURLResponse)?.statusCode ?? 200
            }
            if !(200...299).contains(statusCode) {
                return "Xtream login failed: HTTP \(statusCode)."
            }
            guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                return "Xtream login failed: invalid response."
            }
            let userInfo = root["user_info"] as? [String: Any]
            let authValue = userInfo?["auth"]
            let status = (userInfo?["status"] as? String)?.lowercased() ?? ""
            let authorized = (authValue as? NSNumber)?.intValue == 1 || (authValue as? String) == "1" || status == "active"
            if authorized {
                let exp = userInfo?["exp_date"] as? String ?? ""
                let suffix = exp.isEmpty ? "" : " • expires \(exp)"
                return "Xtream connected. Saved for Live TV. Reopen Live TV or force refresh.\(suffix)"
            }
            return "Xtream login failed: account not authorized."
        } catch {
            return "Xtream login failed: \(error.localizedDescription)"
        }
    }


    private func normalizedXtreamMode(_ raw: String) -> String {
        // v541: auto sports routing removed from production path. All Xtream accounts are Live TV sources.
        return "Full TV"
    }

    private func normalizeXtreamSettingsServer(_ raw: String) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
        return clean
    }


    private var trailerSettingsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Trailer Playback")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Choose how trailers open. Automatic Fallback tries the in-app popup first, then opens YouTube if a direct trailer stream is not ready.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: settingsColumnWidth, alignment: .leading)
            VStack(alignment: .leading, spacing: 12) {
                SettingsButton(title: trailerPlaybackMode == "automatic" ? "✓ Automatic Fallback" : "Automatic Fallback", focus: .trailerModeAutomatic, focused: $focused) { trailerPlaybackMode = "automatic" }
                SettingsButton(title: trailerPlaybackMode == "inApp" ? "✓ In-App Popup" : "In-App Popup", focus: .trailerModeInApp, focused: $focused) { trailerPlaybackMode = "inApp" }
                SettingsButton(title: trailerPlaybackMode == "youtube" ? "✓ Open in YouTube" : "Open in YouTube", focus: .trailerModeYouTube, focused: $focused) { trailerPlaybackMode = "youtube" }
            }

            Text("In-App Popup is experimental. Open in YouTube remains available as a reliable external fallback.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: settingsColumnWidth, alignment: .leading)
        }
        .padding(.top, 10)
    }

    private var appearanceSettingsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Appearance")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Customize the movie/show popup, top navigation menu, and home grid poster theme. These choices do not change Live TV guide, playback, or provider behavior.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: settingsColumnWidth, alignment: .leading)

            SettingsButton(title: popupFontListOpen ? "Popup Font: \(popupFontPreset) ▲" : "Popup Font: \(popupFontPreset) ▼", focus: .popupFontToggle, focused: $focused) {
                popupFontListOpen.toggle()
            }

            PopupFontPreview(preset: popupFontPreset)
                .frame(width: settingsColumnWidth, alignment: .leading)

            if popupFontListOpen {
                PopupFontPickerGrid(selectedPreset: $popupFontPreset)
                    .frame(width: settingsColumnWidth, alignment: .leading)
            }

            SettingsButton(title: topMenuThemeListOpen ? "Top Menu Theme: \(topMenuThemePreset) ▲" : "Top Menu Theme: \(topMenuThemePreset) ▼", focus: .topMenuThemeToggle, focused: $focused) {
                topMenuThemeListOpen.toggle()
            }
            if topMenuThemeListOpen {
                TopMenuThemePicker(selectedTheme: $topMenuThemePreset)
                    .frame(width: settingsColumnWidth, alignment: .leading)
            }

            SettingsButton(title: topMenuFontListOpen ? "Top Menu Font: \(topMenuFontPreset) ▲" : "Top Menu Font: \(topMenuFontPreset) ▼", focus: .topMenuFontToggle, focused: $focused) {
                topMenuFontListOpen.toggle()
            }
            if topMenuFontListOpen {
                TopMenuFontPicker(selectedPreset: $topMenuFontPreset)
                    .frame(width: settingsColumnWidth, alignment: .leading)
            }

            SettingsButton(title: homeGridThemeListOpen ? "Home Grid Theme: \(homeGridThemePreset) ▲" : "Home Grid Theme: \(homeGridThemePreset) ▼", focus: .homeGridThemeToggle, focused: $focused) {
                homeGridThemeListOpen.toggle()
            }
            if homeGridThemeListOpen {
                HomeGridThemePicker(selectedTheme: $homeGridThemePreset)
                    .frame(width: settingsColumnWidth, alignment: .leading)
            }

            SettingsButton(title: liveTVGridThemeListOpen ? "Live TV Grid Background: \(liveTVGridThemePreset) ▲" : "Live TV Grid Background: \(liveTVGridThemePreset) ▼", focus: .liveTVGridThemeToggle, focused: $focused) {
                liveTVGridThemeListOpen.toggle()
            }
            if liveTVGridThemeListOpen {
                LiveTVGridThemePicker(selectedTheme: $liveTVGridThemePreset)
                    .frame(width: settingsColumnWidth, alignment: .leading)
            }
        }
        .padding(.top, 10)
    }

    private var externalPlayerDefaultsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("External Player Defaults")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Optional. Movies/Shows can launch external apps. Live TV can use AVPlayer as a backup/default; KSPlayer remains the normal default and auto-fallback.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: settingsColumnWidth, alignment: .leading)
            liveToggleButton(title: "Movies default to Infuse", subtitle: "Open movie streams in Infuse when a link starts.", isOn: $externalMoviesInfuseDefault, focus: .extMovieInfuse)
            liveToggleButton(title: "Movies default to VLC App", subtitle: "Open movie streams in the external VLC app.", isOn: $externalMoviesVLCDefault, focus: .extMovieVLC)
            liveToggleButton(title: "Movies default to SenPlayer", subtitle: "Open movie streams in SenPlayer when installed.", isOn: $externalMoviesSenPlayerDefault, focus: .extMovieSen)
            liveToggleButton(title: "Shows default to Infuse", subtitle: "Open episode streams in Infuse when a link starts.", isOn: $externalShowsInfuseDefault, focus: .extShowInfuse)
            liveToggleButton(title: "Shows default to VLC App", subtitle: "Open episode streams in the external VLC app.", isOn: $externalShowsVLCDefault, focus: .extShowVLC)
            liveToggleButton(title: "Shows default to SenPlayer", subtitle: "Open episode streams in SenPlayer when installed.", isOn: $externalShowsSenPlayerDefault, focus: .extShowSen)
            liveToggleButton(title: "Live TV default to AVPlayer", subtitle: "Use AVPlayer as Live TV backup/default. If a channel fails, it falls back to KSPlayer automatically.", isOn: $liveTVUseAVPlayerDefault, focus: .liveAVPlayerDefault)
        }
        .padding(.top, 10)
    }

    private var consumerArtworkSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Artwork & Details")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Artwork and metadata are handled automatically. Optional provider keys can be managed from Owner Tools when needed.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: settingsColumnWidth, alignment: .leading)
            Text("Connected")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.green)
                .padding(.horizontal, 22)
                .padding(.vertical, 12)
                .background(Capsule().fill(Color.white.opacity(0.08)))
        }
        .padding(.top, 10)
    }


    private var iCloudBackupRestoreSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("iCloud Profile Backup")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Backs up Debrid Channels settings, provider URLs, artwork keys, Live TV sources, sports preferences, follow alerts, player preferences, and layout choices to your Apple ID iCloud key-value store.")
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .frame(width: settingsColumnWidth, alignment: .leading)
            VStack(alignment: .leading, spacing: 6) {
                Text("Last Backup: \(iCloudProfileBackupLastDate)")
                    .font(.system(size: 16, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.86))
                Text(iCloudBackupMessage.isEmpty ? iCloudProfileBackupLastStatus : iCloudBackupMessage)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.60))
                    .lineLimit(3)
            }
            .padding(12)
            .frame(width: settingsColumnWidth, alignment: .leading)
            .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.055)))
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.10), lineWidth: 1))
            HStack(spacing: 14) {
                SettingsButton(title: iCloudBackupBusy ? "Working…" : "Backup to iCloud", focus: .iCloudBackupNow, focused: $focused) {
                    runICloudBackup()
                }
                SettingsButton(title: "Restore from iCloud", focus: .iCloudRestoreNow, focused: $focused) {
                    runICloudRestore()
                }
                SettingsButton(title: "Clear iCloud Backup", focus: .iCloudClearNow, focused: $focused) {
                    runICloudClearBackup()
                }
            }
            Text("Restore replaces local settings with the latest iCloud backup on this Apple ID. Clear deletes only the iCloud backup copy for this Apple ID; it does not erase local app settings.")
                .font(.system(size: 12, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.50))
                .frame(width: settingsColumnWidth, alignment: .leading)
        }
        .padding(.top, 6)
    }

    private func runICloudBackup() {
        guard !iCloudBackupBusy else { return }
        iCloudBackupBusy = true
        let payload = currentICloudProfilePayload()
        do {
            let data = try JSONSerialization.data(withJSONObject: payload, options: [.sortedKeys])
            guard data.count < 900_000 else {
                iCloudBackupMessage = "Backup is too large for iCloud key-value sync. Remove oversized source lists or move this profile to file-based iCloud backup later."
                iCloudProfileBackupLastStatus = iCloudBackupMessage
                iCloudBackupBusy = false
                return
            }
            let encoded = data.base64EncodedString()
            let cloud = NSUbiquitousKeyValueStore.default
            cloud.set(encoded, forKey: "DebridChannels.iCloudProfileBackup.v1")
            cloud.set(Date().iso8601String, forKey: "DebridChannels.iCloudProfileBackup.lastDate")
            cloud.synchronize()
            iCloudProfileBackupLastDate = Date().friendlyBackupDate
            iCloudProfileBackupLastStatus = "iCloud backup saved. Restore is available on Apple TVs signed into the same Apple ID."
            iCloudBackupMessage = iCloudProfileBackupLastStatus
        } catch {
            iCloudBackupMessage = "iCloud backup failed: \(error.localizedDescription)"
            iCloudProfileBackupLastStatus = iCloudBackupMessage
        }
        iCloudBackupBusy = false
    }

    private func runICloudRestore() {
        guard !iCloudBackupBusy else { return }
        iCloudBackupBusy = true
        let cloud = NSUbiquitousKeyValueStore.default
        cloud.synchronize()
        guard let encoded = cloud.string(forKey: "DebridChannels.iCloudProfileBackup.v1"), let data = Data(base64Encoded: encoded) else {
            iCloudBackupMessage = "No iCloud backup was found for this Apple ID yet."
            iCloudProfileBackupLastStatus = iCloudBackupMessage
            iCloudBackupBusy = false
            return
        }
        do {
            guard let payload = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                iCloudBackupMessage = "iCloud backup restore failed: backup payload is invalid."
                iCloudProfileBackupLastStatus = iCloudBackupMessage
                iCloudBackupBusy = false
                return
            }
            applyICloudProfilePayload(payload)
            iCloudProfileBackupLastDate = Date().friendlyBackupDate
            iCloudProfileBackupLastStatus = "iCloud backup restored. Restart the app if a source list or layout does not refresh immediately."
            iCloudBackupMessage = iCloudProfileBackupLastStatus
        } catch {
            iCloudBackupMessage = "iCloud backup restore failed: \(error.localizedDescription)"
            iCloudProfileBackupLastStatus = iCloudBackupMessage
        }
        iCloudBackupBusy = false
    }

    private func runICloudClearBackup() {
        guard !iCloudBackupBusy else { return }
        iCloudBackupBusy = true
        let cloud = NSUbiquitousKeyValueStore.default
        cloud.removeObject(forKey: "DebridChannels.iCloudProfileBackup.v1")
        cloud.removeObject(forKey: "DebridChannels.iCloudProfileBackup.lastDate")
        cloud.synchronize()
        iCloudProfileBackupLastDate = "Never"
        iCloudProfileBackupLastStatus = "iCloud backup cleared. Local Debrid Channels settings were not changed."
        iCloudBackupMessage = iCloudProfileBackupLastStatus
        iCloudBackupBusy = false
    }

    private func currentICloudProfilePayload() -> [String: Any] {
        [
            "schema": "DebridChannelsProfileBackup.v1",
            "createdAt": Date().iso8601String,
            "appBuild": "v575_iCloud_CLEAR_AND_SOURCE_SPEED_FIX",
            "settings": [
                "stremioManifestURL": manifestURL,
                "liveChannelsDvrBaseURL": liveChannelsDvrBaseURL,
                "liveHDHomeRunManualURL": liveHDHomeRunManualURL,
                "liveHDHomeRunManualGuideURL": liveHDHomeRunManualGuideURL,
                "liveM3UURL": liveM3UURL,
                "liveXMLTVURL": liveXMLTVURL,
                "liveXtreamServer": liveXtreamServer,
                "liveXtreamUsername": liveXtreamUsername,
                "liveXtreamPassword": liveXtreamPassword,
                "liveXtreamAccounts": liveXtreamAccounts,
                "sportsAssignedGroups": sportsAssignedGroupsRaw,
                "liveXtreamLoginStatus": liveXtreamLoginStatus,
                "sportsXtreamImportMode": sportsXtreamImportMode,
                "sportsFavoriteTeams": sportsFavoriteTeams,
                "sportsCustomSourcesJSON": sportsCustomSourcesJSON,
                "sportsScoreTickerEnabled": sportsScoreTickerEnabled,
                "backendBaseURL": backendBaseURL,
                "tmdbApiKey": tmdbApiKey,
                "fanartTvApiKey": fanartTvApiKey,
                "tvdbApiToken": tvdbApiToken,
                "externalMoviesInfuseDefault": externalMoviesInfuseDefault,
                "externalMoviesVLCDefault": externalMoviesVLCDefault,
                "externalMoviesSenPlayerDefault": externalMoviesSenPlayerDefault,
                "externalShowsInfuseDefault": externalShowsInfuseDefault,
                "externalShowsVLCDefault": externalShowsVLCDefault,
                "externalShowsSenPlayerDefault": externalShowsSenPlayerDefault,
                "liveTVUseAVPlayerDefault": liveTVUseAVPlayerDefault,
                "gridLockedMode": gridLockedMode,
                "trailerPlaybackMode": trailerPlaybackMode,
                "trailerProviderMode": trailerProviderMode,
                "popupFontPreset": popupFontPreset,
                "topMenuThemePreset": topMenuThemePreset,
                "topMenuFontPreset": topMenuFontPreset,
                "homeGridThemePreset": homeGridThemePreset,
                "liveTVGridThemePreset": liveTVGridThemePreset,
                "followAlertsEnabled": followAlertsEnabled,
                "followNewEpisodesEnabled": followNewEpisodesEnabled,
                "followSportsAlertsEnabled": followSportsAlertsEnabled,
                "followPPVAlertsEnabled": followPPVAlertsEnabled,
                "followVerifiedOnly": followVerifiedOnly
            ]
        ]
    }

    private func applyICloudProfilePayload(_ payload: [String: Any]) {
        guard let settings = payload["settings"] as? [String: Any] else { return }
        let defaults = UserDefaults.standard
        for (key, value) in settings {
            defaults.set(value, forKey: key)
        }
        defaults.synchronize()
        manifestURL = settings["stremioManifestURL"] as? String ?? manifestURL
        liveChannelsDvrBaseURL = settings["liveChannelsDvrBaseURL"] as? String ?? liveChannelsDvrBaseURL
        liveHDHomeRunManualURL = settings["liveHDHomeRunManualURL"] as? String ?? liveHDHomeRunManualURL
        liveHDHomeRunManualGuideURL = settings["liveHDHomeRunManualGuideURL"] as? String ?? liveHDHomeRunManualGuideURL
        liveM3UURL = settings["liveM3UURL"] as? String ?? liveM3UURL
        liveXMLTVURL = settings["liveXMLTVURL"] as? String ?? liveXMLTVURL
        liveXtreamServer = settings["liveXtreamServer"] as? String ?? liveXtreamServer
        liveXtreamUsername = settings["liveXtreamUsername"] as? String ?? liveXtreamUsername
        liveXtreamPassword = settings["liveXtreamPassword"] as? String ?? liveXtreamPassword
        liveXtreamAccounts = settings["liveXtreamAccounts"] as? String ?? liveXtreamAccounts
        sportsAssignedGroupsRaw = settings["sportsAssignedGroups"] as? String ?? sportsAssignedGroupsRaw
        liveXtreamLoginStatus = settings["liveXtreamLoginStatus"] as? String ?? liveXtreamLoginStatus
        sportsXtreamImportMode = settings["sportsXtreamImportMode"] as? String ?? sportsXtreamImportMode
        sportsFavoriteTeams = settings["sportsFavoriteTeams"] as? String ?? sportsFavoriteTeams
        sportsCustomSourcesJSON = settings["sportsCustomSourcesJSON"] as? String ?? sportsCustomSourcesJSON
        sportsScoreTickerEnabled = settings["sportsScoreTickerEnabled"] as? Bool ?? sportsScoreTickerEnabled
        backendBaseURL = settings["backendBaseURL"] as? String ?? backendBaseURL
        tmdbApiKey = settings["tmdbApiKey"] as? String ?? tmdbApiKey
        fanartTvApiKey = settings["fanartTvApiKey"] as? String ?? fanartTvApiKey
        tvdbApiToken = settings["tvdbApiToken"] as? String ?? tvdbApiToken
        externalMoviesInfuseDefault = settings["externalMoviesInfuseDefault"] as? Bool ?? externalMoviesInfuseDefault
        externalMoviesVLCDefault = settings["externalMoviesVLCDefault"] as? Bool ?? externalMoviesVLCDefault
        externalMoviesSenPlayerDefault = settings["externalMoviesSenPlayerDefault"] as? Bool ?? externalMoviesSenPlayerDefault
        externalShowsInfuseDefault = settings["externalShowsInfuseDefault"] as? Bool ?? externalShowsInfuseDefault
        externalShowsVLCDefault = settings["externalShowsVLCDefault"] as? Bool ?? externalShowsVLCDefault
        externalShowsSenPlayerDefault = settings["externalShowsSenPlayerDefault"] as? Bool ?? externalShowsSenPlayerDefault
        liveTVUseAVPlayerDefault = settings["liveTVUseAVPlayerDefault"] as? Bool ?? liveTVUseAVPlayerDefault
        gridLockedMode = settings["gridLockedMode"] as? Bool ?? gridLockedMode
        trailerPlaybackMode = settings["trailerPlaybackMode"] as? String ?? trailerPlaybackMode
        trailerProviderMode = settings["trailerProviderMode"] as? String ?? trailerProviderMode
        popupFontPreset = settings["popupFontPreset"] as? String ?? popupFontPreset
        topMenuThemePreset = settings["topMenuThemePreset"] as? String ?? topMenuThemePreset
        topMenuFontPreset = settings["topMenuFontPreset"] as? String ?? topMenuFontPreset
        homeGridThemePreset = settings["homeGridThemePreset"] as? String ?? homeGridThemePreset
        liveTVGridThemePreset = settings["liveTVGridThemePreset"] as? String ?? liveTVGridThemePreset
        followAlertsEnabled = settings["followAlertsEnabled"] as? Bool ?? followAlertsEnabled
        followNewEpisodesEnabled = settings["followNewEpisodesEnabled"] as? Bool ?? followNewEpisodesEnabled
        followSportsAlertsEnabled = settings["followSportsAlertsEnabled"] as? Bool ?? followSportsAlertsEnabled
        followPPVAlertsEnabled = settings["followPPVAlertsEnabled"] as? Bool ?? followPPVAlertsEnabled
        followVerifiedOnly = settings["followVerifiedOnly"] as? Bool ?? followVerifiedOnly
    }

    private var resetOnboardingSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Help")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            SettingsButton(title: "Replay First-Time Setup", focus: .saveArtworkKeys, focused: $focused) {
                UserDefaults.standard.set(false, forKey: "hasSeenFirstRunOnboarding")
                store.status = "First-time setup will replay on next app launch."
            }
        }
        .padding(.top, 10)
    }

    private var aboutCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("About Debrid Channels")
                .font(.system(size: 32, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Debrid Channels is a media browser and player that organizes user-configured catalogs, playlists, live TV sources, and provider connections into one premium TV-first experience.")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.74))
                .frame(width: 1040, alignment: .leading)
            Text("Debrid Channels does not host, store, upload, redistribute, or provide movies, shows, live TV channels, or other content. All content comes from sources and services configured by the user.")
                .font(.system(size: 18, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.66))
                .frame(width: 1040, alignment: .leading)
            Text("Users are responsible for the sources they connect and for following applicable laws and service terms in their region.")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: 1040, alignment: .leading)
            Text("Created by Issac. Thank you for supporting a modern unified streaming experience built for big screens.")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(.orange.opacity(0.85))
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 30).fill(Color.white.opacity(0.052)))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }

    private var artworkKeysSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Artwork Provider Keys")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text("Optional. These improve posters, clearlogos, banners, landscape art, and details across Movies, Shows, and Live TV.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: settingsColumnWidth, alignment: .leading)
            liveTextField("TMDB API key", text: $tmdbApiKey, focus: .tmdbKey)
            liveTextField("Fanart.tv API key", text: $fanartTvApiKey, focus: .fanartKey)
            liveTextField("TVDB API bearer token", text: $tvdbApiToken, focus: .tvdbToken)
            SettingsButton(title: "Save Artwork Keys", focus: .saveArtworkKeys, focused: $focused) {
                Task { await saveArtworkKeysToBackend() }
            }
            Text("Keys are saved securely and used to improve artwork throughout Debrid Channels.")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: settingsColumnWidth, alignment: .leading)
        }
        .padding(.top, 10)
    }

    private func saveArtworkKeysToBackend() async {
        let base = backendBaseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !base.isEmpty, let url = URL(string: base + "/api/artwork/provider-keys") else {
            await MainActor.run { store.status = "Artwork key save failed: connection is not ready." }
            return
        }
        let body: [String: String] = [
            "tmdbApiKey": tmdbApiKey,
            "fanartTvApiKey": fanartTvApiKey,
            "tvdbApiToken": tvdbApiToken
        ]
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
            let (_, response) = try await URLSession.shared.data(for: request)
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            await MainActor.run {
                store.status = (200..<300).contains(code) ? "Artwork provider keys saved." : "Artwork key save failed with HTTP \(code)."
            }
        } catch {
            await MainActor.run { store.status = "Artwork key save failed: \(error.localizedDescription)" }
        }
    }

    private var buildStatusSection: some View { EmptyView() }

    private var quickNavigationCard: some View { EmptyView() }

    private var isXtreamFieldFocused: Bool {
        focused == .liveXtreamServer || focused == .liveXtreamUsername || focused == .liveXtreamPassword
    }

    private func acceptSingleSettingsDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSettingsDpadMoveAt) > 0.32 else { return false }
        lastSettingsDpadMoveAt = now
        return true
    }

    private func routeSettings(_ direction: MoveCommandDirection) {
        switch direction {
        case .right:
            switch focused {
            case .manifest: focused = .add
            case .add: focused = .load
            case .load: focused = .loadAll
            case .loadAll: focused = .reset
            case .liveXtreamServer: focused = .liveXtreamUsername
            case .liveXtreamUsername: focused = .liveXtreamPassword
            case .reset: focused = .liveDvr
            case .home: focused = .movies
            case .movies: focused = .shows
            case .shows: focused = .live
            case .liveXtreamPassword: focused = .liveXtreamLogin
            case .liveXtreamLogin: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeYouTube
            case .trailerModeYouTube: focused = .popupFontToggle
            
            
            
            
            
            case .popupFontToggle: focused = .topMenuThemeToggle
            case .topMenuThemeToggle: focused = .topMenuFontToggle
            case .topMenuFontToggle: focused = .backendBase
            case .backendBase: focused = .tmdbKey
            case .tmdbKey: focused = .fanartKey
            case .fanartKey: focused = .tvdbToken
            case .tvdbToken: focused = .saveArtworkKeys
            case .sportsXtreamFull: focused = .sportsXtreamOnly
            case .sportsXtreamOnly: focused = .sportsXtreamBoth
            case .iCloudBackupNow: focused = .iCloudRestoreNow
            case .iCloudRestoreNow: focused = .iCloudClearNow
            case .sportsXtreamBoth, .sportsTickerToggle, .sportsFavoriteTeams, .sportsM3USources, .iCloudClearNow, .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .homeGridThemeToggle, .liveTVGridThemeToggle, .gridLockedMode, .live, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .saveArtworkKeys, .none: break
            }
        case .left:
            switch focused {
            case .add: focused = .manifest
            case .load: focused = .add
            case .loadAll: focused = .load
            case .reset: focused = .loadAll
            case .liveXtreamUsername: focused = .liveXtreamServer
            case .liveXtreamPassword: focused = .liveXtreamUsername
            case .movies: focused = .home
            case .shows: focused = .movies
            case .live: focused = .shows
            case .backendBase: focused = .topMenuFontToggle
            case .topMenuFontToggle: focused = .topMenuThemeToggle
            case .topMenuThemeToggle: focused = .popupFontToggle
            case .liveXtreamLogin: focused = .liveXtreamPassword
            case .trailerModeAutomatic: focused = .liveXtreamLogin
            case .trailerModeInApp: focused = .trailerModeAutomatic
            case .popupFontToggle: focused = .trailerModeYouTube
            
            
            
            
            
            case .trailerModeYouTube: focused = .trailerModeInApp
            case .tmdbKey: focused = .backendBase
            case .fanartKey: focused = .tmdbKey
            case .tvdbToken: focused = .fanartKey
            case .saveArtworkKeys: focused = .tvdbToken
            case .sportsXtreamBoth: focused = .sportsXtreamOnly
            case .sportsXtreamOnly: focused = .sportsXtreamFull
            case .iCloudClearNow: focused = .iCloudRestoreNow
            case .iCloudRestoreNow: focused = .iCloudBackupNow
            case .sportsXtreamFull, .sportsTickerToggle, .sportsFavoriteTeams, .sportsM3USources, .iCloudBackupNow, .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .homeGridThemeToggle, .liveTVGridThemeToggle, .gridLockedMode, .manifest, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .liveXtreamServer, .home, .none: break
            }
        case .down:
            switch focused {
            case .manifest: focused = .add
            case .add, .load, .loadAll, .reset: focused = .liveDvr
            case .liveDvr: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveM3U
            case .liveM3U: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword, .liveXtreamLogin: focused = .sportsXtreamFull
            case .sportsXtreamFull, .sportsXtreamOnly, .sportsXtreamBoth: focused = .sportsTickerToggle
            case .sportsTickerToggle: focused = .sportsFavoriteTeams
            case .sportsFavoriteTeams: focused = .sportsM3USources
            case .sportsM3USources: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeYouTube
            case .trailerModeYouTube: focused = .popupFontToggle
            
            
            
            
            
            case .popupFontToggle: focused = .topMenuThemeToggle
            case .topMenuThemeToggle: focused = .topMenuFontToggle
            case .topMenuFontToggle: focused = .backendBase
            case .gridLockedMode: focused = .backendBase
            case .backendBase, .tmdbKey, .fanartKey, .tvdbToken: focused = .saveArtworkKeys
            case .saveArtworkKeys: focused = .iCloudBackupNow
            case .iCloudBackupNow: focused = .iCloudRestoreNow
            case .iCloudRestoreNow: focused = .iCloudClearNow
            case .iCloudClearNow: focused = .home
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .homeGridThemeToggle, .liveTVGridThemeToggle, .home, .movies, .shows, .live: break
            case .none: focused = .manifest
            }
        case .up:
            switch focused {
            case .home, .movies, .shows, .live: focused = .iCloudClearNow
            case .iCloudClearNow: focused = .iCloudRestoreNow
            case .iCloudRestoreNow: focused = .iCloudBackupNow
            case .iCloudBackupNow: focused = .saveArtworkKeys
            case .saveArtworkKeys: focused = .backendBase
            case .backendBase, .tmdbKey, .fanartKey, .tvdbToken: focused = .topMenuFontToggle
            case .topMenuFontToggle: focused = .topMenuThemeToggle
            case .topMenuThemeToggle: focused = .popupFontToggle
            case .popupFontToggle: focused = .trailerModeYouTube
            
            
            
            
            
            case .trailerModeYouTube: focused = .trailerModeInApp
            case .trailerModeInApp: focused = .trailerModeAutomatic
            case .trailerModeAutomatic: focused = .sportsM3USources
            case .sportsM3USources: focused = .sportsFavoriteTeams
            case .sportsFavoriteTeams: focused = .sportsTickerToggle
            case .sportsTickerToggle: focused = .sportsXtreamFull
            case .sportsXtreamFull, .sportsXtreamOnly, .sportsXtreamBoth: focused = .liveXtreamServer
            case .gridLockedMode: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword, .liveXtreamLogin: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveM3U
            case .liveM3U: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveDvr
            case .liveDvr: focused = .add
            case .add, .load, .loadAll, .reset: focused = .manifest
            case .extMovieInfuse, .extMovieVLC, .extMovieSen, .extShowInfuse, .extShowVLC, .extShowSen, .liveAVPlayerDefault, .homeGridThemeToggle, .liveTVGridThemeToggle, .manifest: store.menuFocusToken += 1
            case .none: focused = .manifest
            }
        default:
            break
        }
    }
}

struct SettingsCategoryPreviewRow: View {
    let title: String
    let subtitle: String
    let systemImage: String

    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: systemImage)
                .font(.system(size: 26, weight: .black))
                .foregroundStyle(.white.opacity(0.90))
                .frame(width: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.system(size: 30, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.96))
                Text(subtitle)
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.52))
                    .lineLimit(1)
            }
            Spacer(minLength: 10)
            Image(systemName: "chevron.right")
                .font(.system(size: 26, weight: .black))
                .foregroundStyle(.white.opacity(0.42))
        }
        .padding(.horizontal, 24)
        .frame(width: 500, height: 70)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color.white.opacity(0.075)))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

struct SettingsSectionCard<Content: View>: View {
    let title: String
    let subtitle: String
    let systemImage: String
    let content: Content

    init(title: String, subtitle: String, systemImage: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.subtitle = subtitle
        self.systemImage = systemImage
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 14) {
                Image(systemName: systemImage)
                    .font(.system(size: 24, weight: .black))
                    .foregroundStyle(Color.orange.opacity(0.92))
                    .frame(width: 32)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title)
                        .font(.system(size: 28, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.55))
                }
                Spacer()
            }
            content
        }
        .padding(22)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(Color.black.opacity(0.26)))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct SettingsStremioAddonRow: View {
    @EnvironmentObject var store: CatalogStore
    let url: String
    let index: Int
    let totalCount: Int

    private var identity: StremioAddonIdentity? { store.addonIdentities[url] }
    private var label: String {
        if let name = identity?.name, !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return name }
        return URL(string: url)?.host ?? "Stremio JSON"
    }
    private var initials: String {
        let text = label.split(separator: " ").prefix(2).compactMap { $0.first }.map(String.init).joined().uppercased()
        return text.isEmpty ? "S" : text
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Text("#\(index + 1)")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.orange)
                    .frame(width: 36, alignment: .leading)

                ZStack {
                    Circle().fill(Color.black.opacity(0.35))
                    if let icon = identity?.iconURL, !icon.isEmpty {
                        RemoteImageFit(url: icon, mode: .fit)
                            .clipShape(Circle())
                    } else {
                        Text(initials)
                            .font(.system(size: 13, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.92))
                    }
                }
                .frame(width: 36, height: 36)

                VStack(alignment: .leading, spacing: 3) {
                    Text(label)
                        .font(.system(size: 17, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.90))
                        .lineLimit(1)
                    Text(url)
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.55))
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }

            HStack(spacing: 8) {
                CatalogPriorityButton(title: "Top", disabled: index == 0) { store.moveManifestURLToTop(url) }
                CatalogPriorityButton(title: "Up", disabled: index == 0) { store.moveManifestURLUp(url) }
                CatalogPriorityButton(title: "Down", disabled: index >= totalCount - 1) { store.moveManifestURLDown(url) }
                CatalogPriorityButton(title: "Bottom", disabled: index >= totalCount - 1) { store.moveManifestURLToBottom(url) }
                CatalogPriorityButton(title: "Remove", destructive: true, disabled: totalCount <= 1) { store.removeManifestURL(url) }
            }
            .padding(.leading, 48)
        }
        .frame(width: 552, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(index == 0 ? Color.orange.opacity(0.55) : Color.white.opacity(0.08), lineWidth: index == 0 ? 2 : 1))
    }
}

struct CatalogPriorityButton: View {
    let title: String
    var destructive: Bool = false
    var disabled: Bool = false
    let action: () -> Void

    private var titleColor: Color {
        disabled ? Color.white.opacity(0.28) : Color.white
    }

    private var fillColor: Color {
        if disabled { return Color.white.opacity(0.035) }
        return destructive ? Color.red.opacity(0.45) : Color.orange.opacity(0.24)
    }

    private var strokeColor: Color {
        if disabled { return Color.white.opacity(0.04) }
        return destructive ? Color.red.opacity(0.75) : Color.orange.opacity(0.45)
    }

    private var label: some View {
        Text(title)
            .font(.system(size: 13, weight: .black, design: .rounded))
            .foregroundColor(titleColor)
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(Capsule().fill(fillColor))
            .overlay(Capsule().stroke(strokeColor, lineWidth: 1))
    }

    var body: some View {
        Button(action: action) {
            label
        }
        .buttonStyle(.plain)
        .disabled(disabled)
    }
}

struct PopupFontPreview: View {
    let preset: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Preview")
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(Color.orange.opacity(0.90))
            Text("The Mandalorian & Grogu")
                .font(PopupTypography.font(preset, size: 21, weight: .black))
                .foregroundStyle(.white)
                .lineLimit(1)
            Text("2026 • Movie • Adventure • ★ 8.4")
                .font(PopupTypography.font(preset, size: 15, weight: .bold))
                .kerning(PopupTypography.kerning(preset))
                .foregroundStyle(.white.opacity(0.78))
                .lineLimit(1)
            Text("A lone warrior and his young companion cross the outer rim in a cinematic adventure.")
                .font(PopupTypography.font(preset, size: 15, weight: .medium))
                .lineSpacing(PopupTypography.descriptionLineSpacing(preset) * 0.55)
                .foregroundStyle(.white.opacity(0.68))
                .lineLimit(2)
        }
        .padding(16)
        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.075)))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct PopupFontPickerGrid: View {
    @Binding var selectedPreset: String

    private var columns: [GridItem] {
        [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]
    }

    private func select(_ preset: PopupFontPreset) {
        selectedPreset = preset.id
        UserDefaults.standard.set(preset.id, forKey: "popupFontPreset")
    }

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(PopupTypography.presets) { preset in
                PopupFontChoiceButton(preset: preset, selected: selectedPreset == preset.id) {
                    select(preset)
                }
            }
        }
        .padding(.top, 4)
    }
}

struct PopupFontChoiceButton: View {
    let preset: PopupFontPreset
    let selected: Bool
    let action: () -> Void
    @FocusState private var focused: Bool

    private var fill: Color {
        if selected { return Color.cyan.opacity(0.95) }
        if focused { return Color.orange.opacity(0.82) }
        return Color.white.opacity(0.085)
    }

    private var stroke: Color {
        if selected { return Color.white.opacity(0.92) }
        if focused { return Color.orange.opacity(0.95) }
        return Color.white.opacity(0.10)
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: selected ? "checkmark.circle.fill" : "textformat")
                    .font(.system(size: 15, weight: .black))
                    .frame(width: 20)
                VStack(alignment: .leading, spacing: 2) {
                    Text(preset.title)
                        .font(PopupTypography.font(preset.id, size: 15, weight: .black))
                        .lineLimit(1)
                    Text(preset.category.uppercased())
                        .font(.system(size: 9, weight: .black, design: .rounded))
                        .foregroundStyle((selected || focused) ? Color.black.opacity(0.62) : Color.white.opacity(0.52))
                        .lineLimit(1)
                }
                Spacer(minLength: 0)
            }
            .foregroundStyle((selected || focused) ? Color.black : Color.white)
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .frame(height: 56)
            .contentShape(RoundedRectangle(cornerRadius: 14))
            .background(RoundedRectangle(cornerRadius: 14).fill(fill))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(stroke, lineWidth: (selected || focused) ? 2 : 1))
            .shadow(color: focused ? Color.orange.opacity(0.30) : Color.clear, radius: 14, y: 4)
        }
        .buttonStyle(.plain)
        .focused($focused)
        .onTapGesture { action() }
    }
}


struct HomeGridThemeStyle {
    static let themes = ["Classic Glow", "Apple Glass", "Frosted 3D", "Pure Black", "Midnight Blue", "Cinema Gold", "Neon Edge", "Carbon OLED"]

    static func accent(for theme: String) -> Color {
        let key = theme.lowercased()
        if key.contains("gold") { return Color.orange }
        if key.contains("neon") { return Color.cyan }
        if key.contains("blue") { return Color(red: 0.16, green: 0.58, blue: 1.0) }
        if key.contains("black") || key.contains("carbon") { return Color.white.opacity(0.80) }
        if key.contains("apple") || key.contains("frost") { return Color.white.opacity(0.95) }
        return Color(red: 0.16, green: 0.58, blue: 1.0)
    }

    static func focusGlowOpacity(for theme: String) -> Double {
        let key = theme.lowercased()
        if key.contains("black") { return 0.16 }
        if key.contains("frost") || key.contains("apple") { return 0.26 }
        if key.contains("neon") { return 0.54 }
        return 0.36
    }

    static func focusGlowRadius(for theme: String) -> CGFloat {
        let key = theme.lowercased()
        if key.contains("frost") || key.contains("apple") { return 34 }
        if key.contains("neon") { return 38 }
        return 28
    }

    static func blackShadowOpacity(for theme: String) -> Double {
        let key = theme.lowercased()
        if key.contains("black") || key.contains("carbon") { return 0.92 }
        if key.contains("apple") || key.contains("frost") { return 0.68 }
        return 0.82
    }
}

struct HomeGridThemeOverlay: View {
    let theme: String
    let focused: Bool

    var body: some View {
        let key = theme.lowercased()
        ZStack {
            if key.contains("apple") || key.contains("frost") {
                LinearGradient(colors: [Color.white.opacity(focused ? 0.20 : 0.10), Color.white.opacity(0.035), Color.black.opacity(0.30)], startPoint: .topLeading, endPoint: .bottomTrailing)
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(Color.white.opacity(focused ? 0.30 : 0.12), lineWidth: focused ? 1.6 : 1.0)
                    .blur(radius: key.contains("frost") ? 0.6 : 0.0)
            } else if key.contains("black") || key.contains("carbon") {
                LinearGradient(colors: [Color.black.opacity(0.04), Color.black.opacity(focused ? 0.22 : 0.34)], startPoint: .top, endPoint: .bottom)
            } else if key.contains("gold") {
                LinearGradient(colors: [Color.orange.opacity(focused ? 0.16 : 0.06), Color.black.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
            } else if key.contains("neon") {
                LinearGradient(colors: [Color.cyan.opacity(focused ? 0.17 : 0.05), Color.purple.opacity(focused ? 0.10 : 0.03), Color.black.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
            } else if key.contains("blue") {
                LinearGradient(colors: [Color.blue.opacity(focused ? 0.18 : 0.06), Color.black.opacity(0.20)], startPoint: .topLeading, endPoint: .bottomTrailing)
            } else {
                Color.clear
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .allowsHitTesting(false)
    }
}

struct HomeGridThemePicker: View {
    @Binding var selectedTheme: String
    private let columns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(HomeGridThemeStyle.themes, id: \.self) { theme in
                Button {
                    selectedTheme = theme
                    UserDefaults.standard.set(theme, forKey: "homeGridThemePreset")
                    UserDefaults.standard.synchronize()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: selectedTheme == theme ? "checkmark.circle.fill" : "rectangle.stack.fill")
                            .font(.system(size: 15, weight: .black))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(theme)
                                .font(.system(size: 15, weight: .black, design: .rounded))
                                .lineLimit(1)
                            Text(themeSubtitle(theme))
                                .font(.system(size: 10, weight: .heavy, design: .rounded))
                                .foregroundStyle(selectedTheme == theme ? Color.black.opacity(0.62) : Color.white.opacity(0.52))
                                .lineLimit(1)
                        }
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle(selectedTheme == theme ? Color.black : Color.white)
                    .padding(.horizontal, 12)
                    .frame(height: 58)
                    .background(RoundedRectangle(cornerRadius: 15, style: .continuous).fill(selectedTheme == theme ? HomeGridThemeStyle.accent(for: theme).opacity(0.92) : Color.white.opacity(0.085)))
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(selectedTheme == theme ? Color.white.opacity(0.90) : Color.white.opacity(0.10), lineWidth: selectedTheme == theme ? 2 : 1))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }

    private func themeSubtitle(_ theme: String) -> String {
        let key = theme.lowercased()
        if key.contains("apple") { return "glass depth" }
        if key.contains("frost") { return "3D frost" }
        if key.contains("black") { return "all black" }
        if key.contains("gold") { return "cinema accent" }
        if key.contains("neon") { return "bright edge" }
        if key.contains("carbon") { return "dark pro" }
        return "current style"
    }
}

struct LiveTVGridThemeStyle {
    static let themes = ["Classic Dark", "Channels Glass", "Frosted Guide", "Pure Black", "Midnight Blue", "Cinema Gold", "Neon Edge", "Carbon OLED"]
    static func accent(for theme: String) -> Color {
        let key = theme.lowercased()
        if key.contains("gold") { return Color(red: 1.0, green: 0.70, blue: 0.22) }
        if key.contains("neon") { return Color.cyan }
        if key.contains("midnight") { return Color(red: 0.22, green: 0.40, blue: 0.95) }
        if key.contains("frost") { return Color(red: 0.70, green: 0.90, blue: 1.0) }
        if key.contains("glass") { return Color(red: 0.45, green: 0.76, blue: 1.0) }
        if key.contains("carbon") { return Color.white.opacity(0.78) }
        return Color.orange
    }
}

struct LiveTVGridBackgroundThemeView: View {
    let theme: String
    let accent: Color
    let showGuide: Bool

    var body: some View {
        ZStack {
            baseLayer
            effectLayer
            LinearGradient(
                colors: [Color.black.opacity(showGuide ? 0.26 : 0.34), Color.black.opacity(showGuide ? 0.66 : 0.74)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
    }

    @ViewBuilder private var baseLayer: some View {
        let key = theme.lowercased()
        if key.contains("pure black") || key.contains("carbon") {
            Color.black
        } else if key.contains("midnight") {
            LinearGradient(colors: [Color.black, Color(red: 0.015, green: 0.027, blue: 0.070), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
        } else if key.contains("gold") {
            LinearGradient(colors: [Color.black, Color(red: 0.090, green: 0.055, blue: 0.015), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
        } else if key.contains("frost") || key.contains("glass") {
            LinearGradient(colors: [Color(red: 0.010, green: 0.016, blue: 0.024), Color(red: 0.035, green: 0.050, blue: 0.070), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
        } else {
            StaticAppBackground()
        }
    }

    @ViewBuilder private var effectLayer: some View {
        let styleAccent = LiveTVGridThemeStyle.accent(for: theme)
        let key = theme.lowercased()
        if key.contains("pure black") {
            Color.black.opacity(0.92)
        } else {
            ZStack {
                RadialGradient(colors: [accent.opacity(showGuide ? 0.42 : 0.52), .clear], center: .topTrailing, startRadius: 80, endRadius: 980)
                RadialGradient(colors: [styleAccent.opacity(key.contains("carbon") ? 0.16 : 0.24), .clear], center: .bottomLeading, startRadius: 40, endRadius: 880)
                if key.contains("glass") || key.contains("frost") {
                    Rectangle().fill(.ultraThinMaterial).opacity(key.contains("frost") ? 0.18 : 0.10)
                    LinearGradient(colors: [Color.white.opacity(0.075), .clear, Color.white.opacity(0.035)], startPoint: .topLeading, endPoint: .bottomTrailing)
                }
                if key.contains("neon") {
                    Rectangle().stroke(styleAccent.opacity(0.22), lineWidth: 2).blur(radius: 10).padding(26)
                }
            }
        }
    }
}

struct LiveTVGridThemePicker: View {
    @Binding var selectedTheme: String
    var body: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 2), spacing: 10) {
            ForEach(LiveTVGridThemeStyle.themes, id: \.self) { theme in
                Button {
                    selectedTheme = theme
                    UserDefaults.standard.set(theme, forKey: "liveTVGridThemePreset")
                    UserDefaults.standard.synchronize()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: selectedTheme == theme ? "checkmark.circle.fill" : "rectangle.on.rectangle.angled")
                            .font(.system(size: 18, weight: .black))
                            .foregroundStyle(selectedTheme == theme ? Color.black.opacity(0.70) : Color.white.opacity(0.56))
                        Text(theme)
                            .font(.system(size: 15, weight: .black, design: .rounded))
                            .lineLimit(1)
                        Spacer(minLength: 0)
                    }
                    .padding(.horizontal, 13)
                    .padding(.vertical, 11)
                    .foregroundStyle(selectedTheme == theme ? Color.black : Color.white)
                    .background(RoundedRectangle(cornerRadius: 15, style: .continuous).fill(selectedTheme == theme ? LiveTVGridThemeStyle.accent(for: theme).opacity(0.92) : Color.white.opacity(0.085)))
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(selectedTheme == theme ? Color.white.opacity(0.90) : Color.white.opacity(0.10), lineWidth: selectedTheme == theme ? 2 : 1))
                }
                .buttonStyle(.plain)
                .modifier(TransparentTVFocusVisual())
            }
        }
        .padding(.vertical, 4)
    }
}

struct TopMenuThemePicker: View {
    @Binding var selectedTheme: String
    private let themes = [
        "Classic", "Modern Pill", "Apple Glass Pill", "Frosted Pill", "Floating Pill", "Compact Pill", "Ultra Rounded Pill", "Neon Pill", "Dark Pill", "Cinema Pill", "Premium Pill",
        "Glass Rail", "Soft Minimal", "Cinematic", "Channels Style", "Minimal", "Floating Tabs", "Glass Tabs", "Classic TV", "Media Center", "Executive", "Dashboard", "Compact Professional",
        "Vision Style", "OLED", "Titanium", "Carbon", "Midnight", "Platinum", "Sapphire", "Emerald", "Gold Accent", "Orange Accent",
        "Soft Glow", "Pulse Glow", "Breathing Light", "Cinematic Glow", "Neon Edge", "Focus Wave", "Ambient Light", "Dynamic Highlight"
    ]
    private let columns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(themes, id: \.self) { theme in
                Button {
                    selectedTheme = theme
                    UserDefaults.standard.set(theme, forKey: "topMenuThemePreset")
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: selectedTheme == theme ? "checkmark.circle.fill" : "rectangle.roundedtop")
                            .font(.system(size: 15, weight: .black))
                        Text(theme)
                            .font(.system(size: 15, weight: .black, design: .rounded))
                            .lineLimit(1)
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle(selectedTheme == theme ? Color.black : Color.white)
                    .padding(.horizontal, 12)
                    .frame(height: 52)
                    .background(RoundedRectangle(cornerRadius: 15, style: .continuous).fill(selectedTheme == theme ? Color.cyan.opacity(0.92) : Color.white.opacity(0.085)))
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(selectedTheme == theme ? Color.white.opacity(0.90) : Color.white.opacity(0.10), lineWidth: selectedTheme == theme ? 2 : 1))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.top, 4)
    }
}

struct TopMenuFontPicker: View {
    @Binding var selectedPreset: String
    private let columns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(PopupTypography.presets) { preset in
                PopupFontChoiceButton(preset: preset, selected: selectedPreset == preset.id) {
                    selectedPreset = preset.id
                    UserDefaults.standard.set(preset.id, forKey: "topMenuFontPreset")
                }
            }
        }
        .padding(.top, 4)
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}



struct LiveTVChannel: Identifiable, Hashable {
    let id: Int
    let logo: String
    let number: String
    let name: String
    let category: String
    let now: String
    let next: String
    let description: String
    let accent: Color
    var streamURL: String = ""
    var iconURL: String = ""
    var tvgID: String = ""
    var source: String = "Demo"
}

extension LiveTVChannel {
    var bestArtworkURL: String? {
        let cleanIcon = iconURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleanIcon.hasPrefix("http://") || cleanIcon.hasPrefix("https://") { return cleanIcon }
        return nil
    }

    var isXtreamSource: Bool {
        source.lowercased().contains("xtream") || streamURL.lowercased().contains("/live/")
    }
}

struct LiveProgram: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let width: CGFloat
    let isLive: Bool
    var description: String = ""
    var startText: String = ""
    var endText: String = ""
    var imageURL: String = ""
    // v276: keep real guide timing so the renderer uses current/future listings
    // instead of the first programs in the XMLTV file. This fixes partially
    // populated guide rows after real channels load.
    var startDate: Date? = nil
    var endDate: Date? = nil

    var liveProgress: CGFloat {
        guard let startDate, let endDate, endDate > startDate else { return 0.5 }
        let duration = endDate.timeIntervalSince(startDate)
        guard duration > 0 else { return 0.5 }
        let elapsed = Date().timeIntervalSince(startDate)
        return CGFloat(min(max(elapsed / duration, 0.0), 1.0))
    }
}

struct LiveTVLoadedChannel: Identifiable, Hashable, Codable {
    var id: Int
    var logo: String
    var number: String
    var name: String
    var category: String
    var now: String
    var next: String
    var description: String
    var streamURL: String
    var iconURL: String
    var tvgID: String
    var source: String

    func uiChannel() -> LiveTVChannel {
        LiveTVChannel(
            id: id,
            logo: logo,
            number: number,
            name: name,
            category: category,
            now: now,
            next: next,
            description: description,
            accent: LiveTVSourceModel.accent(for: category),
            streamURL: streamURL,
            iconURL: iconURL,
            tvgID: tvgID,
            source: source
        )
    }
}

struct XtreamLiveDraft {
    let streamID: String
    let extensionName: String
    let name: String
    let categoryName: String
    let categoryID: String
    let epgID: String
    let number: String
    let iconURL: String
}

struct XtreamParsedPayload {
    let categoryMap: [String: String]
    let liveRows: [XtreamLiveDraft]
}

@MainActor
final class LiveTVSourceModel: ObservableObject {
    @Published var channels: [LiveTVChannel] = LiveTVScreen.sampleChannels
    @Published var guidePrograms: [String: [LiveProgram]] = [:]
    @Published var status: String = "Live TV demo lineup ready. Configure Channels DVR, M3U/XMLTV, or Xtream in Settings, then reopen Live TV."
    @Published var isLoading: Bool = false

    private let cacheKey = "liveTVLoadedChannelsV165"
    private let guideCacheKey = "liveTVGuideProgramsV191"
    private let lastRefreshKey = "liveTVLastRefreshV191"
    private let refreshTTL: TimeInterval = 3 * 60 * 60
    private let liveGuideDurationSeconds = 43_200
    private let liveGuideMaxProgramRows = 96
    private static var sessionChannels: [LiveTVChannel] = []
    private static var sessionGuidePrograms: [String: [LiveProgram]] = [:]
    private static var sessionStatus: String = ""
    private var hasLoadedThisAppSession = false

    private var shouldRefreshNow: Bool {
        let last = UserDefaults.standard.double(forKey: lastRefreshKey)
        guard last > 0 else { return true }
        return Date().timeIntervalSince1970 - last >= refreshTTL
    }

    func refreshIfNeeded() async {
        loadCachedOrDemo()
        guard !hasLoadedThisAppSession || shouldRefreshNow || channels.isEmpty else {
            status = "Live TV lineup kept loaded • \(channels.count) channels • refreshes after 3 hours or app restart"
            return
        }
        await refreshFromConfiguredSources()
    }

    func forceRefreshGuide() async {
        status = "Force refreshing Live TV guide…"
        UserDefaults.standard.removeObject(forKey: lastRefreshKey)
        Self.sessionChannels = []
        Self.sessionGuidePrograms = [:]
        Self.sessionStatus = ""
        hasLoadedThisAppSession = false
        await refreshFromConfiguredSources()
    }

    // v535: when an Xtream account is changed to Sports Only, the previous Full TV disk/session lineup
    // must be invalidated immediately. Otherwise the Live TV grid can visually keep old Xtream channels
    // until the three-hour cache expires, which makes Sports Only look broken.
    static func invalidatePersistedLineupCacheForSourceModeChange() {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: "liveTVLoadedChannelsV165")
        defaults.removeObject(forKey: "liveTVGuideProgramsV191")
        defaults.removeObject(forKey: "liveTVLastRefreshV191")
        sessionChannels = []
        sessionGuidePrograms = [:]
        sessionStatus = ""
    }

    nonisolated static func accent(for category: String) -> Color {
        switch category.lowercased() {
        case "sports": return .red
        case "news": return .red
        case "kids": return .orange
        case "movies": return .cyan
        case "hd": return .blue
        case "favorites": return .indigo
        case "comedy": return .mint
        default: return .gray
        }
    }

    func loadCachedOrDemo() {
        // v309: keep Live TV guide/channel state alive while the app process is alive.
        // This prevents the guide from disappearing when opening Settings or switching tabs,
        // but intentionally does not persist the guide across force-quit/relaunch.
        if !Self.sessionChannels.isEmpty {
            channels = Self.sessionChannels
            guidePrograms = Self.sessionGuidePrograms
            hasLoadedThisAppSession = true
            status = Self.sessionStatus.ifEmpty("Live TV session retained • \(channels.count) channels • \(guidePrograms.values.reduce(0) { $0 + $1.count }) guide rows")
            return
        }
        guard let data = UserDefaults.standard.data(forKey: cacheKey),
              let saved = try? JSONDecoder().decode([LiveTVLoadedChannel].self, from: data),
              !saved.isEmpty else { return }
        channels = saved.map { $0.uiChannel() }
        // Disk lineup is only a visual placeholder after app restart; the guide is reloaded.
        hasLoadedThisAppSession = false
        status = "Cached Live TV lineup shown while guide reloads • \(channels.count) channels"
    }

    func refreshFromConfiguredSources() async {
        isLoading = true
        defer { isLoading = false }
        let defaults = UserDefaults.standard
        let dvrBase = defaults.string(forKey: "liveChannelsDvrBaseURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManual = defaults.string(forKey: "liveHDHomeRunManualURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManualGuide = defaults.string(forKey: "liveHDHomeRunManualGuideURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let m3uURLs = Self.parseSourceList(defaults.string(forKey: "liveM3UURL") ?? "")
        let xmltvURLs = Self.parseSourceList(defaults.string(forKey: "liveXMLTVURL") ?? "")
        let xtreamAccounts = Self.parseXtreamAccounts(
            saved: defaults.string(forKey: "liveXtreamAccounts") ?? "",
            currentServer: defaults.string(forKey: "liveXtreamServer") ?? "",
            currentUser: defaults.string(forKey: "liveXtreamUsername") ?? "",
            currentPass: defaults.string(forKey: "liveXtreamPassword") ?? ""
        )

        var loaded: [LiveTVChannel] = []
        var messages: [String] = []
        var xmlGuide = ""
        let previousGuidePrograms = guidePrograms
        let hasXtreamAccounts = !xtreamAccounts.isEmpty
        // v537: do not let stale guide rows from another IPTV/XMLTV source bleed into Xtream cards.
        // Xtream guide data is keyed exactly by account/source + stream id/tvg id below.
        if hasXtreamAccounts { guidePrograms = [:] }
        // v309: keep the currently visible guide on screen while a refresh is in flight.
        // Only replace it after new guide data has successfully parsed.

        if !dvrBase.isEmpty {
            let result = await loadChannelsDVR(base: dvrBase, allowAutoScan: false)
            loaded.append(contentsOf: result.channels)
            messages.append(result.message)
            let storedDvrBase = UserDefaults.standard.string(forKey: "liveChannelsDvrBaseURL") ?? dvrBase
            let dvrGuideBase = normalizeServerBase(storedDvrBase, defaultPort: 8089)
            if !dvrGuideBase.isEmpty { xmlGuide = await fetchText("\(dvrGuideBase)/devices/ANY/guide/xmltv?duration=\(liveGuideDurationSeconds)", accept: "application/xml,text/xml,*/*", maxBytes: 512 * 1024 * 1024) ?? xmlGuide }
        }

        if !hdhrManual.isEmpty {
            let hdhr = await loadHDHomeRun(manual: hdhrManual, allowAutoScan: false)
            var hdhrChannels = hdhr.channels
            messages.append(hdhr.message)
            if !hdhrManualGuide.isEmpty,
               let hdhrXML = await fetchText(cappedGuideURL(hdhrManualGuide), accept: "application/xml,text/xml,*/*", maxBytes: 512 * 1024 * 1024) {
                hdhrChannels = applyXMLTVIcons(hdhrXML, to: hdhrChannels, baseURL: urlBase(hdhrManualGuide))
                let hdhrGuide = parseXMLTV(hdhrXML, channels: hdhrChannels)
                for (key, value) in hdhrGuide { guidePrograms[key] = value }
                xmlGuide = xmlGuide.isEmpty ? hdhrXML : xmlGuide
                messages.append("HDHomeRun XMLTV/Gracenotes guide matched \(hdhrGuide.count) channel(s)")
            }
            loaded.append(contentsOf: hdhrChannels)
        }

        for (index, m3uURL) in m3uURLs.enumerated() {
            let m3u = await loadM3U(url: m3uURL, source: m3uURLs.count > 1 ? "M3U/XMLTV #\(index + 1)" : "M3U/XMLTV")
            loaded.append(contentsOf: m3u.channels)
            messages.append(m3u.message)
        }

        var xmlGuideFragments: [String] = []
        for (index, xmltvURL) in xmltvURLs.enumerated() {
            if let fragment = await fetchText(cappedGuideURL(xmltvURL), accept: "application/xml,text/xml,*/*", maxBytes: 128 * 1024 * 1024), !fragment.isEmpty {
                xmlGuideFragments.append(fragment)
                messages.append(xmltvURLs.count > 1 ? "XMLTV #\(index + 1) guide loaded" : "XMLTV guide loaded")
            }
        }
        if !xmlGuideFragments.isEmpty { xmlGuide = xmlGuideFragments.joined(separator: "\n") }

        var xtreamGuideJobs: [(server: String, username: String, password: String, channels: [LiveTVChannel])] = []
        for (index, account) in xtreamAccounts.enumerated() {
            // v541: production rollback for IPTV routing. Xtream always imports into normal Live TV.
            // Sports-only/Both auto-routing is backlogged because it was hiding channels and confusing cache state.
            let sourceLabel = xtreamAccounts.count > 1 ? "Xtream/IPTV #\(index + 1)" : "Xtream/IPTV"
            var xtream = await loadXtream(server: account.server, username: account.username, password: account.password, sourceName: sourceLabel)
            messages.append(xtream.message)
            if !xtream.channels.isEmpty {
                let base = normalizeServerBase(account.server, defaultPort: nil)
                let user = urlQueryEncode(account.username)
                let pass = urlQueryEncode(account.password)
                let xmlURL = "\(base)/xmltv.php?username=\(user)&password=\(pass)"
                if let xtreamXML = await fetchText(xmlURL, accept: "application/xml,text/xml,*/*", maxBytes: 512 * 1024 * 1024, timeout: 75), !xtreamXML.isEmpty {
                    xtream.channels = applyXMLTVIcons(xtreamXML, to: xtream.channels, baseURL: base)
                    xmlGuideFragments.append(xtreamXML)
                    messages.append(xtreamAccounts.count > 1 ? "Xtream #\(index + 1) XMLTV guide loaded" : "Xtream XMLTV guide loaded")
                } else {
                    xtreamGuideJobs.append((account.server, account.username, account.password, xtream.channels))
                    messages.append(xtreamAccounts.count > 1 ? "Xtream #\(index + 1) XMLTV unavailable • native short EPG will load after channels appear" : "Xtream XMLTV unavailable • native short EPG will load after channels appear")
                }
                loaded.append(contentsOf: xtream.channels)
                await commitXtreamChannelsInVisibleBatches(xtream.channels, existing: loaded.filter { !$0.source.hasPrefix("Xtream/IPTV") }, messages: messages)
            }
        }

        var finalized = dedupe(loaded)
        if !xmlGuide.isEmpty {
            finalized = applyXMLTVIcons(xmlGuide, to: finalized, baseURL: !xmltvURLs.isEmpty ? urlBase(xmltvURLs[0]) : (!dvrBase.isEmpty ? normalizeServerBase(dvrBase, defaultPort: 8089) : ""))
            let parsedGuide = parseXMLTV(xmlGuide, channels: finalized)
            if !parsedGuide.isEmpty { guidePrograms = parsedGuide }
            else if !previousGuidePrograms.isEmpty { guidePrograms = previousGuidePrograms }
            let guideCount = guidePrograms.values.reduce(0) { $0 + $1.count }
            if guideCount > 0 { messages.append("Guide matched \(guidePrograms.count) channel(s) / \(guideCount) program(s)") }
        } else if !hasXtreamAccounts && guidePrograms.isEmpty && !previousGuidePrograms.isEmpty {
            guidePrograms = previousGuidePrograms
        }

        if !finalized.isEmpty {
            channels = finalized.sorted { channelSortKey($0.number) < channelSortKey($1.number) || (channelSortKey($0.number) == channelSortKey($1.number) && $0.name < $1.name) }
            let persist = channels.map { LiveTVLoadedChannel(id: $0.id, logo: $0.logo, number: $0.number, name: $0.name, category: $0.category, now: $0.now, next: $0.next, description: $0.description, streamURL: $0.streamURL, iconURL: $0.iconURL, tvgID: $0.tvgID, source: $0.source) }
            if let data = try? JSONEncoder().encode(persist) { UserDefaults.standard.set(data, forKey: cacheKey) }
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: lastRefreshKey)
            hasLoadedThisAppSession = true
            status = messages.joined(separator: " • ").ifEmpty("Loaded \(channels.count) Live TV channels")
            Self.sessionChannels = channels
            Self.sessionGuidePrograms = guidePrograms
            Self.sessionStatus = status
            for job in xtreamGuideJobs {
                Task { await self.loadDeferredXtreamShortGuide(server: job.server, username: job.username, password: job.password, channels: job.channels) }
            }
        } else {
            status = messages.joined(separator: " • ").ifEmpty("No configured Live TV source returned channels. Demo lineup remains visible.")
        }
    }

    private struct XtreamAccount { let server: String; let username: String; let password: String; let mode: String }

    private static func parseSourceList(_ raw: String) -> [String] {
        raw
            .components(separatedBy: CharacterSet(charactersIn: "\n;"))
            .flatMap { segment in segment.components(separatedBy: ",").map { String($0) } }
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .reduce(into: [String]()) { result, item in
                if !result.contains(item) { result.append(item) }
            }
    }

    private static func parseXtreamAccounts(saved: String, currentServer: String, currentUser: String, currentPass: String) -> [XtreamAccount] {
        var accounts: [XtreamAccount] = []
        func add(server: String, user: String, pass: String, mode: String = "Full TV") {
            let s = server.trimmingCharacters(in: .whitespacesAndNewlines)
            let u = user.trimmingCharacters(in: .whitespacesAndNewlines)
            let p = pass.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !s.isEmpty, !u.isEmpty, !p.isEmpty else { return }
            let normalized = normalizeXtreamServerStatic(s)
            if !accounts.contains(where: { $0.server == normalized && $0.username == u }) {
                accounts.append(XtreamAccount(server: normalized, username: u, password: p, mode: mode))
            }
        }
        saved.components(separatedBy: .newlines).forEach { line in
            let parts = line.components(separatedBy: "|")
            if parts.count >= 4 { add(server: parts[0], user: parts[1], pass: parts[2], mode: parts.dropFirst(3).joined(separator: "|")) }
            else if parts.count >= 3 { add(server: parts[0], user: parts[1], pass: parts.dropFirst(2).joined(separator: "|"), mode: "Full TV") }
        }
        add(server: currentServer, user: currentUser, pass: currentPass, mode: "Full TV")
        return accounts
    }


    private static func normalizedXtreamModeStatic(_ raw: String) -> String {
        // v541: auto IPTV sports routing is disabled/backlogged. Keep old saved modes harmless.
        return "Full TV"
    }

    private static func normalizeXtreamServerStatic(_ raw: String) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
        return clean
    }

    private static func retagChannel(_ channel: LiveTVChannel, source: String) -> LiveTVChannel {
        LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: channel.now, next: channel.next, description: channel.description, accent: channel.accent, streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: source)
    }

    private func normalizeServerBase(_ raw: String, defaultPort: Int?) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") {
            clean = "http://" + clean
        }
        guard let defaultPort,
              var components = URLComponents(string: clean),
              components.port == nil,
              let host = components.host,
              !host.isEmpty else { return clean }
        components.port = defaultPort
        return components.string ?? clean
    }

    private func channelsDVRCandidates(rawBase: String, allowAutoScan: Bool) -> [String] {
        let trimmed = rawBase.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        return [normalizeServerBase(trimmed, defaultPort: 8089)]
    }

    private func loadChannelsDVR(base rawBase: String, allowAutoScan: Bool = true) async -> (channels: [LiveTVChannel], message: String) {
        let candidates = channelsDVRCandidates(rawBase: rawBase, allowAutoScan: allowAutoScan)
        var best: ([LiveTVChannel], String)? = nil
        for base in candidates {
        var combined: [LiveTVChannel] = []
        let m3uCandidates = [
            "\(base)/devices/ANY/channels.m3u",
            "\(base)/devices/ANY/channels.m3u?format=ts&codec=copy",
            "\(base)/devices/ANY/channels.m3u?format=ts"
        ]
        for url in m3uCandidates {
            if let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 6 * 1024 * 1024) {
                combined += parseM3U(text, source: "Channels DVR", baseURL: base)
            }
        }

        var devices = await fetchDVRDevices(base: base)
        if !devices.contains("ANY") { devices.append("ANY") }
        for device in devices {
            let encDevice = urlEncode(device)
            if let data = await fetchText("\(base)/devices/\(encDevice)/channels", accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024),
               let list = parseDVRChannelsJSON(data, base: base, device: device), !list.isEmpty {
                combined += list
            }
        }
        let groups = await loadDVRLineupGroups(base: base)
        let mapped = combined.map { channel -> LiveTVChannel in
            let extra = groups.first { _, members in
                members.contains(channel.number.lowercased()) || members.contains(channel.name.lowercased()) || (!channel.tvgID.isEmpty && members.contains(channel.tvgID.lowercased()))
            }?.key
            if let extra, !extra.isEmpty {
                return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: normalizeCategory(extra, fallback: channel.category), now: channel.now, next: channel.next, description: channel.description, accent: Self.accent(for: extra), streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: channel.source)
            }
            return channel
        }
        let out = dedupe(mapped)
        if !out.isEmpty { UserDefaults.standard.set(base, forKey: "liveChannelsDvrBaseURL"); return (out, "Channels DVR native • \(out.count) channel(s) • \(base)") }
        best = (out, "Channels DVR returned no channels at \(base)")
        }
        return best ?? ([], allowAutoScan ? "Channels DVR auto-scan found no server" : "Channels DVR not configured")
    }

    private func loadHDHomeRun(manual: String, allowAutoScan: Bool) async -> (channels: [LiveTVChannel], message: String) {
        var all: [LiveTVChannel] = []
        var messages: [String] = []
        for url in hdHomeRunManualCandidates(manual) {
            if url.lowercased().hasSuffix(".m3u") {
                let m3u = await loadM3U(url: url, source: "HDHomeRun")
                all.append(contentsOf: m3u.channels.map { ch in
                    LiveTVChannel(id: ch.id, logo: ch.logo, number: ch.number, name: ch.name, category: ch.category.ifEmpty("HDHomeRun"), now: ch.now, next: ch.next, description: ch.description, accent: Self.accent(for: ch.category), streamURL: ch.streamURL, iconURL: ch.iconURL, tvgID: ch.tvgID, source: "HDHomeRun")
                })
                messages.append("HDHomeRun manual M3U • \(m3u.channels.count)")
            } else if url.lowercased().hasSuffix(".xml") {
                if let xml = await fetchText(url, accept: "application/xml,text/xml,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunXMLLineup(xml, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual XML • \(parsed.count)")
                }
            } else {
                if let json = await fetchText(url, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual JSON • \(parsed.count)")
                }
            }
        }
        if allowAutoScan {
            let devices = await discoverHDHomeRunDevices()
            for device in devices {
                if let json = await fetchText(device.lineupURL, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: device.baseURL)
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun auto \(device.name) • \(parsed.count)")
                }
            }
            if devices.isEmpty { messages.append("HDHomeRun auto-scan found no devices") }
        }
        let out = dedupe(all)
        return (out, out.isEmpty ? messages.joined(separator: " • ").ifEmpty("HDHomeRun off/no channels") : "HDHomeRun • \(out.count) channel(s) • " + messages.joined(separator: " • "))
    }

    private struct HDHomeRunDeviceCandidate { let name: String; let baseURL: String; let lineupURL: String }

    private func discoverHDHomeRunDevices() async -> [HDHomeRunDeviceCandidate] {
        guard let text = await fetchText("http://my.hdhomerun.com/discover", accept: "application/json,*/*", maxBytes: 512 * 1024),
              let data = text.data(using: .utf8),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.compactMap { obj in
            let base = stringValue(obj, keys: ["BaseURL", "BaseUrl", "baseURL"]).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let lineup = stringValue(obj, keys: ["LineupURL", "LineupUrl", "lineupURL"]).ifEmpty(base.isEmpty ? "" : base + "/lineup.json")
            guard !base.isEmpty, !lineup.isEmpty else { return nil }
            let name = stringValue(obj, keys: ["FriendlyName", "DeviceID", "DeviceId"]).ifEmpty("HDHomeRun")
            return HDHomeRunDeviceCandidate(name: name, baseURL: base, lineupURL: lineup)
        }
    }

    private func hdHomeRunManualCandidates(_ raw: String) -> [String] {
        let tokens = raw.split(whereSeparator: { $0 == "," || $0 == ";" || $0 == "\n" }).map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        var out: [String] = []
        for token in tokens {
            var clean = token
            if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
            let lower = clean.lowercased()
            if lower.hasSuffix("/lineup.json") || lower.hasSuffix("/lineup.m3u") || lower.hasSuffix("/lineup.xml") {
                out.append(clean)
            } else if lower.hasSuffix("/discover.json") {
                let base = String(clean.dropLast("/discover.json".count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            } else {
                let base = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            }
        }
        var seen = Set<String>()
        return out.filter { seen.insert($0).inserted }
    }

    private func parseHDHomeRunJSONLineup(_ json: String, base: String) -> [LiveTVChannel] {
        guard let data = json.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.enumerated().compactMap { index, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Guide", "number", "channel"])
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "CallSign"]).ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = stringValue(obj, keys: ["URL", "StreamURL", "PlayURL", "url"]).ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            guard !stream.isEmpty else { return nil }
            let icon = stringValue(obj, keys: ["ImageURL", "GuideImageURL", "LogoURL", "StationLogo", "IconURL", "logo"])
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func parseHDHomeRunXMLLineup(_ xml: String, base: String) -> [LiveTVChannel] {
        guard let regex = try? NSRegularExpression(pattern: #"<Program[^>]*>(.*?)</Program>"#, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let ns = xml as NSString
        return regex.matches(in: xml, range: NSRange(location: 0, length: ns.length)).enumerated().compactMap { index, match in
            let body = ns.substring(with: match.range(at: 1))
            let number = tagText(body, tag: "GuideNumber")
            let name = tagText(body, tag: "GuideName").ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = tagText(body, tag: "URL").ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            let icon = tagText(body, tag: "ImageURL").ifEmpty(tagText(body, tag: "GuideImageURL")).ifEmpty(tagText(body, tag: "LogoURL")).ifEmpty(tagText(body, tag: "IconURL"))
            guard !stream.isEmpty else { return nil }
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func urlBase(_ raw: String) -> String {
        guard let url = URL(string: raw), let scheme = url.scheme, let host = url.host else { return raw }
        let port = url.port.map { ":\($0)" } ?? ""
        return "\(scheme)://\(host)\(port)"
    }

    private func fetchDVRDevices(base: String) async -> [String] {
        guard let text = await fetchText("\(base)/devices", accept: "application/json,*/*", maxBytes: 512 * 1024), let data = text.data(using: .utf8) else { return [] }
        var names: [String] = []
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            for obj in arr { addDeviceName(from: obj, into: &names) }
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if let arr = obj["devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            if let arr = obj["Devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            addDeviceName(from: obj, into: &names)
        }
        var seen = Set<String>()
        return names.filter { value in
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty && clean.uppercased() != "ANY" else { return false }
            return seen.insert(clean).inserted
        }
    }

    private func addDeviceName(from obj: [String: Any], into names: inout [String]) {
        for key in ["name", "Name", "DeviceID", "DeviceId", "deviceID", "id", "ID"] {
            if let value = obj[key] as? String, !value.isEmpty { names.append(value) }
        }
    }

    private func parseDVRChannelsJSON(_ text: String, base: String, device: String) -> [LiveTVChannel]? {
        guard let data = text.data(using: .utf8) else { return nil }
        let raw: Any?
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            raw = arr
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            raw = obj["channels"] as? [[String: Any]] ?? obj["Channels"] as? [[String: Any]]
        } else { raw = nil }
        guard let arr = raw as? [[String: Any]] else { return nil }
        return arr.enumerated().compactMap { idx, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Number", "number", "channelNumber", "ChannelNumber"])
            let id = stringValue(obj, keys: ["id", "ID", "GuideNumber", "Number", "StationID", "stationID", "TmsId", "tmsId", "GuideID", "guideID"]).ifEmpty(number)
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "channel"]).ifEmpty("Channel \(number.ifEmpty(id.ifEmpty("\(idx+1)")))")
            let playbackKey = number.ifEmpty(id)
            guard !playbackKey.isEmpty else { return nil }
            let url = "\(base)/devices/\(urlEncode(device))/channels/\(urlEncode(playbackKey))/stream.mpg?format=ts&codec=copy"
            let rawIcon = stringValue(obj, keys: ["ImageURL", "Image", "imageUrl", "LogoURL", "logoUrl", "logo", "tvg-logo", "icon", "Icon", "stationLogo", "StationLogo", "Logo", "PreferredImage", "GracenoteLogo", "gracenoteLogo"])
            var icon = absoluteLogoURL(rawIcon, base: base)
            if icon.isEmpty && !id.isEmpty { icon = "\(base)/images/station/\(urlEncode(id))" }
            let category = inferCategory(name: name, explicit: "Channels DVR")
            return makeChannel(name: name, number: number, url: url, source: "Channels DVR", category: category, iconURL: icon, tvgID: id)
        }
    }

    private func loadDVRLineupGroups(base: String) async -> [String: Set<String>] {
        guard let text = await fetchText("\(base)/dvr/lineups", accept: "application/json,*/*", maxBytes: 2 * 1024 * 1024), let data = text.data(using: .utf8) else { return [:] }
        let root = try? JSONSerialization.jsonObject(with: data)
        var entries: [[String: Any]] = []
        if let arr = root as? [[String: Any]] { entries = arr }
        if let obj = root as? [String: Any] {
            entries = (obj["lineups"] as? [[String: Any]]) ?? (obj["Lineups"] as? [[String: Any]]) ?? (obj["items"] as? [[String: Any]]) ?? []
        }
        var result: [String: Set<String>] = [:]
        for obj in entries {
            let name = stringValue(obj, keys: ["name", "Name", "title", "Title", "group", "Group"]).ifEmpty("Channels DVR")
            var members = Set<String>()
            func add(_ any: Any?) {
                if let s = any as? String { members.insert(s.lowercased()) }
                if let n = any as? NSNumber { members.insert(n.stringValue.lowercased()) }
                if let arr = any as? [Any] { arr.forEach { add($0) } }
                if let dict = any as? [String: Any] {
                    for key in ["GuideNumber", "Number", "number", "GuideName", "Name", "name", "id", "ID"] { add(dict[key]) }
                }
            }
            for key in ["channels", "Channels", "members", "Members", "items", "Items"] { add(obj[key]) }
            if !members.isEmpty { result[name] = members }
        }
        return result
    }

    private func loadM3U(url: String, source: String) async -> (channels: [LiveTVChannel], message: String) {
        guard let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 128 * 1024 * 1024, timeout: 60) else { return ([], "M3U failed or timed out") }
        let channels = parseM3U(text, source: source, baseURL: "")
        return (channels, channels.isEmpty ? "M3U returned no channels" : "M3U playlist • \(channels.count) channel(s)")
    }

    private func parseM3U(_ text: String, source: String, baseURL: String) -> [LiveTVChannel] {
        var out: [LiveTVChannel] = []
        var meta = ""
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("#EXTINF") { meta = line; continue }
            if line.isEmpty || line.hasPrefix("#") { continue }
            guard !meta.isEmpty else { continue }
            let name = meta.components(separatedBy: ",").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Channel \(out.count + 1)"
            let tvgName = attr(meta, "tvg-name")
            let displayName = tvgName.ifEmpty(name)
            let group = attr(meta, "group-title")
            let number = attr(meta, "tvg-chno").ifEmpty(attr(meta, "channel-number")).ifEmpty(attr(meta, "ch-number"))
            let tvgId = attr(meta, "tvc-guide-stationid").ifEmpty(attr(meta, "tvg-id")).ifEmpty(attr(meta, "channel-id"))
            let icon = absoluteLogoURL(attr(meta, "tvg-logo").ifEmpty(attr(meta, "logo")).ifEmpty(attr(meta, "x-tvg-url")), base: baseURL)
            out.append(makeChannel(name: displayName, number: number, url: absoluteStreamURL(line, base: baseURL), source: source, category: inferCategory(name: displayName, explicit: group), iconURL: icon, tvgID: tvgId))
            meta = ""
        }
        return out
    }

    private func loadDeferredXtreamShortGuide(server: String, username: String, password: String, channels xtreamChannels: [LiveTVChannel]) async {
        guard !xtreamChannels.isEmpty else { return }
        status = "Xtream Live loaded • loading guide in safe batches…"
        Self.sessionStatus = status
        let parsed = await loadXtreamShortGuidePrograms(server: server, username: username, password: password, channels: xtreamChannels)
        guard !parsed.isEmpty else {
            status = "Xtream Live loaded • guide unavailable or provider returned no current EPG"
            Self.sessionStatus = status
            return
        }
        for (key, value) in parsed { guidePrograms[key] = value }
        applyXtreamGuideToVisibleChannels(parsed)
        Self.sessionGuidePrograms = guidePrograms
        let rows = parsed.values.reduce(0) { $0 + $1.count }
        status = "Xtream Live • \(xtreamChannels.count) channel(s) • native provider EPG matched \(parsed.count) key(s) / \(rows) row(s)"
        Self.sessionStatus = status
    }

    private func commitXtreamChannelsInVisibleBatches(_ xtreamChannels: [LiveTVChannel], existing loaded: [LiveTVChannel], messages: [String]) async {
        guard !xtreamChannels.isEmpty else { return }
        var staged = dedupe(loaded)
        let batchSize = 120
        var committed = 0
        while committed < xtreamChannels.count {
            let nextEnd = min(committed + batchSize, xtreamChannels.count)
            let slice = xtreamChannels[committed..<nextEnd]
            staged = dedupe(staged + Array(slice))
            channels = staged.sorted { channelSortKey($0.number) < channelSortKey($1.number) || (channelSortKey($0.number) == channelSortKey($1.number) && $0.name < $1.name) }
            status = (messages + ["Xtream Live visible batch \(nextEnd)/\(xtreamChannels.count)"]).joined(separator: " • ")
            Self.sessionChannels = channels
            Self.sessionGuidePrograms = guidePrograms
            Self.sessionStatus = status
            try? await Task.sleep(nanoseconds: 25_000_000)
            committed = nextEnd
        }
    }

    private func loadXtreamShortGuidePrograms(server: String, username: String, password: String, channels xtreamChannels: [LiveTVChannel]) async -> [String: [LiveProgram]] {
        let base = normalizeServerBase(server, defaultPort: nil)
        let user = urlQueryEncode(username)
        let pass = urlQueryEncode(password)
        let now = Date()
        let cutoff = now.addingTimeInterval(TimeInterval(liveGuideDurationSeconds))
        var resolved: [String: [LiveProgram]] = [:]
        // v537: use the provider's native Xtream compact EPG pipeline, like IPTV editors do:
        // get_short_epg first, get_simple_data_table second. This stays small per request but
        // covers the full visible tvOS lineup instead of only the first 80 channels.
        let safeChannels = Array(xtreamChannels.prefix(5000))
        var processed = 0
        for channel in safeChannels {
            guard let streamId = xtreamStreamID(from: channel.streamURL), !streamId.isEmpty else { continue }
            let encodedStreamID = urlEncode(streamId)
            let urls = [
                "\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_short_epg&stream_id=\(encodedStreamID)&limit=6",
                "\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_simple_data_table&stream_id=\(encodedStreamID)"
            ]
            var programs: [LiveProgram] = []
            for url in urls {
                guard let text = await fetchText(url, accept: "application/json,*/*", maxBytes: 192 * 1024, timeout: 10),
                      let data = text.data(using: .utf8),
                      let parsedPrograms = parseXtreamShortEPG(data: data, now: now, cutoff: cutoff),
                      !parsedPrograms.isEmpty else { continue }
                programs = parsedPrograms
                break
            }
            guard !programs.isEmpty else { continue }
            for key in xtreamGuideStorageKeys(for: channel) { resolved[key] = programs }
            processed += 1
            if processed % 25 == 0 {
                for (key, value) in resolved { guidePrograms[key] = value }
                applyXtreamGuideToVisibleChannels(resolved)
                Self.sessionGuidePrograms = guidePrograms
                status = "Xtream Live loaded • native EPG loading \(processed)/\(safeChannels.count)…"
                Self.sessionStatus = status
            }
            if resolved.values.reduce(0, { $0 + $1.count }) >= 20000 { break }
        }
        return resolved
    }


    private func xtreamGuideStorageKeys(for channel: LiveTVChannel) -> [String] {
        var keys = Set<String>()
        // v537: Xtream EPG must not be stored under generic channel numbers/names, because
        // that lets stale XMLTV rows from unrelated providers make every Xtream card show
        // the same programme. Keep Xtream guide keys source/account specific.
        keys.insert(channelKey(channel))
        if let streamID = xtreamStreamID(from: channel.streamURL), !streamID.isEmpty {
            keys.insert("xtream-stream:\(channel.source.lowercased()):\(streamID)")
        }
        let tvg = normalizeGuideKey(channel.tvgID)
        if !tvg.isEmpty { keys.insert("xtream-tvg:\(channel.source.lowercased()):\(tvg)") }
        return Array(keys)
    }

    private func xtreamGuideLookupKeys(for channel: LiveTVChannel) -> [String] {
        var keys: [String] = [channelKey(channel)]
        if let streamID = xtreamStreamID(from: channel.streamURL), !streamID.isEmpty {
            keys.append("xtream-stream:\(channel.source.lowercased()):\(streamID)")
        }
        let tvg = normalizeGuideKey(channel.tvgID)
        if !tvg.isEmpty { keys.append("xtream-tvg:\(channel.source.lowercased()):\(tvg)") }
        return keys
    }

    private func applyXtreamGuideToVisibleChannels(_ parsed: [String: [LiveProgram]]) {
        guard !parsed.isEmpty else { return }
        let updated = channels.map { channel -> LiveTVChannel in
            guard channel.isXtreamSource else { return channel }
            let programs = xtreamGuideLookupKeys(for: channel).compactMap { parsed[$0] }.first(where: { !$0.isEmpty })
            guard let programs, let current = programs.first else { return channel }
            let next = programs.dropFirst().first?.title ?? channel.next
            return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: current.title, next: next, description: current.description.ifEmpty(channel.description), accent: channel.accent, streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: channel.source)
        }
        channels = updated
        Self.sessionChannels = updated
        let persist = updated.map { LiveTVLoadedChannel(id: $0.id, logo: $0.logo, number: $0.number, name: $0.name, category: $0.category, now: $0.now, next: $0.next, description: $0.description, streamURL: $0.streamURL, iconURL: $0.iconURL, tvgID: $0.tvgID, source: $0.source) }
        if let data = try? JSONEncoder().encode(persist) { UserDefaults.standard.set(data, forKey: cacheKey) }
    }

    private func xtreamStreamID(from streamURL: String) -> String? {
        guard let url = URL(string: streamURL) else { return nil }
        let last = url.lastPathComponent
        if let dot = last.firstIndex(of: ".") { return String(last[..<dot]) }
        return last.isEmpty ? nil : last
    }

    private func parseXtreamShortEPG(data: Data, now: Date, cutoff: Date) -> [LiveProgram]? {
        guard let root = try? JSONSerialization.jsonObject(with: data) else { return nil }
        var rows: [[String: Any]] = []
        if let obj = root as? [String: Any] {
            rows = (obj["epg_listings"] as? [[String: Any]])
                ?? (obj["listings"] as? [[String: Any]])
                ?? (obj["epg"] as? [[String: Any]])
                ?? (obj["data"] as? [[String: Any]])
                ?? (obj["programmes"] as? [[String: Any]])
                ?? (obj["programs"] as? [[String: Any]])
                ?? []
            if rows.isEmpty, let nested = obj["js"] as? [String: Any] {
                rows = (nested["epg_listings"] as? [[String: Any]]) ?? (nested["data"] as? [[String: Any]]) ?? []
            }
        } else if let arr = root as? [[String: Any]] {
            rows = arr
        }
        guard !rows.isEmpty else { return nil }
        let staleCutoff = now.addingTimeInterval(-10 * 60)
        var out: [LiveProgram] = []
        for row in rows.prefix(12) {
            let title = stringValue(row, keys: ["title", "name", "programme", "program", "program_title", "event", "event_name"])
                .base64DecodedIfPossible()
                .ifEmpty("No information")
            let desc = stringValue(row, keys: ["description", "desc", "plot", "subtitle", "long_description"])
                .base64DecodedIfPossible()
            let start = xtreamEPGDate(stringValue(row, keys: ["start", "start_timestamp", "start_time", "start_time_timestamp", "startTime", "starttime"]))
            let end = xtreamEPGDate(stringValue(row, keys: ["end", "stop", "end_timestamp", "end_time", "stop_time", "stop_timestamp", "endTime", "stoptime"]))
            if let end, end < staleCutoff { continue }
            if let start, start > cutoff { continue }
            let minutes: Int
            if let start, let end, end > start { minutes = max(5, Int(end.timeIntervalSince(start) / 60.0)) }
            else { minutes = 30 }
            let isLive = (start ?? .distantFuture) <= now && now < (end ?? .distantPast)
            let width = CGFloat(max(120, min(560, Int((Double(minutes) / 30.0) * 120.0))))
            out.append(LiveProgram(title: title, width: width, isLive: isLive, description: desc, startText: start?.formatted(date: .omitted, time: .shortened) ?? "", endText: end?.formatted(date: .omitted, time: .shortened) ?? "", imageURL: "", startDate: start, endDate: end))
        }
        return out.sorted { ($0.startDate ?? .distantPast) < ($1.startDate ?? .distantPast) }
    }

    private func xtreamEPGDate(_ raw: String) -> Date? {
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        if let seconds = TimeInterval(value) {
            return Date(timeIntervalSince1970: seconds > 10_000_000_000 ? seconds / 1000.0 : seconds)
        }
        let formats = ["yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm:ss.SSSZ"]
        for format in formats {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "en_US_POSIX")
            formatter.dateFormat = format
            if format == "yyyy-MM-dd HH:mm:ss" { formatter.timeZone = .current }
            if let date = formatter.date(from: value) { return date }
        }
        return nil
    }

    private func loadXtream(server: String, username: String, password: String, sourceName: String = "Xtream/IPTV") async -> (channels: [LiveTVChannel], message: String) {
        let base = normalizeServerBase(server, defaultPort: nil)
        let user = urlQueryEncode(username)
        let pass = urlQueryEncode(password)
        async let categoriesText = fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_categories", accept: "application/json,*/*", maxBytes: 8 * 1024 * 1024, timeout: 25)
        async let liveText = fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_streams", accept: "application/json,*/*", maxBytes: 128 * 1024 * 1024, timeout: 45)
        let parsed = await parseXtreamPayloadOffMain(categoriesText: categoriesText, liveText: liveText)
        guard let parsed, !parsed.liveRows.isEmpty else {
            let fallback = await loadXtreamM3UPlaylist(base: base, user: user, pass: pass)
            if !fallback.isEmpty { return (fallback.map { Self.retagChannel($0, source: sourceName) }, "\(sourceName) Live • \(fallback.count) channel(s) via safe M3U fallback") }
            return ([], "Xtream failed or returned no live channels")
        }
        let channels = parsed.liveRows.prefix(30000).compactMap { draft -> LiveTVChannel? in
            let cat = draft.categoryName.ifEmpty(parsed.categoryMap[draft.categoryID] ?? "IPTV")
            return makeChannel(name: draft.name, number: draft.number, url: "\(base)/live/\(user)/\(pass)/\(draft.streamID).\(draft.extensionName.ifEmpty("m3u8"))", source: sourceName, category: inferCategory(name: draft.name, explicit: cat), iconURL: draft.iconURL, tvgID: draft.epgID)
        }
        return (channels, channels.isEmpty ? "\(sourceName) returned no live channels" : "\(sourceName) Live • \(channels.count) channel(s)")
    }

    private nonisolated func parseXtreamPayloadOffMain(categoriesText: String?, liveText: String?) async -> XtreamParsedPayload? {
        await Task.detached(priority: .userInitiated) {
            var categoryMap: [String: String] = [:]
            if let categoriesText, let data = categoriesText.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
                for obj in arr.prefix(5000) {
                    let id = Self.jsonString(obj, keys: ["category_id"])
                    let name = Self.jsonString(obj, keys: ["category_name"])
                    if !id.isEmpty && !name.isEmpty { categoryMap[id] = name }
                }
            }
            guard let liveText, let data = liveText.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return nil }
            let drafts: [XtreamLiveDraft] = arr.prefix(30000).compactMap { obj in
                let id = Self.jsonString(obj, keys: ["stream_id"])
                guard !id.isEmpty else { return nil }
                return XtreamLiveDraft(
                    streamID: id,
                    extensionName: Self.jsonString(obj, keys: ["container_extension"]).ifEmpty("m3u8"),
                    name: Self.jsonString(obj, keys: ["name"]).ifEmpty("Channel \(id)"),
                    categoryName: Self.jsonString(obj, keys: ["category_name"]),
                    categoryID: Self.jsonString(obj, keys: ["category_id"]),
                    epgID: Self.jsonString(obj, keys: ["epg_channel_id", "epg_id", "tvg_id", "tvg-id", "channel_id", "id"]),
                    number: Self.jsonString(obj, keys: ["num"]),
                    iconURL: Self.jsonString(obj, keys: ["stream_icon"])
                )
            }
            return XtreamParsedPayload(categoryMap: categoryMap, liveRows: drafts)
        }.value
    }

    private nonisolated static func jsonString(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let value = obj[key] as? String { return value.trimmingCharacters(in: .whitespacesAndNewlines) }
            if let value = obj[key] as? NSNumber { return value.stringValue }
            if let value = obj[key] { return "\(value)".trimmingCharacters(in: .whitespacesAndNewlines) }
        }
        return ""
    }

    private func loadXtreamM3UPlaylist(base: String, user: String, pass: String) async -> [LiveTVChannel] {
        let url = "\(base)/get.php?username=\(user)&password=\(pass)&type=m3u_plus&output=m3u8"
        guard let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 128 * 1024 * 1024, timeout: 45) else { return [] }
        let parsed = parseM3U(text, source: "Xtream/IPTV", baseURL: base)
        return Array(parsed.prefix(30000))
    }

    private func makeChannel(name: String, number: String, url: String, source: String, category: String, iconURL: String, tvgID: String) -> LiveTVChannel {
        let cleanLogo = channelLogo(name: name)
        let idSeed = "\(source)|\(number)|\(name)|\(url)".unicodeScalars.reduce(0) { ($0 &* 31 &+ Int($1.value)) & 0x7fffffff }
        return LiveTVChannel(id: max(1, idSeed), logo: cleanLogo, number: number, name: name, category: category, now: name, next: "Guide data loading", description: source, accent: Self.accent(for: category), streamURL: url, iconURL: iconURL, tvgID: tvgID, source: source)
    }

    private func applyXMLTVIcons(_ xml: String, to channels: [LiveTVChannel], baseURL: String = "") -> [LiveTVChannel] {
        let icons = xmltvChannelIcons(xml)
        guard !icons.isEmpty else { return channels }
        return channels.map { channel in
            if !channel.iconURL.isEmpty { return channel }
            let keys = channelMatchingKeys(channel)
            guard let rawIcon = keys.compactMap({ icons[$0] }).first(where: { !$0.isEmpty }) else { return channel }
            let icon = absoluteLogoURL(rawIcon, base: baseURL)
            return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: channel.now, next: channel.next, description: channel.description, accent: channel.accent, streamURL: channel.streamURL, iconURL: icon, tvgID: channel.tvgID, source: channel.source)
        }
    }

    private func xmltvChannelIcons(_ xml: String) -> [String: String] {
        var out: [String: String] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            let icon = firstXMLIcon(in: body)
            guard !icon.isEmpty else { continue }
            var keys = Set<String>()
            for key in xmltvLookupKeys(id) { keys.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { out[key] = icon }
        }
        return out
    }


    private func firstXMLIcon(in body: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<icon[^>]*src=\"([^\"]+)\"[^>]*/?>", options: [.caseInsensitive]) else { return "" }
        let ns = body as NSString
        guard let match = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), match.numberOfRanges > 1 else { return "" }
        return ns.substring(with: match.range(at: 1)).xmlDecoded()
    }

    private func cappedGuideURL(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var components = URLComponents(string: trimmed) else { return trimmed }
        var items = components.queryItems ?? []
        let hasDuration = items.contains { $0.name.lowercased() == "duration" }
        if hasDuration {
            items = items.map { item in
                item.name.lowercased() == "duration" ? URLQueryItem(name: item.name, value: String(liveGuideDurationSeconds)) : item
            }
        } else if trimmed.lowercased().contains("/guide/xmltv") {
            items.append(URLQueryItem(name: "duration", value: String(liveGuideDurationSeconds)))
        }
        components.queryItems = items.isEmpty ? nil : items
        return components.string ?? trimmed
    }

    private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) -> [String: [LiveProgram]] {
        // Ported from Android LiveGuideProgramResolver: do not assume XMLTV
        // attribute order. Channels DVR/XMLTV providers can emit channel/start/stop
        // in different orders, and older tvOS builds missed those programmes.
        var programsByKey: [String: [LiveProgram]] = [:]
        let channelNames = channelLookupNames(xml)
        let programRegex = try? NSRegularExpression(pattern: #"<programme\s+([^>]*)>(.*?)</programme>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        let matches = programRegex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? []
        for match in matches.prefix(1500000) {
            let attrs = ns.substring(with: match.range(at: 1))
            let body = ns.substring(with: match.range(at: 2))
            let channelID = xmlAttr(attrs, "channel")
            guard !channelID.isEmpty else { continue }
            let startRaw = xmlAttr(attrs, "start")
            let stopRaw = xmlAttr(attrs, "stop")
            let title = tagText(body, tag: "title").ifEmpty("No information")
            let desc = tagText(body, tag: "desc")
            let programIcon = firstXMLIcon(in: body)
            let isLive = isProgramLive(startRaw, stopRaw)
            let minutes = durationMinutes(startRaw, stopRaw)
            let width = CGFloat(max(120, min(560, Int((Double(minutes) / 30.0) * 120.0))))
            let startDate = xmltvDate(startRaw)
            let endDate = xmltvDate(stopRaw)
            let program = LiveProgram(title: title, width: width, isLive: isLive, description: desc, startText: guideTimeText(startRaw).ifEmpty(isLive ? "Now" : ""), endText: guideTimeText(stopRaw), imageURL: programIcon, startDate: startDate, endDate: endDate)
            var keys = Set<String>()
            for key in xmltvLookupKeys(channelID) { keys.insert(key) }
            for alias in channelNames[channelID] ?? [] {
                for key in xmltvLookupKeys(alias) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { programsByKey[key, default: []].append(program) }
        }
        var resolved: [String: [LiveProgram]] = [:]
        let now = Date()
        let staleCutoff = now.addingTimeInterval(-10 * 60)
        for channel in channels {
            let keys = channelMatchingKeys(channel)
            if let found = keys.compactMap({ programsByKey[$0] }).first(where: { !$0.isEmpty }) {
                let sorted = found.sorted {
                    ($0.startDate ?? .distantPast) < ($1.startDate ?? .distantPast)
                }
                let guideCutoff = now.addingTimeInterval(TimeInterval(liveGuideDurationSeconds))
                let currentAndUpcoming = sorted.filter { program in
                    if let end = program.endDate, end < staleCutoff { return false }
                    if let start = program.startDate, start > guideCutoff { return false }
                    return true
                }
                resolved[channelKey(channel)] = Array((currentAndUpcoming.isEmpty ? sorted : currentAndUpcoming).prefix(liveGuideMaxProgramRows))
            }
        }
        return resolved
    }


    private func isProgramLive(_ start: String, _ stop: String) -> Bool {
        guard let s = xmltvDate(start), let e = xmltvDate(stop) else { return false }
        let now = Date()
        return s <= now && now < e
    }

    private func guideTimeText(_ raw: String) -> String {
        guard let date = xmltvDate(raw) else { return "" }
        return date.formatted(date: .omitted, time: .shortened)
    }

    private func xmltvDate(_ raw: String) -> Date? {
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }
        if let epoch = Double(cleaned) {
            let seconds = epoch > 100_000_000_000 ? epoch / 1000.0 : epoch
            return Date(timeIntervalSince1970: seconds)
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss Z", "yyyyMMddHHmmssZ", "yyyyMMddHHmmss", "yyyyMMddHHmm Z", "yyyyMMddHHmmZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: cleaned) { return date }
        }
        return nil
    }

    private func durationMinutes(_ start: String, _ stop: String) -> Int {
        guard let s = xmltvDate(start), let e = xmltvDate(stop), e > s else { return 30 }
        return max(15, min(240, Int(e.timeIntervalSince(s) / 60.0)))
    }

    private func xmlAttr(_ attrs: String, _ name: String) -> String {
        let escaped = NSRegularExpression.escapedPattern(for: name)
        guard let regex = try? NSRegularExpression(pattern: "(?:^|\\s)" + escaped + "=\\\"([^\\\"]*)\\\"", options: [.caseInsensitive]) else { return "" }
        let ns = attrs as NSString
        guard let m = regex.firstMatch(in: attrs, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func xmltvLookupKeys(_ raw: String) -> [String] {
        let value = raw.xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return [] }
        var keys = Set<String>()
        func add(_ candidate: String) {
            let clean = candidate.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty else { return }
            keys.insert(clean.lowercased())
            let normalized = normalizeGuideKey(clean)
            if !normalized.isEmpty { keys.insert(normalized) }
        }
        add(value)
        add(value.replacingOccurrences(of: ".", with: "-"))
        add(value.replacingOccurrences(of: "-", with: "."))
        add(value.replacingOccurrences(of: "_", with: "."))
        add(value.components(separatedBy: ".").first ?? value)
        add(value.components(separatedBy: "-").first ?? value)
        if let digitMatch = value.range(of: #"[0-9]{3,}"#, options: .regularExpression) {
            add(String(value[digitMatch]))
        }
        if let match = value.range(of: #"^([0-9]+(?:[.\-_][0-9]+)?)\s+(.+)$"#, options: .regularExpression) {
            let pair = String(value[match]).split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
            if let first = pair.first {
                add(String(first))
                add(String(first).replacingOccurrences(of: "-", with: "."))
                add(String(first).replacingOccurrences(of: ".", with: "-"))
            }
            if pair.count > 1 { add(String(pair[1])) }
        }
        return Array(keys)
    }

    private func normalizeGuideKey(_ value: String) -> String {
        var clean = value.lowercased()
        for token in ["fhd", "uhd", "4k", "hd"] { clean = clean.replacingOccurrences(of: token, with: "") }
        return clean.components(separatedBy: CharacterSet.alphanumerics.inverted).joined()
    }


    private func channelLookupNames(_ xml: String) -> [String: Set<String>] {
        var out: [String: Set<String>] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            var names = Set<String>()
            for key in xmltvLookupKeys(id) { names.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { names.insert(key) }
                let parts = display.split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
                if let first = parts.first { for key in xmltvLookupKeys(String(first)) { names.insert(key) } }
                if parts.count > 1 { for key in xmltvLookupKeys(String(parts[1])) { names.insert(key) } }
            }
            out[id] = names
        }
        return out
    }


    func programs(for channel: LiveTVChannel) -> [LiveProgram] {
        if channel.isXtreamSource {
            for key in xtreamGuideLookupKeys(for: channel) {
                if let direct = guidePrograms[key], !direct.isEmpty { return direct }
            }
            return [
                LiveProgram(title: "No Xtream EPG returned yet", width: 300, isLive: true, description: "Waiting for provider XMLTV or native short EPG for this stream.", startText: "Now", endText: ""),
                LiveProgram(title: "Guide data loading", width: 360, isLive: false, description: channel.description, startText: "+30m", endText: "")
            ]
        }
        for key in channelMatchingKeys(channel) {
            if let direct = guidePrograms[key], !direct.isEmpty { return direct }
        }
        let legacyKey = channelKey(channel)
        if let direct = guidePrograms[legacyKey], !direct.isEmpty { return direct }
        return [
            LiveProgram(title: channel.now, width: 240, isLive: true, description: channel.description, startText: "Now", endText: ""),
            LiveProgram(title: channel.next, width: 360, isLive: false, description: channel.description, startText: "+30m", endText: ""),
            LiveProgram(title: channel.category == "Sports" ? "Live Sports" : channel.now, width: 300, isLive: false, description: channel.description),
            LiveProgram(title: channel.category == "Movies" ? "Feature Presentation" : channel.next, width: 330, isLive: false, description: channel.description)
        ]
    }

    func currentProgram(for channel: LiveTVChannel) -> LiveProgram? {
        programs(for: channel).first
    }

    private func channelMatchingKeys(_ channel: LiveTVChannel) -> [String] {
        var keys = Set<String>()
        for raw in [channel.tvgID, channel.number, channel.name, channel.logo, "\(channel.number) \(channel.name)", "\(channel.number) \(channel.logo)", "\(channel.logo) \(channel.number)", "\(channel.name) \(channel.number)"] {
            for key in xmltvLookupKeys(raw) { keys.insert(key) }
        }
        return Array(keys)
    }


    private func channelKey(_ channel: LiveTVChannel) -> String { "\(channel.source)|\(channel.number)|\(channel.name)".lowercased() }

    private func dedupe(_ channels: [LiveTVChannel]) -> [LiveTVChannel] {
        var seen = Set<String>()
        var out: [LiveTVChannel] = []
        for channel in channels {
            let key = !channel.streamURL.isEmpty ? "url:\(channel.streamURL)" : (!channel.number.isEmpty ? "source-num:\(channel.source.lowercased()):\(channel.number)" : "source-name:\(channel.source.lowercased()):\(channel.name.lowercased())")
            if seen.insert(key).inserted { out.append(channel) }
        }
        return out
    }

    private func fetchText(_ urlString: String, accept: String = "*/*", maxBytes: Int = 4 * 1024 * 1024, timeout: TimeInterval = 45) async -> String? {
        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url, timeoutInterval: timeout)
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")
        do {
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: accept, userAgent: "DebridChannels-tvOS/560", maxBytes: maxBytes, timeout: timeout)
                guard (200...299).contains(plain.statusCode) else { return nil }
                return String(data: plain.data, encoding: .utf8)
            }
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            return String(data: Data(data.prefix(maxBytes)), encoding: .utf8)
        } catch { return nil }
    }

    private func attr(_ meta: String, _ key: String) -> String {
        let pattern = "(?:^|\\s)" + NSRegularExpression.escapedPattern(for: key) + "=\"([^\"]*)\""
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return "" }
        let ns = meta as NSString
        guard let m = regex.firstMatch(in: meta, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func stringValue(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let s = obj[key] as? String, !s.isEmpty { return s }
            if let n = obj[key] as? NSNumber { return n.stringValue }
        }
        return ""
    }

    private func tagText(_ body: String, tag: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<\(tag)[^>]*>(.*?)</\(tag)>", options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return "" }
        let ns = body as NSString
        guard let m = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded()
    }

    private func channelLogo(name: String) -> String {
        let words = name.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }
        if words.count >= 2 { return words.prefix(2).compactMap { $0.first.map(String.init) }.joined().uppercased() }
        return String(name.prefix(8)).uppercased()
    }

    private func inferCategory(name: String, explicit: String) -> String {
        let cleaned = explicit.split(separator: ";").first.map(String.init) ?? explicit
        if !cleaned.isEmpty && cleaned.lowercased() != "channels dvr" && cleaned.lowercased() != "iptv" { return normalizeCategory(cleaned, fallback: cleaned) }
        return normalizeCategory("", fallback: name)
    }

    private func normalizeCategory(_ raw: String, fallback: String) -> String {
        let lower = (raw + " " + fallback).lowercased()
        if lower.contains("sport") || lower.contains("sports") || lower.contains("ppv") || lower.contains("event") || lower.contains("nfl") || lower.contains("nba") || lower.contains("mlb") || lower.contains("nhl") || lower.contains("ufc") || lower.contains("wwe") || lower.contains("espn") || lower.contains("bein") || lower.contains("sky sports") || lower.contains("tnt sports") || lower.contains("dazn") { return "Sports" }
        if lower.contains("news") || lower.contains("cnn") || lower.contains("msnbc") { return "News" }
        if lower.contains("kid") || lower.contains("cartoon") || lower.contains("disney") || lower.contains("nick") { return "Kids" }
        if lower.contains("movie") || lower.contains("hbo") || lower.contains("cinema") || lower.contains("starz") { return "Movies" }
        if lower.contains("favorite") { return "Favorites" }
        if lower.contains("hd") { return "HD" }
        if lower.contains("drama") { return "Drama" }
        return raw.isEmpty ? "All" : raw
    }

    private func absoluteLogoURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func absoluteStreamURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func urlEncode(_ value: String) -> String { value.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? value }
    private func urlQueryEncode(_ value: String) -> String {
        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "+&=?#%")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }
    private func channelSortKey(_ value: String) -> Double { Double(value.replacingOccurrences(of: ".", with: ".").components(separatedBy: CharacterSet(charactersIn: "0123456789.").inverted).joined()) ?? Double.greatestFiniteMagnitude }
}

private extension String {
    func ifEmpty(_ replacement: String) -> String { isEmpty ? replacement : self }
    func xmlDecoded() -> String {
        replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
    }
    func base64DecodedIfPossible() -> String {
        let trimmed = trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 8,
              trimmed.range(of: #"^[A-Za-z0-9+/=]+$"#, options: .regularExpression) != nil,
              let data = Data(base64Encoded: trimmed),
              let decoded = String(data: data, encoding: .utf8),
              !decoded.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return self }
        return decoded.xmlDecoded()
    }
}

private enum LiveTVTheme {
    static let glassAccent = Color(red: 0.035, green: 0.043, blue: 0.052)
    static let glassPanel = Color.white.opacity(0.062)
    static let glassPanelFocused = Color.white.opacity(0.118)
    static let glassStroke = Color.white.opacity(0.105)
    static let liveProgram = Color.white.opacity(0.72)
    static let liveProgramText = Color.white.opacity(0.92)
}


struct GridLockedDockPoster: View {
    let item: MediaItem
    let index: Int
    let isFocused: Bool

    private var w: CGFloat { isFocused ? 292 : 258 }
    private var h: CGFloat { isFocused ? 164 : 146 }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Color.black.opacity(0.34)
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            LinearGradient(colors: [.clear, Color.black.opacity(isFocused ? 0.78 : 0.64)], startPoint: .center, endPoint: .bottom)
            Text(item.title)
                .font(.system(size: isFocused ? 16 : 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(1)
                .padding(.horizontal, isFocused ? 14 : 10)
                .padding(.bottom, isFocused ? 12 : 9)
        }
        .frame(width: w, height: h)
        .clipShape(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous).stroke(isFocused ? Color.white.opacity(0.86) : Color.white.opacity(0.10), lineWidth: isFocused ? 3 : 1))
        .shadow(color: .black.opacity(isFocused ? 0.72 : 0.40), radius: isFocused ? 18 : 8, y: isFocused ? 10 : 5)
        .scaleEffect(isFocused ? 1.02 : 1.0)
        .animation(.spring(response: 0.30, dampingFraction: 0.88), value: isFocused)
    }
}
struct LiveTVScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("gridLockedMode") private var gridLockedModeStored: Bool = false
    private var gridLockedMode: Bool { false }
    @StateObject private var liveModel = LiveTVSourceModel()
    private let baseCategories = ["All", "My Favorites", "HD", "Favorites", "Sports", "Drama", "News", "Kids"]
    @AppStorage("myFavoriteChannelIds") private var myFavoriteChannelIdsRaw: String = ""
    @AppStorage("sportsAssignedGroups") private var sportsAssignedGroupsRaw: String = ""
    @AppStorage("sportsManualChannelIds") private var sportsManualChannelIdsRaw: String = ""
    @AppStorage("liveTVGridThemePreset") private var liveTVGridThemePreset: String = "Classic Dark"

    @State private var selectedCategory: String = "All"
    @State private var selectedChannelID: Int = 6003
    @State private var showGuide: Bool = false
    @FocusState private var categoryFocus: String?
    @FocusState private var tileFocus: Int?
    @FocusState private var guideFocus: Int?
    @State private var lastDpadMoveAt: Date = .distantPast
    @State private var lastSelectAt: Date = .distantPast
    @State private var rightEdgeGuideArmedTileID: Int? = nil
    @State private var leftEdgePanelArmedTileID: Int? = nil
    @State private var leftEdgePanelArmedAt: Date = .distantPast
    @State private var quickWindowVisible: Bool = false
    @State private var quickWindowHideToken: Int = 0
    @State private var previewChannelID: Int? = nil
    @State private var previewWarmupToken: Int = 0
    @State private var previewPlaybackSuppressed: Bool = false
    @State private var renderedChannelLimit: Int = 240
    @State private var renderedWindowStart: Int = 0
    @FocusState private var quickPanelFocus: Bool
    @FocusState private var quickPanelItemFocus: Int?
    @State private var quickPanelSelectionIndex: Int = 0
    @State private var lastQuickPanelMoveAt: Date = .distantPast
    @State private var guideHintVisible: Bool = true
    @State private var guideHintHideTask: Task<Void, Never>? = nil
    @FocusState private var gridLockedDockFocus: Int?
    @State private var gridLockedDockRowIndex: Int = 0
    @State private var gridLockedDockLocked: Bool = false

    private var categories: [String] {
        var set = baseCategories
        for cat in liveModel.channels.map(\.category) where !cat.isEmpty && cat != "Movies" && !set.contains(cat) { set.append(cat) }
        return set
    }

    private var myFavoriteChannelIDs: Set<Int> {
        Set(myFavoriteChannelIdsRaw.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespacesAndNewlines)) })
    }

    private var sportsAssignedGroups: Set<String> {
        Set(sportsAssignedGroupsRaw.split(separator: "|").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty })
    }

    private var sportsManualChannelIDs: Set<Int> {
        Set(sportsManualChannelIdsRaw.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespacesAndNewlines)) })
    }

    private var visibleChannels: [LiveTVChannel] {
        if selectedCategory == "All" { return liveModel.channels }
        if selectedCategory == "My Favorites" { return liveModel.channels.filter { myFavoriteChannelIDs.contains($0.id) } }
        if selectedCategory == "HD" { return liveModel.channels.filter { $0.category == "HD" || Int($0.number) ?? 0 >= 6000 || $0.name.localizedCaseInsensitiveContains("HD") } }
        return liveModel.channels.filter { $0.category == selectedCategory }
    }

    private var renderedChannels: [LiveTVChannel] {
        // v331: keep the tvOS Focus Engine away from thousands of focusable grid cells.
        // The provider/source layer may hold thousands of channels, but the visible SwiftUI
        // grid only receives a moving window around the focused channel.
        let source = visibleChannels
        guard source.count > renderedChannelLimit else { return source }
        let maxStart = max(0, source.count - renderedChannelLimit)
        let start = min(max(renderedWindowStart, 0), maxStart)
        let end = min(source.count, start + renderedChannelLimit)
        return Array(source[start..<end])
    }

    private var selectedChannel: LiveTVChannel {
        liveModel.channels.first(where: { $0.id == selectedChannelID }) ?? liveModel.channels.first ?? LiveTVScreen.sampleChannels[0]
    }

    private var previewChannel: LiveTVChannel {
        liveModel.channels.first(where: { $0.id == previewChannelID }) ?? selectedChannel
    }

    private var isFocusedTileLastBoxInRow: Bool {
        let focused = tileFocus ?? selectedChannelID
        guard let index = visibleChannels.firstIndex(where: { $0.id == focused }) else { return false }
        return ((index + 1) % 4 == 0) || index == visibleChannels.count - 1
    }

    private var isFocusedTileFirstBoxInRow: Bool {
        let focused = tileFocus ?? selectedChannelID
        guard let index = visibleChannels.firstIndex(where: { $0.id == focused }) else { return false }
        return index % 4 == 0
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                liveBackground(channel: selectedChannel)

                VStack(alignment: .leading, spacing: 18) {
                    if showGuide {
                        guideView(size: geo.size)
                            .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .opacity))
                            .padding(.horizontal, 52)
                            .padding(.top, 112)
                    } else {
                        liveGrid(size: geo.size)
                            .padding(.leading, gridLockedMode ? 398 : 72)
                            .padding(.trailing, 76)
                            .padding(.top, gridLockedMode ? 92 : 132)
                    }
                }
                .animation(.spring(response: 0.42, dampingFraction: 0.88), value: quickWindowVisible)
                // v252: when the left guide tools panel is open, freeze the grid behind it.
                // The panel owns DPAD movement so background rows cannot scroll or steal focus.
                .disabled(quickWindowVisible)
                .allowsHitTesting(!quickWindowVisible)

                if !showGuide {
                    gridQuickControlWindow(size: geo.size)
                        .offset(x: quickWindowVisible || gridLockedMode ? 0 : -390)
                        .opacity(quickWindowVisible || gridLockedMode ? 1.0 : 0.0)
                        .allowsHitTesting(quickWindowVisible)
                        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: quickWindowVisible)
                        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: gridLockedMode)
                        .zIndex(1800)
                    if gridLockedMode {
                        gridLockedCatalogDock(size: geo.size)
                            .allowsHitTesting(store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                            .zIndex(1200)
                    }
                }

                if liveModel.isLoading {
                    ProgressView()
                        .tint(.white)
                        .position(x: geo.size.width - 120, y: 92)
                }

                if !showGuide && guideHintVisible {
                    guideHint
                        .position(x: geo.size.width - 210, y: 132)
                        .transition(.opacity.combined(with: .move(edge: .trailing)))
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .focusSection()
            .onAppear {
                gridLockedModeStored = false
                if store.selectedTab != .live { store.selectedTab = .live }
                liveModel.loadCachedOrDemo()
                categoryFocus = selectedCategory
                tileFocus = selectedChannelID
                quickWindowVisible = false
                store.liveQuickPanelOpen = false
                quickPanelFocus = false
                leftEdgePanelArmedTileID = nil
                leftEdgePanelArmedAt = .distantPast
                previewChannelID = nil
                resetVirtualChannelWindow(to: selectedChannelID)
                scheduleGuideHintAutoHide()
                Task {
                    await liveModel.refreshIfNeeded()
                    if let first = visibleChannels.first, selectedChannelID == LiveTVScreen.sampleChannels[0].id {
                        selectedChannelID = first.id
                        tileFocus = first.id
                    }
                }
            }
            .onChange(of: store.onboardingForceFullGuide) { value in
                guard store.onboardingTourActive else { return }
                withAnimation(.spring(response: 0.36, dampingFraction: 0.86)) {
                    showGuide = value
                    quickWindowVisible = false
                    store.liveQuickPanelOpen = false
                    guideFocus = selectedChannelID
                    tileFocus = selectedChannelID
                    rightEdgeGuideArmedTileID = nil
                    leftEdgePanelArmedTileID = nil
                    leftEdgePanelArmedAt = .distantPast
                }
                if value { scheduleLivePreviewWarmup(immediate: true) }
            }
            .onDisappear {
                guideHintHideTask?.cancel()
            }
            .onMoveCommand { direction in
                routeLiveSpecialMove(direction)
            }
            .onChange(of: selectedChannelID) { _ in
                keepFocusedChannelInVirtualWindow()
                scheduleLivePreviewWarmup()
            }
            .onChange(of: guideFocus) { value in
                guard showGuide, let value else { return }
                selectedChannelID = value
                scheduleLivePreviewWarmup(immediate: false)
            }
            .onChange(of: showGuide) { value in
                if value {
                    scheduleLivePreviewWarmup(immediate: true)
                } else {
                    previewWarmupToken += 1
                    previewChannelID = nil
                }
            }
            .onChange(of: store.selectedTab) { tab in
                guard gridLockedMode else { return }
                if tab == .home || tab == .movies || tab == .shows {
                    quickWindowVisible = false
                    store.liveQuickPanelOpen = false
                    tileFocus = nil
                    gridLockedDockRowIndex = 0
                    gridLockedDockFocus = 0
                    gridLockedDockLocked = true
                } else if tab == .live {
                    gridLockedDockFocus = nil
                    gridLockedDockLocked = false
                    tileFocus = selectedChannelID
                }
            }
        }
        .background(Color.black.ignoresSafeArea())
    }


    private func acceptSingleDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastDpadMoveAt) > 0.32 else { return false }
        lastDpadMoveAt = now
        return true
    }

    private func acceptSingleSelect() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSelectAt) > 0.30 else { return false }
        lastSelectAt = now
        return true
    }

    private func acceptSingleQuickPanelStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastQuickPanelMoveAt) > 0.42 else { return false }
        lastQuickPanelMoveAt = now
        return true
    }

    private func routeLiveSpecialMove(_ direction: MoveCommandDirection) {
        // v182: native tvOS focus owns normal DPAD movement. Debrid Channels only
        // handles intentional mode transitions. RIGHT on the final grid tile now arms
        // the guide on the first edge press and opens it on the second edge press, so
        // landing on the last channel no longer throws the user straight into guide.
        if showGuide {
            guard direction == .left, acceptSingleDpadStep() else { return }
            if let focusedCategory = categoryFocus, focusedCategory != "All" { return }
            withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                showGuide = false
                tileFocus = selectedChannelID
                rightEdgeGuideArmedTileID = nil
            }
            return
        }

        if gridLockedMode, gridLockedDockLocked || ((store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows) && gridLockedDockFocus != nil) {
            guard acceptSingleQuickPanelStep() else { return }
            switch direction {
            case .up:
                // v430: Grid Locked dock owns vertical focus. At the first dock row,
                // UP must not dump focus back into Live TV or make scrolling stop.
                if gridLockedDockRowIndex > 0 {
                    gridLockedDockRowIndex -= 1
                }
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            case .down:
                gridLockedDockRowIndex = min(gridLockedDockRowIndex + 1, 6)
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            case .left:
                gridLockedDockFocus = max(0, (gridLockedDockFocus ?? 0) - 1)
            case .right:
                gridLockedDockFocus = min(7, (gridLockedDockFocus ?? 0) + 1)
            @unknown default:
                break
            }
            return
        }

        if quickWindowVisible {
            guard acceptSingleQuickPanelStep() else { return }
            switch direction {
            case .left, .right:
                closeQuickWindow()
            case .up:
                quickPanelSelectionIndex = max(0, quickPanelSelectionIndex - 1)
                quickPanelItemFocus = quickPanelSelectionIndex
            case .down:
                quickPanelSelectionIndex = min(quickPanelItemCount - 1, quickPanelSelectionIndex + 1)
                quickPanelItemFocus = quickPanelSelectionIndex
            @unknown default:
                break
            }
            return
        }

        if direction == .left {
            rightEdgeGuideArmedTileID = nil
            let focusedID = tileFocus ?? selectedChannelID
            guard isFocusedTileFirstBoxInRow else {
                leftEdgePanelArmedTileID = nil
                leftEdgePanelArmedAt = .distantPast
                return
            }
            selectedChannelID = focusedID
            tileFocus = focusedID
            // v247: restore the older visible left bar, but keep the requested forced action.
            // First LEFT only arms/re-focuses the first tile. The next LEFT on that same
            // first-column tile opens the menu, matching the RIGHT-edge full-guide behavior.
            let isSecondLeft = leftEdgePanelArmedTileID == focusedID && Date().timeIntervalSince(leftEdgePanelArmedAt) < 3.0
            if isSecondLeft {
                openQuickWindow()
                return
            }
            leftEdgePanelArmedTileID = focusedID
            leftEdgePanelArmedAt = Date()
            DispatchQueue.main.async {
                selectedChannelID = focusedID
                tileFocus = focusedID
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
                selectedChannelID = focusedID
                tileFocus = focusedID
            }
            return
        }

        guard direction == .right, isFocusedTileLastBoxInRow, acceptSingleDpadStep() else {
            if direction != .right { rightEdgeGuideArmedTileID = nil; leftEdgePanelArmedTileID = nil; leftEdgePanelArmedAt = .distantPast }
            return
        }

        let focusedID = tileFocus ?? selectedChannelID
        guard rightEdgeGuideArmedTileID == focusedID else {
            rightEdgeGuideArmedTileID = focusedID
            return
        }

        guideHintVisible = false
        guideHintHideTask?.cancel()
        withAnimation(.spring(response: 0.36, dampingFraction: 0.86)) {
            showGuide = true
            leftEdgePanelArmedTileID = nil
            leftEdgePanelArmedAt = .distantPast
            guideFocus = selectedChannelID
            tileFocus = selectedChannelID
            rightEdgeGuideArmedTileID = nil
        }
        scheduleLivePreviewWarmup(immediate: true)
    }

    private func keepFocusedChannelInVirtualWindow() {
        let source = visibleChannels
        guard source.count > renderedChannelLimit else {
            renderedWindowStart = 0
            return
        }
        let focusedID = tileFocus ?? guideFocus ?? selectedChannelID
        guard let index = source.firstIndex(where: { $0.id == focusedID }) else { return }
        let maxStart = max(0, source.count - renderedChannelLimit)
        let safeStart = min(max(renderedWindowStart, 0), maxStart)
        let safeEnd = min(source.count, safeStart + renderedChannelLimit)
        let edgeBuffer = 32
        if index < safeStart + edgeBuffer || index >= safeEnd - edgeBuffer {
            let targetStart = max(0, min(index - renderedChannelLimit / 2, maxStart))
            if targetStart != renderedWindowStart { renderedWindowStart = targetStart }
        }
    }

    private func resetVirtualChannelWindow(to channelID: Int? = nil) {
        let source = visibleChannels
        guard source.count > renderedChannelLimit else {
            renderedWindowStart = 0
            return
        }
        let index = channelID.flatMap { id in source.firstIndex(where: { $0.id == id }) } ?? 0
        renderedWindowStart = max(0, min(index - renderedChannelLimit / 2, max(0, source.count - renderedChannelLimit)))
    }

    private func scheduleLivePreviewWarmup(immediate: Bool = false) {
        keepFocusedChannelInVirtualWindow()
        previewPlaybackSuppressed = false
        guard showGuide else {
            previewWarmupToken += 1
            return
        }
        let targetID = selectedChannelID
        let targetStream = liveModel.channels.first(where: { $0.id == targetID })?.streamURL ?? selectedChannel.streamURL
        guard !targetStream.isEmpty else { return }
        previewWarmupToken += 1
        let token = previewWarmupToken
        if immediate {
            previewChannelID = targetID
            return
        }
        // v308/v299 base: keep the current preview alive during focus/selection changes instead of
        // blanking the view. This prevents Channels DVR streams from starting and then
        // getting torn down before AVPlayer can render video.
        let delay: Double = 0.55
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            guard token == previewWarmupToken, showGuide, selectedChannelID == targetID else { return }
            previewChannelID = targetID
        }
    }

    private func moveGuideFocus(_ delta: Int) {
        guard let current = guideFocus ?? tileFocus ?? visibleChannels.first?.id, let index = visibleChannels.firstIndex(where: { $0.id == current }) else { return }
        let target = min(max(index + delta, 0), visibleChannels.count - 1)
        selectedChannelID = visibleChannels[target].id
        guideFocus = selectedChannelID
    }

    private func liveBackground(channel: LiveTVChannel) -> some View {
        ZStack {
            LiveTVGridBackgroundThemeView(theme: liveTVGridThemePreset, accent: channel.accent, showGuide: showGuide)
                .ignoresSafeArea()
                .allowsHitTesting(false)
        }
    }

    private func gridLockedCatalogDock(size: CGSize) -> some View {
        let sourceRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let wantedType: String? = store.selectedTab == .movies ? "movie" : (store.selectedTab == .shows ? "series" : nil)
        let targetRows = sourceRows.filter { row in
            row.items.contains { item in
                if let wantedType { return item.type == wantedType }
                return item.type == "movie" || item.type == "series"
            }
        }
        let fallbackRows = sourceRows.filter { row in row.items.contains { $0.type == "movie" || $0.type == "series" } }
        let rowsForDock = targetRows.isEmpty ? fallbackRows : targetRows
        let safeRowIndex = rowsForDock.isEmpty ? 0 : min(max(gridLockedDockRowIndex, 0), rowsForDock.count - 1)
        let activeRow = rowsForDock.indices.contains(safeRowIndex) ? rowsForDock[safeRowIndex] : sourceRows.first
        let nextIndex = safeRowIndex + 1
        let nextRow = rowsForDock.indices.contains(nextIndex) ? rowsForDock[nextIndex] : nil
        let rawItems = activeRow?.items ?? []
        let filteredItems = wantedType == nil ? rawItems.filter { $0.type == "movie" || $0.type == "series" } : rawItems.filter { $0.type == wantedType }
        let items = Array((filteredItems.isEmpty ? rawItems : filteredItems).prefix(8))
        let dockIsActive = store.selectedTab == .home || store.selectedTab == .movies || store.selectedTab == .shows
        let title = store.selectedTab == .shows ? "FEATURED SHOWS" : (store.selectedTab == .movies ? "FEATURED MOVIES" : "FEATURED PICKS")
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .center, spacing: 12) {
                ThemedPanelLogo(title: title)
                    .scaleEffect(0.42, anchor: .leading)
                    .frame(width: 260, height: 36, alignment: .leading)
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 30)
            .padding(.top, 16)

            HStack(alignment: .bottom, spacing: 16) {
                ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
                    let isFocused = dockIsActive && gridLockedDockFocus == index
                    GridLockedDockPoster(item: item, index: index, isFocused: isFocused)
                        .contentShape(RoundedRectangle(cornerRadius: isFocused ? 18 : 14, style: .continuous))
                        .focusable(dockIsActive)
                        .focused($gridLockedDockFocus, equals: index)
                        .modifier(TransparentTVFocusVisual())
                        .onTapGesture {
                            guard dockIsActive else { return }
                            store.openDetail(item, pushCurrent: false)
                        }
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 30)
            .padding(.top, 2)
            .frame(height: 196, alignment: .bottomLeading)

            Text(nextRow?.title ?? "Continue Watching")
                .font(.system(size: 20, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.44))
                .padding(.horizontal, 32)
                .padding(.bottom, 18)
        }
        .frame(width: max(1060, size.width - 398), height: 318, alignment: .topLeading)
        .background(
            UnevenRoundedRectangle(topLeadingRadius: 34, bottomLeadingRadius: 0, bottomTrailingRadius: 0, topTrailingRadius: 34, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.black.opacity(0.70), Color.black.opacity(0.54), Color(red: 0.015, green: 0.018, blue: 0.026).opacity(0.46)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .shadow(color: .black.opacity(0.62), radius: 34, y: -8)
        .focusSection()
        .onExitCommand {
            gridLockedDockLocked = false
            gridLockedDockFocus = nil
            store.selectedTab = .live
            tileFocus = selectedChannelID
        }
        .onMoveCommand { direction in
            guard dockIsActive else { return }
            if direction == .up {
                // v430: stay inside the bottom dock while browsing rows.
                // Live TV focus is restored only by selecting Live TV/RIGHT/LEFT path, not accidental UP.
                if gridLockedDockRowIndex > 0 { gridLockedDockRowIndex -= 1 }
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            } else if direction == .down {
                gridLockedDockRowIndex = min(gridLockedDockRowIndex + 1, max(0, rowsForDock.count - 1))
                gridLockedDockFocus = gridLockedDockFocus ?? 0
            }
        }
        .position(x: size.width * 0.5 + 158, y: size.height - 158)
    }

    private func gridQuickControlWindow(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            quickPanelHeader
            if !gridLockedMode {
                quickPanelRefreshButton
            }
            quickPanelCategorySection
            if !gridLockedMode {
                quickPanelCloseHint
            }
            Spacer(minLength: 0)
        }
        .frame(width: gridLockedMode ? 302 : 306, height: gridLockedMode ? 850 : 780, alignment: .topLeading)
        .background(quickPanelBackground)
        .overlay(quickPanelBorder)
        .shadow(color: Color.cyan.opacity(0.10), radius: 28, x: 8, y: 0)
        .shadow(color: .black.opacity(0.58), radius: 28, x: 12, y: 0)
        .padding(.leading, gridLockedMode ? 18 : 18)
        .padding(.top, gridLockedMode ? 72 : 96)
        .focusSection()
        .focusable(quickWindowVisible)
        .focused($quickPanelFocus)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .onTapGesture { activateQuickPanelSelection() }
        .onSubmit { activateQuickPanelSelection() }
        .onMoveCommand { direction in routeLiveSpecialMove(direction) }
        .onPlayPauseCommand { activateQuickPanelSelection() }
        .onAppear {
            quickPanelSelectionIndex = quickPanelInitialIndex
            quickPanelItemFocus = quickPanelSelectionIndex
        }
        .onChange(of: quickWindowVisible) { visible in
            guard visible else { quickPanelItemFocus = nil; return }
            quickPanelSelectionIndex = quickPanelInitialIndex
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
                quickPanelItemFocus = quickPanelSelectionIndex
            }
        }
        .onChange(of: quickPanelItemFocus) { value in
            if let value, quickWindowVisible { quickPanelSelectionIndex = min(max(value, 0), quickPanelItemCount - 1) }
        }
    }


    private var quickPanelItemCount: Int { categories.count + 1 }

    // v497: Force Refresh is pinned to the top of the left Live TV tools panel
    // and is also the first focused action when the panel opens.
    private var quickPanelInitialIndex: Int { 0 }

    private var isQuickPanelRefreshFocused: Bool {
        quickWindowVisible && quickPanelSelectionIndex == 0
    }

    private func activateQuickPanelSelection() {
        guard quickWindowVisible else { return }
        if quickPanelSelectionIndex == 0 {
            runQuickPanelForceRefresh()
        } else {
            let categoryIndex = quickPanelSelectionIndex - 1
            if categories.indices.contains(categoryIndex) {
                selectQuickPanelCategory(categories[categoryIndex])
            }
        }
        quickPanelFocus = true
    }

    private var quickPanelHeader: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 10) {
                Image(systemName: gridLockedMode ? "rectangle.grid.2x2.fill" : "slider.horizontal.3")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(Color.cyan.opacity(0.92))
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Color.cyan.opacity(0.13)))
                Text(gridLockedMode ? "DEBRID GRID" : "GUIDE TOOLS")
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .tracking(1.6)
                    .foregroundStyle(.white.opacity(0.66))
            }
            Text(gridLockedMode ? "" : "Live Controls")
                .font(.system(size: gridLockedMode ? 1 : 30, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text(gridLockedMode ? "LEFT rail locked visible" : "Refresh first, filter groups, or hold a category to add/remove it from Sports.")
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .lineLimit(2)
                .lineSpacing(3)
        }
        .padding(.horizontal, gridLockedMode ? 16 : 22)
        .padding(.top, gridLockedMode ? 18 : 22)
    }

    private var quickPanelCategorySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("CATEGORIES")
                .font(.system(size: 12, weight: .black, design: .rounded))
                .tracking(1.3)
                .foregroundStyle(.white.opacity(0.42))
                .padding(.horizontal, 22)

            ScrollView(.vertical, showsIndicators: true) {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(Array(categories.enumerated()), id: \.element) { index, category in
                        // v499: left rail has two visual rows at the top: Force Refresh is focus index 0,
                        // so category rows must start at focus index 1. This prevents Force Refresh and
                        // All Channels from drawing focused at the same time.
                        quickPanelCategoryButton(category, index: index + 1)
                    }
                }
                .padding(.horizontal, gridLockedMode ? 12 : 18)
                .padding(.bottom, 4)
            }
            .frame(maxHeight: gridLockedMode ? 620 : 610)
            .onMoveCommand { direction in routeLiveSpecialMove(direction) }
            .focusable(false)
            .focusEffectDisabled()
            .modifier(TransparentTVFocusVisual())
        }
    }

    private func quickPanelCategoryButton(_ category: String, index: Int) -> some View {
        let isFocused = quickWindowVisible && quickPanelSelectionIndex == index
        let isSelected = category == selectedCategory
        return Button {
            quickPanelSelectionIndex = index
            selectQuickPanelCategory(category)
        } label: {
            quickPanelCategoryLabel(category: category, isFocused: isFocused, isSelected: isSelected)
        }
        .buttonStyle(.plain)
        .focusable(false)
        .focused($quickPanelItemFocus, equals: index)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .onLongPressGesture(minimumDuration: 0.65) {
            quickPanelSelectionIndex = index
            toggleSportsAssignedGroup(category)
        }
        .onPlayPauseCommand {
            quickPanelSelectionIndex = index
            toggleSportsAssignedGroup(category)
        }
    }

    private func quickPanelCategoryLabel(category: String, isFocused: Bool, isSelected: Bool) -> some View {
        HStack(spacing: 14) {
            Image(systemName: iconForGuideCategory(category))
                .font(.system(size: 18, weight: .bold))
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 2) {
                Text(category == "All" ? "All Channels" : category)
                    .font(.system(size: gridLockedMode ? 18 : 20, weight: .heavy, design: .rounded))
                    .foregroundStyle(Color.white.opacity(isFocused || isSelected ? 0.98 : 0.72))
                Text(sportsAssignedGroups.contains(category) ? "\(channelCount(for: category)) channels • in Sports" : "\(channelCount(for: category)) channels")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(sportsAssignedGroups.contains(category) ? Color.orange.opacity(0.86) : Color.white.opacity(isFocused ? 0.70 : 0.38))
                    .opacity(1.0)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .frame(width: 248, height: gridLockedMode ? 56 : 48, alignment: .leading)
        .background(quickPanelCategoryBackground(isFocused: isFocused, isSelected: isSelected))
        .overlay(quickPanelCategoryBorder(isFocused: isFocused, isSelected: isSelected))
        .clipShape(Capsule(style: .continuous))
    }

    private func quickPanelCategoryBackground(isFocused: Bool, isSelected: Bool) -> some View {
        Capsule(style: .continuous)
            .fill(isFocused ? Color.cyan.opacity(0.18) : (isSelected ? Color.orange.opacity(0.18) : Color.white.opacity(0.050)))
    }

    private func quickPanelCategoryBorder(isFocused: Bool, isSelected: Bool) -> some View {
        Capsule(style: .continuous)
            .stroke(isFocused ? Color(red: 0.24, green: 0.72, blue: 1.0).opacity(0.96) : (isSelected ? Color.orange.opacity(0.78) : Color.white.opacity(0.10)), lineWidth: isFocused || isSelected ? 2.5 : 1)
    }

    private func selectQuickPanelCategory(_ category: String) {
        selectedCategory = category
        resetVirtualChannelWindow()
        if let first = visibleChannels.first {
            selectedChannelID = first.id
            resetVirtualChannelWindow(to: first.id)
            // v252: keep the side rail as focus owner while open; restore grid focus only after closing.
            if !quickWindowVisible { tileFocus = first.id }
        }
    }

    private func toggleSportsAssignedGroup(_ category: String) {
        guard category != "All" && category != "My Favorites" && category != "Favorites" else {
            store.status = "Open a real channel group, then hold Select/Play-Pause to send that group to Sports."
            return
        }
        var groups = sportsAssignedGroups
        if groups.contains(category) {
            groups.remove(category)
            store.status = "Removed \(category) from Sports Channels."
        } else {
            groups.insert(category)
            store.status = "Added \(category) to Sports Channels. Open Sports to see that group there."
        }
        sportsAssignedGroupsRaw = groups.sorted().joined(separator: "|")
    }

    private var quickPanelRefreshButton: some View {
        Button {
            runQuickPanelForceRefresh()
        } label: {
            quickPanelRefreshLabel
        }
        .buttonStyle(.plain)
        .focusable(false)
        .focused($quickPanelItemFocus, equals: 0)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .padding(.horizontal, 18)
        .padding(.top, 0)
        .onPlayPauseCommand { quickPanelSelectionIndex = 0; runQuickPanelForceRefresh() }
        .onSubmit { quickPanelSelectionIndex = 0; runQuickPanelForceRefresh() }
    }

    private func runQuickPanelForceRefresh() {
        guard acceptSingleSelect() else { return }
        quickPanelFocus = true
        Task {
            await liveModel.forceRefreshGuide()
            selectedCategory = "All"
            if let first = visibleChannels.first {
                selectedChannelID = first.id
                // v252: real guide refresh can update selection, but must not move focus behind the open rail.
                if !quickWindowVisible { tileFocus = first.id }
            }
            DispatchQueue.main.async {
                quickPanelFocus = true
            }
        }
    }

    private var quickPanelRefreshLabel: some View {
        HStack(spacing: 16) {
            ZStack {
                Circle().fill(Color.blue.opacity(0.24))
                Image(systemName: "arrow.clockwise")
                    .font(.system(size: 28, weight: .black))
                    .foregroundStyle(Color.cyan.opacity(0.96))
            }
            .frame(width: 52, height: 52)

            VStack(alignment: .leading, spacing: 2) {
                Text("Force Refresh Guide")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Reload listings and artwork")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.56))
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .frame(width: 258, height: 92, alignment: .leading)
        .background(quickPanelRefreshBackground)
        .overlay(quickPanelRefreshBorder)
        .shadow(color: Color.cyan.opacity(isQuickPanelRefreshFocused ? 0.24 : 0.06), radius: isQuickPanelRefreshFocused ? 18 : 6, x: 0, y: 0)
        .scaleEffect(isQuickPanelRefreshFocused ? 1.025 : 1.0)
    }

    private var quickPanelRefreshBackground: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color.cyan.opacity(0.20), Color(red: 0.02, green: 0.05, blue: 0.10).opacity(0.98), Color.black.opacity(0.92)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var quickPanelRefreshBorder: some View {
        RoundedRectangle(cornerRadius: 22, style: .continuous)
            .stroke(isQuickPanelRefreshFocused ? Color.cyan.opacity(0.95) : Color.white.opacity(0.14), lineWidth: isQuickPanelRefreshFocused ? 3 : 1)
    }

    private var quickPanelCloseHint: some View {
        Text("RIGHT closes panel")
            .font(.system(size: 13, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.50))
            .padding(.leading, 24)
    }

    private var quickPanelBackground: some View {
        RoundedRectangle(cornerRadius: gridLockedMode ? 34 : 28, style: .continuous)
            .fill(
                LinearGradient(
                    colors: gridLockedMode
                        ? [Color.cyan.opacity(0.15), Color(red: 0.014, green: 0.021, blue: 0.034).opacity(0.92), Color.black.opacity(0.86)]
                        : [Color(red: 0.018, green: 0.030, blue: 0.052).opacity(0.98), Color.cyan.opacity(0.14), Color(red: 0.02, green: 0.02, blue: 0.04).opacity(0.94), Color.black.opacity(0.90)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var quickPanelBorder: some View {
        RoundedRectangle(cornerRadius: gridLockedMode ? 34 : 28, style: .continuous)
            .stroke(gridLockedMode ? Color.cyan.opacity(0.26) : Color.cyan.opacity(0.30), lineWidth: gridLockedMode ? 1.4 : 1.2)
    }

    private var isFocusedFirstGridTile: Bool {
        guard let focused = tileFocus,
              let first = visibleChannels.first else { return false }
        return focused == first.id
    }

    private func openQuickWindow() {
        quickWindowHideToken += 1
        withAnimation(.spring(response: 0.42, dampingFraction: 0.86)) {
            quickWindowVisible = true
            store.liveQuickPanelOpen = true
            // v252: move focus ownership fully into the side rail while it is open.
            // selectedChannelID is preserved so closing restores the same grid card.
            tileFocus = nil
            categoryFocus = nil
            guideFocus = nil
            quickPanelFocus = true
            quickPanelItemFocus = quickPanelInitialIndex
            rightEdgeGuideArmedTileID = nil
            leftEdgePanelArmedTileID = nil
            leftEdgePanelArmedAt = .distantPast
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            quickPanelSelectionIndex = quickPanelInitialIndex
            quickPanelItemFocus = quickPanelSelectionIndex
            quickPanelFocus = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.16) {
            if quickWindowVisible {
                quickPanelSelectionIndex = quickPanelInitialIndex
                quickPanelFocus = true
            }
        }
    }

    private func closeQuickWindow() {
        quickWindowHideToken += 1
        withAnimation(.spring(response: 0.34, dampingFraction: 0.88)) {
            quickWindowVisible = false
            store.liveQuickPanelOpen = false
            quickPanelFocus = false
            quickPanelItemFocus = nil
            tileFocus = selectedChannelID
        }
    }

    private func scheduleQuickWindowHide(delay: Double) {
        // v223: the utility panel is no longer a timed/autoloading hint. It only opens
        // intentionally when the user presses LEFT from the first grid card, and closes
        // when the user presses RIGHT/LEFT from the panel.
        quickWindowHideToken += 1
    }

    private var topCategoryRail: some View {
        HStack(spacing: 34) {
            ForEach(categories, id: \.self) { category in
                let isFocused = categoryFocus == category
                let isSelected = category == selectedCategory
                Text(category)
                    .font(.system(size: 28, weight: isSelected || isFocused ? .heavy : .semibold))
                    .foregroundStyle(isFocused ? Color.black : (isSelected ? .white : .white.opacity(0.58)))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
                    .padding(.horizontal, isFocused ? 28 : 18)
                    .padding(.vertical, isFocused ? 12 : 10)
                    .background(
                        Capsule(style: .continuous)
                            .fill(isFocused ? Color.white.opacity(0.94) : Color.clear)
                    )
                    .overlay(alignment: .bottom) {
                        if isSelected && !isFocused {
                            Capsule().fill(Color.orange.opacity(0.95)).frame(height: 5).offset(y: 8)
                        }
                    }
                    .contentShape(Capsule(style: .continuous))
                    .focusable(!quickWindowVisible)
                    .focused($categoryFocus, equals: category)
                    .modifier(TransparentTVFocusVisual())
                    .onTapGesture {
                        guard !quickWindowVisible else { return }
                        selectedCategory = category
                        resetVirtualChannelWindow()
                        if let first = visibleChannels.first {
                            selectedChannelID = first.id
                            resetVirtualChannelWindow(to: first.id)
                            tileFocus = first.id
                        }
                    }
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .center)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.10)))
    }

    private func isMyFavorite(_ channel: LiveTVChannel) -> Bool {
        myFavoriteChannelIDs.contains(channel.id)
    }

    private func toggleMyFavorite(_ channel: LiveTVChannel) {
        var ids = myFavoriteChannelIDs
        if ids.contains(channel.id) {
            ids.remove(channel.id)
        } else {
            ids.insert(channel.id)
        }
        myFavoriteChannelIdsRaw = ids.sorted().map(String.init).joined(separator: ",")
        if selectedCategory == "My Favorites", visibleChannels.isEmpty {
            selectedCategory = "All"
            resetVirtualChannelWindow()
        }
    }

    private func myFavoriteActionTitle(for channel: LiveTVChannel) -> String {
        isMyFavorite(channel) ? "Remove from My Favorites" : "Add to My Favorites"
    }

    private func isManualSportsChannel(_ channel: LiveTVChannel) -> Bool {
        sportsManualChannelIDs.contains(channel.id)
    }

    private func toggleManualSportsChannel(_ channel: LiveTVChannel) {
        var ids = sportsManualChannelIDs
        if ids.contains(channel.id) {
            ids.remove(channel.id)
            store.status = "Removed \(channel.name) from Sports Hub."
        } else {
            ids.insert(channel.id)
            store.status = "Added \(channel.name) to Sports Hub."
        }
        sportsManualChannelIdsRaw = ids.sorted().map(String.init).joined(separator: ",")
    }

    private func manualSportsActionTitle(for channel: LiveTVChannel) -> String {
        isManualSportsChannel(channel) ? "Remove from Sports" : "Add to Sports"
    }

    private func liveGrid(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: gridLockedMode ? 20 : 36), count: 4), spacing: gridLockedMode ? 22 : 34) {
                        ForEach(renderedChannels) { channel in
                            liveTile(channel: channel)
                                .id(channel.id)
                        }
                    }
                    .padding(.top, gridLockedMode ? 8 : 8)
                    .padding(.bottom, gridLockedMode ? 10 : 110)
                }
                // v444: remove unused bottom black reserve while preserving current card size/spacing.
                .frame(height: gridLockedMode ? 606 : size.height - 132)
                .onChange(of: tileFocus) { value in
                    if let value, !quickWindowVisible {
                        keepFocusedChannelInVirtualWindow()
                        DispatchQueue.main.async {
                            withAnimation(.easeOut(duration: 0.10)) {
                                proxy.scrollTo(value, anchor: .center)
                            }
                        }
                    }
                }
            }
        }
    }

    private func liveTile(channel: LiveTVChannel) -> some View {
        let isFocused = tileFocus == channel.id
        let program = liveModel.currentProgram(for: channel)
        return LiveTVGridTileContent(channel: channel, isFocused: isFocused, program: program, loadArtwork: true, gridLockedMode: gridLockedMode)
            .scaleEffect(isFocused ? (gridLockedMode ? 1.045 : 1.115) : 1.0)
            .offset(x: (gridLockedMode && isFocusedTileFirstBoxInRow && isFocused) ? 44 : 0, y: isFocused ? (gridLockedMode ? -2 : -6) : 0)
            .zIndex(isFocused ? 20 : 0)
            .shadow(color: .black.opacity(isFocused ? 0.88 : 0.30), radius: isFocused ? 30 : 8, y: isFocused ? 16 : 4)
            .animation(.spring(response: 0.32, dampingFraction: 0.94), value: isFocused)
            .contentShape(RoundedRectangle(cornerRadius: 4))
            .focusable(!quickWindowVisible)
            .focused($tileFocus, equals: channel.id)
            .modifier(TransparentTVFocusVisual())
            .onTapGesture {
                guard !quickWindowVisible, acceptSingleSelect() else { return }
                selectedChannelID = channel.id
                play(channel: channel)
            }
            .onPlayPauseCommand {
                guard !quickWindowVisible, acceptSingleSelect() else { return }
                selectedChannelID = channel.id
                play(channel: channel)
            }
            .contextMenu {
                Button(myFavoriteActionTitle(for: channel)) { toggleMyFavorite(channel) }
                Button(manualSportsActionTitle(for: channel)) { toggleManualSportsChannel(channel) }
            }
            .onMoveCommand { direction in
                // v243: catch edge LEFT/RIGHT while the grid tile itself owns focus.
                // This prevents tvOS from escaping the grid before the forced two-press side-panel action can run.
                routeLiveSpecialMove(direction)
            }
            .onChange(of: tileFocus) { value in
                rightEdgeGuideArmedTileID = nil
                // v247: do not clear the armed-left-panel state when tvOS briefly tries to
                // move focus away after the first LEFT. The first card is re-focused so the
                // second LEFT can open the panel instead of disabling the action.
                if let value, !quickWindowVisible {
                    selectedChannelID = value
                    keepFocusedChannelInVirtualWindow()
                }
            }
    }

    private func shouldLoadArtwork(for channel: LiveTVChannel) -> Bool {
        guard let focused = tileFocus ?? guideFocus else { return false }
        if focused == channel.id { return true }
        guard let focusedIndex = visibleChannels.firstIndex(where: { $0.id == focused }),
              let channelIndex = visibleChannels.firstIndex(where: { $0.id == channel.id }) else { return false }
        return abs(focusedIndex - channelIndex) <= 4
    }

    private func scheduleGuideHintAutoHide() {
        guideHintHideTask?.cancel()
        guideHintVisible = true
        guideHintHideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 10_000_000_000)
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.24)) { guideHintVisible = false }
        }
    }

    private var guideHint: some View {
        HStack(spacing: 10) {
            Image(systemName: "arrow.right.circle.fill")
            Text("Press RIGHT for full guide")
        }
        .font(.system(size: 22, weight: .bold))
        .foregroundStyle(Color.white.opacity(0.96))
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .background(BlackGlassGuideButtonBackground())
    }

    private func guideView(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            googleGuideHero(channel: selectedChannel, size: size)
                .frame(maxWidth: .infinity, minHeight: 260, maxHeight: 260, alignment: .topLeading)

            VStack(alignment: .leading, spacing: 0) {
                googleGuideTimelineHeader
                    .padding(.bottom, 8)
                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: true) {
                        LazyVStack(spacing: 8) {
                            ForEach(renderedChannels) { channel in
                                googleGuideTimelineRow(channel: channel, rowWidth: size.width - 160)
                                    .id(channel.id)
                            }
                        }
                        .padding(.bottom, 130)
                    }
                    .frame(maxWidth: .infinity, maxHeight: size.height - 455, alignment: .topLeading)
                    .onChange(of: guideFocus) { value in
                        if let value {
                            withAnimation(.easeOut(duration: 0.16)) {
                                proxy.scrollTo(value, anchor: .center)
                            }
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: size.height - 120, alignment: .topLeading)
    }

    private func googleGuideHero(channel: LiveTVChannel, size: CGSize) -> some View {
        let currentProgram = liveModel.currentProgram(for: channel)
        let artURL = currentProgram?.imageURL ?? ""
        // v347: safe-area hero redesign.  No absolute left/right positioning.
        // The preview and info cards now live inside one responsive HStack with fixed
        // inner padding, so neither side can be clipped by the screen edge or guide scroll area.
        let heroHeight: CGFloat = 252

        return GeometryReader { heroGeo in
            let heroWidth = heroGeo.size.width
            // v347: compute the cards from the real safe content width.  v347 padded
            // a full-width HStack, which made the preview/info cards overflow and clip
            // on opposite screen edges.  Here the card widths plus the gap always fit
            // inside heroWidth - safe margins.
            let outerPad = max(72, min(112, heroWidth * 0.060))
            let gap: CGFloat = max(28, min(44, heroWidth * 0.024))
            let contentWidth = max(780, heroWidth - (outerPad * 2))
            let previewCardWidth = min(560, max(430, contentWidth * 0.43))
            let infoWidth = max(430, contentWidth - previewCardWidth - gap)
            let previewWidth = max(360, previewCardWidth - 28)

            HStack(alignment: .top, spacing: gap) {
                VStack(alignment: .leading, spacing: 10) {
                    livePreviewWindow(
                        channel: previewChannel,
                        program: liveModel.currentProgram(for: previewChannel) ?? currentProgram,
                        active: showGuide && !previewPlaybackSuppressed && !previewChannel.streamURL.isEmpty
                    )
                    .frame(width: previewWidth, height: 206)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

                    // v361: keep muted preview video, remove the bottom "Live Preview" caption.
                }
                .padding(14)
                .frame(width: previewCardWidth, height: heroHeight, alignment: .topLeading)

                HStack(alignment: .center, spacing: 22) {
                    guideHeroChannelLogo(channel: channel)
                        .frame(width: 118, height: 118)
                        .layoutPriority(2)

                    VStack(alignment: .leading, spacing: 9) {
                        Text(currentProgram?.title ?? channel.now)
                            .font(.system(size: 37, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.58)
                        Text("\(currentProgram?.startText ?? "Now") - \((currentProgram?.endText ?? "").ifEmpty("Next"))  •  \(channel.category)")
                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.82))
                            .lineLimit(1)
                            .minimumScaleFactor(0.72)
                        HStack(spacing: 10) {
                            guideHeroMiniChannelIcon(channel: channel)
                                .frame(width: 42, height: 30)
                            Text("\(channel.number)  •  \(channel.source)  •  \(channel.name)")
                                .font(.system(size: 17, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white.opacity(0.70))
                                .lineLimit(1)
                                .minimumScaleFactor(0.70)
                        }
                        Text((currentProgram?.description ?? "").ifEmpty(channel.description))
                            .font(.system(size: 18, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.62))
                            .lineLimit(2)
                            .minimumScaleFactor(0.78)
                    }
                    .layoutPriority(1)

                    Spacer(minLength: 6)

                    guideHeroProgramArtwork(artURL: artURL, channel: channel)
                        .frame(width: min(140, max(112, infoWidth * 0.18)), height: 198)
                }
                .padding(.horizontal, 22)
                .frame(width: infoWidth, height: heroHeight, alignment: .leading)
                .background(guideHeroCardBackground(accent: channel.accent.opacity(0.22)))
                // v361: keep dynamic channel/program gradient tint but remove visible boxed border.
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .shadow(color: .black.opacity(0.25), radius: 18, x: 0, y: 10)
            }
            .frame(width: contentWidth, height: heroHeight, alignment: .topLeading)
            .padding(.horizontal, outerPad)
        }
        .frame(maxWidth: .infinity, minHeight: heroHeight, maxHeight: heroHeight, alignment: .topLeading)
    }

    private func guideHeroCardBackground(accent: Color) -> some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color.cyan.opacity(0.075), accent, Color.black.opacity(0.42)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }

    private var guideHeroCardBorder: some View {
        RoundedRectangle(cornerRadius: 24, style: .continuous)
            .stroke(Color.white.opacity(0.16), lineWidth: 1.2)
    }

    private func guideHeroProgramArtwork(artURL: String, channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(Color.black.opacity(0.20))
            if let url = URL(string: artURL), !artURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(6)
                    default: guideHeroLogoFallback(channel: channel)
                    }
                }
            } else {
                guideHeroLogoFallback(channel: channel)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.15), lineWidth: 1))
    }

    private func guideHeroLogoFallback(channel: LiveTVChannel) -> some View {
        Text(channel.logo)
            .font(.system(size: 31, weight: .black, design: .rounded))
            .foregroundStyle(.white.opacity(0.88))
            .lineLimit(1)
            .minimumScaleFactor(0.42)
            .padding(10)
    }

    private func guideHeroChannelLogo(channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18).fill(Color.black.opacity(0.24))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(18)
                    default: Text(channel.logo).font(.system(size: 46, weight: .black)).foregroundStyle(.white)
                    }
                }
            } else {
                Text(channel.logo).font(.system(size: 46, weight: .black)).foregroundStyle(.white)
            }
        }
    }

    private func guideHeroMiniChannelIcon(channel: LiveTVChannel) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 7).fill(Color.black.opacity(0.22))
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit().padding(3)
                    default: Text(channel.logo).font(.system(size: 13, weight: .black)).foregroundStyle(.white.opacity(0.9))
                    }
                }
            } else {
                Text(channel.logo).font(.system(size: 13, weight: .black)).foregroundStyle(.white.opacity(0.9))
            }
        }
        .overlay(RoundedRectangle(cornerRadius: 7).stroke(Color.white.opacity(0.14), lineWidth: 1))
    }

    private func activePreviewCaption(channel: LiveTVChannel) -> String {
        if previewPlaybackSuppressed { return "Opening Live TV…" }
        if channel.streamURL.isEmpty { return "Live Preview Unavailable" }
        return "Live Preview • \(channel.number) • \(channel.name)"
    }

    private func livePreviewWindow(channel: LiveTVChannel, program: LiveProgram?, active: Bool) -> some View {
        ZStack(alignment: .bottomLeading) {
            Color.black
            if active, let streamURL = URL(string: channel.streamURL), !channel.streamURL.isEmpty {
                #if canImport(KSPlayer)
                KSPlayerVideoSurface(url: streamURL, shouldPlay: true, seekSerial: 0, seekSeconds: 0, seekIsAbsolute: false, reloadToken: 0, startTimeSeconds: 0, externalAudioURL: nil, externalAudioOffsetMS: 0, muteAudio: true)
                    .id("live-preview-ks-\(channel.streamURL)")
                    .allowsHitTesting(false)
                #else
                SilentVideoBackground(url: streamURL, isMuted: true)
                    .id("live-preview-avfallback-\(channel.streamURL)")
                    .allowsHitTesting(false)
                #endif
            } else if let url = URL(string: program?.imageURL ?? ""), !(program?.imageURL ?? "").isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFit().padding(10)
                    default:
                        Color.black
                    }
                }
            }
            // v348: no text/channel caption on the preview surface. Keep it a plain
            // blended video box so labels do not overlap or look like a second info row.
        }
        .background(Color.black)
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private var googleGuideTimelineHeader: some View {
        HStack(spacing: 10) {
            Text(Date().formatted(.dateTime.weekday(.abbreviated).month().day()))
                .font(.system(size: 20, weight: .bold))
                .foregroundStyle(.white.opacity(0.58))
                .frame(width: 350, alignment: .leading)
            ForEach(guideTimeSlots, id: \.self) { time in
                Text(time)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundStyle(.white.opacity(time == guideTimeSlots.first ? 0.72 : 0.48))
                    .frame(width: 295, alignment: .leading)
            }
        }
        .frame(height: 42)
    }

    private func googleGuideTimelineRow(channel: LiveTVChannel, rowWidth: CGFloat) -> some View {
        let isFocused = guideFocus == channel.id
        let programs = Array(liveModel.programs(for: channel).prefix(10))
        let minProgramWidth: CGFloat = 170
        return HStack(spacing: 8) {
            guideChannelPill(channel: channel, isFocused: isFocused)
                .frame(width: 330, height: 82)

            ForEach(programs) { program in
                GoogleGuideProgramCell(program: program, width: max(minProgramWidth, program.width))
            }

            if programs.count < 10 {
                ForEach(0..<(10 - programs.count), id: \.self) { _ in
                    GuideEmptyProgramCell(width: 295)
                }
            }
        }
        .frame(width: rowWidth, alignment: .leading)
        .contentShape(Rectangle())
        .focusable(true)
        .focused($guideFocus, equals: channel.id)
        .modifier(TransparentTVFocusVisual())
        .onTapGesture {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .contextMenu {
            Button(myFavoriteActionTitle(for: channel)) { toggleMyFavorite(channel) }
        }
        .onChange(of: guideFocus) { value in if let value { selectedChannelID = value } }
    }

    private func guideChannelPill(channel: LiveTVChannel, isFocused: Bool) -> some View {
        HStack(spacing: 18) {
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 28, weight: .black)) }
                }
                .frame(width: 96, height: 54)
            } else {
                Text(channel.logo).font(.system(size: 28, weight: .black)).lineLimit(1).frame(width: 96, alignment: .leading)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(channel.number).font(.system(size: 22, weight: .bold)).foregroundStyle(.white.opacity(0.76))
                Text(channel.name).font(.system(size: 18, weight: .medium)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 18)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(isFocused ? 0.38 : 0.30)))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.clear, lineWidth: 1))
    }

    private var googleGuideSideRail: some View {
        VStack(alignment: .leading, spacing: 20) {
            googleGuideSideRailHeader

            ForEach(categories, id: \.self) { category in
                googleGuideSideRailButton(category: category)
            }

            Spacer(minLength: 0)
        }
        .padding(.top, 8)
        .padding(.horizontal, 18)
        .background(googleGuideSideRailBackground)
        .overlay(googleGuideSideRailBorder)
    }

    private var googleGuideSideRailHeader: some View {
        Text("YOUR CHANNELS")
            .font(.system(size: 17, weight: .heavy))
            .tracking(1.6)
            .foregroundStyle(.white.opacity(0.48))
            .padding(.leading, 12)
    }

    private var googleGuideSideRailBackground: some View {
        RoundedRectangle(cornerRadius: 30).fill(Color.black.opacity(0.34))
    }

    private var googleGuideSideRailBorder: some View {
        RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.08), lineWidth: 1)
    }

    private func googleGuideSideRailButton(category: String) -> some View {
        let isSelected = category == selectedCategory
        return Button {
            selectGuideCategory(category)
        } label: {
            googleGuideSideRailButtonContent(category: category, isSelected: isSelected)
        }
        .buttonStyle(.plain)
        .focused($categoryFocus, equals: category)
    }

    private func googleGuideSideRailButtonContent(category: String, isSelected: Bool) -> some View {
        HStack(spacing: 18) {
            googleGuideSideRailIcon(category: category, isSelected: isSelected)
            googleGuideSideRailText(category: category, isSelected: isSelected)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .frame(height: 92)
        .background(googleGuideSideRailButtonBackground(isSelected: isSelected))
    }

    private func googleGuideSideRailIcon(category: String, isSelected: Bool) -> some View {
        ZStack {
            Circle().fill(isSelected ? Color.white.opacity(0.16) : Color.white.opacity(0.07))
            Image(systemName: iconForGuideCategory(category))
                .font(.system(size: 23, weight: .bold))
                .foregroundStyle(isSelected ? .black : .white.opacity(0.76))
        }
        .frame(width: 58, height: 58)
    }

    private func googleGuideSideRailText(category: String, isSelected: Bool) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(category == "All" ? "All Channels" : category)
                .font(.system(size: 29, weight: .semibold))
                .foregroundStyle(isSelected ? .black : .white.opacity(0.88))
            Text("\(channelCount(for: category)) channels")
                .font(.system(size: 21, weight: .medium))
                .foregroundStyle(isSelected ? .black.opacity(0.58) : .white.opacity(0.42))
        }
    }

    private func googleGuideSideRailButtonBackground(isSelected: Bool) -> some View {
        RoundedRectangle(cornerRadius: 25).fill(isSelected ? Color.white.opacity(0.92) : Color.white.opacity(0.04))
    }

    private func selectGuideCategory(_ category: String) {
        selectedCategory = category
        resetVirtualChannelWindow()
        if let first = visibleChannels.first {
            selectedChannelID = first.id
            resetVirtualChannelWindow(to: first.id)
            guideFocus = first.id
            tileFocus = first.id
        }
    }

    private func channelCount(for category: String) -> Int {
        if category == "All" { return liveModel.channels.count }
        if category == "My Favorites" { return liveModel.channels.filter { myFavoriteChannelIDs.contains($0.id) }.count }
        if category == "HD" { return liveModel.channels.filter { $0.category == "HD" || Int($0.number) ?? 0 >= 6000 || $0.name.localizedCaseInsensitiveContains("HD") }.count }
        return liveModel.channels.filter { $0.category == category }.count
    }

    private func iconForGuideCategory(_ category: String) -> String {
        switch category.lowercased() {
        case "my favorites": return "heart.fill"
        case "favorites": return "star.fill"
        case "movies": return "movieclapper.fill"
        case "sports": return "sportscourt.fill"
        case "news": return "newspaper.fill"
        case "kids": return "face.smiling.fill"
        case "hd": return "tv.fill"
        default: return "rectangle.grid.2x2.fill"
        }
    }

    private var guideSideRail: some View {
        VStack(spacing: 24) {
            VStack(spacing: 26) {
                Image(systemName: "heart")
                Image(systemName: "list.bullet")
                Image(systemName: "rectangle.grid.2x2")
                Image(systemName: "circle")
                Image(systemName: "book")
                Image(systemName: "magnifyingglass")
            }
            .font(.system(size: 30, weight: .semibold))
            .foregroundStyle(.white.opacity(0.56))
            .frame(maxWidth: .infinity)
            .padding(.top, 26)
            VStack(alignment: .trailing, spacing: 22) {
                ForEach(categories, id: \.self) { category in
                    Text(category == "All" ? "All Channels" : category == "HD" ? "HD Channels" : category)
                        .font(.system(size: 26, weight: category == selectedCategory ? .bold : .medium))
                        .foregroundStyle(category == selectedCategory ? .white : .white.opacity(0.56))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .onTapGesture { selectedCategory = category }
                }
            }
            Spacer()
        }
        .padding(.top, 68)
        .padding(.horizontal, 12)
        .background(Color.black.opacity(0.18))
    }

    private func guidePreview(channel: LiveTVChannel) -> some View {
        let currentProgram = liveModel.programs(for: channel).first
        let artURL = currentProgram?.imageURL ?? ""
        return HStack(alignment: .top, spacing: 34) {
            ZStack(alignment: .bottomLeading) {
                RoundedRectangle(cornerRadius: 22).fill(Color.black.opacity(0.58))
                if let url = URL(string: artURL), !artURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image):
                            image.resizable().scaledToFit().padding(8)
                        default:
                            guideLogoCard(channel: channel)
                        }
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                } else {
                    guideLogoCard(channel: channel)
                }
                LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .center, endPoint: .bottom)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                HStack(spacing: 10) {
                    if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                        AsyncImage(url: url) { phase in
                            switch phase { case .success(let image): image.resizable().scaledToFit(); default: Text(channel.logo).font(.system(size: 22, weight: .black)) }
                        }.frame(width: 70, height: 38)
                    } else {
                        Text(channel.logo).font(.system(size: 22, weight: .black)).frame(width: 64, alignment: .leading)
                    }
                    Text(channel.number).font(.system(size: 22, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(18)
            }
            .frame(width: 470, height: 246)
            .background(Color.black.opacity(0.46))
            .clipShape(RoundedRectangle(cornerRadius: 22))

            VStack(alignment: .leading, spacing: 12) {
                Text(channel.source.uppercased() + "  |  " + channel.logo)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white.opacity(0.58))
                Text(currentProgram?.title ?? channel.now)
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text((currentProgram?.startText ?? "Now") + ((currentProgram?.endText ?? "").isEmpty ? "" : " - \(currentProgram?.endText ?? "")") + "   " + channel.category)
                    .font(.system(size: 27, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.82))
                Text((currentProgram?.description ?? "").ifEmpty(channel.description))
                    .font(.system(size: 24, weight: .medium))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(2)
                HStack(spacing: 10) { guideBadge("LIVE"); guideBadge("HD"); guideBadge(channel.category) }
            }
            Spacer(minLength: 0)
        }
        .padding(.top, 8)
        .padding(.bottom, 6)
    }

    private func guideLogoCard(channel: LiveTVChannel) -> some View {
        ZStack {
            LinearGradient(colors: [Color.white.opacity(0.92), channel.accent.opacity(0.28)], startPoint: .topLeading, endPoint: .bottomTrailing)
            if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase { case .success(let image): image.resizable().scaledToFit().padding(34); default: Text(channel.logo).font(.system(size: 62, weight: .black, design: .rounded)).foregroundStyle(.black.opacity(0.78)).padding(26) }
                }
            } else {
                Text(channel.logo).font(.system(size: 62, weight: .black, design: .rounded)).minimumScaleFactor(0.5).foregroundStyle(.black.opacity(0.78)).padding(26)
            }
        }
    }

    private func guideBadge(_ text: String) -> some View {
        Text(text).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 8).background(RoundedRectangle(cornerRadius: 2).fill(Color.black.opacity(0.58)).overlay(RoundedRectangle(cornerRadius: 2).stroke(Color.white.opacity(0.16), lineWidth: 1)))
    }

    private var guideTimeSlots: [String] {
        let calendar = Calendar.current
        let now = Date()
        let minute = calendar.component(.minute, from: now)
        let flooredMinute = minute < 30 ? 0 : 30
        let base = calendar.date(bySettingHour: calendar.component(.hour, from: now), minute: flooredMinute, second: 0, of: now) ?? now
        return (0..<6).compactMap { offset in
            calendar.date(byAdding: .minute, value: offset * 30, to: base)?.formatted(date: .omitted, time: .shortened)
        }
    }

    private var timeHeader: some View {
        HStack(spacing: 10) {
            Text("").frame(width: 230)
            ForEach(guideTimeSlots, id: \.self) { time in
                Text(time).font(.system(size: 24, weight: .bold)).foregroundStyle(.white.opacity(0.48)).frame(width: 260, alignment: .leading)
            }
        }
    }

    private func guideRow(channel: LiveTVChannel, rowWidth: CGFloat) -> some View {
        let isFocused = guideFocus == channel.id
        let channelColumnWidth: CGFloat = 230
        let programCount = 6
        let programWidth = max(190, (rowWidth - channelColumnWidth - 54) / CGFloat(programCount))
        let programs = Array(liveModel.programs(for: channel).prefix(programCount))

        return HStack(spacing: 10) {
            HStack(spacing: 12) {
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFit()
                        default: Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1)
                        }
                    }
                    .frame(width: 86, height: 46)
                } else {
                    Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1).frame(width: 86, alignment: .leading)
                }
                Text(channel.number).font(.system(size: 25, weight: .bold)).foregroundStyle(.white.opacity(0.78))
            }
            .padding(.horizontal, 12)
            .frame(width: channelColumnWidth, height: 74, alignment: .leading)
            .background((isFocused ? Color.white.opacity(0.035) : LiveTVTheme.glassPanel))
            .clipShape(RoundedRectangle(cornerRadius: 4))

            ForEach(programs) { program in
                GuideProgramCell(program: program, width: programWidth)
            }

            if programs.count < programCount {
                ForEach(0..<(programCount - programs.count), id: \.self) { _ in
                    GuideEmptyProgramCell(width: 210)
                }
            }
        }
        .frame(width: rowWidth, alignment: .leading)
        .clipped()
        .contentShape(Rectangle())
        .focusable(true)
        .focused($guideFocus, equals: channel.id)
        .modifier(TransparentTVFocusVisual())
        .onTapGesture {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .contextMenu {
            Button(myFavoriteActionTitle(for: channel)) { toggleMyFavorite(channel) }
        }
        .onChange(of: guideFocus) { value in if let value { selectedChannelID = value } }
    }



private struct BlackGlassGuideButtonBackground: View {
    var body: some View {
        Capsule(style: .continuous)
            .fill(
                LinearGradient(
                    colors: [Color.white.opacity(0.11), Color.white.opacity(0.045), Color.black.opacity(0.20)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .overlay(
                Capsule(style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.34), radius: 14, x: 0, y: 8)
    }
}

private struct GoogleGuideProgramCell: View {
    let program: LiveProgram
    let width: CGFloat

    var body: some View {
        HStack(spacing: 14) {
            if let url = URL(string: program.imageURL), !program.imageURL.isEmpty {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFill()
                    default: Color.white.opacity(0.05)
                    }
                }
                .frame(width: 58, height: 58)
                .clipShape(RoundedRectangle(cornerRadius: 7))
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(program.title)
                    .font(.system(size: 23, weight: program.isLive ? .bold : .semibold))
                    .lineLimit(1)
                    .foregroundStyle(.white.opacity(program.isLive ? 0.96 : 0.82))
                if !program.startText.isEmpty {
                    HStack(spacing: 8) {
                        Text(program.startText)
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white.opacity(0.46))
                        if program.isLive {
                            Text("LIVE")
                                .font(.system(size: 12, weight: .heavy))
                                .foregroundStyle(.red)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 2)
                                .overlay(RoundedRectangle(cornerRadius: 3).stroke(Color.red, lineWidth: 1))
                        }
                    }
                }
            }
            Spacer(minLength: 0)
        }
        .frame(width: width, height: 86, alignment: .leading)
        .padding(.horizontal, 18)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(LinearGradient(colors: [Color.white.opacity(program.isLive ? 0.13 : 0.075), Color.white.opacity(program.isLive ? 0.07 : 0.035)], startPoint: .topLeading, endPoint: .bottomTrailing))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(program.isLive ? 0.12 : 0.055), lineWidth: 1))
        )
        .overlay {
            if program.isLive {
                GeometryReader { proxy in
                    let x = max(0, min(proxy.size.width - 3, proxy.size.width * program.liveProgress))
                    Rectangle()
                        .fill(Color.red.opacity(0.96))
                        .frame(width: 3, height: proxy.size.height - 10)
                        .position(x: x, y: proxy.size.height / 2)
                        .shadow(color: .red.opacity(0.72), radius: 5)
                }
                .allowsHitTesting(false)
            }
        }
    }
}

private struct GuideProgramCell: View {
    let program: LiveProgram
    let width: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(program.title)
                .font(.system(size: 22, weight: program.isLive ? .bold : .semibold))
                .lineLimit(1)
                .foregroundStyle(program.isLive ? .black : .white.opacity(0.84))
            if !program.startText.isEmpty {
                Text(program.startText)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(program.isLive ? .black.opacity(0.62) : .white.opacity(0.42))
            }
        }
        .frame(width: width, height: 74, alignment: .leading)
        .padding(.horizontal, 12)
        .background(program.isLive ? Color.white.opacity(0.82) : LiveTVTheme.glassPanel)
        .clipShape(RoundedRectangle(cornerRadius: 4))
        .overlay(alignment: .leading) {
            if program.isLive {
                VStack(spacing: 0) {
                    Circle().fill(Color.red).frame(width: 9, height: 9)
                    Rectangle().fill(Color.red.opacity(0.95)).frame(width: 3, height: 58)
                }
                .offset(x: 6)
            }
        }
    }
}

private struct GuideEmptyProgramCell: View {
    let width: CGFloat

    var body: some View {
        Text("No guide data")
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(.white.opacity(0.36))
            .frame(width: width, height: 86, alignment: .leading)
            .padding(.horizontal, 12)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.035)))
    }
}

    private func play(channel: LiveTVChannel) {
        guard let url = URL(string: channel.streamURL), !channel.streamURL.isEmpty else { liveModel.status = "No playable URL for \(channel.name). Configure Channels DVR/M3U/Xtream source."; return }
        // v347: stop/suppress the KS guide preview before routing into full KS Live TV playback.
        // This keeps the preview surface from continuing audio while the full channel opens.
        previewPlaybackSuppressed = true
        previewWarmupToken += 1
        previewChannelID = nil
        store.liveQuickPanelOpen = false
        let program = liveModel.currentProgram(for: channel)
        let programTitle = (program?.title ?? channel.now).trimmingCharacters(in: .whitespacesAndNewlines)
        let programDescription = (program?.description ?? channel.description).trimmingCharacters(in: .whitespacesAndNewlines)
        let timeLine = [program?.startText ?? "Now", program?.endText ?? ""].filter { !$0.isEmpty }.joined(separator: " - ")
        let smartDescription = [programTitle, timeLine, programDescription].filter { !$0.isEmpty }.joined(separator: "\n")
        let item = MediaItem(id: "live-\(channel.id)-\(channel.streamURL.hashValue)", title: channel.name, year: "Live", type: "live", catalog: channel.source, description: smartDescription.ifEmpty(channel.description), genres: [channel.category, channel.source, timeLine].filter { !$0.isEmpty }, rating: "", posterURL: (program?.imageURL ?? "").ifEmpty(channel.iconURL), landscapeURL: program?.imageURL, logoURL: channel.iconURL, previewURL: nil)
        store.startPlayback(item: item, url: url, alternates: [], subtitles: [], label: "Live TV direct stream: \(channel.name) • \(programTitle.ifEmpty(channel.now)) • \(channel.source) • \(channel.number) • KS Live TV route")
    }

    static let sampleChannels: [LiveTVChannel] = [
        LiveTVChannel(id: 6003, logo: "CBS", number: "6003", name: "The Talk", category: "Drama", now: "The Young and the Restless", next: "The Bold and the Beautiful", description: "A live daytime lineup with drama, interviews, and entertainment news.", accent: .gray),
        LiveTVChannel(id: 6011, logo: "COMEDY", number: "6011", name: "South Park", category: "Favorites", now: "South Park", next: "Catfish: The TV Show", description: "South Park goes gluten free in this animated comedy block.", accent: .indigo),
        LiveTVChannel(id: 6013, logo: "MTV", number: "6013", name: "Catfish", category: "Favorites", now: "Catfish: The TV Show", next: "Catfish: The TV Show", description: "Online relationships, mysteries, and reveals.", accent: .gray),
        LiveTVChannel(id: 6017, logo: "CMT", number: "6017", name: "Mike & Molly", category: "Comedy", now: "Mike & Molly", next: "Mom", description: "Classic sitcom blocks and comfort comedy favorites.", accent: .mint),
        LiveTVChannel(id: 6019, logo: "BET", number: "6019", name: "black-ish", category: "Drama", now: "black-ish", next: "Tyler Perry's Meet the Browns", description: "Comedy, family stories, and drama favorites.", accent: .gray),
        LiveTVChannel(id: 6021, logo: "TV LAND", number: "6021", name: "Bonanza", category: "Drama", now: "Bonanza", next: "Gunsmoke", description: "Classic TV westerns and vintage drama blocks.", accent: .green),
        LiveTVChannel(id: 6022, logo: "PARAMOUNT", number: "6022", name: "Mom", category: "HD", now: "Mom", next: "Two and a Half Men", description: "HD sitcom favorites with back-to-back episodes.", accent: .blue),
        LiveTVChannel(id: 6031, logo: "ESPN", number: "6031", name: "SportsCenter", category: "Sports", now: "SportsCenter", next: "NFL Live", description: "Live sports news, highlights, and analysis.", accent: .red),
        LiveTVChannel(id: 6044, logo: "CNN", number: "6044", name: "CNN Newsroom", category: "News", now: "CNN Newsroom", next: "The Lead", description: "Breaking news and live national coverage.", accent: .red),
        LiveTVChannel(id: 6052, logo: "NICK", number: "6052", name: "SpongeBob", category: "Kids", now: "SpongeBob SquarePants", next: "The Loud House", description: "Animated favorites for kids and family viewing.", accent: .orange),
        LiveTVChannel(id: 6060, logo: "HBO", number: "6060", name: "Feature Movie", category: "Movies", now: "Feature Presentation", next: "Behind the Scenes", description: "Premium movie presentation with cinematic artwork.", accent: .cyan),
        LiveTVChannel(id: 6070, logo: "WEATHER", number: "6070", name: "Weather Headlines", category: "News", now: "Weather Headlines", next: "Local Forecast", description: "Regional weather headlines, storms, and local forecast updates.", accent: .teal)
    ]
}

private struct LiveTVGridTileContent: View {
    let channel: LiveTVChannel
    let isFocused: Bool
    let program: LiveProgram?
    let loadArtwork: Bool
    let gridLockedMode: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottomLeading) {
                LiveTVGridTileArtwork(channel: channel, program: program, loadArtwork: loadArtwork, gridLockedMode: gridLockedMode)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

                LiveTVGridTileFooter(channel: channel, isFocused: isFocused, program: program)
                    .frame(width: geo.size.width, height: 82)
            }
            .frame(width: geo.size.width, height: geo.size.height, alignment: .center)
            .background(Color.black.opacity(0.50))
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(tileBorder)
            .scaleEffect(isFocused ? 1.035 : 1.0)
            .overlay(focusPopOverlay)
            .shadow(color: .black.opacity(isFocused ? 0.58 : 0.18), radius: isFocused ? 18 : 4, y: isFocused ? 10 : 2)
            .animation(.easeOut(duration: 0.16), value: isFocused)
        }
        .aspectRatio(gridLockedMode ? 1.22 : (16.0 / 9.0), contentMode: .fit)
        .frame(height: gridLockedMode ? 372 : 278)
    }

    private var tileBorder: some View {
        RoundedRectangle(cornerRadius: 16, style: .continuous)
            .stroke(isFocused ? Color.cyan.opacity(0.92) : Color.white.opacity(0.045), lineWidth: isFocused ? 3.0 : 1)
    }

    private var focusPopOverlay: some View {
        RoundedRectangle(cornerRadius: 18, style: .continuous)
            .stroke(isFocused ? Color.cyan.opacity(0.32) : Color.clear, lineWidth: isFocused ? 8 : 0)
            .blur(radius: isFocused ? 1.5 : 0)
    }
}

private struct LiveTVGridTileArtwork: View {
    let channel: LiveTVChannel
    let program: LiveProgram?
    let loadArtwork: Bool
    let gridLockedMode: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .center) {
                programArtBackground(size: geo.size)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                LinearGradient(colors: [.black.opacity(0.02), .black.opacity(0.24)], startPoint: .center, endPoint: .bottom)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
    }

    @ViewBuilder
    private func programArtBackground(size: CGSize) -> some View {
        if loadArtwork, let art = program?.imageURL, !art.isEmpty, let url = URL(string: art) {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    ZStack {
                        image
                            .resizable()
                            .scaledToFill()
                            .frame(width: size.width, height: size.height)
                            .clipped()
                            .blur(radius: 10)
                            .opacity(0.52)
                            .saturation(1.10)
                        image
                            .resizable()
                            .scaledToFit()
                            .frame(width: size.width, height: size.height)
                            .clipped()
                    }
                default:
                    channelPosterFallback(size: size)
                }
            }
        } else {
            channelPosterFallback(size: size)
        }
    }

    // v474: missing Gracenote/program artwork falls through provider artwork first
    // (TVDB/Fanart/TMDB via backend), then provider/channel icon, then generated card.
    @ViewBuilder
    private func channelPosterFallback(size: CGSize) -> some View {
        ZStack {
            gradientBackground
            if let providerURL = providerChannelPosterURL {
                AsyncImage(url: providerURL) { phase in
                    switch phase {
                    case .success(let image):
                        posterImageLayers(image: image, size: size, foregroundPadding: 0)
                    default:
                        channelIconPosterFallback(size: size)
                    }
                }
            } else {
                channelIconPosterFallback(size: size)
            }
        }
    }

    @ViewBuilder
    private func channelIconPosterFallback(size: CGSize) -> some View {
        if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    posterImageLayers(image: image, size: size, foregroundPadding: max(22, min(size.width, size.height) * 0.16))
                default:
                    generatedChannelPoster
                }
            }
        } else {
            generatedChannelPoster
        }
    }

    private func posterImageLayers(image: Image, size: CGSize, foregroundPadding: CGFloat) -> some View {
        ZStack {
            image
                .resizable()
                .scaledToFill()
                .frame(width: size.width, height: size.height)
                .clipped()
                .blur(radius: foregroundPadding > 0 ? 18 : 10)
                .opacity(foregroundPadding > 0 ? 0.26 : 0.48)
            image
                .resizable()
                .scaledToFit()
                .padding(foregroundPadding)
                .frame(width: size.width, height: size.height)
                .shadow(color: .black.opacity(0.65), radius: 12, y: 5)
        }
    }

    private var providerChannelPosterURL: URL? {
        // v539: Xtream should use the actual current programme as the Gracenotes-style replacement key.
        // Only block provider lookup when the Xtream EPG did not provide a real programme title; otherwise
        // ask the backend for a TMDB/Fanart/TVDB now-playing poster/backdrop and keep channel logo fallback.
        let currentTitle = (program?.title ?? channel.now).trimmingCharacters(in: .whitespacesAndNewlines)
        if currentTitle.isEmpty { return nil }
        if channel.source.lowercased().contains("xtream") {
            let lower = currentTitle.lowercased()
            if currentTitle.caseInsensitiveCompare(channel.name) == .orderedSame || lower == "no information" || lower == "no guide data" || lower == "unknown" {
                return nil
            }
        }
        let configuredBase = (UserDefaults.standard.string(forKey: "backendBaseURL") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let base = configuredBase.isEmpty ? "https://api.skylinejay187.it.com" : configuredBase
        guard var comps = URLComponents(string: base + "/api/artwork/now-playing") else { return nil }
        comps.queryItems = [
            URLQueryItem(name: "channel", value: channel.name),
            URLQueryItem(name: "program", value: currentTitle),
            URLQueryItem(name: "tvgId", value: channel.tvgID),
            URLQueryItem(name: "number", value: channel.number),
            URLQueryItem(name: "source", value: channel.source),
            URLQueryItem(name: "type", value: "tv")
        ]
        return comps.url
    }

    private var generatedChannelPoster: some View {
        VStack(spacing: 10) {
            Text(channel.logo)
                .font(.system(size: channel.logo.count > 6 ? 26 : 38, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(1)
                .minimumScaleFactor(0.32)
            Text(channel.name)
                .font(.system(size: 16, weight: .heavy, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
                .lineLimit(1)
                .minimumScaleFactor(0.55)
        }
        .padding(.horizontal, 24)
        .shadow(color: .black.opacity(0.72), radius: 8, y: 3)
    }

    private var gradientBackground: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(
                LinearGradient(
                    colors: [Color.black.opacity(0.78), channel.accent.opacity(0.34), Color.black.opacity(0.90)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
    }
}

private struct LiveTVGridTileFooter: View {
    let channel: LiveTVChannel
    let isFocused: Bool
    let program: LiveProgram?

    @ViewBuilder
    private var footerChannelIcon: some View {
        if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFit()
                default:
                    Text(channel.logo)
                        .font(.system(size: channel.logo.count > 6 ? 10 : 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.35)
                }
            }
        } else {
            Text(channel.logo)
                .font(.system(size: channel.logo.count > 6 ? 10 : 14, weight: .black, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.35)
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 3) {
                footerChannelIcon
                    .frame(width: 38, height: 24, alignment: .leading)
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
                Text(channel.number)
                    .font(.system(size: 10, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
                    .lineLimit(1)
                    .minimumScaleFactor(0.45)
            }
            .frame(width: 52, alignment: .leading)

            VStack(alignment: .leading, spacing: 2) {
                Text(program?.title ?? channel.now)
                    .font(.system(size: 15, weight: .heavy, design: .rounded))
                    .tracking(-0.15)
                    .lineLimit(2)
                    .minimumScaleFactor(0.42)
                    .fixedSize(horizontal: false, vertical: true)
                    .shadow(color: .black.opacity(0.92), radius: 4, x: 0, y: 2)
                Text(channel.name)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(1)
                    .minimumScaleFactor(0.50)
                    .shadow(color: .black.opacity(0.86), radius: 3, x: 0, y: 1)
            }
            Spacer()
        }
        .foregroundStyle(.white.opacity(0.96))
        .padding(.horizontal, 16)
        .padding(.bottom, 10)
        .frame(height: 78, alignment: .bottomLeading)
    }
}


// MARK: - v221 Compile Recovery Shared UI Helpers
// Restores helper views referenced by the grid/overlay rebuild so the project compiles cleanly in GitHub Actions.

struct TransparentTVFocusVisual: ViewModifier {
    func body(content: Content) -> some View {
        content
            .buttonStyle(.plain)
            .focusEffectDisabled()
    }
}



struct SportsNoPlatterButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.92 : 1.0)
            .scaleEffect(configuration.isPressed ? 0.985 : 1.0)
    }
}

struct InvisibleTVFocusPlatter: ViewModifier {
    func body(content: Content) -> some View {
        content
            .buttonStyle(.plain)
            .focusEffectDisabled()
            .background(Color.clear)
            .compositingGroup()
    }
}

struct SafeCardScrollMotion: ViewModifier {
    let isFocused: Bool
    var intensity: CGFloat = 1.0

    func body(content: Content) -> some View {
        content
            .scaleEffect(isFocused ? 1.0 + (0.065 * intensity) : 1.0)
            .shadow(color: isFocused ? Color.black.opacity(0.34) : Color.black.opacity(0.18), radius: isFocused ? 22 : 8, x: 0, y: isFocused ? 16 : 5)
            .zIndex(isFocused ? 10 : 0)
            .animation(.spring(response: 0.34, dampingFraction: 0.82), value: isFocused)
    }
}




struct FocusedPanelBackdropArtwork: View {
    let item: MediaItem

    private var url: String? {
        item.landscapeURL ?? item.posterURL
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black.opacity(0.96)

                // v250: single-panel backdrop only. No duplicate fitted layer, no blurred edge layer,
                // and no split/dark-side composition. The selected card artwork owns the panel and
                // scales to cover the actual panel bounds.
                RemoteImageFit(url: url, mode: .fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .opacity(0.88)
                    .saturation(1.06)
                    .contrast(1.04)
                    .allowsHitTesting(false)

                LinearGradient(
                    colors: [Color.black.opacity(0.54), Color.black.opacity(0.18), Color.black.opacity(0.50)],
                    startPoint: .leading,
                    endPoint: .trailing
                )

                LinearGradient(
                    colors: [Color.black.opacity(0.18), Color.clear, Color.black.opacity(0.40)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
    }
}

struct DetailPoster: View {
    let item: MediaItem

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
            // v252: remove only the remaining media-popup poster title label.
            // Keep poster artwork, top themed logo/header, metadata, buttons, and More Like This unchanged.
            LinearGradient(colors: [.clear, .black.opacity(0.34)], startPoint: .top, endPoint: .bottom)
        }
    }
}

struct DetailBackdropArtwork: View {
    let item: MediaItem

    var body: some View {
        ZStack {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            Color.black.opacity(0.18)
        }
    }
}


struct PopupHeaderBackdropArtwork: View {
    let item: MediaItem

    private var preferredBackdropURL: String? {
        let raw = item.landscapeURL ?? item.posterURL
        guard var value = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return raw }
        // v486: Prefer the highest useful provider artwork for the hero header.
        // TMDB paths often arrive as smaller w500/w780 assets; the header needs a clean 16:9 crop.
        let tmdbSizes = ["/w92/", "/w154/", "/w185/", "/w342/", "/w500/", "/w780/", "/w1280/"]
        for size in tmdbSizes where value.contains(size) {
            value = value.replacingOccurrences(of: size, with: "/original/")
            break
        }
        return value
    }

    var body: some View {
        // v486: Zoom out slightly while keeping the banner fully filled, then nudge the art
        // down again so faces/key poster artwork sit inside the visible crop.
        RemoteImageFit(url: preferredBackdropURL, mode: .fill)
            .scaleEffect(1.0)
            .offset(y: 128)
            .clipped()
            .overlay(Color.black.opacity(0.015))
    }
}

struct ThemedPanelLogo: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.system(size: 50, weight: .black, design: .rounded))
            .kerning(0.8)
            .foregroundStyle(
                LinearGradient(
                    colors: [Color.white, Color.white.opacity(0.92), Color.cyan.opacity(0.80)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .shadow(color: .black.opacity(0.55), radius: 2, x: 0, y: 3)
            .shadow(color: .cyan.opacity(0.14), radius: 10, x: 0, y: 0)
            .overlay(alignment: .bottom) {
                LinearGradient(colors: [.clear, .white.opacity(0.18), .clear], startPoint: .leading, endPoint: .trailing)
                    .frame(height: 2)
                    .padding(.horizontal, 6)
                    .offset(y: 2)
            }
    }
}

struct CardThemedLogo: View {
    let item: MediaItem
    let focused: Bool

    private var fallbackTitle: String {
        let clean = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !clean.isEmpty { return clean.uppercased() }
        return item.catalog.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
    }

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: .black.opacity(0.55), radius: 4, y: 3)
            } else {
                Text(fallbackTitle)
                    .font(.system(size: focused ? 30 : 22, weight: .black, design: .rounded))
                    .kerning(1.0)
                    .lineLimit(2)
                    .minimumScaleFactor(0.35)
                    .foregroundStyle(
                        LinearGradient(
                            colors: [Color.white, Color.white.opacity(0.92), Color.cyan.opacity(0.74)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .shadow(color: .black.opacity(0.68), radius: 3, x: 0, y: 3)
                    .shadow(color: .cyan.opacity(focused ? 0.22 : 0.10), radius: focused ? 12 : 6)
            }
        }
    }
}

struct PopupArtworkLogoOnly: View {
    let item: MediaItem

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: .black.opacity(0.58), radius: 6, y: 3)
            } else {
                // v251: no generated text-logo fallback on media information popup.
                EmptyView()
            }
        }
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    var pulse: Bool = false
    @State private var glow = false

    var body: some View {
        Group {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .shadow(color: Color.white.opacity(glow ? 0.18 : 0.05), radius: glow ? 18 : 4)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: 58, weight: .black, design: .rounded))
                    .kerning(1.6)
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .minimumScaleFactor(0.35)
                    .shadow(color: Color.cyan.opacity(glow ? 0.20 : 0.07), radius: glow ? 18 : 5)
            }
        }
        .scaleEffect(pulse && glow ? 1.012 : 1.0)
        .animation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true), value: glow)
        .onAppear {
            guard pulse else { return }
            glow = true
        }
    }
}



struct SportsLiveEvent: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let league: String
    let status: String
    let artworkURL: String?
    let accent: Color
    var streamURL: String? = nil
    var webURL: String? = nil
}

struct SportsLiveTeam: Identifiable {
    let id: String
    let name: String
    let league: String
    let badgeURL: String?
}

@MainActor
final class SportsLiveZoneModel: ObservableObject {
    @Published var ticker: [String] = ["Loading public sports ticker…"]
    @Published var liveNow: [SportsLiveEvent] = []
    @Published var today: [SportsLiveEvent] = []
    @Published var upcoming: [SportsLiveEvent] = []
    @Published var favoriteTeams: [SportsLiveTeam] = []
    @Published var sportsOnlyChannels: [SportsLiveEvent] = []
    @Published var highlights: [SportsLiveEvent] = []
    @Published var commandCenter: [SportsLiveEvent] = []
    @Published var theaterMode: [SportsLiveEvent] = []
    @Published var heatMap: [SportsLiveEvent] = []
    @Published var ppvEvents: [SportsLiveEvent] = []
    @Published var status: String = "Sports Live Zone warming up public data…"

    var favoriteTeamCards: [SportsLiveEvent] {
        favoriteTeams.map { team in
            SportsLiveEvent(id: "favorite-team-\(team.id)", title: team.name, subtitle: "Roster • schedule • players • scores • highlights", league: team.league, status: "My Team", artworkURL: team.badgeURL, accent: .yellow)
        }
    }

    private var loaded = false
    private let sportsKeywords = ["sport", "sports", "ppv", "event", "events", "redzone", "nfl", "nba", "mlb", "nhl", "soccer", "football", "basketball", "baseball", "hockey", "ufc", "mma", "boxing", "wwe", "aew", "wrestling", "tennis", "golf", "f1", "formula", "racing", "nascar", "espn", "fs1", "fs2", "bein", "sky sports", "tnt sports", "dazn", "fubo", "nbcsn", "ppv"]

    func load(favoriteTeams rawFavorites: String, xtreamAccounts rawAccounts: String, customSources rawSportsSources: String = "") async {
        guard !loaded else { return }
        loaded = true
        status = "Loading schedules, team art, and scoreboards…"
        async let sportsDBEvents = loadSportsDBToday()
        async let espnEvents = loadESPNScores()
        async let teamArt = loadFavoriteTeams(rawFavorites)
        async let highlightFeed = loadSportsHighlights()
        async let customSportsChannels = loadSportsOnlyM3USources(rawSportsSources)
        let (dbEvents, scoreEvents, teams, highlightEvents, channels) = await (sportsDBEvents, espnEvents, teamArt, highlightFeed, customSportsChannels)
        favoriteTeams = teams
        sportsOnlyChannels = channels
        highlights = highlightEvents
        let combined = scoreEvents + dbEvents
        ppvEvents = makePPVEvents(from: combined + channels)
        commandCenter = makeCommandCenter(events: combined, favorites: teams, channels: channels, ppv: ppvEvents)
        theaterMode = makeTheaterModes(events: combined, channels: channels)
        heatMap = makeSportsHeatMap(events: combined, highlights: highlightEvents, channels: channels)
        liveNow = combined.filter { event in
            let s = event.status.lowercased()
            return s.contains("live") || s.contains("in progress") || s.contains("halftime") || s.contains("period") || s.contains("quarter")
        }
        today = combined.isEmpty ? fallbackTodayEvents(favoriteTeams: rawFavorites) : Array(combined.prefix(18))
        upcoming = Array((dbEvents + fallbackUpcomingEvents()).prefix(18))
        if highlights.isEmpty { highlights = fallbackHighlights() }
        ticker = makeTicker(events: combined, favorites: teams, channels: channels)
        status = "Command Center ready • \(today.count) today • \(liveNow.count) live • \(ppvEvents.count) PPV/event cards"
    }

    private func loadSportsDBToday() async -> [SportsLiveEvent] {
        let today = Self.dayString(Date())
        let sports = ["Soccer", "American Football", "Basketball", "Baseball", "Ice Hockey", "Motorsport", "Fighting", "Tennis", "Golf"]
        var output: [SportsLiveEvent] = []
        for sport in sports {
            let encoded = sport.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? sport
            guard let url = URL(string: "https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=\(today)&s=\(encoded)"),
                  let root = await fetchJSON(url),
                  let events = root["events"] as? [[String: Any]] else { continue }
            output += events.prefix(10).compactMap { item in
                let home = item["strHomeTeam"] as? String ?? "Home"
                let away = item["strAwayTeam"] as? String ?? "Away"
                let league = item["strLeague"] as? String ?? sport
                let time = item["strTime"] as? String ?? item["dateEvent"] as? String ?? "Today"
                let status = item["strStatus"] as? String ?? "Scheduled"
                let art = item["strThumb"] as? String ?? item["strPoster"] as? String ?? item["strFanart"] as? String
                let id = item["idEvent"] as? String ?? "sportsdb-\(sport)-\(home)-\(away)-\(time)"
                return SportsLiveEvent(id: "sportsdb-\(id)", title: "\(away) at \(home)", subtitle: time, league: league, status: status, artworkURL: art, accent: .orange)
            }
            if output.count >= 36 { break }
        }
        return Array(output.prefix(36))
    }

    private func loadESPNScores() async -> [SportsLiveEvent] {
        let endpoints = [
            ("NFL", "https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard"),
            ("NCAAF", "https://site.api.espn.com/apis/site/v2/sports/football/college-football/scoreboard"),
            ("NBA", "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard"),
            ("WNBA", "https://site.api.espn.com/apis/site/v2/sports/basketball/wnba/scoreboard"),
            ("NCAAM", "https://site.api.espn.com/apis/site/v2/sports/basketball/mens-college-basketball/scoreboard"),
            ("MLB", "https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/scoreboard"),
            ("NHL", "https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/scoreboard"),
            ("Soccer", "https://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard"),
            ("UFC", "https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard"),
            ("F1", "https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard")
        ]
        var output: [SportsLiveEvent] = []
        for (league, raw) in endpoints {
            guard let url = URL(string: raw), let root = await fetchJSON(url), let events = root["events"] as? [[String: Any]] else { continue }
            for event in events.prefix(10) {
                let name = event["shortName"] as? String ?? event["name"] as? String ?? league
                let statusDict = event["status"] as? [String: Any]
                let statusType = statusDict?["type"] as? [String: Any]
                let status = statusType?["shortDetail"] as? String ?? statusType?["description"] as? String ?? "Scheduled"
                let competitions = event["competitions"] as? [[String: Any]]
                let competitors = competitions?.first?["competitors"] as? [[String: Any]] ?? []
                let art = competitors.compactMap { comp -> String? in
                    let team = comp["team"] as? [String: Any]
                    if let logo = team?["logo"] as? String { return logo }
                    if let logos = team?["logos"] as? [[String: Any]] { return logos.first?["href"] as? String }
                    return nil
                }.first
                let scoreLine = competitors.compactMap { comp -> String? in
                    let team = comp["team"] as? [String: Any]
                    let abbr = team?["abbreviation"] as? String ?? team?["shortDisplayName"] as? String
                    let score = comp["score"] as? String
                    guard let abbr else { return nil }
                    return score == nil ? abbr : "\(abbr) \(score!)"
                }.joined(separator: "  ")
                let id = event["id"] as? String ?? "espn-\(league)-\(name)"
                output.append(SportsLiveEvent(id: "espn-\(league)-\(id)", title: name, subtitle: scoreLine.ifEmpty(status), league: league, status: status, artworkURL: art, accent: .green))
            }
        }
        return output
    }

    private func loadFavoriteTeams(_ raw: String) async -> [SportsLiveTeam] {
        let names = raw.components(separatedBy: CharacterSet(charactersIn: ",\n"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        guard !names.isEmpty else { return [] }
        var teams: [SportsLiveTeam] = []
        for name in names.prefix(8) {
            let encoded = name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? name
            if let url = URL(string: "https://www.thesportsdb.com/api/v1/json/3/searchteams.php?t=\(encoded)"),
               let root = await fetchJSON(url),
               let arr = root["teams"] as? [[String: Any]],
               let team = arr.first {
                teams.append(SportsLiveTeam(id: team["idTeam"] as? String ?? name, name: team["strTeam"] as? String ?? name, league: team["strLeague"] as? String ?? "Favorite", badgeURL: team["strTeamBadge"] as? String ?? team["strTeamLogo"] as? String))
            } else {
                teams.append(SportsLiveTeam(id: name, name: name, league: "Favorite", badgeURL: nil))
            }
        }
        return teams
    }

    private func loadSportsOnlyXtreamChannels(_ rawAccounts: String) async -> [SportsLiveEvent] {
        // Normal Xtream/M3U imports stay in Live TV. Automatic sports routing remains backlogged.
        return []
    }

    private func loadSportsOnlyM3USources(_ raw: String) async -> [SportsLiveEvent] {
        let urls = raw.components(separatedBy: CharacterSet(charactersIn: "\n,"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && ($0.lowercased().hasPrefix("http://") || $0.lowercased().hasPrefix("https://")) }
        guard !urls.isEmpty else { return [] }
        var output: [SportsLiveEvent] = []
        for (idx, rawURL) in urls.prefix(6).enumerated() {
            guard let url = URL(string: rawURL), let text = await fetchText(url, maxBytes: 3_000_000) else { continue }
            output += parseSportsM3U(text, sourceIndex: idx)
            if output.count >= 300 { break }
        }
        return Array(output.prefix(300))
    }

    private func parseSportsM3U(_ text: String, sourceIndex: Int) -> [SportsLiveEvent] {
        var output: [SportsLiveEvent] = []
        let lines = text.components(separatedBy: .newlines)
        var pendingName = "Sports Channel"
        var pendingLogo: String? = nil
        var pendingGroup = "Sports Only"
        for line in lines {
            if line.hasPrefix("#EXTINF") {
                pendingName = Self.extinfName(line)
                pendingLogo = Self.attribute("tvg-logo", in: line)
                pendingGroup = Self.attribute("group-title", in: line) ?? "Sports Only"
            } else if line.lowercased().hasPrefix("http") {
                let haystack = "\(pendingName) \(pendingGroup)".lowercased()
                if sportsKeywords.contains(where: { haystack.contains($0) }) {
                    output.append(SportsLiveEvent(id: "sports-m3u-\(sourceIndex)-\(output.count)-\(pendingName)", title: pendingName, subtitle: pendingGroup, league: "Sports M3U", status: "Watch Live", artworkURL: pendingLogo, accent: .cyan, streamURL: line))
                }
                if output.count >= 250 { break }
            }
        }
        return output
    }


    private func loadSportsHighlights() async -> [SportsLiveEvent] {
        // v549: public/free highlight foundation. ScoreBat covers global soccer highlights;
        // fallback cards keep every major sport represented until each provider plugin is enabled.
        guard let url = URL(string: "https://www.scorebat.com/video-api/v3/") else { return [] }
        guard let root = await fetchJSON(url), let response = root["response"] as? [[String: Any]] else { return [] }
        return response.prefix(14).enumerated().map { idx, item in
            let title = item["title"] as? String ?? "Soccer Highlight"
            let competition = ((item["competition"] as? [String: Any])?["name"] as? String) ?? "Soccer Highlights"
            let thumb = item["thumbnail"] as? String
            let matchURL = item["matchviewUrl"] as? String
            return SportsLiveEvent(id: "scorebat-highlight-\(idx)-\(title)", title: title, subtitle: "Video highlight ready", league: competition, status: "Highlight", artworkURL: thumb, accent: .purple, webURL: matchURL)
        }
    }

    private func fallbackHighlights() -> [SportsLiveEvent] {
        ["NFL", "NBA", "MLB", "NHL", "Soccer", "UFC", "Boxing", "WWE", "AEW", "TNA", "NJPW", "F1", "NASCAR", "Tennis", "Golf"].enumerated().map { idx, league in
            SportsLiveEvent(id: "fallback-highlight-\(idx)", title: "\(league) Highlights", subtitle: "Highlight rail ready", league: league, status: "Highlight", artworkURL: nil, accent: .purple)
        }
    }

    private func makePPVEvents(from events: [SportsLiveEvent]) -> [SportsLiveEvent] {
        let ppvWords = ["ppv", "pay per view", "ufc", "boxing", "fight", "wwe", "aew", "tna", "njpw", "mania", "slam", "title", "event"]
        let matched = events.filter { event in
            let haystack = "\(event.title) \(event.subtitle) \(event.league) \(event.status)".lowercased()
            return ppvWords.contains(where: { haystack.contains($0) })
        }
        if !matched.isEmpty {
            return Array(matched.prefix(18)).map { event in
                SportsLiveEvent(id: "ppv-\(event.id)", title: event.title, subtitle: event.subtitle.ifEmpty("Event card"), league: event.league, status: "PPV / Event", artworkURL: event.artworkURL, accent: .red)
            }
        }
        return ["UFC / Fight Night", "Boxing PPV", "WWE Premium Live Event", "AEW PPV", "TNA Special Event", "NJPW Event", "Big Game Events"].enumerated().map { idx, title in
            SportsLiveEvent(id: "fallback-ppv-\(idx)", title: title, subtitle: "Add sports-only M3U or manual sports channels to light up this card", league: "PPV", status: "Event Watch", artworkURL: nil, accent: .red)
        }
    }

    private func makeCommandCenter(events: [SportsLiveEvent], favorites: [SportsLiveTeam], channels: [SportsLiveEvent], ppv: [SportsLiveEvent]) -> [SportsLiveEvent] {
        let liveCount = events.filter { $0.status.lowercased().contains("live") || $0.status.lowercased().contains("progress") }.count
        let startingSoon = events.filter { $0.status.lowercased().contains("pre") || $0.status.lowercased().contains("scheduled") }.count
        return [
            SportsLiveEvent(id: "command-live", title: "What Matters Right Now", subtitle: "\(liveCount) live • \(startingSoon) starting soon", league: "Command Center", status: "Pulse", artworkURL: nil, accent: .green),
            SportsLiveEvent(id: "command-ppv", title: "PPV / Event Watch", subtitle: "\(ppv.count) fight, wrestling, and big-event cards", league: "Events", status: "PPV", artworkURL: nil, accent: .red),
            SportsLiveEvent(id: "command-teams", title: "My Team Intelligence", subtitle: favorites.isEmpty ? "Choose favorite teams to unlock dashboards" : "\(favorites.count) favorite team dashboard(s)", league: "My Teams", status: "Priority", artworkURL: favorites.first?.badgeURL, accent: .yellow),
            SportsLiveEvent(id: "command-sources", title: "Sports Sources", subtitle: channels.isEmpty ? "Sports-only M3U ready" : "\(channels.count) sports-only channel cards", league: "Sources", status: "Channels", artworkURL: channels.first?.artworkURL, accent: .cyan)
        ]
    }

    private func makeTheaterModes(events: [SportsLiveEvent], channels: [SportsLiveEvent]) -> [SportsLiveEvent] {
        let active = events.prefix(5).map { event in
            SportsLiveEvent(id: "theater-\(event.id)", title: "Theater: \(event.title)", subtitle: "Scores • highlights • channels • alerts", league: event.league, status: "Theater", artworkURL: event.artworkURL, accent: .orange)
        }
        if !active.isEmpty { return Array(active) }
        return ["NFL Sunday", "NBA Night", "Fight Night", "Wrestling Night", "Race Day", "Soccer Saturday"].enumerated().map { idx, title in
            SportsLiveEvent(id: "fallback-theater-\(idx)", title: title, subtitle: "Multi-panel sports cockpit foundation", league: "Theater Mode", status: "Preview", artworkURL: channels.first?.artworkURL, accent: .orange)
        }
    }

    private func makeSportsHeatMap(events: [SportsLiveEvent], highlights: [SportsLiveEvent], channels: [SportsLiveEvent]) -> [SportsLiveEvent] {
        let leagues = ["NFL", "NBA", "MLB", "NHL", "Soccer", "NCAA", "UFC", "Boxing", "Wrestling", "F1", "NASCAR", "Tennis", "Golf", "PPV"]
        return leagues.map { league in
            let score = events.filter { $0.league.localizedCaseInsensitiveContains(league) || $0.title.localizedCaseInsensitiveContains(league) }.count
                + highlights.filter { $0.league.localizedCaseInsensitiveContains(league) || $0.title.localizedCaseInsensitiveContains(league) }.count
                + channels.filter { $0.title.localizedCaseInsensitiveContains(league) || $0.subtitle.localizedCaseInsensitiveContains(league) }.count
            let bars = String(repeating: "█", count: max(1, min(10, score + 1)))
            return SportsLiveEvent(id: "heat-\(league)", title: "\(league) Heat", subtitle: bars, league: "Activity Map", status: score > 0 ? "Active" : "Ready", artworkURL: nil, accent: score > 0 ? .green : .blue)
        }
    }

    private func makeTicker(events: [SportsLiveEvent], favorites: [SportsLiveTeam], channels: [SportsLiveEvent]) -> [String] {
        let orderedSports = ["NFL", "NBA", "MLB", "NHL", "WNBA", "NCAA", "Soccer", "UFC", "Boxing", "WWE", "AEW", "TNA", "NJPW", "F1", "NASCAR", "Tennis", "Golf", "PPV"]
        var picked: [SportsLiveEvent] = []
        for league in orderedSports {
            if let match = events.first(where: { $0.league.localizedCaseInsensitiveContains(league) || $0.title.localizedCaseInsensitiveContains(league) }) {
                picked.append(match)
            }
        }
        for event in events where picked.count < 18 && !picked.contains(where: { $0.id == event.id }) { picked.append(event) }
        var items = picked.prefix(18).map { "\($0.league) • \($0.title) • \($0.subtitle.ifEmpty($0.status))" }
        items += favorites.prefix(6).map { "★ \($0.name) • team art ready" }
        if !channels.isEmpty { items.append("\(channels.count) manual sports source cards") }
        return items.isEmpty ? ["NFL • NBA • MLB • NHL • Soccer • NCAA • UFC • Boxing", "WWE • AEW • TNA • NJPW wrestling headlines ready", "F1 • NASCAR • Tennis • Golf", "Add favorite teams in Settings"] : items
    }

    private func fallbackTodayEvents(favoriteTeams: String) -> [SportsLiveEvent] {
        let teams = favoriteTeams.components(separatedBy: CharacterSet(charactersIn: ",\n")).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        let names = teams.isEmpty ? ["NFL Live", "NBA Tonight", "MLB Live", "NHL Center Ice", "Soccer Today", "UFC Fight Night", "WWE Raw / SmackDown", "AEW Dynamite / Collision", "F1 Weekend", "Tennis Live", "Golf Central"] : teams
        return names.enumerated().map { idx, name in
            SportsLiveEvent(id: "fallback-today-\(idx)", title: name, subtitle: "Today", league: "Favorites", status: "Scheduled", artworkURL: nil, accent: .orange)
        }
    }

    private func fallbackUpcomingEvents() -> [SportsLiveEvent] {
        ["NFL", "NBA", "MLB", "NHL", "Soccer", "NCAA", "UFC", "Boxing", "WWE", "AEW", "TNA", "NJPW", "F1", "NASCAR", "Tennis", "Golf"].enumerated().map { idx, league in
            SportsLiveEvent(id: "fallback-upcoming-\(idx)", title: "\(league) Upcoming", subtitle: "Schedule rail ready", league: league, status: "Upcoming", artworkURL: nil, accent: .blue)
        }
    }

    private func fetchJSON(_ url: URL) async -> [String: Any]? {
        var req = URLRequest(url: url, timeoutInterval: 10)
        req.setValue("application/json,*/*", forHTTPHeaderField: "Accept")
        req.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await URLSession.shared.data(for: req)
            guard ((response as? HTTPURLResponse)?.statusCode ?? 200) < 400 else { return nil }
            return try JSONSerialization.jsonObject(with: data) as? [String: Any]
        } catch { return nil }
    }

    private func fetchText(_ url: URL, maxBytes: Int) async -> String? {
        do {
            let data: Data
            let statusCode: Int
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "audio/x-mpegurl,text/plain,*/*", userAgent: "DebridChannels-tvOS/560", maxBytes: maxBytes, timeout: 12)
                data = plain.data
                statusCode = plain.statusCode
            } else {
                var req = URLRequest(url: url, timeoutInterval: 12)
                req.setValue("audio/x-mpegurl,text/plain,*/*", forHTTPHeaderField: "Accept")
                req.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")
                let (sessionData, response) = try await URLSession.shared.data(for: req)
                data = sessionData
                statusCode = (response as? HTTPURLResponse)?.statusCode ?? 200
            }
            guard statusCode < 400 else { return nil }
            return String(data: Data(data.prefix(maxBytes)), encoding: .utf8)
        } catch { return nil }
    }

    private static func dayString(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }

    private static func normalizeServer(_ raw: String) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
        return clean
    }

    private static func attribute(_ name: String, in line: String) -> String? {
        guard let range = line.range(of: "\(name)=\"") else { return nil }
        let rest = line[range.upperBound...]
        guard let end = rest.firstIndex(of: "\"") else { return nil }
        return String(rest[..<end])
    }

    private static func extinfName(_ line: String) -> String {
        if let comma = line.lastIndex(of: ",") { return String(line[line.index(after: comma)...]).trimmingCharacters(in: .whitespacesAndNewlines) }
        return attribute("tvg-name", in: line) ?? "Sports Channel"
    }
}

struct SportsHubScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("sportsCustomSourcesJSON") private var sportsCustomSourcesJSON: String = ""
    @AppStorage("sportsFavoriteTeams") private var sportsFavoriteTeams: String = ""
    @AppStorage("sportsScoreTickerEnabled") private var sportsScoreTickerEnabled: Bool = true
    @AppStorage("liveXtreamAccounts") private var liveXtreamAccounts: String = ""
    @StateObject private var liveZone = SportsLiveZoneModel()
    @StateObject private var liveModel = LiveTVSourceModel()
    @AppStorage("sportsAssignedGroups") private var sportsAssignedGroupsRaw: String = ""
    @AppStorage("sportsManualChannelIds") private var sportsManualChannelIdsRaw: String = ""

    private var assignedSportsGroups: Set<String> {
        Set(sportsAssignedGroupsRaw.split(separator: "|").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty })
    }

    private var manualSportsChannelIDs: Set<Int> {
        Set(sportsManualChannelIdsRaw.split(separator: ",").compactMap { Int($0.trimmingCharacters(in: .whitespacesAndNewlines)) })
    }

    private var sportsRows: [(String, [MediaItem])] {
        let assigned = assignedSportsGroups
        let manualIDs = manualSportsChannelIDs
        let assignedChannels = liveModel.channels.filter { channel in
            manualIDs.contains(channel.id) || assigned.contains(channel.category) || assigned.contains(channel.source)
        }
        let items = Array(assignedChannels.prefix(80)).map { channel in
            MediaItem(
                id: "sports-live-\(channel.id)-\(channel.streamURL.hashValue)",
                title: channel.name,
                year: "Live",
                type: "live",
                catalog: channel.source,
                description: channel.description,
                genres: [channel.category, channel.source],
                rating: "",
                posterURL: channel.bestArtworkURL,
                landscapeURL: channel.bestArtworkURL,
                logoURL: channel.bestArtworkURL,
                previewURL: channel.streamURL,
                addonName: channel.category,
                addonIconURL: channel.bestArtworkURL
            )
        }
        return [("Sports Channels", items)]
    }

    private var sportsSourceStatus: String {
        if !manualSportsChannelIDs.isEmpty || !assignedSportsGroups.isEmpty { return "\(manualSportsChannelIDs.count) channel(s) • \(assignedSportsGroups.count) group(s) assigned" }
        return "Sports scores/schedules • sports-only M3U isolated"
    }

    var body: some View {
        ZStack(alignment: .leading) {
            LinearGradient(colors: [Color.black, Color(red: 0.02, green: 0.025, blue: 0.035), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 28) {
                        Color.clear.frame(height: 1).id("sportsTop")

                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Sports")
                                    .font(.system(size: 62, weight: .black, design: .rounded))
                                    .foregroundStyle(.white)
                                Text("Command Center • Scores • Theater • Highlights • PPV Events • Teams • Wrestling • Sports Sources")
                                    .font(.system(size: 24, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.62))
                            }
                            Spacer()
                            SportsStatusPill(title: "Sports Live Zone", subtitle: liveZone.status.ifEmpty(sportsSourceStatus), icon: "sportscourt.fill")
                        }
                        .padding(.horizontal, 86)
                        .padding(.top, 42)

                        if sportsScoreTickerEnabled {
                            SportsScoreTicker(favoriteTeams: sportsFavoriteTeams, liveItems: liveZone.ticker)
                                .padding(.horizontal, 86)
                        }

                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 18) {
                                SportsHeroCard(title: "Live Now", subtitle: "\(max(liveZone.liveNow.count, sportsRows.first?.1.count ?? 0)) active cards", icon: "dot.radiowaves.left.and.right")
                                SportsHeroCard(title: "Today", subtitle: "\(liveZone.today.count) public events", icon: "calendar")
                                SportsHeroCard(title: "Highlights", subtitle: "All-sports video rail", icon: "play.rectangle.fill")
                                SportsHeroCard(title: "PPV Events", subtitle: "Fight, wrestling, big-event watch", icon: "ticket.fill")
                                SportsHeroCard(title: "Scores", subtitle: "Public score feeds", icon: "sportscourt.fill")
                            }
                            .padding(.horizontal, 86)
                            .padding(.vertical, 4)
                        }

                        SportsTeamFocusRail(favoriteTeams: sportsFavoriteTeams, teams: liveZone.favoriteTeams)
                            .padding(.horizontal, 86)

                        SportsLiveEventRail(title: "SPORTS COMMAND CENTER", events: liveZone.commandCenter)
                        SportsLiveEventRail(title: "MY TEAMS PRIORITY", events: liveZone.favoriteTeamCards)
                        SportsLiveEventRail(title: "SPORTS THEATER MODE", events: liveZone.theaterMode)
                        SportsLiveEventRail(title: "PPV / EVENT WATCH", events: liveZone.ppvEvents)
                        SportsLiveEventRail(title: "LIVE NOW", events: liveZone.liveNow)
                        SportsLiveEventRail(title: "SPORTS HEAT MAP", events: liveZone.heatMap)
                        SportsLiveEventRail(title: "TODAY", events: liveZone.today)
                        SportsLiveEventRail(title: "HIGHLIGHTS", events: liveZone.highlights)
                        SportsLiveEventRail(title: "UPCOMING", events: liveZone.upcoming)
                        SportsLiveEventRail(title: "SPORTS SOURCES", events: liveZone.sportsOnlyChannels)

                        if (sportsRows.first?.1.isEmpty ?? true) && liveZone.today.isEmpty && liveZone.sportsOnlyChannels.isEmpty {
                            SportsEmptyState()
                                .padding(.horizontal, 86)
                        } else {
                            ForEach(sportsRows, id: \.0) { row in
                                VStack(alignment: .leading, spacing: 14) {
                                    Text(row.0.uppercased())
                                        .font(.system(size: 20, weight: .black, design: .rounded))
                                        .kerning(1.5)
                                        .foregroundStyle(.white.opacity(0.72))
                                        .padding(.horizontal, 86)
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 18) {
                                            ForEach(row.1) { item in
                                                SportsChannelCard(item: item) {
                                                    if let raw = item.previewURL, let url = URL(string: raw) {
                                                        store.playbackURL = url
                                                        store.playbackItem = item
                                                        store.status = "Playing sports channel: \(item.title)."
                                                    } else {
                                                        store.status = "Sports channel has no playable stream URL yet."
                                                    }
                                                }
                                            }
                                        }
                                        .padding(.horizontal, 86)
                                        .padding(.vertical, 12)
                                    }
                                }
                            }
                        }

                        Spacer().frame(height: 90)
                    }
                }
                .onAppear {
                    proxy.scrollTo("sportsTop", anchor: .top)
                    store.liveQuickPanelOpen = false
                    store.topMenuFocusLocked = false
                    liveModel.loadCachedOrDemo()
                }
            }

            VStack {
                Spacer()
                HStack(spacing: 8) {
                    Image(systemName: "arrow.uturn.left")
                    Text("Press Back to Exit Sports")
                }
                .font(.system(size: 16, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.82))
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(Capsule().fill(Color.black.opacity(0.62)))
                .overlay(Capsule().stroke(Color.white.opacity(0.14), lineWidth: 1))
                .rotationEffect(.degrees(-90))
                .offset(x: -72)
                Spacer()
            }
            .allowsHitTesting(false)
        }
        .onExitCommand { store.selectedTab = .home }
        .task {
            liveModel.loadCachedOrDemo()
            await liveModel.refreshIfNeeded()
            await liveZone.load(favoriteTeams: sportsFavoriteTeams, xtreamAccounts: liveXtreamAccounts, customSources: sportsCustomSourcesJSON)
        }
    }
}

struct SportsScoreTicker: View {
    let favoriteTeams: String
    var liveItems: [String] = []
    @State private var tickerOffset: CGFloat = 0
    private var teams: [String] {
        favoriteTeams
            .components(separatedBy: CharacterSet(charactersIn: ",\n"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }
    private var tickerItems: [String] {
        if !liveItems.isEmpty { return Array(liveItems.prefix(14)) }
        let base = teams.isEmpty ? ["Choose favorite teams", "Add sports-only M3U", "PPV/Event Watch"] : teams
        return base.prefix(8).map { "★ \($0): waiting for verified live feed" } + [
            "NFL • NBA • MLB • NHL • WNBA • NCAA",
            "Soccer • UFC • Boxing • WWE • AEW • TNA • NJPW",
            "F1 • NASCAR • Tennis • Golf • PPV Events",
            "Sports-only M3U and manual sports channels stay isolated"
        ]
    }
    private var tickerText: String {
        tickerItems.joined(separator: "     •     ") + "     •     "
    }
    var body: some View {
        HStack(spacing: 18) {
            Image(systemName: "dot.radiowaves.left.and.right")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(.green)
            GeometryReader { proxy in
                let text = tickerText
                HStack(spacing: 60) {
                    Text(text)
                    Text(text)
                }
                .font(.system(size: 17, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.86))
                .lineLimit(1)
                .offset(x: tickerOffset)
                .frame(height: proxy.size.height, alignment: .center)
                .clipped()
                .onAppear {
                    tickerOffset = proxy.size.width
                    withAnimation(.linear(duration: 24).repeatForever(autoreverses: false)) {
                        tickerOffset = -max(900, proxy.size.width)
                    }
                }
                .onChange(of: text) { _ in
                    tickerOffset = proxy.size.width
                    withAnimation(.linear(duration: 24).repeatForever(autoreverses: false)) {
                        tickerOffset = -max(900, proxy.size.width)
                    }
                }
            }
            .clipped()
        }
        .padding(.horizontal, 20)
        .frame(height: 58)
        .background(RoundedRectangle(cornerRadius: 24, style: .continuous).fill(Color.black.opacity(0.38)))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Color.green.opacity(0.20), lineWidth: 1))
    }
}

struct SportsTeamFocusRail: View {
    let favoriteTeams: String
    var teams: [SportsLiveTeam] = []
    private var fallbackTeams: [String] {
        favoriteTeams
            .components(separatedBy: CharacterSet(charactersIn: ",\n"))
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }
    var body: some View {
        HStack(spacing: 14) {
            if !teams.isEmpty {
                ForEach(teams.prefix(8)) { team in
                    HStack(spacing: 10) {
                        RemoteImageFit(url: team.badgeURL, mode: .fit)
                            .frame(width: 28, height: 28)
                            .clipShape(Circle())
                        VStack(alignment: .leading, spacing: 1) {
                            Text(team.name).lineLimit(1)
                            Text(team.league).font(.system(size: 11, weight: .bold, design: .rounded)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
                        }
                    }
                    .font(.system(size: 16, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color.white.opacity(0.075)))
                    .overlay(Capsule().stroke(Color.cyan.opacity(0.08), lineWidth: 0.8))
                }
            } else {
                ForEach((fallbackTeams.isEmpty ? ["Choose Favorite Teams"] : fallbackTeams).prefix(6), id: \.self) { team in
                    HStack(spacing: 10) {
                        Image(systemName: "star.circle.fill").foregroundStyle(.yellow)
                        Text(team).lineLimit(1)
                    }
                    .font(.system(size: 16, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(Capsule().fill(Color.white.opacity(0.075)))
                    .overlay(Capsule().stroke(Color.cyan.opacity(0.08), lineWidth: 0.8))
                }
            }
        }
    }
}

struct SportsLiveEventRail: View {
    let title: String
    let events: [SportsLiveEvent]
    var body: some View {
        if !events.isEmpty {
            VStack(alignment: .leading, spacing: 14) {
                Text(title)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .kerning(1.5)
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.horizontal, 86)
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 18) {
                        ForEach(events) { event in
                            SportsLiveEventCard(event: event)
                        }
                    }
                    .padding(.horizontal, 86)
                    .padding(.vertical, 8)
                }
            }
        }
    }
}

struct SportsLiveEventCard: View {
    @EnvironmentObject var store: CatalogStore
    let event: SportsLiveEvent
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: {
            if let raw = event.streamURL, let url = URL(string: raw) {
                store.playbackURL = url
                store.playbackItem = MediaItem(id: event.id, title: event.title, year: "Live", type: "live", catalog: event.league, description: event.subtitle, genres: [event.league, event.status], rating: "", posterURL: event.artworkURL, landscapeURL: event.artworkURL, logoURL: event.artworkURL, previewURL: raw, addonName: event.status, addonIconURL: event.artworkURL)
                store.status = "Playing sports source: \(event.title)."
            } else if let raw = event.webURL, let url = URL(string: raw) {
                UIApplication.shared.open(url)
                store.status = "Opening highlight: \(event.title)."
            } else {
                store.status = event.status.lowercased().contains("highlight") ? "Highlight info: \(event.title). This card has verified metadata but no playable public URL." : "Sports info: \(event.title) • \(event.subtitle). Add a playable sports source/channel for Watch Live."
            }
        }) {
            VStack(alignment: .leading, spacing: 12) {
                ZStack(alignment: .topLeading) {
                    RemoteImageFit(url: event.artworkURL, mode: .fill)
                        .frame(width: 330, height: 160)
                        .background(LinearGradient(colors: [event.accent.opacity(0.34), Color.black.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                    Text(event.status.uppercased())
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10).padding(.vertical, 6)
                        .background(Capsule().fill(event.accent.opacity(0.70)))
                        .padding(12)
                }
                Text(event.title).font(.system(size: 20, weight: .black, design: .rounded)).foregroundStyle(.white).lineLimit(2)
                Text("\(event.league) • \(event.subtitle)").font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58)).lineLimit(1)
                HStack(spacing: 7) {
                    Image(systemName: event.status.lowercased().contains("highlight") ? "play.circle.fill" : "info.circle.fill")
                    Text(event.streamURL != nil ? "Watch Live" : (event.webURL != nil ? "Open Highlight" : (event.status.lowercased().contains("highlight") ? "Highlight Info" : "More Info")))
                }
                .font(.system(size: 12, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.86))
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(Capsule().fill(event.accent.opacity(0.22)))
            }
            .padding(14)
            .frame(width: 358, height: 278, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 30, style: .continuous).fill(Color.black.opacity(focused ? 0.72 : 0.42)))
            .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(focused ? Color(red: 0.24, green: 0.72, blue: 1.0).opacity(0.96) : Color.white.opacity(0.10), lineWidth: focused ? 2 : 1))
            .scaleEffect(focused ? 1.035 : 1.0)
        }
        .buttonStyle(SportsNoPlatterButtonStyle())
        .focused($focused)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .contentShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
    }
}

struct SportsHeroCard: View {
    let title: String
    let subtitle: String
    let icon: String
    var body: some View {
        HStack(spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 28, weight: .black))
                .foregroundStyle(.orange)
                .frame(width: 42)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 22, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 15, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.54)).lineLimit(1)
            }
            Spacer()
        }
        .padding(22)
        .frame(width: 400, height: 112)
        .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct SportsStatusPill: View {
    let title: String
    let subtitle: String
    let icon: String
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 24, weight: .black)).foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.system(size: 18, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.56))
            }
        }
        .padding(.horizontal, 20).padding(.vertical, 14)
        .background(Capsule().fill(Color.black.opacity(0.34)))
        .overlay(Capsule().stroke(Color.cyan.opacity(0.18), lineWidth: 1))
    }
}

struct SportsEmptyState: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Sports Command Center ready")
                .font(.system(size: 30, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Add favorite teams or sports-only M3U links in Settings. Normal Live TV sources stay separate while Sports builds dashboards, highlights, PPV/event cards, and theater mode.")
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .lineLimit(3)
        }
        .padding(32)
        .frame(maxWidth: .infinity, minHeight: 210, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 34, style: .continuous).fill(Color.white.opacity(0.045)))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct SportsChannelCard: View {
    let item: MediaItem
    let action: () -> Void
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                RemoteImageFit(url: item.posterURL, mode: .fit)
                    .frame(width: 245, height: 132)
                    .background(Color.black.opacity(0.24))
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                Text(item.title)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(item.addonName ?? item.catalog)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.54))
                    .lineLimit(1)
            }
            .padding(14)
            .frame(width: 278, height: 235, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 28, style: .continuous).fill(Color.black.opacity(focused ? 0.70 : 0.42)))
            .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(focused ? Color(red: 0.24, green: 0.72, blue: 1.0).opacity(0.96) : Color.white.opacity(0.10), lineWidth: focused ? 2 : 1))
            .scaleEffect(focused ? 1.045 : 1.0)
        }
        .buttonStyle(SportsNoPlatterButtonStyle())
        .focused($focused)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
        .contentShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
    }
}

struct LivePlaybackLogoOnly: View {
    let item: MediaItem

    private var smartProgramLine: String {
        let desc = item.description.trimmingCharacters(in: .whitespacesAndNewlines)
        if !desc.isEmpty { return desc }
        let genre = item.genres.filter { !$0.isEmpty }.joined(separator: " • ")
        return genre.isEmpty ? "Smart program info loads from EPG when available" : genre
    }

    var body: some View {
        HStack(spacing: 14) {
            if let logoURL = item.logoURL, !logoURL.isEmpty {
                RemoteImageFit(url: logoURL, mode: .fit)
                    .frame(width: 170, height: 54, alignment: .leading)
                    .clipped()
                    .shadow(color: Color.white.opacity(0.10), radius: 10)
            } else if let posterURL = item.posterURL, !posterURL.isEmpty {
                RemoteImageFit(url: posterURL, mode: .fit)
                    .frame(width: 170, height: 54, alignment: .leading)
                    .clipped()
                    .shadow(color: Color.white.opacity(0.10), radius: 10)
            } else {
                Image(systemName: "tv.fill")
                    .font(.system(size: 34, weight: .black))
                    .foregroundStyle(.white.opacity(0.86))
                    .frame(width: 78, height: 54, alignment: .leading)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(item.title)
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(1)
                Text(smartProgramLine)
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
        }
        .accessibilityLabel("Live TV channel logo")
    }
}

// v536: Global Favorites tab foundation. It keeps the tab visible now and reads the existing Live TV
// My Favorites store so channels added from Live TV appear outside the Live TV surface too.
struct GlobalFavoritesScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("favoriteMediaIds") private var favoriteMediaIdsRaw: String = ""
    @FocusState private var focusedRow: Int?
    @FocusState private var removeFocused: Bool
    @State private var selectedIndex: Int = 0

    private var favoriteKeys: Set<String> { favoriteMediaKeySet(favoriteMediaIdsRaw) }

    private var favoriteItems: [MediaItem] {
        let rows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        var seen = Set<String>()
        return rows.flatMap { $0.items }.filter { item in
            guard item.type == "movie" || item.type == "series" else { return false }
            let key = mediaFavoriteKey(item)
            return favoriteKeys.contains(key) && seen.insert(key).inserted
        }
    }

    private var selectedFavorite: MediaItem? {
        guard !favoriteItems.isEmpty else { return nil }
        return favoriteItems[min(max(selectedIndex, 0), favoriteItems.count - 1)]
    }

    private var row: MediaRow {
        MediaRow(id: "catalog-favorites-quick-panel", title: "Favorite Movies & Shows", items: favoriteItems)
    }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            LinearGradient(colors: [Color.black.opacity(0.96), Color(red: 0.02, green: 0.02, blue: 0.035), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 18) {
                Spacer()
                HStack(alignment: .bottom, spacing: 18) {
                    ThemedPanelLogo(title: "Favorites")
                        .frame(height: 58, alignment: .leading)
                    Text("Movies & Shows quick panel")
                        .font(.system(size: 19, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                    Spacer()
                }

                if favoriteItems.isEmpty {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("No movie or show favorites yet")
                            .font(.system(size: 34, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Hold Select on a movie or show card, then choose Add to Favorites. Live TV channel favorites stay in Live TV → My Favorites.")
                            .font(.system(size: 21, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.62))
                            .lineLimit(3)
                    }
                    .padding(34)
                    .frame(maxWidth: .infinity, minHeight: 240, alignment: .leading)
                    .background(RoundedRectangle(cornerRadius: 34, style: .continuous).fill(Color.white.opacity(0.045)))
                    .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 1))
                    .focusable(true)
                    .focused($focusedRow, equals: 0)
                    .modifier(TransparentTVFocusVisual())
                } else {
                    GridOSFixedSlotCatalogRail(row: row, rowIndex: 0, focusedRow: $focusedRow, selectedIndex: $selectedIndex)

                    HStack(spacing: 14) {
                        if let selectedFavorite {
                            Button("Remove from Favorites") { removeFavorite(selectedFavorite) }
                                .font(.system(size: 18, weight: .black, design: .rounded))
                                .padding(.horizontal, 22)
                                .padding(.vertical, 12)
                                .background(Capsule().fill(removeFocused ? Color.red.opacity(0.70) : Color.white.opacity(0.10)))
                                .overlay(Capsule().stroke(removeFocused ? Color.white.opacity(0.70) : Color.white.opacity(0.14), lineWidth: 1))
                                .buttonStyle(.plain)
                                .focused($removeFocused)
                                .focusEffectDisabled()
                                .modifier(TransparentTVFocusVisual())
                            Text("Press Select on a card to open details")
                                .font(.system(size: 16, weight: .bold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.52))
                        }
                    }
                    .padding(.top, 4)
                }
            }
            .padding(.horizontal, 86)
            .padding(.bottom, 74)
        }
        .onAppear {
            store.liveQuickPanelOpen = false
            store.topMenuFocusLocked = false
            focusedRow = 0
        }
        .onMoveCommand { direction in
            if direction == .up { store.menuFocusToken += 1 }
            if direction == .down && !favoriteItems.isEmpty { removeFocused = true }
        }
        .onExitCommand { store.selectedTab = .home }
    }

    private func removeFavorite(_ item: MediaItem) {
        var keys = favoriteMediaKeySet(favoriteMediaIdsRaw)
        keys.remove(mediaFavoriteKey(item))
        favoriteMediaIdsRaw = keys.sorted().joined(separator: "|")
        selectedIndex = min(selectedIndex, max(favoriteItems.count - 2, 0))
        store.status = "Removed \(item.title) from Favorites."
    }
}

struct FavoriteLiveChannelCard: View {
    let channel: LiveTVChannel
    let action: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                RemoteImageFit(url: channel.bestArtworkURL, mode: .fit)
                    .frame(width: 270, height: 150)
                    .background(Color.black.opacity(0.30))
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                Text(channel.name)
                    .font(.system(size: 21, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text([channel.number, channel.category, channel.source].filter { !$0.isEmpty }.joined(separator: " • "))
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.56))
                    .lineLimit(1)
            }
            .padding(14)
            .frame(width: 304, height: 250, alignment: .topLeading)
            .background(RoundedRectangle(cornerRadius: 30, style: .continuous).fill(Color.black.opacity(focused ? 0.72 : 0.42)))
            .overlay(RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(focused ? Color(red: 0.24, green: 0.72, blue: 1.0).opacity(0.96) : Color.white.opacity(0.10), lineWidth: focused ? 2 : 1))
            .scaleEffect(focused ? 1.04 : 1.0)
        }
        .buttonStyle(.plain)
        .focused($focused)
        .focusEffectDisabled()
        .modifier(TransparentTVFocusVisual())
    }
}