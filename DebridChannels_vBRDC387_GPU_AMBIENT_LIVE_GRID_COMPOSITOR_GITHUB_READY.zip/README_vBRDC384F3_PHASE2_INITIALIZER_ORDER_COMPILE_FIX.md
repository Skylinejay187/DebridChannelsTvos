# vBRDC384F3 — Phase 2 Initializer Order Compile Fix

Base: vBRDC384F2 / 1.0.1086 / build 1086.

GitHub Actions reached Swift compilation and failed at the single `UniversalVideoSurface` call in `DebridChannelsTVOSApp.swift` because Swift's synthesized memberwise initializer requires arguments in stored-property declaration order. `onAetherLiveWindowChanged` had been placed before `onAetherFirstFrameReady`, while `UniversalVideoSurface` declares `onAetherFirstFrameReady` first and `onAetherLiveWindowChanged` after the remaining Aether callbacks.

F3 moves only the existing `onAetherLiveWindowChanged` closure to its correct initializer position: after `onAetherSubtitleTextChanged` and before `onKSBufferUpdate`.

No callback body, timeshift behavior, Aether routing, R7 Live audio/video stabilization, VOD behavior, navigation, top menu, logo, catalogs, or ambient behavior is changed.

Validation:
- `swiftc -parse Sources/DebridChannelsTVOSApp.swift`
- `swiftc -parse Sources/UniversalCodecSupport.swift`
- final ZIP integrity test
