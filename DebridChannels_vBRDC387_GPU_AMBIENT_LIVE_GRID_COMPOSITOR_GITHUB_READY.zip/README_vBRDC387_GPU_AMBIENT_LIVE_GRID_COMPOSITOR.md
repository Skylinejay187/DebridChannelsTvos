# vBRDC387 — GPU Ambient + Live TV Compositor Performance

Version: 1.0.1090 (1090)
Base: vBRDC386R1

## Changes
- Replaces Classic Ambient Smoke's SwiftUI per-frame state animation with a Core Animation compositor/GPU-first surface.
- Smoke textures are generated once and reused; motion is transform/opacity interpolation owned by Core Animation.
- No CADisplayLink, repeating Timer, TimelineView, or per-frame SwiftUI state mutation is used by Classic Ambient Smoke.
- Classic Smoke remains mounted only on the active Live TV grid surface.
- When focused Live TV preview becomes active, Classic Smoke is unmounted and all layer animations are destroyed.
- Full-screen Live TV, VOD, Guide, Search, Media Information, Catalog/non-Live tabs, and inactive app state do not own the Classic Smoke renderer.
- Existing native tvOS focus/grid behavior is preserved; this phase does not replace the focus engine with a custom Metal grid. Existing transform-based card motion remains compositor-friendly.

## Regression locks
- Preserve R7 Live playback stability.
- Preserve F3 Live timeshift.
- Preserve Phase 3/4 VOD cache, amplification, subtitles, and cache visualization.
- Preserve R3 navigation/top-menu/Signal-logo behavior.

## Physical test
Rapidly scroll the Live TV grid with Classic Smoke enabled. Verify smooth focus/card movement. Let a focused preview start and verify smoke stops immediately. Move focus so preview ends and verify smoke recreates cleanly. Open Guide/Catalog/VOD/full-screen Live TV and verify no ambient animation remains active.
