#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REVISION="refs/tags/6.89.1"
VERSION="6.89.1"
REPOSITORY_URL="https://github.com/superuser404notfound/AetherEngine.git"
CACHE_DIR="${ROOT_DIR}/.build-cache/aetherengine-vBRDC358"
EXTRACT_DIR="${CACHE_DIR}/source"
VENDOR_DIR="${ROOT_DIR}/Vendor/AetherEngine"
PATCH_MARKER="${VENDOR_DIR}/.debridchannels-vBRDC358-aether-6.89.1"

if [[ -f "${PATCH_MARKER}" ]] && grep -q "${REVISION}" "${PATCH_MARKER}"; then
  echo "AetherEngine ${VERSION} Debrid Channels vendor already present."
  exit 0
fi

rm -rf "${EXTRACT_DIR}"
mkdir -p "${CACHE_DIR}" "${EXTRACT_DIR}"

echo "============================================================"
echo "DEBRID CHANNELS vBRDC358 FETCHING AETHERENGINE ${VERSION}"
echo "revision=${REVISION}"
echo "mode=namespaced FFmpeg + native live/IPTV host contracts"
echo "============================================================"

git -C "${EXTRACT_DIR}" init -q
git -C "${EXTRACT_DIR}" remote add origin "${REPOSITORY_URL}"
git -C "${EXTRACT_DIR}" config core.sparseCheckout true
mkdir -p "${EXTRACT_DIR}/.git/info"
cat > "${EXTRACT_DIR}/.git/info/sparse-checkout" <<'SPARSE'
/Package.swift
/Sources/AetherEngine/
SPARSE

FETCHED=0
for ATTEMPT in 1 2 3 4 5; do
  if git -C "${EXTRACT_DIR}" fetch --no-tags --depth 1 origin "${REVISION}"; then
    FETCHED=1
    break
  fi
  echo "Pinned AetherEngine fetch attempt ${ATTEMPT} failed; retrying..."
  sleep $((ATTEMPT * 3))
done
if [[ "${FETCHED}" != "1" ]]; then
  echo "ERROR: Could not fetch pinned AetherEngine ${VERSION} revision after retries."
  exit 1
fi

git -C "${EXTRACT_DIR}" checkout -q --detach FETCH_HEAD
SOURCE_DIR="${EXTRACT_DIR}"

# Xcode 16.4 / AppleTVOS 18.5 compatibility for the final tvOS-17 Aether 6.x tag.
python3 - "${SOURCE_DIR}" <<'PYCOMPAT'
from pathlib import Path
import sys
root = Path(sys.argv[1]) / "Sources" / "AetherEngine"
for f in root.rglob("*.swift"):
    text = f.read_text()
    if "import AVFoundation" in text:
        f.write_text(text.replace("import AVFoundation", "@preconcurrency import AVFoundation"))

f = root / "Video" / "VTCapabilityProbe.swift"
text = f.read_text()
old = """        if #available(tvOS 26.2, iOS 26.2, macOS 16.0, visionOS 26.2, *) {
            VTRegisterSupplementalVideoDecoderIfAvailable(kCMVideoCodecType_AV1)
        }
"""
new = """        #if os(macOS)
        if #available(macOS 16.0, *) {
            VTRegisterSupplementalVideoDecoderIfAvailable(kCMVideoCodecType_AV1)
        }
        #endif
"""
assert old in text, "VT supplemental-decoder compatibility anchor changed"
f.write_text(text.replace(old, new))

f = root / "Renderer" / "SampleBufferRenderer.swift"
text = f.read_text()
old = """        if #available(tvOS 26.0, iOS 26.0, macOS 26.0, visionOS 26.0, *) {
            layer.preferredDynamicRange = isHDR ? .high : .standard
        } else {
            #if os(iOS) || os(macOS)
            if #available(iOS 17.0, macOS 14.0, *) {
                layer.wantsExtendedDynamicRangeContent = isHDR
            }
            #endif
        }
"""
new = """        #if !os(tvOS)
        if #available(iOS 26.0, macOS 26.0, visionOS 26.0, *) {
            layer.preferredDynamicRange = isHDR ? .high : .standard
        } else {
            #if os(iOS) || os(macOS)
            if #available(iOS 17.0, macOS 14.0, *) {
                layer.wantsExtendedDynamicRangeContent = isHDR
            }
            #endif
        }
        #endif
"""
assert old in text, "makeDisplayLayer HDR compatibility anchor changed"
text = text.replace(old, new)
old = """        if #available(tvOS 26.0, iOS 26.0, macOS 26.0, visionOS 26.0, *) {
            displayLayer.preferredDynamicRange = isHDR ? .high : .standard
        } else {
            #if os(iOS) || os(macOS)
            if #available(iOS 17.0, macOS 14.0, *) {
                displayLayer.wantsExtendedDynamicRangeContent = isHDR
            }
            #endif
        }
"""
new = """        #if !os(tvOS)
        if #available(iOS 26.0, macOS 26.0, visionOS 26.0, *) {
            displayLayer.preferredDynamicRange = isHDR ? .high : .standard
        } else {
            #if os(iOS) || os(macOS)
            if #available(iOS 17.0, macOS 14.0, *) {
                displayLayer.wantsExtendedDynamicRangeContent = isHDR
            }
            #endif
        }
        #endif
"""
assert old in text, "setHDROutput compatibility anchor changed"
f.write_text(text.replace(old, new))

f = root / "Display" / "DisplayCriteriaController.swift"
text = f.read_text()
old = """    private static func headroomLimitLabel(_ traits: UITraitCollection) -> String {
        guard #available(tvOS 26.0, *) else { return "n/a" }
        switch traits.hdrHeadroomUsageLimit {
        case .active: return "active"
        case .inactive: return "inactive"
        case .unspecified: return "unspecified"
        @unknown default: return "unknown"
        }
    }
"""
new = """    private static func headroomLimitLabel(_ traits: UITraitCollection) -> String {
        // Xcode 16.4 / AppleTVOS 18.5 does not expose this SDK-26 diagnostic property.
        // HDR engagement still uses Aether's currentEDRHeadroom + AVDisplayCriteria path.
        return "n/a"
    }
"""
assert old in text, "headroom diagnostic compatibility anchor changed"
f.write_text(text.replace(old, new))
PYCOMPAT

# vBRDC383R7 Phase-1 Live video cadence correction.
# Keep Aether 6.89.1's normal combined-loop rule intact here. R5/R6 temporarily
# enabled the VOD parked-video/audio-decoupling arm for live-without-DVR sessions;
# physical Apple TV testing confirmed that it stopped the HDHomeRun audio loss, but
# Aether's own #107 comments document that this arm can make queued video late and
# visibly skip when software 1080i decode/deinterlace runs near realtime. R7 moves
# raw live software sessions onto Aether's purpose-built live reader/feeder + bounded
# ring path instead (selected by dvrWindowSeconds in the host bridge), where the
# independent #107 audio look-ahead pump keeps audio smooth without parking video in
# the VOD FIFO. No user-facing timeshift controls are enabled in this phase.

# Debrid Channels intentionally vendors only the core engine. Keep Aether's namespaced
# FFmpeg graph deterministic and the sole FFmpeg graph used by Signal internal playback.
cat > "${SOURCE_DIR}/Package.swift" <<'PACKAGE'
// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AetherEngine",
    platforms: [
        .iOS(.v16),
        .tvOS(.v17),
        .macOS(.v14),
        .visionOS(.v1),
    ],
    products: [
        .library(name: "AetherEngine", targets: ["AetherEngine"]),
    ],
    dependencies: [
        .package(url: "https://github.com/superuser404notfound/FFmpegBuild", .upToNextMinor(from: "3.3.0")),
        .package(url: "https://github.com/superuser404notfound/LibDovi", .upToNextMinor(from: "2.1.0")),
    ],
    targets: [
        .target(
            name: "AetherEngine",
            dependencies: [
                .product(name: "AetherFFmpegBuild", package: "FFmpegBuild"),
                .product(name: "Dovi", package: "LibDovi"),
            ],
            path: "Sources/AetherEngine",
            linkerSettings: [
                .linkedFramework("AVFoundation"),
                .linkedFramework("AVKit"),
                .linkedFramework("CoreMedia"),
                .linkedFramework("CoreVideo"),
                .linkedFramework("VideoToolbox"),
                .linkedFramework("AudioToolbox"),
            ]
        ),
    ],
    // Xcode 16.4 CI compatibility: avoid Swift 6 strict-Sendable diagnostics
    // becoming hard errors inside AVFoundation async imports.
    swiftLanguageModes: [.v5]
)
PACKAGE

# vBRDC385 Phase 3: decoded PCM gain hook used only when Signal's VOD amplification is enabled.
python3 - "${SOURCE_DIR}" <<'PY_AETHER_GAIN'
from pathlib import Path
import sys
root = Path(sys.argv[1]) / "Sources" / "AetherEngine"

audio = root / "Audio" / "AudioDecoder.swift"
s = audio.read_text()
needle = "    private var clock = AudioClockAnchor()\n"
assert needle in s
s = s.replace(needle, needle + "    private var decodedGainLinear: Float = 1.0\n\n    func setGainDB(_ db: Double) {\n        let clamped = max(0, min(12, db))\n        decodedGainLinear = Float(pow(10.0, clamped / 20.0))\n    }\n", 1)
needle = "        guard convertedSamples > 0 else { return }\n\n        // First frame in a new accumulator captures the PTS"
assert needle in s
s = s.replace(needle, "        guard convertedSamples > 0 else { return }\n\n        if decodedGainLinear > 1.0001 {\n            let count = Int(convertedSamples) * Int(channels)\n            tempBuffer.withMemoryRebound(to: Float.self, capacity: count) { samples in\n                for index in 0..<count {\n                    let amplified = samples[index] * decodedGainLinear\n                    samples[index] = max(-1.0, min(1.0, amplified))\n                }\n            }\n        }\n\n        // First frame in a new accumulator captures the PTS", 1)
audio.write_text(s)

host = root / "Native" / "SoftwarePlaybackHost.swift"
s = host.read_text()
needle = "    private(set) var audioDelaySeconds: Double = 0\n"
assert needle in s
s = s.replace(needle, needle + "\n    func setAudioGainDB(_ db: Double) { audioDecoder?.setGainDB(db) }\n", 1)
host.write_text(s)

ext = root / "AetherEngine+SignalAudioGain.swift"
ext.write_text("""import Foundation

extension AetherEngine {
    @MainActor public func setDecodedAudioGainDB(_ db: Double) {
        softwareHost?.setAudioGainDB(max(0, min(12, db)))
    }
}
""")
PY_AETHER_GAIN

# vBRDC358 tracks the final tvOS-17-compatible Aether 6.x release. Keep the upstream
# core source unchanged and only trim the package graph to the engine product Signal uses.
# Contracts below fail the build if this tag no longer provides the host APIs we depend on.
grep -q 'AetherFFmpegBuild' "${SOURCE_DIR}/Package.swift"
grep -q '.upToNextMinor(from: "3.3.0")' "${SOURCE_DIR}/Package.swift"
grep -R -q 'liveSourceReset' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'nativeRemoteHLS' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'liveJoinProfile' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'hasFirstFrameReadyForDisplay' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'liveJoinStartsImmediately' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'preferredDecodePath' "${SOURCE_DIR}/Sources/AetherEngine"
grep -R -q 'public final class HLSLiveIngestReader' "${SOURCE_DIR}/Sources/AetherEngine"
if grep -R -q '^import Libav' "${SOURCE_DIR}/Sources/AetherEngine"; then
  echo "ERROR: Unprefixed Libav import found in Aether ${VERSION} vendor."
  grep -R -n '^import Libav' "${SOURCE_DIR}/Sources/AetherEngine" || true
  exit 1
fi
if ! grep -R -q '^import AetherLibav' "${SOURCE_DIR}/Sources/AetherEngine"; then
  echo "ERROR: Namespaced Aether FFmpeg imports are missing."
  exit 1
fi

rm -rf "${SOURCE_DIR}/.git"
mkdir -p "$(dirname "${VENDOR_DIR}")"
rm -rf "${VENDOR_DIR}"
mv "${SOURCE_DIR}" "${VENDOR_DIR}"
printf 'revision=%s\nversion=%s\nffmpeg=AetherFFmpegBuild-3.3.x-FFmpeg-8.1.2\npatch=vBRDC358B-aether-tvos-xcode16.4-compat\n' "${REVISION}" "${VERSION}" > "${PATCH_MARKER}"

echo "Aether-only AetherEngine ${VERSION} vendor ready at ${VENDOR_DIR}"
