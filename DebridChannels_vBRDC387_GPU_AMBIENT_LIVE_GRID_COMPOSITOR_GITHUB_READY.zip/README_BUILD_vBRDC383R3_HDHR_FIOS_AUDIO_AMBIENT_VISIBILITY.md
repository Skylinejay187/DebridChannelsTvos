# vBRDC383R3 — Phase 1 HDHomeRun / FiOS live-path split + ambient visibility correction

Authoritative lineage: vBRDC382 -> vBRDC383 -> vBRDC383R2 -> vBRDC383R3.
Marketing/build remains 1.0.1085 / 1085 because Phase 1 has not yet passed physical Apple TV validation.

## Physical-device findings carried into R3
- HDHomeRun Live TV: video can continue while audio becomes silent in both Preview and full-screen.
- Verizon FiOS Live TV: audio remains present, but some streams show stutter/video glitches.
- VOD playback is reported clean and is intentionally not changed here.
- vBRDC383R2 ambient presets became effectively invisible on the television.

## Live TV provider-aware Aether routing
R2 applied one ingest-first HLS rule broadly. R3 instead forwards Signal's Live TV source/route hint through the runtime Aether bridge so Preview, Guide Preview and full-screen playback can use the same source policy.

- HDHomeRun / direct tuner MPEG-TS: Aether software/FFmpeg decode is attempted first, with the generic URL route as a bounded fallback. This is the closest Aether-only equivalent to the prior KSPlayer FFmpeg-first transport-stream behavior.
- Verizon FiOS / HLS: native remote HLS is attempted first for frame cadence. Explicit HLS ingest remains a recovery rung, followed by software decode only if needed.
- Generic HLS: native HLS -> explicit ingest -> software recovery.
- Generic non-HLS transport: automatic -> software recovery.
- Live join remains `.standard`; `liveJoinStartsImmediately` remains disabled. `.fastZap` is not restored.
- Live probe/analyze is restored to a conservative 15 MB / 15 s window, matching the older stable KSPlayer-era inspection budget more closely than R2's shortened window.
- Diagnostics use `[Signal][AetherLive][vBRDC383R3]` and now include the classified source profile and redacted live URL.

## Ambient correction
R3 uses the supplied v66 source as the historical visual reference. R2 copied only the blurred bodies but omitted the two moving radial light fields, then added an additional whole-screen black veil. R3 restores the radial foundation and removes that double-dimming.

- Subtle/Cinematic/Heavy preserve the v66 large blurred ellipse/capsule language and 10-second drift.
- Heavy restores the extra visible smoke bank.
- Orbs/Deadlight is a broad overlapped blue/white travelling body plus a faint smoke bed, kept behind the Live TV cards rather than rendered as discrete dots/rings.
- The historical edge-darkening gradient is retained without covering the full effect with an opaque veil.

## Scope lock
No Live TV timeshift, VOD cache, subtitle fix, membership changes, catalog/navigation redesign, Preview Mirror changes, icon changes, or VOD playback changes are included.
Phase 1 remains unconfirmed until physical Apple TV testing proves continuous HDHomeRun audio and acceptable FiOS video cadence.
