import SwiftUI
import AVKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct CinematicAmbientBackground: View {
    @State private var drift = false

    var body: some View {
        ZStack {
            Color.black
            AmbientEffectsLayer(drift: drift)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 10.0).repeatForever(autoreverses: true)) {
                drift.toggle()
            }
        }
    }
}

struct AmbientEffectsLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            RadialGradient(
                colors: [Color.cyan.opacity(drift ? 0.20 : 0.09), Color.blue.opacity(0.05), Color.clear],
                center: drift ? .topTrailing : .bottomLeading,
                startRadius: 40,
                endRadius: 980
            )
            .scaleEffect(drift ? 1.18 : 1.0)
            .blur(radius: 18)

            RadialGradient(
                colors: [Color.white.opacity(0.065), Color.gray.opacity(0.025), Color.clear],
                center: drift ? .bottomTrailing : .topLeading,
                startRadius: 30,
                endRadius: 760
            )
            .offset(x: drift ? -80 : 70, y: drift ? 36 : -30)
            .blur(radius: 34)

            LinearGradient(
                colors: [Color.black.opacity(0.40), Color.clear, Color.black.opacity(0.68)],
                startPoint: .top,
                endPoint: .bottom
            )

            SmokeLayer(drift: drift)
                .opacity(1.0)

            DenseSmokeLayer(drift: drift)
                .opacity(1.0)

            ExtraVisibleSmokeLayer(drift: drift)
                .opacity(1.0)
        }
    }
}

struct SmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Ellipse()
                    .fill(Color.white.opacity(0.030))
                    .frame(width: CGFloat(300 + i * 95), height: CGFloat(92 + i * 31))
                    .blur(radius: CGFloat(36 + i * 5))
                    .rotationEffect(.degrees(Double(i * 11) + (drift ? 5 : -5)))
                    .offset(
                        x: CGFloat(i * 160 - 420) + (drift ? CGFloat(45 - i * 12) : CGFloat(-20 + i * 10)),
                        y: CGFloat(i * 54 - 130) + (drift ? CGFloat(20 - i * 4) : CGFloat(-12 + i * 2))
                    )
            }
        }
    }
}


struct DenseSmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.cyan.opacity(0.055), Color.white.opacity(0.070), Color.blue.opacity(0.032), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(420 + i * 70), height: CGFloat(80 + i * 16))
                    .blur(radius: CGFloat(22 + i * 2))
                    .rotationEffect(.degrees(Double(-18 + i * 7) + (drift ? 8 : -8)))
                    .offset(
                        x: CGFloat(i * 130 - 520) + (drift ? CGFloat(90 - i * 10) : CGFloat(-70 + i * 8)),
                        y: CGFloat(i * 62 - 220) + (drift ? CGFloat(38 - i * 3) : CGFloat(-30 + i * 2))
                    )
            }
        }
        .blendMode(.screen)
    }
}



struct ExtraVisibleSmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<9, id: \.self) { i in
                Ellipse()
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.18), Color.cyan.opacity(0.14), Color.gray.opacity(0.10), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(520 + i * 95), height: CGFloat(110 + i * 22))
                    .blur(radius: CGFloat(24 + i * 3))
                    .rotationEffect(.degrees(Double(i * 13) + (drift ? 14 : -14)))
                    .offset(
                        x: CGFloat(i * 150 - 650) + (drift ? CGFloat(140 - i * 12) : CGFloat(-120 + i * 10)),
                        y: CGFloat(i * 70 - 300) + (drift ? CGFloat(58 - i * 4) : CGFloat(-48 + i * 3))
                    )
            }
        }
        .blendMode(.screen)
    }
}



struct FocusedSmokeOverlay: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<7, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.115), Color.cyan.opacity(0.07), Color.gray.opacity(0.06), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(520 + i * 100), height: CGFloat(84 + i * 18))
                    .blur(radius: CGFloat(28 + i * 3))
                    .rotationEffect(.degrees(Double(-16 + i * 8) + (drift ? 10 : -10)))
                    .offset(
                        x: CGFloat(i * 150 - 520) + (drift ? CGFloat(95 - i * 10) : CGFloat(-80 + i * 8)),
                        y: CGFloat(i * 68 - 210) + (drift ? CGFloat(44 - i * 4) : CGFloat(-34 + i * 3))
                    )
            }
        }
        .blendMode(.screen)
        .opacity(0.95)
    }
}

struct HomeArtworkBackground: View {
    let item: MediaItem

    private var backgroundURL: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black
            RemoteImageFit(url: backgroundURL, mode: .fill)
                .ignoresSafeArea()
                .scaleEffect(1.01)
                .opacity(0.86)
                .saturation(1.08)
                .contrast(1.04)
            // Keep the home readable without blurring or washing out the selected artwork.
            LinearGradient(
                colors: [Color.black.opacity(0.58), Color.black.opacity(0.28), Color.black.opacity(0.72)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
    }
}


struct PreviewAwareHomeBackground: View {
    let item: MediaItem
    let previewActive: Bool

    var body: some View {
        ZStack {
            HomeArtworkBackground(item: item)
            if previewActive, let preview = item.previewURL, let url = URL(string: preview) {
                SilentVideoBackground(url: url)
                    .ignoresSafeArea()
                    .opacity(0.92)
                    .overlay(Color.black.opacity(0.34))
                    .transition(.opacity.animation(.easeInOut(duration: 0.35)))
            }
        }
        .ignoresSafeArea()
    }
}

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        let player = AVPlayer(url: url)
        player.isMuted = true
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem,
            queue: .main
        ) { _ in
            player.seek(to: .zero)
            player.play()
        }
        player.play()
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if let current = controller.player?.currentItem?.asset as? AVURLAsset, current.url == url {
            controller.player?.play()
        } else {
            let player = AVPlayer(url: url)
            player.isMuted = true
            controller.player = player
            player.play()
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack(alignment: .top) {
            switch store.selectedTab {
            case .home:
                NineSlotHome(filter: nil)
            case .movies:
                NineSlotHome(filter: "movie")
            case .shows:
                NineSlotHome(filter: "series")
            case .live:
                LiveTVPlaceholder()
            case .settings:
                SettingsScreen()
            }

            TopMenuBar()

            if let detail = store.selectedDetail {
                DetailPage(item: detail)
                    .zIndex(2000)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .zIndex(3000)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V74_DETAIL_VOD_REAL_APP") }
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                HStack(spacing: 48) {
                    ForEach(AppTab.allCases) { tab in
                        Button {
                            withAnimation(.spring(response: 0.36, dampingFraction: 0.82)) {
                                store.selectedTab = tab
                            }
                        } label: {
                            VStack(spacing: 7) {
                                Text(tab.rawValue)
                                    .font(.system(size: 27, weight: .heavy, design: .serif))
                                    .tracking(1.8)
                                    .foregroundStyle(store.selectedTab == tab ? Color.white : Color.white.opacity(0.70))
                                Capsule()
                                    .fill(store.selectedTab == tab ? Color.cyan : Color.clear)
                                    .frame(width: tab.rawValue.count > 6 ? 78 : 54, height: 5)
                            }
                            .scaleEffect(focusedTab == tab ? 1.10 : 1.0)
                            .shadow(color: focusedTab == tab ? .cyan.opacity(0.85) : .clear, radius: 16)
                        }
                        .buttonStyle(.plain)
                        .focused($focusedTab, equals: tab)
                    }
                }
                .position(x: geo.size.width * 0.56, y: 45)
                .focusSection()

                Button {
                    store.status = "Search UI shell selected. Search wiring is preserved for the next pass."
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(searchFocused ? Color.cyan : Color.white.opacity(0.94))
                        .scaleEffect(searchFocused ? 1.18 : 1.0)
                        .shadow(color: searchFocused ? .cyan.opacity(0.8) : .clear, radius: 16)
                }
                .buttonStyle(.plain)
                .focused($searchFocused)
                // Search sits alone on the far right, matching the approved reference.
                .position(x: geo.size.width - max(64, geo.size.width * 0.055), y: 45)
            }
            .frame(width: geo.size.width, height: 92, alignment: .top)
        }
        .frame(height: 92)
        .padding(.top, 8)
        .zIndex(999)
        .onChange(of: store.menuFocusToken) { _ in
            focusedTab = store.selectedTab
        }
    }
}

struct NineSlotHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex = 0
    @State private var selectedIndex = 0
    @State private var previewReady = false
    @FocusState private var isCanvasFocused: Bool

    var activeRows: [MediaRow] {
        let rows = store.rows
        guard let filter else { return rows }
        return rows.map { row in
            MediaRow(id: row.id, title: row.title, items: row.items.filter { $0.type.lowercased().contains(filter) })
        }.filter { !$0.items.isEmpty }
    }

    var currentRow: MediaRow {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        return rows[min(rowIndex, rows.count - 1)]
    }

    var items: [MediaItem] {
        currentRow.items.isEmpty ? CatalogStore.demoRows()[0].items : currentRow.items
    }

    var focused: MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        return items[normalized(selectedIndex)]
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                // Full-screen cinematic card board. The focused item is the large left card;
                // all logo/metadata/info is INSIDE that card, matching the reference layout.
                NineSlotDeck(items: items, selectedIndex: selectedIndex, rowTitle: currentRow.title, previewReady: previewReady)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

            }
            .contentShape(Rectangle())
            .focusable(true)
            .focused($isCanvasFocused)
            .onAppear { isCanvasFocused = true }
            .onTapGesture { store.openDetail(focused) }
            .onPlayPauseCommand { store.openDetail(focused) }
            .task(id: focused.id) {
                previewReady = false
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                if !Task.isCancelled { previewReady = true }
            }
            .onMoveCommand { direction in
                switch direction {
                case .right:
                    nextItem()
                case .left:
                    previousItem()
                case .down:
                    nextRow()
                case .up:
                    if rowIndex > 0 { previousRow() } else { store.menuFocusToken += 1; isCanvasFocused = false }
                default:
                    break
                }
            }
        }
    }

    func normalized(_ value: Int) -> Int {
        guard !items.isEmpty else { return 0 }
        return (value % items.count + items.count) % items.count
    }

    func nextItem() {
        guard !items.isEmpty else { return }
        withAnimation(.easeOut(duration: 0.20)) {
            selectedIndex = normalized(selectedIndex + 1)
        }
    }

    func previousItem() {
        guard !items.isEmpty else { return }
        withAnimation(.easeOut(duration: 0.20)) {
            selectedIndex = normalized(selectedIndex - 1)
        }
    }

    func nextRow() {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        guard rows.count > 1 else { return }
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = min(rowIndex + 1, rows.count - 1)
            selectedIndex = 0
        }
    }

    func previousRow() {
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}


struct NineSlotDeck: View {
    let items: [MediaItem]
    let selectedIndex: Int
    let rowTitle: String
    let previewReady: Bool
    @State private var pulse = false
    @State private var idleMotion = false
    @State private var bgDrift = false

    // v66 SHAPED SNAP GRID + HOME ARTWORK BACKGROUND:
    // No HStack/VStack flexible sizing is allowed for the main deck.
    // Every card is placed by explicit x/y coordinates from one shared grid.
    // The split line is the exact same y for left and right cards.
    // The left boxes are wider than the poster cells, but their heights are identical
    // to the top/bottom poster rows. Landscape art is clipped inside the fixed frame.
    struct Layout {
        let edge: CGFloat
        let top: CGFloat
        let gap: CGFloat
        let leftW: CGFloat
        let rowH: CGFloat
        let posterW: CGFloat
        let topY: CGFloat
        let bottomY: CGFloat
        let leftX: CGFloat
        let rightStartX: CGFloat
    }

    func layout(in size: CGSize) -> Layout {
        let W = size.width
        let H = size.height

        // v60 uses the approved snap-grid formula:
        // two landscape cards on the left, four portrait cards on the right.
        // All cards share the exact same row height. The left cards are only wider.
        let edge = max(36, min(W, H) * 0.030)
        let top = max(118, H * 0.125)
        let bottom = max(30, H * 0.040)
        let gap = max(16, min(W, H) * 0.016)

        let boardW = W - edge * 2
        let boardH = H - top - bottom

        // A landscape card should be 16:9 and a poster card 2:3.
        // Solve the row height from width AND height, then use the smaller value so
        // nothing can stretch, overflow, or change shape when artwork loads.
        let landscapeAspect: CGFloat = 16.0 / 9.0
        let posterAspect: CGFloat = 2.0 / 3.0
        let rowHFromHeight = (boardH - gap) / 2.0
        let rowHFromWidth = (boardW - gap * 4.0) / (landscapeAspect + posterAspect * 4.0)
        let rowH = max(190, min(rowHFromHeight, rowHFromWidth))

        let leftW = rowH * landscapeAspect
        let posterW = rowH * posterAspect

        // Center the two-row board vertically under the top menu when width becomes
        // the limiting factor on 16:9 screens.
        let usedH = rowH * 2.0 + gap
        let actualTop = top + max(0, (boardH - usedH) / 2.0)

        let topY = actualTop + rowH / 2.0
        let bottomY = actualTop + rowH + gap + rowH / 2.0
        let leftX = edge + leftW / 2.0
        let rightStartX = edge + leftW + gap

        return Layout(edge: edge, top: actualTop, gap: gap, leftW: leftW, rowH: rowH, posterW: posterW, topY: topY, bottomY: bottomY, leftX: leftX, rightStartX: rightStartX)
    }

    var body: some View {
        GeometryReader { geo in
            let L = layout(in: geo.size)

            ZStack(alignment: .topLeading) {
                // Background animation remains underneath; the selected artwork/video is now
                // the visible full-screen layer above it.
                AmbientEffectsLayer(drift: bgDrift)
                    .ignoresSafeArea()
                    .opacity(0.82)

                PreviewAwareHomeBackground(item: itemFor(0), previewActive: previewReady)
                    .id("home-bg-\(itemFor(0).id)-\(previewReady)")
                    .ignoresSafeArea()

                // Visible cinematic smoke now sits ABOVE the focused artwork/video background
                // and below the cards, so the effect stays visible with the selected poster.
                FocusedSmokeOverlay(drift: bgDrift)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .zIndex(20)

                BrandMark(pulse: false)
                    .frame(width: min(geo.size.width * 0.17, 320), height: 74)
                    .position(x: L.edge + min(geo.size.width * 0.17, 320) / 2, y: 48)
                    .zIndex(130)

                // LEFT TOP: fixed-width landscape hero. Same height as every right poster.
                LandscapeHeroCard(item: itemFor(0), rowTitle: rowTitle, pulse: pulse, previewReady: previewReady)
                    .id("hero-\(itemFor(0).id)")
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.topY)
                    .zIndex(70)

                // LEFT BOTTOM: fixed-width Continue Watching. Same size as top-left.
                ContinueWatchingCard(item: itemFor(0), pulse: pulse)
                    .id("continue-\(itemFor(0).id)")
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.bottomY)
                    .zIndex(65)

                // RIGHT SIDE: 4 x 2 poster grid, explicit coordinates, equal heights.
                ForEach(1...8, id: \.self) { slot in
                    let col = (slot - 1) % 4
                    let row = (slot - 1) / 4
                    let x = L.rightStartX + CGFloat(col) * (L.posterW + L.gap) + L.posterW / 2
                    let y = row == 0 ? L.topY : L.bottomY
                    PosterQueueCard(item: itemFor(slot), idleMotion: idleMotion, slot: slot)
                        .id("poster-\(slot)-\(itemFor(slot).id)")
                        .frame(width: L.posterW, height: L.rowH)
                        .clipShape(RoundedRectangle(cornerRadius: 24))
                        // v66: Option G focus-float timing; no old snap/card-slide transition.
                        .position(x: x, y: y)
                        .zIndex(60)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .animation(.easeOut(duration: 0.24), value: selectedIndex)
            .clipped()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.35).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
            withAnimation(.easeInOut(duration: 9.5).repeatForever(autoreverses: true)) {
                bgDrift.toggle()
            }
            // Right-side poster motion is now driven by TimelineView inside each poster,
            // so it never stops or resets when scrolling/focus changes.
        }
    }

    func itemFor(_ slot: Int) -> MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        let index = (selectedIndex + slot) % items.count
        return items[index]
    }
}

struct BrandMark: View {
    let pulse: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "waveform.path.ecg")
                .font(.system(size: 42, weight: .bold))
                .foregroundStyle(Color.cyan)
                .shadow(color: .cyan.opacity(0.36), radius: 6)
            VStack(alignment: .leading, spacing: -2) {
                Text("DEBRID")
                    .font(.system(size: 32, weight: .black))
                Text("CHANNELS")
                    .font(.system(size: 25, weight: .black))
                    .foregroundStyle(Color.cyan)
                Text("PREMIUM")
                    .font(.system(size: 13, weight: .bold))
                    .tracking(8)
                    .foregroundStyle(.white.opacity(0.68))
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .scaleEffect(1.0)
        .allowsHitTesting(false)
    }
}

struct LandscapeHeroCard: View {
    let item: MediaItem
    let rowTitle: String
    let pulse: Bool
    let previewReady: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            HeroLandscapeArtwork(item: item)
                .overlay(
                    ZStack {
                        LinearGradient(colors: [.black.opacity(0.64), .black.opacity(0.12), .clear], startPoint: .leading, endPoint: .trailing)
                        LinearGradient(colors: [.clear, .black.opacity(0.48)], startPoint: .top, endPoint: .bottom)
                    }
                )

            VStack(alignment: .leading, spacing: 10) {
                HeroLogoText(item: item, pulse: pulse)
                    .id("hero-logo-\(item.id)")
                    .frame(maxWidth: 360, maxHeight: 88, alignment: .leading)
                    .padding(.bottom, 8)

                HStack(spacing: 10) {
                    Text(item.year)
                    Text("•")
                    Text(item.type.capitalized)
                    Text("•")
                    Text(item.catalog.isEmpty ? rowTitle : item.catalog)
                }
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white.opacity(0.93))

                HStack(spacing: 10) {
                    ForEach(item.genres.prefix(2), id: \.self) { genre in
                        Text(genre)
                            .font(.system(size: 13, weight: .bold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.42)))
                            .overlay(Capsule().stroke(.white.opacity(0.14), lineWidth: 1))
                    }
                }

                HStack(spacing: 14) {
                    Text("IMDb")
                        .font(.system(size: 16, weight: .black))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.yellow))
                    Text(item.rating)
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(.white)
                }

                Text(item.description)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(3)
                    .frame(maxWidth: 560, alignment: .leading)
            }
            .padding(.leading, 28)
            .padding(.bottom, 22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .overlay(
            RoundedRectangle(cornerRadius: 28)
                .stroke(Color.cyan.opacity(pulse ? 1.0 : 0.72), lineWidth: 4)
        )
        .shadow(color: .cyan.opacity(pulse ? 0.72 : 0.30), radius: pulse ? 30 : 16)
    }
}

struct HeroLandscapeArtwork: View {
    let item: MediaItem

    private var url: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
            RemoteImageFit(url: url, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .clipped()
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    let pulse: Bool
    @State private var logoPulse = false

    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 13 ? 40 : 58, weight: .black, design: .rounded))
                    .italic()
                    .minimumScaleFactor(0.38)
                    .lineLimit(2)
                    .foregroundStyle(LinearGradient(colors: [.white, .cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
        }
        .shadow(color: .cyan.opacity(logoPulse ? 0.95 : 0.35), radius: logoPulse ? 18 : 7)
        .scaleEffect(logoPulse ? 1.022 : 1.0)
        .onAppear { startPulse() }
        .onChange(of: item.id) { _ in startPulse() }
    }

    private func startPulse() {
        logoPulse = false
        withAnimation(.easeInOut(duration: 1.18).repeatForever(autoreverses: true)) {
            logoPulse = true
        }
    }
}


struct ContinueWatchingCard: View {
    let item: MediaItem
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // For now this uses landscape artwork as a last-scene preview placeholder.
            // When resume capture is wired, this same card will load the real saved frame thumbnail.
            HeroLandscapeArtwork(item: item)
                .overlay(Color.black.opacity(0.22))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom))

            Image(systemName: "play.circle.fill")
                .font(.system(size: 84, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .shadow(color: .black.opacity(0.85), radius: 8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            VStack(alignment: .leading, spacing: 8) {
                Text("Continue Watching")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(Color.cyan)
                HStack {
                    Text(item.title)
                        .font(.system(size: 20, weight: .bold))
                        .lineLimit(1)
                    Spacer()
                    Text("35m left")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundStyle(.white)

                GeometryReader { proxy in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.18))
                        Capsule().fill(Color.cyan).frame(width: proxy.size.width * 0.62)
                    }
                }
                .frame(height: 8)
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .shadow(color: .black.opacity(0.75), radius: 18)
    }
}

struct PosterQueueCard: View {
    let item: MediaItem
    let idleMotion: Bool
    let slot: Int

    var body: some View {
        TimelineView(.animation) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate
            let phase = t * 0.18 + Double(slot) * 0.72
            let floatY = sin(phase) * 1.05
            let floatX = cos(phase * 0.55) * 0.45
            let scale = 1.0 + CGFloat(sin(phase * 0.48)) * 0.0035

            ZStack {
                LinearGradient(colors: [.black, .gray.opacity(0.16)], startPoint: .top, endPoint: .bottom)
                RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .clipShape(RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.13), lineWidth: 1))
            .shadow(color: .black.opacity(0.62), radius: 12)
            .offset(x: CGFloat(floatX), y: CGFloat(floatY))
            .scaleEffect(scale)
        }
    }
}



struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @FocusState private var focused: DetailFocus?

    enum DetailFocus: Hashable { case menuHome, menuMovies, menuShows, menuLive, menuSettings, play, trailer, findLinks, back }

    var body: some View {
        ZStack {
            DetailBackground(item: item)
            VStack(spacing: 0) {
                MenuBar(selected: $store.selectedTab, focusToken: store.menuFocusToken)
                    .padding(.top, 28)
                Spacer()
            }
            DetailMainContent(
                item: item,
                focused: $focused,
                onPlay: { Task { await store.playFirstDirectStream(for: item) } },
                onTrailer: { openTrailer() },
                onFindLinks: { Task { await store.findStreams(for: item) } },
                onBack: { store.closeOrBackDetail() }
            )
            .environmentObject(store)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL) {
                    trailerPopup = false
                    self.trailerURL = nil
                }
                .zIndex(50)
            }
        }
        .onAppear { focused = .play }
        .task(id: item.id) {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            guard !Task.isCancelled else { return }
            if let url = store.directPreviewURL(for: item), !trailerPopup {
                trailerURL = url
                trailerPopup = true
            }
        }
        .onExitCommand {
            if trailerPopup { trailerPopup = false } else { store.closeOrBackDetail() }
        }
    }

    private func openTrailer() {
        if let url = store.directPreviewURL(for: item) {
            trailerURL = url
            trailerPopup = true
        } else {
            store.status = "No direct trailer URL available yet. Backend/resolver must convert YouTube IDs or non-direct trailer sources."
        }
    }
}

struct DetailBackground: View {
    let item: MediaItem
    var body: some View {
        ZStack {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                .ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.18), .black.opacity(0.72), .black.opacity(0.94)], startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.25), .clear, .black.opacity(0.72)], startPoint: .leading, endPoint: .trailing)
                .ignoresSafeArea()
        }
    }
}

struct DetailMainContent: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    var focused: FocusState<DetailPage.DetailFocus?>.Binding
    let onPlay: () -> Void
    let onTrailer: () -> Void
    let onFindLinks: () -> Void
    let onBack: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 26) {
            Spacer(minLength: 170)
            DetailHeroInfo(item: item)
            DetailActionButtons(focused: focused, onPlay: onPlay, onTrailer: onTrailer, onFindLinks: onFindLinks, onBack: onBack)
            StreamLinksPanel(item: item)
                .environmentObject(store)
                .frame(width: 980)
            MoreLikeThisSection(current: item)
                .environmentObject(store)
            Spacer(minLength: 40)
        }
        .padding(.leading, 84)
        .padding(.trailing, 70)
    }
}

struct DetailHeroInfo: View {
    let item: MediaItem
    var body: some View {
        HStack(alignment: .center, spacing: 38) {
            RemoteImageFit(url: item.posterURL, mode: .fill)
                .frame(width: 230, height: 345)
                .clipShape(RoundedRectangle(cornerRadius: 24))
                .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.18), lineWidth: 1.5))
                .shadow(color: .black.opacity(0.45), radius: 18)

            VStack(alignment: .leading, spacing: 18) {
                HeroLogoText(item: item, pulse: true)
                    .frame(width: 780, height: 124, alignment: .leading)
                DetailMetaLine(item: item)
                DetailRatingsRow(item: item)
                Text(item.description)
                    .font(.system(size: 27, weight: .medium))
                    .lineLimit(3)
                    .foregroundStyle(.white.opacity(0.94))
                    .frame(width: 980, alignment: .leading)
                CreditsPanel(item: item)
            }
        }
    }
}

struct DetailMetaLine: View {
    let item: MediaItem
    var body: some View {
        Text("\(item.year)  •  \(item.type.capitalized)  •  \(item.genres.prefix(3).joined(separator: "  •  "))")
            .font(.system(size: 27, weight: .heavy))
            .foregroundStyle(.white.opacity(0.92))
    }
}

struct DetailRatingsRow: View {
    let item: MediaItem
    var body: some View {
        HStack(spacing: 18) {
            ScoreBadge(title: "IMDb", value: item.rating.isEmpty ? "—" : item.rating, color: .yellow, textColor: .black)
            ScoreBadge(title: "RT", value: "—", color: .red, textColor: .white)
            ScoreBadge(title: "Popcorn", value: "—", color: .orange, textColor: .white)
        }
    }
}

struct ScoreBadge: View {
    let title: String
    let value: String
    let color: Color
    let textColor: Color
    var body: some View {
        HStack(spacing: 8) {
            Text(title)
                .font(.system(size: 18, weight: .black))
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(RoundedRectangle(cornerRadius: 6).fill(color))
                .foregroundStyle(textColor)
            Text(value)
                .font(.system(size: 28, weight: .black))
                .foregroundStyle(.white)
        }
    }
}

struct CreditsPanel: View {
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Directors: available when credits metadata is provided")
            Text("Stars: actor information appears here from backend/Stremio credits metadata")
        }
        .font(.system(size: 21, weight: .semibold))
        .foregroundStyle(.white.opacity(0.72))
    }
}

struct DetailActionButtons: View {
    var focused: FocusState<DetailPage.DetailFocus?>.Binding
    let onPlay: () -> Void
    let onTrailer: () -> Void
    let onFindLinks: () -> Void
    let onBack: () -> Void

    var body: some View {
        HStack(spacing: 18) {
            DetailButton(title: "PLAY", focus: .play, focused: focused, action: onPlay)
            DetailButton(title: "TRAILER", focus: .trailer, focused: focused, action: onTrailer)
            DetailButton(title: "FIND LINKS", focus: .findLinks, focused: focused, action: onFindLinks)
            DetailButton(title: "BACK", focus: .back, focused: focused, action: onBack)
        }
    }
}

struct StreamLinksPanel: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Selectable Links")
                .font(.system(size: 24, weight: .black))
                .foregroundStyle(.cyan)
            if store.streamLinks.isEmpty {
                EmptyLinksMessage(message: store.lastStreamMessage)
            } else {
                StreamLinksScroll(item: item)
                    .environmentObject(store)
            }
        }
        .padding(18)
        .background(RoundedRectangle(cornerRadius: 24).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }
}

struct EmptyLinksMessage: View {
    let message: String
    var body: some View {
        Text(message.isEmpty ? "No links loaded yet. Press Find Links." : message)
            .font(.system(size: 19, weight: .semibold))
            .foregroundStyle(.white.opacity(0.70))
    }
}

struct StreamLinksScroll: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 14) {
                ForEach(store.streamLinks) { link in
                    StreamLinkButton(item: item, link: link)
                        .environmentObject(store)
                }
            }
        }
    }
}

struct StreamLinkButton: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let link: StreamLink

    var body: some View {
        Button {
            if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                store.playbackItem = item
                store.playbackURL = url
            } else {
                store.status = "Selected link is not direct playable yet. Resolver/backend conversion is needed."
            }
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                Text(link.quality).font(.system(size: 20, weight: .black))
                Text(link.size).font(.system(size: 15, weight: .bold))
                Text(link.source).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white.opacity(0.65))
            }
            .frame(width: 165, height: 74, alignment: .leading)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 18).fill(link.isDirectPlayable ? Color.cyan.opacity(0.20) : Color.white.opacity(0.08)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(link.isDirectPlayable ? Color.cyan.opacity(0.70) : Color.white.opacity(0.18), lineWidth: 1.5))
        }
        .buttonStyle(.plain)
    }
}

struct MoreLikeThisSection: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("More Like This")
                .font(.system(size: 34, weight: .black))
                .foregroundStyle(.white)
            RelatedMoviesRow(current: current) { selected in
                store.openDetail(selected)
            }
        }
    }
}

struct RelatedMoviesRow: View {
    let current: MediaItem
    let onSelect: (MediaItem) -> Void

    var relatedItems: [MediaItem] {
        let all = CatalogStore.demoRows().flatMap { $0.items }
        return Array(all.filter { $0.id != current.id }.prefix(6))
    }

    var body: some View {
        HStack(spacing: 24) {
            ForEach(relatedItems) { item in
                RelatedMovieCard(item: item, onSelect: onSelect)
            }
        }
    }
}

struct RelatedMovieCard: View {
    let item: MediaItem
    let onSelect: (MediaItem) -> Void
    var body: some View {
        Button { onSelect(item) } label: {
            ZStack(alignment: .bottomLeading) {
                RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                Text(item.title)
                    .font(.system(size: 19, weight: .black))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .padding(14)
            }
            .frame(width: 210, height: 310)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.18), lineWidth: 1))
            .shadow(color: .black.opacity(0.60), radius: 12)
        }
        .buttonStyle(.plain)
    }
}

struct TrailerPopup: View {
    let url: URL
    let close: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(spacing: 18) {
                SilentVideoBackground(url: url)
                    .frame(width: 1540, height: 720)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .background(Color.black)
                Button("Close Trailer", action: close)
                    .font(.system(size: 26, weight: .bold))
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL
    @State private var player: AVPlayer? = nil
    @FocusState private var focusedControl: PlayerControl?

    enum PlayerControl: Hashable { case back10, play, forward10, audio, subtitles, episodes, zoom, settings, close }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            PlayerVideoLayer(player: player)
            PlayerGradientLayer()
            PlayerOverlayContent(item: item, player: player, focusedControl: $focusedControl, onToggle: togglePlay, onSeek: seek, onClose: { store.closePlayer() })
        }
        .onAppear {
            let av = AVPlayer(url: url)
            player = av
            av.play()
            focusedControl = .play
        }
        .onDisappear { player?.pause() }
        .onExitCommand { store.closePlayer() }
    }

    private func togglePlay() {
        guard let player else { return }
        if player.timeControlStatus == .playing { player.pause() } else { player.play() }
    }

    private func seek(seconds: Double) {
        guard let player else { return }
        let current = CMTimeGetSeconds(player.currentTime())
        let target = CMTime(seconds: max(0, current + seconds), preferredTimescale: 600)
        player.seek(to: target)
    }
}

struct PlayerVideoLayer: View {
    let player: AVPlayer?
    var body: some View {
        Group {
            if let player { VideoPlayer(player: player) } else { Color.black }
        }
        .ignoresSafeArea()
    }
}

struct PlayerGradientLayer: View {
    var body: some View {
        LinearGradient(colors: [.black.opacity(0.28), .clear, .black.opacity(0.94)], startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
    }
}

struct PlayerOverlayContent: View {
    let item: MediaItem
    let player: AVPlayer?
    var focusedControl: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let onToggle: () -> Void
    let onSeek: (Double) -> Void
    let onClose: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            PlayerInfoBlock(item: item)
            PlayerProgressBlock()
            PlayerControlsRow(player: player, focusedControl: focusedControl, onToggle: onToggle, onSeek: onSeek, onClose: onClose)
        }
        .foregroundStyle(.white)
        .padding(.leading, 76)
        .padding(.bottom, 64)
    }
}

struct PlayerInfoBlock: View {
    let item: MediaItem
    var body: some View {
        HStack(alignment: .bottom, spacing: 28) {
            RemoteImageFit(url: item.posterURL, mode: .fill)
                .frame(width: 185, height: 275)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(.white.opacity(0.18), lineWidth: 1))
            VStack(alignment: .leading, spacing: 10) {
                HeroLogoText(item: item, pulse: true)
                    .frame(width: 760, height: 112, alignment: .leading)
                Text("\(item.year)  •  \(item.type.capitalized)  •  \(item.genres.prefix(2).joined(separator: "  •  "))  •  Direct Play")
                    .font(.system(size: 25, weight: .heavy))
                Text("★ \(item.rating)   Cache: active while playing")
                    .font(.system(size: 23, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.82))
                Text(item.description)
                    .font(.system(size: 25, weight: .medium))
                    .lineLimit(2)
                    .frame(width: 1080, alignment: .leading)
            }
        }
    }
}

struct PlayerProgressBlock: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            GeometryReader { proxy in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.22))
                    Capsule().fill(Color.white).frame(width: proxy.size.width * 0.18)
                }
            }
            .frame(width: 1540, height: 8)
            HStack { Text("1:14"); Spacer(); Text("1:35:25") }
                .font(.system(size: 20, weight: .semibold))
                .frame(width: 1540)
                .foregroundStyle(.white.opacity(0.88))
        }
        .padding(.top, 6)
    }
}

struct PlayerControlsRow: View {
    let player: AVPlayer?
    var focusedControl: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let onToggle: () -> Void
    let onSeek: (Double) -> Void
    let onClose: () -> Void

    var body: some View {
        HStack(spacing: 18) {
            PlayerButton(title: "-10", focus: .back10, focused: focusedControl) { onSeek(-10) }
            PlayerButton(title: player?.timeControlStatus == .playing ? "PAUSE" : "PLAY", focus: .play, focused: focusedControl) { onToggle() }
            PlayerButton(title: "+10", focus: .forward10, focused: focusedControl) { onSeek(10) }
            PlayerButton(title: "AUDIO", focus: .audio, focused: focusedControl) { }
            PlayerButton(title: "SUBTITLES", focus: .subtitles, focused: focusedControl) { }
            PlayerButton(title: "EPISODES", focus: .episodes, focused: focusedControl) { }
            PlayerButton(title: "ZOOM", focus: .zoom, focused: focusedControl) { }
            PlayerButton(title: "SETTINGS", focus: .settings, focused: focusedControl) { }
            PlayerButton(title: "CLOSE", focus: .close, focused: focusedControl) { onClose() }
        }
        .font(.system(size: 22, weight: .black))
    }
}

struct PlayerButton: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(Capsule().fill(focused.wrappedValue == focus ? Color.white : Color.black.opacity(0.48)))
                .foregroundStyle(focused.wrappedValue == focus ? Color.black : Color.white)
                .overlay(Capsule().stroke(.white.opacity(0.22), lineWidth: 1.2))
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct DetailButton: View {
    let title: String
    let focus: DetailPage.DetailFocus
    var focused: FocusState<DetailPage.DetailFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 26, weight: .black))
                .foregroundStyle(.white)
                .padding(.horizontal, 34)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.cyan.opacity(0.75) : Color.white.opacity(0.12)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.cyan : Color.white.opacity(0.18), lineWidth: focused.wrappedValue == focus ? 3 : 1))
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @FocusState private var focused: SettingsFocus?

    enum SettingsFocus: Hashable { case manifest, add, load, loadAll, reset, home, movies, shows, live }

    var body: some View {
        ZStack {
            CinematicAmbientBackground().ignoresSafeArea()

            VStack(alignment: .leading, spacing: 22) {
                Text("Settings")
                    .font(.system(size: 62, weight: .black))
                    .foregroundStyle(.white)
                    .padding(.top, 132)

                VStack(alignment: .leading, spacing: 16) {
                    Text("Stremio JSON Catalogs")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)

                    TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(20)
                        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.cyan : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
                        .focused($focused, equals: .manifest)
                        .frame(width: 1180)

                    HStack(spacing: 16) {
                        SettingsButton(title: "Add JSON", focus: .add, focused: $focused) {
                            store.addManifestURL(manifestURL)
                            manifestURL = ""
                        }
                        SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL", focus: .load, focused: $focused) {
                            Task { await store.loadManifest(urlString: manifestURL) }
                        }
                        SettingsButton(title: "Load All Catalogs", focus: .loadAll, focused: $focused) {
                            Task { await store.loadAllManifests() }
                        }
                        SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                            store.resetDemo()
                        }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Saved JSON URLs")
                            .font(.system(size: 20, weight: .black))
                            .foregroundStyle(.cyan)
                        ForEach(store.manifestURLs.prefix(5), id: \.self) { url in
                            Text("• \(url)")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(.white.opacity(0.72))
                                .lineLimit(1)
                                .frame(width: 1120, alignment: .leading)
                        }
                    }
                    .padding(.top, 4)

                    Text("Build v74 V66 DETAIL VOD REAL APP")
                        .font(.system(size: 22, weight: .black))
                        .foregroundStyle(Color.cyan)
                    Text(store.status)
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .frame(width: 1180, alignment: .leading)
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                VStack(alignment: .leading, spacing: 14) {
                    Text("Quick Navigation")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)
                    HStack(spacing: 18) {
                        SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                        SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                        SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                        SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
                    }
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                Spacer()
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
        }
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct LiveTVPlaceholder: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 24) {
                Text("Live TV")
                    .font(.system(size: 76, weight: .black))
                Text("Live TV layout is preserved for the next native tvOS guide pass.")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            }
            .foregroundStyle(.white)
        }
    }
}
