# Debrid Channels tvOS Build From ZIP

Upload the contents of this repo to GitHub. The workflow searches all ZIP files, extracts the source ZIP that contains `DebridChannelsTVOS.xcodeproj`, builds the tvOS app unsigned, and uploads an unsigned IPA artifact.

Use Actions > Build tvOS IPA From ZIP > Run workflow.
