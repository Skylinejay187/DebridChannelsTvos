# vBRDC388R3K1F2 — Kingfisher MainActor Compile Fix

Version: 1.0.1100 (1100)

Narrow compile-only follow-up to vBRDC388R3K1F1.

- Keeps Kingfisher 8.11.0 and the R3 single-active-surface artwork architecture intact.
- Uses `KF.ImageResource` to remove the deprecated/ambiguous resource spelling.
- Marks the local Kingfisher `retrieve` helper `@MainActor`, matching the existing main-actor-owned request registry and cancellation box.
- No playback, Live TV, timeshift, trailer, VOD cache, ambient, navigation, or surface-quiescence behavior changes.
