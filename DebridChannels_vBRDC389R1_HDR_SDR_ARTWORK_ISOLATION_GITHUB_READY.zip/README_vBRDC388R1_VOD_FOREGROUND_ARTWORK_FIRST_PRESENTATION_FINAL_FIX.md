# vBRDC388R1 — VOD Foreground Artwork First-Presentation Final Fix

Version: 1.0.1094 (1094)
Base: vBRDC388 / 1.0.1093

## Physical regression addressed
Visible VOD artwork could be empty on the first presentation and then appear after dismissing/reopening. The same lifecycle symptom affected the VOD overlay, Cast Explorer and episode/season artwork.

## Root cause repaired
PremiumRemoteImageLoader's mounted-blank rehydration pass was globally disabled whenever exclusive VOD playback was active. Visible VOD UI already opts into `publishDuringPlayback`, but a mounted loader whose first request was cancelled/deferred could not rehydrate until playback ended. Reopening the surface created a new loader against the now-warm cache, masking the ownership bug.

R1 makes mounted-blank recovery ownership-aware: the global pass can run during playback, but each loader may restart only when it explicitly owns visible playback artwork (`allowPublicationDuringPlayback`). Decorative/catalog/background artwork remains gated.

The VOD overlay and VOD panels now request a targeted mounted-blank recovery when they become visible. This covers overlay, Cast Explorer, Episodes/season cards and Spotlight artwork that already use the bounded playback-artwork contract without adding timers, forced view identity changes, or broad cache churn.

## Spotlight Hub Related on Trakt
Related cards now consume the available row width instead of using a hard-coded 82-point width. The existing four-item cap and Spotlight design remain, while cards distribute across the row and use the full available artwork area.

## Regression locks preserved
- vBRDC388 trailer display-handoff hardening and smooth Aether trailer cadence
- R2 Classic Smoke appearance/lifecycle
- R3 Unity/navigation behavior
- Live R7 playback stability and Phase 2 timeshift
- VOD cache/subtitle/amplification behavior
- No KSPlayer/Aether architecture change in this repair

## Validation
- `swiftc -parse Sources/RemoteImageFit.swift Sources/DebridChannelsTVOSApp.swift` passed.
- Main and Top Shelf plist lint passed.
- Version metadata synchronized to 1.0.1094 / 1094; release ID vBRDC388R1.

Physical Apple TV remains authoritative. Test first-open VOD overlay, first-open Cast Explorer, multiple cast members, Episodes S1→S2→S1, Spotlight Related on Trakt, then trailer→VOD return.
