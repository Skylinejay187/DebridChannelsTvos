# vBRDC389R1 — HDR/SDR Artwork Isolation

Physical Apple TV regression fix folded into Aether Finalization Phase 1.

## Fix
When HDR/Dolby Vision VOD is active, Signal's SwiftUI artwork hierarchy is explicitly restricted to standard dynamic range on tvOS 18+ using SwiftUI's `allowedDynamicRange(.standard)` environment.

This is intentionally scoped to SwiftUI image rendering. It does **not** disable HDR/Dolby Vision video, alter Aether decoding, or disable tvOS Match Dynamic Range / Match Frame Rate for normal VOD. Trailer-only display-match suppression remains separate.

Affected UI includes shared RemoteImageFit artwork and descendant VOD overlay, Spotlight Hub, cast/profile, provider, and catalog imagery.

## Regression locks
No changes to Aether decode/cadence, Live R7 playback, timeshift, VOD cache, Kingfisher, trailer decoder path, approved ambient appearance, navigation, or Unity quiescence.
