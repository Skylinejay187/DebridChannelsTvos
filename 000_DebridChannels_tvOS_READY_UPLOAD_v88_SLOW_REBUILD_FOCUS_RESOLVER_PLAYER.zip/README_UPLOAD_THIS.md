# Debrid Channels tvOS v88 - Slow Rebuild / Focus Resolver Stabilization

Upload this ZIP directly to GitHub. It preserves the v73-approved Home and media detail visual baseline while rebuilding the runtime problem areas reported from Apple TV testing.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V88_SLOW_REBUILD_FOCUS_RESOLVER_PLAYER`

What changed in v88:
1. Remote/select debounce added so one Select press does not double-fire actions or overshoot focus.
2. Home DPAD movement throttled and slowed slightly to reduce fast skipping.
3. Problematic right-side poster animation removed completely; right cards are now static.
4. Media information text panel shifted further right and narrowed so it no longer blocks Search Links / stream chips.
5. Top menu stays at the same visible hero position instead of dropping lower/looking hidden on detail.
6. Stremio stream search expanded across all configured manifests, movie/series endpoint candidates, and ID candidates.
7. Stream results deduplicate and sort by quality while loading progressively.
8. v73 Home/detail layout geometry is preserved; this is not a redesign.

Codec truth:
The included player remains AVFoundation/AVPlayerLayer with the custom Debrid overlay. Full unsupported-codec coverage still needs compiled tvOS libVLC/FFmpeg frameworks in a later package.
