import SwiftUI
import Foundation

struct MediaItem: Identifiable, Hashable {
    let id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String? = nil
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StreamLink: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String?
    var quality: String
    var size: String
    var source: String

    var isDirectPlayable: Bool {
        guard let url else { return false }
        let lower = url.lowercased()
        return lower.hasPrefix("http") && (lower.contains(".mp4") || lower.contains(".m3u8") || lower.contains(".mov") || lower.contains(".m4v") || lower.contains(".mkv") || lower.contains(".webm") || lower.contains(".ts") || lower.contains("/stream/") || lower.contains("/download/") || lower.contains("/hls/"))
    }
}

struct StremioStreamResponse: Decodable {
    var streams: [StremioStream]?
}

struct StremioStream: Decodable {
    var title: String?
    var name: String?
    var url: String?
    var infoHash: String?
    var externalUrl: String?
    var fileIdx: Int?
    var behaviorHints: StremioBehaviorHints?
}

struct StremioBehaviorHints: Decodable {
    var filename: String?
    var videoSize: Int64?
}

struct StremioManifest: Decodable {
    var name: String?
    var catalogs: [StremioCatalog]?
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?
}

struct StremioTrailer: Decodable {
    var source: String?
    var type: String?
    var title: String?
}

struct StremioVideo: Decodable {
    var url: String?
    var src: String?
    var source: String?
    var type: String?
    var title: String?
}

struct StremioMeta: Decodable {
    var id: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
    var trailers: [StremioTrailer]?
    var videos: [StremioVideo]?
    var trailer: String?
    var preview: String?
    var previewVideo: String?
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case live = "Live TV"
    case settings = "Settings"
    var id: String { rawValue }
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var selectedTab: AppTab = .home
    @Published var status: String = "Build v88 SLOW REBUILD: v73 visuals preserved, remote input debounced, right poster animation removed, Stremio stream scan expanded, detail info shifted right."
    @Published var menuFocusToken: Int = 0
    @Published var isLoading: Bool = false
    @Published var manifestURLs: [String] = []
    @Published var selectedDetail: MediaItem? = nil
    @Published var playbackURL: URL? = nil
    @Published var playbackItem: MediaItem? = nil
    @Published var streamLinks: [StreamLink] = []
    @Published var lastStreamMessage: String = ""
    @Published var detailBackStack: [MediaItem] = []

    private let manifestsKey = "stremioManifestURLs"

    init() {
        let saved = UserDefaults.standard.stringArray(forKey: manifestsKey) ?? []
        if saved.isEmpty {
            manifestURLs = ["https://v3-cinemeta.strem.io/manifest.json"]
        } else {
            manifestURLs = saved
        }
    }

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func directPreviewURL(for item: MediaItem) -> URL? {
        guard let preview = item.previewURL, let url = URL(string: preview) else { return nil }
        let lower = preview.lowercased()
        // AVPlayer needs a direct MP4/M3U8/MOV style URL. YouTube page IDs/links must be converted by backend.
        if lower.contains("youtube.com") || lower.contains("youtu.be") { return nil }
        return url
    }

    func findStreams(for item: MediaItem) async -> [StreamLink] {
        lastStreamMessage = "Searching all configured Stremio addons for \(item.title)…"
        streamLinks = []

        let urlSession = URLSession.shared
        let typeCandidates = streamTypeCandidates(for: item)
        let idCandidates = streamIDCandidates(for: item)
        var found: [StreamLink] = []
        var seenKeys = Set<String>()
        var attempts = 0

        for manifest in manifestURLs {
            guard let manifestURL = URL(string: manifest) else { continue }
            let base = normalizedStremioBase(from: manifestURL.absoluteString)
            let sourceName = manifestURL.host ?? "Stremio"

            for type in typeCandidates {
                for streamID in idCandidates {
                    guard let encodedID = streamID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let streamURL = URL(string: "\(base)/stream/\(type)/\(encodedID).json") else { continue }
                    attempts += 1
                    do {
                        let (data, response) = try await urlSession.data(from: streamURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioStreamResponse.self, from: data)
                        for stream in decoded.streams ?? [] {
                            let title = stream.title ?? stream.name ?? stream.behaviorHints?.filename ?? "Stream"
                            let playableURL = stream.url ?? stream.externalUrl
                            let sizeText: String
                            if let bytes = stream.behaviorHints?.videoSize, bytes > 0 {
                                let gb = Double(bytes) / 1_073_741_824.0
                                sizeText = String(format: "%.1f GB", gb)
                            } else {
                                sizeText = "Unknown size"
                            }
                            let lower = title.lowercased()
                            let quality: String
                            if lower.contains("2160") || lower.contains("4k") { quality = "4K" }
                            else if lower.contains("1080") { quality = "1080p" }
                            else if lower.contains("720") { quality = "720p" }
                            else if lower.contains("480") { quality = "480p" }
                            else { quality = "Auto" }

                            let key = "\(sourceName)|\(playableURL ?? stream.infoHash ?? title)|\(stream.fileIdx ?? -1)"
                            guard !seenKeys.contains(key) else { continue }
                            seenKeys.insert(key)
                            found.append(StreamLink(title: title, url: playableURL, quality: quality, size: sizeText, source: sourceName))
                        }

                        if !found.isEmpty {
                            streamLinks = found
                            lastStreamMessage = "Found \(found.count) link(s) so far from \(sourceName)…"
                        }
                    } catch {
                        continue
                    }
                }
            }
        }

        let sorted = found.sorted { lhs, rhs in
            let rank: [String: Int] = ["4K": 0, "1080p": 1, "720p": 2, "480p": 3, "Auto": 4]
            return (rank[lhs.quality] ?? 9) < (rank[rhs.quality] ?? 9)
        }
        streamLinks = sorted
        if sorted.isEmpty {
            lastStreamMessage = "No stream links found for \(item.title) after \(attempts) stream endpoint checks. Add addons that expose /stream/movie or /stream/series links, or use a backend resolver for debrid/magnet-only addons."
        } else {
            lastStreamMessage = "Found \(sorted.count) total stream link(s) for \(item.title) across all configured addons."
        }
        return sorted
    }

    private func normalizedStremioBase(from manifest: String) -> String {
        var base = manifest
        if base.hasSuffix("/manifest.json") { base.removeLast("/manifest.json".count) }
        if base.hasSuffix("manifest.json") { base.removeLast("manifest.json".count) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    private func streamTypeCandidates(for item: MediaItem) -> [String] {
        let lower = item.type.lowercased()
        if lower.contains("series") || lower.contains("show") { return ["series", "movie"] }
        return ["movie", "series"]
    }

    private func streamIDCandidates(for item: MediaItem) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !ordered.contains(trimmed) else { return }
            ordered.append(trimmed)
        }

        add(item.id)
        if let colon = item.id.split(separator: ":").first { add(String(colon)) }
        if item.id.hasPrefix("tt") == false, let range = item.id.range(of: "tt[0-9]+", options: .regularExpression) {
            add(String(item.id[range]))
        }
        return ordered
    }

    func playFirstDirectStream(for item: MediaItem) async {
        let links = await findStreams(for: item)
        if let direct = links.first(where: { $0.isDirectPlayable }), let raw = direct.url, let url = URL(string: raw) {
            startPlayback(item: item, url: url, label: "Playing \(direct.quality) link for \(item.title).")
        } else if let preview = directPreviewURL(for: item) {
            // v84 real-player test path: when a catalog has no direct movie links yet, PLAY still opens
            // the custom Debrid player with the direct preview/sample URL so the full VOD surface can be tested.
            startPlayback(item: item, url: preview, label: "No resolved VOD link found, opening direct preview stream in the custom Debrid player for testing.")
        } else {
            status = links.isEmpty ? lastStreamMessage : "Links found, but none are direct playable URLs yet. Debrid/link resolver backend is needed for magnet/infoHash streams."
        }
    }

    func startPlayback(item: MediaItem, url: URL, label: String) {
        playbackItem = item
        playbackURL = url
        status = label
    }

    func closePlayer() {
        playbackURL = nil
        playbackItem = nil
    }

    func openDetail(_ item: MediaItem, pushCurrent: Bool = false) {
        if pushCurrent, let current = selectedDetail {
            detailBackStack.append(current)
        } else if !pushCurrent {
            detailBackStack.removeAll()
        }
        selectedDetail = item
    }

    func closeDetail() {
        if let previous = detailBackStack.popLast() {
            selectedDetail = previous
        } else {
            selectedDetail = nil
        }
    }
    func addManifestURL(_ urlString: String) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, URL(string: clean) != nil else {
            status = "Enter a valid Stremio manifest URL before adding."
            return
        }
        guard !manifestURLs.contains(clean) else {
            status = "That Stremio JSON is already in your list."
            return
        }
        manifestURLs.append(clean)
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Added Stremio JSON. Press Load All Catalogs to refresh rows."
    }

    func removeManifestURL(_ urlString: String) {
        manifestURLs.removeAll { $0 == urlString }
        if manifestURLs.isEmpty { manifestURLs = ["https://v3-cinemeta.strem.io/manifest.json"] }
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Removed Stremio JSON."
    }

    func loadAllManifests() async {
        let urls = manifestURLs
        guard !urls.isEmpty else {
            status = "Add at least one Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }

        var mergedRows: [MediaRow] = []
        var loadedNames: [String] = []
        for url in urls {
            do {
                let result = try await fetchRows(from: url)
                mergedRows.append(contentsOf: result.rows)
                loadedNames.append(result.name)
            } catch {
                status = "Skipped one manifest: \(error.localizedDescription)"
            }
        }
        if mergedRows.isEmpty {
            status = "No rows returned from saved Stremio JSON list. Demo rows kept."
        } else {
            rows = mergedRows
            status = "Loaded \(mergedRows.count) rows from \(loadedNames.joined(separator: ", "))."
        }
    }

    private func fetchRows(from urlString: String) async throws -> (name: String, rows: [MediaRow]) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let manifestURL = URL(string: clean) else { throw URLError(.badURL) }
        let (data, _) = try await URLSession.shared.data(from: manifestURL)
        let manifest = try JSONDecoder().decode(StremioManifest.self, from: data)
        let base = manifestURL.deletingLastPathComponent()
        let catalogs = (manifest.catalogs ?? []).prefix(8)
        var builtRows: [MediaRow] = []
        for catalog in catalogs {
            let type = catalog.type ?? "movie"
            let id = catalog.id ?? "popular"
            let catalogURL = base.appending(path: "catalog").appending(path: type).appending(path: id + ".json")
            do {
                let (catalogData, _) = try await URLSession.shared.data(from: catalogURL)
                let response = try JSONDecoder().decode(CatalogResponse.self, from: catalogData)
                let items = (response.metas ?? []).prefix(24).map { meta in
                    MediaItem(
                        id: meta.id ?? UUID().uuidString,
                        title: meta.name ?? "Untitled",
                        year: Self.firstYear(from: meta.releaseInfo),
                        type: meta.type ?? type,
                        catalog: catalog.name ?? id.capitalized,
                        description: meta.description ?? "No description available yet.",
                        genres: Array((meta.genres ?? [type.capitalized, "Cinema"]).prefix(3)),
                        rating: meta.imdbRating ?? "—",
                        posterURL: Self.highest(meta.poster),
                        landscapeURL: Self.highest(meta.background ?? meta.poster),
                        logoURL: Self.highest(meta.logo),
                        previewURL: Self.previewURL(from: meta)
                    )
                }
                if !items.isEmpty {
                    builtRows.append(MediaRow(id: "\(type)-\(id)-\(manifest.name ?? "manifest")", title: catalog.name ?? id.capitalized, items: items))
                }
            } catch {
                continue
            }
        }
        return (manifest.name ?? "manifest", builtRows)
    }


    func loadManifest(urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else {
            status = "Enter a valid Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let result = try await fetchRows(from: clean)
            if result.rows.isEmpty {
                status = "No catalog rows returned. Demo rows kept."
            } else {
                rows = result.rows
                status = "Loaded \(result.rows.count) rows from \(result.name)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo, text.count >= 4 else { return "2026" }
        return String(text.prefix(4))
    }

    static func previewURL(from meta: StremioMeta) -> String? {
        if let direct = meta.previewVideo, direct.hasPrefix("http") { return direct }
        if let direct = meta.preview, direct.hasPrefix("http") { return direct }
        if let direct = meta.trailer, direct.hasPrefix("http") { return direct }
        if let video = meta.videos?.first(where: { ($0.url ?? $0.src ?? $0.source ?? "").hasPrefix("http") }) {
            return video.url ?? video.src ?? video.source
        }
        // Some Stremio manifests expose YouTube trailer IDs; those are kept as metadata only
        // because AVPlayer needs a direct playable video URL.
        return nil
    }

    static func highest(_ url: String?) -> String? {
        guard var u = url, !u.isEmpty else { return nil }
        u = u.replacingOccurrences(of: "w92", with: "original")
        u = u.replacingOccurrences(of: "w154", with: "original")
        u = u.replacingOccurrences(of: "w185", with: "original")
        u = u.replacingOccurrences(of: "w342", with: "original")
        u = u.replacingOccurrences(of: "w500", with: "original")
        u = u.replacingOccurrences(of: "w780", with: "original")
        return u
    }

    static func demoRows() -> [MediaRow] {
        let items: [MediaItem] = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "movie", catalog: "Featured", description: "A temporary small-town sheriff uncovers a violent mystery after a bank robbery exposes a deeper conspiracy.", genres: ["Action", "Crime", "Thriller"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
            MediaItem(id: "apex", title: "APEX", year: "2026", type: "movie", catalog: "Featured", description: "A climber enters a hidden cave system and finds the rescue mission was never about saving him.", genres: ["Adventure", "Thriller"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
            MediaItem(id: "red", title: "RED SIGNAL", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators through a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "BLUE FALL", year: "2026", type: "movie", catalog: "Featured", description: "A detective wakes in a fractured digital city with one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "circle", title: "THE CIRCLE", year: "2026", type: "movie", catalog: "Featured", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "cinema", title: "CENTRAL CINEMA", year: "2026", type: "movie", catalog: "Featured", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "THE LOST PATH", year: "2026", type: "movie", catalog: "Featured", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "STORMLINE", year: "2026", type: "movie", catalog: "Featured", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "night", title: "NIGHT RUN", year: "2026", type: "movie", catalog: "Featured", description: "A driver with no name carries the wrong package across the city before sunrise.", genres: ["Action", "Neo-Noir"], rating: "7.4", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "harbor", title: "HARBOR BLACK", year: "2026", type: "series", catalog: "Featured", description: "A dockside murder opens a case that reaches every powerful family in the city.", genres: ["Series", "Crime"], rating: "7.6", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed())),
            MediaRow(id: "shows", title: "Shows", items: items.map { item in var copy = item; copy.type = "series"; return copy })
        ]
    }
}
