# vBRDC202 Regression Locks

1. Main Movies may not publish TV-show-only cards; main TV Shows may not publish movie-only cards. Playback/Live TV browse filtering remains independent and explicit.
2. Local `dc-local-continue` Resume is the native playback-progress shelf and may import Trakt cloud checkpoints. It must not lose already-known poster/backdrop artwork when cloud timing is newer.
3. Moving Resume to the top must update the mounted rail immediately and survive subsequent official-catalog and Trakt row publications.
4. Ordinary refresh failures/transient connection reads may not remove last-known-good Trakt shelves. Only explicit Disconnect Trakt removes them.
5. `isConnected` must not perform a synchronous Keychain query on every SwiftUI/catalog read.
6. Trakt resume materialization must use one batched cache persistence operation per cloud snapshot, not one whole-cache write per title.
7. Resume artwork repair must be batched and may not alter the resume timestamp/position.
8. Resume/Trakt rows may not enter generic manifest row artwork-repair logic.
9. Trakt account endpoint and TMDB artwork hydration fanout stays bounded at four concurrent operations per batch.
10. Trakt metadata caches remain bounded.
11. VOD exclusive playback remains the resource owner; vBRDC200 playback handoff protections are not weakened.
12. Force Guide after sleep retains vBRDC201 authoritative user-triggered refresh behavior.
