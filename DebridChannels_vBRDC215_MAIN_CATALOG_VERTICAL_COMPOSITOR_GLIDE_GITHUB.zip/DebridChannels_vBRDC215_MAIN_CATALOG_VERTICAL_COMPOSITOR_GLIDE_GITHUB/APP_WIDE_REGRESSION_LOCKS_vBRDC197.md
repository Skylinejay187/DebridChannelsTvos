# App-Wide Regression Locks — vBRDC197

1. Build lineage remains packaged vBRDC196 -> vBRDC197 only.
2. Trakt current/cache row merges must tolerate duplicate row IDs and must never use a unique-key dictionary initializer on overlapping snapshots.
3. `Sync Resume Now` must materialize valid Trakt playback checkpoints into the native Debrid Channels resume cache before the heavier Trakt catalog refresh.
4. A newer local resume checkpoint must never be overwritten by an older/equal Trakt checkpoint.
5. Valid imported Trakt progress must drive the normal Resume button, progress bar and native Debrid Channels Continue Watching row.
6. The last successful Trakt playback snapshot may hydrate native resume state at launch before network refresh.
7. Explicit Trakt Connect/Sync refreshes may proceed while base catalogs are loading and must publish cached/fast Trakt state immediately.
8. A manual resume sync must not immediately duplicate the same Trakt playback API round-trip in the following catalog refresh.
9. `Continue Watching • Trakt` remains available from already-synced cloud progress without waiting for unrelated Watchlist/History/discovery endpoints.
10. Trakt/external last-known-good cache keys remain stable across build upgrades and migrate the vBRDC196 cache once.
11. Media Information keeps Debrid Channels Favorite separate from the visible Trakt Watchlist action.
12. The Trakt action must add/remove Watchlist state only after a successful API mutation and must not mutate Debrid Channels Favorites.
13. Trakt movie rows may contain movies only; Trakt TV rows may contain series/shows only.
14. Trakt Continue Watching, Watch History, Watchlist, Favorites, Recommendations, Trending, Popular and Anticipated shelves remain independently available when usable.
15. Customize All-in-One continues to expose On/Off, Move to Top, Move Up and Move Down for local/Trakt account rows.
16. Native Debrid Channels Continue Watching and dual durable local resume persistence remain independent of Trakt availability.
17. No end user is asked for a Trakt Client ID or Client Secret; no Trakt application secret may appear in UI, docs or validation logs.
18. Spotlight Hub Trakt integration remains optional.
19. Live TV Episode Alerts remain enabled.
20. Production & Ratings themed logo remains an independent setting.
21. Player Engine chip remains absent from the VOD rail.
22. vBRDC189 fixed/even VOD rail and full Video Fit behavior remain unchanged.
23. Playback catalog themed-logo identity publication from vBRDC187 remains intact.
24. vBRDC188 approved app icon assets remain unchanged.
