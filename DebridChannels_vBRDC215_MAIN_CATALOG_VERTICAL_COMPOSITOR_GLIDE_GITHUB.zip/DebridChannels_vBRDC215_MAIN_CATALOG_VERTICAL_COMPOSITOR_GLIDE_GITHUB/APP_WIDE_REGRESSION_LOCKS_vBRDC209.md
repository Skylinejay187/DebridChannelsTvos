# APP-WIDE REGRESSION LOCKS — vBRDC209

These are release invariants, not optional implementation notes.

## 1. Active episode video owns the machine through the final rendered frame
- No full Up Next provider/source fan-out may begin while `isPlaying == true`.
- `startUpNextPreparationIfNeeded`, `prepareUpNextSourcesIfNeeded`, `evaluateUpNextPresentation`, and `armUpNextAutoAdvanceIfNeeded` must all reject active playback.
- If the user resumes from a pause, any in-flight Up Next metadata/source/decor task must be cancelled immediately and may not publish after resume.
- The Up Next watchdog may detect EOF, but it may not resolve providers, rank links, preflight sources, decode artwork, or publish the Up Next surface while the current episode is rendering.

## 2. Natural EOF callback is a zero-work latch
- Natural EOF may only mark the transition pending, remember the reason, and stop the watchdog.
- Trakt completion, Resume clearing, intro-session finalization, MediaRemote stopped-state publication, next-episode metadata, source resolution, artwork, and catalog work must wait for the post-EOF settle lane.
- Preserve a decoder settle delay before post-EOF work starts.

## 3. Periodic checkpoints never own completion
- The five-second Resume checkpoint must never call Trakt `markCompleted` merely because playback is >=95% complete.
- Ordinary Resume cache writes in the completion window must not repeatedly clear/rewrite the cache.
- True player EOF owns completion/clear. A deliberate durable exit may perform one synchronous completion-window clear.

## 4. Up Next artwork cannot force publication over playing video
- Up Next artwork must not use forced playback publication.
- A stale/prepared Up Next surface must be hidden as soon as active playback resumes.
- Keep Up Next source resolution and visual publication subordinate to the current decoder.

## 5. Preserve vBRDC208 cross-feature guarantees
- Episode Alerts remain discoverable/presentable during VOD and Live TV.
- System Now Playing remains published for VOD/Live TV and recovers after media-service lifecycle changes.
- ATVLoadly-compatible `AppIcon-1280x768.png` remains additive and byte-identical to the approved icon.
- Movies/TV catalog boundaries, Trakt shelf stickiness, Force Guide recovery, and vBRDC200+ internal VOD handoff protections remain intact.
