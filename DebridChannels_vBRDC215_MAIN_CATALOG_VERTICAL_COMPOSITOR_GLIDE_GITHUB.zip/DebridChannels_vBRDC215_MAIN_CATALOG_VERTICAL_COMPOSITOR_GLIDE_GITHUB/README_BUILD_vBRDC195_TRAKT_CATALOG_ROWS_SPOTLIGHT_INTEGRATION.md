# Debrid Channels vBRDC195 — Trakt Catalog Rows + Spotlight Integration

Release: vBRDC195
Marketing version: 1.0.898
Apple build: 898
Donor/source of truth: packaged vBRDC194 only

## Trakt catalog layer
- Connected Trakt accounts now add account-aware catalog shelves to the existing Movies and TV Shows surfaces.
- Implemented shelves, when Trakt returns usable entries:
  - Continue Watching • Trakt
  - Trakt Watchlist
  - Recently Watched • Trakt
  - Trakt Favorites
  - Recommended for You • Trakt
  - Trending on Trakt
  - Popular on Trakt
  - Anticipated on Trakt
- Trakt supplies list/order/identity only. Debrid Channels continues to own card rendering, artwork enrichment, Media Information, favorites, Find Links, source resolution and playback.
- Trakt shelves are hidden from Home so the unified Home surface is not flooded with duplicate movie/show account rows.
- Trakt shelves exist only while a Trakt account is connected and are removed immediately on disconnect.

## Artwork / identity safety
- Existing Debrid Channels MediaItems are matched first by TMDB, IMDb and title/year identity.
- Unmatched Trakt titles receive a bounded TMDB enrichment pass before publication, preventing blank catalog cards when possible.
- Trakt CDN image URLs are not hotlinked. This follows Trakt's image policy; Debrid Channels reuses its own/TMDB artwork lane instead.
- Trakt account rows are not persisted into the protected official catalog snapshot or the built-in catalog row customizer.

## Spotlight Hub
- Spotlight Hub remains optional and mutually exclusive with Production & Ratings.
- When Trakt is connected, Spotlight Hub adds title-specific account state:
  - Watchlist
  - Favorite
  - Recently watched
  - Cloud resume percentage when available
- Adds a compact Related on Trakt visual strip using Debrid Channels/TMDB artwork.
- Related Trakt titles take priority over the older text review so the panel remains compact rather than stacking redundant content.
- Existing Trakt Community Pulse and regional Where to Watch data remain available.

## Preserved
- vBRDC194 shared Trakt app authorization: regular users only see Connect / Sync / Disconnect, never developer credential fields.
- Existing local resume remains the instant/offline fallback beneath Trakt cross-device resume.
- Live TV Episode Alerts remain enabled.
- Production & Ratings themed-logo option remains independent.
- vBRDC189 fixed/even VOD rail and complete Video Fit system remain unchanged.
- Player Engine chip remains removed from the VOD control rail.
- Playback UNITY catalogs and playback themed-logo identity hardening remain intact.
- vBRDC188 approved icon assets remain unchanged.

## Validation boundary
GitHub Actions/Xcode with the tvOS SDK remains the authoritative compile. Linux validation covers Swift parsing, isolated Trakt service typechecking, project source inclusion, metadata synchronization, static regression contracts and ZIP integrity.
