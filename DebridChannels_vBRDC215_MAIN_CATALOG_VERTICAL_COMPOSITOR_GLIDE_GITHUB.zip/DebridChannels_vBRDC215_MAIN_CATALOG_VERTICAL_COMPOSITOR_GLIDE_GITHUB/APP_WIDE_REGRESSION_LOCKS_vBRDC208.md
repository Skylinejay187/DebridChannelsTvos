# APP-WIDE REGRESSION LOCKS — vBRDC208

These are release invariants, not optional implementation notes.

## 1. Episode Alerts are playback-visible and playback-discoverable
- A newly released followed-show episode must be discoverable while VOD is playing.
- A newly released followed-show episode must be discoverable while Live TV is playing.
- The alert banner must render inside the player ZStack without requiring playback exit.
- Playback-priority cleanup may not stop/defer the only Episode Alert heartbeat when full-screen alerts are enabled.
- Keep one bounded configured heartbeat only; never add a per-frame or playback-clock alert scanner.

## 2. System Now Playing is a public app contract
- Every active VOD and Live TV session must publish through the central `DebridNowPlayingManager`.
- Publish video media type, title, duration/elapsed when known, playback rate, live state, service identity and asset identity.
- Keep the tvOS playback audio session active while a Now Playing owner exists.
- Reassert the retained state after app/media-service/audio lifecycle recovery.
- Do not add a second high-frequency playback clock solely for Now Playing.

## 3. ATVLoadly icon compatibility is additive
- Never replace or flatten the canonical layered tvOS `AppIcon` asset catalog.
- Keep `Resources/AppIcon-1280x768.png` byte-identical to the approved raw Debrid Channels icon.
- Keep the alias in the final `.app` bundle and keep legacy plist references pointing to it for IPA clients.

## 4. Up Next / EOF playback budget remains protected
- Natural EOF must not enter the ordinary user-pause durable-flush path.
- Preserve buffer-aware Up Next source preparation and 2/4/8 second failed-search backoff.
- Preserve near-EOF fallback at ~0.10 seconds.
- Do not start decorative next-episode networking before it is needed for playback.

## 5. Cross-feature changes require regression checks
Any future change to root lifecycle, playback ownership, scene phase, MediaRemote, alert scheduling, app icon packaging or post-build scripts must run the vBRDC208 contract before packaging.
