from pathlib import Path
import plistlib
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "Sources/DebridChannelsTVOSApp.swift").read_text()
TRAKT = (ROOT / "Sources/TraktSyncManager.swift").read_text()
PROJECT = (ROOT / "project.yml").read_text()


def between(start, end):
    a = APP.index(start)
    b = APP.index(end, a)
    return APP[a:b]


def test_release_identity():
    assert PROJECT.count("MARKETING_VERSION: 1.0.909") == 2
    assert PROJECT.count("CURRENT_PROJECT_VERSION: 909") == 2
    for rel in ("Sources/Info.plist", "TopShelfExtension/Info.plist"):
        with (ROOT / rel).open("rb") as fh:
            p = plistlib.load(fh)
        assert p["CFBundleShortVersionString"] == "1.0.909"
        assert str(p["CFBundleVersion"]) == "909"
        assert p["DebridChannelsReleaseID"] == "vBRDC206"


def test_system_now_playing_is_centralized():
    assert "private final class DebridNowPlayingManager" in APP
    assert "MPNowPlayingInfoCenter.default().nowPlayingInfo" in APP
    assert "MPMediaItemPropertyArtist" in APP
    assert "MPMediaItemPropertyAlbumTitle" in APP
    assert "MPNowPlayingInfoPropertyExternalContentIdentifier" in APP
    assert "claimLiveSession" in APP
    assert "publishLiveTVSystemNowPlaying(claim: true)" in APP
    assert "publishVODSystemNowPlayingMetadata()" in APP


def test_vod_now_playing_keeps_existing_remote_command_bridge():
    block = between("final class BluetoothVODMediaButtonCoordinator", "final class DebridChannelsAppDelegate")
    assert "MPRemoteCommandCenter.shared()" in block
    assert "togglePlayPauseCommand" in block
    assert "playCommand" in block
    assert "pauseCommand" in block
    assert "DebridNowPlayingManager.shared.claimVODSession" in block
    assert "DebridNowPlayingManager.shared.updateVODTiming" in block


def test_natural_eof_is_classified_before_pause_publication():
    ks = between("onKSPlaybackEnded: {", "onKSChaptersDiscovered:")
    assert ks.index('handleNaturalEpisodeEnd(reason: "KSPlayer natural completion")') < ks.index("isPlaying = false")
    av = between("endObserver = NotificationCenter.default.addObserver", "if !store.playbackSubtitleURLs.isEmpty")
    assert av.index('handleNaturalEpisodeEnd(reason: "AVPlayer natural completion")') < av.index("isPlaying = false", av.index('handleNaturalEpisodeEnd(reason: "AVPlayer natural completion")'))
    obs = between(".onChange(of: isPlaying)", ".onChange(of: activePanel)")
    assert "if !playing, vodAsyncRuntime.naturalEpisodeTransitionActive" in obs
    assert obs.index("naturalEpisodeTransitionActive") < obs.index("TraktSyncManager.shared.playbackStateChanged")
    assert obs.index("naturalEpisodeTransitionActive") < obs.index("PlaybackResumeCacheManager.shared.flushSynchronously()")


def test_natural_eof_is_idempotent_and_decorative_work_is_not_started():
    block = between("private func handleNaturalEpisodeEnd", "private func startLocalIntroDetectionIfNeeded")
    assert "!vodAsyncRuntime.naturalEpisodeTransitionActive" in block
    assert "deferProgressRefresh: true" in block
    assert "prefetchUpNextIntroAfterCurrentEpisodeEndsIfNeeded" not in block
    assert "loadUpNextDecorationAfterCurrentEpisodeEndsIfNeeded" not in block


def test_provider_retry_is_buffer_and_backoff_guarded():
    block = between("private func prepareUpNextSourcesIfNeeded", "private func nextEpisode")
    assert "bufferedHeadroom >= 24" in block
    assert "bufferedHeadroom >= 12" in block
    assert "upNextSourceRetryNotBeforeUptime" in block
    assert "ProcessInfo.processInfo.systemUptime + delay" in block
    watchdog = between("private func startUpNextWatchdogIfNeeded", "private func handleNaturalEpisodeEnd")
    assert "remaining <= 0.10" in watchdog


def test_outgoing_up_next_owners_cancel_before_handoff():
    block = between("private func playPreparedUpNextEpisode", "private func routeUpNextMove")
    for marker in (
        "upNextWatchdogTask?.cancel()",
        "upNextPreparationTask?.cancel()",
        "upNextSourcePreparationTask?.cancel()",
        "upNextDecorationTask?.cancel()",
    ):
        assert marker in block
    assert block.index("upNextWatchdogTask?.cancel()") < block.index("store.startPlayback(")


def test_trakt_cloud_refresh_is_deferred_past_decoder_startup():
    assert "deferredProgressRefreshNeeded" in TRAKT
    mark = TRAKT[TRAKT.index("func markCompleted"):TRAKT.index("func removeCloudResume")]
    assert "deferProgressRefresh: Bool = false" in mark
    assert "deferredProgressRefreshNeeded = true" in mark
    assert "Task.sleep(nanoseconds: 4_000_000_000)" in mark
    assert "refreshPlaybackProgress(force: true)" in mark


def test_avplayer_buffering_is_not_misclassified_as_pause():
    block = between("timeObserver = av.addPeriodicTimeObserver", "endObserver = NotificationCenter.default.addObserver")
    assert "case .waitingToPlayAtSpecifiedRate:" in block
    waiting = block[block.index("case .waitingToPlayAtSpecifiedRate:"):]
    assert "break" in waiting[:120]
    assert 'handleNaturalEpisodeEnd(reason: "AVPlayer paused at natural completion")' in block
