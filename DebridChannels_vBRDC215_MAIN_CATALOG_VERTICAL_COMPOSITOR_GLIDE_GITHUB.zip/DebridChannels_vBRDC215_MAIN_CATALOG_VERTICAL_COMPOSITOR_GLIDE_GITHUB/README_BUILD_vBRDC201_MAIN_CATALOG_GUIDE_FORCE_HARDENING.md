# Debrid Channels vBRDC201 — Main Catalog Boundary + Force Guide Sleep Recovery

Release: vBRDC201  
Marketing version: 1.0.904  
Build: 904

Built directly from the corrected vBRDC200 package.

## Main Home / Movies / TV Shows

- Main persistent catalog shell now derives Movies/TV Shows projection from UNITY's active catalog tab rather than the retained hidden render-tab identity.
- Main catalog rows are explicitly re-projected whenever Home/Movies/TV Shows changes, even when provider rows did not publish a revision.
- The visible root catalog filter follows the presented/selected category; hidden-shell identity remains retention-only.
- Playback UNITY catalogs remain on their existing explicit destination filter path and are not changed.

## Live TV Force Guide

- Explicit Refresh/Force Guide cancels any older automatic TTL/resume refresh before starting a new provider generation.
- User-initiated guide publication no longer waits forever on the normal durable interactive-metadata lane after a long tvOS idle/sleep.
- Force Guide still respects cancellation, active VOD ownership, refresh generations, and active-scene safety.
- Scene inactivity clears stale transient UNITY navigation/handoff/recovery owners so hours-old focus state cannot block later guide/catalog publication.

## Trakt persistence

- No reconnect behavior was added. The OAuth token bundle remains stored in Apple Keychain and reused across launches/normal updates under the same signing/keychain identity.
- Explicit Disconnect remains the only application path that deletes the Trakt token.
