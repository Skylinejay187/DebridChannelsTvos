# Debrid Channels vBRDC192 — Spotlight Hub + Live TV Episode Alerts

Build metadata:
- Release: vBRDC192
- Marketing version: 1.0.895
- Apple build: 895
- Donor: packaged vBRDC191 only

## Media Information — Spotlight Hub

The vBRDC191 Behind the Scenes panel is retired from the active UI.

The mutually-exclusive Media Info feature choices remain:
- Off
- Production & Ratings
- Spotlight Hub

Production & Ratings Themed Logo remains a separate independent preference and is not tied to the selected feature panel.

Spotlight Hub uses TMDB data that was not previously surfaced in this Media Information slot:
- official title video extras, prioritized as Featurette / Clip / Bloopers / Teaser / Behind the Scenes, with Trailer fallback only when needed;
- visual YouTube thumbnails for the available official extras;
- local-region streaming/free/ad/rent/buy provider logos from TMDB watch-provider data;
- required JustWatch attribution when provider availability is shown;
- one compact TMDB community review highlight when available.

This replaces the prior static scene/crew presentation. No Fanart Collector Showcase request is issued by the active metadata path.

## Episode Alerts — Live TV

The existing single Episode Alert scheduler and durable queue now continue during both VOD and Live TV when the presentation scope is enabled.

The existing `Main UI + VOD Playback` setting is presented as `Main UI + VOD + Live TV` while preserving the stored raw value for upgrade compatibility.

The shared VODPlayerScreen now mounts the same passive Episode Alert banner above both VOD and Live TV video surfaces. It remains non-focusable and does not pause playback, reopen controls, or create a second polling loop.

## Preserved locks

- vBRDC188 main icon unchanged.
- vBRDC189 fixed/even VOD control rail unchanged.
- vBRDC189 Video Fit/aspect system unchanged.
- vBRDC190 Player Engine chip remains removed from the VOD shelf; engine settings remain available internally.
- vBRDC191 Production & Ratings themed-logo setting remains independent.
- Playback UNITY Home / Movies / TV Shows remains intact.
