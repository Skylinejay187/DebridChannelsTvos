# Debrid Channels vBRDC202

Release: vBRDC202  
Marketing version: 1.0.905  
Build: 905  
Source-of-truth parent: vBRDC201 packaged ZIP

## Purpose

This release hardens the remaining Resume/Trakt/catalog publication problems seen after the vBRDC201 main Movies/TV Shows boundary correction.

## Runtime changes

- Resume row ordering is applied immediately when catalog customization is committed and remains governed by the saved global custom rank on later catalog/Trakt publications.
- Trakt cloud progress is imported into the native playback resume cache as one batch instead of one synchronous whole-cache rewrite per title.
- Resume entries keep separate portrait and landscape artwork URLs while retaining the legacy artwork field for backward compatibility.
- Newer Trakt timing checkpoints preserve good local artwork instead of replacing it with artwork-less cloud entries.
- Artwork learned later from official/Trakt/TMDB cards is backfilled into the native resume cache without changing playback time or recency.
- Resume artwork backfill is batched so a 20+ card shelf produces one utility-queue durable write rather than one full resume-cache write per card.
- Last-known-good Trakt catalog rows remain mounted through ordinary catalog publications. They are removed only by the explicit Disconnect Trakt path.
- `TraktSyncManager.isConnected` uses a cached token bundle after the startup Keychain read; ordinary SwiftUI/catalog reads no longer synchronously hit Security.framework.
- An explicit Trakt Sync can recover an already-persisted Keychain token after a transient startup read miss without requiring Device Code authorization again.
- Trakt catalog persistence JSON encoding/UserDefaults write is moved to a utility queue.
- Missing artwork in Resume/Trakt rows no longer launches generic All-in-One manifest row recovery.
- Trakt account endpoint requests are processed in batches of four instead of a large simultaneous burst.
- TMDB artwork hydration is processed in batches of four.
- Trakt related metadata and TMDB resolved-item caches now have fixed memory bounds.

## Memory/stall audit conclusion

The concrete freeze risks in this area were work amplification rather than evidence of one unbounded decoded-image cache: repeated full resume persistence, concurrent Trakt/TMDB network/JSON bursts, and inappropriate generic catalog recovery triggered by blank account cards. Existing image caches remain bounded and already have playback lifecycle purge paths, so their capacity was not blindly reduced in this release.

## Preserved behavior

- vBRDC201 main Home/Movies/TV Shows category boundary fixes.
- Correct playback/Live TV popup catalog filtering.
- vBRDC201 Force Guide/sleep hardening.
- vBRDC200 VOD source failover/Next Episode playback resource ownership changes.
- Existing visual assets and UI appearance.
- Explicit Trakt Disconnect still removes account shelves and credentials as designed.
