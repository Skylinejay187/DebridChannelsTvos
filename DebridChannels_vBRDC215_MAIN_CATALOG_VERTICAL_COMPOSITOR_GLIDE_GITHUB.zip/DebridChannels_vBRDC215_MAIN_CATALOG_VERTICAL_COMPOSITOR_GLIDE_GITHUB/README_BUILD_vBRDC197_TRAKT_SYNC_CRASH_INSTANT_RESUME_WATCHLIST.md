# Debrid Channels vBRDC197 — Trakt Sync Crash Fix + Instant Resume + Watchlist

Release: vBRDC197
Marketing version: 1.0.900
Apple build: 900
Donor/source of truth: packaged vBRDC196 only

## Exact crash fix
The supplied vBRDC196 IPS shows a main-thread `EXC_BREAKPOINT / SIGTRAP` in Swift Dictionary merge while `CatalogStore.mergeLastKnownGoodTraktRows(fresh:previous:)` was combining current and cached Trakt shelves. The old merge assumed row IDs were unique even though current and last-known-good snapshots intentionally overlap.

vBRDC197 makes the boundary duplicate-safe: Trakt rows are deduplicated by row ID before publication, previous rows are inserted explicitly, and non-empty fresh rows replace the matching ID without `Dictionary(uniqueKeysWithValues:)`.

## Instant Trakt -> Debrid Channels resume
- `Sync Resume Now` fetches Trakt playback progress once.
- Valid unfinished Trakt checkpoints are materialized into the same durable `PlaybackResumeCacheManager` used by normal Debrid Channels playback.
- A Trakt checkpoint therefore drives the native Resume button, progress bar and Debrid Channels Continue Watching row.
- Imported timestamps are preserved, so a stale cloud checkpoint cannot overwrite a newer local checkpoint.
- The last successful Trakt playback snapshot is cached and can hydrate local resume state immediately on launch before a network refresh.
- Manual Sync publishes local/Continue Watching state before starting the heavier Watchlist/History/discovery shelf refresh.

## Faster/stabler Trakt rows
- Manual Connect/Sync may refresh Trakt shelves even while the base catalog is still loading; it no longer silently waits behind the first catalog load.
- The already-fetched playback data is not immediately fetched a second time by the Trakt catalog refresh.
- `Continue Watching • Trakt` has a fast path from the already-synced cloud resume points and can publish identity/placeholder cards even before the base catalog artwork finishes loading.
- Trakt and external catalog cache keys are stable across build upgrades, with one-time migration from the vBRDC196 keys, so updating the app does not intentionally cold-start those shelves.
- The bounded TMDB enrichment set now runs concurrently instead of in three sequential batches, reducing first connected-account shelf latency.
- An explicit Connect/Sync refresh cancels the delayed post-playback refresh it supersedes, preventing a second forced shelf request moments later.
- Last-known-good Trakt rows remain mergeable per shelf instead of disappearing as one batch.

## Visible Trakt action in Media Information
When Trakt is connected, Media Information keeps the existing Debrid Channels Favorite action and adds a separate red Trakt Watchlist action:
- `ADD TO TRAKT`
- `IN TRAKT WATCHLIST`

The action adds/removes the title from the user's Trakt Watchlist and updates the local Trakt membership state/shelves without changing Debrid Channels Favorites.

## Preserved
- Trakt Continue Watching, Watch History, Watchlist, Favorites, Recommendations, Trending, Popular and Anticipated shelves.
- Trakt movie/show hard separation and Customize All-in-One controls.
- Native Debrid Channels Continue Watching and dual durable local resume persistence.
- Shared Debrid Channels Trakt authorization flow.
- Spotlight Hub Trakt integration.
- Live TV Episode Alerts.
- Independent Production & Ratings themed-logo setting.
- vBRDC189 fixed/even VOD rail and full Video Fit system.
- Player Engine chip remains removed.
- Playback UNITY catalogs and vBRDC187 themed-logo identity fix.
- vBRDC188 approved icon assets unchanged.

## Validation boundary
GitHub Actions/Xcode with the tvOS SDK remains the authoritative compile. Linux validation covers Swift parsing, targeted semantic typechecking, project/source inclusion, metadata synchronization, static regression contracts, icon byte comparison and ZIP integrity.
