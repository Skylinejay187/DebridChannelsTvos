from pathlib import Path
import plistlib, re

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / "Sources/CatalogStore.swift").read_text()
TRAKT = (ROOT / "Sources/TraktSyncManager.swift").read_text()
SERVICE = (ROOT / "Sources/TraktCatalogService.swift").read_text()
RESUME = (ROOT / "Sources/PlaybackResumeCache.swift").read_text()
APP = (ROOT / "Sources/DebridChannelsTVOSApp.swift").read_text()
PROJECT = (ROOT / "project.yml").read_text()

def block(text, start, end):
    a = text.index(start)
    b = text.index(end, a)
    return text[a:b]

def test_release_identity():
    assert PROJECT.count("MARKETING_VERSION: 1.0.905") == 2
    assert PROJECT.count("CURRENT_PROJECT_VERSION: 905") == 2
    assert 'private static let appVersion = "1.0.905"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC202 TraktCatalog' in SERVICE
    for rel in ("Sources/Info.plist", "TopShelfExtension/Info.plist"):
        with (ROOT / rel).open("rb") as fh:
            plist = plistlib.load(fh)
        assert plist["CFBundleShortVersionString"] == "1.0.905"
        assert str(plist["CFBundleVersion"]) == "905"
        assert plist["DebridChannelsReleaseID"] == "vBRDC202"

def test_trakt_connection_identity_is_memory_cached():
    assert "private var tokenBundleCache: TraktOAuthTokenBundle? = nil" in TRAKT
    assert "var isConnected: Bool { withStateLock { tokenBundleCache != nil } }" in TRAKT
    init = block(TRAKT, "private init()", "@inline(__always)")
    assert "readKeychainString(account: Self.tokenAccount)" in init
    assert "tokenBundleCache = try? JSONDecoder().decode" in init
    read = block(TRAKT, "private func readTokenBundle()", "private func storeTokenBundle")
    assert "withStateLock { tokenBundleCache }" in read
    disconnect = block(TRAKT, "func disconnect()", "func beginDeviceLink")
    assert "tokenBundleCache = nil" in disconnect
    assert "func restorePersistedConnectionIfNeeded() -> Bool" in TRAKT

def test_cloud_resume_import_is_batched_and_artwork_preserving():
    materialize = block(TRAKT, "private func materializeCloudResumePoints", "func cloudResumeEntry")
    assert "[PlaybackResumeCacheManager.SyncedProgressUpdate]" in materialize
    assert "importSyncedProgressBatch(updates)" in materialize
    assert "synchronously: true" not in materialize
    assert "func importSyncedProgressBatch" in RESUME
    batch = block(RESUME, "func importSyncedProgressBatch", "func backfillArtwork")
    assert "writerQueue.sync" in batch
    assert "let preservedPoster = item.posterURL" in batch
    assert "newestExisting?.posterArtworkURL" in batch
    assert "let preservedLandscape = item.landscapeURL" in batch
    assert "newestExisting?.landscapeArtworkURL" in batch
    assert batch.count("self.write(snapshot, to: fileURL, removeLegacyAfterSuccess: false)") == 1

def test_resume_artwork_is_dual_channel_and_backfilled():
    assert "var posterArtworkURL: String? = nil" in RESUME
    assert "var landscapeArtworkURL: String? = nil" in RESUME
    local = block(STORE, "private func localContinueWatchingRow", "private func immediateTraktContinueRows")
    assert "PlaybackResumeCacheManager.shared.backfillArtworkBatch(artworkBackfills)" in local
    assert "entry.posterArtworkURL ?? entry.artworkURL" in local
    assert "entry.landscapeArtworkURL ?? entry.artworkURL" in local
    assert "var artworkBackfills: [PlaybackResumeCacheManager.ArtworkBackfillUpdate]" in local

def test_trakt_rows_are_sticky_until_explicit_disconnect():
    refresh = block(STORE, "func refreshTraktCatalogRowsIfNeeded", "private func refreshPlaybackDerivedCatalogRowsIfNeededWithoutNetwork")
    guard_prefix = refresh[:refresh.index("migrateConnectedTraktRowsToTopIfNeeded")]
    assert "removeTraktCatalogRows" not in guard_prefix
    assert "Last-known-good rows stay mounted" in refresh
    assert "restorePersistedConnectionIfNeeded()" in refresh
    update = block(STORE, "private func updateVisibleCatalogRows", "func applyAllInOneCatalogPreference")
    assert "isTraktCatalogRow" in update
    # Production callsite must be the explicit Disconnect button only.
    outside_def = APP.count("removeTraktCatalogRows(")
    assert outside_def == 1

def test_resume_move_to_top_survives_account_migration_and_global_sort():
    descriptors = block(STORE, "private static let traktCustomizationDescriptors", "private func isTraktCatalogRow")
    assert descriptors.index('id: "dc-local-continue"') < descriptors.index('id: "trakt-movie-continue"')
    migration = block(STORE, "private func migrateConnectedTraktRowsToTopIfNeeded", "private func hiddenCustomizedRowIDs")
    assert "savedAccountIDs" in migration
    assert "for id in savedAccountIDs" in migration
    assert "for id in accountIDs" in migration
    priority = block(STORE, "private func prioritizedRowsForDisplay", "private func prioritizedManifestURLsWithMetadataFallback")
    assert "customRank" in priority
    assert "manifestSorted + sortedAccount" in priority
    assert "customRank[lhs.element.id]" in priority
    commit = block(STORE, "func commitBuiltInCatalogCustomization", "// MARK: - Phase 5")
    assert "let immediateReorderedRows = prioritizedRowsForDisplay(rows)" in commit

def test_account_rows_never_use_generic_manifest_artwork_repair():
    lazy = block(STORE, "private func shouldLazyRefreshCatalogRow", "private func refreshCatalogRowIfNeeded")
    assert "if isTraktCatalogRow(row) || isPlaybackDerivedCatalogRow(row) { return false }" in lazy

def test_trakt_network_fanout_and_metadata_caches_are_bounded():
    assert "private let relatedCacheLimit = 32" in SERVICE
    assert "private let tmdbResolvedCacheLimit = 96" in SERVICE
    assert "let endpointBatchSize = 4" in SERVICE
    assert "Array(endpoints[start..<min(start + endpointBatchSize, endpoints.count)])" in SERVICE
    assert "let lookupBatchSize = 4" in SERVICE
    assert "Array(candidates[start..<min(start + lookupBatchSize, candidates.count)])" in SERVICE
    assert "await Task.yield()" in SERVICE
    assert "relatedCache.count > relatedCacheLimit" in SERVICE
    assert "tmdbResolvedCache.count > tmdbResolvedCacheLimit" in SERVICE

def test_account_shelf_persistence_is_off_main():
    assert 'DispatchQueue(label: "DebridChannels.CatalogStore.persistence", qos: .utility)' in STORE
    assert "private func persistRowsOffMain" in STORE
    refresh = block(STORE, "func refreshTraktCatalogRowsIfNeeded", "private func refreshPlaybackDerivedCatalogRowsIfNeededWithoutNetwork")
    assert "persistRowsOffMain(mergedTrakt" in refresh

def test_v201_main_catalog_boundary_and_force_guide_regressions_remain():
    assert "vBRDC201: playback browse already carries an explicit destination filter" in APP
    assert "switch unityCore.activeTab" in APP
    assert 'rebuildRenderedRows(reason: "main catalog active-tab boundary")' in APP
    assert "forceGuide" in APP.lower() or "Force Guide" in APP
    assert "vBRDC201" in APP  # historical regression markers retained
