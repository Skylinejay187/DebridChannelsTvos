# Debrid Channels vBRDC191

Marketing version: 1.0.894  
Apple build: 894

Built only from the packaged vBRDC190 source.

## Media Information alternative rebuilt

The vBRDC190 Collector Showcase presentation is retired from the active UI.
The mutually exclusive right-side Media Information slot is now:

- Off
- Production & Ratings
- Behind the Scenes

Behind the Scenes is deliberately different from Production & Ratings and from the former Collector Showcase. It presents a fixed three-frame scene strip and filmmaking craft credits retrieved from TMDB credits metadata, including when available:

- Cinematography / Director of Photography
- Original score / composer
- Editing
- Production design
- Costume design
- Visual effects supervision
- Sound design / supervising sound
- Screenplay / teleplay / writer

The panel does not auto-rotate and does not use the former clear-art/disc-art/tagline/collection collage treatment.

## Production & Ratings themed logo restored as independent setting

`Production & Ratings Themed Logo` is once again a standalone VOD settings option. Its preference remains available and saved even when Production & Ratings is not the currently selected Media Information feature.

## Preserved

- Production & Ratings behavior and data
- vBRDC190 Player Engine chip removal
- vBRDC189 fixed/even VOD control rail
- vBRDC189 Video Fit/aspect-ratio menu
- vBRDC187 playback catalog logo identity correction
- vBRDC188 approved app icon assets
- Playback engine selection logic remains available internally/settings; only its VOD rail chip stays removed
