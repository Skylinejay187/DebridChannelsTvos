# Debrid Channels vBRDC186 — VOD Runtime Crash + Live TV Media Information Artwork Fix

Built only from packaged vBRDC185.

## Device crash fixed
The supplied tvOS 26.6 IPS (build 888) reports `EXC_BAD_ACCESS / KERN_PROTECTION_FAILURE` on the main thread while Swift instantiates generic metadata for `VODPlayerScreen.vodOriginalBottomChromeLayer`. The stack enters `swift::SubstGenericParametersFromMetadata` and `__swift_instantiateConcreteTypeFromMangledName` before returning through `playerVisualTree`. This is a SwiftUI concrete-type / stack-exhaustion failure, not a decoder crash.

vBRDC186 converts the VOD control shelf from a large static `LazyHStack` tuple to one descriptor-driven `ForEach` child type and type-erases the hero/status, timeline, and drawer chrome islands before final composition. Playback actions, focus IDs, order, titles, and Home / Movies / TV Shows UNITY controls are preserved.

## Live TV / in-playback Media Information
- Poster artwork, themed title logo, and cast portraits are treated as foreground playback UI and may publish while full-screen playback is active.
- Cast names remain visible with initials fallback when portrait artwork is absent or invalid.
- Credits/detail hydration and Source Intelligence behavior are unchanged.
- Removed the user-facing `PLAYBACK BROWSE` wording from Media Information and the catalog header.

## Version
- Release: vBRDC186
- Marketing: 1.0.889
- Apple build: 889
