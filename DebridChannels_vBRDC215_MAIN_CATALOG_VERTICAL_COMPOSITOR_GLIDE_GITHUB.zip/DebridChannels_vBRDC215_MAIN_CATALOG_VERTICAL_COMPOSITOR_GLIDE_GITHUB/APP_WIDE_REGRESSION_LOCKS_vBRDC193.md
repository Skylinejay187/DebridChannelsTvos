# App-Wide Regression Locks — vBRDC193

1. Build lineage remains packaged vBRDC192 -> vBRDC193 only.
2. Local resume is never removed as a prerequisite for Trakt; Trakt is an optional synchronization layer.
3. Newest local-or-Trakt resume checkpoint wins by timestamp.
4. The five-second local player checkpoint must not become a recurring Trakt start/scrobble request.
5. Trakt start/pause/stop must follow real player state/lifecycle edges.
6. Trakt OAuth token and Client Secret storage remains Keychain-backed.
7. Refresh token exchange remains serialized; never race a single-use Trakt refresh token.
8. Spotlight Hub must not reintroduce the vBRDC192 passive video-card row or TMDB videos request.
9. Spotlight provider logos visible during active playback are foreground artwork and may publish through the bounded playback-artwork lane.
10. URL-bearing/spam-style TMDB review text must not be shown in Spotlight Hub.
11. Production & Ratings / Spotlight Hub / Off remain mutually exclusive for the right-side Media Information feature slot.
12. Production & Ratings Themed Logo remains an independent option and must not disappear when Spotlight Hub is selected.
13. Player Engine chip remains absent from the VOD control rail; underlying player engine settings remain available.
14. vBRDC189 VOD rail remains mathematically fixed/non-scrolling and Video Fit remains available.
15. Live TV Episode Alerts remain enabled through the shared existing alert scheduler/banner.
16. vBRDC188 approved AppIcon and DebridChannelsHomeIcon assets remain byte-identical.
17. Playback UNITY Home/Movies/TV Shows catalogs and vBRDC187 themed-logo identity fixes remain intact.
18. User-facing `PLAYBACK BROWSE` and the removed playback catalog top header must not return.
