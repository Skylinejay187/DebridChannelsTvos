# Debrid Channels vBRDC193 — Trakt Cross-Device Resume + Spotlight Hub Fix

Release: vBRDC193
Marketing version: 1.0.896
Apple build: 896
Donor/source of truth: packaged vBRDC192 only

## Trakt cross-device resume

vBRDC193 keeps the existing local PlaybackResumeCache as the instant/offline resume source and adds Trakt as an optional cloud synchronization layer above it.

- Device-code account linking suitable for Apple TV.
- OAuth access/refresh tokens are kept in Keychain.
- The Trakt API app Client Secret is kept in Keychain; the Client ID is a normal preference.
- Trakt refresh tokens are serialized because each refresh token is single-use.
- Unfinished playback is imported from `/sync/playback/movies` and `/sync/playback/episodes` with extended metadata.
- When both local and Trakt checkpoints exist, the checkpoint with the newest `updatedAt/paused_at` wins.
- Local resume remains fully functional if Trakt is disabled, unconfigured, offline, or unavailable.
- Trakt scrobbling follows semantic playback edges only: start/unpause -> start, pause/background/exit -> pause, natural completion -> stop at 100%.
- The existing five-second local resume clock stays local and does not generate repeated Trakt start calls.
- Trakt playback progress refreshes opportunistically on app activation and can also be refreshed manually in Settings.

### First-time Trakt configuration

Trakt requires an API application Client ID and Client Secret. In this source package, no third-party Trakt credentials are bundled. Enter the Debrid Channels Trakt API app credentials once under Settings -> VOD Player -> Trakt Cross-Device Resume, then choose Connect Trakt. Apple TV displays the device authorization URL and code; after approval, account tokens are stored in Keychain.

## Spotlight Hub rebuild/fix

The passive TMDB extras/video-card row from vBRDC192 was removed entirely.

Spotlight Hub now focuses on information not already represented by Production & Ratings:

- Trakt Community Pulse: watchers, plays, collectors, and comments.
- Trakt cloud-resume percentage/time when the current title has a synchronized checkpoint.
- Regional Where-to-Watch provider strip from TMDB/JustWatch data.
- Clean TMDB community highlight when a usable review exists.
- Provider-logo images receive bounded foreground playback publication permission, so the same artwork gate that caused blank cards during active VOD/Live TV playback cannot suppress them.
- Review text rejects URL-bearing/spam-style entries and strips markup/URLs before display.
- Spotlight no longer requests TMDB `videos`, reducing metadata/network work for this panel.

Production & Ratings, Spotlight Hub, and Off remain mutually exclusive owners of the same Media Information feature slot. The Production & Ratings themed-logo control remains a separate independent setting.

## Preserved locks

- vBRDC188 approved icon assets unchanged byte-for-byte.
- vBRDC189 fixed/even non-scrolling VOD control rail preserved.
- vBRDC189 Video Fit/aspect system preserved.
- Player Engine playback chip remains removed.
- Live TV Episode Alerts from vBRDC192 preserved.
- Playback Home/Movies/TV Shows UNITY catalog chips preserved.
- Playback catalog themed-logo identity hardening preserved.
- No visible `PLAYBACK BROWSE` wording.
- No playback catalog top capsule/header bar.

## Validation

- 66 Swift source files passed `swiftc -frontend -parse` in this environment.
- `TraktSyncManager.swift` passed standalone Swift 5 typechecking with project-compatible MediaItem/PlaybackResumeEntry stubs.
- `VODProductionMetadata.swift` passed standalone Swift 5 typechecking.
- project.yml parses as YAML.
- App and Top Shelf plist versions are synchronized to 1.0.896 / 896 / vBRDC193.
- App icon asset-tree hashes match packaged vBRDC192 exactly.
- Final ZIP archive integrity verified with `unzip -t`.
- GitHub Actions/Xcode remains the authoritative tvOS/iOS SDK compile.
