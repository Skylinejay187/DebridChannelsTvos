# Debrid Channels vBRDC199 — Catalog Type + Trakt Order Final Boundary Fix

Release: vBRDC199  
Marketing version: 1.0.902  
Build: 902

## Fixed

- Official All-in-One batch rows now use the manifest catalog declaration as the authoritative movie/series type.
- Batch rows are matched to manifest catalogs by display name before reused catalog IDs such as `popular`, preventing movie/show declaration collisions.
- Official row items are forced to the manifest-declared type instead of trusting malformed/swapped meta `type` values.
- Durable official snapshots cannot replace a fresh corrected row with an older fuller row when the two disagree on movie vs series identity.
- Final Movies/TV Shows projection now applies row-level and canonical-item type barriers for stale v198 cached rows.
- Trakt row labels use their actual shelf title (`Continue Watching • Trakt`, `Watch History • Trakt`, etc.) rather than collapsing to the provider-only label `Trakt`.
- Official row-ID migration now preserves Trakt/local Continue Watching ordering and hidden/on-off state.
- vBRDC198 damaged saved orders that lost every Trakt ID are repaired once when Trakt is connected; valid user custom orders are not overwritten.

## Preserved

- Trakt cross-device resume + local resume materialization.
- Trakt Watch History, Watchlist, Favorites, Recommendations, Trending, Popular, Anticipated rows.
- Trakt Media Information watchlist button.
- All-in-One/external catalog switching and separated caches.
- Playback UNITY catalogs, VOD rail, Video Fit, Live TV episode alerts, Spotlight Hub.
- Approved vBRDC188 app icon assets unchanged.
