# App-wide Regression Locks — vBRDC211

These are cross-feature invariants. Future work must not weaken them.

1. Full-screen VOD and Live TV are both eligible system media owners.
2. The authoritative tvOS media-ownership path is a real `MPNowPlayingSession` backed by the bundled muted local `AVQueuePlayer` anchor; KSPlayer/VLC remain the real content renderers.
3. `MPNowPlayingSession.automaticallyPublishesNowPlayingInfo` stays disabled; Debrid Channels publishes title/type/timing/live-state through the session-scoped `nowPlayingInfoCenter`.
4. The active session must call `becomeActiveIfPossible()` and retain one stable process-lifetime anchor/session object.
5. Play/Pause/Toggle handlers remain installed on the session-scoped remote-command center and the shared compatibility center.
6. Remote commands must be enabled before non-mixable AVAudioSession activation.
7. Duplicate delivery across session/shared command centers and SwiftUI Play/Pause must never double-toggle playback.
8. Bluetooth/system Play/Pause routes directly to the active playback UUID and never passes through the generic 440 ms UI debounce.
9. VOD and Live TV Now Playing continue to publish video media type, title/content identity, elapsed time, playback rate, and live-stream state where appropriate.
10. Live TV claims media-button ownership before decoder mount and republishes authoritative program/channel metadata after the player surface appears.
11. Visible diagnostics for current/last system-session claim and the last received media-button event remain available for device validation.
12. Trakt manual resync restores persisted OAuth/Keychain state before requesting playback progress.
13. A successful Trakt manual resync must show an explicit confirmation; verified account identity must not hide that result.
14. A successful profile restore with a surviving Trakt Keychain link issues exactly one automatic playback-progress resync and immediately reprojects Continue Playing.
15. A catalog refresh that follows a just-completed manual/restore resync must be able to skip a second playback-progress request.
16. Restore codes never copy Trakt OAuth refresh tokens; a missing Keychain link must be reported and require reconnect rather than silently failing.
17. Cold Resume projection/artwork/themed-logo recovery does not depend on visiting another catalog tab and remains bounded/cancellable during full-screen playback.
18. Episode Alert discovery/presentation remains supported during VOD and Live TV.
19. vBRDC209 natural-EOF decoder isolation remains intact; no early Up Next provider fan-out while the current video is actively rendering.
20. Normal Resume checkpoints must not reintroduce >=95% completion semantics or repeated Trakt completion.
21. Main Movies/TV Shows type boundaries remain distinct; playback popup catalogs stay independently filtered.
22. Force Guide retains bounded self-healing retry-until-authoritative behavior.
23. ATVLoadly compatibility alias remains `Resources/AppIcon-1280x768.png`; canonical layered tvOS assets remain unchanged.
24. No synchronous `UserDefaults.synchronize()` calls.
