# Debrid Channels vBRDC200 — VOD Playback Handoff + Resource Priority Hardening

Release: vBRDC200  
Marketing version: 1.0.903  
Build: 903  
Donor/source of truth: packaged vBRDC199 ZIP only

## Primary fixes

- Internal VOD-to-VOD presentation changes are now distinguished from a real player dismissal.
- Dead-link automatic failover no longer performs the outgoing screen's durable resume flush, Trakt pause edge, or playback-derived catalog shelf refresh while the replacement decoder is starting.
- Next Episode/autoplay gets the same lightweight outgoing-surface handoff behavior.
- Playback-derived catalog rows recover once, when CatalogStore actually releases the VOD-exclusive gate, rather than being rebuilt during player teardown.
- The normal playback-clock publication path no longer duplicates Up Next provider/presentation/autoplay decisions; the dedicated Up Next watchdog is the sole timing owner.
- Up Next source-provider fan-out is buffer-aware on KSPlayer: early search windows require playable headroom, while the final 120/30 seconds and natural EOF retain reliability fallbacks.
- Next-episode Alternate Audio discovery is deferred until the incoming episode starts.
- Next-episode Production metadata and intro prefetch are deferred until natural EOF; they no longer compete with an actively decoding current episode.
- KSPlayer playable-endpoint telemetry is retained as non-published runtime state while VOD chrome is hidden, allowing buffer-aware scheduling without waking SwiftUI/compositor state.
- Current-title Production/Spotlight metadata completion is held in pending state while chrome is hidden and committed only when controls/panels become visible.
- Episode Alert followed-show network scanning pauses during VOD-exclusive playback and resumes after VOD. Already-queued alerts can still present, and Live TV keeps its existing alert scanning behavior.

## Preserved

- Playback UNITY catalog popup and its Home / Movies / TV Shows category/type boundaries.
- vBRDC199 manifest-authoritative catalog movie/show type hardening and Trakt order repair.
- Normal 5-second resume checkpoints and durable resume on a true exit/background lifecycle edge.
- Trakt playback synchronization on real play/pause/exit edges.
- Automatic source failover behavior and resume target continuity.
- Up Next/Next Episode autoplay reliability.
- Skip Intro and its local/community marker systems.
- Alternate Audio for the episode that is actually playing.
- Live TV Episode Alert presentation/scanning behavior.
- Approved app icon assets unchanged.

## Validation

- 9/9 vBRDC200 playback/resource-priority contract tests pass.
- All 67 app Swift source files parse successfully.
- App + Top Shelf (68 Swift files total) parse successfully.
- `project.yml` lists exactly the 67 app Swift source files present on disk.
- App and Top Shelf plists validate.
- App/Top Shelf version and build are synchronized to 1.0.903 / 903.
- `Resources/Assets.xcassets` is byte-identical to the packaged vBRDC199 donor.

Linux cannot run the tvOS SDK/Xcode archive; GitHub Actions/Xcode remains the authoritative compile/runtime validation.
