# App-wide Regression Locks — vBRDC212

1. Source Intelligence contacts configured stream providers concurrently; never restore a serial all-provider foreground loop.
2. Provider concurrency uses a sliding refill window so a slow task cannot create a fixed chunk barrier.
3. First usable provider results publish immediately and remain selectable while other providers continue.
4. Find Links must not block provider fan-out behind TMDB/Cinemeta identity hydration.
5. Manifest `stream` resource type/id-prefix constraints are used to eliminate impossible requests.
6. Movie and series endpoint aliases remain media-kind isolated; never query both sets unconditionally.
7. Repeat-title source cache stays process-memory-only, bounded, short-lived, and excluded for opaque In-S/Nuvio playback sessions.
8. PLAY may start from the first ranked direct source without waiting for all providers.
9. One dead provider must fail independently; Source Intelligence URLSession remains foreground/fail-fast and does not `waitsForConnectivity`.
10. Explicit catalog Reload supersedes a stuck active catalog generation rather than coalescing behind it.
11. First catalog paint / explicit recovery is an availability operation and must not be indefinitely held by the durable navigation/frame publication gate.
12. Official manifest/batch foreground paths remain single-attempt and bounded; retry policy belongs to catalog recovery, not nested network loops.
13. Batch failure fallback remains bounded-parallel; never restore an 80+ row serial fallback.
14. Catalog recovery keeps its dedicated fail-fast session/per-host concurrency; do not route the bounded fallback back through a lower-capacity shared session.
15. Manual catalog Reload publishes first-page/batch rows before optional complete long-shelf pagination.
16. Cached catalog rows are retained across transient refresh failure; a network miss is never permission to clear the visible catalog.
17. vBRDC211 MPNowPlayingSession ownership, Bluetooth Play/Pause, Now Playing diagnostics, and dual command-center de-duplication remain intact.
18. vBRDC211 manual Trakt resync confirmation and restore-code one-time automatic progress resync remain intact.
19. KSPlayer/VLC remain the actual VOD renderers; no Source Intelligence optimization changes playback engine ownership.
20. Movies and TV Shows remain type-correct in both primary catalogs and playback-browse catalogs.
21. Existing source ranking, provider/debrid identity, proxy headers, subtitles, failover URLs, and TorBox Usenet behavior remain intact.
22. No synchronous `UserDefaults.synchronize()` calls are reintroduced.
23. ATVLoadly/icon assets and unrelated UI artwork remain untouched by this performance pass.
