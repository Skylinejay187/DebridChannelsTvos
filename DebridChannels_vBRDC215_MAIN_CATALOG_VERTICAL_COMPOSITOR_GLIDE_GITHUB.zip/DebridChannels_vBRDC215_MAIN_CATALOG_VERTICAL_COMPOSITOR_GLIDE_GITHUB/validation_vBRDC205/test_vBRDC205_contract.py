from pathlib import Path
import plistlib
import hashlib

ROOT = Path(__file__).resolve().parents[1]
PROJECT = (ROOT / "project.yml").read_text()
TRAKT = (ROOT / "Sources/TraktSyncManager.swift").read_text()
TRAKT_CAT = (ROOT / "Sources/TraktCatalogService.swift").read_text()


def test_release_identity():
    assert PROJECT.count("MARKETING_VERSION: 1.0.908") == 2
    assert PROJECT.count("CURRENT_PROJECT_VERSION: 908") == 2
    for rel in ("Sources/Info.plist", "TopShelfExtension/Info.plist"):
        with (ROOT / rel).open("rb") as fh:
            plist = plistlib.load(fh)
        assert plist["CFBundleShortVersionString"] == "1.0.908"
        assert str(plist["CFBundleVersion"]) == "908"
        assert plist["DebridChannelsReleaseID"] == "vBRDC205"
    assert 'private static let appVersion = "1.0.908"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC205 TraktCatalog' in TRAKT_CAT


def test_atvloadly_fallback_is_explicitly_copied_postbuild():
    assert 'RAW_ICON_SRC="$PROJECT_DIR/Resources/DebridChannelsHomeIcon.png"' in PROJECT
    assert 'RAW_ICON_DST="$APP_DIR/DebridChannelsHomeIcon.png"' in PROJECT
    assert 'cp -f "$RAW_ICON_SRC" "$RAW_ICON_DST"' in PROJECT
    assert 'test -s "$RAW_ICON_DST"' in PROJECT
    assert 'cmp -s "$RAW_ICON_SRC" "$RAW_ICON_DST"' in PROJECT
    assert 'Print :CFBundleIconFile' in PROJECT
    assert 'Print :CFBundleIconFiles:0' in PROJECT
    raw = ROOT / "Resources/DebridChannelsHomeIcon.png"
    canonical = ROOT / "Resources/Assets.xcassets/DebridChannelsHomeIcon.imageset/DebridChannelsHomeIcon.png"
    assert raw.is_file() and raw.stat().st_size > 0
    assert raw.read_bytes() == canonical.read_bytes()


def test_v203_feature_contracts_remain_present():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    guide=(ROOT/'Sources/LiveTVGuideCacheManager.swift').read_text()
    resume=(ROOT/'Sources/PlaybackResumeCache.swift').read_text()
    assert 'Force Guide now means force-until-authoritative' in app
    assert 'startLiveTVGuideRecoveryLoopIfNeeded' in app
    assert 'loadPersistedStateAsync()' in guide
    assert 'func backfillThemedLogo(for item: MediaItem' in resume
    assert 'refreshConnectedAccountIdentityIfNeeded' in TRAKT


def test_v204_optional_chain_compile_fix_remains():
    app=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
    assert 'activeRowPresentation?.rowKind?.lowercased()' in app
    assert 'activeRowPresentation?.rowKind.lowercased()' not in app
