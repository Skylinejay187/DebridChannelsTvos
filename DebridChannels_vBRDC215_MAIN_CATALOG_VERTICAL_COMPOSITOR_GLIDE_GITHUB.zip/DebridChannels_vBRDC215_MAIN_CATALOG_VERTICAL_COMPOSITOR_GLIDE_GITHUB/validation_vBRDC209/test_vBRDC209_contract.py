from pathlib import Path
import plistlib, re, yaml, hashlib

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
RESUME = (ROOT / 'Sources/PlaybackResumeCache.swift').read_text()
PROJECT_TEXT = (ROOT / 'project.yml').read_text()
PROJECT = yaml.safe_load(PROJECT_TEXT)

def between(text, start, end):
    a = text.index(start)
    b = text.index(end, a)
    return text[a:b]

def test_release_identity():
    assert PROJECT_TEXT.count('MARKETING_VERSION: 1.0.912') == 2
    assert PROJECT_TEXT.count('CURRENT_PROJECT_VERSION: 912') == 2
    for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
        with (ROOT / rel).open('rb') as fh:
            p = plistlib.load(fh)
        assert p['CFBundleShortVersionString'] == '1.0.912'
        assert str(p['CFBundleVersion']) == '912'
        assert p['DebridChannelsReleaseID'] == 'vBRDC209'
    assert 'private static let appVersion = "1.0.912"' in (ROOT/'Sources/TraktSyncManager.swift').read_text()
    assert 'DebridChannels-tvOS/vBRDC209 TraktCatalog' in (ROOT/'Sources/TraktCatalogService.swift').read_text()

def test_active_video_hard_blocks_all_upnext_heavy_owners():
    prep = between(APP, 'private func startUpNextPreparationIfNeeded()', 'private func prefetchUpNextIntroAfterCurrentEpisodeEndsIfNeeded')
    source = between(APP, 'private func prepareUpNextSourcesIfNeeded', 'private func nextEpisode')
    present = between(APP, 'private func evaluateUpNextPresentation', 'private func armUpNextAutoAdvanceIfNeeded')
    arm = between(APP, 'private func armUpNextAutoAdvanceIfNeeded', 'private func startUpNextWatchdogIfNeeded')
    for block in (prep, source, present, arm):
        assert '!isPlaying' in block
    assert 'let preparation = await store.prepareUpNextEpisodeSources(for: target)' in source
    assert 'guard !Task.isCancelled,\n                  !isPlaying' in source

def test_resume_cancels_inflight_upnext_and_hides_surface():
    state = between(APP, '.onChange(of: isPlaying)', '// vBRDC193: publish an immediate Trakt start/pause edge')
    for marker in (
        'upNextPreparationTask?.cancel()',
        'upNextSourcePreparationTask?.cancel()',
        'upNextDecorationTask?.cancel()',
        'upNextPostEOFTask?.cancel()',
        'upNextCountdownTask?.cancel()',
        'upNextVisible = false',
        'upNextAutoAdvanceArmed = false',
    ):
        assert marker in state

def test_natural_eof_callback_is_zero_work_latch():
    eof = between(APP, 'private func handleNaturalEpisodeEnd(reason: String)', 'private func schedulePostEOFUpNextWork()')
    assert 'naturalEpisodeTransitionActive = true' in eof
    assert 'naturalEpisodeEndReason = reason' in eof
    assert 'upNextNaturalEndPending = true' in eof
    assert 'upNextWatchdogTask?.cancel()' in eof
    for forbidden in (
        'markCompleted(', 'PlaybackResumeCacheManager.shared.clear',
        'fetchSeriesEpisodes', 'prepareUpNextEpisodeSources',
        'updateNowPlaying(', 'playbackMetadata(for:'
    ):
        assert forbidden not in eof

def test_post_eof_lane_owns_completion_and_provider_start():
    post = between(APP, 'private func schedulePostEOFUpNextWork()', 'private func startLocalIntroDetectionIfNeeded')
    assert 'Task.sleep(nanoseconds: 300_000_000)' in post
    for marker in (
        'BluetoothVODMediaButtonCoordinator.shared.updateNowPlaying(',
        'TraktSyncManager.shared.markCompleted(',
        'PlaybackResumeCacheManager.shared.clear(for: item)',
        'LocalIntroDetectionEngine.shared.finishSession',
        'startUpNextPreparationIfNeeded()',
        'prepareUpNextSourcesIfNeeded(force: true)',
    ):
        assert marker in post

def test_no_95_percent_completion_network_or_clock_amplification():
    save = between(APP, 'private func saveResumePositionIfNeeded', 'private func defaultExternalTargetForCurrentItem')
    assert 'markCompleted(' not in save
    assert 'elapsed / resolvedDurationSeconds >= 0.95' not in save
    clock = between(APP, 'private func startPlayerClock()', 'private func formatTime')
    assert 'currentSeconds / total >= 0.95' not in clock
    assert 'markCompleted(item: item, duration: total)' not in clock

def test_resume_cache_completion_window_does_not_rewrite_every_checkpoint():
    save = between(RESUME, 'func saveProgress(item:', '/// vBRDC197: materialize')
    assert 'seconds / normalizedDuration >= completionThreshold' in save
    assert 'if synchronously { clear(for: item, synchronously: true) }' in save
    # no unconditional clear in the completion branch
    completion = save[save.index('if normalizedDuration > 0'):save.index('let key = playbackKey')]
    assert completion.count('clear(for: item') == 1
    assert 'if synchronously' in completion

def test_upnext_artwork_is_not_forced_over_playback():
    overlay = between(APP, 'private var upNextEpisodeOverlay', 'private func handleBluetoothVODMediaCommand')
    assert 'maxPixelSize: 512' in overlay
    assert 'forceVisiblePlaybackPublication: false' in overlay

def test_v208_episode_alert_nowplaying_and_atvloadly_contracts_preserved():
    suspend = between(APP, 'private func suspendNonAlertRootWorkForVOD()', 'private func resumeNonAlertRootWorkAfterVOD()')
    assert 'stopNewEpisodeHeartbeat' not in suspend
    scan = between(APP, 'private func runRealEpisodeAlertScan', 'private func enqueueNewEpisodeAlerts')
    assert 'allowExistingScannerDuringPlayback' in scan
    manager = between(APP, 'private final class DebridNowPlayingManager', 'final class BluetoothVODMediaButtonCoordinator')
    for marker in ('MPNowPlayingInfoPropertyMediaType', 'MPNowPlayingInfoMediaType.video.rawValue', 'MPNowPlayingInfoPropertyAssetURL', 'AVAudioSession.sharedInstance()'):
        assert marker in manager
    approved = ROOT/'Resources/DebridChannelsHomeIcon.png'
    alias = ROOT/'Resources/AppIcon-1280x768.png'
    assert approved.exists() and alias.exists() and approved.read_bytes() == alias.read_bytes()

def test_project_source_contract():
    app_sources = PROJECT['targets']['DebridChannelsTVOS']['sources']
    swift_entries = [x for x in app_sources if isinstance(x, dict) and str(x.get('path','')).endswith('.swift')]
    assert len(swift_entries) == 67
    top_sources = PROJECT['targets']['DebridChannelsTopShelf']['sources']
    assert len([x for x in top_sources if isinstance(x, dict) and str(x.get('path','')).endswith('.swift')]) == 1
