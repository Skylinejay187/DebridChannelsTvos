# Debrid Channels vBRDC213 — Build Fix + v211/v212 Preservation

Release: vBRDC213  
Marketing version: 1.0.916  
Build: 916  
Donor/source of truth: packaged vBRDC212 `INSTANT_SOURCE_INTELLIGENCE_CATALOG_FORCE_LOAD` ZIP only.

## GitHub build failure root cause

The supplied GitHub Actions log did not fail in Swift compilation. The build stopped in the existing **V1041 Production configuration validation** phase before the app target's Swift sources were compiled.

The ZIP used by that run was the earlier/intermediate package named:

`DebridChannels_vBRDC212_INSTANT_SOURCE_CATALOG_BOOTSTRAP_GITHUB.zip`

That archive had a split release identity:

- Main app: 1.0.915 / build 915
- Top Shelf extension: 1.0.914 / build 914
- Some release IDs/User-Agents still identified as vBRDC211

The validation phase correctly stopped the build with:

`ERROR: App version 1.0.915 does not match Top Shelf version 1.0.914.`

vBRDC213 is packaged from the later/final vBRDC212 donor and gives the app, Top Shelf extension, project settings, Trakt app version, Trakt catalog User-Agent, and Source Intelligence/catalog User-Agents one coherent vBRDC213 / 1.0.916 / 916 identity.

## vBRDC211 behavior retained

- MPNowPlayingSession backed by the bundled muted AVPlayer media anchor.
- Session-scoped and shared MediaRemote command centers for Bluetooth Play/Pause.
- VOD and Live TV Now Playing publication and diagnostics.
- Explicit Trakt resync confirmation.
- Restore-code Keychain Trakt recovery with one automatic playback resync.
- Playback-already-synchronized catalog refresh path to avoid duplicate Trakt progress requests.

## vBRDC212 behavior retained

- Sliding bounded Source Intelligence provider fan-out (up to 12 lanes).
- Fail-fast foreground source URLSession and dedicated catalog URLSession.
- Provider-by-provider incremental source publication and first-source focus.
- Parallel identity hydration rather than blocking provider discovery.
- Manifest capability filtering and configure-page normalization.
- Movie/series endpoint separation and bounded recovery identities.
- Short-lived in-memory source/manifest caches.
- First direct source can start PLAY before the complete provider wave finishes.
- Forced catalog reload supersedes a stalled generation.
- First catalog paint bypasses the durable frame gate when no rows are visible.
- Fast manifest/batch budgets and bounded parallel per-row fallback.
- Fast visible reload followed by background long-shelf pagination.
- 1 s / 3 s / 8 s early catalog recovery cadence with durable cached-row fallback retained.

## Build-fix scope

No player engine, artwork asset, catalog UI, source ranking, provider credentials, playback semantics, Trakt semantics, or source-search algorithm was changed in vBRDC213. Runtime code changes versus the final vBRDC212 donor are release/User-Agent labels only.

GitHub Actions/Xcode with the tvOS SDK remains authoritative for full SDK compile/link. Linux validation performs full Swift parser coverage, plist/YAML checks, regression contracts, donor diff checks, and ZIP integrity.
