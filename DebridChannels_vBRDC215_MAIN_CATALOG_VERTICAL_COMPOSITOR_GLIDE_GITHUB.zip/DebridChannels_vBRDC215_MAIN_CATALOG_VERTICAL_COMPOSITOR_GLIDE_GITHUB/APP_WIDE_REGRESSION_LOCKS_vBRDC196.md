# App-Wide Regression Locks — vBRDC196

1. Build lineage remains packaged vBRDC195 -> vBRDC196 only.
2. All-in-One mode changes invalidate old catalog-load generations; an earlier request may never republish a superseded mode.
3. Official All-in-One cache, external catalog cache, Trakt account cache, and local resume data remain separate ownership domains.
4. External catalogs must respect All-in-One OFF immediately without requiring app restart; All-in-One ON must recover official rows immediately from its own cached/protected state when available.
5. Customize All-in-One includes built-in rows, local Continue Watching and Trakt rows.
6. Every customizable row keeps On/Off, Move to Top, Move Up and Move Down controls; reordering cached rows must not force a full network reload.
7. Trakt account rows remain excluded from the protected official catalog snapshot even though their order/visibility is customizable.
8. Trakt movie rows may contain movies only; Trakt TV-show rows may contain series/shows only.
9. Connected Trakt accounts may expose separate Continue Watching, Watch History, Watchlist, Favorites, Recommendations, Trending, Popular and Anticipated shelves for Movies and TV Shows.
10. Trakt shelves use last-known-good row merging; a temporary empty/failed endpoint must not erase unrelated healthy account rows.
11. Post-playback Trakt shelf refresh must occur after the durable pause scrobble/cloud checkpoint rather than racing it.
12. Native Debrid Channels Continue Watching remains available from local resume state independently of Trakt.
13. Resume progress has dual durable persistence and the newest valid local payload wins on relaunch; valid local progress must not reset merely because the process closed.
14. Trakt remains an optional synchronization layer over local resume; failure/disconnect must never delete valid local checkpoints.
15. No end user is asked for a Trakt Client ID or Client Secret; no Trakt application secret may appear in UI, status text, readmes or validation logs.
16. Spotlight Hub Trakt integration remains optional.
17. Live TV Episode Alerts remain enabled.
18. Production & Ratings themed logo remains an independent setting.
19. Player Engine chip remains absent from the VOD rail.
20. vBRDC189 fixed/even VOD rail and full Video Fit behavior remain unchanged.
21. Playback catalog themed-logo identity publication from vBRDC187 remains intact.
22. vBRDC188 approved app icon assets remain unchanged.
