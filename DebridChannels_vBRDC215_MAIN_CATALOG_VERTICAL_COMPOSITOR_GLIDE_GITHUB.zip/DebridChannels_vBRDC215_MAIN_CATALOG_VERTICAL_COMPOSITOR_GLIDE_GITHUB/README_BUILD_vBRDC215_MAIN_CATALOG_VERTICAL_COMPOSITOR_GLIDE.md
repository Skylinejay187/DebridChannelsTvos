# Debrid Channels vBRDC215 — Main Catalog Vertical Compositor Glide

Release: vBRDC215
Marketing: 1.0.918
Build: 918
Donor: packaged vBRDC214 only.

## Why this build exists
The vBRDC214 main-catalog pass removed expensive preview/hero work from the Up/Down frame, but the visual row handoff itself still used the older v715 animation-disabled data swap. That protected against old previous/next-row ghosting, but it could still look abrupt even when frame time was healthy.

## Main Home / Movies / TV Shows vertical row transition
- Keeps the single persistent `GridOSFixedSlotCatalogRail`; no second outgoing row tree is mounted.
- Keeps `.transition(.identity)` and `.animation(nil, value: activeRowIndex)` on the persistent rail, preserving the established no-peek/no-ghost contract.
- On Up/Down, the destination row is rebound atomically in an animation-disabled transaction.
- The destination quick-panel (provider title, cards, and next-row label) then receives a compositor-only 32-point directional arrival glide with a restrained 0.94→1.0 opacity settle.
- The visible glide is a 240 ms ease-out and starts on the next run-loop turn after the row data has rebound, mirroring the proven persistent horizontal rail strategy: data first, compositor motion second.
- Rapid repeated Up/Down moves are generation-owned so a stale animation/settle task cannot finish over a newer row.
- tvOS Reduce Motion is respected; when enabled the destination commits immediately without the visual glide.
- The playback-browse catalog path is deliberately untouched (`phase = 1`) because the user already reported it as smooth.

## Frame-budget protection
The vBRDC214 preview/hero suppression remains and is extended through the complete visible transition. Up/Down navigation now holds the navigation-geometry lane for 300 ms, and focused-card preview/hero metadata work resumes only after the destination row has landed.

## Preserved
- vBRDC214 universal all-configured-Stremio-addon fan-out and first-result publication
- vBRDC214 shared MPRemoteCommandCenter + dual Now Playing publication + persistent muted ownership anchor
- vBRDC211 Trakt restore/resync behavior
- vBRDC212 catalog force-load, fast catalog session, provider fail-fast, caches, ranking, source failover, and first-link playback behavior
- Catalog filtering/type boundaries, focus restoration, row-entry first-card policy, Details restore, artwork identity hardening, Live TV/VOD catalog browser behavior, player engines, UI themes and layout

## Validation boundary
Linux validation parses Swift syntax, validates plist/project release coherence, and runs source-level regression contracts. GitHub Actions/Xcode remains authoritative for tvOS SDK compile/link, and a physical Apple TV remains authoritative for perceived frame pacing.
