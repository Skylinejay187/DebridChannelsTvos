from pathlib import Path
import plistlib
import hashlib
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "Sources/DebridChannelsTVOSApp.swift").read_text()
TRAKT = (ROOT / "Sources/TraktSyncManager.swift").read_text()
TRAKT_CAT = (ROOT / "Sources/TraktCatalogService.swift").read_text()
HERO = (ROOT / "Sources/CatalogHeroMetadataCache.swift").read_text()
RESUME = (ROOT / "Sources/PlaybackResumeCache.swift").read_text()
STORE = (ROOT / "Sources/CatalogStore.swift").read_text()
GUIDE = (ROOT / "Sources/LiveTVGuideCacheManager.swift").read_text()
PROJECT = (ROOT / "project.yml").read_text()
UNITY = (ROOT / "Sources/UnityCatalogVisualSystem.swift").read_text()


def block(text, start, end):
    a = text.index(start)
    b = text.index(end, a)
    return text[a:b]


def test_release_identity():
    assert PROJECT.count("MARKETING_VERSION: 1.0.906") == 2
    assert PROJECT.count("CURRENT_PROJECT_VERSION: 906") == 2
    for rel in ("Sources/Info.plist", "TopShelfExtension/Info.plist"):
        with (ROOT / rel).open("rb") as fh:
            plist = plistlib.load(fh)
        assert plist["CFBundleShortVersionString"] == "1.0.906"
        assert str(plist["CFBundleVersion"]) == "906"
        assert plist["DebridChannelsReleaseID"] == "vBRDC203"
    assert 'private static let appVersion = "1.0.906"' in TRAKT
    assert 'private static let appDate = "2026-09-07"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC203 TraktCatalog' in TRAKT_CAT


def test_trakt_identity_recovers_from_keychain_without_display_name():
    restore = block(TRAKT, "func restorePersistedConnectionIfNeeded()", "var accountIdentityVerified")
    assert "connectedAccountName" not in restore.split("guard let raw", 1)[0]
    assert 'readKeychainString(account: Self.tokenAccount)' in restore
    identity = block(TRAKT, "func refreshConnectedAccountIdentityIfNeeded", "var connectedAccountName")
    assert "fetchAccountName()" in identity
    assert 'accountVerifiedDefaultsKey' in identity
    assert 'Connected as \\(resolved) • Verified' in identity
    assert 'removeObject(forKey: Self.accountVerifiedDefaultsKey)' in TRAKT
    assert 'authenticatedGET(path: "/users/settings")' in TRAKT


def test_trakt_settings_show_verified_identity_and_restore_refreshes_it():
    assert 'Connected ✓: \\(TraktSyncManager.shared.connectedAccountName) • \\(TraktSyncManager.shared.accountIdentityVerified ? "Verified ✓"' in APP
    assert APP.count("refreshConnectedAccountIdentityIfNeeded(") >= 4
    restore_area = block(APP, "restore codes intentionally never carry Trakt OAuth refresh", "await MainActor.run")
    assert "restorePersistedConnectionIfNeeded()" in restore_area
    assert "refreshConnectedAccountIdentityIfNeeded(force: true)" in restore_area


def test_trakt_and_resume_force_themed_logo_hydration():
    assert "append_to_response=images&include_image_language=en,null" in TRAKT_CAT
    assert "priorityLogoHydration" in TRAKT_CAT
    assert "matched poster" in TRAKT_CAT
    assert "existing.logoURL = hydrated.logoURL" in TRAKT_CAT
    assert "let logoURL: String?" in TRAKT_CAT
    assert "logoURL: logoURL" in TRAKT_CAT
    assert "let logoURL: String?" in HERO
    assert 'URLQueryItem(name: "include_image_language", value: "en,null")' in HERO
    focused = block(APP, "private var focusedThemedLogoURL", "private var activeRowPresentation")
    assert "focusedHeroMetadata?.logoURL" in focused
    assert "backfillThemedLogo(for: item, logoURL: logoURL)" in APP


def test_resume_persists_logo_independently():
    assert "var logoArtworkURL: String? = nil" in RESUME
    assert "logoArtworkURL: item.logoURL" in RESUME
    assert "let preservedLogo = item.logoURL ?? newestExisting?.logoArtworkURL" in RESUME
    assert "func backfillThemedLogo(for item: MediaItem" in RESUME
    assert "logoURL: entry.logoArtworkURL" in STORE
    assert "logoURL: matched.logoURL" in STORE


def test_live_guide_health_bypasses_three_hour_stale_gate():
    health = block(APP, "private func hasCurrentOrUpcomingGuideCoverage", "func retryIncompleteGuideRecovery")
    assert "end > now && start < futureCutoff" in health
    assert "hasConfiguredLiveTVSource" in health
    assert "guard hasConfiguredLiveTVSource else { return false }" in health
    assert "guard hasRealLineup else { return true }" in health
    refresh = block(APP, "func refreshIfNeeded()", "func forceRefreshGuide()")
    assert "guideRecoveryRequired" in refresh
    assert "userInitiatedForce: recoveringIncompleteGuide" in refresh
    publication = block(APP, "func refreshFromConfiguredSources", "private static func parseSourceList")
    assert "let guideHealthy = hasCurrentOrUpcomingGuideCoverage(finalizedGuidePrograms)" in publication
    assert "guideCacheManager.markRefreshed()" in publication
    assert "guideCacheManager.resetRefreshClock()" in publication
    assert "guide incomplete • recovery armed" in publication


def test_force_guide_and_normal_live_surface_keep_retrying_with_backoff():
    normal = block(APP, "private func startLiveTVGuideRecoveryLoopIfNeeded", "private func startLiveTVRefreshIfActive")
    for seconds in ("10", "30", "60", "120", "300"):
        assert seconds in normal
    assert "while !Task.isCancelled" in normal
    assert "liveModel.retryIncompleteGuideRecovery()" in normal
    force = block(APP, "private func runQuickPanelForceRefresh()", "private var quickPanelRefreshLabel")
    assert "Force Guide now means force-until-authoritative" in force
    assert "while liveModel.guideRecoveryRequired" in force
    assert "liveModel.retryIncompleteGuideRecovery()" in force
    assert "retryDelays" in force


def test_zero_channel_provider_failure_never_counts_as_refresh_success():
    source = block(APP, "func refreshFromConfiguredSources", "private static func parseSourceList")
    empty = block(source, "if dedupe(loaded).isEmpty", "// Guide enrichment phase")
    assert "guideCacheManager.resetRefreshClock()" in empty
    assert "recovery armed" in empty


def test_deferred_xtream_publication_is_generation_safe_and_bounded():
    deferred = block(APP, "private func loadDeferredXtreamShortGuide", "private func commitXtreamChannelsInVisibleBatches")
    assert deferred.count("generation == refreshGeneration") >= 2
    assert "maxWait: 1.20" in deferred
    assert "guideCacheManager.resetRefreshClock()" in deferred


def test_persisted_live_guide_decode_runs_on_utility_queue():
    async_load = block(GUIDE, "func loadPersistedStateAsync()", "func persistGuidePrograms")
    assert "Self.persistenceQueue.async" in async_load
    assert "loadChannelSnapshots()" in async_load
    assert "loadGuidePrograms()" in async_load
    restore = block(APP, "func loadCachedOrDemo()", "private func persistGuidePrograms")
    assert "loadPersistedStateAsync()" in restore
    assert "await task.value" in restore


def test_atvloadly_raw_icon_fallback_is_bundled_without_changing_canonical_icon():
    with (ROOT / "Sources/Info.plist").open("rb") as fh:
        plist = plistlib.load(fh)
    assert plist["CFBundleIconName"] == "AppIcon"
    assert plist["CFBundleIconFile"] == "DebridChannelsHomeIcon.png"
    assert plist["CFBundleIconFiles"] == ["DebridChannelsHomeIcon.png"]
    assert "Resources/DebridChannelsHomeIcon.png" in PROJECT
    assert 'test -f "$APP_DIR/DebridChannelsHomeIcon.png"' in PROJECT
    raw = ROOT / "Resources/DebridChannelsHomeIcon.png"
    canonical = ROOT / "Resources/Assets.xcassets/DebridChannelsHomeIcon.imageset/DebridChannelsHomeIcon.png"
    assert raw.read_bytes() == canonical.read_bytes()


def test_no_synchronous_userdefaults_flush_left_in_app_sources():
    assert ".synchronize()" not in APP
    assert ".synchronize()" not in UNITY


def test_project_source_inventory_is_intact():
    parsed = yaml.safe_load(PROJECT)
    target = parsed["targets"]["DebridChannelsTVOS"]
    paths = []
    for entry in target["sources"]:
        path = entry if isinstance(entry, str) else entry.get("path")
        if path and path.endswith(".swift"):
            paths.append(path)
    assert len(paths) == 67, len(paths)
    assert len(set(paths)) == 67
    for rel in paths:
        assert (ROOT / rel).is_file(), rel
    assert len(list((ROOT / "TopShelfExtension").glob("*.swift"))) == 1
