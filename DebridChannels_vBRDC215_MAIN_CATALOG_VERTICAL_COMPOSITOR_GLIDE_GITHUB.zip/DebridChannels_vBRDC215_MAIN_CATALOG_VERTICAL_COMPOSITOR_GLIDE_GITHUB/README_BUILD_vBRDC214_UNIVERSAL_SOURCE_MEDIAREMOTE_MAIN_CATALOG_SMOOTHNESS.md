# Debrid Channels vBRDC214 — Universal Source Fan-Out + MediaRemote + Main Catalog Smoothness

Release: vBRDC214
Marketing: 1.0.917
Build: 917
Donor: packaged vBRDC213 only.

## Universal Source Intelligence
- Every configured Stremio stream addon receives a provider task immediately. The previous 12-addon application queue is removed.
- Existing vBRDC212 completion-order publishing, first-link playback, manifest/stream fail-fast budgets, compatibility filtering, memory caches, identity fallback, and provider ranking remain intact.
- URLSession retains per-host transport limits so duplicate endpoints cannot create unbounded connections.
- Network/provider response time cannot be made literally zero, but Debrid Channels no longer intentionally waits to start later configured addons.

## Bluetooth / Now Playing
- The shared MPRemoteCommandCenter is registered first as the authoritative custom-player accessory route, matching Apple's tvOS custom-player guidance; MPNowPlayingSession remains mirrored.
- Now Playing metadata is published to both MPNowPlayingInfoCenter.default() and the MPNowPlayingSession info center.
- The muted local AVPlayer ownership anchor remains playing for the entire real media session, even when KSPlayer/VLC is paused. PlaybackRate still reports the real paused/playing state.
- This specifically addresses the observed pattern where the first headphone Pause works and the following Play is no longer routed after the anchor itself was paused.

## Main catalog vertical scrolling
- Main Home/Movies/Shows now suspends focused-card preview resolution, hero metadata fetches, and decorative high-resolution work during Up/Down row movement.
- Decorative work restarts after a short 160 ms settle on the destination row.
- This matches the lighter frame-budget behavior already seen in playback-browse catalogs without changing catalog layout or navigation semantics.

## Preserved
vBRDC211 Trakt restore/resync, vBRDC212 catalog force-load and Source Intelligence first-result behavior, player engines, ranking, provider identity, headers, subtitles, failover, catalog type boundaries, artwork/UI design, and all prior regression locks remain preserved.
