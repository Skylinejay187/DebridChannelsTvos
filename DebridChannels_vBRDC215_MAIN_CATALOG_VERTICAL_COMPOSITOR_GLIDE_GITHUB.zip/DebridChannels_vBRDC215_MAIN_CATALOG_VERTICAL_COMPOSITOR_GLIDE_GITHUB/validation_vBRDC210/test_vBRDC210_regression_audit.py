from pathlib import Path
import plistlib, re
ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT/'Sources/CatalogStore.swift').read_text()
TRAKT = (ROOT/'Sources/TraktSyncManager.swift').read_text()
HERO = (ROOT/'Sources/CatalogHeroMetadataCache.swift').read_text()
PROJECT = (ROOT/'project.yml').read_text()

def test_release_identity():
    assert PROJECT.count('MARKETING_VERSION: 1.0.913') == 2
    assert PROJECT.count('CURRENT_PROJECT_VERSION: 913') == 2
    for rel in ('Sources/Info.plist','TopShelfExtension/Info.plist'):
        with (ROOT/rel).open('rb') as f: p=plistlib.load(f)
        assert p['CFBundleShortVersionString']=='1.0.913'
        assert str(p['CFBundleVersion'])=='913'
        assert p['DebridChannelsReleaseID']=='vBRDC210'

def test_now_playing_eligibility_contract():
    with (ROOT/'Sources/Info.plist').open('rb') as f: p=plistlib.load(f)
    assert 'audio' in p.get('UIBackgroundModes', [])
    assert 'try session.setCategory(.playback, mode: .moviePlayback, options: [])' in APP
    assert 'try session.setActive(true)' in APP
    assert 'UIApplication.shared.beginReceivingRemoteControlEvents()' in APP
    for marker in ('togglePlayPauseCommand.addTarget','playCommand.addTarget','pauseCommand.addTarget'):
        assert marker in APP
    assert 'MPNowPlayingInfoPropertyMediaType' in APP
    assert 'MPNowPlayingInfoMediaType.video.rawValue' in APP
    assert 'MPNowPlayingInfoPropertyPlaybackRate' in APP
    assert 'MPNowPlayingInfoPropertyElapsedPlaybackTime' in APP
    assert 'MPNowPlayingInfoPropertyServiceIdentifier' in APP

def test_remote_commands_enabled_before_audio_activation():
    vod = APP[APP.index('func claimVODSession(', APP.index('final class BluetoothVODMediaButtonCoordinator')):]
    vod = vod[:vod.index('func claimLiveControlSession')]
    assert vod.index('syncAvailability()') < vod.index('activateVODAudioSession()')
    live = APP[APP.index('func claimLiveControlSession'):APP.index('func releaseVODSession')]
    assert live.index('syncAvailability()') < live.index('activateVODAudioSession()')

def test_live_claim_precedes_decoder_mount():
    start = STORE[STORE.index('func startPlayback(item: MediaItem'):STORE.index('private func quickPlaybackPreflight') if False else len(STORE)]
    # Narrow to startPlayback body.
    start = start[:start.index('/// Phase 0 entry point')]
    assert 'claimLiveControlSession' in start
    assert start.index('claimLiveControlSession') < start.index('playbackURL = url')

def test_live_pause_updates_system_rate():
    assert 'func updateLivePlaybackState' in APP
    change = APP[APP.index('.onChange(of: isPlaying)'):]
    assert 'updateLivePlaybackState(playbackPresentationID, isPlaying: playing)' in change[:4000]

def test_trakt_manual_resync_restores_session_first():
    block = TRAKT[TRAKT.index('func manualResyncFromSettings'):TRAKT.index('var connectedAccountName')]
    assert block.index('restorePersistedConnectionIfNeeded()') < block.index('refreshPlaybackProgress(force: true)')
    settings = APP[APP.index('SettingsButton(title: "Sync Resume Now"'):]
    settings = settings[:settings.index('if TraktSyncManager.shared.isConnected')]
    assert 'manualResyncFromSettings()' in settings
    assert 'refreshPlaybackProgress(force: true)' not in settings

def test_cold_resume_artwork_is_explicit():
    assert 'func hydrateResumeArtworkOnColdLaunchIfNeeded' in STORE
    for marker in ('posterURL: String?','landscapeURL: String?','logoURL: String?'):
        assert marker in HERO
    block = STORE[STORE.index('func hydrateResumeArtworkOnColdLaunchIfNeeded'):STORE.index('func refreshPlaybackDerivedCatalogRows(')]
    assert 'entries.prefix(12)' in block
    assert 'batchSize = 3' in block
    assert 'CatalogHeroMetadataCache.shared.metadata' in block
    assert 'resumeColdArtworkOverrides' in block
    assert 'backfillArtworkBatch' in block
    local = STORE[STORE.index('private func localContinueWatchingRow'):STORE.index('private func immediateTraktContinueRows')]
    assert 'coldOverride?.posterURL' in local
    assert 'coldOverride?.landscapeURL' in local
    assert 'coldOverride?.logoURL' in local

def test_cold_hydration_cancels_for_playback():
    assert STORE.count('resumeColdArtworkHydrationTask?.cancel()') >= 3
    assert '!fullScreenPlaybackResourceSuspended' in STORE[STORE.index('func hydrateResumeArtworkOnColdLaunchIfNeeded'):STORE.index('func refreshPlaybackDerivedCatalogRows(')]

def test_resume_projection_does_not_force_duplicate_account_refresh():
    sig='func refreshPlaybackDerivedCatalogRows(scheduleAccountRefresh: Bool = true)'
    assert sig in STORE
    block=STORE[STORE.index(sig):STORE.index('func removeTraktCatalogRows')]
    assert 'guard scheduleAccountRefresh, TraktSyncManager.shared.isConnected else { return }' in block
    assert APP.count('refreshPlaybackDerivedCatalogRows(scheduleAccountRefresh: false)') >= 4

def test_episode_alert_playback_contract_preserved():
    assert 'allowExistingScannerDuringPlayback = episodeAlertFullScreenPlaybackActive' in APP
    assert 'newEpisodeAlertPresentationScope == .mainAndVOD' in APP
    assert 'deferred while VOD playback owns frame budget' not in APP

def test_up_next_eof_isolation_preserved():
    for marker in ('naturalEpisodeTransitionActive','upNextPostEOFTask','schedulePostEOFUpNextWork()'):
        assert marker in APP
    prep=APP[APP.index('private func prepareUpNextSourcesIfNeeded'):APP.index('private func nextEpisode')]
    assert '!isPlaying,' in prep
    assert 'current video is the absolute resource owner' in APP

def test_atvloadly_icon_contract_preserved():
    assert 'Resources/AppIcon-1280x768.png' in PROJECT
    assert 'ATVLOADLY_ICON_DST="$APP_DIR/AppIcon-1280x768.png"' in PROJECT
    assert (ROOT/'Resources/AppIcon-1280x768.png').exists()

def test_force_guide_recovery_preserved():
    for marker in ('Force Guide now means force-until-authoritative','guide self-heal','retryIncompleteGuideRecovery'):
        assert marker in APP

def test_main_catalog_type_boundary_preserved():
    assert 'vBRDC199: a fuller but type-corrupted v198 snapshot must never beat a' in STORE
    assert 'vBRDC199: for the official All-in-One source the manifest catalog' in STORE

def test_no_obsolete_sync_or_completion_amplifiers():
    assert '.synchronize()' not in APP
    save=APP[APP.index('private func saveResumePositionIfNeeded'):APP.index('private func defaultExternalTargetForCurrentItem')]
    assert 'markCompleted' not in save
    assert '>= 0.95' not in save
