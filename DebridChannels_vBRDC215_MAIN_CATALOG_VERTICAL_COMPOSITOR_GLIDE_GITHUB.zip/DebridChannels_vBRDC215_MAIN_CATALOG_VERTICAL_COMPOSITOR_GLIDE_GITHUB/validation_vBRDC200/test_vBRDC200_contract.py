from pathlib import Path
import plistlib

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "Sources/DebridChannelsTVOSApp.swift").read_text()
STORE = (ROOT / "Sources/CatalogStore.swift").read_text()
PROJECT = (ROOT / "project.yml").read_text()

def block(start, end):
    a = APP.index(start)
    b = APP.index(end, a)
    return APP[a:b]

def test_release_version():
    assert PROJECT.count("MARKETING_VERSION: 1.0.903") == 2
    assert PROJECT.count("CURRENT_PROJECT_VERSION: 903") == 2
    for rel in ("Sources/Info.plist", "TopShelfExtension/Info.plist"):
        with (ROOT / rel).open("rb") as fh:
            plist = plistlib.load(fh)
        assert plist["CFBundleShortVersionString"] == "1.0.903"
        assert str(plist["CFBundleVersion"]) == "903"

def test_internal_vod_handoff_is_lightweight():
    teardown = block("private var isInternalVODPlaybackHandoff", "private func presentAutomaticSourceFailoverToast")
    assert "store.vodExclusivePlaybackActive" in teardown
    assert "store.playbackPresentationID != playbackPresentationID || incomingURL != url" in teardown
    assert "if !isLivePlayback && !internalHandoff" in teardown
    assert "PlaybackResumeCacheManager.shared.flushSynchronously()" in teardown
    assert "store.refreshPlaybackDerivedCatalogRows()" not in teardown
    assert "[VODHandoff][vBRDC200] lightweight outgoing teardown" in teardown

def test_old_surface_uses_handoff_mode():
    lifecycle = block(".onDisappear {", "private var playerInputTree")
    assert "let internalVODHandoff = isInternalVODPlaybackHandoff" in lifecycle
    assert "teardownPlayer(forInternalHandoff: internalVODHandoff)" in lifecycle
    assert "LocalIntroDetectionEngine.shared.finishSession" in lifecycle

def test_up_next_has_single_timing_owner():
    clock = block(".onChange(of: currentSeconds)", ".onChange(of: playbackOverlayBridge.snapshot)")
    assert "evaluateSkipIntroPresentation()" in clock
    assert "prepareUpNextSourcesIfNeeded" not in clock
    assert "evaluateUpNextPresentation" not in clock
    assert "armUpNextAutoAdvanceIfNeeded" not in clock
    watchdog = block("private func startUpNextWatchdogIfNeeded()", "private func handleNaturalEpisodeEnd")
    assert "prepareUpNextSourcesIfNeeded(force: upNextNaturalEndPending)" in watchdog
    assert "evaluateUpNextPresentation(forceAtEnd: upNextNaturalEndPending)" in watchdog

def test_up_next_provider_search_is_buffer_aware():
    source_prep = block("private func prepareUpNextSourcesIfNeeded", "private func nextEpisode")
    assert "latestBufferedPlaybackSeconds" in source_prep
    assert "bufferedHeadroom >= 24" in source_prep
    assert "bufferedHeadroom >= 12" in source_prep
    assert "remaining > 120" in source_prep
    assert "remaining > 30" in source_prep

def test_next_episode_decor_and_alternate_audio_are_deferred():
    identity = block("private func startUpNextPreparationIfNeeded()", "private func prefetchUpNextIntroAfterCurrentEpisodeEndsIfNeeded")
    assert "VODProductionMetadataService.fetch" not in identity
    assert "AppSideIntroSegmentService.shared.prefetch" not in identity
    source_prep = block("private func prepareUpNextSourcesIfNeeded", "private func nextEpisode")
    assert "AlternateAudioDiscoveryClient.discover" not in source_prep
    assert "Available after episode starts" in source_prep
    eof_decor = block("private func loadUpNextDecorationAfterCurrentEpisodeEndsIfNeeded", "private func prepareUpNextSourcesIfNeeded")
    assert "guard upNextNaturalEndPending" in eof_decor
    assert "VODProductionMetadataService.fetch" in eof_decor

def test_hidden_production_metadata_does_not_publish_to_swiftui():
    production = block("private func loadVODProductionMetadata", "private func showVODCastExplorerOnboardingIfNeeded")
    assert "pendingVODProductionMetadata = snapshot" in production
    assert "if controlsVisible || activePanel != nil" in production
    assert "commitPendingVODProductionMetadataIfVisible" in production
    buffer_cb = block("onKSBufferUpdate:", "onKSTracksDiscovered:")
    assert "latestBufferedPlaybackSeconds = normalizedPlayable" in buffer_cb
    assert "guard controlsVisible || activePanel != nil || isScrubbingTimeline || isSeekingInPlayer else { return }" in buffer_cb

def test_episode_alert_network_scans_defer_only_for_vod():
    scheduler = block("private func activateNewEpisodeAlertScheduler", "private func shouldRunImmediateEpisodeAlertCatchUp")
    assert "!store.vodExclusivePlaybackActive" in scheduler
    scan = block("private func runRealEpisodeAlertScan", "private func enqueueNewEpisodeAlerts")
    assert "if store.vodExclusivePlaybackActive" in scan
    assert "deferred while VOD playback owns frame budget" in scan
    assert "allowExistingScannerDuringPlayback" in scan

def test_v199_catalog_type_boundary_contract_still_present():
    for marker in (
        "vBRDC199: for the official All-in-One source the manifest catalog",
        "vBRDC199: a fuller but type-corrupted v198 snapshot must never beat a",
        "[TraktCatalog][vBRDC199] repaired/promoted connected Trakt shelves to top order",
    ):
        assert marker in STORE
