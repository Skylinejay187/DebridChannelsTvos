# APP-WIDE REGRESSION LOCKS — vBRDC192

1. Build only from packaged vBRDC191 donor state.
2. Production & Ratings and Spotlight Hub are mutually exclusive Media Information owners; Off is also valid.
3. Production & Ratings Themed Logo is an independent preference and must not disappear when another feature panel is selected.
4. Spotlight Hub must not fall back to the retired Collector Showcase or static Behind the Scenes crew/scene panel.
5. Spotlight Hub may fetch TMDB videos/reviews/watch providers only as part of the existing optional VOD production-metadata demand path; it must not become always-on background work.
6. Watch-provider display must include JustWatch attribution.
7. Episode Alerts use one existing scheduler/queue across Main UI, VOD and Live TV; no second Live TV polling system.
8. Full-screen playback Episode Alerts are passive banners only and must never take focus, pause playback, alter playback clocks, or force controls open.
9. vBRDC188 icon assets remain unchanged.
10. vBRDC189 fixed/even VOD rail and full Video Fit system remain unchanged.
11. vBRDC190 Player Engine chip stays absent from the VOD shelf; engine selection remains available in settings/internal panel logic.
12. vBRDC187 playback catalog logo identity and top-bar removal remain intact.
