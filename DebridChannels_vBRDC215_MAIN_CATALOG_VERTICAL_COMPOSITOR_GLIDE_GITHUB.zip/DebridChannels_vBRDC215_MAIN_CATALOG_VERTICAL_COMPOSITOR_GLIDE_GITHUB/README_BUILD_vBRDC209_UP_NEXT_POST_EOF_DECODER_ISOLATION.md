# Debrid Channels vBRDC209 — Up Next Post-EOF Decoder Isolation

Release: vBRDC209
Version: 1.0.912
Build: 912

Built directly from vBRDC208.

## Primary correction
Physical Apple TV testing still showed the final portion of TV episodes glitching/freezing visually while audio continued. The deeper audit found two independent forms of end-window work amplification:

1. Up Next metadata/source preparation ran through `CatalogStore` (`@MainActor`) while the outgoing episode was still playing. Provider JSON decoding, ranking and preflights could return to MainActor during the final scenes.
2. The ordinary five-second Resume checkpoint declared titles complete at >=95%, repeatedly triggering Trakt completion/cloud refresh and Resume cache clearing before real EOF.

## vBRDC209 behavior
- Full Up Next identity/provider/source work is forbidden while active video is playing.
- Natural EOF is a zero-work latch.
- A 300 ms post-EOF decoder-settle lane owns Trakt completion, Resume clearing, Now Playing stopped-state publication and next-episode resolution.
- EOF cancels the Up Next watchdog so it cannot bypass the settle lane.
- Resuming playback cancels every in-flight Up Next task and hides any prepared Up Next surface.
- Up Next artwork no longer forces visible playback publication and is downsampled to 512px.
- Five-second Resume checkpoints no longer call Trakt completion at 95%.
- Ordinary completion-window Resume checkpoints no longer enqueue repeated cache clears/writes.
- Legacy non-KS periodic clocks no longer mark completion at 95% either.

## Preserved
vBRDC208 Episode Alerts, system Now Playing/Home Assistant integration, ATVLoadly icon compatibility, Live TV guide recovery, Trakt identity/shelf hardening, catalog boundaries, and prior VOD handoff/failover protections are retained.
