# App-Wide Regression Locks — vBRDC195

1. Build lineage remains packaged vBRDC194 -> vBRDC195 only.
2. No end user is asked for a Trakt Client ID or Client Secret; Connect / Sync / Disconnect remains the consumer flow.
3. Trakt catalog shelves appear only for connected accounts and only on Movies / TV Shows, not Home.
4. Trakt lists provide identity/order only; all cards, artwork, details, Find Links and playback continue through the existing Debrid Channels pipeline.
5. Do not hotlink Trakt image CDN URLs. Reuse Debrid Channels artwork or bounded TMDB enrichment.
6. Do not persist Trakt account shelves into the protected official catalog snapshot, compact launch cache, or built-in All-in-One row customizer.
7. Disconnecting Trakt removes all account shelves and cached personal title status.
8. Spotlight Hub remains optional and shows title-specific Trakt status + Related on Trakt when connected; it does not become a second full catalog browser.
9. Related on Trakt takes visual priority over the older community-review text to keep Spotlight Hub compact.
10. Existing local resume remains active; Trakt remains an optional cross-device synchronization layer.
11. Live TV Episode Alerts remain enabled.
12. Production & Ratings themed logo remains an independent setting.
13. Player Engine chip remains absent from the VOD rail.
14. vBRDC189 fixed/even VOD control rail and full Video Fit system remain unchanged.
15. Playback catalog themed-logo identity publication from vBRDC187 remains intact.
16. vBRDC188 approved app icon assets remain unchanged.
17. No Trakt application secret may be printed in UI, status strings, validation logs, readmes or audit docs.
