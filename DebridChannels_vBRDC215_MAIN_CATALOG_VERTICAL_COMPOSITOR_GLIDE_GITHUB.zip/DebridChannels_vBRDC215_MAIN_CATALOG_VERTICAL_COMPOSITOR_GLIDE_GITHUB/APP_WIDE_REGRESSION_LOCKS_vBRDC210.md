# App-wide Regression Locks — vBRDC210

These are cross-feature invariants. Future performance work must not weaken them.

1. Full-screen VOD and Live TV are both eligible system media owners.
2. MPRemoteCommandCenter Play/Pause/Toggle handlers must remain installed and enabled for the active full-screen playback UUID.
3. Remote commands must be enabled before non-mixable AVAudioSession playback activation.
4. VOD and Live TV Now Playing must publish video media type, elapsed time, playback rate, and service/content identity.
5. Live TV must claim media-button ownership before decoder mount and reassert it after first frame/audio-route establishment.
6. Bluetooth/system Play/Pause must route directly to the active player and must not pass through the generic 440 ms UI debounce.
7. Trakt manual resync must restore persisted OAuth/Keychain state before requesting progress.
8. Cold Resume projection must not depend on visiting another catalog tab.
9. Cold Resume poster, landscape, and themed-logo repair must be bounded and must cancel for full-screen playback.
10. Playback-derived Resume re-projection must be able to skip duplicate account-network refresh.
11. Episode Alert discovery/presentation remains supported during VOD and Live TV.
12. vBRDC209 natural-EOF decoder isolation remains intact; no early Up Next provider fan-out while video is actively rendering.
13. Normal Resume checkpoints must not reintroduce >=95% completion semantics or repeated Trakt completion.
14. Main Movies/TV Shows type boundaries remain distinct; playback popup catalogs stay independently filtered.
15. Force Guide must retain bounded self-healing retry-until-authoritative behavior.
16. ATVLoadly compatibility alias must remain `Resources/AppIcon-1280x768.png`; canonical layered tvOS assets remain unchanged.
17. No synchronous `UserDefaults.synchronize()` calls.
