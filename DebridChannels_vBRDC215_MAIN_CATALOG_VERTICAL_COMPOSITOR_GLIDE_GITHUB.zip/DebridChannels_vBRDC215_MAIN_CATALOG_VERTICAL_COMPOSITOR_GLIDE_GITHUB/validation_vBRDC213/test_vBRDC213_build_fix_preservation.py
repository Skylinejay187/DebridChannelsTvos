from pathlib import Path
import plistlib
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
TRAKT = (ROOT / 'Sources/TraktSyncManager.swift').read_text()
TRAKT_CATALOG = (ROOT / 'Sources/TraktCatalogService.swift').read_text()
PROJECT = (ROOT / 'project.yml').read_text()


def test_release_identity_is_one_coherent_v213_transaction():
    assert PROJECT.count('MARKETING_VERSION: 1.0.916') == 2
    assert PROJECT.count('CURRENT_PROJECT_VERSION: 916') == 2
    for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
        with (ROOT / rel).open('rb') as f:
            p = plistlib.load(f)
        assert p['CFBundleShortVersionString'] == '1.0.916'
        assert str(p['CFBundleVersion']) == '916'
        assert p['DebridChannelsReleaseID'] == 'vBRDC213'
    assert 'private static let appVersion = "1.0.916"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC213 TraktCatalog' in TRAKT_CATALOG
    assert 'DebridChannels-tvOS/916 InstantSourceFanout' in STORE
    assert 'DebridChannels-tvOS/916 InstantCatalogManifest' in STORE
    assert 'DebridChannels-tvOS/916 InstantCatalogBatchRows' in STORE
    assert 'DebridChannels-tvOS/916 InstantCatalogFanout' in STORE


def test_no_stale_v211_or_v212_release_identity_literals_remain():
    production = '\n'.join([PROJECT, APP, STORE, TRAKT, TRAKT_CATALOG,
                            (ROOT / 'Sources/Info.plist').read_text(),
                            (ROOT / 'TopShelfExtension/Info.plist').read_text()])
    for stale in (
        'MARKETING_VERSION: 1.0.915', 'CURRENT_PROJECT_VERSION: 915',
        '<string>1.0.915</string>', '<string>915</string>',
        '<string>vBRDC212</string>', 'DebridChannels-tvOS/915 Instant',
        'DebridChannels-tvOS/vBRDC212 TraktCatalog',
        'private static let appVersion = "1.0.915"',
        '<string>1.0.914</string>', '<string>914</string>',
        '<string>vBRDC211</string>', 'DebridChannels-tvOS/vBRDC211 TraktCatalog',
        'private static let appVersion = "1.0.914"',
    ):
        assert stale not in production


def test_v211_system_media_anchor_and_remote_ownership_are_preserved():
    for marker in (
        'let session = MPNowPlayingSession(players: [player])',
        'session.automaticallyPublishesNowPlayingInfo = false',
        'session.nowPlayingInfoCenter.nowPlayingInfo = info',
        'centers.append(session.remoteCommandCenter)',
        'centers.append(MPRemoteCommandCenter.shared())',
        'session.becomeActiveIfPossible',
        'debridSystemMediaRemoteLastEventV2',
    ):
        assert marker in APP
    assert (ROOT / 'Resources/DebridSystemMediaAnchor.m4a').exists()
    assert '- path: Resources/DebridSystemMediaAnchor.m4a' in PROJECT


def test_v211_trakt_restore_and_exact_one_resync_contract_are_preserved():
    for marker in (
        'func manualResyncFromSettings() async -> Bool',
        '✓ Trakt resync complete •',
        'restorePersistedConnectionIfNeeded()',
        'playbackAlreadySynchronized: Bool = false',
        'skipPlaybackRefresh: playbackAlreadySynchronized',
    ):
        assert marker in (TRAKT + STORE + APP)
    restore = APP[APP.index('let recoveredPersistedTrakt = TraktSyncManager.shared.restorePersistedConnectionIfNeeded()'):]
    restore = restore[:restore.index('private func', 1)] if 'private func' in restore[1:] else restore
    assert 'let resynced = await TraktSyncManager.shared.manualResyncFromSettings()' in restore
    assert 'playbackAlreadySynchronized: true' in restore


def test_v212_fail_fast_source_session_is_preserved():
    block = STORE[STORE.index('private static func makeSourceIntelligenceURLSession()'):STORE.index('private func rotateSourceIntelligenceURLSession()')]
    assert 'configuration.timeoutIntervalForRequest = 8' in block
    assert 'configuration.timeoutIntervalForResource = 15' in block
    assert 'configuration.waitsForConnectivity = false' in block
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in block
    assert 'configuration.timeoutIntervalForRequest = 35' not in block


def test_v212_sliding_provider_fanout_and_incremental_first_result_are_preserved():
    block = STORE[STORE.index('let sourceManifests = prioritizedManifestURLsWithMetadataFallback()'):STORE.index('var xtreamLinks: [StreamLink]')]
    assert 'let maximumConcurrentProviders = min(12, max(1, sourceManifests.count))' in block
    assert 'withTaskGroup(of: SourceAddonScanResult?.self)' in block
    assert 'while let optionalResult = await group.next()' in block
    assert 'nextProviderIndex < sourceManifests.count' in block
    assert 'Showing results now while' in block
    assert 'for chunkStart in stride' not in block
    ui = APP[APP.index('.onChange(of: store.streamLinks.count)'):APP.index('.onChange(of: sourcePanelVisible)')]
    assert 'count > 0, sourcePanelVisible, isFindingLinks' in ui
    assert 'focus = .stream(0)' in ui


def test_v212_parallel_identity_hydration_and_bounded_recovery_are_preserved():
    source_block = STORE[STORE.index('func findStreams(for item: MediaItem'):STORE.index('let additiveFebBoxAllowed')]
    assert 'let inSResolverTask: Task<MediaItem, Never>?' in source_block
    assert 'activeInSResolverTask = inSResolverTask' in source_block
    recovery = STORE[STORE.index('func findStreamsForcePopulated'):STORE.index('func cancelCurrentStreamSearch')]
    assert 'for candidate in candidates.prefix(3)' in recovery
    assert 'candidates.prefix(6)' not in recovery
    ui = APP[APP.index('// vBRDC212: race providers immediately with the identity already on screen.'):]
    ui = ui[:ui.index('case .episodes:')]
    assert ui.index('let resolverTask = Task') < ui.index('let fastResult = await store.findStreamsForcePopulated')
    assert 'resolverTask.cancel()' in ui


def test_v212_manifest_capability_and_media_type_filtering_are_preserved():
    cap = STORE[STORE.index('private func sourceManifestAllowsStreamRequest'):STORE.index('private func scanSingleSourceAddonProvider')]
    assert 'resource.types' in cap and 'resource.idPrefixes' in cap
    assert 'manifest.types' in cap and 'manifest.idPrefixes' in cap
    types = STORE[STORE.index('private func expandedStreamTypes'):STORE.index('private func parsedQuality')]
    assert 'never cross-query movie + series endpoints' in types
    assert 'add("movie")' not in types
    assert 'add("series")' not in types


def test_v212_short_memory_caches_are_preserved_and_memory_pressure_clears_them():
    for marker in (
        'sourceLinkMemoryCacheTTL: TimeInterval = 240',
        'sourceLinkMemoryCacheLimit = 48',
        'sourceManifestMemoryCacheTTL: TimeInterval = 900',
        'sourceManifestMemoryCacheLimit = 32',
    ):
        assert marker in STORE
    memory = STORE[STORE.index('func handlePhase7MemoryPressure'):STORE.index('private static func makeCatalogFastURLSession')]
    assert 'sourceLinkMemoryCache.removeAll' in memory
    assert 'sourceManifestMemoryCache.removeAll' in memory


def test_v212_first_source_autoplay_is_preserved():
    block = STORE[STORE.index('func playFirstDirectStream(for item: MediaItem)'):]
    block = block[:9000]
    assert 'let searchTask = Task' in block
    assert 'let earlyVisible = streamLinks' in block
    assert 'if let direct = earlyDirect.first' in block
    assert 'Fast source ready.' in block
    assert 'startPlayback(' in block


def test_v212_catalog_force_load_is_preserved():
    assert 'catalogRecoveryRetryDelays: [TimeInterval] = [1, 3, 8, 20, 45, 90, 180]' in STORE
    load = STORE[STORE.index('func loadAllManifests(forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false)'):]
    assert 'urgent reload superseded active catalog generation' in load
    assert 'catalogLifecycleGeneration &+= 1' in load
    assert 'if forceOfficialRefresh || !hasVisibleCatalogRows' in load
    assert 'publicationPermitted = true' in load
    reload = STORE[STORE.index('func reloadDebridChannelsCatalogs()'):STORE.index('func handlePhase7MemoryPressure')]
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: false)' in reload
    assert 'Completing long shelves in the background' in reload
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: true)' in reload


def test_v212_catalog_network_parallelism_is_preserved():
    session = STORE[STORE.index('private static func makeCatalogFastURLSession()'):STORE.index('private static func makeSourceIntelligenceURLSession()')]
    assert 'configuration.waitsForConnectivity = false' in session
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in session
    fetch = STORE[STORE.index('private func fetchCatalogData'):STORE.index('private func safeCatalogFailureDescription')]
    assert 'Self.catalogFastURLSession.data(for: request)' in fetch
    fallback = STORE[STORE.index('// vBRDC212: if the batch endpoint is unavailable'):]
    fallback = fallback[:fallback.index('let repairedRows = isOfficialRequest')]
    assert 'fallbackConcurrency = min(isOfficialRequest ? 12 : 6' in fallback
    assert 'fetchCatalogData(request, attempts: 1)' in fallback


def test_no_merge_conflict_markers_in_changed_runtime_files():
    for rel in ('Sources/CatalogStore.swift', 'Sources/DebridChannelsTVOSApp.swift',
                'Sources/TraktSyncManager.swift', 'Sources/TraktCatalogService.swift', 'project.yml'):
        text = (ROOT / rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
