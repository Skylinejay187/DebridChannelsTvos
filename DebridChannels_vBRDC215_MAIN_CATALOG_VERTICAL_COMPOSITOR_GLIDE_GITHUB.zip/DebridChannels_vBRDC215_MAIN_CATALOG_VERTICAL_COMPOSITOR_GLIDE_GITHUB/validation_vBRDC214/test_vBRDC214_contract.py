from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()

def test_universal_addon_fanout():
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat

def test_now_playing_dual_publish():
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in app
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in app

def test_shared_remote_first():
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app

def test_anchor_not_paused_on_real_pause():
    block=app[app.index('private func synchronizeAnchorPlaybackOnMain'):app.index('private func requestSystemSessionActivationOnMain')]
    assert 'player.pause()' not in block
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in block

def test_main_catalog_settle():
    assert 'verticalCatalogNavigationSettling = true' in app
    assert '160_000_000' in app
    assert '!verticalCatalogNavigationSettling' in app

def test_versions():
    assert 'MARKETING_VERSION: 1.0.917' in proj
    assert 'CURRENT_PROJECT_VERSION: 917' in proj
