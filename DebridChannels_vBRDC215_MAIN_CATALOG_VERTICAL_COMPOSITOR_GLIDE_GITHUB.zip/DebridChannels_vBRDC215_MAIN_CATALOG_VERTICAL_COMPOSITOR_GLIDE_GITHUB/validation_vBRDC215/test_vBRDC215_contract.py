from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()
trakt=(r/'Sources/TraktSyncManager.swift').read_text()
traktcat=(r/'Sources/TraktCatalogService.swift').read_text()


def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.918' in proj
    assert 'CURRENT_PROJECT_VERSION: 918' in proj
    assert '<string>1.0.918</string>' in (r/'Sources/Info.plist').read_text()
    assert '<string>918</string>' in (r/'Sources/Info.plist').read_text()
    assert '<string>vBRDC215</string>' in (r/'Sources/Info.plist').read_text()
    assert '<string>1.0.918</string>' in (r/'TopShelfExtension/Info.plist').read_text()
    assert '<string>918</string>' in (r/'TopShelfExtension/Info.plist').read_text()
    assert '<string>vBRDC215</string>' in (r/'TopShelfExtension/Info.plist').read_text()
    assert 'private static let appVersion = "1.0.918"' in trakt
    assert 'DebridChannels-tvOS/vBRDC215 TraktCatalog' in traktcat


def test_main_vertical_is_compositor_only_single_tree():
    assert 'private struct MainCatalogVerticalRowArrivalModifier: ViewModifier' in app
    assert '.offset(y: signedDirection * 32 * remaining)' in app
    assert '.opacity(0.94 + (0.06 * Double(clampedPhase)))' in app
    assert 'verticalCatalogRowMotionPhase: CGFloat = 1' in app
    assert 'verticalCatalogRowMotionGeneration: UInt64 = 0' in app
    assert 'phase: playbackBrowseMode ? 1 : verticalCatalogRowMotionPhase' in app
    # The historical no-peek persistent-rail locks must remain: no outgoing second row tree.
    rail=app[app.index('private func catalogRail('):app.index('@ViewBuilder\n    private func nextRowTitle')]
    assert '.transition(.identity)' in rail
    assert '.animation(nil, value: activeRowIndex)' in rail


def test_vertical_row_swap_is_atomic_then_animated_next_turn():
    block=app[app.index('private func moveQuickPanelRow(_ delta: Int)'):app.index('private func scheduleFirstCardRowEntryFocus')]
    assert 'transaction.disablesAnimations = true' in block
    assert 'verticalCatalogRowMotionPhase = 0' in block
    assert 'activeRowIndex = next' in block
    assert 'focusedRow = next' in block
    assert 'DispatchQueue.main.async' in block
    assert 'withAnimation(.easeOut(duration: 0.24))' in block
    assert 'verticalCatalogRowMotionPhase = 1' in block
    assert '300_000_000' in block
    assert 'motionGeneration == verticalCatalogRowMotionGeneration' in block
    assert 'accessibilityReduceMotion' in block


def test_vertical_frame_budget_matches_motion():
    nav=app[app.index('private func registerCatalogNavigation'):app.index('private func handleQuickPanelMove')]
    assert 'case .up, .down:' in nav
    assert 'settleWindow = 0.30' in nav


def test_v214_universal_stremio_fanout_preserved():
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat
    assert 'DebridChannels-tvOS/918 UniversalInstantSourceFanout' in cat


def test_v214_system_media_preserved():
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in app
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in app
    block=app[app.index('private func synchronizeAnchorPlaybackOnMain'):app.index('private func requestSystemSessionActivationOnMain')]
    assert 'player.pause()' not in block
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in block


def test_v211_trakt_restore_resync_contract_preserved():
    assert 'manualResyncFromSettings() async -> Bool' in trakt
    assert 'restorePersistedConnectionIfNeeded()' in trakt
    assert '✓ Trakt resync complete' in trakt


def test_v212_catalog_force_load_contract_preserved():
    assert 'forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false' in cat
    assert 'catalogLifecycleGeneration &+= 1' in cat
    assert '[1, 3, 8, 20, 45, 90, 180]' in cat


def test_v212_fail_fast_source_and_memory_caches_preserved():
    session=cat[cat.index('private static func makeSourceIntelligenceURLSession()'):cat.index('private func rotateSourceIntelligenceURLSession()')]
    assert 'configuration.timeoutIntervalForRequest = 8' in session
    assert 'configuration.timeoutIntervalForResource = 15' in session
    assert 'configuration.waitsForConnectivity = false' in session
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in session
    for marker in (
        'sourceLinkMemoryCacheTTL: TimeInterval = 240',
        'sourceLinkMemoryCacheLimit = 48',
        'sourceManifestMemoryCacheTTL: TimeInterval = 900',
        'sourceManifestMemoryCacheLimit = 32',
    ):
        assert marker in cat


def test_v212_first_source_autoplay_and_parallel_identity_preserved():
    play=cat[cat.index('func playFirstDirectStream(for item: MediaItem)'):]
    assert 'let searchTask = Task' in play[:10000]
    assert 'let earlyVisible = streamLinks' in play[:10000]
    assert 'if let direct = earlyDirect.first' in play[:10000]
    assert 'Fast source ready.' in play[:10000]
    source=cat[cat.index('func findStreams(for item: MediaItem'):cat.index('let additiveFebBoxAllowed')]
    assert 'let inSResolverTask: Task<MediaItem, Never>?' in source
    assert 'activeInSResolverTask = inSResolverTask' in source


def test_v212_catalog_fast_session_and_reload_preserved():
    session=cat[cat.index('private static func makeCatalogFastURLSession()'):cat.index('private static func makeSourceIntelligenceURLSession()')]
    assert 'configuration.waitsForConnectivity = false' in session
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in session
    assert 'configuration.timeoutIntervalForRequest = 8' in session
    assert 'configuration.timeoutIntervalForResource = 20' in session
    reload=cat[cat.index('func reloadDebridChannelsCatalogs()'):cat.index('func handlePhase7MemoryPressure')]
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: false)' in reload
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: true)' in reload


def test_playback_browse_vertical_path_is_not_animated_by_v215():
    quick=app[app.index('private func catalogQuickPanel'):app.index('@ViewBuilder\n    private func activeCatalogRowPager')]
    assert 'phase: playbackBrowseMode ? 1 : verticalCatalogRowMotionPhase' in quick
    move=app[app.index('private func moveQuickPanelRow(_ delta: Int)'):app.index('private func scheduleFirstCardRowEntryFocus')]
    assert move.count('if !playbackBrowseMode') >= 3


def test_no_merge_conflict_markers_in_changed_runtime_files():
    for rel in ('Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/TraktSyncManager.swift','Sources/TraktCatalogService.swift','project.yml'):
        text=(r/rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
