# App-wide regression locks — vBRDC200

1. Playback UNITY Home / Movies / TV Shows catalog type boundaries from vBRDC199 remain unchanged.
2. A VOD-to-VOD replacement (automatic source failover, Next Episode, internal source/title switch) must never be treated as a true player exit.
3. Internal VOD handoff teardown must not synchronously flush resume persistence or publish a Trakt pause/catalog shelf rebuild while the incoming decoder starts.
4. Durable resume persistence remains required on a true user exit and app background lifecycle edge.
5. Playback-derived catalog shelves recover when the VOD-exclusive gate actually ends, not during an internal VOD handoff.
6. The dedicated Up Next watchdog is the only recurring owner of Up Next source/presentation/autoplay timing.
7. Early Up Next source-provider fan-out must respect KSPlayer playable headroom; late/EOF fallback must remain available for autoplay reliability.
8. Next-episode Alternate Audio discovery must not run while the current episode is actively decoding.
9. Next-episode decorative Production metadata and intro prefetch must not run before natural EOF.
10. Hidden VOD Production metadata completion must not publish into SwiftUI until VOD chrome/panels are visible.
11. Episode Alert network scans defer during VOD-exclusive playback; queued alert presentation remains allowed and Live TV alert scanning remains supported.
12. vBRDC199 manifest-authoritative movie/show typing, Trakt row naming/order repair, and icon assets remain preserved.
