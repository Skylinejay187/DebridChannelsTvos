# Debrid Channels vBRDC194 — Shared Trakt App Authorization

Release: vBRDC194
Marketing version: 1.0.897
Apple build: 897
Donor/source of truth: packaged vBRDC193 only

## Changes
- Debrid Channels now owns one shared Trakt API application identity.
- Removed end-user Trakt Client ID / Client Secret text fields and the Save Credentials action.
- Users now only use Connect Trakt, Sync Resume Now, and Disconnect Trakt.
- Device Code flow remains the tvOS account-link path.
- Existing local resume remains the instant/offline fallback; Trakt remains the cross-device synchronization layer.
- OAuth access/refresh tokens remain in Keychain.
- No Trakt app secret is printed in settings, validation output, build notes, or status text.

## Preserved
- vBRDC193 Spotlight Hub redesign and Trakt Community Pulse.
- Live TV episode alerts.
- Production & Ratings themed-logo option.
- vBRDC189 fixed/even VOD control rail and Video Fit modes.
- Player Engine chip remains removed.
- vBRDC188 approved icon assets remain unchanged.
