# App-wide regression locks — vBRDC198

1. Trakt movie shelves must never publish into the TV Shows branch.
2. Trakt show shelves must never publish into the Movies branch.
3. Every Trakt row must pass the CatalogStore sanitizer and the visual branch filter before rendering.
4. When Trakt is connected, Trakt account shelves are the default top rows before ordinary catalogs.
5. The vBRDC198 top-order repair is one-time. After it runs, explicit Customize All-in-One ordering is authoritative and must not be overwritten on refresh/reconnect.
6. Connected Trakt rows stay out of Home.
7. Native Debrid Channels Continue Watching stays available as a separate local/offline resume row.
8. Trakt cloud resume continues to materialize into native Debrid Channels resume/progress state; no fixed resume timestamp is permitted.
9. Sync Resume duplicate-key crash fix from vBRDC197 must remain intact.
10. Existing VOD rail, Video Fit, Playback UNITY, Live TV Episode Alerts, Production & Ratings themed logo, and approved icon remain unchanged.
