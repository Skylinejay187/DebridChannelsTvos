# Debrid Channels vBRDC196 — Catalog State + Trakt History + Resume Hardening

Release: vBRDC196
Marketing version: 1.0.899
Apple build: 899
Donor/source of truth: packaged vBRDC195 only

## Catalog mode/state hardening
- All-in-One ON/OFF now invalidates the previous catalog-load generation immediately, so a stale request cannot republish the old mode after the toggle changes.
- Official All-in-One, external Stremio catalogs, Trakt shelves, and local Continue Watching now keep separate cache ownership.
- External mode has its own last-known-good fast-launch cache. Toggling modes no longer makes one mode evict the other's cached rows.
- Row customization applies against already loaded rows immediately and no longer forces an unnecessary full catalog network reload.

## Customize All-in-One
- The customizer now includes built-in rows, the local Debrid Channels Continue Watching row, and all Trakt rows.
- Each customizable row supports On/Off, Move to Top, Move Up, and Move Down.
- Trakt/account rows remain outside the protected official snapshot even though they participate in user-visible ordering.

## Trakt catalog shelves
When Trakt is connected and a shelf has usable results, Movies and TV Shows can independently expose:
- Continue Watching • Trakt
- Watch History • Trakt
- Trakt Watchlist
- Trakt Favorites
- Recommended for You • Trakt
- Trending on Trakt
- Popular on Trakt
- Anticipated on Trakt

Movies and TV Shows are hard-separated by row identity and media type before publication. A movie cannot publish into a Trakt TV row and a series cannot publish into a Trakt movie row.

## Trakt stability / post-playback visibility
- Trakt shelves keep a separate last-known-good cache so a partial/temporary endpoint response cannot make the entire account layer blink away.
- The Trakt shelf refresh TTL is shortened and post-playback refresh is ordered after the pause scrobble/cloud checkpoint is accepted.
- A forced playback-progress refresh waits for an already-running refresh instead of racing past it.
- Continue Watching uses the same authoritative Trakt cloud-resume state as cross-device Resume.

## Debrid Channels Continue Watching / resume persistence
- A native Continue Watching row is synthesized from the local resume cache and is available without waiting on Trakt/network refresh.
- Resume entries now retain media/provider IDs so Continue Watching cards can recover exact identity after relaunch.
- Resume persistence now has two durable copies: Application Support plus a UserDefaults shadow copy. Startup chooses the newest valid payload and repairs the older copy.
- Pause/background/dismissal lifecycle edges make a synchronous durable checkpoint so the latest valid progress does not disappear when tvOS terminates the process.
- Local resume remains the instant/offline fallback; Trakt remains the cross-device synchronization layer.

## Preserved
- Shared Debrid Channels Trakt application authorization and consumer Connect / Sync / Disconnect flow.
- Spotlight Hub Trakt integration.
- Live TV Episode Alerts.
- Independent Production & Ratings themed-logo setting.
- vBRDC189 fixed/even VOD rail and full Video Fit system.
- Player Engine chip remains removed.
- Playback UNITY catalogs and playback themed-logo identity fixes.
- vBRDC188 approved icon assets unchanged.

## Validation boundary
GitHub Actions/Xcode with the tvOS SDK remains the authoritative compile. Linux validation covers Swift parsing, metadata/project synchronization, source inclusion, static regression checks, icon byte comparison and ZIP integrity.
