# DebridChannels vBRDC203

Version **1.0.906**, build **906**. Built only from the packaged vBRDC202 source.

This release hardens four user-visible areas without redesigning the UI: restored Trakt account identity, themed logos for Trakt/Resume account rows, self-healing Live TV/guide loading, and app-icon compatibility for IPA/sideload browsers. It also moves persisted Live TV guide decoding off MainActor and removes synchronous UserDefaults flushes from app sources.

Live TV recovery is intentionally persistent but bounded: while the Live TV surface is active and a provider is configured, incomplete or missing current guide coverage retries after 10s, 30s, 60s, 120s, and then every 300s. It pauses when Live TV is no longer active or VOD owns playback and re-arms when appropriate. Cached channels/guide remain available during recovery.

Trakt OAuth tokens remain in the Keychain. If a same-device reinstall/profile restore retains the Keychain token but loses the display name, the app verifies the existing session and repopulates the account identity. A truly new device still requires normal Trakt authorization because OAuth refresh tokens are intentionally not copied through the DebridChannels restore profile.
