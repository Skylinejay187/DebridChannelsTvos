# Debrid Channels tvOS v26 Signing Safe

Upload this repository package to GitHub and run **00 Build tvOS IPA From Source ZIP**.

GitHub artifacts are downloaded as a ZIP wrapper. Extract the artifact ZIP first, then upload the `.ipa` inside to Signulous.

Do not upload the GitHub artifact ZIP itself to Signulous.
