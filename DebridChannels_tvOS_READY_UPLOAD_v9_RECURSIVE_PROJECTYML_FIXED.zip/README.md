# Debrid Channels tvOS GitHub Build Repo v9

Upload this repo's files to GitHub, or keep the workflow file in `.github/workflows` and upload `source_zip/DebridChannelsTVOS_Source.zip`.

The workflow recursively extracts ZIPs until it finds `project.yml`, generates the Xcode project with XcodeGen, builds unsigned for tvOS, and uploads an unsigned IPA artifact.
