import SwiftUI
import Foundation

struct MediaItem: Identifiable, Hashable {
    let id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StremioManifest: Decodable {
    var name: String?
    var catalogs: [StremioCatalog]?
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?
}

struct StremioMeta: Decodable {
    var id: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var status: String = "v29 rotational cinema layout loaded. Use Settings to load Cinemeta/Stremio rows."
    @Published var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @Published var selectedTab: AppTab = .home

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func useCinemeta() {
        manifestURL = "https://v3-cinemeta.strem.io/manifest.json"
    }

    func loadCatalogRows() async {
        let typed = manifestURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: typed), !typed.isEmpty else {
            status = "Invalid manifest URL."
            return
        }
        status = "Loading manifest..."
        do {
            let (manifestData, _) = try await URLSession.shared.data(from: url)
            let manifest = try JSONDecoder().decode(StremioManifest.self, from: manifestData)
            let base = typed.replacingOccurrences(of: "/manifest.json", with: "")
            let catalogs = (manifest.catalogs ?? []).prefix(8)
            var builtRows: [MediaRow] = []
            for catalog in catalogs {
                guard let type = catalog.type, let id = catalog.id else { continue }
                guard let catalogURL = URL(string: "\(base)/catalog/\(type)/\(id).json") else { continue }
                do {
                    let (data, _) = try await URLSession.shared.data(from: catalogURL)
                    let response = try JSONDecoder().decode(CatalogResponse.self, from: data)
                    let items = (response.metas ?? []).prefix(24).map { meta in
                        MediaItem(
                            id: meta.id ?? UUID().uuidString,
                            title: meta.name ?? "Untitled",
                            year: Self.firstYear(from: meta.releaseInfo),
                            type: meta.type ?? type,
                            catalog: catalog.name ?? id.capitalized,
                            description: meta.description ?? "No description available yet.",
                            genres: Array((meta.genres ?? ["Movie", "Cinematic"]).prefix(2)),
                            rating: meta.imdbRating ?? "—",
                            posterURL: Self.highest(meta.poster),
                            landscapeURL: Self.highest(meta.background ?? meta.poster),
                            logoURL: Self.highest(meta.logo)
                        )
                    }
                    if !items.isEmpty {
                        builtRows.append(MediaRow(id: "\(type)-\(id)", title: catalog.name ?? id.capitalized, items: items))
                    }
                } catch {
                    continue
                }
            }
            if builtRows.isEmpty {
                status = "No playable catalog rows returned. Demo rows kept."
            } else {
                rows = builtRows
                let manifestName = manifest.name ?? "manifest"
                status = "Loaded \(builtRows.count) Stremio rows from \(manifestName)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo else { return "2026" }
        return String(text.prefix(4))
    }

    static func highest(_ url: String?) -> String? {
        guard var u = url, !u.isEmpty else { return nil }
        u = u.replacingOccurrences(of: "w342", with: "original")
        u = u.replacingOccurrences(of: "w500", with: "original")
        u = u.replacingOccurrences(of: "w780", with: "original")
        return u
    }

    static func demoRows() -> [MediaRow] {
        let items = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "Movie", catalog: "Cinemeta", description: "Centers on a temporary small-town sheriff who uncovers dark mysteries after a local bank robbery.", genres: ["Action", "Crime"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "cave", title: "Apex", year: "2026", type: "movie", catalog: "Popular", description: "An adrenaline junkie enters a hidden cave system and discovers nature is not the only thing out for blood.", genres: ["Adventure", "Thriller"], rating: "Popular", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "redshoe", title: "Red Signal", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators into a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "Blue Fall", year: "2026", type: "movie", catalog: "New", description: "A detective wakes up in a fractured digital city with only one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "suit", title: "The Circle", year: "2026", type: "movie", catalog: "Trending", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "neon", title: "Central Cinema", year: "2026", type: "movie", catalog: "Cinema", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "The Lost Path", year: "2026", type: "movie", catalog: "Adventure", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1800&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "Stormline", year: "2026", type: "movie", catalog: "Thriller", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500.35314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500.35314209-a25ddb2bd429?auto=format&fit=crop&w=1800&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed()))
        ]
    }
}
