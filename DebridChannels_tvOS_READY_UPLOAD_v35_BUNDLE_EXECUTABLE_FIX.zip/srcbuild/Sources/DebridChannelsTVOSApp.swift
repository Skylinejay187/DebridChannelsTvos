import SwiftUI
import AVKit

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case live = "Live TV"
    case movies = "Movies"
    case shows = "Shows"
    case settings = "Settings"
    var id: String { rawValue }
}

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(store) }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore
    var body: some View {
        ZStack {
            switch store.selectedTab {
            case .settings: SettingsScreen()
            case .live: PlaceholderScreen(title: "Live TV", message: "Live TV renderer is preserved for the next wiring phase.")
            case .movies: CinemaHome(filter: "movie")
            case .shows: CinemaHome(filter: "series")
            case .home: CinemaHome(filter: nil)
            }
            TopNavBar()
        }
        .background(Color.black.ignoresSafeArea())
    }
}

struct TopNavBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    var body: some View {
        VStack {
            HStack(spacing: 64) {
                Spacer(minLength: 280)
                ForEach(AppTab.allCases) { tab in
                    Text(tab.rawValue)
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(store.selectedTab == tab ? .orange : .white)
                        .padding(.vertical, 8)
                        .overlay(alignment: .bottom) {
                            Capsule().fill(store.selectedTab == tab ? Color.orange : Color.clear).frame(width: 82, height: 5).offset(y: 8)
                        }
                        .scaleEffect(focusedTab == tab ? 1.08 : 1.0)
                        .focusable(true)
                        .focused($focusedTab, equals: tab)
                        .onTapGesture { withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) { store.selectedTab = tab } }
                }
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 34, weight: .semibold))
                    .foregroundStyle(.white)
                    .padding(.leading, 40)
                Spacer(minLength: 36)
            }
            .padding(.top, 28)
            Spacer()
        }
        .ignoresSafeArea(edges: .top)
    }
}

struct CinemaHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex: Int = 0
    @State private var selectedIndex: Int = 0
    @FocusState private var canvasFocused: Bool

    var activeRows: [MediaRow] {
        if let filter { return store.rows.map { MediaRow(id: $0.id, title: $0.title, items: $0.items.filter { $0.type.lowercased().contains(filter) || filter == "movie" }) }.filter { !$0.items.isEmpty } }
        return store.rows
    }

    var row: MediaRow { activeRows.isEmpty ? CatalogStore.demoRows()[0] : activeRows[min(rowIndex, activeRows.count - 1)] }
    var items: [MediaItem] { row.items.isEmpty ? CatalogStore.demoRows()[0].items : row.items }
    var selected: MediaItem { items[selectedIndex % items.count] }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                RemoteImageFit(url: selected.landscapeURL ?? selected.posterURL)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                    .opacity(0.68)
                    .overlay(LinearGradient(colors: [.black.opacity(0.12), .black.opacity(0.9)], startPoint: .top, endPoint: .bottom))
                    .overlay(LinearGradient(colors: [.black.opacity(0.15), .black.opacity(0.86)], startPoint: .trailing, endPoint: .leading))
                    .ignoresSafeArea()

                HeroInfo(item: selected)
                    .frame(width: 470, alignment: .leading)
                    .position(x: 280, y: 420)

                RotatingCardMatrix(items: items, selectedIndex: $selectedIndex)
                    .frame(width: geo.size.width, height: geo.size.height)

                if activeRows.count > 1 {
                    Text(row.title)
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(.white.opacity(0.5))
                        .position(x: 1650, y: 1010)
                }
            }
            .focusable(true)
            .focused($canvasFocused)
            .onAppear { canvasFocused = true }
            .onMoveCommand { direction in
                switch direction {
                case .right: advance()
                case .left: retreat()
                case .down: nextRow()
                case .up: previousRow()
                default: break
                }
            }
        }
    }

    func advance() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.82)) { selectedIndex = (selectedIndex + 1) % items.count }
    }
    func retreat() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.82)) { selectedIndex = (selectedIndex - 1 + items.count) % items.count }
    }
    func nextRow() {
        guard activeRows.count > 1 else { return }
        withAnimation(.spring(response: 0.55, dampingFraction: 0.84)) {
            rowIndex = min(rowIndex + 1, activeRows.count - 1)
            selectedIndex = 0
        }
    }
    func previousRow() {
        withAnimation(.spring(response: 0.55, dampingFraction: 0.84)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}

struct HeroInfo: View {
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            LogoView(item: item)
                .frame(maxWidth: 410, alignment: .leading)
            HStack(spacing: 14) {
                Text(item.year)
                Text("•")
                Text(item.type.capitalized)
                Text("•")
                Text(item.catalog)
            }
            .font(.system(size: 23, weight: .semibold))
            .foregroundStyle(.white.opacity(0.96))

            HStack(spacing: 14) {
                ForEach(item.genres.prefix(2), id: \.self) { genre in
                    Text(genre).font(.system(size: 17, weight: .bold)).padding(.horizontal, 22).padding(.vertical, 12).background(Capsule().fill(Color.white.opacity(0.09))).overlay(Capsule().stroke(.white.opacity(0.14), lineWidth: 1))
                }
            }
            HStack(spacing: 22) {
                Text("IMDb").font(.system(size: 21, weight: .black)).foregroundStyle(.black).padding(.horizontal, 18).padding(.vertical, 12).background(RoundedRectangle(cornerRadius: 8).fill(.yellow))
                Text(item.rating).font(.system(size: 38, weight: .bold)).foregroundStyle(.white)
            }
            Text(item.description)
                .font(.system(size: 23, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(4)
                .shadow(radius: 6)
                .frame(width: 440, alignment: .leading)
        }
    }
}

struct LogoView: View {
    let item: MediaItem
    @State private var pulse = false
    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 10 ? 54 : 72, weight: .black, design: .rounded))
                    .italic()
                    .foregroundStyle(LinearGradient(colors: [.orange, .red], startPoint: .top, endPoint: .bottom))
            }
        }
        .shadow(color: .orange.opacity(pulse ? 0.8 : 0.35), radius: pulse ? 22 : 8)
        .onAppear { withAnimation(.easeInOut(duration: 1.25).repeatForever(autoreverses: true)) { pulse.toggle() } }
    }
}

struct RotatingCardMatrix: View {
    let items: [MediaItem]
    @Binding var selectedIndex: Int
    @State private var pulse = false

    struct Slot { let x: CGFloat; let y: CGFloat; let w: CGFloat; let h: CGFloat }
    let slots: [Slot] = [
        Slot(x: 315, y: 760, w: 520, h: 305),   // 1 locked hero/focused card
        Slot(x: 820, y: 775, w: 465, h: 285),   // 2
        Slot(x: 1320, y: 775, w: 465, h: 285),  // 3
        Slot(x: 1630, y: 775, w: 365, h: 285),  // 4
        Slot(x: 1320, y: 430, w: 460, h: 270),  // 5
        Slot(x: 1640, y: 430, w: 360, h: 270),  // 6
        Slot(x: 1360, y: 205, w: 390, h: 245),  // 7
        Slot(x: 1665, y: 205, w: 305, h: 245)   // 8
    ]

    var body: some View {
        ZStack {
            ForEach(0..<min(8, items.count), id: \.self) { offset in
                let item = items[(selectedIndex + offset) % items.count]
                let slot = slots[offset]
                MatrixCard(item: item, focused: offset == 0, pulse: pulse)
                    .frame(width: slot.w, height: slot.h)
                    .position(x: slot.x, y: slot.y)
                    .zIndex(offset == 0 ? 10 : Double(8 - offset))
                    .opacity(offset == 0 ? 1.0 : 0.64)
                    .scaleEffect(offset == 0 ? 1.0 : 0.98)
                    .animation(.spring(response: 0.58, dampingFraction: 0.82), value: selectedIndex)
            }
        }
        .onAppear { withAnimation(.easeInOut(duration: 1.05).repeatForever(autoreverses: true)) { pulse.toggle() } }
    }
}

struct MatrixCard: View {
    let item: MediaItem
    let focused: Bool
    let pulse: Bool
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL)
                .clipped()
                .overlay(LinearGradient(colors: [.clear, .black.opacity(focused ? 0.45 : 0.62)], startPoint: .top, endPoint: .bottom))
            if focused {
                VStack(alignment: .leading, spacing: 4) {
                    LogoView(item: item).frame(width: 230, height: 82, alignment: .leading)
                }.padding(36)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(focused ? Color.orange : Color.orange.opacity(0.30), lineWidth: focused ? 4 : 1.2))
        .shadow(color: focused ? .orange.opacity(pulse ? 0.96 : 0.48) : .clear, radius: focused ? (pulse ? 35 : 18) : 0)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @State private var typedURL: String = ""
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text("Settings").font(.system(size: 54, weight: .black)).foregroundStyle(.white)
                Text(store.status).font(.system(size: 26, weight: .semibold)).foregroundStyle(.white.opacity(0.85))
                panel {
                    Text("Catalog / Artwork Wiring").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
                    Text("Load Stremio/Cinemeta rows. Real-Debrid and Torbox are intentionally not wired yet.").font(.system(size: 22, weight: .semibold)).foregroundStyle(.white.opacity(0.7))
                    HStack(spacing: 18) {
                        tvButton("Cinemeta") { store.useCinemeta(); typedURL = store.manifestURL }
                        tvButton("Use Typed URL") { store.manifestURL = typedURL.isEmpty ? store.manifestURL : typedURL }
                        tvButton("Load Catalog Rows") { store.manifestURL = typedURL.isEmpty ? store.manifestURL : typedURL; Task { await store.loadCatalogRows() } }
                        tvButton("Reset Demo") { store.resetDemo() }
                    }
                    TextField(store.manifestURL, text: $typedURL)
                        .font(.system(size: 24, weight: .semibold))
                        .padding(18)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.10)))
                        .foregroundStyle(.white)
                }
                panel {
                    Text("Motion Layout").font(.system(size: 30, weight: .black)).foregroundStyle(.white)
                    Text("v29 uses the fixed left hero slot and rotating right-side queue layout requested.").font(.system(size: 22, weight: .semibold)).foregroundStyle(.white.opacity(0.75))
                }
            }.padding(.top, 140).padding(.horizontal, 80).padding(.bottom, 80)
        }
        .background(Color.black.ignoresSafeArea())
        .onAppear { typedURL = store.manifestURL }
    }

    func panel<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 18) { content() }
            .padding(24)
            .background(RoundedRectangle(cornerRadius: 24).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
    func tvButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) { Text(title).font(.system(size: 22, weight: .bold)).padding(.horizontal, 18).padding(.vertical, 12) }
    }
}

struct PlaceholderScreen: View {
    let title: String
    let message: String
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title).font(.system(size: 72, weight: .black)).foregroundStyle(.white)
            Text(message).font(.system(size: 30, weight: .semibold)).foregroundStyle(.white.opacity(0.75))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .padding(.leading, 90)
        .background(Color.black.ignoresSafeArea())
    }
}
