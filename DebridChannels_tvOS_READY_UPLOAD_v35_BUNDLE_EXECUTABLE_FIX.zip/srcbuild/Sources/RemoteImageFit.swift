import SwiftUI

struct RemoteImageFit: View {
    let url: String?
    var mode: ContentMode = .fill

    var body: some View {
        AsyncImage(url: URL(string: url ?? "")) { phase in
            switch phase {
            case .success(let image):
                image.resizable().aspectRatio(contentMode: mode)
            case .failure:
                placeholder
            case .empty:
                placeholder.overlay(ProgressView().scaleEffect(0.6))
            @unknown default:
                placeholder
            }
        }
    }

    var placeholder: some View {
        LinearGradient(colors: [.black.opacity(0.5), .gray.opacity(0.25)], startPoint: .topLeading, endPoint: .bottomTrailing)
    }
}
