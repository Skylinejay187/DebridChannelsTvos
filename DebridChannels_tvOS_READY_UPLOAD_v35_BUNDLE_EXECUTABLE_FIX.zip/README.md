Debrid Channels tvOS v35

GitHub Actions builds one IPA artifact:
01-UPLOAD-THIS-IPA-v35

Extract the artifact ZIP first. Upload only:
DebridChannelsTVOS_v35_UPLOAD_THIS_IPA.ipa

This build explicitly verifies CFBundleExecutable exists inside the IPA before uploading the artifact.
