# Debrid Channels tvOS v802 - Sports quick panel rewire + compact ticker fix

- Disabled the active independent Sports Center route and rewired Sports to a Harmony-style quick-panel surface over the Live TV backing layout.
- Sports now opens from Live TV, Settings, Movies, Shows, and Favorites without bouncing to Home/Live.
- Sports quick panel owns focus like Movies/Shows while open; closing releases focus back to the normal top menu/Live TV route.
- Sports quick panel uses the existing sports classifier, scores provider, and favorites manager to show a large sports hero, Live & Upcoming rail, favorite teams when available, and sports channel rows.
- Moved the Movies/Shows release ticker and global sports ticker to the shared safe lane aligned to the first Live TV grid card leading edge, not the screen/logo edge.
- Reused `NewEpisodeAlertTheme` for Movies/Shows ticker visuals so it matches the existing episode alert banner theme system.
- Kept the sports ticker on a sports theme, compacted to the same physical footprint as the Movies/Shows ticker.
- Hid both global tickers in Settings, while Sports owns focus, and during quick panels, details, search, onboarding, and playback.
