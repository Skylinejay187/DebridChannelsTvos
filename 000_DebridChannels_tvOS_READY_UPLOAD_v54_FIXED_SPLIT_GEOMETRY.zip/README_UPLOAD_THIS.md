Debrid Channels tvOS v54 fixed split geometry. Left split column is locked from row height; landscape artwork cannot stretch the boxes. Settings marker: Build v54 FIXED SPLIT GEOMETRY ACTIVE.
