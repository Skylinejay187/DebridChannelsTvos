# Debrid Channels tvOS v802 - Top-left ticker + Sports route fix

- Restored Sports top-menu routing by preventing the Live TV backing surface from changing the active route back to Live/Home when Sports opens.
- Sports selection still clears stale live quick-panel/menu focus state and nudges content focus so the active Sports quick-panel surface opens from Live TV, Settings, Movies, Shows, and Favorites.
- Moved the Movies/Shows release ticker and global sports ticker to the shared physical top-left safe lane above the first Live TV grid card.
- Reused `NewEpisodeAlertTheme` for Movies/Shows ticker visuals so it matches the existing episode alert banner theme system.
- Kept the sports ticker on its existing premium sports theme.
- Hid both global tickers in Settings, while Sports owns focus, and during quick panels, details, search, onboarding, and playback.
