# Debrid Channels tvOS v414

Stability rollback from v413 aggressive trailer prefetch to v412-style details-only full-ready trailer playback.

Install with backend v1.8.15.32. This build is intended to fix the v413 regression where trailers loaded slower, some failed to load, and playback still glitched.
