# Debrid Channels tvOS v415

Trailer ready 5-to-10 second stability pass built from v414 rollback.

## Changes
- Details/Media Info prewarm only; no row-focus aggressive prefetch.
- Trailer backend resolve waits are capped so uncached trailers fail cleanly instead of hanging for 27-30 seconds.
- Trailer popup keeps the single AVPlayer layer stability path.
- Bundle marker updated to 1.0.415 / 415.

## Preserved
- KSPlayer/VOD playback unchanged.
- Existing popup styling/animations/focus behavior preserved.
- Persistent backend trailer txt/index cache behavior preserved in matching backend v1.8.15.33.
