# Debrid Channels tvOS v543 Stabilization Recovery

Scope: rollback-style repair after v542 instability.

- Kept Live TV channel favorites separate from top-menu Favorites.
- Top-menu Favorites is movies/shows only.
- Reworked top-menu Favorites cards so saved catalog movies/shows open the existing media detail popup.
- Removed Sports focus-island ownership so UP hands focus back to the global top menu.
- Added Sports on-appear cleanup to prevent stale Live TV quick-panel state from hiding navigation.
- Replaced static Sports ticker text with a visible marquee foundation.
- Did not touch the established popup trailer/cast/link resolver paths.
- IPTV sports auto-routing remains disabled/backlogged.
