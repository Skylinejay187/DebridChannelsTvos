# Debrid Channels tvOS/iOS v1120

## Focused app pass — Smooth navigation sound + Settings toggle

- **Base:** v1119 only
- **Marketing version:** 1.0.648
- **Build:** 648
- **Backend:** no update required; continue using backend v669

## Navigation sound behavior

v1120 adds one short, restrained focus-navigation cue across the app. The cue is driven by UIKit's completed focus-update notification rather than being attached independently to every SwiftUI card, preventing nested views from producing duplicate sounds.

The sound plays only when:

- focus moved from one real item to another;
- the update has a directional focus heading;
- the app is active;
- Navigation Sounds is enabled;
- no full-screen VOD or Live TV player is presented.

Rapid Apple TV remote holds are rate-limited to one cue per 105 milliseconds. The bundled cue is a 60-millisecond, mono, 48 kHz PCM sound with a restrained baked level. No audio-session category is changed, and KSPlayer/AVPlayer are not modified.

## Settings

Settings → Appearance now contains **Navigation Sounds**.

- The option defaults to On.
- Turning it On plays one preview cue.
- Turning it Off immediately silences future navigation cues.
- The preference is included in full-profile backup/restore.
- Restore Stable UI Defaults returns it to On.

## Playback isolation

`VODPlayerScreen` suppresses navigation cues for both VOD and Live TV from presentation through teardown. The existing VOD exclusive gate is also checked as a second safeguard. Playback controls therefore remain silent while video is running.

## Protected systems

The following implementation files remain byte-identical to v1119:

- Automatic Source Failover
- CatalogStore and catalog/source resolution
- KSPlayer surface
- Per-title playback memory
- Resume cache
- Alternate Audio clients
- Source Intelligence
- Trailer service
- Live TV guide cache
- Production & Ratings metadata
- Artwork cache

The main app file changed only for app launch registration, the Appearance toggle, profile persistence, and two player-screen suppression hooks.

## Validation performed

- 47 Swift files parsed successfully.
- Navigation sound contract passed 27/27 checks.
- Both app and Top Shelf plists validated at 1.0.648 / 648.
- Project version and source registration validated.
- Bundled WAV validated as 60 ms, mono, 48 kHz, low amplitude.
- Thirteen protected implementation files remained byte-identical to v1119.
- Complete baseline comparison, package hashes, clean extraction comparison, and ZIP CRC verification are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required to judge the sound's perceived volume and cadence before Phase 8.
