import Foundation
import UIKit
import AVFoundation
import QuartzCore

/// One restrained navigation cue for genuine directional focus changes.
///
/// The manager listens to UIKit's process-wide focus update notification instead
/// of attaching audio work to every SwiftUI card. This keeps the feature isolated,
/// avoids duplicate sounds when nested focus states update, and lets playback
/// screens suppress the cue without touching KSPlayer or AVPlayer.
@MainActor
final class NavigationSoundManager: NSObject {
    static let shared = NavigationSoundManager()
    static let enabledDefaultsKey = "navigationSoundEffectsEnabled"

    private var focusObserver: NSObjectProtocol?
    private var player: AVAudioPlayer?
    private var lastPlayedAt: CFTimeInterval = 0
    private var playbackSuppressed = false
    private let minimumInterval: CFTimeInterval = 0.105

    private override init() {
        super.init()
    }

    static var isEnabled: Bool {
        let defaults = UserDefaults.standard
        guard defaults.object(forKey: enabledDefaultsKey) != nil else { return true }
        return defaults.bool(forKey: enabledDefaultsKey)
    }

    func start() {
        guard focusObserver == nil else { return }
        preparePlayer()
        focusObserver = NotificationCenter.default.addObserver(
            forName: UIFocusSystem.didUpdateNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            Task { @MainActor in
                self?.handleFocusUpdate(notification)
            }
        }
    }

    func setPlaybackSuppressed(_ suppressed: Bool) {
        playbackSuppressed = suppressed
    }

    func previewIfEnabled() {
        guard Self.isEnabled else { return }
        play(force: true)
    }

    private func handleFocusUpdate(_ notification: Notification) {
        guard Self.isEnabled,
              !playbackSuppressed,
              !VODExclusivePlaybackGate.isActive,
              UIApplication.shared.applicationState == .active,
              let context = notification.userInfo?[UIFocusSystem.focusUpdateContextUserInfoKey] as? UIFocusUpdateContext,
              context.previouslyFocusedItem != nil,
              context.nextFocusedItem != nil,
              !context.focusHeading.isEmpty else { return }
        play(force: false)
    }

    private func preparePlayer() {
        guard player == nil,
              let url = Bundle.main.url(forResource: "NavigationFocusSoftTick", withExtension: "wav") else { return }
        do {
            let nextPlayer = try AVAudioPlayer(contentsOf: url)
            nextPlayer.volume = 0.72
            nextPlayer.numberOfLoops = 0
            nextPlayer.prepareToPlay()
            player = nextPlayer
        } catch {
            print("[NavigationSound][v1120] unable to prepare focus cue: \(error.localizedDescription)")
        }
    }

    private func play(force: Bool) {
        let now = CACurrentMediaTime()
        if !force, now - lastPlayedAt < minimumInterval { return }
        if player == nil { preparePlayer() }
        guard let player else { return }
        lastPlayedAt = now
        player.currentTime = 0
        player.play()
    }
}
