# vBRDC322 — Phase 4 EPG / Gracenote Reliability Re-Core
Version 1.0.1024 (1024)

Phase 4 begins with the explicitly requested EPG/Gracenote reliability work.

- Last-known-good lineup and guide remain visible while refresh/recovery is in flight.
- A partial/failed XMLTV/Gracenote response may not replace a healthier visible snapshot.
- Guide health is independent of lineup health and provider TTL.
- Recovery is allowed to continue at low frequency while the app is active on Home/Movies/Shows;
  it does not require the heavyweight Live TV Grid/Guide to remain mounted.
- Retry bookkeeping no longer republishes status text on every attempt.
- On return to Live TV after recovery, retained logo/artwork requests are resumed and the visible
  artwork corridor is force-rehydrated.
- Existing generation checks prevent stale post-sleep/provider tasks from publishing over newer data.
- Existing durable disk snapshots remain the cold-start source of truth until fresher healthy guide data wins.
- UNITY, full playback, trailers, and the Phase 2/3 catalog/artwork fixes are preserved.
