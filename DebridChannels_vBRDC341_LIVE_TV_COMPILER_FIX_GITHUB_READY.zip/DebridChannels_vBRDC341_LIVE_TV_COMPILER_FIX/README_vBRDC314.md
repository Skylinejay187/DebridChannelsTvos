# vBRDC314 — Nuvio-Inspired Performance Re-Core Phase 1
Version: 1.0.1016 (1016)

This build starts the requested background architecture re-core while preserving Signal's visible features and playback design.

## What changed

- Catalog focused previews now use one application-scoped AVPlayer pool instead of constructing a new AVPlayer for each focused identity. The player object stays stable and only the item/surface ownership changes after settled focus.
- Heavy catalog hero/card/image/preview content is physically unmounted while Search, full playback, or an exclusive trailer owns the screen. The outer catalog state shell remains alive so row/focus memory survives.
- Focused catalog card now has an Equatable boundary and is rendered through `.equatable()` so unrelated parent publications do not automatically rebuild that expensive subtree.
- Added deliberate visible/near-visible catalog poster hydration. The active row, neighboring rows, and nearby items warm source bytes independent of focus/remount behavior.
- Catalog vertical focus handoff no longer chases tvOS focus across 0/16/32/64 ms writes. It performs one atomic destination commit, yields once, verifies once, and stops.
- Dynamic wallpaper remains animated during navigation but automatically drops to a low-cost 6 fps/detail-1 navigation budget. Visual Performance settings now affect idle richness without deciding focus smoothness.
- Artwork loading is now direct-first. Signal no longer forces every public poster through the shared backend image proxy before local caching. Existing persistent source-byte, URLCache, and decoded-memory caches remain in place.
- Full VOD and Live TV playback architecture is preserved.
- Existing approved trailer playback behavior is preserved; catalog work now gets out of the way while exclusive trailer playback owns the screen.
- v310/v311 Guide focus behavior and the later performance diagnostics remain preserved.

## Why

Hardware tests showed native tvOS overlays become glitchy mainly while catalog/live preview surfaces are active, while full VOD/Live TV playback is much smoother. The prior code also retained several generations of focus-correction and preview/player ownership logic. This phase removes those conflicts instead of adding more throttles.

## Validation

- `swiftc -frontend -parse` run across all 72 Swift source files: 0 syntax failures.
- `CURRENT_PROJECT_VERSION`: 1016 in both project entries.
- Marketing version: 1.0.1016.

This environment cannot perform the final Xcode/tvOS semantic build; GitHub Actions remains the authoritative build validation.
