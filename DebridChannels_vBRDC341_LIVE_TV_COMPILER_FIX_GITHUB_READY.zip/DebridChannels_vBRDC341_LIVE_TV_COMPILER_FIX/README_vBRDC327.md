# vBRDC327 — App-Wide + Playback Lifecycle Re-Core
Version 1.0.1029 (1029)

Fresh Apple/Nuvio/KSPlayer review plus another Signal source audit.

Performance:
- Search no longer creates a second LiveTVSourceModel/EPG/Gracenote runtime.
- Focused catalog poster leaves no longer observe the giant CatalogStore just to know
  whether Media Information is open; the owner passes one semantic Boolean.
- Protected official catalog snapshot decoding is process-cached to avoid repeated
  multi-megabyte Data/JSON work on CatalogStore's MainActor.
- v325/v326 invalidation, Settings, Top Menu, poster and stall-watchdog work retained.

VOD / lifecycle:
- Bluetooth reassert now reconciles transient MPNowPlayingSession command-center targets.
- Returning from app switcher reasserts the existing Aether/KS Play pulse rather than
  requiring decoder recreation.
- Scene inactivity no longer synchronously flushes resume storage and rebuilds
  playback-derived catalog rows on the MainActor.
- KSPlayer explicitly starts every session at 1.0x via startPlayRate.

Guide:
- RIGHT universally collapses the Guide category rail from category, timeline/channel,
  header or geometry-edge focus. Existing category-row mapping is preserved when relevant.
- Once collapsed, normal native Guide RIGHT navigation is untouched.

Aether Live TV:
- Live join moves from aggressive fastZap/immediate presentation to Aether's standard
  reliability profile with non-immediate join, preserving the existing bounded recovery
  ladder while giving audio/video continuity time to establish.

No intentional visual changes to UNITY, Guide appearance, catalog geometry, Settings,
trailers, wallpapers, Media Information or playback chrome.
