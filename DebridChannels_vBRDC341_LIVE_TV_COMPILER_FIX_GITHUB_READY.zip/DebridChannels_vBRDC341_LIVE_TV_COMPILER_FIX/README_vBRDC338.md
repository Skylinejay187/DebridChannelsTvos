# vBRDC338 — Live TV visual themes and typography

Base: approved vBRDC334 / 1.0.1036. New version: vBRDC338 / 1.0.1040 / build 1040. Rejected v335–v337 implementations are NOT inherited.

## Five theme options
Original Unity (unchanged default), Unity 3D Tilt (focus perspective around Y axis), Floating Cinema (inset artwork and suspended shadow), Immersive Artwork (edge-to-edge artwork and minimal radius), Premium Glass (static translucent pane with inset information panel). The original focused-grid focus ring remains the sole ring and isn't reimplemented. Grid paging, fixed card slots, playback, image loader, guide, and catalog scrolling paths stay intact.

## Independent settings
Information: Standard, Minimal, Detailed synopsis, Now / Next. Typography: Unity Original, SF Pro Light/Regular/Medium/Rounded, Avenir Light/Regular/Medium, Helvetica Neue Light/Regular, Georgia Regular, Cinema Serif. Theme, information and font settings persist through backup/restore and reset to the original values on Reset. Fonts reference platform fonts only; no font files are included.

## Validation limits
Swift parser and ZIP CRC can be tested in this environment; full tvOS Xcode typechecking, Apple TV focus navigation, visual comparisons and FPS must be validated in the actual CI/Apple TV. This is a focused four-theme replacement pilot rather than sixteen more superficial variants.
