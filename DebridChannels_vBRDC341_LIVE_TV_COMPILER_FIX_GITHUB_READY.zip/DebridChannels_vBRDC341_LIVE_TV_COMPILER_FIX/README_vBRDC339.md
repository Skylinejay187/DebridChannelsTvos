# vBRDC339 — Signal icon, Live TV animation and theme corrections

Source: vBRDC338, itself derived from locked approved vBRDC334. v334 catalog-scroll pipeline unchanged; no backend changes.

- Main Apple TV icon uses preferred play/SIGNAL artwork in actual 1280×768 TV tile format and 400×240 small stack. All app icon paths and both layered stacks updated together; no stale front layers.
- Header animation choices: Signal TV, Retro Tube, Signal Play, Signal TV Black, Signal TV Silver, Signal TV Ember. Four supplied artworks are packaged in dedicated assets. Removed former fourteen unused animations from the picker/switch. Dark graphite gradients added to Live lettering.
- Live wallpaper mounted only in active Live TV grid; it is deliberately not keyed on channel focus or grid page and continues on rapid browsing. Unmounts on Guide, other tabs, Search, details, playback, owner actions, and background/inactive app.
- Themes restricted to Original Unity, Unity 3D Tilt, Unity 3D Tilt Reverse, Premium Glass. Matching header/ambient treatments for 3D and Glass. Existing focus-ring renderer remains the sole ring. Information density and typography independent.
- Added SF Pro Thin, Avenir Book, Helvetica Neue UltraLight to existing light/regular font offerings. No font binaries bundled.
- Validation: Swift parser and ZIP integrity only; full Xcode compile and physical Apple TV QA required.
