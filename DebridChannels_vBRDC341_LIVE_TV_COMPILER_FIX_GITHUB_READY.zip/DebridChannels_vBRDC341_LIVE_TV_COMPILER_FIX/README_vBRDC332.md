# vBRDC332 / 1.0.1034 / build 1034

Source donor: vBRDC331 packaged ZIP only. Preserves all v328-v331 performance/playback/settings fixes.

- Directly fetch the official catalog's existing immutable `/assets/` objects. Do not route catalog.skylinejay187.it.com artwork through the unrelated /api/image proxy.
- Prefetch poster bytes above AND below the active row; prioritize current and adjacent rows for rapid upward scrolling.
- Spotlight warmups no longer replace/cancel the global catalog prefetch queue.
- Corrupt persistent image bytes are discarded and retried from the network rather than producing a permanent blank cache hit.
- Focus arrival uses a non-overshooting ease-out and is disabled during visual focus pinning; the user's selected horizontal motion style remains intact.

Physical tvOS build/runtime and deployed server performance must be verified separately.
