#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
mkdir -p Vendor/TVVLCKit .build-cache
TARGET_FW="Vendor/TVVLCKit/TVVLCKit.framework"
TARGET_XC="Vendor/TVVLCKit/TVVLCKit.xcframework"
if [ -d "$TARGET_FW" ]; then
  EXISTING_BYTES=$(find "$TARGET_FW" -type f -exec stat -f%z {} \; | awk '{s+=$1} END {print s+0}')
  if [ "$EXISTING_BYTES" -ge 30000000 ]; then
    echo "TVVLCKit already vendored ($EXISTING_BYTES bytes); skipping download."
    exit 0
  fi
  rm -rf Vendor/TVVLCKit
  mkdir -p Vendor/TVVLCKit
fi
TVVLC_URL="https://download.videolan.org/cocoapods/prod/TVVLCKit-3.7.3-319ed2c0-79128878.tar.xz"
ARCHIVE=".build-cache/TVVLCKit-3.7.3.tar.xz"
EXTRACT_DIR=".build-cache/TVVLCKitExtract"
rm -rf "$EXTRACT_DIR"; mkdir -p "$EXTRACT_DIR"
echo "Fetching TVVLCKit in parallel with Swift dependencies..."
curl -fL --retry 5 --retry-delay 5 --connect-timeout 30 -o "$ARCHIVE" "$TVVLC_URL"
ARCHIVE_BYTES=$(stat -f%z "$ARCHIVE")
[ "$ARCHIVE_BYTES" -ge 100000000 ] || { echo "ERROR: TVVLCKit archive is too small ($ARCHIVE_BYTES)." >&2; exit 1; }
tar -xJf "$ARCHIVE" -C "$EXTRACT_DIR"
FOUND_XC=$(find "$EXTRACT_DIR" -iname 'TVVLCKit.xcframework' -type d -print | head -n 1 || true)
FOUND_FW=""
if [ -n "$FOUND_XC" ]; then
  rm -rf "$TARGET_XC"; cp -R "$FOUND_XC" "$TARGET_XC"
  FOUND_FW=$(find "$TARGET_XC" -path '*/tvos-arm64/TVVLCKit.framework' -type d -print | head -n 1 || true)
fi
[ -n "$FOUND_FW" ] || FOUND_FW=$(find "$EXTRACT_DIR" -path '*/tvos-arm64/TVVLCKit.framework' -type d -print | head -n 1 || true)
[ -n "$FOUND_FW" ] || FOUND_FW=$(find "$EXTRACT_DIR" -iname 'TVVLCKit.framework' -type d -print | grep -v simulator | head -n 1 || true)
[ -n "$FOUND_FW" ] || { echo "ERROR: tvOS arm64 TVVLCKit.framework not found." >&2; exit 1; }
rm -rf "$TARGET_FW"; cp -R "$FOUND_FW" "$TARGET_FW"
VENDOR_BYTES=$(find "$TARGET_FW" -type f -exec stat -f%z {} \; | awk '{s+=$1} END {print s+0}')
[ "$VENDOR_BYTES" -ge 30000000 ] || { echo "ERROR: Vendored TVVLCKit is too small ($VENDOR_BYTES)." >&2; exit 1; }
echo "TVVLCKit ready ($VENDOR_BYTES bytes)."
