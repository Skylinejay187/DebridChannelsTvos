import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct CatalogHeroMetadataSnapshot: Hashable, Sendable {
    let runtimeMinutes: Int?
    let releaseYear: String?
    let genres: [String]
    let seasonCount: Int?
    let overview: String?
}

actor CatalogHeroMetadataCache {
    static let shared = CatalogHeroMetadataCache()

    private struct CacheEntry {
        let value: CatalogHeroMetadataSnapshot?
        let expiresAt: Date
    }

    private var entries: [String: CacheEntry] = [:]
    private var inFlight: [String: Task<CatalogHeroMetadataSnapshot?, Never>] = [:]
    private let ttl: TimeInterval = 6 * 60 * 60

    func metadata(
        itemID: String,
        tmdbID: String?,
        imdbID: String?,
        title: String,
        year: String,
        type: String,
        apiKey: String
    ) async -> CatalogHeroMetadataSnapshot? {
        let cleanKey = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.isEmpty else { return nil }

        let cacheKey = [itemID, tmdbID ?? "", imdbID ?? "", type, year, title]
            .joined(separator: "|")
            .lowercased()

        if let cached = entries[cacheKey], cached.expiresAt > Date() {
            return cached.value
        }
        if let task = inFlight[cacheKey] {
            return await task.value
        }

        let task = Task<CatalogHeroMetadataSnapshot?, Never> {
            await Self.fetchMetadata(
                itemID: itemID,
                tmdbID: tmdbID,
                imdbID: imdbID,
                title: title,
                year: year,
                type: type,
                apiKey: cleanKey
            )
        }
        inFlight[cacheKey] = task
        let value = await task.value
        inFlight[cacheKey] = nil
        entries[cacheKey] = CacheEntry(value: value, expiresAt: Date().addingTimeInterval(ttl))
        return value
    }

    private static func fetchMetadata(
        itemID: String,
        tmdbID: String?,
        imdbID: String?,
        title: String,
        year: String,
        type: String,
        apiKey: String
    ) async -> CatalogHeroMetadataSnapshot? {
        struct TMDBReference: Decodable { let id: Int? }
        struct TMDBFindResponse: Decodable {
            let movie_results: [TMDBReference]?
            let tv_results: [TMDBReference]?
        }
        struct TMDBSearchResponse: Decodable { let results: [TMDBReference]? }
        struct TMDBGenre: Decodable { let name: String? }
        struct MovieDetail: Decodable {
            let runtime: Int?
            let release_date: String?
            let genres: [TMDBGenre]?
            let overview: String?
        }
        struct TVDetail: Decodable {
            let episode_run_time: [Int]?
            let first_air_date: String?
            let genres: [TMDBGenre]?
            let number_of_seasons: Int?
            let overview: String?
        }

        func request<T: Decodable>(_ type: T.Type, url: URL) async -> T? {
            do {
                var request = URLRequest(url: url)
                request.timeoutInterval = 8
                request.cachePolicy = .returnCacheDataElseLoad
                let (data, response) = try await URLSession.shared.data(for: request)
                guard !Task.isCancelled else { return nil }
                if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
                    return nil
                }
                return try JSONDecoder().decode(T.self, from: data)
            } catch {
                return nil
            }
        }

        func makeURL(path: String, query: [URLQueryItem] = []) -> URL? {
            var components = URLComponents()
            components.scheme = "https"
            components.host = "api.themoviedb.org"
            components.path = "/3/\(path)"
            components.queryItems = [
                URLQueryItem(name: "api_key", value: apiKey),
                URLQueryItem(name: "language", value: "en-US")
            ] + query
            return components.url
        }

        let normalizedType = type.lowercased()
        let isTV = normalizedType.contains("series") || normalizedType.contains("show") || normalizedType == "tv"
        var kind = isTV ? "tv" : "movie"
        var resolvedID: String? = tmdbID?.trimmingCharacters(in: .whitespacesAndNewlines)

        if resolvedID?.isEmpty != false {
            let parts = itemID.split(separator: ":").map(String.init)
            if parts.count >= 3, parts[0].lowercased() == "tmdb" {
                kind = (parts[1].lowercased() == "tv" || isTV) ? "tv" : "movie"
                resolvedID = parts[2]
            }
        }

        if resolvedID?.isEmpty != false {
            let candidateIMDb: String? = {
                let clean = imdbID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                if clean.lowercased().hasPrefix("tt") { return clean }
                if itemID.lowercased().hasPrefix("tt") { return itemID }
                if let range = itemID.range(of: #"tt\d{6,}"#, options: .regularExpression) {
                    return String(itemID[range])
                }
                return nil
            }()

            if let candidateIMDb,
               let url = makeURL(
                    path: "find/\(candidateIMDb)",
                    query: [URLQueryItem(name: "external_source", value: "imdb_id")]
               ),
               let found = await request(TMDBFindResponse.self, url: url) {
                if let movieID = found.movie_results?.compactMap(\.id).first {
                    kind = "movie"
                    resolvedID = String(movieID)
                } else if let tvID = found.tv_results?.compactMap(\.id).first {
                    kind = "tv"
                    resolvedID = String(tvID)
                }
            }
        }

        if resolvedID?.isEmpty != false {
            let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleanTitle.isEmpty else { return nil }
            var queryItems = [
                URLQueryItem(name: "query", value: cleanTitle),
                URLQueryItem(name: "include_adult", value: "false")
            ]
            let cleanYear = String(year.filter(\.isNumber).prefix(4))
            if !cleanYear.isEmpty {
                queryItems.append(URLQueryItem(name: kind == "tv" ? "first_air_date_year" : "year", value: cleanYear))
            }
            if let url = makeURL(path: "search/\(kind)", query: queryItems),
               let search = await request(TMDBSearchResponse.self, url: url),
               let firstID = search.results?.compactMap(\.id).first {
                resolvedID = String(firstID)
            }
        }

        guard let resolvedID, !resolvedID.isEmpty,
              let detailURL = makeURL(path: "\(kind)/\(resolvedID)") else { return nil }

        if kind == "tv", let detail = await request(TVDetail.self, url: detailURL) {
            return CatalogHeroMetadataSnapshot(
                runtimeMinutes: detail.episode_run_time?.first(where: { $0 > 0 }),
                releaseYear: detail.first_air_date.flatMap(Self.yearPrefix),
                genres: detail.genres?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } ?? [],
                seasonCount: detail.number_of_seasons,
                overview: detail.overview?.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        }

        if let detail = await request(MovieDetail.self, url: detailURL) {
            return CatalogHeroMetadataSnapshot(
                runtimeMinutes: detail.runtime,
                releaseYear: detail.release_date.flatMap(Self.yearPrefix),
                genres: detail.genres?.compactMap { $0.name?.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty } ?? [],
                seasonCount: nil,
                overview: detail.overview?.trimmingCharacters(in: .whitespacesAndNewlines)
            )
        }
        return nil
    }

    private static func yearPrefix(_ value: String) -> String? {
        let digits = value.filter(\.isNumber)
        guard digits.count >= 4 else { return nil }
        return String(digits.prefix(4))
    }
}
