from pathlib import Path
import plistlib, re, yaml

ROOT = Path(__file__).resolve().parents[1]
app = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
bridge = (ROOT/'Sources/ManagedAddonBridge.swift').read_text()
cred = (ROOT/'Sources/DebridCredentialBridge.swift').read_text()
health = (ROOT/'Sources/ConnectedServicesHealthClient.swift').read_text()
catalog = (ROOT/'Sources/CatalogStore.swift').read_text()
project = (ROOT/'project.yml').read_text()
with open(ROOT/'Sources/Info.plist','rb') as f: app_plist=plistlib.load(f)
with open(ROOT/'TopShelfExtension/Info.plist','rb') as f: ext_plist=plistlib.load(f)
proj=yaml.safe_load(project)

checks=[]
def check(name, cond):
    checks.append((name, bool(cond)))
    if not cond:
        raise AssertionError(name)

check('app marketing 1.0.756', app_plist['CFBundleShortVersionString']=='1.0.756')
check('app build 756', app_plist['CFBundleVersion']=='756')
check('app release vBRDC053', app_plist['DebridChannelsReleaseID']=='vBRDC053')
check('top shelf version parity', ext_plist['CFBundleShortVersionString']=='1.0.756' and ext_plist['CFBundleVersion']=='756' and ext_plist['DebridChannelsReleaseID']=='vBRDC053')
check('project version parity', proj['settings']['base']['MARKETING_VERSION']=='1.0.756' and str(proj['settings']['base']['CURRENT_PROJECT_VERSION'])=='756')

check('managed Debridio state removed', 'managedDebridio' not in app and 'ManagedAddonCredentialStore' not in app and 'Debridio Scraper' not in app)
check('managed Debridio implementation removed', 'debridioScraperManifestURL' not in bridge and 'debridioWatchtowerManifestURL' not in bridge and 'debridioTMDBManifestURL' not in bridge)
check('Comet generator removed from app', 'builtInCometManifestURL' not in app and 'case "comet"' not in app)
check('Comet generator removed from bridge', 'cometManifestURL' not in bridge and 'Comet •' not in bridge)
check('dead built-in installer removed', 'private func installBuiltInAddon' not in app)
check('duplicate Torrentio override UI removed', 'torrentioRealDebridApiKey") private var' not in app and 'torrentioTorBoxApiKey") private var' not in app)
check('legacy overrides migrate to main keys', 'migrateLegacyOverridesIfNeeded' in cred and 'torrentioRealDebridApiKey' in cred and 'torrentioTorBoxApiKey' in cred and 'removeObject(forKey: legacyKey)' in cred)
check('retired Debridio keychain cleanup present', 'debridio-api-key-v1' in cred and 'SecItemDelete' in cred)
check('dead addon quality UI removed', '@AppStorage("builtInAddonQualityFilter")' not in app and 'focus: .addonQuality' not in app)
check('runtime managed bridge is Torrentio only', 'Torrentio •' in bridge and 'torrentio.strem.fun' in bridge)
check('native TorBox Usenet status explicit', 'API + Usenet + Voyager connected' in health and 'Voyager Usenet search connected' in health and 'search_user_engines=true' in health)
check('saved Stremio addons are health checked', 'verifySavedStremioAddons' in health and 'stremioManifestURLs' in health and 'Stremio addon connected' in health)
check('saved addons get no global bridge injection', 'Saved Stremio addons stay isolated' in app and 'never receive global debrid credentials automatically' in app)
check('one-time old Comet saved URL cleanup', 'retiredManagedCometRemoved' in catalog and 'isRetiredManagedCometManifest' in catalog)
check('generic manual addon path preserved', 'Saved JSON URLs' in app and 'store.addManifestURL(manifestURL)' in app)
check('managed catalog injection removed', 'ManagedAddonBridge.catalogMetadataManifests' not in catalog and 'ManagedAddonBridge.streamManifests' not in catalog)

# Resource/package hygiene: canonical asset catalog only, no loose historical art copies.
loose_resources=[p for p in (ROOT/'Resources').iterdir() if p.is_file()]
check('no loose duplicate Resources files', not loose_resources)
check('canonical asset catalog exists', (ROOT/'Resources/Assets.xcassets/AppIcon.brandassets/AppIcon.imagestack').exists())
check('project no duplicate Resources build entry', project.count('- path: Resources/Assets.xcassets')==1 and '\n      - path: Resources\n' not in project)

# Historical build debris was removed from the source package.
allowed_root={'project.yml','DebridChannelsTVOS.entitlements'}
root_files={p.name for p in ROOT.iterdir() if p.is_file()}
check('root contains no historical logs/manifests', root_files.issubset(allowed_root | {'README_BUILD_vBRDC053_VBRDC052_BASE_CLEANUP_TORRENTIO_USENET_STATUS.md','AUDIT_vBRDC053_CHANGED_FILES.txt','PACKAGE_FILE_HASHES_vBRDC053.sha256'}))
old_validation=[p.name for p in ROOT.iterdir() if p.is_dir() and (p.name.lower().startswith('validation')) and p.name!='validation_vBRDC053']
check('old validation folders removed', not old_validation)

print(f'{len(checks)}/{len(checks)} vBRDC053 contracts PASS')
for name,_ in checks:
    print('PASS', name)
