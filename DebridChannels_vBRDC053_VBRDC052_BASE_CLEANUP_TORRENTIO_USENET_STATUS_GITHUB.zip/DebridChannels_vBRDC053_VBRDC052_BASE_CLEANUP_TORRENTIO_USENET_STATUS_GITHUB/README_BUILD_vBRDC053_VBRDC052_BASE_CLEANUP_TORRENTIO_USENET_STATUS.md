# Debrid Channels vBRDC053

- Release ID: `vBRDC053`
- Marketing version: `1.0.756`
- Apple build: `756`
- Backend: `v692` unchanged
- Fresh base: packaged `vBRDC052` only

## Scope

vBRDC053 is a cleanup/correction build. It removes the managed Debridio and Comet implementations, eliminates duplicated/dead addon configuration, keeps native TorBox Usenet/Voyager, keeps Torrentio on the global credential bridge, and aggressively removes historical packaging debris that is not part of the Xcode build.

## Addon cleanup

### Managed Debridio removed

Removed the vBRDC052 managed Debridio API-key UI and all generated Debridio Scraper, Watchtower, TMDB, and TVDB adapters. Debridio can still be used as a normal user-supplied Stremio manifest through **Saved JSON URLs**; the generic Stremio engine remains unchanged.

A one-time migration removes the retired managed-Debridio UserDefaults keys and deletes the old `debridio-api-key-v1` Keychain item so an unused credential is not left behind.

### Managed Comet removed

Removed Comet manifest generation, Comet connection-health rows, the duplicate Comet manifest builder in the Settings screen, and the already-dead built-in addon installer helpers. A one-time migration removes old saved managed-Comet endpoints (`comet.elfhosted.com` / `comet.feels.legal`) from prior configurations.

### Torrentio bridge simplified

The managed bridge now generates **Torrentio only** from the main Real-Debrid/TorBox credentials.

The duplicate Torrentio override fields were removed from Settings. Existing installations are preserved by a one-time migration:

- `torrentioRealDebridApiKey` -> `realDebridApiKey` when the main key is blank
- `torrentioTorBoxApiKey` -> `torBoxApiKey` when the main key is blank

The old override value is then removed. Old profile backups containing those fields are still accepted and folded into the main service keys during restore.

The obsolete managed-addon quality text field was also removed; it no longer affected Torrentio's allow-list behavior. Cached/uncached and CAM/low-quality controls remain.

## Connection confirmation

**Verify Connected Services** now checks:

- TorBox account API
- TorBox Usenet API
- TorBox Voyager Usenet search
- Voyager user search engines
- Real-Debrid API
- runtime-generated Torrentio bridge(s)
- every user-saved Stremio manifest independently

A successful TorBox row explicitly reports `API + Usenet + Voyager connected`. Saved Stremio addons report their manifest reachability and advertised resources such as Streams, Catalogs, Metadata, and Subtitles. Global debrid credentials are never injected into arbitrary saved Stremio addons.

## Package/build cleanup

The previous package had accumulated years of historical audit files, validation output, duplicate artwork masters, and legacy dependency files. None were required by Xcode/GitHub Actions.

vBRDC053 removes:

- historical root-level README/audit/log/JSON/SHA output
- old validation folders
- the historical `Docs` folder from the distributable source package
- unused `Podfile` and `Cartfile` (TVVLCKit is already fetched by the authoritative Xcode pre-build script)
- all loose duplicate icon/launcher/top-shelf artwork in `Resources/`
- the redundant non-asset `Resources` build-phase entry

The canonical `Resources/Assets.xcassets` remains intact, including AppIcon, App Store icon stack, Top Shelf artwork, loading screen, and other runtime assets.

This reduces the GitHub-upload source ZIP from roughly 25.3 MiB to roughly 3 MiB while retaining the build inputs.

## Preserved systems

The vBRDC049 playback/graphics stability path is untouched. The following were verified byte-for-byte against packaged vBRDC052:

- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/LocalIntroDetectionEngine.swift`
- `Scripts/patch_kspnuvio_local_intro_vBRDC043.py`
- `Scripts/patch_kspnuvio_playback_stability_vBRDC049.py`
- `Scripts/fetch_patch_kspnuvio_vBRDC043.sh`

No backend change is required.

## Validation

Local validation completed before packaging:

- 60 Swift production/Top Shelf files parse
- focused credential/managed-addon/health Swift typecheck passes
- Torrentio bridge runtime test passes, including legacy-key migration
- saved-Stremio-addon health runtime test passes against a local manifest server
- 26/26 vBRDC053 static contracts pass
- app/Top Shelf/project version parity passes
- project YAML and both plists parse
- every project-listed source/resource path exists
- KSP patch Python scripts compile and fetch script passes `bash -n`
- five playback/intro stability files are byte-for-byte preserved
- final ZIP integrity is checked after packaging

Full Xcode/GitHub Actions compilation remains authoritative for the Apple/tvOS SDK build.
