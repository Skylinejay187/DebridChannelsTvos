# Debrid Channels vBRDC229 — MPVKit Primary + Instant Handoff

Release: vBRDC229  
Marketing version: 1.0.932  
Build: 932

## Playback architecture
- MPVKit/libmpv is the production-first VOD and full Live TV renderer.
- MPVKit dependency is pinned to revision `99030e05253f0977b5e00eb079416565c608f2b1`.
- Hardware video decode: VideoToolbox.
- Presentation: gpu-next through Vulkan/MoltenVK onto a CAMetalLayer.
- Audio output: AVFoundation.
- KSPlayer remains installed as a cold compatibility fallback; it is not mounted during normal MPVKit startup.
- AVPlayer and VLC remain explicit compatibility paths.
- Existing Bluetooth/MediaRemote/Now Playing ownership, Trakt/resume, subtitles/audio selection, failover, playback overlays, aspect controls and external-player routes are retained.

## Instant source-to-first-frame handoff
- Source Intelligence pre-shapes each direct source into a `ReadyPlaybackSource` while the source list is already visible.
- Primary headers, fallback URL order, fallback header map, subtitle URLs and adaptive-cache hints are prepared before selection.
- `startPlayback` publishes a new immutable presentation UUID, claims media-button ownership, consumes the ready-source plan, arms the artwork cover, and publishes `playbackURL` immediately after the launch-critical contract is complete.
- Session-journal I/O is deferred to the next main-queue turn.
- The same media artwork remains above the decoder during the source -> player -> display -> first-frame transition and is released only from the active renderer's first-frame signal.
- `PlaybackLaunchBenchmark` records source handoff, MPV initialization/open/probe/render milestones and total time to accepted first frame.

## MPVKit startup / playback
- HTTP request headers are preserved for protected/debrid/Stremio sources.
- MPV starts paused while source/track/resume state is committed.
- Resume is applied in-place and durable progress continues to checkpoint from the authoritative decoder clock.
- First-frame release requires configured video dimensions, configured VO, an unpaused/non-seeking renderer and an advancing MPV playback clock. A resume seek alone cannot remove the launch cover.
- tvOS display matching remains VOD-only and has a bounded HDMI-settle gate.
- App background/foreground preserves a verified MPV position and explicitly detaches/reattaches video rather than treating lifecycle EOF-like samples as completion.

## Adaptive cache and Live TV time-shift
The cache is RAM bounded and memory-tier aware. VOD prioritizes forward read-ahead. Live TV reserves a larger backward demuxer cache for pause/rewind while retaining a bounded forward cache. `Go Live` seeks to the live edge without recreating the decoder.

Current plans:
- compact-memory VOD: 120s logical/readahead, 128 MiB forward, 32 MiB backward
- larger-memory VOD: 180s logical/readahead, 320 MiB forward, 96 MiB backward
- compact-memory Live TV: 1800s logical, 180s readahead, 96 MiB forward, 160 MiB backward
- larger-memory Live TV: 3600s logical, 240s readahead, 160 MiB forward, 256 MiB backward

These are byte ceilings, not preallocated memory promises; the actual rewind duration depends on stream bitrate and origin seekability.

## Live TV controls
- Auto is MPVKit-first.
- Per-channel override supports Auto, MPVKit, KSPlayer, AVPlayer and VLC.
- MPVKit Live TV exposes Go Live and pause/rewind time-shift using the seekable demuxer cache.
- Existing Live TV guide/overlay/category behavior remains in place.

## Settings
VOD Player settings now identify MPVKit as Primary, KSPlayer as Compatibility Backup and AVPlayer as Native Compatibility. Existing installs are migrated once to MPVKit primary; a later manual user selection is respected.

## Validation limits
This Linux environment can parse Swift and validate project/plist/source contracts, but cannot perform an authoritative Xcode/tvOS link, package build, Metal/VideoToolbox runtime test, HDMI display-match test, Bluetooth test, or physical Apple TV playback test. GitHub Actions/Xcode remains authoritative for those stages.
