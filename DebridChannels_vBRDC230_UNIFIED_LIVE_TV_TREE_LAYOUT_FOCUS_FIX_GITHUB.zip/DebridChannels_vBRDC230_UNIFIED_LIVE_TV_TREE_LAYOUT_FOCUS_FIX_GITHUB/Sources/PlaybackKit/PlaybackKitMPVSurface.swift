import Foundation
import SwiftUI
import UIKit
import QuartzCore
import Metal

#if canImport(Libmpv)
import Libmpv

/// vBRDC229: MPVKit becomes the production-first internal renderer. This host is an
/// independent Debrid Channels implementation built against MPVKit's public Libmpv API.
/// It intentionally keeps the surface contract small so KSPlayer can remain a cold
/// compatibility fallback without both engines being resident during ordinary startup.
struct PlaybackKitMPVHost: UIViewRepresentable {
    let url: URL
    var shouldPlay: Bool = true
    var seekSerial: Int = 0
    var seekSeconds: Double = 0
    var seekIsAbsolute: Bool = false
    var goLiveSerial: Int = 0
    var reloadToken: Int = 0
    var startTimeSeconds: Double = 0
    var isLiveStream: Bool = false
    var playbackSessionID: UUID? = nil
    var routeHint: String = ""
    var httpHeaders: [String: String] = [:]
    var selectedAudioTrackID: Int? = nil
    var selectedSubtitleTrackID: Int? = nil
    var selectedExternalSubtitleURL: URL? = nil
    var subtitleDelayMS: Int = 0
    var trackSelectionSerial: Int = 0
    var audioGainDB: Double = 0

    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onBufferUpdate: ((Double, Double) -> Void)? = nil
    var onTracksDiscovered: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)? = nil
    var onPlaybackFailure: ((String) -> Void)? = nil
    var onPlaybackEnded: (() -> Void)? = nil
    var onFirstFrameReady: (() -> Void)? = nil
    var onMilestone: ((String) -> Void)? = nil
    var onChaptersDiscovered: (([PlaybackChapterMarker]) -> Void)? = nil

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> MPVRenderView {
        let view = MPVRenderView()
        // Install the callback/configuration contract before libmpv is created so an
        // initialization failure is surfaced to the owning player screen instead of
        // disappearing into an empty default callback set. attach() starts the queued
        // configuration immediately after mpv_initialize succeeds.
        configure(context.coordinator)
        context.coordinator.attach(to: view)
        return view
    }

    func updateUIView(_ uiView: MPVRenderView, context: Context) {
        context.coordinator.attach(to: uiView)
        configure(context.coordinator)
    }

    static func dismantleUIView(_ uiView: MPVRenderView, coordinator: Coordinator) {
        coordinator.shutdown()
    }

    private func configure(_ coordinator: Coordinator) {
        coordinator.callbacks = .init(
            time: onPlaybackTimeUpdate,
            buffer: onBufferUpdate,
            tracks: onTracksDiscovered,
            failure: onPlaybackFailure,
            ended: onPlaybackEnded,
            firstFrame: onFirstFrameReady,
            milestone: onMilestone,
            chapters: onChaptersDiscovered
        )
        coordinator.configure(
            url: url,
            shouldPlay: shouldPlay,
            seekSerial: seekSerial,
            seekSeconds: seekSeconds,
            seekIsAbsolute: seekIsAbsolute,
            goLiveSerial: goLiveSerial,
            reloadToken: reloadToken,
            startTimeSeconds: startTimeSeconds,
            isLiveStream: isLiveStream,
            playbackSessionID: playbackSessionID,
            routeHint: routeHint,
            httpHeaders: httpHeaders,
            selectedAudioTrackID: selectedAudioTrackID,
            selectedSubtitleTrackID: selectedSubtitleTrackID,
            selectedExternalSubtitleURL: selectedExternalSubtitleURL,
            subtitleDelayMS: subtitleDelayMS,
            trackSelectionSerial: trackSelectionSerial,
            audioGainDB: audioGainDB
        )
    }

    final class MPVRenderView: UIView {
        let videoLayer = MPVMetalLayer()

        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .black
            isUserInteractionEnabled = false
            layer.masksToBounds = true
            videoLayer.contentsGravity = .resize
            videoLayer.framebufferOnly = true
            videoLayer.backgroundColor = UIColor.black.cgColor
            layer.addSublayer(videoLayer)
        }

        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

        override func layoutSubviews() {
            super.layoutSubviews()
            let scale = UIScreen.main.nativeScale
            CATransaction.begin()
            CATransaction.setDisableActions(true)
            videoLayer.frame = bounds
            videoLayer.contentsScale = scale
            let size = CGSize(
                width: max(2, (bounds.width * scale).rounded()),
                height: max(2, (bounds.height * scale).rounded())
            )
            videoLayer.drawableSize = size
            CATransaction.commit()
        }
    }

    final class MPVMetalLayer: CAMetalLayer {
        override var drawableSize: CGSize {
            get { super.drawableSize }
            set {
                guard newValue.width > 1, newValue.height > 1 else { return }
                if super.drawableSize != newValue { super.drawableSize = newValue }
            }
        }
    }

    struct Callbacks {
        var time: ((Double, Double) -> Void)?
        var buffer: ((Double, Double) -> Void)?
        var tracks: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)?
        var failure: ((String) -> Void)?
        var ended: (() -> Void)?
        var firstFrame: (() -> Void)?
        var milestone: ((String) -> Void)?
        var chapters: (([PlaybackChapterMarker]) -> Void)?
    }

    struct Configuration: Equatable {
        var url: URL
        var shouldPlay: Bool
        var seekSerial: Int
        var seekSeconds: Double
        var seekIsAbsolute: Bool
        var goLiveSerial: Int
        var reloadToken: Int
        var startTimeSeconds: Double
        var isLiveStream: Bool
        var playbackSessionID: UUID?
        var routeHint: String
        var httpHeaders: [String: String]
        var selectedAudioTrackID: Int?
        var selectedSubtitleTrackID: Int?
        var selectedExternalSubtitleURL: URL?
        var subtitleDelayMS: Int
        var trackSelectionSerial: Int
        var audioGainDB: Double
    }

    final class Coordinator {
        var callbacks = Callbacks()

        private weak var renderView: MPVRenderView?
        private var handle: OpaquePointer?
        private let eventQueue = DispatchQueue(label: "com.channelsdebrid.mpv.events", qos: .userInteractive)
        private var eventTimer: DispatchSourceTimer?
        private let stateLock = NSLock()
        private var config: Configuration?
        private var appliedURL: URL?
        private var appliedReloadToken: Int = -1
        private var appliedSeekSerial: Int = -1
        private var appliedGoLiveSerial: Int = -1
        private var appliedTrackSelectionSerial: Int = -1
        private var lastShouldPlay = true
        private var firstFrameReported = false
        private var fileLoaded = false
        private var pendingAutoplay = true
        private var pendingStartSeconds: Double = 0
        private var lastPublishedTime: Double = -1
        private var lastPublishedDuration: Double = -1
        private var lastTrackSignature = ""
        private var didPublishChapters = false
        private var didReportFailure = false
        private var cleanEOFReported = false
        private var displayGateWork: DispatchWorkItem?
        // First-frame release must be based on renderer + advancing playback-clock
        // evidence. In particular, a resume seek can publish its target time before any
        // pixel has actually been presented, so the mere presence of a non-zero time is
        // not sufficient.
        private var lastFrameEvidenceTime: Double?
        // tvOS can detach Metal/video while another app is frontmost. Preserve a
        // verified MPV position and explicitly detach/re-attach video so backgrounding
        // cannot turn a transient final-frame/eof sample into a completed watch.
        private var lifecycleObservers: [NSObjectProtocol] = []
        private var isApplicationBackgrounded = false
        private var wasPlayingBeforeBackground = false
        private var lifecyclePositionSeconds: Double?
        // Display-match gate: FILE_LOADED arms it, VIDEO_RECONFIG releases it after a
        // short HDMI-settle beat. A bounded fallback prevents unusual files from stalling.
        private var sawVideoReconfig = false
        private var waitingForDisplayGate = false
        // Closest non-invasive first-byte checkpoint available from libmpv: the first
        // positive demuxer cache duration means media packet data has reached the demuxer.
        private var firstBufferedDataReported = false

        deinit { shutdown() }

        func attach(to view: MPVRenderView) {
            renderView = view
            view.setNeedsLayout()
            view.layoutIfNeeded()
            if handle == nil { setupMPV(layer: view.videoLayer) }
            startQueuedConfigurationIfNeeded()
        }

        private func startQueuedConfigurationIfNeeded() {
            guard handle != nil else { return }
            stateLock.lock(); let next = config; stateLock.unlock()
            guard let next, appliedURL != next.url || appliedReloadToken != next.reloadToken else { return }
            appliedURL = next.url
            appliedReloadToken = next.reloadToken
            appliedSeekSerial = next.seekSerial
            appliedGoLiveSerial = next.goLiveSerial
            appliedTrackSelectionSerial = next.trackSelectionSerial
            lastShouldPlay = next.shouldPlay
            startLoad(next)
        }

        func configure(
            url: URL,
            shouldPlay: Bool,
            seekSerial: Int,
            seekSeconds: Double,
            seekIsAbsolute: Bool,
            goLiveSerial: Int,
            reloadToken: Int,
            startTimeSeconds: Double,
            isLiveStream: Bool,
            playbackSessionID: UUID?,
            routeHint: String,
            httpHeaders: [String: String],
            selectedAudioTrackID: Int?,
            selectedSubtitleTrackID: Int?,
            selectedExternalSubtitleURL: URL?,
            subtitleDelayMS: Int,
            trackSelectionSerial: Int,
            audioGainDB: Double
        ) {
            let next = Configuration(
                url: url,
                shouldPlay: shouldPlay,
                seekSerial: seekSerial,
                seekSeconds: seekSeconds,
                seekIsAbsolute: seekIsAbsolute,
                goLiveSerial: goLiveSerial,
                reloadToken: reloadToken,
                startTimeSeconds: startTimeSeconds,
                isLiveStream: isLiveStream,
                playbackSessionID: playbackSessionID,
                routeHint: routeHint,
                httpHeaders: httpHeaders,
                selectedAudioTrackID: selectedAudioTrackID,
                selectedSubtitleTrackID: selectedSubtitleTrackID,
                selectedExternalSubtitleURL: selectedExternalSubtitleURL,
                subtitleDelayMS: subtitleDelayMS,
                trackSelectionSerial: trackSelectionSerial,
                audioGainDB: audioGainDB
            )
            stateLock.lock(); config = next; stateLock.unlock()
            guard handle != nil else { return }

            if appliedURL != url || appliedReloadToken != reloadToken {
                appliedURL = url
                appliedReloadToken = reloadToken
                appliedSeekSerial = seekSerial
                appliedGoLiveSerial = goLiveSerial
                appliedTrackSelectionSerial = trackSelectionSerial
                lastShouldPlay = shouldPlay
                startLoad(next)
                return
            }

            if lastShouldPlay != shouldPlay {
                lastShouldPlay = shouldPlay
                setFlag("pause", !shouldPlay)
            }
            if appliedSeekSerial != seekSerial {
                appliedSeekSerial = seekSerial
                if seekIsAbsolute {
                    command("seek \(formatSeconds(seekSeconds)) absolute exact")
                } else {
                    command("seek \(formatSeconds(seekSeconds)) relative exact")
                }
                callbacks.milestone?("mpv seek command accepted")
            }
            if appliedGoLiveSerial != goLiveSerial {
                appliedGoLiveSerial = goLiveSerial
                // On live/HLS streams absolute-percent 100 is MPV's canonical seek-to-edge
                // command. If the origin exposes no seek window MPV simply leaves playback
                // at the current live edge without tearing down the decoder.
                command("seek 100 absolute-percent exact")
                setFlag("pause", false)
            }
            if appliedTrackSelectionSerial != trackSelectionSerial {
                appliedTrackSelectionSerial = trackSelectionSerial
                applyTrackSelection(next)
            }
            setDouble("sub-delay", Double(subtitleDelayMS) / 1000.0)
            applyAudioGain(next.audioGainDB)
        }

        private func setupMPV(layer: CAMetalLayer) {
            guard let created = mpv_create() else {
                callbacks.failure?("MPVKit could not create a libmpv instance.")
                return
            }
            handle = created
            callbacks.milestone?("mpv instance created")

            var windowID = Int64(bitPattern: UInt64(UInt(bitPattern: Unmanaged.passUnretained(layer).toOpaque())))
            _ = mpv_set_option(created, "wid", MPV_FORMAT_INT64, &windowID)
            setOption("vo", "gpu-next")
            setOption("gpu-api", "vulkan")
            setOption("gpu-context", "moltenvk")
            setOption("hwdec", "videotoolbox")
            setOption("ao", "avfoundation")
            setOption("audio-channels", "auto-safe")
            setOption("audio-format", "float")
            setOption("volume-max", "400")
            setOption("audio-fallback-to-null", "no")
            setOption("keep-open", "yes")
            setOption("target-colorspace-hint", "yes")
            setOption("tone-mapping", "auto")
            setOption("target-prim", "auto")
            setOption("target-trc", "auto")
            setOption("hdr-compute-peak", "yes")
            setOption("vulkan-swap-mode", "fifo")
            setOption("vulkan-queue-count", "1")
            setOption("vulkan-async-compute", "no")
            setOption("vulkan-async-transfer", "no")
            setOption("vulkan-disable-interop", "yes")
            setOption("demuxer-seekable-cache", "yes")
            setOption("cache-pause", "yes")
            setOption("cache-pause-wait", "1")
            setOption("cache", "yes")
            setOption("sub-use-margins", "yes")
            setOption("sub-ass-force-margins", "yes")
            setOption("sub-ass-override", "strip")

            let initResult = mpv_initialize(created)
            guard initResult >= 0 else {
                reportFailure("MPVKit initialization failed: \(errorString(initResult))")
                return
            }
            startEventPump()
            installLifecycleObserversIfNeeded()
            callbacks.milestone?("mpv initialized")
        }

        private func startLoad(_ next: Configuration) {
            guard handle != nil else { return }
            displayGateWork?.cancel()
            firstFrameReported = false
            fileLoaded = false
            didPublishChapters = false
            didReportFailure = false
            cleanEOFReported = false
            firstBufferedDataReported = false
            sawVideoReconfig = false
            waitingForDisplayGate = false
            pendingAutoplay = next.shouldPlay
            pendingStartSeconds = max(0, next.startTimeSeconds)
            lastPublishedTime = -1
            lastPublishedDuration = -1
            lastTrackSignature = ""
            lastFrameEvidenceTime = nil

            let cache = MPVCachePlan.current(isLive: next.isLiveStream)
            // libmpv options set after mpv_initialize are exposed through the
            // options/<name> property namespace. Using the option namespace here keeps
            // VOD and Live TV on different RAM/back-buffer profiles without recreating
            // the process or silently failing with MPV_ERROR_PROPERTY_NOT_FOUND.
            setRuntimeOption("cache-secs", cache.logicalSeconds)
            setRuntimeOption("demuxer-readahead-secs", cache.readaheadSeconds)
            setRuntimeOption("demuxer-max-bytes", cache.forwardBytes)
            setRuntimeOption("demuxer-max-back-bytes", cache.backwardBytes)
            setRuntimeOption("demuxer-seekable-cache", next.isLiveStream ? "yes" : "no")
            applyHTTPHeaders(next.httpHeaders)
            setFlag("pause", true)
            setDouble("sub-delay", Double(next.subtitleDelayMS) / 1000.0)
            applyAudioGain(next.audioGainDB)

            #if os(tvOS)
            if !next.isLiveStream {
                DebridTVOSDisplayMatchCoordinator.applyForFullScreenVOD(
                    url: next.url,
                    hint: next.routeHint,
                    httpHeaders: next.httpHeaders
                )
            }
            #endif

            callbacks.milestone?("mpv loadfile dispatched")
            command("loadfile \(quoted(next.url.absoluteString)) replace")
        }

        private func handleFileLoaded() {
            stateLock.lock(); let next = config; stateLock.unlock()
            guard let next else { return }
            fileLoaded = true
            callbacks.milestone?("mpv source opened and probed")
            applyTrackSelection(next)
            setDouble("sub-delay", Double(next.subtitleDelayMS) / 1000.0)
            applyAudioGain(next.audioGainDB)
            if pendingStartSeconds > 1.0 {
                command("seek \(formatSeconds(pendingStartSeconds)) absolute exact")
            }
            publishTracks(force: true)
            publishChaptersIfAvailable()

            #if os(tvOS)
            if DebridTVOSDisplayMatchCoordinator.isSystemDisplayMatchingEnabled() && !next.isLiveStream {
                waitingForDisplayGate = true
                // If VIDEO_RECONFIG already arrived before FILE_LOADED, release after the
                // same bounded HDMI-settle beat. Otherwise wait for actual video params.
                if sawVideoReconfig {
                    releaseDisplayGate(after: 0.18, reason: "video reconfig already available")
                } else {
                    releaseDisplayGate(after: 0.70, reason: "bounded display-match fallback")
                }
            } else {
                releaseDisplayGate(after: 0, reason: "display matching not required")
            }
            #else
            releaseDisplayGate(after: 0, reason: "non-tvOS")
            #endif
        }

        private func applyTrackSelection(_ next: Configuration) {
            if let audio = next.selectedAudioTrackID {
                setString("aid", String(audio))
            }
            if let subtitle = next.selectedSubtitleTrackID {
                setString("sid", String(subtitle))
            } else {
                setString("sid", "no")
            }
            if let external = next.selectedExternalSubtitleURL {
                command("sub-add \(quoted(external.absoluteString)) select")
            }
        }

        private func applyAudioGain(_ dB: Double) {
            let clamped = max(0, min(10, dB))
            let volume = 100.0 * pow(10.0, clamped / 20.0)
            setDouble("volume", min(400, volume))
        }

        private func applyHTTPHeaders(_ headers: [String: String]) {
            let userAgent = headerValue("user-agent", in: headers) ?? "DebridChannels-tvOS/MPVKit"
            let referrer = headerValue("referer", in: headers) ?? headerValue("referrer", in: headers) ?? ""
            setString("user-agent", userAgent)
            setString("referrer", referrer)
            let reserved = Set(["user-agent", "referer", "referrer", "host", "content-length", "transfer-encoding", "range", "content-range"])
            let fields = headers
                .filter { !reserved.contains($0.key.lowercased()) && !$0.value.isEmpty }
                .map { "\($0.key): \($0.value.replacingOccurrences(of: ",", with: "\\,"))" }
                .joined(separator: ",")
            setString("http-header-fields", fields)
        }

        private func startEventPump() {
            eventTimer?.cancel()
            let timer = DispatchSource.makeTimerSource(queue: eventQueue)
            timer.schedule(deadline: .now(), repeating: .milliseconds(50), leeway: .milliseconds(8))
            timer.setEventHandler { [weak self] in
                self?.drainEventsAndPublishState()
            }
            eventTimer = timer
            timer.resume()
        }

        private func drainEventsAndPublishState() {
            guard let handle else { return }
            while let event = mpv_wait_event(handle, 0) {
                let eventID = event.pointee.event_id
                if eventID == MPV_EVENT_NONE { break }
                if eventID == MPV_EVENT_START_FILE {
                    DispatchQueue.main.async { [weak self] in self?.callbacks.milestone?("mpv source open started") }
                } else if eventID == MPV_EVENT_FILE_LOADED {
                    DispatchQueue.main.async { [weak self] in self?.handleFileLoaded() }
                } else if eventID == MPV_EVENT_END_FILE {
                    if let data = event.pointee.data?.assumingMemoryBound(to: mpv_event_end_file.self) {
                        let reason = data.pointee.reason
                        let errorCode = data.pointee.error
                        if isApplicationBackgrounded {
                            // Background video detachment/route changes are lifecycle events,
                            // never authoritative natural completion.
                            continue
                        }
                        if reason == MPV_END_FILE_REASON_EOF && errorCode >= 0 {
                            cleanEOFReported = true
                            DispatchQueue.main.async { [weak self] in self?.callbacks.ended?() }
                        } else if errorCode < 0 {
                            let message = "MPVKit stream ended with \(errorString(errorCode))."
                            DispatchQueue.main.async { [weak self] in self?.reportFailure(message) }
                        }
                    }
                } else if eventID == MPV_EVENT_VIDEO_RECONFIG {
                    sawVideoReconfig = true
                    DispatchQueue.main.async { [weak self] in
                        guard let self else { return }
                        self.callbacks.milestone?("mpv video renderer configured")
                        if self.waitingForDisplayGate {
                            self.releaseDisplayGate(after: 0.18, reason: "video reconfig + HDMI settle")
                        }
                    }
                }
            }
            if !firstBufferedDataReported, (readDouble("demuxer-cache-duration") ?? 0) > 0 {
                firstBufferedDataReported = true
                DispatchQueue.main.async { [weak self] in
                    self?.callbacks.milestone?("mpv first buffered media data observed")
                }
            }
            publishStateSnapshot()
        }

        private func publishStateSnapshot() {
            guard handle != nil, fileLoaded, !isApplicationBackgrounded else { return }
            let current = max(0, readDouble("time-pos") ?? 0)
            let duration = max(0, readDouble("duration") ?? 0)
            // demuxer-cache-time is the timestamp at the end of buffered data,
            // not a duration to add to time-pos. Adding it to current would double-count
            // the playhead and overstate VOD buffer health.
            let cacheEnd = max(0, readDouble("demuxer-cache-time") ?? 0)
            let buffered = max(current, cacheEnd)
            let voConfigured = readFlag("vo-configured")
            let width = readInt("video-params/w")
            let height = readInt("video-params/h")
            let paused = readFlag("pause")
            let seeking = readFlag("seeking")
            let previousFrameEvidenceTime = lastFrameEvidenceTime
            lastFrameEvidenceTime = current

            if abs(current - lastPublishedTime) >= 0.08 || abs(duration - lastPublishedDuration) >= 0.5 {
                lastPublishedTime = current
                lastPublishedDuration = duration
                DispatchQueue.main.async { [weak self] in
                    self?.callbacks.time?(current, duration)
                    self?.callbacks.buffer?(buffered, duration)
                }
            }

            let clockAdvanced = previousFrameEvidenceTime.map { current - $0 > 0.004 } ?? false
            if !firstFrameReported,
               voConfigured,
               width > 1,
               height > 1,
               !paused,
               !seeking,
               clockAdvanced {
                firstFrameReported = true
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.callbacks.milestone?("mpv first rendered frame + advancing clock")
                    self.callbacks.firstFrame?()
                }
            }

            publishTracks(force: false)
            if !didPublishChapters { publishChaptersIfAvailable() }
        }

        private func releaseDisplayGate(after delay: TimeInterval, reason: String) {
            displayGateWork?.cancel()
            let work = DispatchWorkItem { [weak self] in
                guard let self else { return }
                self.waitingForDisplayGate = false
                if self.pendingAutoplay && !self.isApplicationBackgrounded {
                    self.setFlag("pause", false)
                }
                self.callbacks.milestone?("mpv display gate released (\(reason))")
            }
            displayGateWork = work
            if delay <= 0 {
                DispatchQueue.main.async(execute: work)
            } else {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: work)
            }
        }

        private func installLifecycleObserversIfNeeded() {
            guard lifecycleObservers.isEmpty else { return }
            let center = NotificationCenter.default
            lifecycleObservers.append(center.addObserver(
                forName: UIApplication.didEnterBackgroundNotification,
                object: nil,
                queue: .main
            ) { [weak self] _ in self?.enterBackground() })
            lifecycleObservers.append(center.addObserver(
                forName: UIApplication.willEnterForegroundNotification,
                object: nil,
                queue: .main
            ) { [weak self] _ in self?.enterForeground() })
        }

        private func enterBackground() {
            guard handle != nil else { return }
            let position = max(0, readDouble("time-pos") ?? lastPublishedTime)
            lifecyclePositionSeconds = position.isFinite ? position : nil
            wasPlayingBeforeBackground = !readFlag("pause")
            isApplicationBackgrounded = true
            displayGateWork?.cancel()
            waitingForDisplayGate = false
            setFlag("pause", true)
            setString("vid", "no")
            callbacks.milestone?("mpv background snapshot captured")
        }

        private func enterForeground() {
            guard handle != nil else { return }
            let shouldResume = wasPlayingBeforeBackground && (config?.shouldPlay ?? true)
            setString("vid", "auto")
            if let target = lifecyclePositionSeconds, target > 0.5 {
                command("seek \(formatSeconds(target)) absolute exact")
            }
            isApplicationBackgrounded = false
            lastFrameEvidenceTime = nil
            setFlag("pause", !shouldResume)
            callbacks.milestone?("mpv foreground video restored")
        }

        private func publishTracks(force: Bool) {
            let count = readInt("track-list/count")
            guard count >= 0 else { return }
            var audio: [RealMediaTrackOption] = []
            var subtitles: [RealMediaTrackOption] = []
            var signatureParts: [String] = []
            for index in 0..<count {
                let prefix = "track-list/\(index)"
                let type = readString("\(prefix)/type") ?? ""
                let id = readInt("\(prefix)/id")
                guard id >= 0 else { continue }
                let title = (readString("\(prefix)/title") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let language = (readString("\(prefix)/lang") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let codec = (readString("\(prefix)/codec") ?? readString("\(prefix)/codec-desc") ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let isDefault = readFlag("\(prefix)/default")
                let isForced = readFlag("\(prefix)/forced")
                signatureParts.append("\(type):\(id):\(title):\(language):\(codec):\(isDefault):\(isForced)")
                let label = title.isEmpty ? (language.isEmpty ? "Track \(id)" : language.uppercased()) : title
                let option = RealMediaTrackOption(
                    id: "mpv-\(type)-\(id)",
                    optionIndex: id,
                    label: label,
                    languageName: language.isEmpty ? "Unknown" : language,
                    codecOrFormat: codec.isEmpty ? nil : codec,
                    isDefault: isDefault,
                    isForced: isForced,
                    isSDH: title.lowercased().contains("sdh") || title.lowercased().contains("hearing")
                )
                if type == "audio" { audio.append(option) }
                if type == "sub" { subtitles.append(option) }
            }
            let signature = signatureParts.joined(separator: "|")
            guard force || signature != lastTrackSignature else { return }
            lastTrackSignature = signature
            DispatchQueue.main.async { [weak self] in self?.callbacks.tracks?(audio, subtitles) }
        }

        private func publishChaptersIfAvailable() {
            let count = readInt("chapter-list/count")
            guard count > 0 else { return }
            var chapters: [PlaybackChapterMarker] = []
            for index in 0..<count {
                let time = readDouble("chapter-list/\(index)/time") ?? -1
                guard time >= 0 else { continue }
                let title = readString("chapter-list/\(index)/title") ?? "Chapter \(index + 1)"
                let next = index + 1 < count ? (readDouble("chapter-list/\(index + 1)/time") ?? time + 1) : max(time + 1, readDouble("duration") ?? time + 1)
                chapters.append(.init(startSeconds: time, endSeconds: max(time + 0.1, next), title: title))
            }
            guard !chapters.isEmpty else { return }
            didPublishChapters = true
            DispatchQueue.main.async { [weak self] in self?.callbacks.chapters?(chapters) }
        }

        func shutdown() {
            displayGateWork?.cancel()
            displayGateWork = nil
            lifecycleObservers.forEach { NotificationCenter.default.removeObserver($0) }
            lifecycleObservers.removeAll()
            eventTimer?.cancel()
            eventTimer = nil
            guard let current = handle else { return }
            handle = nil
            eventQueue.async {
                mpv_terminate_destroy(current)
            }
        }

        private func reportFailure(_ message: String) {
            guard !didReportFailure else { return }
            didReportFailure = true
            callbacks.failure?(message)
        }

        private func setOption(_ name: String, _ value: String) {
            guard let handle else { return }
            let result = mpv_set_option_string(handle, name, value)
            if result < 0 { print("[MPVKit][vBRDC229] option \(name) rejected: \(errorString(result))") }
        }

        private func setString(_ name: String, _ value: String) {
            guard let handle else { return }
            let result = mpv_set_property_string(handle, name, value)
            if result < 0 { print("[MPVKit][vBRDC229] property \(name) rejected: \(errorString(result))") }
        }

        private func setRuntimeOption(_ name: String, _ value: String) {
            guard let handle else { return }
            let property = "options/\(name)"
            let result = mpv_set_property_string(handle, property, value)
            if result < 0 {
                print("[MPVKit][vBRDC229] runtime option \(name) rejected: \(errorString(result))")
            }
        }

        private func setDouble(_ name: String, _ value: Double) {
            guard let handle else { return }
            var copy = value
            _ = mpv_set_property(handle, name, MPV_FORMAT_DOUBLE, &copy)
        }

        private func setFlag(_ name: String, _ value: Bool) {
            guard let handle else { return }
            var flag: Int32 = value ? 1 : 0
            _ = mpv_set_property(handle, name, MPV_FORMAT_FLAG, &flag)
        }

        private func command(_ value: String) {
            guard let handle else { return }
            let result = mpv_command_string(handle, value)
            if result < 0 { print("[MPVKit][vBRDC229] command rejected: \(value.prefix(40)) • \(errorString(result))") }
        }

        private func readDouble(_ name: String) -> Double? {
            guard let handle else { return nil }
            var value = 0.0
            return mpv_get_property(handle, name, MPV_FORMAT_DOUBLE, &value) >= 0 ? value : nil
        }

        private func readInt(_ name: String) -> Int {
            guard let handle else { return -1 }
            var value: Int64 = 0
            return mpv_get_property(handle, name, MPV_FORMAT_INT64, &value) >= 0 ? Int(value) : -1
        }

        private func readFlag(_ name: String) -> Bool {
            guard let handle else { return false }
            var value: Int32 = 0
            return mpv_get_property(handle, name, MPV_FORMAT_FLAG, &value) >= 0 && value != 0
        }

        private func readString(_ name: String) -> String? {
            guard let handle, let pointer = mpv_get_property_string(handle, name) else { return nil }
            defer { mpv_free(pointer) }
            return String(cString: pointer)
        }

        private func headerValue(_ name: String, in headers: [String: String]) -> String? {
            headers.first(where: { $0.key.caseInsensitiveCompare(name) == .orderedSame })?.value
        }

        private func quoted(_ value: String) -> String {
            let escaped = value
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "\"", with: "\\\"")
            return "\"\(escaped)\""
        }

        private func formatSeconds(_ value: Double) -> String {
            String(format: "%.3f", value.isFinite ? value : 0)
        }

        private func errorString(_ code: Int32) -> String {
            guard let ptr = mpv_error_string(code) else { return "libmpv error \(code)" }
            return String(cString: ptr)
        }
    }
}

private struct MPVCachePlan {
    let logicalSeconds: String
    let readaheadSeconds: String
    let forwardBytes: String
    let backwardBytes: String

    static func current(isLive: Bool) -> MPVCachePlan {
        let ram = ProcessInfo.processInfo.physicalMemory
        let compact = ram <= 2_500_000_000
        if isLive {
            // Back-buffer is intentionally larger than forward-buffer for pause/rewind.
            // These are hard byte ceilings; the long logical window never forces MPV to
            // allocate it all. This is the first production time-shift layer and remains
            // safely below tvOS jetsam territory on both memory tiers.
            return compact
                ? .init(logicalSeconds: "1800", readaheadSeconds: "180", forwardBytes: "96MiB", backwardBytes: "160MiB")
                : .init(logicalSeconds: "3600", readaheadSeconds: "240", forwardBytes: "160MiB", backwardBytes: "256MiB")
        }
        return compact
            ? .init(logicalSeconds: "120", readaheadSeconds: "120", forwardBytes: "128MiB", backwardBytes: "32MiB")
            : .init(logicalSeconds: "180", readaheadSeconds: "180", forwardBytes: "320MiB", backwardBytes: "96MiB")
    }
}

#else

/// Compile-safe placeholder used only if the MPVKit package failed to resolve. The app's
/// engine policy detects that situation and keeps KSPlayer as the compatibility fallback.
struct PlaybackKitMPVHost: View {
    let url: URL
    var body: some View { Color.black }
}

#endif
