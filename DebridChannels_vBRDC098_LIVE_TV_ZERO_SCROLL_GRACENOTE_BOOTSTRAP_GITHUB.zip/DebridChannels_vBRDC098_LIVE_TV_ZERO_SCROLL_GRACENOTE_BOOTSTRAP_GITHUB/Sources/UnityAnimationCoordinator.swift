import Foundation
import Combine

/// vBRDC080 — Code Name: UNITY
///
/// Process-wide animation arbitration for Debrid Channels. Animated surfaces no longer
/// independently decide when to pause/restart. Each visual system asks for a named feature
/// permit and the coordinator applies one compatibility policy across the app.
///
/// Important policy:
/// - Source Intelligence *searching* is non-exclusive for the focused-card preview. The
///   preview may remain mounted, but the underlying catalog scale pulse yields whenever
///   Media Information is active so overlay/search layout work never competes with it.
/// - Opening an actual source, resolving the Play action, trailer playback, or full-screen
///   playback is exclusive. Auxiliary/ambient animation lanes yield before decoder handoff.
/// - Global Search, Settings, Guide, and inactive scene ownership prevent hidden catalog
///   animation work, but do not mutate the user's saved animation preferences.
final class UnityAnimationCoordinator: ObservableObject {
    static let shared = UnityAnimationCoordinator()

    enum Feature: String, CaseIterable {
        case dynamicWallpaper
        case catalogFocusArrival
        case catalogPulse
        case catalogPreview
        case catalogRowMotion
        case detailTransition
        case detailConnector
        case sourceIntelligenceMotion
        case liveTVMotion
        case guideMotion
        case sportsMotion
        case tickerMotion
        case overlayChrome
        case playbackChrome
        case alertMotion
    }

    struct GlobalContext: Equatable {
        var sceneActive: Bool = true
        var globalSearchActive: Bool = false
        var settingsActive: Bool = false
        var detailActive: Bool = false
        var fullScreenPlaybackActive: Bool = false
    }

    @Published private(set) var revision: UInt64 = 0
    private(set) var context = GlobalContext()

    private(set) var sourceSearchActive: Bool = false
    private(set) var sourceOpeningActive: Bool = false
    private(set) var trailerExclusiveActive: Bool = false
    private(set) var guideActive: Bool = false
    private(set) var surfaceHandoffActive: Bool = false

    // vBRDC090 — Motion Runtime / frame-budget lane. A Siri Remote burst is treated as
    // one focus transaction rather than dozens of unrelated animations. Only the
    // navigation-critical lane is allowed to mutate geometry until focus settles.
    // Crucially, revision is published only on burst begin/end — not every D-pad repeat —
    // so the coordinator itself cannot become another source of root invalidation.
    private(set) var navigationBurstActive: Bool = false
    private(set) var navigationBurstSource: String = "none"
    // vBRDC092: after the navigation lane itself settles, keep only ambient/repeating
    // work frozen for one short recovery beat. Without this phase wallpaper, glow,
    // previews, tickers and deferred image publications all woke on the exact same
    // frame that the row transition reached identity, creating a visible end-of-move hitch.
    private(set) var postNavigationVisualRecoveryActive: Bool = false
    private var navigationBurstGeneration: UInt64 = 0
    private var navigationSettleWorkItem: DispatchWorkItem? = nil
    private var navigationRecoveryWorkItem: DispatchWorkItem? = nil

    private init() {}

    func synchronizeGlobal(
        sceneActive: Bool,
        globalSearchActive: Bool,
        settingsActive: Bool,
        detailActive: Bool,
        fullScreenPlaybackActive: Bool
    ) {
        let next = GlobalContext(
            sceneActive: sceneActive,
            globalSearchActive: globalSearchActive,
            settingsActive: settingsActive,
            detailActive: detailActive,
            fullScreenPlaybackActive: fullScreenPlaybackActive
        )
        guard next != context else { return }
        context = next
        bump()
    }


    /// vBRDC090: register one user-navigation frame-budget burst. Repeated D-pad events
    /// only extend the settle deadline; they do not republish ObservableObject state.
    /// This gives the focused surface exclusive compositor priority while decorative
    /// pulse/wallpaper/ticker/preview work remains frozen.
    func registerNavigationActivity(source: String, settleAfter: TimeInterval = 0.18) {
        let normalized = source.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "unknown" : source
        navigationBurstGeneration &+= 1
        let generation = navigationBurstGeneration
        navigationSettleWorkItem?.cancel()
        navigationRecoveryWorkItem?.cancel()
        navigationRecoveryWorkItem = nil
        let wasRecovering = postNavigationVisualRecoveryActive
        postNavigationVisualRecoveryActive = false
        navigationBurstSource = normalized

        if !navigationBurstActive {
            navigationBurstActive = true
            bump()
        } else if wasRecovering {
            // The navigation burst is already published as active; clearing a stale recovery
            // phase requires no second invalidation because all ambient permits remain denied.
        }

        let work = DispatchWorkItem { [weak self] in
            guard let self, generation == self.navigationBurstGeneration else { return }
            self.navigationSettleWorkItem = nil
            guard self.navigationBurstActive else { return }
            self.navigationBurstActive = false
            self.navigationBurstSource = "none"
            self.postNavigationVisualRecoveryActive = true
            self.bump()

            let recovery = DispatchWorkItem { [weak self] in
                guard let self, generation == self.navigationBurstGeneration else { return }
                self.navigationRecoveryWorkItem = nil
                guard self.postNavigationVisualRecoveryActive else { return }
                self.postNavigationVisualRecoveryActive = false
                self.bump()
            }
            self.navigationRecoveryWorkItem = recovery
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.09, execute: recovery)
        }
        navigationSettleWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + max(0.10, settleAfter), execute: work)
    }

    /// High-churn image/model publishers use this to avoid committing nonessential visual
    /// state in the exact frame a focus move is being resolved by tvOS.
    var shouldDeferNoncriticalVisualPublication: Bool {
        navigationBurstActive || postNavigationVisualRecoveryActive || surfaceHandoffActive || sourceOpeningActive || trailerExclusiveActive || context.fullScreenPlaybackActive
    }

    /// Source Intelligence search is deliberately distinct from source opening.
    /// Searching is compatible with catalog pulse/preview; opening a real stream is not.
    func setSourceIntelligence(searching: Bool, opening: Bool) {
        guard searching != sourceSearchActive || opening != sourceOpeningActive else { return }
        sourceSearchActive = searching
        sourceOpeningActive = opening
        bump()
    }

    func setTrailerExclusiveActive(_ active: Bool) {
        guard active != trailerExclusiveActive else { return }
        trailerExclusiveActive = active
        bump()
    }

    func setGuideActive(_ active: Bool) {
        guard active != guideActive else { return }
        guideActive = active
        bump()
    }

    /// vBRDC081: cross-surface navigation receives an exclusive, very short handoff window.
    /// This prevents the outgoing and incoming heavy animation trees from compositing at once.
    /// It does not alter any saved animation setting; permits resume after focus ownership settles.
    func setSurfaceHandoffActive(_ active: Bool) {
        guard active != surfaceHandoffActive else { return }
        surfaceHandoffActive = active
        bump()
    }

    func resetTransientOwnership() {
        navigationSettleWorkItem?.cancel()
        navigationSettleWorkItem = nil
        navigationRecoveryWorkItem?.cancel()
        navigationRecoveryWorkItem = nil
        navigationBurstGeneration &+= 1
        let changed = sourceSearchActive || sourceOpeningActive || trailerExclusiveActive || guideActive || surfaceHandoffActive || navigationBurstActive || postNavigationVisualRecoveryActive
        sourceSearchActive = false
        sourceOpeningActive = false
        trailerExclusiveActive = false
        guideActive = false
        surfaceHandoffActive = false
        navigationBurstActive = false
        navigationBurstSource = "none"
        postNavigationVisualRecoveryActive = false
        if changed { bump() }
    }

    func allows(_ feature: Feature) -> Bool {
        guard context.sceneActive else { return false }

        // vBRDC081: a tab/surface handoff gets one exclusive compositor/focus window.
        // Alerts and static overlay chrome may remain, but perpetual/card/video-adjacent
        // animation cannot run simultaneously in outgoing and incoming trees.
        if surfaceHandoffActive {
            return feature == .overlayChrome || feature == .alertMotion
        }

        // Full-screen playback owns frame/decoder budget. Only player chrome and the
        // already-approved alert lane may animate on top of it.
        if context.fullScreenPlaybackActive {
            return feature == .playbackChrome || feature == .alertMotion
        }

        // Built-in full trailer owns the same decoder lane before/while it is mounted.
        if trailerExclusiveActive {
            return feature == .playbackChrome || feature == .overlayChrome || feature == .alertMotion
        }

        // Selecting/opening a real link is a decoder handoff. Stop ambient/auxiliary
        // movement before playback begins, not while the user is merely searching.
        if sourceOpeningActive {
            return feature == .overlayChrome || feature == .alertMotion
        }

        // vBRDC090: one focus lane owns geometry during an active Siri Remote burst.
        // Decorative/repeating/media-adjacent motion resumes after the 180 ms settle
        // window. This is intentionally system-wide and independent of Performance Mode.
        if navigationBurstActive {
            switch feature {
            case .catalogFocusArrival, .catalogRowMotion, .liveTVMotion, .guideMotion, .sportsMotion, .overlayChrome, .alertMotion:
                return true
            case .dynamicWallpaper, .catalogPulse, .catalogPreview, .detailTransition, .detailConnector, .sourceIntelligenceMotion, .tickerMotion, .playbackChrome:
                return false
            }
        }

        // vBRDC092: the row has reached its identity transform, but do not wake all
        // perpetual/media-adjacent systems on that same frame. Detail/connector motion
        // remains available so a user can immediately open a card without losing polish.
        if postNavigationVisualRecoveryActive {
            switch feature {
            case .dynamicWallpaper, .catalogPulse, .catalogPreview, .tickerMotion:
                return false
            default:
                break
            }
        }

        switch feature {
        case .dynamicWallpaper:
            return !context.globalSearchActive
                && !context.settingsActive
                && !context.detailActive
                && !guideActive
                && !sourceSearchActive

        case .catalogPreview:
            // Preserve the exact muted preview instance beneath a catalog-origin Details
            // popup. It does not mutate layout geometry and must not be restarted by
            // incremental Source Intelligence result publications.
            return !context.globalSearchActive
                && !context.settingsActive
                && !guideActive

        case .catalogPulse:
            // vBRDC087 animation isolation: the repeat-forever scale transform yields to
            // Media Information/Source Intelligence. This removes a competing geometry/
            // compositing animation from the selected AVPlayer-backed card while the popup
            // is inserting/updating its link panel. It resumes only after Details closes.
            return !context.globalSearchActive
                && !context.settingsActive
                && !guideActive
                && !context.detailActive

        case .catalogFocusArrival, .catalogRowMotion:
            // Navigation motion is catalog-local. Details may remain mounted over the
            // catalog but no hidden row transition should be started from another surface.
            return !context.globalSearchActive
                && !context.settingsActive
                && !guideActive
                && !context.detailActive

        case .detailTransition, .detailConnector:
            return context.detailActive && !context.globalSearchActive

        case .sourceIntelligenceMotion:
            return context.detailActive && !context.globalSearchActive

        case .liveTVMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive

        case .guideMotion:
            return guideActive && !context.globalSearchActive && !context.settingsActive

        case .sportsMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive

        case .tickerMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive && !guideActive

        case .overlayChrome:
            return true

        case .playbackChrome:
            return false

        case .alertMotion:
            return true
        }
    }

    /// Stable diagnostic string used by tests/logs without exposing internal view state.
    var diagnosticSummary: String {
        "scene=\(context.sceneActive ? "active" : "inactive") search=\(context.globalSearchActive) detail=\(context.detailActive) sourceSearch=\(sourceSearchActive) sourceOpening=\(sourceOpeningActive) trailer=\(trailerExclusiveActive) playback=\(context.fullScreenPlaybackActive) guide=\(guideActive) handoff=\(surfaceHandoffActive) nav=\(navigationBurstActive ? navigationBurstSource : "idle") recovery=\(postNavigationVisualRecoveryActive)"
    }

    private func bump() {
        revision &+= 1
        print("[UNITY Animation] revision=\(revision) \(diagnosticSummary)")
    }
}
