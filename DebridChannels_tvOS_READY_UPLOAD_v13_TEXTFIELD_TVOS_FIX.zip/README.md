# Debrid Channels tvOS v13

Ready-to-upload repo package. GitHub Actions recursively extracts the embedded source zip, generates the tvOS Xcode project with XcodeGen, builds unsigned, and uploads the IPA artifact.

v13 fixes tvOS unavailable TextField roundedBorder style and keeps tvOS-safe layout controls.
