# Debrid Channels tvOS v32

Ready-to-upload GitHub repo package.

Run: `00 Build tvOS IPA From Source ZIP`

The artifact should contain three IPA files:
- DebridChannelsTVOS_v32_unsigned_clean.ipa
- DebridChannelsTVOS_v32_adhoc_attempt.ipa
- DebridChannelsTVOS_v32_deep_adhoc_attempt.ipa

Extract the artifact ZIP before uploading an IPA to your signing service.
