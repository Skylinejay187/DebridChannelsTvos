# vBRDC388R3K1F3 — Kingfisher SwiftPM Embed Fix

Version 1.0.1101 / build 1101.

Narrow packaging fix from K1F2. Kingfisher remains pinned at 8.11.0 and remains a Swift Package product dependency of DebridChannelsTVOS. The explicit `embed: true` flag was removed only from the Kingfisher dependency so XcodeGen no longer creates an invalid manual Copy Frameworks entry for the SwiftPM product. AetherPlaybackBridge embedding is unchanged. No playback, artwork runtime, navigation, ambient, timeshift, cache, trailer, or Unity runtime behavior was intentionally changed.
