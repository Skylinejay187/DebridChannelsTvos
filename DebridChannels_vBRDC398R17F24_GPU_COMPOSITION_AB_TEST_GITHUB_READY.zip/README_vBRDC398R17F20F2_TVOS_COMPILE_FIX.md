# vBRDC398R17F20F2 — tvOS recorder compile correction

Base: F20F1, with all existing features and recorder retained.

GitHub Actions log `logs_106615481109.zip` reported SwiftUI `textSelection(.enabled)` unavailable on tvOS in Sources/DebridChannelsTVOSApp.swift. Removed only this unsupported modifier from the recorder report Text.

App version and build remain 1.0.1126 / 1126. This is a source-level compile correction, not a verified successful Xcode build.
