vBRDC398R15F4 — Cover Flow side-poster perspective

Base: vBRDC398R15F3.
Changes: symmetric inward-facing Y-axis rotation of side portrait posters and their matching reflections, 21 degrees at nearest neighbors, increasing 1.8 degrees per depth step, capped at 30 degrees. No change to focused-card 1.5-degree tilt, navigation, poster identities, or artwork pipeline.
Version: 1.0.1119 / build 1119.
Validation: Swift parser only; Xcode/tvOS runtime and smoothness untested.
