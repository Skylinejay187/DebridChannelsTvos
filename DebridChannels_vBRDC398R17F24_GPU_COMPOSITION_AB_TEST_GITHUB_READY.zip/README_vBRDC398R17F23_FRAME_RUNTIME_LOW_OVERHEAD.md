# F23 — low-risk frame runtime overhead reduction

Patched forward from F22. This is an initial controlled performance experiment, not a proven fix for app-wide stutter.

- UnityFrameRevisionWaiterHub avoids constructing a waiter-ID array when no tasks are waiting.
- Per-frame-ownership DEBUG print output is opt-in via SIGNAL_TRACE_UNITY_FRAMES=1, avoiding expensive console work during rapid remote navigation in debug builds.
- No playback, focus, rendering, MediaFlow Light, or Performance Recorder behavior intentionally changed.
- Compare the same 226-second navigation sequence against the F20 baseline (1,388 hitches; 850.4ms worst frame; 375MB peak).
- Full tvOS build and on-device effect remain unverified.
