# vBRDC398R17F7 — Existing Profile Backup Coverage + Active-App Auto Refresh

- Preserves the existing Backup Code, Create/Refresh Backup, Restore Code, Clear Backup interface and server transport.
- Adds explicit backup/restore coverage for Spotlight display mode/rotation/themes and 3D Cover Flow layout, title logo, focus logo, motion, reflections, artwork, hide-title and detail-shift preferences; ambient smoke mode is also allowed on restore.
- Uses the existing protected backup code to update the existing backend profile approximately every 3 hours while app is active. No auto-generated new codes. When app is suspended, tvOS cannot guarantee wakeup; refresh resumes on active app polling (up to 5 minutes).
- Preserves the remote credential vault, manifest metadata, and other profile fields while updating whitelisted settings from local preferences; refreshes favorites portable library.
- Does not add any settings controls. Explicit manual backup/restore remains available.
- Does not claim to back up downloaded media, server entitlements, or all non-UserDefaults app state.
- Caution: Periodic backups reuse the backend's existing restore/save protocol. Concurrent backup operations and credentials in server storage require integration/security review. Full Xcode/tvOS device validation not available here.
