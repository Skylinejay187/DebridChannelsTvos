# vBRDC393 — Media Information original surface restoration

- Restored vBRDC228 catalog artwork background and Media Information popup presentation/layout code into the latest vBRDC393 Phase 2 source.
- Removed the v393 catalog-wide black layering and extra glass mask, outline, elevation shadows, and scale/offset changes that interfered with surface rendering.
- Restored original catalog-origin clear stage backdrop.
- Kept Settings Media Information Glass Transparency 0–100%; its value now adjusts a neutral tint confined to the Media Information popup bounds only, not catalog/Live TV layers. 100% removes added tint; 0% adds maximum tint.
- Preserved Up Next cinematic autoplay, four-minute timing, Resume/Trakt logic and all other v393 source changes.
- Swift syntax parsed on Linux; Xcode/tvOS compile and real-device rendering not verified.

## Test
1. Open catalog → Media Information → Back repeatedly; verify old layout and original focus/scroll, no black overlay or ghosting.
2. Change glass transparency at 0, 65 and 100; confirm only popup tint changes, not catalog surface.
3. Test search/favorites Media Information separately.
4. Verify 4-minute Up Next and second-stage automatic playback, Resume removal, and Trakt confirmation remain functional.
