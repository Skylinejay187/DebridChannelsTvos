# vBRDC393 — Consolidated Phase 2 source test candidate

## Up Next / Auto Next — verify all nine
1. Next episode correctly identified for each series/season.
2. Episode ordering and end-of-season transitions.
3. Up Next appears at the correct point near EOF.
4. Countdown timing and cancel/rearm behavior.
5. Automatic source resolution before handoff.
6. No duplicate episode launches or stale sessions.
7. Graceful handling of unavailable next-episode sources.
8. Auto Next enabled and disabled behavior in Settings.
9. Manual Play Next, Cancel, and natural EOF transitions.

## Continue Watching and Trakt
10. One Resume poster per TV show, even when multiple episodes have progress.
11. Resume poster points to correct episode and timestamp.
12. Long-press Select -> Remove from Continue Watching removes locally, without deleting Trakt history.
13. Separate Delete from Trakt Watch History confirmation; test authorized account, cancelled dialog, failure and refresh. Episode deletion requires episode identity.

## Unity Media Information
14. Settings -> Appearance: Media Information Glass Transparency 0–100% (10% steps), persistence across relaunch.
15. Catalog rows appear beneath the popup without Live TV dashboard ghosting; readable text and buttons.
16. Open/close Media Information without losing catalog focus, scroll position, or artwork.
17. Preview Mirror catalog Signal logo stays hidden, dashboard logo stays unchanged.

## Validation limits
Swift syntax parsing passed for all Sources/*.swift. Xcode/tvOS typechecking, device installation, playback and Trakt network mutation are NOT tested here. Report each item PASS/FAIL with screenshots/logs when possible. Do not consider the phase accepted until device verification.
