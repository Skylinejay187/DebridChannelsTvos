# Signal vBRDC390 — Aether Live Recovery Cooldown Checkpoint

Based exclusively on vBRDC390 Spotlight + Trailer Glass checkpoint.

## Change
- In `Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift`, coalesce duplicate liveSourceReset/audioDelivery retune signals inside the existing 20-second cooldown rather than treating the cooldown as an exhausted recovery budget and immediately publishing a terminal failure.
- Preserve the existing maximum of three actual retunes and source/route ownership checks.

## Validation
- `swiftc -frontend -parse` passed for the modified bridge source.
- ZIP integrity checked after packaging.

## Not completed
- Root-cause H.264/HEVC/MPEG-TS glitch remediation, device tests, complete Kingfisher first-presentation repair, VOD clock/resume drift fix, and full Xcode tvOS build.
- This is not a final release.
