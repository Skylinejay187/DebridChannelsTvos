# vBRDC398R3 — VOD Catalog Cover Flow Source Candidate

Added VOD Player settings → Catalog Appearance: Classic Rows (default), 3D Cover Flow, Portrait/Landscape artwork. Cover Flow renders selected movie/show in the center with up to four side cards per direction, 3D perspective and glow. Retains existing row-level remote navigation, select, long-press and Media Information; does not touch Live TV. Spotlight Hub settings unchanged.

Validation: swiftc frontend parse only, ZIP integrity. Not compiled using Xcode/tvOS SDK, not device-tested. No reflections setting exposed; this is a visual source candidate, not a certified release. Existing 1.0.1111 build version remains unchanged for this R3 source revision.
