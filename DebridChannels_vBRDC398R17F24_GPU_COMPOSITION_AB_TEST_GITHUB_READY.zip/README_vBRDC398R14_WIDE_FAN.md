# Signal tvOS vBRDC398R14 — Wide Cover Flow fan
Base: vBRDC398R13 source; version 1.0.1115, build 1115.
- Cover Flow side poster outer-edge distances expanded by 30% toward the TV edges.
- Side posters angled inward 7° nearest to 11° at farthest; reflected artwork uses same angle.
- Keeps original center focus card, 1.5° center perspective, preview, focus, title, controls.
- Retains R13 black-glass floor and reflection fade.
- No change to Classic Unity catalog geometry or Up Next.
Validation is Swift parser and ZIP integrity only; tvOS build and visual comparison pending.
