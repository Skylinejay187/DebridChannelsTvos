# vBRDC398R16 — 3D Cover Flow controls / media popup restore

Source candidate (not built with Xcode or device tested).

- 3D catalog Media Information popup restores normal catalog Y offset (+126 rather than -140), leaving Classic untouched.
- 3D focused card logo Show/Hide (default Hide), while preview playback remains intact.
- 3D catalog hero themed logo or text-only choice, with existing fallback when no themed logo is available.
- 3D rail motion: Card Push (interactive spring) or Classic Smooth (ease-in-out), defaults Card Push.
- Existing artwork cache, mirrored posters, row selection, navigation and Classic layout retained.

Validation: Linux Swift frontend parse only; Xcode tvOS typecheck, archive and device motion/popup tests still required.
