# vBRDC392 — consolidated Phase 1 source pass

- Preserved prior artwork ownership, reveal recovery and Cast Explorer changes.
- Prevented sparse playback metadata refreshes from clearing previously hydrated poster, backdrop and cast fields.
- Stopped persisting requested seek targets before seek completion; AVPlayer saves after successful seek callback, internal engine uses existing decoder-clock confirmation floor.
- Added duration sanity validation for durable resume checkpoints.
- On foreground return, guard against stale playback presentations, restore VOD media command registration and rehydrate artwork if overlay is visible.
- Retained existing Bluetooth duplicate suppression, AVAudioSession interruption/route observers, Aether lifecycle, and EOF handling.

Important: This is an integrated source patch, not a demonstrated fix on hardware. Some issues (including intermittent audio/remote events and long-session glitches) can only be evaluated using an Xcode build and Apple TV tests.
