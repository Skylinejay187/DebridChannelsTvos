# vBRDC395 Phase 4 — Live TV / AetherEngine stabilization

## Implemented in this source checkpoint
- Coalesce audio-delivery drop and liveSourceReset notifications during the 20-second retune cooldown into a single deferred recovery.
- Revalidate engine identity, generation, URL, and Live TV state before performing deferred retune.
- Respect the three-retune recovery budget at execution time, not when merely queuing a cooldown operation.
- Cancel queued retunes during session teardown and channel changes through the existing stopSession path.

## Validation performed
- Swift frontend syntax parsing of AetherPlaybackBridge.swift: PASS.
- Swift frontend syntax parsing of Sources and TopShelfExtension: PASS (no failures printed).
- ZIP archive integrity: checked during packaging.

## Not yet verified / NOT a completed phase
- Apple TV Xcode build, device playback, HDHomeRun audio and video continuity, FiOS/HLS playback, channel zapping, preview-to-fullscreen transition, timeshift playback, cache teardown, prolonged playback, GPU/CPU performance, audio track selection, and full regression suite.
- No claims of successful on-device testing or complete v395 stabilization are made.

## Regression constraints
- Preserve existing tvOS Unity dashboard, catalogs, Media Information, VOD, and ambient layer lifecycle.
- Preserve Aether timeshift and VOD cache paths; do not remove KSPlayer until the later parity phase.
