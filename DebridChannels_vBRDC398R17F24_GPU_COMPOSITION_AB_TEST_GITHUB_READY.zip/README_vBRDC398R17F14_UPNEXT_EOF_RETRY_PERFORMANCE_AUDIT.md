# vBRDC398R17F14 — Up Next EOF retry and performance investigation

Based strictly on R17F13. Fix: after natural episode EOF, a failed provider lookup now schedules a dedicated bounded retry (2s then 4s, maximum three total attempts) rather than depending on the already-cancelled playback watchdog. The retry is scoped to the current presentation and URL and cancelled when playback resumes, changes, or teardown occurs. It never resolves sources over an actively playing decoder. Existing Up Next UI, episode selection and countdown behavior are preserved.

Performance audit: no speculative GPU or UI changes in this checkpoint. Source has multiple TimelineView/Canvas clocks, dynamic wallpaper engines, retained catalog/live surfaces, image loading and provider decoding on MainActor. These are candidates, not proven runtime causes. Profile repeated Live TV -> catalogs -> media info -> playback -> return using Xcode Instruments SwiftUI, Time Profiler, Animation Hitches and Allocations on real Apple TV. Compare ambient/wallpaper enabled vs disabled, measure main-thread spikes, active player count, and retained views. Do not claim lag resolved until device metrics confirm.

Validation: Swift parser and ZIP integrity only. No Xcode/tvOS compile or Apple TV runtime test.
