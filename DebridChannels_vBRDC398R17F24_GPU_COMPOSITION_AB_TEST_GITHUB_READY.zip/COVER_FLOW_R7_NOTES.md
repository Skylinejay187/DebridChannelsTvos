# vBRDC398R7 — Classic reflections + R6 compilation scope fix

Base: vBRDC398R6.

- Corrects the GitHub Actions reported missing `coverFlowEnabled`, `flowHeroHeight`, `flowReflectionHeight`, and `flowScale` references in the parent catalog view by calculating parent-local layout values.
- Adds dark mirrored/fading cached-artwork reflections to Classic Unity selected landscape card and neighboring portrait cards, without altering Classic navigation, card sizes, or focus actions.
- Leaves Cover Flow's R6 geometry, reflection, and circular navigation intact.
- Validation: Linux swiftc frontend parse and ZIP integrity. No Xcode SDK compile or Apple TV runtime test.
