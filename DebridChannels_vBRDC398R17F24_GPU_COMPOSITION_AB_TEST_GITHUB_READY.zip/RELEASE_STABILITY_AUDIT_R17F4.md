# Signal tvOS release stability checkpoint — vBRDC398R17F4

## Implemented: 3D detail-row snap-back
The Cover Flow rail's -370 pt offset previously used `(selectedDetail != nil || detailPresentationAnchorItem != nil)`. The anchor intentionally persists through focus restoration and can remain set after closing Media Information or returning from playback. Offset now uses `selectedDetail != nil && playbackURL == nil`, so the anchor cannot strand the rail to the left. This does not change the existing anchor's separate focus/artwork restoration behavior, Classic Rows, or the option to enable/disable shift.

## Static inspection findings — not a completed system-wide audit
- Several timer-driven UI update sites are present (e.g. 5.8-second catalog page rotation, 5-second advisor fact rotation, one-second membership screen clock). Some are guarded by visibility; lifecycle ownership and mount behavior need instrumented verification.
- Several `repeatForever` SwiftUI animations exist. Check that inactive surfaces unmount or stop animating, rather than only being visually hidden.
- Several detached background tasks handle artwork and parsing. Review cancellation, image decode budgets, and cache ownership during rapid row scrolling.
- CADisplayLink and heartbeat timers exist; confirm pause/invalidation at all app lifecycle transitions.

## Required before declaring release-ready
1. On-device regression test: 3D shift enabled/disabled; Details > Back; Details > Play > Back; switch catalog rows/tabs; repeat rapidly. Verify offset always returns to zero and focused card remains selected.
2. Instruments: Allocations/Leaks, Time Profiler, Core Animation, Memory Graph, and thermal testing across 30-60 minutes of rapid browsing, Media Information, playback and background/foreground.
3. Compare memory baseline after repeated navigation cycles and verify image cache eviction, preview player teardown, timer/Task cancellation, and inactive ambient surface suspension.
4. Full Xcode build, device smoke test, release signing/entitlements, purchase and backend checks, crash reporting, and TestFlight/release candidate gate.

## Validation scope
`swiftc -frontend -parse Sources/DebridChannelsTVOSApp.swift` passed on Linux. This is syntax parsing only, not tvOS compilation or device testing.
