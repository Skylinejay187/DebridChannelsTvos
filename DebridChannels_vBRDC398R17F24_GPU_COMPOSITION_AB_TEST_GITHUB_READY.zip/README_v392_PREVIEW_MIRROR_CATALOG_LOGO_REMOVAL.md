Preview Mirror catalog logo removal only; Phase 1 v392 changes preserved.
