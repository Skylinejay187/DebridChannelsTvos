# Signal v390 Turbo visual mode checkpoint — NOT FINAL

Adds three persisted visual profiles (Normal, Performance, Turbo), migrating older Balanced/Compatibility settings. The Settings button cycles profiles.

Turbo targets 60 FPS for procedural Live TV wallpaper, up to 30 FPS for CPU-decoded animated image wallpapers, and 60 FPS for two existing app-wide eligible animation timelines (focus/card/ticker surfaces), with faster springs in selected navigation paths. During remote navigation, procedural wallpaper is capped at 30 FPS; inactive wallpaper surfaces remain governed by existing pause/unmount lifecycle. Aether playback frame rates, decoding and image quality are unchanged.

This is a first implementation, NOT a verified fully app-wide 60 FPS mode. Other SwiftUI animations remain system-compositor driven and have not all been individually tuned. A 60 FPS target does not guarantee 60 FPS, and higher procedural rendering costs may cause frame hitches. Requires Xcode compile, on-device Apple TV testing, Instruments hitches/CPU/GPU measurements and regression validation. No claims of measured improvement.
