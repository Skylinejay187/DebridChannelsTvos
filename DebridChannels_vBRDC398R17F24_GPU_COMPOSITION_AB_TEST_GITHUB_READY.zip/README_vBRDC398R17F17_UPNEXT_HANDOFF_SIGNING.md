# vBRDC398R17F17 — Up Next EOF handoff candidate

Base: uploaded vBRDC398R17F16 MediaFlow ATS source, patched forward. MediaFlow ATS and proxy implementation unchanged.

## Targeted source fixes
- Preserve the EOF ownership latch until a playable next episode is committed rather than clearing it as soon as countdown is armed.
- When the countdown expires before the provider finishes resolving a source, preserve the armed countdown and continue bounded post-EOF retries rather than silently disarming autoplay.
- When an asynchronous source becomes ready after countdown expiration, immediately commit the prepared next episode through the existing guarded playback path.
- Respect the user's cancel-auto-next state before arming.
- Preserve 240-second Up Next presentation, current cinematic visuals, episode discovery, current playback engine, source routing, and the decoder-safe policy forbidding expensive source resolution during active playback.
- Bump tvOS app and TopShelf extension versions to 1.0.1122 (build 1122); release ID vBRDC398R17F17. Preserve bundle IDs and signing settings.

## Signulous / updates
An incremented CFBundleVersion and stable bundle ID do not guarantee an install-over-existing update when Signulous signs builds with different certificates or provisioning profiles. Install-over-existing compatibility must be tested using the same distribution/signing identity and bundle ID. The app cannot force an iOS/tvOS native update prompt for sideloaded builds; users may choose whether to install a newly supplied signed IPA. No automatic updater was added.

## Verification limitations
Swift syntax parsing performed using Linux Swift compiler frontend; not an Xcode tvOS compile. No physical Apple TV playback, signing, update/install-over-existing, or scrolling frame-time profiling performed. Smooth-scrolling architectural audit remains a separate performance workstream; this build intentionally avoids speculative broad UI changes while repairing episode handoff.

## Test checklist
1. Episode within 240s of end: Up Next UI appearance and manual Play Next.
2. Natural EOF with automatic playback on, next source ready and delayed: 15s countdown, successful next episode, no duplicates.
3. Automatic playback off and explicit cancellation: no unwanted autoplay.
4. Cross-season next episode; Trakt watched and resume cleared.
5. MediaFlow proxy stream playback and ATS regression.
6. Signulous install-over-existing on second Apple TV with consistent signing certificate/profile; if it fails, capture installation error and signing identifiers.
7. Live TV grid, catalogs, and Cover Flow scrolling on-device.
