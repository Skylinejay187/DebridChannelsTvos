# vBRDC390 Performance Mode checkpoint (not final)

One-click Performance Mode replaces the old Visual Performance preset picker.
On: procedural wallpaper 8 FPS idle / 4 FPS navigation, detail 1; animated image decode 4 FPS.
Off: procedural wallpaper 16 FPS idle / 8 FPS navigation, detail 3; animated image decode 10 FPS.
The prior 18-20 FPS navigation burst escalation is removed. Playback and UI compositor are not frame-capped.
Legacy settings migration: Compatibility=On, Balanced/High Performance=Off. Existing settings storage key preserved.

Source syntax parsed with swiftc -frontend -parse. No tvOS SDK/Xcode compilation, hardware profiling or Apple TV runtime testing performed.
Previous v390 EPG/artwork/Spotlight/trailer/live recovery checkpoints retained.
Remaining artwork, VOD resume and full release validation pending.
