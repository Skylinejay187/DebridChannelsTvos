# vBRDC390 Floating Media Information checkpoint (NOT FINAL)

Changes from unified profiles checkpoint:
- Media Information popup: subtle compositor shadow / cyan depth treatment, keeping current connector, panel size, focus, source panel, and animation structure unchanged.
- Move existing Media Information top bar (logo, metadata, description) up 8 points without moving the connector or lower controls.

Preserved: unified Normal / Performance / Turbo profile source changes and other inherited v390 work.

Validation: Swift frontend syntax parse of main app source; ZIP integrity. Not an Xcode compile or device UI test.

Still outstanding: hardware layout check (including long synopsis), themed logo/artwork reliability, Kingfisher integration, full app-wide profile wiring, VOD resume, Up Next, Aether-only cleanup, customer-facing build-history cleanup, release tests.
