Debrid Channels tvOS v28 layout merge. v14 structure baseline without boxed hero, with catalog/settings wiring preserved. Upload repo contents to GitHub and run Actions.
