# Debrid Channels tvOS Build From ZIP

Upload this repo contents to GitHub or upload only the source zip plus the workflow file.

Workflow builds an unsigned tvOS IPA artifact from `source_zip/DebridChannelsTVOS_Source_BuildReady.zip`.
