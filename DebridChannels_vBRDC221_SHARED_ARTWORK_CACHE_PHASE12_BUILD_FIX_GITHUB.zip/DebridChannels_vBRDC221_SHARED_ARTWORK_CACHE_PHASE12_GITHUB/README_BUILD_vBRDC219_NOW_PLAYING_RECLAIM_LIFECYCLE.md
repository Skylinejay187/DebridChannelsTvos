# Debrid Channels vBRDC219 — Now Playing Reclaim Lifecycle

Release: **vBRDC219**  
Marketing version: **1.0.922**  
Build: **922**

## Purpose

Hardware/Home Assistant testing of vBRDC217/vBRDC218 proved that the Now Playing metadata path itself works: the first movie publishes title, artwork, progress, playback state, and Bluetooth transport correctly, and exiting correctly returns the Apple TV entity to Idle. The remaining failure was lifecycle-specific: a second playback in the same app process could remain Idle until Debrid Channels was force-closed and relaunched.

## Root cause addressed

`MPNowPlayingSession` exposes a request to become active, but the retained Debrid ownership graph had no explicit inverse claim path. Previous builds cleared both Now Playing centers and deactivated `AVAudioSession`, yet retained the silent AVQueuePlayer, AVPlayerLooper, MPNowPlayingSession, and the session-scoped MPRemoteCommandCenter targets. A later playback could therefore trust an in-process `session.isActive` state even after the system MediaRemote publication had already gone Idle.

## vBRDC219 fix

* A completed playback is now a hard MediaRemote ownership boundary.
* The departing session clears session-scoped and default Now Playing information, stops the 10-second heartbeat, and still reports Idle immediately.
* Session-scoped remote-command targets are removed while the process-wide `MPRemoteCommandCenter.shared()` registration is retained. This preserves the Bluetooth route already proven on hardware.
* The old MPNowPlayingSession is detached from its silent AVQueuePlayer, then the session, looper, and player are discarded.
* The default-center fallback flag is reset between playbacks instead of becoming sticky for the process lifetime.
* The next movie, episode, or Live TV playback creates a fresh silent AVQueuePlayer + MPNowPlayingSession ownership pair.
* Command-center registrations are reconciled on every playback claim so the newly-created session receives fresh targets and the released session is not retained indirectly.
* New ownership explicitly requires `becomeActiveIfPossible` even if a session object reports `isActive`; that fast path is trusted only after the current ownership epoch has successfully claimed MediaRemote.
* App/audio/media-service reassertions also force a fresh system activation request before metadata is considered restored.
* After activation succeeds, the complete Now Playing dictionary is published again, preserving the vBRDC217 Home Assistant metadata/artwork heartbeat behavior.

## Preserved behavior

The vBRDC217 Home Assistant metadata implementation, artwork loading, 10-second heartbeat, movie/TV/live classification, vBRDC216/vBRDC218 catalog behavior, working Bluetooth Play/Pause route, universal Stremio addon fan-out, vBRDC212 Source Intelligence/catalog fast paths, and vBRDC211 Trakt restore/resync behavior remain in place.

## Validation scope

Static validation can prove source integrity, release identity, lifecycle contracts, and Swift syntax parsing. A physical Apple TV remains authoritative for MediaRemote/Home Assistant behavior, and GitHub Actions/Xcode remains authoritative for a full tvOS SDK compile.
