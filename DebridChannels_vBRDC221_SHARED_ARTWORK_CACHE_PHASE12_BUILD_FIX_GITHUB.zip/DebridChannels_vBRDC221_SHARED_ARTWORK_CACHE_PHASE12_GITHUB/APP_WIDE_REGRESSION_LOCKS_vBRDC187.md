# vBRDC187 Regression Locks

These behaviors are intentional and should not be regressed by later playback/catalog work.

1. The in-player Home / Movies / TV Shows catalogs do not render a separate top capsule/header bar. The catalog itself is the surface; MENU/Back exits through the existing playback catalog close callback.
2. While Live TV or VOD playback remains active, the visible focused-card themed logo is foreground playback artwork and is allowed to publish.
3. Playback catalog clearlogos are media-identity + logo-URL scoped and must never retain a previous title's clearlogo after focus moves to a different item.
4. The large hero clearlogo follows the same identity-strict playback rule.
5. Normal Home/Movies/Shows browsing outside playback keeps the established retained-frame continuity policy.
6. Do not solve logo correctness by re-enabling catalog trailer previews, background hero enrichment, or broad catalog prefetch during active playback.
