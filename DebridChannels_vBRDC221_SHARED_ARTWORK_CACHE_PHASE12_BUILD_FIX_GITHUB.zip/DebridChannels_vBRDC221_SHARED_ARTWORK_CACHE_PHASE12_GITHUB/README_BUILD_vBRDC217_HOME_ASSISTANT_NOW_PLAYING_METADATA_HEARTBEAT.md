# Debrid Channels vBRDC217 — Home Assistant / Now Playing metadata hardening

Release: **vBRDC217**  
Marketing version: **1.0.920**  
Build: **920**  
Donor/source of truth: packaged **vBRDC216** only.

## Why this build exists

vBRDC216 confirmed the Bluetooth/headphone Play/Pause transport path was finally working, but tvOS Now Playing / Home Assistant metadata still was not visible reliably. vBRDC217 therefore leaves the working Bluetooth transport ownership intact and changes only the MediaRemote metadata publication lifecycle plus release metadata.

## Now Playing fixes

- Every Now Playing dictionary publication is executed on the main thread.
- When `MPNowPlayingSession` exists, its `nowPlayingInfoCenter` is published first because tvOS treats the session-scoped center as authoritative; the same snapshot is mirrored to `MPNowPlayingInfoCenter.default()` for compatibility.
- The complete metadata snapshot is re-published immediately after `becomeActiveIfPossible` actually succeeds. Earlier builds could publish before activation and never re-publish after ownership was granted.
- If tvOS reports that the synthetic anchor session cannot become active, or explicitly rejects activation, the app drops the rejected `MPNowPlayingSession` and falls back to the standard custom-player path: the already-working muted AVPlayer/audio-session anchor + `MPRemoteCommandCenter.shared()` + `MPNowPlayingInfoCenter.default()`.
- On fallback, secondary session command targets are removed so the rejected session can deallocate; the working shared Bluetooth command center remains installed.
- VOD and Live TV now publish concrete `MPMediaItemPropertyMediaType` values instead of overwriting them with `.anyVideo`:
  - movie -> `.movie`
  - episode/show -> `.tvShow`
  - Live TV -> `.tvShow` plus `MPNowPlayingInfoPropertyIsLiveStream = true`
- `MPNowPlayingInfoPropertyMediaType` remains `.video` as required by the Now Playing API.
- Existing title, artist/subtitle, album label, elapsed time, duration, playback rate, progress, external content ID, asset URL, queue identity and service identifier are preserved.
- Live TV metadata refresh no longer forces playback rate back to 1.0 when the real player is paused.
- A process-level 10-second MediaRemote heartbeat re-publishes a fresh elapsed-time snapshot. The existing VOD decoder clock still provides the authoritative ~5-second elapsed updates; Live TV is extrapolated from its last real timing anchor so Home Assistant/pyatv does not see an unchanged stale position for long-running playback.

## Artwork

- VOD: landscape artwork first, poster fallback.
- Live TV: current program artwork first, channel icon fallback, then item artwork.
- Artwork is converted to a real `MPMediaItemArtwork` backed by a decoded `UIImage`.
- Artwork is generation-owned by the active playback presentation, so a late image response from an old episode/channel cannot overwrite the new item.
- Now Playing artwork has its own small 24 MB / 8-image cache and does not touch the app's catalog artwork cache.
- TMDB Now Playing requests are capped to `w780` and decoded to at most 1280 pixels.
- Artwork network work starts only after the real player reports first frame, preserving playback startup priority.

## Preserved work

- vBRDC216 fixed-slot instant main Home/Movies/TV Shows vertical row swaps remain unchanged.
- vBRDC214 Bluetooth ownership hardening and silent anchor behavior remain unchanged during normal session operation.
- Universal all-addon Stremio source fan-out remains unchanged.
- vBRDC212 Source Intelligence and catalog fast-loading paths remain unchanged.
- vBRDC211 Trakt restore/resync behavior remains unchanged.
- Resources are byte-for-byte identical to vBRDC216.

## Validation performed in this environment

- 68/68 production Swift files parsed successfully with `swiftc -parse`.
- App and Top Shelf plists pass `plutil -lint`.
- vBRDC217 contracts: 16 passed.
- vBRDC216 applicable preservation contracts: 10 passed, 1 release-identity test deselected.
- vBRDC214 applicable preservation contracts: 4 passed, 2 historical/changed-contract tests deselected.
- V1041-equivalent app/Top Shelf/project release coherence passes for 1.0.920 (920) / vBRDC217.
- No merge-conflict markers.
- Resources match vBRDC216 byte-for-byte.

A full Xcode/tvOS SDK compile and link cannot be performed in this Linux environment. GitHub Actions/Xcode remains authoritative for compilation, and a physical Apple TV/Home Assistant/pyatv instance remains authoritative for MediaRemote visibility.
