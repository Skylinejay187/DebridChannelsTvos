# Debrid Channels vBRDC210 — System Media / Trakt / Cold Resume Regression Audit

Release: vBRDC210
Marketing version: 1.0.913
Build: 913
Donor/source of truth: vBRDC209 packaged source only.

## Runtime fixes

- Restores the complete tvOS custom-player media ownership contract for VOD and Live TV:
  - MPRemoteCommandCenter Play/Pause/Toggle handlers are installed process-wide.
  - Commands are enabled before playback AVAudioSession activation and reinforced after activation.
  - AVAudioSession uses non-mixable `.playback` / `.moviePlayback` and is reasserted on app/audio lifecycle recovery.
  - `beginReceivingRemoteControlEvents()` is kept active for accessory compatibility.
  - Now Playing publishes explicit video media type, queue identity, timing/rate, service identity, VOD identity, and Live TV state.
  - Live TV claims system media ownership before its decoder is mounted and reasserts after first frame.
  - Bluetooth/media-command notifications now route to both VOD and Live TV full-screen playback.
  - `UIBackgroundModes` contains `audio`.

- Trakt Settings resync is no longer allowed to run before restored Keychain OAuth state is materialized.
  - Manual resync restores the persisted connection first.
  - Account identity is verified.
  - Playback progress is force-refreshed.
  - Resume rows are reprojected immediately without causing a duplicate forced account refresh.

- Cold Resume artwork/themed-logo recovery is deterministic.
  - Resume is reprojected after cold Trakt progress import and after official catalog publication.
  - Up to 12 unresolved Resume entries can use the existing TMDB hero metadata cache in batches of 3.
  - Poster, landscape, and themed logo are handled independently.
  - Resolved visuals are persisted back into the Resume cache.
  - Cold hydration is cancelled whenever full-screen playback owns resources.

## Preserved regression locks

- vBRDC209 post-EOF decoder isolation / Up Next source-resolution rules remain intact.
- Episode Alert scanning and presentation remain eligible during VOD and Live TV.
- Main Movies / TV Shows catalog type boundary remains intact.
- Force Guide bounded indefinite recovery remains intact.
- ATVLoadly `AppIcon-1280x768.png` compatibility alias remains packaged without modifying the canonical layered tvOS icon.
- No `UserDefaults.synchronize()` calls reintroduced.
- Normal Resume checkpoints do not reintroduce >=95% completion/Trakt amplification.

## Local validation

- vBRDC210 regression contracts: 15/15 passed.
- Swift syntax parse: 68/68 files, 0 failures.
- App Swift sources: 67; Top Shelf Swift sources: 1.
- Sources/Info.plist and TopShelfExtension/Info.plist: vBRDC210 / 1.0.913 / 913.
- Resources/Assets.xcassets is byte-identical to vBRDC209.
- No merge-conflict markers in source/project files.

GitHub Actions/Xcode 16.4 / tvOS 18.5 remains the authoritative SDK type-check/build.
