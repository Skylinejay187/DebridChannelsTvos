# Debrid Channels tvOS v1075

Base: v1074
Version: 1.0.603
Build: 603

## Objective

Restore full-width catalog presentation and introduce Movie Mode without replacing or rebuilding the active VOD playback host.

## Full-width catalog rails

- Removes the fixed 12-poster trailing-card cap from the primary Home / Movies / Shows catalog rail.
- Calculates the number of progressively sized portrait cards required to fill the complete tvOS viewport.
- Keeps a two-card render buffer so DPAD movement does not reveal an empty right edge.
- Does not force every item in a 100+ item row to mount at once; catalog paging and loading remain unchanged.

## Focused preview artwork restoration

- Keeps the v1074 audio-isolated preview player mounted after its one-shot preview ends.
- Promotes the focused-card artwork above the dormant preview surface after playback stops.
- Prevents a black preview layer from covering the focused landscape card.

## Movie Mode

Movie Mode is available only during movie or episode playback and keeps the existing VOD player and overlay as the permanent main UI.

### Enabling Movie Mode

- Adds **Movie Mode During VOD Playback** to the existing Settings screen.
- The global toggle controls whether every new VOD session begins with Movie Mode available.
- Adds **Start Movie Mode This Session** inside the current VOD Playback Settings panel for one-session activation without changing the global preference.
- The Movie Mode preference participates in profile backup and restore.

### VOD interaction

- When Movie Mode is active and the normal VOD overlay is hidden, pressing **Down** opens the Movie Mode shelves.
- Left and Right preserve the existing hidden-overlay -30 / +60 second seek behavior.
- Up preserves the existing VOD control drawer behavior.
- Back closes Movie Mode shelves and returns focus to the uninterrupted VOD session.
- The KSPlayer / PlaybackKit render host, clock, audio, subtitle, resume, and timeline state are not recreated when shelves open or close.

### Movie Mode shelves

- Home, Movies, Shows, Live TV, and Settings are presented as a bottom shelf rail rather than a top navigation bar.
- Home, Movies, and Shows use full-width horizontal catalog rows over the active video.
- Selecting a media card opens an in-player confirmation/details layer; the current VOD is not closed until the user explicitly chooses to open the selected title's full media information.
- The Settings shelf can disable Movie Mode for the current session, return to video, or transition to the existing full Settings screen.

### Live TV in Movie Mode

- Live TV appears only after the dedicated Live TV section is selected.
- Uses a transparent five-column grid over the currently playing VOD.
- A Quick Guide information panel follows the focused channel.
- No full guide is mounted in Movie Mode.
- Selecting a channel uses the existing Live TV playback handoff.

## Preserved

- v1074 durable built-in trailer file and trailer-audio EOF isolation.
- Existing VOD overlay, player controls, seek cadence, Source Intelligence, provider mixing, episode alerts, catalogs, search, favorites, Live TV, and Top Shelf behavior.
- Existing normal app mode remains unchanged when Movie Mode is disabled.

## Validation boundary

- All Swift sources pass `swiftc -parse`.
- App and Top Shelf plists parse and match 1.0.603 (603).
- `project.yml` parses and matches the same version/build.
- Backend Python sources compile without writing into the project tree.
- Archive extraction and SHA-256 round-trip validation pass.
- GitHub Actions/Xcode remains the authoritative tvOS compilation gate.
- Physical Apple TV testing is required for DPAD focus, KSPlayer isolation, Movie Mode shelves, and Live TV transition behavior.
