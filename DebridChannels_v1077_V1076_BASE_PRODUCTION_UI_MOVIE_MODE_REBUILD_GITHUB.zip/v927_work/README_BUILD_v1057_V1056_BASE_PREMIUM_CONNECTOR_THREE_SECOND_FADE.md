# Debrid Channels v1057 — Premium Poster Connector + Three-Second Fade

Base: v1056 (1.0.584 / 584)  
Release: v1057 (1.0.585 / 585)

## Requested media-information popup behavior

The connected media-information popup remains fully visible and interactive. Only the line that
connects the focused poster to the popup is temporary:

1. The connector starts from inside the focused poster's upper-right edge.
2. It keeps the existing upward Bezier curvature and clear corridor introduced in v1054, so it
   does not cross the neighboring poster or the large hero logo/media text.
3. It draws/fades in when a new movie or show popup opens.
4. It stays present for three seconds.
5. It then fades out over the same smooth 0.52-second easing used for its appearance. It does not
   retract backward and it does not dismiss, dim, move, or disable the popup.
6. Reusing the popup for a different title cancels the old timer and starts a fresh three-second
   connector window for the newly focused poster.

## Premium connector redesign

The previous bright single stroke and floating endpoint dots were replaced by a restrained
premium treatment:

- brushed-metal/glass orange-platinum-cyan gradient;
- soft wide glass aura behind a crisp 6.2-point core;
- fine white specular edge for definition over bright artwork;
- polished circular socket that makes the line visibly grow out of the focused poster;
- small faceted endpoint at the popup edge instead of a floating round dot;
- preserved poster-origin geometry and endpoint corridor from v1054.

The connector is noninteractive and accessibility-hidden, so it cannot take focus or interfere
with popup controls.

## Preserved

- v1056 trailer full-audio reliability, complete-remux settling, and generation-scoped startup
- v1055 catalog completeness watchdog and manual Debrid Channels catalog reload
- v1054 VOD launch/session/render-surface ownership and stale-close guards
- v1053 TVMaze-first episode-alert verification and snapshot repair
- current connected popup layout, artwork option, focus graph, media information, cast, episodes,
  Source Intelligence, trailer popup, and external-player actions
- Live TV, guide, playback, search, favorites, Top Shelf, backup/restore, and signing identity

## Validation

- all 39 Swift files pass `swiftc -frontend -parse`
- both plists pass `plutil -lint`
- `project.yml` passes YAML parsing
- app, extension, and project versions match 1.0.585 (585)
- static assertions verify independent line visibility, three-second cancellation-safe timer,
  popup persistence, fade-only close, poster-origin geometry, premium layers, and preserved v1053–v1056 fixes
- ZIP extraction and full-file round-trip hash verification are recorded in
  `VALIDATION_RESULTS_v1057.json`

GitHub Actions remains the authoritative full tvOS SDK compile/archive gate. Physical Apple TV
review remains the final confirmation of the visual timing and appearance.
