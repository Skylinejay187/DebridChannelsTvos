# App-wide regression locks — vBRDC201

1. Main Movies must project only movie rows/items; main TV Shows must project only series/show rows/items.
2. Main catalog filtering follows the active/presented category, never a stale hidden-shell retention tab.
3. Home keeps the mixed movie + TV catalog behavior.
4. Playback Live TV/VOD Home/Movies/TV Shows catalogs retain their explicit destination filtering and existing behavior.
5. Force Guide supersedes/cancels an older automatic Live TV refresh generation.
6. User-triggered Force Guide may not wait indefinitely on a stale post-sleep transient frame owner.
7. tvOS scene inactivity clears transient navigation/surface/recovery ownership without clearing real playback ownership.
8. Trakt OAuth remains Keychain-backed and is deleted only by explicit Disconnect.
9. vBRDC200 VOD playback handoff/resource-priority fixes remain intact.
10. Approved app icon/assets remain unchanged.
