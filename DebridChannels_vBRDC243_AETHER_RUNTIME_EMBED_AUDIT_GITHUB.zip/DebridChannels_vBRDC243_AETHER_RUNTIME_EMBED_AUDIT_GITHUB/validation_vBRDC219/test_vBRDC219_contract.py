from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()
trakt=(r/'Sources/TraktSyncManager.swift').read_text()
traktcat=(r/'Sources/TraktCatalogService.swift').read_text()
info=(r/'Sources/Info.plist').read_text()
top=(r/'TopShelfExtension/Info.plist').read_text()


def block(start, end):
    i=app.index(start)
    return app[i:app.index(end, i)]


def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.922' in proj
    assert 'CURRENT_PROJECT_VERSION: 922' in proj
    for text in (info, top):
        assert '<string>1.0.922</string>' in text
        assert '<string>922</string>' in text
        assert '<string>vBRDC219</string>' in text
    assert 'private static let appVersion = "1.0.922"' in trakt
    assert 'DebridChannels-tvOS/vBRDC219 TraktCatalog' in traktcat
    assert 'DebridChannels-tvOS/922 UniversalInstantSourceFanout' in cat


def test_release_is_a_hard_mediaremote_ownership_boundary():
    rel=block('func releaseSession(_ sessionID: UUID)', 'private func mutate(')
    assert 'self.stopHeartbeatOnMain()' in rel
    assert 'self.nowPlayingSession?.nowPlayingInfoCenter.nowPlayingInfo = nil' in rel
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = nil' in rel
    assert 'dropSessionScopedCommandCentersForPlaybackRelease()' in rel
    assert 'session.removePlayer(player)' in rel
    assert 'self.nowPlayingSession = nil' in rel
    assert 'self.mediaAnchorLooper = nil' in rel
    assert 'self.mediaAnchorPlayer?.removeAllItems()' in rel
    assert 'self.mediaAnchorPlayer = nil' in rel
    assert 'self.defaultCenterFallbackActive = false' in rel
    assert 'self.requiresFreshSystemMediaClaim = true' in rel
    assert 'setActive(false' in rel


def test_new_anchor_marks_fresh_claim_required():
    prep=block('private func prepareSystemMediaAnchorIfNeededOnMain()', 'private func preparedCommandCentersOnMain')
    assert 'let player = AVQueuePlayer(items: [])' in prep
    assert 'let looper = AVPlayerLooper(player: player, templateItem: templateItem)' in prep
    assert 'let session = MPNowPlayingSession(players: [player])' in prep
    assert 'requiresFreshSystemMediaClaim = true' in prep


def test_activation_does_not_trust_stale_isactive_after_release():
    req=block('private func requestSystemSessionActivationOnMain', 'func reassertCurrentSession')
    assert 'session.isActive && !requiresFreshSystemMediaClaim' in req
    assert 'session.becomeActiveIfPossible' in req
    assert 'self.requiresFreshSystemMediaClaim = false' in req
    assert 'self.publishSnapshotOnMain(snapshot)' in req


def test_lifecycle_reassert_forces_real_reclaim():
    reassert=block('func reassertCurrentSession(reason: String)', 'func claimVODSession(')
    assert 'self.requiresFreshSystemMediaClaim = true' in reassert
    assert 'self.requestSystemSessionActivationOnMain(reason: reason)' in reassert


def test_dynamic_session_command_center_is_reconciled_each_claim():
    install=block('func installIfNeeded()', '/// vBRDC217: if tvOS refuses')
    assert 'refreshCommandCenterRegistrations()' in install
    assert 'DebridNowPlayingManager.shared.remoteCommandCenters()' in install
    assert 'desiredIDs' in install
    assert 'removeCommandRegistration(registration)' in install
    assert 'dropSessionScopedCommandCentersForPlaybackRelease()' in install


def test_release_preserves_shared_bluetooth_command_center_only():
    drop=block('func dropSessionScopedCommandCentersForPlaybackRelease()', '/// vBRDC217: if tvOS refuses')
    assert 'ObjectIdentifier(MPRemoteCommandCenter.shared())' in drop
    assert 'let kept = registrations.filter' in drop
    assert 'removeCommandRegistration(registration)' in drop
    assert 'removeTarget(nil)' not in drop


def test_v217_now_playing_publication_artwork_and_heartbeat_preserved():
    pub=block('private func publishSnapshotOnMain', 'private func ensureHeartbeatOnMain')
    assert 'assert(Thread.isMainThread)' in pub
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in pub
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in pub
    assert pub.index('session.nowPlayingInfoCenter.nowPlayingInfo = info') < pub.index('MPNowPlayingInfoCenter.default().nowPlayingInfo = info')
    hb=block('private func ensureHeartbeatOnMain', 'private func stopHeartbeatOnMain')
    assert 'withTimeInterval: 10.0' in hb
    assert 'publishSnapshotOnMain(snapshot)' in hb
    artwork=block('private func loadArtwork', 'private func synchronizeAnchorPlaybackOnMain')
    assert 'MPMediaItemArtwork(boundsSize: image.size)' in artwork
    assert 'MPMediaItemPropertyArtwork' in artwork


def test_movie_tv_live_classification_preserved():
    enum_block=block('private enum DebridNowPlayingContentKind', 'private enum DebridNowPlayingArtworkURL')
    assert 'case .movie: return .movie' in enum_block
    assert 'case .tvShow, .liveTV: return .tvShow' in enum_block
    live=block('private func publishLiveSession(', 'func releaseSession')
    assert 'MPNowPlayingInfoPropertyIsLiveStream] = true' in live


def test_working_bluetooth_anchor_behavior_preserved():
    anchor=block('private func synchronizeAnchorPlaybackOnMain', 'private func activateDefaultCenterFallbackOnMain')
    assert 'player.pause()' not in anchor
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in anchor
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app


def test_v218_main_catalog_behavior_untouched_by_mediaremote_patch():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'transaction.disablesAnimations = true' in nav
    assert 'activeRowIndex = next' in nav
    assert 'focusedRow = next' in nav
    assert 'verticalRowVisualFocusPinned = true' in nav
    assert 'store.topMenuFocusLocked = true' not in nav


def test_universal_source_and_catalog_fast_paths_preserved():
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in cat
    assert 'sourceLinkMemoryCacheTTL: TimeInterval = 240' in cat
    assert 'sourceManifestMemoryCacheTTL: TimeInterval = 900' in cat
    assert '[1, 3, 8, 20, 45, 90, 180]' in cat


def test_trakt_restore_resync_preserved():
    assert 'manualResyncFromSettings() async -> Bool' in trakt
    assert 'restorePersistedConnectionIfNeeded()' in trakt
    assert '✓ Trakt resync complete' in trakt


def test_background_audio_capability_preserved():
    assert '<key>UIBackgroundModes</key>' in info
    assert '<string>audio</string>' in info


def test_no_merge_conflict_markers():
    for rel in ('Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/TraktSyncManager.swift','Sources/TraktCatalogService.swift','project.yml'):
        text=(r/rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
