# APP-WIDE REGRESSION LOCKS — vBRDC216

vBRDC216 is a narrow correction built from the packaged vBRDC215 source.

## New lock: main catalog vertical playback parity

For Home / Movies / TV Shows main-screen Up/Down navigation:

1. Keep one persistent `GridOSFixedSlotCatalogRail`.
2. Rebind destination row + focus atomically with animations disabled.
3. Do not add a vertical offset, scale, opacity transition, root glide, crossfade, second row tree, or delayed arrival animation.
4. Keep the rail at stable screen coordinates exactly like playback-browse catalogs.
5. Keep `.transition(.identity)` and `.animation(nil, value: activeRowIndex)` on the persistent rail.
6. Decorative preview/hero work may be deferred for frame budget, but the visible row/focus commit must remain immediate.

## Existing locks preserved

- Universal Stremio addon fan-out / first-result publication.
- Source/link and manifest memory caches and fail-fast sessions.
- Main catalog durable/force-load behavior.
- Bluetooth/MediaRemote ownership architecture from vBRDC214.
- Now Playing dual publication from vBRDC214.
- Trakt restore/manual resync and playback synchronization protections.
- Existing top-menu/focus handoff and catalog no-peek behavior.
