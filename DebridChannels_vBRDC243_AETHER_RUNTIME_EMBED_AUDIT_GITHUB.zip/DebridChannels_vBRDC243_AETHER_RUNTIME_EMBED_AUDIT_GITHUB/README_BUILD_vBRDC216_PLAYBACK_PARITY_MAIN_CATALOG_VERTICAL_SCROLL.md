# Debrid Channels vBRDC216 — Playback-Parity Main Catalog Vertical Scroll

Release: **vBRDC216 / 1.0.919 / build 919**

## Why this build exists

The first supplied test video showed the vBRDC215 main Home/Movies/TV Shows catalog moving the entire quick-panel rail vertically during every Up/Down row change. The second supplied VOD playback-catalog video showed the desired behavior: the rail remains physically stable and the destination row replaces the current row immediately in the same fixed slots.

vBRDC215's new 32-point / 240-ms root compositor glide was therefore the wrong visual model. It has been removed rather than tuned.

## vBRDC216 vertical catalog behavior

The main catalog now uses the same vertical presentation strategy already used by `playbackBrowseMode`:

- one persistent `GridOSFixedSlotCatalogRail` only;
- destination row and focus are committed together inside an animation-disabled transaction;
- no second/outgoing row tree is retained;
- no vertical root offset;
- no opacity arrival fade;
- no delayed `DispatchQueue.main.async` animation pass;
- no `withAnimation` vertical row motion;
- `.transition(.identity)` remains on the rail;
- `.animation(nil, value: activeRowIndex)` remains on the rail.

This keeps the card rail, provider title, and next-row hint at stable screen coordinates while Up/Down changes rows immediately.

## Performance protection retained

The vBRDC214 main-catalog frame-budget protection remains. Before a main-screen vertical row change, speculative preview/hero work is cancelled and decorative work is held for 160 ms after the destination row is rebound. This delay is non-visual and does not delay focus or row presentation.

## Preserved contracts

- vBRDC214 universal Stremio stream-addon fan-out remains active for every configured stream addon.
- vBRDC214 shared `MPRemoteCommandCenter` + dual Now Playing publication remains intact.
- vBRDC211 Trakt restore/resync behavior remains intact.
- vBRDC212 Source Intelligence caches/fail-fast networking and catalog force-load behavior remain intact.
- playback-browse catalogs themselves are not redesigned or changed.

## Validation scope

Linux validation can parse Swift syntax and validate package/release contracts, but it cannot perform the authoritative tvOS Xcode compile/link or hardware-focus/render test. GitHub Actions/Xcode remains authoritative for compilation and the physical Apple TV remains authoritative for final motion feel.
