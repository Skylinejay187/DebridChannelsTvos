# APP-WIDE REGRESSION LOCKS — vBRDC219

1. Do not regress vBRDC217 Now Playing metadata: main-thread publication, session-first + default-center mirror, artwork, media types, playback rate/elapsed updates, and 10-second heartbeat.
2. Exiting a completed movie/show/Live TV session must still clear Now Playing so Home Assistant reaches Idle.
3. Idle must not leave a retained MPNowPlayingSession/AVQueuePlayer/AVPlayerLooper ownership graph that prevents the next playback from claiming MediaRemote.
4. The next playback must build a fresh MPNowPlayingSession anchor and call `becomeActiveIfPossible` for that ownership epoch.
5. `session.isActive` may only skip activation after the current epoch has already completed a successful claim.
6. Retain `MPRemoteCommandCenter.shared()` across release/reclaim because this is the hardware-proven Bluetooth Play/Pause route.
7. Remove only session-scoped command targets when a playback ends; do not globally remove unrelated shared command targets.
8. Keep vBRDC214 muted anchor behavior while a session is owned: real pause state is metadata; the hidden anchor remains playing.
9. Preserve vBRDC217 fallback to `MPNowPlayingInfoCenter.default()` if MPNowPlayingSession cannot activate. The fallback must reset at final playback release so later playback can retry a real session.
10. Do not alter the main catalog scrolling/focus work in vBRDC218 as part of this MediaRemote lifecycle patch.
11. Preserve universal Stremio addon fan-out, Source Intelligence/catalog fast paths, Trakt restore/resync, resources, icon, and bundled media anchor.
