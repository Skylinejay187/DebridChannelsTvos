# Debrid Channels vBRDC190 — Collector Showcase + Player Engine Chip Removal

Release: vBRDC190  
Marketing version: 1.0.893  
Build: 893  
Donor/source of truth: packaged vBRDC189 only.

## Scope

This build makes two targeted VOD/UI changes without changing the vBRDC189 Video Fit system, the fixed mathematically-even VOD control rail, playback engines, or the vBRDC188 icon artwork.

### 1. Player Engine chip removed from the VOD rail

The visible `Player Engine` control is no longer appended to the VOD control descriptors and is removed from secondary rail ordering. The underlying engine implementation, engine panel, AVPlayer/KSPlayer selection logic, compatibility paths, and settings remain present. This is a UI cleanup only.

### 2. Mutually-exclusive Media Information feature slot

The existing right-side Media Information feature area now supports one owner at a time:

- Off
- Production & Ratings
- Collector Showcase

Enabling Production & Ratings disables Collector Showcase. Enabling Collector Showcase disables Production & Ratings. A restore-time normalization also prevents both from surviving enabled together.

## Collector Showcase

Collector Showcase is a visual + factual alternative to Production & Ratings. It uses specialty artwork when the configured providers expose it, with safe fallbacks when they do not.

Visual inputs include:

- Clear-art / movie clear-art
- Character cutout art
- Movie disc art
- Collection/franchise artwork
- Existing key art / title logo fallback

Additional facts include, when available:

- Tagline
- Original title
- Collection/franchise name
- TV creator names

Artwork publication is explicitly allowed for this foreground Media Information surface while VOD playback owns the exclusive playback gate. The specialty art rotation is scoped to the visible panel lifecycle and does not run when Collector Showcase is not displayed.

## Metadata additions

`VODProductionMetadataSnapshot` now carries specialty visual and title-fact fields used only by this optional panel. TMDB detail responses provide the collection/tagline/original-title/creator data. A configured Fanart.tv API key is used for specialty clear-art, character-art, and disc-art requests.

## Preserved behavior

- vBRDC189 fixed/non-scrolling VOD control rail remains intact.
- vBRDC189 Video Fit & Aspect Ratio chip/modes remain intact.
- With Player Engine removed, the maximum 14-control VOD rail gives each control a 126.00 pt slot inside the existing 1800 pt rail; the focused 108 pt chip scales to 116.64 pt and remains inside its slot.
- Playback-engine internals remain intact.
- Live TV is not given the Collector Showcase panel.
- vBRDC188 main icon assets are byte-identical to vBRDC189/vBRDC190.

## Validation

- All 66 Swift source files parse successfully with `swiftc -parse`.
- `VODProductionMetadata.swift` passes standalone `swiftc -typecheck`.
- Main app and Top Shelf plists parse and report 1.0.893 / 893 / vBRDC190.
- `project.yml` parses as YAML and carries 1.0.893 / 893 for both targets.
- Structural checks confirm Player Engine is absent from the visible VOD descriptor rail while its underlying engine code remains.
- Structural checks confirm the Media Information feature modes are mutually exclusive.
- Icon checksums match vBRDC189 exactly.

GitHub Actions/Xcode remains authoritative for a full tvOS SDK compile because this environment does not contain Xcode/tvOS SDKs.
