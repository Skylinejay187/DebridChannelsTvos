from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()
trakt=(r/'Sources/TraktSyncManager.swift').read_text()
traktcat=(r/'Sources/TraktCatalogService.swift').read_text()


def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.919' in proj
    assert 'CURRENT_PROJECT_VERSION: 919' in proj
    for rel in ('Sources/Info.plist','TopShelfExtension/Info.plist'):
        text=(r/rel).read_text()
        assert '<string>1.0.919</string>' in text
        assert '<string>919</string>' in text
        assert '<string>vBRDC216</string>' in text
    assert 'private static let appVersion = "1.0.919"' in trakt
    assert 'DebridChannels-tvOS/vBRDC216 TraktCatalog' in traktcat
    assert 'DebridChannels-tvOS/919 UniversalInstantSourceFanout' in cat


def test_v215_main_only_glide_is_fully_removed():
    assert 'MainCatalogVerticalRowArrivalModifier' not in app
    assert 'verticalCatalogRowMotionPhase' not in app
    assert 'verticalCatalogRowMotionGeneration' not in app
    assert '.offset(y: signedDirection * 32 * remaining)' not in app
    assert '.opacity(0.94 + (0.06 * Double(clampedPhase)))' not in app


def test_main_quick_panel_is_geometrically_fixed_like_playback_browse():
    block=app[app.index('private func catalogQuickPanel'):app.index('@ViewBuilder\n    private func activeCatalogRowPager')]
    assert 'MainCatalogVerticalRowArrivalModifier' not in block
    assert '.modifier(' not in block
    assert 'fixed makes main-catalog Up/Down identical to playback-browse catalog Up/Down' in block


def test_vertical_row_swap_matches_playback_browse_atomic_path():
    block=app[app.index('private func moveQuickPanelRow(_ delta: Int)'):app.index('private func scheduleFirstCardRowEntryFocus')]
    assert 'transaction.disablesAnimations = true' in block
    assert 'activeRowIndex = next' in block
    assert 'focusedRow = next' in block
    assert 'withAnimation(' not in block
    assert 'DispatchQueue.main.async' not in block
    assert 'verticalCatalogRowMotionPhase' not in block
    assert '160_000_000' in block
    assert 'navigationGeneration == verticalCatalogNavigationGeneration' in block


def test_persistent_single_rail_no_peek_contract_preserved():
    rail=app[app.index('private func catalogRail('):app.index('@ViewBuilder\n    private func nextRowTitle')]
    assert '.transition(.identity)' in rail
    assert '.animation(nil, value: activeRowIndex)' in rail
    assert 'GridOSFixedSlotCatalogRail(' in rail


def test_vertical_frame_budget_is_nonvisual_and_short():
    nav=app[app.index('private func registerCatalogNavigation'):app.index('private func handleQuickPanelMove')]
    assert 'case .up, .down:' in nav
    assert 'settleWindow = 0.16' in nav
    assert 'visible row swap is immediate, matching playback-browse' in nav


def test_v214_universal_stremio_fanout_preserved():
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat


def test_v214_system_media_preserved():
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in app
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in app
    block=app[app.index('private func synchronizeAnchorPlaybackOnMain'):app.index('private func requestSystemSessionActivationOnMain')]
    assert 'player.pause()' not in block
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in block


def test_v211_trakt_restore_resync_preserved():
    assert 'manualResyncFromSettings() async -> Bool' in trakt
    assert 'restorePersistedConnectionIfNeeded()' in trakt
    assert '✓ Trakt resync complete' in trakt


def test_v212_source_and_catalog_fast_paths_preserved():
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in cat
    assert 'sourceLinkMemoryCacheTTL: TimeInterval = 240' in cat
    assert 'sourceManifestMemoryCacheTTL: TimeInterval = 900' in cat
    assert 'forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false' in cat
    assert '[1, 3, 8, 20, 45, 90, 180]' in cat


def test_no_merge_conflict_markers():
    for rel in ('Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/TraktSyncManager.swift','Sources/TraktCatalogService.swift','project.yml'):
        text=(r/rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
