# Debrid Channels vBRDC237 — Aether shared FFmpeg graph fix

Release: vBRDC237  
Version: 1.0.940 (940)

## Build failure fixed
vBRDC236 reached Swift package resolution, then Xcode stopped because two packages exported the same FFmpeg module targets (`Libavcodec`, `Libavformat`, `Libavfilter`, etc.):

- KSPNUVIO generated manifest -> kingslay/FFmpegKit
- AetherEngine 5.5.1 -> superuser404notfound/FFmpegBuild

SwiftPM does not allow both copies of those identically-named binary targets in one graph.

## vBRDC237 correction
KSPNUVIO's generated production manifest now consumes the same `superuser404notfound/FFmpegBuild` package as AetherEngine, pinned to exact 2.0.0. KSPNUVIO links the individual Libavcodec, Libavformat, Libavutil, Libswresample, Libswscale and Libavfilter products it needs.

This gives both playback engines one FFmpeg provider/package identity while retaining:

- AetherEngine primary playback, exact 5.5.1
- KSPlayer/KSPNUVIO fallback
- existing zero-delay prepared-source handoff
- resume/progress ownership
- Now Playing and Bluetooth control ownership
- source failover
- VOD overlay and Live TV unity tree
- vBRDC235 Live TV upward-focus correction

No intentional playback/UI behavior change was made beyond the dependency graph repair.
