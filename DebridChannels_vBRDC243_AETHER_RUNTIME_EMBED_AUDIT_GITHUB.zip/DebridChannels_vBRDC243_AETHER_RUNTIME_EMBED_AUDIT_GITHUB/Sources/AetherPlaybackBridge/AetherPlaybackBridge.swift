import Foundation
import UIKit
import Combine
@_implementationOnly import AetherEngine

/// Dynamic-framework boundary between Debrid Channels and AetherEngine.
///
/// The app target intentionally never imports AetherEngine (or AetherLibav*). KSPlayer keeps its
/// original FFmpegKit graph in the app executable, while this framework owns AetherEngine and its
/// namespaced FFmpegBuild graph. Keeping Aether types out of every public signature prevents Clang
/// from merging incompatible FFmpeg C declarations while compiling DebridChannelsTVOS.
@MainActor
public final class AetherPlaybackHostView: UIView {
    public var onPlaybackTimeUpdate: ((Double, Double) -> Void)?
    public var onBufferUpdate: ((Double, Double) -> Void)?
    public var onFirstFrameReady: (() -> Void)?
    public var onPlaybackFailure: ((String) -> Void)?
    public var onPlaybackEnded: (() -> Void)?

    private let playerView = AetherPlayerView()
    private var engine: AetherEngine?
    private var cancellables = Set<AnyCancellable>()
    private var loadTask: Task<Void, Never>?
    private var seekTask: Task<Void, Never>?
    private var generation: UInt64 = 0
    private var duration: Double = 0
    private var currentTime: Double = 0
    private var firstFramePublished = false
    private var failed = false

    public override init(frame: CGRect) {
        super.init(frame: frame)
        bootstrapView()
    }


    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        bootstrapView()
    }

    private func bootstrapView() {
        backgroundColor = .black
        playerView.backgroundColor = .black
        playerView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(playerView)
        NSLayoutConstraint.activate([
            playerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            playerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            playerView.topAnchor.constraint(equalTo: topAnchor),
            playerView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])
    }

    public func load(
        url: URL,
        startTimeSeconds: Double,
        isLiveStream: Bool,
        httpHeaders: [String: String],
        enableDisplayMatch: Bool,
        autoplay: Bool
    ) {
        stopSession(advanceGeneration: true)
        failed = false
        firstFramePublished = false
        duration = 0
        currentTime = 0

        let localGeneration = generation
        do {
            let engine = try AetherEngine()
            self.engine = engine
            engine.bind(view: playerView)
            installObservers(engine: engine, generation: localGeneration)

            let options = LoadOptions(
                httpHeaders: httpHeaders,
                matchContentEnabled: enableDisplayMatch,
                isLive: isLiveStream,
                preferredAudioLanguages: ["en", "eng"],
                autoplay: autoplay
            )
            let requestedStart = isLiveStream ? 0 : max(0, startTimeSeconds)

            loadTask = Task { @MainActor [weak self, weak engine] in
                guard let self, let engine else { return }
                do {
                    try await engine.load(url: url, options: options)
                    guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                    if requestedStart > 0.25 {
                        await engine.seek(to: requestedStart)
                    }
                    guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                    if autoplay { engine.play() } else { engine.pause() }
                } catch is CancellationError {
                    return
                } catch {
                    guard !Task.isCancelled, self.generation == localGeneration else { return }
                    self.publishFailure(error.localizedDescription)
                }
            }
        } catch {
            publishFailure("AetherEngine initialization failed: \(error.localizedDescription)")
        }
    }

    public func seek(to seconds: Double) {
        guard let engine else { return }
        let localGeneration = generation
        seekTask?.cancel()
        seekTask = Task { @MainActor [weak self, weak engine] in
            guard let self, let engine, self.generation == localGeneration else { return }
            await engine.seek(to: max(0, seconds))
        }
    }

    public func play() {
        engine?.play()
    }

    public func pause() {
        engine?.pause()
    }

    public func stop() {
        stopSession(advanceGeneration: true)
    }

    private func stopSession(advanceGeneration: Bool) {
        if advanceGeneration { generation &+= 1 }
        loadTask?.cancel()
        loadTask = nil
        seekTask?.cancel()
        seekTask = nil
        cancellables.removeAll()
        engine?.stop()
        engine = nil
    }

    private func installObservers(engine: AetherEngine, generation observedGeneration: UInt64) {
        engine.$duration
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.duration = value.isFinite ? max(0, value) : 0
                self.onPlaybackTimeUpdate?(self.currentTime, self.duration)
            }
            .store(in: &cancellables)

        engine.clock.$currentTime
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.currentTime = max(0, value)
                self.onPlaybackTimeUpdate?(self.currentTime, self.duration)
            }
            .store(in: &cancellables)

        engine.clock.$bufferedPosition
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.onBufferUpdate?(max(0, value), self.duration)
            }
            .store(in: &cancellables)

        // Preserve the established Debrid Channels launch-cover contract for this integration phase.
        // A later engine-only polish can move this to Aether's stricter first-frame signal without
        // touching the FFmpeg isolation boundary.
        engine.$isSessionReady
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] ready in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration,
                      ready, !self.firstFramePublished else { return }
                self.firstFramePublished = true
                self.onFirstFrameReady?()
            }
            .store(in: &cancellables)

        engine.$state
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] state in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                let value = String(describing: state).lowercased()
                if value.hasPrefix("error") {
                    self.publishFailure("AetherEngine playback error: \(state)")
                } else if value == "ended" {
                    self.onPlaybackEnded?()
                }
            }
            .store(in: &cancellables)
    }

    private func publishFailure(_ message: String) {
        guard !failed else { return }
        failed = true
        onPlaybackFailure?(message)
    }
}
