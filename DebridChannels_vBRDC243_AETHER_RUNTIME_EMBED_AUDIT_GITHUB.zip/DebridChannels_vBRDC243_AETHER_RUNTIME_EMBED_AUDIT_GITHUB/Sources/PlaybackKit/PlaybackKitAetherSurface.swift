import Foundation
import SwiftUI
import UIKit

#if canImport(AetherPlaybackBridge)
import AetherPlaybackBridge

/// vBRDC242: the app talks only to the dynamic AetherPlaybackBridge framework.
/// No AetherEngine or AetherLibav module enters DebridChannelsTVOS, so KSPlayer's
/// independent FFmpegKit declarations cannot collide with Aether's FFmpeg headers.
struct PlaybackKitAetherHost: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let playAssertionSerial: Int
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    var isLiveStream: Bool = false
    var httpHeaders: [String: String] = [:]
    var enableDisplayMatch: Bool = true
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onBufferUpdate: ((Double, Double) -> Void)? = nil
    var onFirstFrameReady: (() -> Void)? = nil
    var onPlaybackFailure: ((String) -> Void)? = nil
    var onPlaybackEnded: (() -> Void)? = nil

    final class Coordinator {
        var currentURL: URL?
        var currentTime: Double = 0
        var lastReloadToken = -1
        var lastSeekSerial = 0
        var lastPlayAssertionSerial = 0
        var lastShouldPlay = false
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> AetherPlaybackHostView {
        let view = AetherPlaybackHostView(frame: .zero)
        view.backgroundColor = .black
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: AetherPlaybackHostView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    static func dismantleUIView(_ view: AetherPlaybackHostView, coordinator: Coordinator) {
        view.stop()
    }

    private func configure(view: AetherPlaybackHostView, coordinator: Coordinator) {
        view.onPlaybackTimeUpdate = { current, duration in
            coordinator.currentTime = current
            onPlaybackTimeUpdate?(current, duration)
        }
        view.onBufferUpdate = onBufferUpdate
        view.onFirstFrameReady = onFirstFrameReady
        view.onPlaybackFailure = onPlaybackFailure
        view.onPlaybackEnded = onPlaybackEnded

        let needsLoad = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken
        if needsLoad {
            coordinator.currentURL = url
            coordinator.currentTime = max(0, startTimeSeconds)
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            coordinator.lastShouldPlay = shouldPlay
            view.load(
                url: url,
                startTimeSeconds: startTimeSeconds,
                isLiveStream: isLiveStream,
                httpHeaders: httpHeaders,
                enableDisplayMatch: enableDisplayMatch,
                autoplay: shouldPlay
            )
            return
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = seekIsAbsolute ? max(0, seekSeconds) : max(0, coordinator.currentTime + seekSeconds)
            view.seek(to: target)
        }

        if playAssertionSerial != coordinator.lastPlayAssertionSerial {
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            view.play()
        }

        if shouldPlay != coordinator.lastShouldPlay {
            coordinator.lastShouldPlay = shouldPlay
            if shouldPlay { view.play() } else { view.pause() }
        }
    }
}
#endif
