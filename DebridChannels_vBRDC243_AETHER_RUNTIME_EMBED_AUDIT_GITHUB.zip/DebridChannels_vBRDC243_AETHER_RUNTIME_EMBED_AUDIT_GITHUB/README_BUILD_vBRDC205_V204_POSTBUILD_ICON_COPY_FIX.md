# Debrid Channels vBRDC205 — v204 post-build icon copy fix

Built directly from vBRDC204.

GitHub/Xcode reached app link successfully in vBRDC204, then failed in the V379 AppIcon post-build phase because the raw ATVLoadly compatibility PNG was not present in the final .app when the validation test ran. vBRDC205 explicitly copies the approved raw fallback icon into the app bundle after actool finishes, validates that the copy is non-empty and byte-identical, and retains the canonical layered tvOS AppIcon.

Release: vBRDC205 / 1.0.908 / build 908.
