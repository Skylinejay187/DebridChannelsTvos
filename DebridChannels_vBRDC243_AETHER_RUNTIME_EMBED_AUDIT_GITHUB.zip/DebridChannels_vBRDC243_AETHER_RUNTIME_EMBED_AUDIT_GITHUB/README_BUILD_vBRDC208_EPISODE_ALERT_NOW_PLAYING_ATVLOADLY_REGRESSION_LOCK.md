# Debrid Channels vBRDC208 — Episode Alert / Now Playing / ATVLoadly Regression Lock

Release: **vBRDC208**  
Marketing version: **1.0.911**  
Build: **911**

Built only from the packaged vBRDC207 source tree.

## Why this build exists

vBRDC207 exposed three regressions/incomplete integrations during physical Apple TV testing:

1. Episode Alerts could render during playback if already queued, but the network heartbeat was explicitly stopped/deferred during VOD. New episodes therefore were not discovered until playback exited.
2. Debrid Channels populated `MPNowPlayingInfoCenter`, but the publication was not sufficiently hardened as a tvOS custom-video Now Playing session for MediaRemote consumers such as Home Assistant/pyatv.
3. The ATVLoadly compatibility PNG was bundled under a filename that ATVLoadly's IPA parser does not recognize as a loose icon candidate.

## Episode Alerts

Episode Alerts are an explicit playback feature and are now regression-locked as such:

- The single configured Episode Alert heartbeat remains eligible during both VOD and Live TV.
- Entering either full-screen VOD or Live TV re-arms that same scheduler if required.
- Playback optimization code may suspend catalog/bootstrap/entitlement/verification work, but may not stop the Episode Alert heartbeat.
- The existing passive in-player `RootNewEpisodeAlertBanner` remains mounted in the VOD/Live TV player ZStack.
- No second playback timer or extra alert polling loop was introduced.
- The old vBRDC200 rule that deferred Episode Alert network scans specifically during VOD is intentionally superseded by this build because it prevented the user-visible alert feature from working in playback.

## tvOS Now Playing / Home Assistant

The shared Debrid Channels Now Playing publisher now supplies a fuller custom-video MediaRemote record:

- title / channel / episode context
- duration
- elapsed playback time
- playback/default rate
- live-stream state
- external content identifier
- asset URL
- `MPNowPlayingInfoPropertyMediaType = video`
- service identifier

`AVAudioSession` is explicitly activated as `.playback` / `.moviePlayback` for both VOD and Live TV claims. The last authoritative Now Playing snapshot is retained and reasserted after app activation, audio-route changes, interruptions and media-services resets.

The shared `MPRemoteCommandCenter` registration is now installed at app-root lifetime rather than waiting for the first VOD session, so Live TV can also establish the custom-player MediaRemote context even when no VOD has played first.

No extra playback polling clock was added. VOD keeps using the existing authoritative decoder clock with its existing throttling; Live TV uses existing EPG/player lifecycle updates.

## ATVLoadly icon

The canonical layered tvOS `AppIcon` asset catalog remains unchanged.

For ATVLoadly/IPA metadata clients, the exact approved raw icon is additionally copied as:

`AppIcon-1280x768.png`

This alias is byte-identical to `DebridChannelsHomeIcon.png` and intentionally follows ATVLoadly's current loose-icon filename parser (`AppIcon...<width>x<height>.png`). The final app post-build phase explicitly copies and validates the alias in the `.app` bundle.

## Preserved vBRDC206/vBRDC207 playback protections

This build does not roll back the Up Next / natural EOF work:

- natural EOF is not treated as a user Pause
- final-clock fallback threshold remains ~0.10s, not ~1.25s early
- Up Next provider work remains buffer-aware (24s / 12s headroom)
- failed provider retries remain backed off 2s / 4s / 8s
- Trakt cloud progress refresh remains deferred until the incoming episode has stabilized

## Regression validation

`validation_vBRDC208/test_vBRDC208_regression_contract.py` locks the cross-feature invariants above so future performance or playback changes cannot silently disable Episode Alerts, strip MediaRemote video metadata, or remove the ATVLoadly-compatible icon alias.
