from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
app=(BASE/'Sources/DebridChannelsTVOSApp.swift').read_text()
push=(BASE/'Sources/DebridNowShowingDirectPushManager.swift').read_text()
sec=(BASE/'Sources/ReleaseCandidateSecurityManager.swift').read_text()
proj=(BASE/'project.yml').read_text()
plist=(BASE/'Sources/Info.plist').read_text()

def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.923' in proj
    assert 'CURRENT_PROJECT_VERSION: 923' in proj
    assert '<string>1.0.923</string>' in plist
    assert '<string>923</string>' in plist
    assert '<string>vBRDC220</string>' in plist

def test_direct_push_source_compiled():
    assert 'Sources/DebridNowShowingDirectPushManager.swift' in proj
    assert 'POST' not in push or 'request.httpMethod = "POST"' in push
    assert '/api/push' in push and '/api/push/verify' in push

def test_playback_hooks():
    for needle in [
        'DebridNowShowingDirectPushManager.shared.claimVOD',
        'DebridNowShowingDirectPushManager.shared.enrichVOD',
        'DebridNowShowingDirectPushManager.shared.updateVODTiming',
        'DebridNowShowingDirectPushManager.shared.publishLive',
        'DebridNowShowingDirectPushManager.shared.updatePlaybackState',
        'DebridNowShowingDirectPushManager.shared.release(sessionID: sessionID)'
    ]:
        assert needle in app

def test_settings_and_restore_pairing():
    assert 'Debrid Now Showing Display' in app
    assert 'debridNowShowingServerURLV1' in app
    assert 'debridNowShowingPushTokenV1' in app
    assert 'debridNowShowingServerURLV1' in sec
    assert 'debridNowShowingPushTokenV1' in sec

def test_v219_now_playing_lifecycle_preserved():
    for needle in [
        'requiresFreshSystemMediaClaim = true',
        'dropSessionScopedCommandCentersForPlaybackRelease()',
        'nowPlayingSession = nil',
        'mediaAnchorPlayer = nil',
        'session.becomeActiveIfPossible'
    ]:
        assert needle in app
