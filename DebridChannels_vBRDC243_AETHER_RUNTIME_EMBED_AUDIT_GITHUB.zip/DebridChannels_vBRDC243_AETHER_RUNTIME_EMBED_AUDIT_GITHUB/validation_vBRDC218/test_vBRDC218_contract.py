from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()
trakt=(r/'Sources/TraktSyncManager.swift').read_text()
traktcat=(r/'Sources/TraktCatalogService.swift').read_text()
info=(r/'Sources/Info.plist').read_text()
top=(r/'TopShelfExtension/Info.plist').read_text()


def block(start, end):
    i=app.index(start)
    return app[i:app.index(end, i)]


def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.921' in proj
    assert 'CURRENT_PROJECT_VERSION: 921' in proj
    for text in (info, top):
        assert '<string>1.0.921</string>' in text
        assert '<string>921</string>' in text
        assert '<string>vBRDC218</string>' in text
    assert 'private static let appVersion = "1.0.921"' in trakt
    assert 'DebridChannels-tvOS/vBRDC218 TraktCatalog' in traktcat
    assert 'DebridChannels-tvOS/921 UniversalInstantSourceFanout' in cat


def test_main_vertical_move_is_one_atomic_no_animation_rebind():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'transaction.disablesAnimations = true' in nav
    assert 'withTransaction(transaction)' in nav
    assert 'selectedIndices[row.id] = 0' in nav
    assert 'activeRowIndex = next' in nav
    assert 'focusedRow = next' in nav
    assert 'withAnimation(' not in nav
    assert 'MainCatalogVerticalRowArrivalModifier' not in app


def test_main_vertical_move_no_longer_publishes_legacy_top_menu_lock():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'store.topMenuFocusLocked = true' not in nav
    assert 'topMenuFocusLocked mutation' in nav


def test_main_vertical_focus_geometry_is_pinned_through_focus_graph_handoff():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'verticalRowVisualFocusPinned = true' in nav
    assert nav.index('verticalRowVisualFocusPinned = true') < nav.index('activeRowIndex = next')
    rail=block('private func catalogRail(', '@ViewBuilder\n    private func nextRowTitle')
    assert 'surfaceHandoffVisualFocusPinned || surfaceHandoffActive || verticalRowVisualFocusPinned' in rail
    card=block('struct FixedSlotFocusedCatalogCard: View', 'struct FixedSlotPreviewCatalogCard: View')
    assert 'private var unfocusedWidth: CGFloat { max(260, cardWidth * 0.82) }' in card
    assert '.offset(y: focused ? -6 + focusArrivalVerticalOffset : 0)' in card


def test_focus_pin_release_is_bounded_and_animation_free():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'verticalFocusPinReleaseTask = Task { @MainActor in' in nav
    assert 'let delays: [UInt64] = [0, 16_000_000, 32_000_000, 64_000_000]' in nav
    assert 'focus.disablesAnimations = true' in nav
    assert 'release.disablesAnimations = true' in nav
    assert 'final.disablesAnimations = true' in nav
    assert 'verticalRowVisualFocusPinned = false' in nav


def test_playback_browse_vertical_path_not_replaced_or_animated():
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'if !playbackBrowseMode {' in nav
    assert 'activeRowIndex = next' in nav
    assert 'focusedRow = next' in nav
    rail=block('private func catalogRail(', '@ViewBuilder\n    private func nextRowTitle')
    assert '.transition(.identity)' in rail
    assert '.animation(nil, value: activeRowIndex)' in rail


def test_v217_now_playing_main_thread_session_first_and_heartbeat_preserved():
    pub=block('private func publishSnapshotOnMain', 'private func ensureHeartbeatOnMain')
    assert 'assert(Thread.isMainThread)' in pub
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in pub
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in pub
    assert pub.index('session.nowPlayingInfoCenter.nowPlayingInfo = info') < pub.index('MPNowPlayingInfoCenter.default().nowPlayingInfo = info')
    hb=block('private func ensureHeartbeatOnMain', 'private func stopHeartbeatOnMain')
    assert 'withTimeInterval: 10.0' in hb
    assert 'publishSnapshotOnMain(snapshot)' in hb


def test_v217_media_types_artwork_and_fallback_preserved():
    enum_block=block('private enum DebridNowPlayingContentKind', 'private enum DebridNowPlayingArtworkURL')
    assert 'case .movie: return .movie' in enum_block
    assert 'case .tvShow, .liveTV: return .tvShow' in enum_block
    artwork=block('private func loadArtwork', 'private func synchronizeAnchorPlaybackOnMain')
    assert 'MPMediaItemArtwork(boundsSize: image.size)' in artwork
    fb=block('private func activateDefaultCenterFallbackOnMain', 'private func requestSystemSessionActivationOnMain')
    assert 'retainSharedCommandCenterOnlyForDefaultNowPlayingFallback()' in fb
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = snapshot' in fb


def test_v214_bluetooth_anchor_and_universal_source_fanout_preserved():
    anchor=block('private func synchronizeAnchorPlaybackOnMain', 'private func activateDefaultCenterFallbackOnMain')
    assert 'player.pause()' not in anchor
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in anchor
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat


def test_v211_trakt_restore_resync_preserved():
    assert 'manualResyncFromSettings() async -> Bool' in trakt
    assert 'restorePersistedConnectionIfNeeded()' in trakt
    assert '✓ Trakt resync complete' in trakt


def test_v212_source_catalog_fast_paths_preserved():
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in cat
    assert 'sourceLinkMemoryCacheTTL: TimeInterval = 240' in cat
    assert 'sourceManifestMemoryCacheTTL: TimeInterval = 900' in cat
    assert 'forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false' in cat
    assert '[1, 3, 8, 20, 45, 90, 180]' in cat


def test_background_audio_capability_preserved():
    assert '<key>UIBackgroundModes</key>' in info
    assert '<string>audio</string>' in info


def test_no_merge_conflict_markers():
    for rel in ('Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/TraktSyncManager.swift','Sources/TraktCatalogService.swift','project.yml'):
        text=(r/rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
