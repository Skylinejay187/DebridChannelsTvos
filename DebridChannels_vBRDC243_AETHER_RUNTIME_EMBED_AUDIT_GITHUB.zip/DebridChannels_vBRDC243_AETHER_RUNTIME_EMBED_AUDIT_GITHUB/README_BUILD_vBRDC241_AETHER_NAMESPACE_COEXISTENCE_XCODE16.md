# Debrid Channels vBRDC241 — Aether namespace coexistence + Xcode 16.4 compatibility

Release: **vBRDC241**  
Version/build: **1.0.944 (944)**

## Root cause fixed
vBRDC240 proved dependency resolution and reached compilation, but KSPlayer was being compiled against Aether's FFmpegBuild 2.0.0 ABI. KSPNUVIO is authored against kingslay/FFmpegKit 6.1.3 and relies on its Swift/C shim surface (`swift_AVERROR_*`, legacy channel-layout helpers, `avcodec_close`, swscale pointer types, and private mux helpers). Patching those one by one would fork KSPlayer's decoder ABI.

AetherEngine 6.57.0 is the upstream release that moved FFmpegBuild to **3.0.0 with Aether-prefixed target/framework/module names specifically so a host can coexist with FFmpegKit/KSPlayer**. vBRDC241 adopts that intended graph:

- KSPlayer/KSPNUVIO -> exact FFmpegKit 6.1.3 (known-good decoder ABI)
- AetherEngine -> exact 6.57.0 source revision `3d9ca508...`
- Aether FFmpeg -> exact namespaced FFmpegBuild 3.0.0 (`AetherLibav*`)
- LibDovi -> exact 2.1.0

## Xcode 16.4 compatibility
The Aether source is vendored during XcodeGen and receives three narrow compile-only guards:

1. AVFoundation imports in the two async media-selection/track-loading files are marked `@preconcurrency` for Xcode 16.4's older Sendable annotations.
2. `AVSampleBufferDisplayLayer.preferredDynamicRange` is compiled only with compiler 6.2+; older SDKs retain Aether's pre-26 behavior.
3. `VTRegisterSupplementalVideoDecoderIfAvailable` is omitted on tvOS where Xcode 16.4 marks it unavailable; the normal hardware capability probe remains.

No Debrid Channels playback policy, resume state, source failover, Now Playing/Bluetooth ownership, Live TV unity tree, focus math, or zero-delay prepared-source handoff was removed.
