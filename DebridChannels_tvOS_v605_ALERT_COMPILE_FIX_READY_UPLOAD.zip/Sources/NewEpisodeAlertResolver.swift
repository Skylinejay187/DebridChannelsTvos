import Foundation

private struct DCGlobalEpisodeOrdinal: Comparable {
    let season: Int
    let episode: Int

    static func < (lhs: DCGlobalEpisodeOrdinal, rhs: DCGlobalEpisodeOrdinal) -> Bool {
        if lhs.season != rhs.season { return lhs.season < rhs.season }
        return lhs.episode < rhs.episode
    }
}

private func dcGlobalFirstRegexMatch(pattern: String, in text: String) -> [String]? {
    guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return nil }
    let range = NSRange(text.startIndex..<text.endIndex, in: text)
    guard let match = regex.firstMatch(in: text, options: [], range: range) else { return nil }
    return (0..<match.numberOfRanges).compactMap { index in
        let matchRange = match.range(at: index)
        guard let swiftRange = Range(matchRange, in: text) else { return nil }
        return String(text[swiftRange])
    }
}

private func dcGlobalEpisodeOrdinal(for item: MediaItem) -> DCGlobalEpisodeOrdinal {
    if let season = item.seasonNumber, let episode = item.episodeNumber {
        return DCGlobalEpisodeOrdinal(season: max(season, 0), episode: max(episode, 0))
    }

    let searchable = [item.id, item.title, item.description]
        .joined(separator: " ")
        .lowercased()

    let patterns = [
        #"s\s*(\d{1,3})\s*e\s*(\d{1,3})"#,
        #"season\s*(\d{1,3}).{0,16}episode\s*(\d{1,3})"#,
        #"(\d{1,3})\s*x\s*(\d{1,3})"#
    ]

    for pattern in patterns {
        if let match = dcGlobalFirstRegexMatch(pattern: pattern, in: searchable), match.count >= 3,
           let season = Int(match[1]), let episode = Int(match[2]) {
            return DCGlobalEpisodeOrdinal(season: season, episode: episode)
        }
    }

    return DCGlobalEpisodeOrdinal(season: item.seasonNumber ?? 0, episode: item.episodeNumber ?? 0)
}

private func dcGlobalEpisodeAlertTitle(showTitle: String, episodeTitle: String?, season: Int, episode: Int) -> String {
    let code = "S\(String(format: "%02d", season))E\(String(format: "%02d", episode))"
    let cleanEpisodeTitle = (episodeTitle ?? "")
        .replacingOccurrences(of: showTitle, with: "")
        .trimmingCharacters(in: CharacterSet(charactersIn: " -–—|\n\t"))
    if cleanEpisodeTitle.isEmpty || cleanEpisodeTitle.lowercased().contains(code.lowercased()) {
        return "\(showTitle) \(code)"
    }
    return "\(showTitle) \(code) — \(cleanEpisodeTitle)"
}

func dcResolvedLatestEpisodeAlertItem(episodes: [MediaItem], show: MediaItem) -> MediaItem {
    let validEpisodes = episodes.filter { episode in
        let ordinal = dcGlobalEpisodeOrdinal(for: episode)
        return ordinal.season > 0 || ordinal.episode > 0
    }

    let latest = validEpisodes.max { lhs, rhs in
        dcGlobalEpisodeOrdinal(for: lhs) < dcGlobalEpisodeOrdinal(for: rhs)
    }

    let chosen = latest ?? show
    let ordinal = latest.map(dcGlobalEpisodeOrdinal(for:)) ?? DCGlobalEpisodeOrdinal(season: max(show.seasonNumber ?? 1, 1), episode: max(show.episodeNumber ?? 1, 1))
    let season = max(ordinal.season, 1)
    let episode = max(ordinal.episode, 1)
    let baseID = show.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? show.title : show.id

    var resolved = MediaItem(
        id: latest?.id ?? "\(baseID):latest:S\(season):E\(episode)",
        title: dcGlobalEpisodeAlertTitle(showTitle: show.title, episodeTitle: latest?.title, season: season, episode: episode),
        year: chosen.year.isEmpty ? show.year : chosen.year,
        type: "series",
        catalog: chosen.catalog.isEmpty ? show.catalog : chosen.catalog,
        description: latest?.description.isEmpty == false ? chosen.description : "Verified new-episode alert resolved from the full series episode list, not the currently highlighted season.",
        genres: chosen.genres.isEmpty ? show.genres : chosen.genres,
        rating: chosen.rating.isEmpty ? show.rating : chosen.rating,
        posterURL: chosen.posterURL ?? show.posterURL,
        landscapeURL: chosen.landscapeURL ?? show.landscapeURL,
        logoURL: chosen.logoURL ?? show.logoURL,
        previewURL: chosen.previewURL ?? show.previewURL,
        addonName: chosen.addonName ?? show.addonName,
        addonIconURL: chosen.addonIconURL ?? show.addonIconURL,
        seasonNumber: season,
        episodeNumber: episode,
        cast: chosen.cast.isEmpty ? show.cast : chosen.cast,
        directors: chosen.directors.isEmpty ? show.directors : chosen.directors,
        castMembers: chosen.castMembers.isEmpty ? show.castMembers : chosen.castMembers
    )
    if resolved.castMembers.isEmpty { resolved.castMembers = show.castMembers }
    if resolved.cast.isEmpty { resolved.cast = show.cast }
    if resolved.directors.isEmpty { resolved.directors = show.directors }
    return resolved
}
