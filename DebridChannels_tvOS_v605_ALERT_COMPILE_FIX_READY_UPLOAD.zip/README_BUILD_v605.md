# v605 Compile Fix

Fixes v604 latest-season alert compile visibility by adding a file-scope NewEpisodeAlertResolver source and registering it in project.yml. Alert behavior remains: choose latest season/highest episode from all fetched episodes, independent of highlighted season.

Backend untouched. Membership, sports, trailer, TVE, backup untouched.
