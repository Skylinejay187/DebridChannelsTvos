# Debrid Channels v987 — VOD Clock Recovery + Second Open Fix

Base: v986.

## Main VOD changes

- Keeps the v986 4K decoded-frame queue at 16 frames.
- Keeps decoder threads at `auto` and asynchronous decompression disabled.
- Disables `isSecondOpen` for main VOD only, matching the KSPNUVIO default and requiring the preferred VOD buffer before the session becomes playable.
- Preserves the one-shot automatic first-frame release and emergency same-position recovery.
- Replaces KSPNUVIO's aggressive main-VOD late-frame recovery with a Debrid VOD-only clock policy:
  - preserves early-frame hold behavior;
  - tolerates brief VideoToolbox/decode spikes;
  - never flushes the decoded queue, drops a GOP, or seeks for ordinary cadence recovery;
  - allows one controlled frame drop only for sustained severe A/V lateness and only when queue headroom exists.
- Adds low-volume diagnostics for controlled cadence drops.
- Pins KSPNUVIO to audited revision `69a73e5e22184c6db254eb2919f81768afb57a81` so upstream cadence behavior cannot change silently between builds.

## Preserved

- Source Intelligence 25/50 visible results.
- Selected source plus three playback fallbacks.
- High-memory 2160p/remux 3-second preferred and 30-second maximum buffer.
- v985 no-IPS memory-pressure protections and playback journal.
- Hardware decoding, frame/dynamic-range matching, audio/subtitle behavior, resume, overlay, trailers, and Live TV.
