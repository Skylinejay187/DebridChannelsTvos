# Debrid Channels v988 — Async Decompression + Stock Clock Recovery

Base: v987.

## Main VOD changes

- Restores `asynchronousDecompression = true` for movies and episodes.
- Removes the v987 Debrid-only `videoClockSync` override and returns main VOD to KSPNUVIO stock A/V clock recovery.
- Keeps `syncDecodeVideo = false`.
- Keeps `syncDecodeAudio = false`.
- Keeps `isSecondOpen = false` so the preferred startup buffer is reached before playback.
- Keeps hardware decoding enabled.
- Keeps decoder threads at `auto`.
- Keeps the 4K decoded-frame queue at 16 frames, 1080p at 24, and lower resolutions at 16.

## Why synchronous decode remains disabled

KSPNUVIO uses `SyncPlayerItemTrack` when either synchronous decode switch is enabled. That couples decoding more tightly to packet consumption instead of using the independent asynchronous track workers. It is intended as a compatibility mode, not a fast-motion enhancement, and can reduce buffering/decode headroom for high-bitrate video or complex audio.

## Preserved

- Source Intelligence 25/50 visible results.
- Selected source plus three playback fallbacks.
- 2160p/remux 3-second preferred and 30-second maximum buffer.
- v985 memory-pressure protections and playback journal.
- One-shot automatic first-frame release.
- Audio/subtitle switching, resume, overlay, frame/dynamic-range matching, trailers, and Live TV.
- KSPNUVIO pinned revision `69a73e5e22184c6db254eb2919f81768afb57a81`.
