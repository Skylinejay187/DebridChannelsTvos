# DebridChannels tvOS v806 — Real Sports Row + Ticker + Advisory Fix

Base: `DebridChannels_tvOS_v805_TICKER_VISIBILITY_SEARCH_SPORTS_MINIMAL_ROW_FIX_READY_UPLOAD.zip`

Scoped changes only:

- Moved Movies/Shows release ticker and global sports ticker slightly higher above the top-right Live TV card.
- Kept ticker close above the card, with more clearance so it does not touch.
- Kept Sports on the Live TV/Harmony background as a quick-panel overlay, not a fullscreen Sports section.
- Sports now presents only:
  - a small `Sports` quick-panel title
  - one bottom row labeled `Live & Upcoming Games`
- Removed the fullscreen/hero feel from the active Sports surface for this build.
- Made advisory/certification/rating/descriptors refresh per selected title by resetting advisor state on item/title/rating/genre changes and extracting certification/descriptors from the selected media item.

Intentionally untouched:

- playback
- Source Intelligence
- membership
- backend
