# v884 - v883 Base: VOD Mock-Match Geometry + TV Poster + Thin Progress

Base: DebridChannels_v883_V881_BASE_RESTORE_VOD_STATUS_LEFT_THIN_PROGRESS

Scope: VOD overlay only.

Changes:
- TV episode playback now uses the parent show's main portrait poster in the VOD overlay poster slot instead of the episode landscape/still artwork.
- VOD information stage adjusted toward the approved mock-up with fixed visual anchors: poster, title/logo, facts, description, status row, cast wall, and timeline remain mathematically tied to the same lower chrome layout.
- Progress bar is now a thinner mock-up style rail with the white scrubber dot preserved.
- Status chips remain part of the media information group and no standalone white time labels are restored.

Not touched:
- Live TV grid/guide/settings.
- Playback engines and source selection logic, except preserving show-poster artwork for TV episode overlay display.
- Return-focus, scrolling, catalog rows, trailers, Source Intelligence.
