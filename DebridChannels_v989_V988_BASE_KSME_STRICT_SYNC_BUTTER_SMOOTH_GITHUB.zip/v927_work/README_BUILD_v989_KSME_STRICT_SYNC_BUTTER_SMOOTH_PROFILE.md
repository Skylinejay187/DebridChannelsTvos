# Debrid Channels v989 — KSME Strict-Sync Butter-Smooth Profile

Base: v988.

This build applies the user-specified KSPlayer/KSPNUVIO profile without retaining the v988 asynchronous-decode choices.

## Player routing

- `KSOptions.firstPlayerType = KSMEPlayer.self`
- `KSOptions.secondPlayerType = KSMEPlayer.self`
- Existing Debrid Channels stable render host and one-shot main-VOD first-frame release remain.

## Buffering and seek

- Base preferred buffer: 10 seconds
- Base maximum buffer: 30 seconds
- Second Open: enabled
- Accurate seek: enabled
- Seek autoplay: enabled
- Dynamic buffer scaling:
  - buffering/loading: 15 / 45 seconds
  - ready/playing: 8 / 30 seconds

## Decode and synchronization

- Hardware decode: enabled
- Asynchronous decompression: disabled
- Synchronous video decode: enabled
- Synchronous audio decode: enabled
- Decoder threads: `auto`
- Decoder thread type: `slice`
- Full resolution: `lowres = 0`
- Loop filter skipping: `none`
- Decoder framedrop: `1`
- Existing adaptive VOD decoded-frame queue remains:
  - 2160p: 16
  - 1080p: 24
  - lower: 16

## Demux/network options

Applied through each real `KSOptions.formatContextOptions` dictionary:

- `rtsp_transport = tcp`
- `infinite_buffer = 1`
- `fflags = nobuffer`
- `packet-buffering = 1`
- `reorder_queue_size = 1024`
- `buffer_size = 8388608`
- `max_delay = 500000`
- `analyzeduration = 10000000`
- `probesize = 15000000`
- reconnect and 15-second read timeout retained
- Debrid request headers retained

## Display matching

The pinned KSPNUVIO API does not contain the proposed `displayCriteriaFormatDescriptionEnabled` property. Debrid Channels already has the supported tvOS equivalent using `AVDisplayManager.preferredDisplayCriteria`. v989 forces that path for every full-screen VOD session and preserves the existing Live TV display-match route.

## Background behavior

The app uses a custom `KSPlayerLayer` host rather than `IOSVideoPlayerView`, so there is no `backgroundPaused` property to assign. v989 implements the equivalent behavior with tvOS lifecycle observers: pause on background and resume on foreground only when playback was previously requested.

## Live TV

- KSME-only routing and the requested decode/demux profile are applied.
- Automatic interlace detection is enabled.
- `deinterlace = 1` is supplied to the decoder options for Live TV.

## Preserved stability protections

- Source Intelligence still displays 25 or 50 links.
- Active playback still retains only the selected source plus three fallbacks.
- Playback termination journal remains.
- VOD overlay, tracks, resume, catalogs, resolver, and Live TV data/guide systems are unchanged.
