Debrid Channels tvOS v72
- Rolled forward from v66/v71 stable visual base.
- Full-screen media information detail page rebuilt in the requested style: backdrop, pulse logo, metadata, play/trailer/find-links controls, trailer row, actor/info panel.
- Trailer popup added for direct playable preview URLs.
- VOD player shell added with poster/logo/ratings/info overlay.
- Stream lookup added: Load All Stremio JSON sources and query /stream/{type}/{id}.json for links.
- Multi-JSON stack/save/clear/load-all preserved.
- App logo/brand mark preserved.
- Note: previews/trailers require direct MP4/HLS URLs. YouTube trailer IDs or magnet/infoHash-only streams need backend/debrid resolver conversion before Apple AVPlayer can play them.
