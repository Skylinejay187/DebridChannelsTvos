# Debrid Channels vBRDC244 — Xcode-native Aether embed / Signulous compatibility

Release: **vBRDC244**  
Version: **1.0.947 (947)**

## Why this build exists
The vBRDC242 device IPS proved the dynamic Aether bridge itself loaded far enough for dyld to resolve its dependencies, but `AetherLibavcodec.framework` was absent from the application Frameworks directory. vBRDC243 manually copied the runtime frameworks after the normal build. That closed the dyld hole but left a fragile late-injected nested-framework layout for third-party re-signers such as Signulous.

## vBRDC244 correction
The app target now directly declares the exact Aether runtime package products as XcodeGen dependencies with `embed: true` and `codeSign: true`. Xcode therefore generates the normal **Embed Frameworks** / **CodeSignOnCopy** relationships. No post-build script copies or mutates Aether frameworks.

The application still does **not** import AetherEngine or any AetherLib module. Aether imports remain behind `AetherPlaybackBridge`, preserving the KSPlayer/FFmpegKit vs Aether FFmpeg C-header isolation.

Directly embedded runtime products:
- AetherPlaybackBridge.framework
- AetherLibavcodec.framework
- AetherLibavformat.framework
- AetherLibavutil.framework
- AetherLibswresample.framework
- AetherLibswscale.framework
- AetherLibavfilter.framework
- AetherLibdav1d.framework
- AetherLibzimg.framework
- AetherLibzvbi.framework
- Dovi.framework

A read-only post-build audit verifies the complete `@rpath/*.framework` closure in the final app. If Xcode fails to embed any required runtime framework, GitHub Actions fails instead of producing an installable-looking IPA that dyld or tvOS later rejects.

## Regression locks
Aether remains primary with KSPlayer fallback. Resume/progress, prepared-source zero-delay handoff, Now Playing/Bluetooth ownership, failover, previews, VOD/Live TV UI and Live TV focus behavior are unchanged.
