from pathlib import Path
import plistlib
import re

ROOT = Path(__file__).resolve().parents[1]
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
PROJECT = (ROOT / 'project.yml').read_text()
TRAKT = (ROOT / 'Sources/TraktSyncManager.swift').read_text()
TRAKT_CATALOG = (ROOT / 'Sources/TraktCatalogService.swift').read_text()


def test_release_identity_v212():
    assert PROJECT.count('MARKETING_VERSION: 1.0.915') == 2
    assert PROJECT.count('CURRENT_PROJECT_VERSION: 915') == 2
    for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
        with (ROOT / rel).open('rb') as f:
            p = plistlib.load(f)
        assert p['CFBundleShortVersionString'] == '1.0.915'
        assert str(p['CFBundleVersion']) == '915'
        assert p['DebridChannelsReleaseID'] == 'vBRDC212'
    assert 'private static let appVersion = "1.0.915"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC212 TraktCatalog' in TRAKT_CATALOG


def test_source_intelligence_session_is_foreground_fail_fast():
    block = STORE[STORE.index('private static func makeSourceIntelligenceURLSession()'):STORE.index('private func rotateSourceIntelligenceURLSession()')]
    assert 'configuration.timeoutIntervalForRequest = 8' in block
    assert 'configuration.timeoutIntervalForResource = 15' in block
    assert 'configuration.waitsForConnectivity = false' in block
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in block
    assert 'timeoutIntervalForRequest = 35' not in block
    assert 'waitsForConnectivity = true' not in block


def test_source_links_and_manifests_have_bounded_memory_cache():
    for marker in (
        'sourceLinkMemoryCacheTTL: TimeInterval = 240',
        'sourceLinkMemoryCacheLimit = 48',
        'sourceManifestMemoryCacheTTL: TimeInterval = 900',
        'sourceManifestMemoryCacheLimit = 32',
        'rememberStreamLinks(cacheSafeLinks',
        'cachedSourceManifest(for: rawManifest)',
        'rememberSourceManifest(decoded, resolvedURL: candidateURL, rawManifest: rawManifest)',
    ):
        assert marker in STORE
    memory = STORE[STORE.index('func handlePhase7MemoryPressure'):STORE.index('private static func makeSourceIntelligenceURLSession')]
    assert 'sourceLinkMemoryCache.removeAll' in memory
    assert 'sourceManifestMemoryCache.removeAll' in memory


def test_movie_and_series_are_not_cross_queried():
    block = STORE[STORE.index('private func expandedStreamTypes'):STORE.index('private func parsedQuality')]
    assert 'never cross-query movie + series endpoints' in block
    assert 'return value == "movie" || value == "film"' in block
    assert 'return value == "series" || value == "show" || value == "tv" || value == "episode"' in block
    # Old bug appended both to every request regardless of media kind.
    assert 'add("movie")' not in block
    assert 'add("series")' not in block


def test_configure_pages_do_not_steal_first_manifest_request():
    block = STORE[STORE.index('private func manifestURLCandidates(from raw: String)'):STORE.index('private func normalizedStremioBase') ]
    assert 'let isConfigurePage =' in block
    assert 'if !isConfigurePage { add(clean) }' in block
    assert 'if isConfigurePage { add(clean) }' in block
    assert block.index('if !isConfigurePage { add(clean) }') < block.index('else if lower.hasSuffix("/configure")') < block.index('if isConfigurePage { add(clean) }')


def test_manifest_capabilities_skip_impossible_stream_requests():
    block = STORE[STORE.index('private func sourceManifestAllowsStreamRequest'):STORE.index('private func scanSingleSourceAddonProvider')]
    assert 'resource.types' in block
    assert 'resource.idPrefixes' in block
    assert 'manifest.types' in block
    assert 'manifest.idPrefixes' in block
    scan = STORE[STORE.index('private func scanSingleSourceAddonProvider'):STORE.index('func findStreamsForcePopulated')]
    assert 'guard sourceManifestAllowsStreamRequest(type: type, id: streamID, manifest: manifest) else { continue }' in scan


def test_each_provider_is_a_short_independent_latency_race():
    block = STORE[STORE.index('private func scanSingleSourceAddonProvider'):STORE.index('func findStreamsForcePopulated')]
    assert 'manifestTimeout: TimeInterval = mediaFusionHint ? 6.0 : 4.0' in block
    assert 'streamTimeout: TimeInterval = isMediaFusion ? 8.0 : 6.0' in block
    assert 'if appendedFromEndpoint > 0 { break providerPasses }' in block
    # Foreground MediaFusion must not bring back the old 28s + retry delay.
    assert '28.0' not in block
    assert '900_000_000' not in block


def test_provider_fanout_uses_sliding_bounded_concurrency():
    block = STORE[STORE.index('let sourceManifests = prioritizedManifestURLsWithMetadataFallback()'):STORE.index('var xtreamLinks: [StreamLink]')]
    assert 'let maximumConcurrentProviders = min(12, max(1, sourceManifests.count))' in block
    assert 'withTaskGroup(of: SourceAddonScanResult?.self)' in block
    assert 'while let optionalResult = await group.next()' in block
    assert 'nextProviderIndex < sourceManifests.count' in block
    assert 'Showing results now while' in block
    # Fixed chunks recreate a barrier behind one slow provider; v212 uses a refill window.
    assert 'for chunkStart in stride' not in block


def test_identity_hydration_does_not_block_initial_provider_fanout():
    start = STORE.index('func findStreams(for item: MediaItem')
    block = STORE[start:STORE.index('let additiveFebBoxAllowed', start)]
    assert 'let inSResolverTask: Task<MediaItem, Never>?' in block
    assert 'activeInSResolverTask = inSResolverTask' in block
    assert 'let inSResolverItem = await inSResolverReadyItem(item)' not in block
    ui = APP[APP.index('// vBRDC212: race providers immediately with the identity already on screen.'):]
    ui = ui[:ui.index('case .episodes:')]
    assert ui.index('let resolverTask = Task') < ui.index('let fastResult = await store.findStreamsForcePopulated')
    assert 'let resolverItem = await resolverTask.value' in ui
    assert 'resolverTask.cancel()' in ui


def test_first_source_is_interactive_before_full_scan_finishes():
    block = APP[APP.index('.onChange(of: store.streamLinks.count)'):APP.index('.onChange(of: sourcePanelVisible)')]
    assert 'count > 0, sourcePanelVisible, isFindingLinks' in block
    assert 'if case .sourceProvider = focus' in block
    assert 'focus = .stream(0)' in block


def test_find_links_no_longer_sleeps_and_repeats_entire_scan():
    start = APP.index('case .findLinks, .searchLinks:')
    main = APP[start:APP.index('case .episodes:', start)]
    assert 'findStreamsForcePopulated' in main
    assert 'Task.sleep(nanoseconds: 650_000_000)' not in main
    assert main.count('findStreamsForcePopulated') <= 2  # exact identity + stronger identity only when needed


def test_auto_play_consumes_first_published_direct_source():
    start = STORE.index('func playFirstDirectStream(for item: MediaItem)')
    block = STORE[start:start + 9000]
    assert 'let searchTask = Task' in block
    assert 'let earlyVisible = streamLinks' in block
    assert 'if let direct = earlyDirect.first' in block
    assert 'Fast source ready.' in block
    assert 'startPlayback(' in block


def test_recovery_identity_amplification_is_bounded():
    block = STORE[STORE.index('func findStreamsForcePopulated'):STORE.index('func cancelCurrentStreamSearch')]
    assert 'for candidate in candidates.prefix(3)' in block
    assert 'candidates.prefix(6)' not in block


def test_catalog_recovery_backoff_starts_quickly():
    assert 'catalogRecoveryRetryDelays: [TimeInterval] = [1, 3, 8, 20, 45, 90, 180]' in STORE


def test_forced_catalog_reload_supersedes_stuck_generation():
    start = STORE.index('func loadAllManifests(forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false)')
    block = STORE[start:STORE.index('cancelCatalogRecoveryRetry(resetAttempt: false)', start)]
    assert 'if forceOfficialRefresh,' in block
    assert 'catalogLifecycleGeneration &+= 1' in block
    assert 'urgent reload superseded active catalog generation' in block


def test_first_catalog_paint_is_not_blocked_by_durable_frame_gate():
    block = STORE[STORE.index('// vBRDC212: never let the frame-budget gate become a catalog availability gate.'):STORE.index('if allInOneCatalogsEnabled {', STORE.index('// vBRDC212: never let the frame-budget gate become a catalog availability gate.'))]
    assert 'if forceOfficialRefresh || !hasVisibleCatalogRows' in block
    assert 'publicationPermitted = true' in block
    assert 'waitUntilPermittedDurably(.interactiveMetadata)' in block


def test_manual_catalog_reload_publishes_fast_then_pages_in_background():
    block = STORE[STORE.index('func reloadDebridChannelsCatalogs()'):STORE.index('func handlePhase7MemoryPressure')]
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: false)' in block
    assert 'Completing long shelves in the background' in block
    assert 'loadAllManifests(forceOfficialRefresh: true, forceCompleteRows: true)' in block


def test_official_manifest_and_batch_do_not_retry_for_tens_of_seconds():
    block = STORE[STORE.index('private func fetchRows(from urlString: String'):STORE.index('private static func isSeriesLikeForEpisodeAlerts')]
    assert '(isOfficialRequest ? 4.5 : 8.0)' in block
    assert 'InstantCatalogManifest' in block
    assert 'fetchCatalogData(request, attempts: 1)' in block
    assert '(isOfficialRequest ? 8.0 : 12.0)' in block
    assert 'InstantCatalogBatchRows' in block


def test_catalog_network_session_does_not_serialize_parallel_recovery():
    block = STORE[STORE.index('private static func makeCatalogFastURLSession()'):STORE.index('private static func makeSourceIntelligenceURLSession()')]
    assert 'configuration.waitsForConnectivity = false' in block
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in block
    fetch = STORE[STORE.index('private func fetchCatalogData'):STORE.index('private func safeCatalogFailureDescription')]
    assert 'Self.catalogFastURLSession.data(for: request)' in fetch
    assert 'URLSession.shared.data(for: request)' not in fetch


def test_catalog_endpoint_fallback_is_parallel_not_83_rows_serial():
    block = STORE[STORE.index('// vBRDC212: if the batch endpoint is unavailable'):STORE.index('let repairedRows = isOfficialRequest', STORE.index('// vBRDC212: if the batch endpoint is unavailable'))]
    assert 'fallbackConcurrency = min(isOfficialRequest ? 12 : 6' in block
    assert 'let tasks: [Task<(StremioCatalog, CatalogResponse?), Never>]' in block
    assert 'InstantCatalogFanout' in block
    assert 'fetchCatalogData(request, attempts: 1)' in block


def test_v211_mediaremote_and_trakt_hardening_remain_present():
    for marker in (
        'let session = MPNowPlayingSession(players: [player])',
        'session.nowPlayingInfoCenter.nowPlayingInfo = info',
        'session.remoteCommandCenter',
        'MPRemoteCommandCenter.shared()',
        '✓ Trakt resync complete •',
    ):
        assert marker in APP or marker in TRAKT
    assert (ROOT / 'Resources/DebridSystemMediaAnchor.m4a').exists()


def test_no_merge_conflict_markers():
    for rel in ('Sources/CatalogStore.swift', 'Sources/DebridChannelsTVOSApp.swift', 'project.yml'):
        text = (ROOT / rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
