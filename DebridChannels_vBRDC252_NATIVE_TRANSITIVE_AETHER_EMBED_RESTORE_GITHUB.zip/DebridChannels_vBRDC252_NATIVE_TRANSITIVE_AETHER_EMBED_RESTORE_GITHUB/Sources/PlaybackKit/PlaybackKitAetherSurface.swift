import Foundation
import SwiftUI
import UIKit
import Darwin

private enum DebridAetherRuntimeEvent {
    static let time = Notification.Name("DebridChannels.Aether.time")
    static let buffer = Notification.Name("DebridChannels.Aether.buffer")
    static let firstFrame = Notification.Name("DebridChannels.Aether.firstFrame")
    static let failure = Notification.Name("DebridChannels.Aether.failure")
    static let ended = Notification.Name("DebridChannels.Aether.ended")
}

/// vBRDC252: Xcode/SwiftPM owns native embedding of the bridge and its transitive Aether
/// frameworks. The app still creates no Aether engine/player object until an Aether playback
/// surface is requested; this preserves standard signed packaging for ATVLoadly/Signulous.
@MainActor
private final class DebridAetherRuntimeLoader {
    static let shared = DebridAetherRuntimeLoader()

    private typealias HostFactory = @convention(c) () -> UnsafeMutableRawPointer?
    private var frameworkHandle: UnsafeMutableRawPointer?
    private var hostFactory: HostFactory?
    private(set) var lastError: String?

    private init() {}

    func makeHostView() -> UIView? {
        guard loadIfNeeded(), let hostFactory else { return nil }
        guard let pointer = hostFactory() else {
            lastError = "AetherPlaybackBridge factory returned no view."
            return nil
        }
        let view = Unmanaged<UIView>.fromOpaque(pointer).takeRetainedValue()
        view.backgroundColor = .black
        return view
    }

    private func loadIfNeeded() -> Bool {
        if frameworkHandle != nil, hostFactory != nil { return true }

        guard let frameworksURL = Bundle.main.privateFrameworksURL else {
            lastError = "The app bundle has no Frameworks directory."
            return false
        }
        let binaryURL = frameworksURL
            .appendingPathComponent("AetherPlaybackBridge.framework", isDirectory: true)
            .appendingPathComponent("AetherPlaybackBridge", isDirectory: false)
        guard FileManager.default.fileExists(atPath: binaryURL.path) else {
            lastError = "AetherPlaybackBridge.framework is missing from the installed app."
            return false
        }

        _ = dlerror()
        guard let handle = dlopen(binaryURL.path, RTLD_NOW | RTLD_LOCAL) else {
            lastError = dlerror().map { String(cString: $0) } ?? "dlopen failed for AetherPlaybackBridge."
            return false
        }
        guard let symbol = dlsym(handle, "DebridAetherCreateHostView") else {
            lastError = dlerror().map { String(cString: $0) } ?? "AetherPlaybackBridge factory symbol is missing."
            dlclose(handle)
            return false
        }

        frameworkHandle = handle
        hostFactory = unsafeBitCast(symbol, to: HostFactory.self)
        lastError = nil
        return true
    }
}

/// Aether surface with late object creation. There is intentionally no `import AetherPlaybackBridge`
/// here; the app communicates through KVC/selectors + NotificationCenter. The framework graph is
/// natively embedded/linked by Xcode, while Aether engine/player objects are created only on demand.
struct PlaybackKitAetherHost: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let playAssertionSerial: Int
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    var isLiveStream: Bool = false
    var httpHeaders: [String: String] = [:]
    var enableDisplayMatch: Bool = true
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onBufferUpdate: ((Double, Double) -> Void)? = nil
    var onFirstFrameReady: (() -> Void)? = nil
    var onPlaybackFailure: ((String) -> Void)? = nil
    var onPlaybackEnded: (() -> Void)? = nil

    @MainActor
    final class Coordinator {
        var currentURL: URL?
        var currentTime: Double = 0
        var lastReloadToken = -1
        var lastSeekSerial = 0
        var lastPlayAssertionSerial = 0
        var lastShouldPlay = false
        var isAetherHost = false
        var observers: [NSObjectProtocol] = []
        var onPlaybackTimeUpdate: ((Double, Double) -> Void)?
        var onBufferUpdate: ((Double, Double) -> Void)?
        var onFirstFrameReady: (() -> Void)?
        var onPlaybackFailure: ((String) -> Void)?
        var onPlaybackEnded: (() -> Void)?

        func installObservers(for view: UIView) {
            removeObservers()
            let center = NotificationCenter.default
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.time, object: view, queue: .main) { [weak self] note in
                guard let self else { return }
                let current = (note.userInfo?["current"] as? NSNumber)?.doubleValue ?? 0
                let duration = (note.userInfo?["duration"] as? NSNumber)?.doubleValue ?? 0
                self.currentTime = current
                self.onPlaybackTimeUpdate?(current, duration)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.buffer, object: view, queue: .main) { [weak self] note in
                let buffered = (note.userInfo?["buffered"] as? NSNumber)?.doubleValue ?? 0
                let duration = (note.userInfo?["duration"] as? NSNumber)?.doubleValue ?? 0
                self?.onBufferUpdate?(buffered, duration)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.firstFrame, object: view, queue: .main) { [weak self] _ in
                self?.onFirstFrameReady?()
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.failure, object: view, queue: .main) { [weak self] note in
                let message = note.userInfo?["message"] as? String ?? "AetherEngine runtime failure."
                self?.onPlaybackFailure?(message)
            })
            observers.append(center.addObserver(forName: DebridAetherRuntimeEvent.ended, object: view, queue: .main) { [weak self] _ in
                self?.onPlaybackEnded?()
            })
        }

        func removeObservers() {
            let center = NotificationCenter.default
            observers.forEach { center.removeObserver($0) }
            observers.removeAll()
        }

    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> UIView {
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onBufferUpdate = onBufferUpdate
        context.coordinator.onFirstFrameReady = onFirstFrameReady
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.onPlaybackEnded = onPlaybackEnded

        guard let view = DebridAetherRuntimeLoader.shared.makeHostView() else {
            let placeholder = UIView(frame: .zero)
            placeholder.backgroundColor = .black
            let message = DebridAetherRuntimeLoader.shared.lastError ?? "AetherEngine runtime bridge could not be loaded."
            DispatchQueue.main.async { onPlaybackFailure?(message) }
            return placeholder
        }

        context.coordinator.isAetherHost = true
        context.coordinator.installObservers(for: view)
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onBufferUpdate = onBufferUpdate
        context.coordinator.onFirstFrameReady = onFirstFrameReady
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.onPlaybackEnded = onPlaybackEnded
        guard context.coordinator.isAetherHost else { return }
        configure(view: view, coordinator: context.coordinator)
    }

    static func dismantleUIView(_ view: UIView, coordinator: Coordinator) {
        if coordinator.isAetherHost {
            performNoArgumentSelector("aetherStop", on: view)
        }
        coordinator.removeObservers()
    }

    private func configure(view: UIView, coordinator: Coordinator) {
        let needsLoad = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken
        if needsLoad {
            coordinator.currentURL = url
            coordinator.currentTime = max(0, startTimeSeconds)
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            coordinator.lastShouldPlay = shouldPlay

            view.setValue(url.absoluteString, forKey: "configuredURLString")
            view.setValue(NSNumber(value: max(0, startTimeSeconds)), forKey: "configuredStartTimeSeconds")
            view.setValue(NSNumber(value: isLiveStream), forKey: "configuredIsLiveStream")
            view.setValue(httpHeaders as NSDictionary, forKey: "configuredHTTPHeaders")
            view.setValue(NSNumber(value: enableDisplayMatch), forKey: "configuredEnableDisplayMatch")
            view.setValue(NSNumber(value: shouldPlay), forKey: "configuredAutoplay")
            Self.performNoArgumentSelector("aetherLoadConfiguredMedia", on: view)
            return
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = seekIsAbsolute ? max(0, seekSeconds) : max(0, coordinator.currentTime + seekSeconds)
            view.setValue(NSNumber(value: target), forKey: "configuredSeekSeconds")
            Self.performNoArgumentSelector("aetherSeekConfiguredPosition", on: view)
        }

        if playAssertionSerial != coordinator.lastPlayAssertionSerial {
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            Self.performNoArgumentSelector("aetherPlay", on: view)
        }

        if shouldPlay != coordinator.lastShouldPlay {
            coordinator.lastShouldPlay = shouldPlay
            Self.performNoArgumentSelector(shouldPlay ? "aetherPlay" : "aetherPause", on: view)
        }
    }

    private static func performNoArgumentSelector(_ name: String, on view: UIView) {
        let selector = NSSelectorFromString(name)
        guard view.responds(to: selector) else { return }
        _ = view.perform(selector)
    }
}
