import Foundation
import UIKit
import Combine
@_implementationOnly import AetherEngine

private enum AetherBridgeNotification {
    static let time = Notification.Name("DebridChannels.Aether.time")
    static let buffer = Notification.Name("DebridChannels.Aether.buffer")
    static let firstFrame = Notification.Name("DebridChannels.Aether.firstFrame")
    static let failure = Notification.Name("DebridChannels.Aether.failure")
    static let ended = Notification.Name("DebridChannels.Aether.ended")
}

/// Dynamic-framework boundary between Debrid Channels and AetherEngine.
///
/// vBRDC252 keeps this bridge under Xcode/SwiftPM native linking + embedding so its transitive
/// Aether runtime frameworks are packaged and signed correctly.
/// Debrid Channels `dlopen`s the signed framework only when an Aether playback surface is
/// actually requested. That keeps AetherEngine + its namespaced FFmpeg graph completely cold
/// while the user is browsing catalogs or the Live TV grid, while KSPlayer keeps its original
/// FFmpegKit graph in the app executable.
@MainActor
public final class AetherPlaybackHostView: UIView {
    // KVC/Objective-C runtime configuration surface. The app intentionally does not import
    // this Swift module, so every runtime command crosses only Foundation/UIKit values.
    @objc public dynamic var configuredURLString: String = ""
    @objc public dynamic var configuredStartTimeSeconds: Double = 0
    @objc public dynamic var configuredIsLiveStream: Bool = false
    @objc public dynamic var configuredHTTPHeaders: NSDictionary = [:]
    @objc public dynamic var configuredEnableDisplayMatch: Bool = true
    @objc public dynamic var configuredAutoplay: Bool = true
    @objc public dynamic var configuredSeekSeconds: Double = 0

    private let playerView = AetherPlayerView()
    private var engine: AetherEngine?
    private var cancellables = Set<AnyCancellable>()
    private var loadTask: Task<Void, Never>?
    private var seekTask: Task<Void, Never>?
    private var generation: UInt64 = 0
    private var duration: Double = 0
    private var currentTime: Double = 0
    private var firstFramePublished = false
    private var failed = false
    private var lastTimeNotificationAt: TimeInterval = 0
    private var lastTimeNotificationValue: Double = -1
    private var lastBufferNotificationAt: TimeInterval = 0
    private var lastBufferNotificationValue: Double = -1

    public override init(frame: CGRect) {
        super.init(frame: frame)
        bootstrapView()
    }

    public required init?(coder: NSCoder) {
        super.init(coder: coder)
        bootstrapView()
    }

    private func bootstrapView() {
        backgroundColor = .black
        playerView.backgroundColor = .black
        playerView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(playerView)
        NSLayoutConstraint.activate([
            playerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            playerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            playerView.topAnchor.constraint(equalTo: topAnchor),
            playerView.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])
    }

    @objc public func aetherLoadConfiguredMedia() {
        guard let url = URL(string: configuredURLString), !configuredURLString.isEmpty else {
            publishFailure("AetherEngine received an invalid playback URL.")
            return
        }
        var headers: [String: String] = [:]
        for (key, value) in configuredHTTPHeaders {
            guard let key = key as? String else { continue }
            headers[key] = String(describing: value)
        }
        load(
            url: url,
            startTimeSeconds: configuredStartTimeSeconds,
            isLiveStream: configuredIsLiveStream,
            httpHeaders: headers,
            enableDisplayMatch: configuredEnableDisplayMatch,
            autoplay: configuredAutoplay
        )
    }

    @objc public func aetherSeekConfiguredPosition() {
        seek(to: configuredSeekSeconds)
    }

    @objc public func aetherPlay() { play() }
    @objc public func aetherPause() { pause() }
    @objc public func aetherStop() { stop() }

    public func load(
        url: URL,
        startTimeSeconds: Double,
        isLiveStream: Bool,
        httpHeaders: [String: String],
        enableDisplayMatch: Bool,
        autoplay: Bool
    ) {
        stopSession(advanceGeneration: true)
        failed = false
        firstFramePublished = false
        duration = 0
        currentTime = 0
        lastTimeNotificationAt = 0
        lastTimeNotificationValue = -1
        lastBufferNotificationAt = 0
        lastBufferNotificationValue = -1

        let localGeneration = generation
        do {
            let engine = try AetherEngine()
            self.engine = engine
            engine.bind(view: playerView)
            installObservers(engine: engine, generation: localGeneration)

            let options = LoadOptions(
                httpHeaders: httpHeaders,
                matchContentEnabled: enableDisplayMatch,
                isLive: isLiveStream,
                preferredAudioLanguages: ["en", "eng"],
                autoplay: autoplay
            )
            let requestedStart = isLiveStream ? 0 : max(0, startTimeSeconds)

            loadTask = Task { @MainActor [weak self, weak engine] in
                guard let self, let engine else { return }
                do {
                    try await engine.load(url: url, options: options)
                    guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                    if requestedStart > 0.25 {
                        await engine.seek(to: requestedStart)
                    }
                    guard !Task.isCancelled, self.generation == localGeneration, self.engine === engine else { return }
                    if autoplay { engine.play() } else { engine.pause() }
                } catch is CancellationError {
                    return
                } catch {
                    guard !Task.isCancelled, self.generation == localGeneration else { return }
                    self.publishFailure(error.localizedDescription)
                }
            }
        } catch {
            publishFailure("AetherEngine initialization failed: \(error.localizedDescription)")
        }
    }

    public func seek(to seconds: Double) {
        guard let engine else { return }
        let localGeneration = generation
        seekTask?.cancel()
        seekTask = Task { @MainActor [weak self, weak engine] in
            guard let self, let engine, self.generation == localGeneration else { return }
            await engine.seek(to: max(0, seconds))
        }
    }

    public func play() { engine?.play() }
    public func pause() { engine?.pause() }
    public func stop() { stopSession(advanceGeneration: true) }

    private func stopSession(advanceGeneration: Bool) {
        if advanceGeneration { generation &+= 1 }
        loadTask?.cancel()
        loadTask = nil
        seekTask?.cancel()
        seekTask = nil
        cancellables.removeAll()
        engine?.stop()
        engine = nil
    }

    private func installObservers(engine: AetherEngine, generation observedGeneration: UInt64) {
        engine.$duration
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                self.duration = value.isFinite ? max(0, value) : 0
                self.publishTimeNotification(force: true)
            }
            .store(in: &cancellables)

        engine.clock.$currentTime
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.currentTime = max(0, value)
                self.publishTimeNotification(force: false)
            }
            .store(in: &cancellables)

        engine.clock.$bufferedPosition
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] value in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration, value.isFinite else { return }
                self.publishBufferNotification(position: max(0, value))
            }
            .store(in: &cancellables)

        engine.$isSessionReady
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] ready in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration,
                      ready, !self.firstFramePublished else { return }
                self.firstFramePublished = true
                NotificationCenter.default.post(name: AetherBridgeNotification.firstFrame, object: self)
            }
            .store(in: &cancellables)

        engine.$state
            .receive(on: RunLoop.main)
            .sink { [weak self, weak engine] state in
                guard let self, let engine, self.engine === engine, self.generation == observedGeneration else { return }
                let value = String(describing: state).lowercased()
                if value.hasPrefix("error") {
                    self.publishFailure("AetherEngine playback error: \(state)")
                } else if value == "ended" {
                    NotificationCenter.default.post(name: AetherBridgeNotification.ended, object: self)
                }
            }
            .store(in: &cancellables)
    }

    private func publishTimeNotification(force: Bool) {
        let uptime = ProcessInfo.processInfo.systemUptime
        let movedEnough = abs(currentTime - lastTimeNotificationValue) >= 0.18
        guard force || movedEnough || uptime - lastTimeNotificationAt >= 0.22 else { return }
        lastTimeNotificationAt = uptime
        lastTimeNotificationValue = currentTime
        NotificationCenter.default.post(
            name: AetherBridgeNotification.time,
            object: self,
            userInfo: ["current": currentTime, "duration": duration]
        )
    }

    private func publishBufferNotification(position: Double) {
        let uptime = ProcessInfo.processInfo.systemUptime
        let movedEnough = abs(position - lastBufferNotificationValue) >= 0.30
        guard movedEnough || uptime - lastBufferNotificationAt >= 0.35 else { return }
        lastBufferNotificationAt = uptime
        lastBufferNotificationValue = position
        NotificationCenter.default.post(
            name: AetherBridgeNotification.buffer,
            object: self,
            userInfo: ["buffered": position, "duration": duration]
        )
    }

    private func publishFailure(_ message: String) {
        guard !failed else { return }
        failed = true
        NotificationCenter.default.post(
            name: AetherBridgeNotification.failure,
            object: self,
            userInfo: ["message": message]
        )
    }
}

/// C ABI factory used by the app after `dlopen`. Returning an opaque retained UIView keeps
/// the app target free of any Swift symbol reference to AetherPlaybackBridge.
@_cdecl("DebridAetherCreateHostView")
public func DebridAetherCreateHostView() -> UnsafeMutableRawPointer {
    let view = MainActor.assumeIsolated { AetherPlaybackHostView(frame: .zero) }
    return Unmanaged.passRetained(view).toOpaque()
}
