# V187 Full Google-Style Shell Rebuild

- Rebuilt the global top navigation into the approved black-glass/Google-style header.
- Replaced old Debrid Channels Premium branding with the new Debrid Channels play-logo mark.
- Reworked the Home visual shell toward the approved mockup: wide cinematic hero, black-glass panels, orange accent focus, Continue Watching row, and poster row layout.
- Preserved the existing app engines underneath: catalog loading, playback, VOD cache path, Live TV source handling, Live TV guide cache TTL, KSPlayer/VLC routing, and invisible native focus hitboxes.
- This is a visual-shell consolidation pass intended to be rollback-safe if the new visual direction needs adjustment.
