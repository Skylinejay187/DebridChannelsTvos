# vBRDC358 — AetherEngine-only migration candidate

Source: vBRDC357.

- Raises Apple TV floor to tvOS 18 for AetherEngine 7.15.0.
- Pins upstream AetherEngine 7.15.0 commit 654d0f2c4411397cf629a9d1eb760aef842e171a.
- Uses AetherEngine upstream FFmpegBuild 3.5.x (FFmpeg n8.1.3).
- Removes KSPlayer SwiftPM dependency, vendored KSPNUVIO tree, KSPlayer playback surface, and KSP dependency fetch/patch scripts.
- Aether is the only compiled internal FFmpeg playback engine.
- Removes Aether->KS runtime fallback; Aether failures now use Signal source failover/error handling.
- Live TV keeps Aether liveSourceReset/recovery and uses modern immediate join with a less brittle probe budget.
- Existing Signal VOD overlay, track menus, resume/Up Next hooks and Aether subtitle overlay remain wired to the same app state.
- Volume amplification presets no longer force an engine handoff. Aether 7.15 public API still exposes 0...1 volume only, so >0 dB amplification remains intentionally non-operative in this candidate until an Aether-native gain stage is implemented.

Physical Apple TV validation required: VOD, Live TV audio continuity, subtitles, track switching, DV/HDR, Atmos/multichannel, seek/resume, Up Next, remote/Bluetooth controls, lifecycle recovery, long-play, cache/DVR/timeshift.
