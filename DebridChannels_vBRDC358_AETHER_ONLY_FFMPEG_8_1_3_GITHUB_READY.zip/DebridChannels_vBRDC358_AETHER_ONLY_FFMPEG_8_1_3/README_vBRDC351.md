# vBRDC351 — Preview Mirror remote navigation repair

Derived exclusively from uploaded vBRDC350 (1.0.1052 / 1052); output 1.0.1053 / 1053.

- Reveal chrome before top-menu focus; fallback Up from GRID.
- Cancellation-aware 15-second auto-hide, refreshed on menu movements/focus.
- Native tvOS footer Select Buttons; focus and layout priority repaired.
- Categories retain production categories and original filtering, with serialized focus handoffs.
- Guide and Options use existing full Guide and existing Settings.
- Golden, playback, geometry and lifecycle behavior retained.

Parsing is not an Xcode/tvOS SDK compile. Device verification pending.
