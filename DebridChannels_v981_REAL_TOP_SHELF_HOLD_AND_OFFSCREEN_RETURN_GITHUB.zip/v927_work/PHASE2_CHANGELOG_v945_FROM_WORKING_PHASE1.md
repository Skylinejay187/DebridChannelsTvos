# Debrid Channels v945 — PlaybackKit Phase 2

Authoritative base: confirmed-working `DebridChannels_v944_PLAYBACKKIT_PHASE1_FROM_V943_GITHUB.zip`.

## Scope

- Activated the existing `OverlayBridge` as the dedicated overlay-facing PlaybackKit publication lane.
- Connected the bridge only for non-Live-TV VOD sessions.
- Synced bridge visibility with the existing VOD controls/panel visibility.
- Disconnected the bridge during VOD teardown.
- Kept the original v943 overlay clock and all existing UI state authoritative; the bridge is passive in this phase.

## Explicitly unchanged

- KSPlayer and FFmpeg decoder configuration
- Player/render host ownership and lifecycle
- `KSPlayerVideoSurface.updateUIView`
- Buffering, probing, frame pacing, and first-frame behavior
- Existing VOD clock, seek, play/pause, audio, subtitle, and overlay controls
- Overlay appearance, focus, animations, and remote navigation
- Trailers and Live TV
- Source Intelligence, Favorites, catalogs, guide, and grid

## Phase 2 purpose

This establishes a throttled, independently owned state channel that later overlay extraction can observe without subscribing directly to raw player callbacks. No playback behavior is replaced in this build.
