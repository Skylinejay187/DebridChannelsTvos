# Debrid Channels v944 — PlaybackKit Phase 1 (rebuilt from v943)

Authoritative base: `DebridChannels_v943_TRAILER_V840_CADENCE_HYBRID.zip`

## Scope
- Added the passive `Sources/PlaybackKit/PlaybackKitFoundation.swift` architecture boundary.
- Added that source to the XcodeGen tvOS target in `project.yml`.
- Routed the existing KSPlayer VOD surface and trailer surface through a transparent `PlaybackKitKSPlayerHost` wrapper.
- Registered/cleared non-Live-TV PlaybackKit sessions from the existing VOD screen lifecycle.
- Mirrored the existing KSPlayer time callback into the passive PlaybackKit clock without replacing the v943 overlay clock or presentation behavior.

## Intentionally unchanged
- KSPlayer and FFmpeg options/tuning
- Decoder, demuxer, buffering, probing, and hardware settings
- First-frame release and loading gate
- Render view ownership, attachment, hierarchy, and layout
- Audio/subtitle selection and flush behavior
- VOD overlay appearance, focus, controls, and timer ownership
- Live TV, Guide, Grid, Favorites, Source Intelligence, and trailer cadence logic

This phase is foundation-only. Playback remains owned by the original v943 implementation.
