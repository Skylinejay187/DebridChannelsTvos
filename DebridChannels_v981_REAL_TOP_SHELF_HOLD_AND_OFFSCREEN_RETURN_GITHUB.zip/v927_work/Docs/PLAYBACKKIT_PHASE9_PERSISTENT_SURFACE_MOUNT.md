# PlaybackKit Phase 9 — Persistent Surface Mount

Base: v951 Phase 8, rebuilt from the confirmed-working v943 lineage.

## Scope
- Adds a stable SwiftUI-owned `PlaybackSurfaceAnchorView`.
- Mounts the existing `KSContainerView` beneath the session-owned `PlaybackPersistentRenderHostView`.
- Preserves the same KSPlayer layer, decoder, render view, and URL configuration.
- Uses the Phase 7 registration lease and session/surface UUID guards.
- Returns the surface to its anchor during ordered teardown before KSPlayer dismantling.

## Explicitly unchanged
- KSPlayer player type and options
- FFmpeg and VideoToolbox configuration
- buffering and cache policy
- track selection and decoder flush behavior
- first-frame logic
- VOD overlay layout and controls
- Live TV playback path

## Phase boundary
SwiftUI still owns the outer anchor and can invoke `updateUIView`. Phase 10 will isolate the mounted video surface from SwiftUI refresh-driven configuration work; Phase 9 only establishes persistent UIKit ownership and controlled mounting.
