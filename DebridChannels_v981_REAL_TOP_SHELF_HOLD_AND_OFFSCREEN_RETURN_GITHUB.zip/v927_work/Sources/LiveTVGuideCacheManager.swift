import Foundation

// v783 Architecture Migration Step 9
// Centralizes Live TV lineup + guide cache persistence/refresh timing so the
// LiveTVSourceModel can keep owning provider loading and UI state only.
final class LiveTVGuideCacheManager {
    static let channelCacheKey = "liveTVLoadedChannelsV165"
    static let guideCacheKey = "liveTVGuideProgramsV191"
    static let lastRefreshKey = "liveTVLastRefreshV191"
    static let channelCacheFileName = "liveTVLoadedChannelsV165.json"
    static let guideCacheFileName = "liveTVGuideProgramsV191.json"

    let refreshTTL: TimeInterval

    init(refreshTTL: TimeInterval = 3 * 60 * 60) {
        self.refreshTTL = refreshTTL
    }

    var shouldRefreshNow: Bool {
        let last = UserDefaults.standard.double(forKey: Self.lastRefreshKey)
        guard last > 0 else { return true }
        return Date().timeIntervalSince1970 - last >= refreshTTL
    }

    func markRefreshed(_ date: Date = Date()) {
        UserDefaults.standard.set(date.timeIntervalSince1970, forKey: Self.lastRefreshKey)
    }

    func resetRefreshClock() {
        UserDefaults.standard.removeObject(forKey: Self.lastRefreshKey)
    }

    func loadChannelSnapshots() -> [LiveTVLoadedChannel]? {
        guard let data = Self.loadLargeStateData(defaultsKey: Self.channelCacheKey, fileName: Self.channelCacheFileName),
              let saved = try? JSONDecoder().decode([LiveTVLoadedChannel].self, from: data),
              !saved.isEmpty else { return nil }
        return saved
    }

    func persistChannels(_ channels: [LiveTVLoadedChannel]) {
        guard !channels.isEmpty, let data = try? JSONEncoder().encode(channels) else {
            Self.saveLargeStateData(Data(), defaultsKey: Self.channelCacheKey, fileName: Self.channelCacheFileName)
            return
        }
        Self.saveLargeStateData(data, defaultsKey: Self.channelCacheKey, fileName: Self.channelCacheFileName)
    }

    func loadGuidePrograms() -> [String: [LiveProgram]]? {
        guard let data = Self.loadLargeStateData(defaultsKey: Self.guideCacheKey, fileName: Self.guideCacheFileName),
              let cached = try? JSONDecoder().decode([String: [CachedLiveProgram]].self, from: data) else { return nil }
        let restored = cached.mapValues { $0.map(\.liveProgram) }
        return restored.isEmpty ? nil : restored
    }

    func persistGuidePrograms(_ guide: [String: [LiveProgram]], maxRows: Int) {
        guard !guide.isEmpty else {
            Self.saveLargeStateData(Data(), defaultsKey: Self.guideCacheKey, fileName: Self.guideCacheFileName)
            return
        }
        let cached = guide.mapValues { programs in programs.prefix(maxRows).map(CachedLiveProgram.init) }
        if let data = try? JSONEncoder().encode(cached) {
            Self.saveLargeStateData(data, defaultsKey: Self.guideCacheKey, fileName: Self.guideCacheFileName)
        }
    }

    static func clearPersistedCache() {
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: channelCacheKey)
        defaults.removeObject(forKey: guideCacheKey)
        defaults.removeObject(forKey: lastRefreshKey)
        removeLargeStateFile(named: channelCacheFileName)
        removeLargeStateFile(named: guideCacheFileName)
    }

    private static func largeStateDirectory() -> URL? {
        guard let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first else { return nil }
        let dir = base.appendingPathComponent("DebridChannelsLargeState", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    private static func largeStateFile(named name: String) -> URL? {
        largeStateDirectory()?.appendingPathComponent(name)
    }

    private static func removeLargeStateFile(named name: String) {
        guard let url = largeStateFile(named: name) else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private static func loadLargeStateData(defaultsKey: String, fileName: String) -> Data? {
        if let url = largeStateFile(named: fileName),
           let data = try? Data(contentsOf: url),
           !data.isEmpty {
            return data
        }
        let data = UserDefaults.standard.data(forKey: defaultsKey)
        if let data, !data.isEmpty {
            if let url = largeStateFile(named: fileName) {
                try? data.write(to: url, options: [.atomic])
            }
            UserDefaults.standard.removeObject(forKey: defaultsKey)
        }
        return data
    }

    private static func saveLargeStateData(_ data: Data, defaultsKey: String, fileName: String) {
        guard !data.isEmpty else {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            removeLargeStateFile(named: fileName)
            return
        }
        if let url = largeStateFile(named: fileName) {
            try? data.write(to: url, options: [.atomic])
        }
        UserDefaults.standard.removeObject(forKey: defaultsKey)
    }
}
