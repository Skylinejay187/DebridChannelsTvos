import Foundation
import AVFoundation

/// v786 architecture migration: centralizes lightweight playback state decisions
/// without taking ownership of the existing player surfaces, focus engine, resume
/// cache, or Source Intelligence handoff. Keep this manager pure and side-effect
/// free so the current player behavior remains unchanged.
struct PlaybackStateManager {
    static let shared = PlaybackStateManager()

    enum Surface: String {
        case avPlayer = "AVPlayer"
        case ksPlayer = "KSPlayer"
        case vlc = "VLC"
    }

    struct EngineContext {
        let isLive: Bool
        let forceKSPlayer: Bool
        let forceVLC: Bool
    }

    struct OverlayContext {
        let isLive: Bool
        let status: String
        let isLoading: Bool
        let errorText: String?
    }

    struct ResumeContext {
        let seconds: Double
        let duration: Double
        let isLive: Bool
    }

    func activeEngineName(for context: EngineContext) -> String {
        if context.isLive && context.forceKSPlayer { return "KSPlayer Live TV" }
        if context.isLive && context.forceVLC { return "VLC Live TV" }
        if context.isLive && !context.forceKSPlayer && !context.forceVLC { return "AVPlayer Live TV" }
        if context.forceKSPlayer { return Surface.ksPlayer.rawValue }
        if context.forceVLC { return Surface.vlc.rawValue }
        return Surface.avPlayer.rawValue
    }

    func loadingTitle(for context: OverlayContext) -> String {
        if context.errorText != nil { return "Playback Issue" }
        if context.isLive { return "Loading Stream..." }
        return "Preparing Playback..."
    }

    func statusLabel(for context: OverlayContext) -> String {
        let trimmed = context.status.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty { return trimmed }
        return context.isLive ? "Live" : "Cache Warming"
    }

    func shouldOfferResume(_ context: ResumeContext) -> Bool {
        guard !context.isLive else { return false }
        guard context.seconds >= 8 else { return false }
        guard context.duration <= 0 || context.seconds < context.duration * 0.95 else { return false }
        return true
    }

    func clampedSeekTarget(current: Double, delta: Double, duration: Double) -> Double {
        let target = current + delta
        guard duration > 0 else { return max(0, target) }
        return min(max(0, target), duration)
    }

    func watchedPercent(current: Double, duration: Double) -> Int {
        guard duration > 0 else { return 0 }
        return max(0, min(100, Int((current / duration) * 100.0)))
    }
}
