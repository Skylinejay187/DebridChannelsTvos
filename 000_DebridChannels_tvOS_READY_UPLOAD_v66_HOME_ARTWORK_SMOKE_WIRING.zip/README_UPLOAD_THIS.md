Debrid Channels tvOS v66 ready-to-upload repo package.

Upload this package contents to GitHub and run:
00 Build tvOS IPA From Source ZIP - UNIVERSAL DEVICE BUILD

Build marker:
Build v66 HOME ARTWORK SMOKE WIRING

Changes:
- Home screen focused artwork background with blur/dark/blue fade only on home.
- Expanded detail page stays clean without blur/blue wash.
- Stronger smoke layer.
- Right poster subtle idle motion.
- Poster logo pulse restarts on focused item changes.
- Stremio multi-JSON wiring, detail page, 30s preview-ready trigger preserved.
