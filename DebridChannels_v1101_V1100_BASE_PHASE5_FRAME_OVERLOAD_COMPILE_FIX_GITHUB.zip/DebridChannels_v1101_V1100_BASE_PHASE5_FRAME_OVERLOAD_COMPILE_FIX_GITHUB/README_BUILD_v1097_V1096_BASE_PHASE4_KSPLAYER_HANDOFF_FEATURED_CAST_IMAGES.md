# Debrid Channels v1097 — Phase 4 KSPlayer Handoff and Synchronization

- Base: v1096 only
- Marketing version: 1.0.625
- Build: 625
- Scope: Phase 4 app-side KSPlayer bridge handoff plus the requested Featured Cast image cleanup
- Backend update required for this phase: **No**
- Required backend: v667 Alternate Audio Discovery + Bridge

## Phase 4 handoff

The prepared Phase 3 HLS bridge can now replace the active KSPlayer source inside the existing VOD presentation. The root `CatalogStore.playbackURL` and `playbackPresentationID` remain stable, so the overlay, focus state, media identity, and playback screen are not recreated.

Every handoff receives a unique ownership UUID and source generation. Decoder callbacks are accepted only when the presentation ID, KSPlayer reload token, and exact source URL all match the current generation. A stopped outgoing player therefore cannot update the clock, tracks, failure state, or active session.

The handoff preserves:

- Current playback timestamp
- Play/pause state
- Selected subtitle state and external subtitle URL
- The original embedded audio selection for restoration
- Exact movie or episode ownership
- Existing VOD overlay and focus state

A one-shot timestamp correction is issued only when the new bridge clock differs from the saved position by more than three seconds. An 18-second first-frame recovery timer and the KSPlayer failure callback both restore the original source automatically if the bridge cannot become stable.

## Audio controls

The VOD Audio panel now connects:

- Prepare & Use Audio Bridge
- −250 ms
- +250 ms
- Reset
- Restore Original Audio
- Clear Alternate Audio

Changing the offset while Alternate Audio is active prepares a replacement bridge and performs another generation-safe handoff. Restore Original Audio returns to the untouched selected video source without dismissing the VOD screen.

Candidate choice and offset are saved against a deterministic exact-title identity containing media IDs plus season and episode information. The previous randomized Swift `hashValue` offset key was replaced so the saved offset survives app relaunches.

## Featured Cast cleanup

The active VOD Featured Cast stage now includes only cast entries with a valid HTTP/HTTPS profile-image URL. Empty, malformed, known placeholder, silhouette, and missing-image URLs are excluded before display.

A dedicated visible-image loader removes an entry if its image request or decode fails. If no valid cast images remain, the Featured Cast wall is not shown. No initials, blank silhouette, or image-less cast tiles are generated. Remaining cast order and the existing visual design are preserved.

## Backend status

No backend package change is required for v1097. Keep backend v667 installed and running. It already provides:

- `POST /api/alternate-audio/discover`
- `POST /api/alternate-audio/bridge`
- Bridge status and temporary HLS delivery

## Protected behavior

- Tapframe KSPNUVIO remains the only KSPlayer fork.
- KSPlayer was not replaced.
- Direct candidate URLs never enter the player as an external-audio input.
- Trailer resolver/runtime files remain byte-identical to v1096.
- Live TV guide cache and premium Live TV UI files remain unchanged.
- Stable feature-gate definitions remain unchanged and Alternate Audio remains experimental.
- No Movie Mode source was added.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing with backend v667 is required before Phase 5.
