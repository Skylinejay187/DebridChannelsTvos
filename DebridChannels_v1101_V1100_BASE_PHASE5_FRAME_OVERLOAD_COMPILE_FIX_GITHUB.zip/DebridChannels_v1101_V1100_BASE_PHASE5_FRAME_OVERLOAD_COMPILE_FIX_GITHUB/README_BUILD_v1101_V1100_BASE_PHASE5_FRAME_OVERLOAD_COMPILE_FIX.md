# Debrid Channels tvOS/iOS v1101

## Phase 5 SwiftUI frame-overload compile correction

- Base: v1100 only
- Marketing version: 1.0.629
- Build: 629
- Backend: no update required; continue using backend v668

## GitHub Actions failure corrected

The v1100 Xcode build progressed past the previous Catalog Health type-check timeout, then failed on two invalid SwiftUI modifier calls in `Sources/DebridChannelsTVOSApp.swift`:

- line 24795: `extra argument 'minHeight' in call`
- line 24889: `extra argument 'minHeight' in call`

The code combined SwiftUI's fixed-width `frame(width:height:alignment:)` shorthand with `minHeight`, which belongs to the separate flexible min/ideal/max frame overload.

v1101 splits each row constraint into two valid modifiers:

- fixed width and leading alignment
- minimum height and leading alignment

The provider row remains 1190 points wide with a 58-point minimum height. The catalog row remains 1190 points wide with a 54-point minimum height. No Catalog Health content, action, spacing, color, state, or reload behavior was changed.

## Preserved

- Complete Phase 5 Catalog Health diagnostics and safe cache clearing
- Image-only Featured Cast
- Season/episode text removed from poster artwork
- Episode air/release dates, including future dates
- Alternate Audio lifecycle stabilization and backend v668 cancellation
- Tapframe KSPNUVIO KSPlayer
- v1073 eager trailer behavior
- Premium Live TV overlay and Gracenote persistence
- Search, Favorites, catalog focus/pulse, episode alerts, and full-width rows

## Validation

- All 45 Swift files parsed
- Both plists parsed and versioned 1.0.629 / 629
- XcodeGen project versions match both plists
- Frame-overload correction contract passed 10/10
- Phase 2 discovery regression passed 8/8
- Phase 3 bridge regression passed 9/9
- Complete v1100 hash comparison completed
- Clean archive extraction and complete file-hash verification completed

GitHub Actions remains the authoritative tvOS/Xcode compilation test.
