# vBRDC398R17F16 — MediaFlow ATS packaging correction

Base: R17F15. All app logic, wallpapers, icon, Up Next changes preserved.

## Confirmed packaging bug

project.yml had `INFOPLIST_KEY_NSAppTransportSecurity_NSAllowsArbitraryLoads: YES`, but `GENERATE_INFOPLIST_FILE: NO` and `INFOPLIST_FILE: Sources/Info.plist`. The actual bundled plist had **no** NSAppTransportSecurity dictionary. The project-level generated-plist key cannot be relied upon to insert the exception into the custom plist. This explains the Apple TV ATS rejection of the user's HTTP public-IP MediaFlow proxy.

## Correction

Add NSAppTransportSecurity -> NSAllowsArbitraryLoads = true to the actual Sources/Info.plist. This implements the already-documented user-configured HTTP endpoint compatibility policy without changing any source routing or fail-closed proxy behavior. HTTPS remains preferable for remote/public proxies.

## Validation

Check that built .app/Info.plist contains this dictionary with `plutil -p`; validate the endpoint is reachable and authenticated; confirm the app does not bypass MediaFlow if verification fails. Xcode/Apple TV runtime testing not performed here.

## Performance

ATS denial may create repeated failed verification/retry work, but this change alone is NOT a proven fix for navigation hitches. Capture Instruments traces on device before claiming full smoothness.
