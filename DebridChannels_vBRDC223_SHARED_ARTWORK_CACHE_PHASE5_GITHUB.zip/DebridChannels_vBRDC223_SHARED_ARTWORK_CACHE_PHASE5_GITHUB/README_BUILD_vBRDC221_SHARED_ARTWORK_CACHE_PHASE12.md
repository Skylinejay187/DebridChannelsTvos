# Debrid Channels vBRDC221 — Shared Artwork Cache Phase 1/2

Built only from `DebridChannels_vBRDC220_DEBRID_NOW_SHOWING_DIRECT_PUSH_GITHUB.zip`.

## Change

`PremiumArtworkURL` now routes every public artwork request through the configured Debrid Channels backend `/api/image` shared-cache endpoint.

This covers artwork that arrives from normal backend catalogs as well as public poster/logo/backdrop URLs supplied directly by Stremio/addon/catalog metadata. Already-proxied backend URLs and local/private-network artwork URLs are left alone.

The result is one shared origin:

`Provider -> Debrid Channels backend persistent cache -> every Apple TV/iOS user`

When User A causes an uncached poster to download, User B requests the same backend URL and receives the persisted server copy instead of creating another provider download.

Existing in-app decoded image caching, artwork quality upgrading, catalog logic, focus behavior, Live TV, Trakt, VOD and playback systems are preserved.

## Version

- Marketing version: `1.0.924`
- Build: `924`

## Validation

All Swift sources pass `swiftc -frontend -parse`. Existing donor warning in `PlaybackKitKSPlayerSurface.swift` remains unchanged.
