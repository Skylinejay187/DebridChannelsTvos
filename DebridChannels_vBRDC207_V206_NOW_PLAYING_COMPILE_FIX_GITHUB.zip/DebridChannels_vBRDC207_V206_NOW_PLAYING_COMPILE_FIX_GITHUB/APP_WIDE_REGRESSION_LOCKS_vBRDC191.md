# vBRDC191 Regression Locks

1. Package donor is vBRDC190 only.
2. Player Engine must not return to the visible VOD control rail.
3. VOD control rail remains non-scrolling and mathematically even.
4. Full Video Fit/aspect-ratio feature remains present.
5. Production & Ratings and Behind the Scenes are mutually exclusive right-side Media Information owners.
6. Production & Ratings Themed Logo is an independent persisted setting and must not disappear merely because another feature is selected.
7. Behind the Scenes uses scene imagery + filmmaking craft credits; no Collector Showcase clear-art/disc-art collage UI.
8. vBRDC188 app icon assets remain unchanged.
