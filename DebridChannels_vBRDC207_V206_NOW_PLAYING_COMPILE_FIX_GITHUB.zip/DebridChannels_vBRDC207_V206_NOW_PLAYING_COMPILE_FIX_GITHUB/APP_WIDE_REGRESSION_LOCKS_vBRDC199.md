# App-wide regression locks — vBRDC199

1. Movies and TV Shows must never render rows declared for the opposite media type.
2. Official All-in-One manifest catalog type is authoritative over batch/meta type fields.
3. Reused catalog IDs (for example `popular`) must never be matched across movie/show catalogs by ID alone when a title match is available.
4. Fresh corrected media-type rows must beat stale fuller snapshots with conflicting media type.
5. Trakt shelf titles must remain specific and visible; provider label `Trakt` may not replace `Continue Watching • Trakt`, `Watch History • Trakt`, etc.
6. Built-in catalog refresh/migration must preserve Trakt/local row order and hidden state.
7. If a vBRDC198 damaged order contains no Trakt IDs while Trakt is connected, repair Trakt to the top once; never overwrite a valid saved Trakt order.
8. Trakt rows remain top account rows by default when connected and verified, unless the user explicitly reorders/disables them.
9. Home remains free of Trakt account shelves.
10. Approved icon assets remain byte-identical.
