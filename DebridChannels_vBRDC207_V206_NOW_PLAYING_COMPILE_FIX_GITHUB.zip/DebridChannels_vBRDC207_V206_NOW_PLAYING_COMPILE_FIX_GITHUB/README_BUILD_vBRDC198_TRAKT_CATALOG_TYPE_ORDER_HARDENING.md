# Debrid Channels vBRDC198 — Trakt Catalog Type + Order Hardening

Release: vBRDC198  
Marketing version: 1.0.901  
Build: 901

## Source of truth
Built directly from packaged vBRDC197. No older repository state or reconstructed source was used.

## Fixes
- Added a final Trakt publication sanitizer so stale/current account rows cannot bypass movie/show normalization.
- Added a second hard media boundary in the rendered Movies / TV Shows projection. `trakt-movie-*` shelves cannot appear in TV Shows; `trakt-show-*` shelves cannot appear in Movies.
- Normalized common media type spellings (`movie`, `film`, `series`, `show`, `tv`, `episode`) before the final section filter.
- Added a one-time connected-account order repair for vBRDC195-v197 saved customization state. Verified Trakt rows are promoted above ordinary catalog rows before cached first paint.
- The same order repair also runs when a Trakt account is first connected after CatalogStore initialization.
- After the one-time repair, Customize All-in-One remains authoritative. Move to Top / Move Up / Move Down / On-Off survive later catalog and Trakt refreshes.
- Default connected ordering puts the Trakt account shelves first in their existing logical order, then native Debrid Channels Continue Watching, then ordinary catalogs.

## Preserved from vBRDC197
- Duplicate-safe Sync Resume merge crash fix.
- Trakt -> native Debrid Channels resume materialization.
- Immediate local Continue Watching / progress publication.
- Trakt Watchlist action in Media Information.
- Watch History, Watchlist, Favorites, Recommendations, Trending, Popular and Anticipated account shelves.
- Trakt rows remain absent from Home.
- Existing local/offline resume remains active.
- Approved vBRDC188 icon is unchanged.

## Validation
- 68 Swift files parsed successfully with `swiftc -frontend -parse`.
- 67 application Swift sources remain represented by the project Sources tree.
- App + Top Shelf version metadata synchronized to 1.0.901 / 901.
- 27 locked app icon files byte-identical to packaged vBRDC197.
- Final package ZIP integrity checked.

GitHub Actions / Xcode remains authoritative for the tvOS/iOS SDK compile.
