from pathlib import Path
import plistlib, re
ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
TRAKT = (ROOT/'Sources/TraktSyncManager.swift').read_text()
TRAKT_CAT = (ROOT/'Sources/TraktCatalogService.swift').read_text()
PROJECT = (ROOT/'project.yml').read_text()

def test_main_catalog_uses_active_tab_boundary():
    assert 'private var effectiveCatalogFilter: String?' in APP
    assert 'if playbackBrowseMode { return filter }' in APP
    assert 'case .movies: return "movie"' in APP
    assert 'case .shows: return "series"' in APP
    assert 'if let filter = effectiveCatalogFilter' in APP
    assert 'rebuildRenderedRows(reason: "main catalog active-tab boundary")' in APP
    assert 'let visibleCatalogTab = catalogPresentationTab ??' in APP
    assert 'filter: visibleCatalogTab == .movies ? "movie" : (visibleCatalogTab == .shows ? "series" : nil)' in APP

def test_playback_catalog_filter_remains_explicit():
    assert 'filter: destination.catalogFilter' in APP
    assert 'playbackBrowseMode: true' in APP

def test_force_guide_is_authoritative_after_idle():
    assert 'refreshFromConfiguredSources(showLoadingIndicator: true, userInitiatedForce: true)' in APP
    assert 'func refreshFromConfiguredSources(showLoadingIndicator: Bool = true, userInitiatedForce: Bool = false)' in APP
    assert 'waitUntilPermitted(.interactiveMetadata, maxWait: 0.80)' in APP
    assert APP.count('guard await awaitGuidePublicationLane() else { return }') == 2
    force = APP[APP.index('private func runQuickPanelForceRefresh()'):]
    assert 'liveRefreshTask?.cancel()' in force[:1600]
    assert 'liveRefreshTask = nil' in force[:1600]

def test_sleep_clears_stale_transient_owners():
    scene = APP[APP.index('.onChange(of: scenePhase) { phase in'):]
    assert 'unityAnimations.resetTransientOwnership()' in scene[:5000]

def test_trakt_connection_is_keychain_persistent():
    assert 'private static let tokenAccount = "oauth-token-v1"' in TRAKT
    assert 'kSecAttrAccessibleAfterFirstUnlock' in TRAKT
    assert 'var isConnected: Bool { readTokenBundle() != nil }' in TRAKT
    assert 'func disconnect()' in TRAKT
    assert TRAKT.count('TraktSyncManager.shared.disconnect()') == 0

def test_release_identity():
    assert PROJECT.count('MARKETING_VERSION: 1.0.904') == 2
    assert PROJECT.count('CURRENT_PROJECT_VERSION: 904') == 2
    for rel in ('Sources/Info.plist','TopShelfExtension/Info.plist'):
        with (ROOT/rel).open('rb') as f: p=plistlib.load(f)
        assert p['CFBundleShortVersionString'] == '1.0.904'
        assert str(p['CFBundleVersion']) == '904'
        assert p['DebridChannelsReleaseID'] == 'vBRDC201'
    assert 'private static let appVersion = "1.0.904"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC201 TraktCatalog' in TRAKT_CAT
