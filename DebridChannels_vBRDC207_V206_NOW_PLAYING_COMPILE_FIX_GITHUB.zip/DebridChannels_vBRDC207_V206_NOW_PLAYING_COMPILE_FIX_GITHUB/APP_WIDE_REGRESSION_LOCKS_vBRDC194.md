# App-Wide Regression Locks — vBRDC194

1. Build lineage remains packaged vBRDC193 -> vBRDC194 only.
2. No end user is asked for a Trakt Client ID or Client Secret.
3. Trakt Settings expose Connect / Sync / Disconnect only, plus the resume-sync toggle and device authorization code state.
4. Trakt OAuth access and refresh tokens remain Keychain-backed.
5. Existing local resume is never removed; Trakt remains an optional sync layer.
6. Spotlight Hub remains video-card-free and uses Community Pulse / cloud resume / Where to Watch / review highlight.
7. Live TV Episode Alerts remain enabled.
8. Production & Ratings themed logo remains an independent setting.
9. Player Engine chip remains absent from the VOD rail.
10. vBRDC189 even VOD control rail and full Video Fit system remain unchanged.
11. vBRDC188 approved app icon assets remain unchanged.
