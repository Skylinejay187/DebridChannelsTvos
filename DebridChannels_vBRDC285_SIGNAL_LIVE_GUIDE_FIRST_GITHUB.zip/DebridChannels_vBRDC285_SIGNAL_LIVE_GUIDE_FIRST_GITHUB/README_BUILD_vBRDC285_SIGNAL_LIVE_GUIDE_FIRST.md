# vBRDC285 — Signal Live TV Guide-First

Version: 1.0.988 (988)

Live TV is now guide-first rather than grid-first. The mounted Live TV browse surface is a new dark television guide with a persistent left category rail, large now-playing hero, right-side artwork/live preview with black fade, and timeline rows beneath. The former Grid/Carousel/List renderers are no longer mounted by LiveTVScreen.

Startup modes in Settings:
- Guide First
- Resume With Guide
- Resume Fullscreen

Full-screen Live TV playback continues to use the existing player and Quick Guide. Returning from playback lands in the new guide with the current channel selected. Existing source loading, Gracenote/XMLTV, favorites, channel actions, Top Menu, Aether/KSPlayer routing, trailer resolver, branding, app icon and Top Shelf fixes are retained from vBRDC284.
