# vBRDC389 — Aether Finalization Phase 1 + Trailer Scope Repair

Version: 1.0.1102 (1102)

## Scope

This build starts the Aether finalization/cleanup phase while folding in the two minor trailer regressions reported on physical Apple TV.

### Trailer-only display-match suppression
- `UniversalVideoSurface` now forwards its caller-provided `enableDisplayMatch` value into Aether instead of hard-disabling display matching globally.
- VOD can therefore use the existing tvOS Match Dynamic Range / Match Frame Rate policy again.
- Built-in trailers still pass `enableDisplayMatch=false` directly on their own Aether surface, so suppression remains trailer-only.

### Stricter trailer quiescence
- While `trailerActive`, UnityFrameRuntime now permits only playback chrome + persistence.
- Alert animation is suspended during trailers to leave more main-thread/compositor budget for tvOS Control Center/settings overlays.
- Source-opening behavior remains unchanged.

### Aether finalization Phase 1
- Settings now present AetherEngine as the single built-in trailer engine.
- Restored legacy engine preferences are normalized to Aether for VOD, Live TV and trailers.
- Updated stale Now Playing copy that still described KSPlayer/VLC as active playback engines.
- No Aether decoder/cadence changes, no Live R7/timeshift/cache changes, no Kingfisher changes, no navigation/ambient changes.

## Regression locks
- vBRDC383R7 Live TV stability
- vBRDC384F3 timeshift
- vBRDC385+ VOD cache/subtitles/amplification
- vBRDC387R2 approved ambient appearance/lifecycle
- vBRDC387R3F1 trailer cadence
- vBRDC388R3 single-active-surface quiescence
- vBRDC388R3K1F3 Kingfisher SwiftPM packaging
