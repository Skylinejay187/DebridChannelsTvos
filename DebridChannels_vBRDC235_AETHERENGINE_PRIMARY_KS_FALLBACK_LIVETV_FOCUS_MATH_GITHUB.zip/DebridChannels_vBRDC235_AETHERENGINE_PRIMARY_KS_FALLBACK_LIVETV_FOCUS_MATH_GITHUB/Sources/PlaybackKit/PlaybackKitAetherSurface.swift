import Foundation
import SwiftUI
import Combine
import UIKit

#if canImport(AetherEngine)
import AetherEngine

/// vBRDC235: AetherEngine owns primary decode/render while Debrid Channels keeps the
/// existing VOD/Live TV chrome, resume persistence, source failover and system-media lanes.
/// The host intentionally translates Aether's public transport/clock surface into the
/// same callbacks the legacy KSPlayer surface already feeds so higher layers do not fork.
struct PlaybackKitAetherHost: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let playAssertionSerial: Int
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    var isLiveStream: Bool = false
    var httpHeaders: [String: String] = [:]
    var enableDisplayMatch: Bool = true
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onBufferUpdate: ((Double, Double) -> Void)? = nil
    var onFirstFrameReady: (() -> Void)? = nil
    var onPlaybackFailure: ((String) -> Void)? = nil
    var onPlaybackEnded: (() -> Void)? = nil

    final class Coordinator {
        var engine: AetherEngine?
        var cancellables = Set<AnyCancellable>()
        var loadTask: Task<Void, Never>?
        var seekTask: Task<Void, Never>?
        var currentURL: URL?
        var lastReloadToken = -1
        var lastSeekSerial = 0
        var lastPlayAssertionSerial = 0
        var lastShouldPlay = false
        var duration: Double = 0
        var currentTime: Double = 0
        var firstFramePublished = false
        var failed = false

        deinit {
            loadTask?.cancel()
            seekTask?.cancel()
            engine?.stop()
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> AetherPlayerView {
        let view = AetherPlayerView()
        view.backgroundColor = .black
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: AetherPlayerView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    static func dismantleUIView(_ view: AetherPlayerView, coordinator: Coordinator) {
        coordinator.loadTask?.cancel()
        coordinator.seekTask?.cancel()
        coordinator.cancellables.removeAll()
        coordinator.engine?.stop()
        coordinator.engine = nil
    }

    private func configure(view: AetherPlayerView, coordinator: Coordinator) {
        let needsLoad = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken || coordinator.engine == nil
        if needsLoad {
            coordinator.loadTask?.cancel()
            coordinator.seekTask?.cancel()
            coordinator.cancellables.removeAll()
            coordinator.engine?.stop()
            coordinator.engine = nil
            coordinator.currentURL = url
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            coordinator.lastShouldPlay = shouldPlay
            coordinator.duration = 0
            coordinator.currentTime = 0
            coordinator.firstFramePublished = false
            coordinator.failed = false

            do {
                let engine = try AetherEngine()
                coordinator.engine = engine
                engine.bind(view: view)
                installObservers(engine: engine, coordinator: coordinator)

                var options = LoadOptions(
                    httpHeaders: httpHeaders,
                    matchContentEnabled: enableDisplayMatch,
                    isLive: isLiveStream,
                    liveJoinProfile: isLiveStream ? .fastZap : .standard,
                    preferredAudioLanguages: ["en", "eng"],
                    autoplay: shouldPlay
                )
                if isLiveStream {
                    options.nativeRemoteHLSIngestFallback = true
                }

                let requestedStart = isLiveStream ? 0 : max(0, startTimeSeconds)
                coordinator.loadTask = Task { @MainActor in
                    do {
                        try await engine.load(url: url, options: options)
                        guard !Task.isCancelled, coordinator.currentURL == url else { return }
                        if requestedStart > 0.25 {
                            await engine.seek(to: requestedStart)
                        }
                        if shouldPlay { engine.play() } else { engine.pause() }
                    } catch is CancellationError {
                        return
                    } catch {
                        guard !Task.isCancelled, coordinator.currentURL == url else { return }
                        publishFailure(error.localizedDescription, coordinator: coordinator)
                    }
                }
            } catch {
                publishFailure("AetherEngine initialization failed: \(error.localizedDescription)", coordinator: coordinator)
            }
            return
        }

        guard let engine = coordinator.engine else { return }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = seekIsAbsolute ? max(0, seekSeconds) : max(0, coordinator.currentTime + seekSeconds)
            coordinator.seekTask?.cancel()
            coordinator.seekTask = Task { @MainActor in
                await engine.seek(to: target)
            }
        }

        if playAssertionSerial != coordinator.lastPlayAssertionSerial {
            coordinator.lastPlayAssertionSerial = playAssertionSerial
            engine.play()
        }

        if shouldPlay != coordinator.lastShouldPlay {
            coordinator.lastShouldPlay = shouldPlay
            if shouldPlay { engine.play() } else { engine.pause() }
        }
    }

    private func installObservers(engine: AetherEngine, coordinator: Coordinator) {
        engine.$duration
            .receive(on: RunLoop.main)
            .sink { value in
                coordinator.duration = value.isFinite ? max(0, value) : 0
                onPlaybackTimeUpdate?(coordinator.currentTime, coordinator.duration)
            }
            .store(in: &coordinator.cancellables)

        engine.clock.$currentTime
            .receive(on: RunLoop.main)
            .sink { value in
                guard value.isFinite else { return }
                coordinator.currentTime = max(0, value)
                onPlaybackTimeUpdate?(coordinator.currentTime, coordinator.duration)
            }
            .store(in: &coordinator.cancellables)

        engine.clock.$bufferedPosition
            .receive(on: RunLoop.main)
            .sink { value in
                guard value.isFinite else { return }
                onBufferUpdate?(max(0, value), coordinator.duration)
            }
            .store(in: &coordinator.cancellables)

        engine.$hasFirstFrameReadyForDisplay
            .removeDuplicates()
            .receive(on: RunLoop.main)
            .sink { ready in
                guard ready, !coordinator.firstFramePublished else { return }
                coordinator.firstFramePublished = true
                onFirstFrameReady?()
            }
            .store(in: &coordinator.cancellables)

        engine.$state
            .receive(on: RunLoop.main)
            .sink { state in
                let value = String(describing: state).lowercased()
                if value.hasPrefix("error") {
                    publishFailure("AetherEngine playback error: \(state)", coordinator: coordinator)
                } else if value == "ended" {
                    onPlaybackEnded?()
                }
            }
            .store(in: &coordinator.cancellables)
    }

    private func publishFailure(_ message: String, coordinator: Coordinator) {
        guard !coordinator.failed else { return }
        coordinator.failed = true
        onPlaybackFailure?(message)
    }
}
#endif
