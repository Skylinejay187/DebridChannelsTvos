# Debrid Channels tvOS v19

Ready-to-upload repo package. Upload this ZIP to GitHub, run Actions, download unsigned IPA.

Changes: Android-style structure, centered top menu, full-screen hero, one visible first row, no white focus square, blue pulse focus, Stremio/Cinemeta row loading in Settings.
