import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct VODProductionCompany: Identifiable, Hashable, Codable {
    var id: String { name.lowercased() + "|" + (logoURL ?? "") }
    let name: String
    let logoURL: String?
}

struct VODProductionMetadataSnapshot: Hashable {
    var certification: String? = nil
    var budget: Int? = nil
    var revenue: Int? = nil
    var status: String? = nil
    var runtimeMinutes: Int? = nil
    var releaseDate: String? = nil
    var countries: [String] = []
    var languages: [String] = []
    var studios: [VODProductionCompany] = []
    var networks: [VODProductionCompany] = []
    var landscapeArtworkURLs: [String] = []
    var titleLogoURL: String? = nil

    static let empty = VODProductionMetadataSnapshot()

    var hasUsefulContent: Bool {
        certification != nil || budget != nil || revenue != nil || status != nil || runtimeMinutes != nil || releaseDate != nil || !countries.isEmpty || !languages.isEmpty || !studios.isEmpty || !networks.isEmpty || !landscapeArtworkURLs.isEmpty || titleLogoURL != nil
    }
}

enum VODProductionMetadataService {
    private struct TMDBReference: Decodable { let id: Int? }
    private struct FindResponse: Decodable {
        let movie_results: [TMDBReference]?
        let tv_results: [TMDBReference]?
    }
    private struct SearchResponse: Decodable { let results: [TMDBReference]? }
    private struct Company: Decodable {
        let name: String?
        let logo_path: String?
    }
    private struct Country: Decodable {
        let iso_3166_1: String?
        let name: String?
    }
    private struct Language: Decodable {
        let english_name: String?
        let name: String?
    }
    private struct ArtworkImage: Decodable {
        let file_path: String?
        let width: Int?
        let height: Int?
        let aspect_ratio: Double?
        let vote_average: Double?
        let vote_count: Int?
        let iso_639_1: String?
    }
    private struct ArtworkImages: Decodable {
        let backdrops: [ArtworkImage]?
        let logos: [ArtworkImage]?
    }
    private struct MovieReleaseEntry: Decodable {
        let certification: String?
        let type: Int?
    }
    private struct MovieReleaseCountry: Decodable {
        let iso_3166_1: String?
        let release_dates: [MovieReleaseEntry]?
    }
    private struct MovieReleaseDates: Decodable { let results: [MovieReleaseCountry]? }
    private struct TVContentRating: Decodable {
        let iso_3166_1: String?
        let rating: String?
    }
    private struct TVContentRatings: Decodable { let results: [TVContentRating]? }
    private struct MovieDetail: Decodable {
        let budget: Int?
        let revenue: Int?
        let status: String?
        let runtime: Int?
        let release_date: String?
        let production_companies: [Company]?
        let production_countries: [Country]?
        let spoken_languages: [Language]?
        let release_dates: MovieReleaseDates?
        let images: ArtworkImages?
    }
    private struct EpisodeSummary: Decodable { let runtime: Int? }
    private struct TVDetail: Decodable {
        let status: String?
        let episode_run_time: [Int]?
        let first_air_date: String?
        let origin_country: [String]?
        let production_companies: [Company]?
        let networks: [Company]?
        let spoken_languages: [Language]?
        let content_ratings: TVContentRatings?
        let last_episode_to_air: EpisodeSummary?
        let images: ArtworkImages?
    }

    static func fetch(
        itemID: String,
        tmdbID explicitTMDBID: String?,
        imdbID explicitIMDbID: String?,
        title: String,
        year: String,
        type: String,
        seasonNumber: Int?,
        episodeNumber: Int?,
        apiKey: String
    ) async -> VODProductionMetadataSnapshot {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return .empty }

        let lowerType = type.lowercased()
        let isTV = seasonNumber != nil || episodeNumber != nil || lowerType.contains("series") || lowerType.contains("show") || lowerType.contains("episode") || lowerType == "tv"
        var kind = isTV ? "tv" : "movie"
        var tmdbID = explicitTMDBID?.trimmingCharacters(in: .whitespacesAndNewlines)

        let idParts = itemID.split(separator: ":").map(String.init)
        if tmdbID?.isEmpty != false, idParts.count >= 3, idParts[0].lowercased() == "tmdb" {
            kind = (idParts[1].lowercased() == "tv" || isTV) ? "tv" : "movie"
            tmdbID = idParts[2]
        }

        let imdbID: String? = {
            let explicit = explicitIMDbID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if explicit.lowercased().hasPrefix("tt") { return explicit }
            if itemID.lowercased().hasPrefix("tt") { return String(itemID.split(separator: ":").first ?? Substring(itemID)) }
            if let range = itemID.range(of: #"tt\d{6,}"#, options: .regularExpression) { return String(itemID[range]) }
            return nil
        }()

        if tmdbID?.isEmpty != false, let imdbID,
           let url = makeURL(path: "find/\(imdbID)", apiKey: key, query: [URLQueryItem(name: "external_source", value: "imdb_id")]),
           let found = await request(FindResponse.self, url: url) {
            if isTV, let value = found.tv_results?.compactMap(\.id).first {
                kind = "tv"
                tmdbID = String(value)
            } else if let value = found.movie_results?.compactMap(\.id).first {
                kind = "movie"
                tmdbID = String(value)
            } else if let value = found.tv_results?.compactMap(\.id).first {
                kind = "tv"
                tmdbID = String(value)
            }
        }

        if tmdbID?.isEmpty != false {
            let cleanTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
            guard cleanTitle.count >= 2 else { return .empty }
            var query = [
                URLQueryItem(name: "query", value: cleanTitle),
                URLQueryItem(name: "include_adult", value: "false")
            ]
            let cleanYear = String(year.filter(\.isNumber).prefix(4))
            if !cleanYear.isEmpty {
                query.append(URLQueryItem(name: kind == "tv" ? "first_air_date_year" : "year", value: cleanYear))
            }
            if let url = makeURL(path: "search/\(kind)", apiKey: key, query: query),
               let found = await request(SearchResponse.self, url: url),
               let value = found.results?.compactMap(\.id).first {
                tmdbID = String(value)
            }
        }

        guard let tmdbID, !tmdbID.isEmpty else { return .empty }
        if kind == "tv" {
            guard let url = makeURL(
                path: "tv/\(tmdbID)",
                apiKey: key,
                query: [
                    URLQueryItem(name: "append_to_response", value: "content_ratings,images"),
                    URLQueryItem(name: "include_image_language", value: "en,null")
                ]
            ), let detail = await request(TVDetail.self, url: url) else { return .empty }

            let artwork = artwork(detail.images)
            return VODProductionMetadataSnapshot(
                certification: preferredTVRating(detail.content_ratings?.results ?? []),
                budget: nil,
                revenue: nil,
                status: clean(detail.status),
                runtimeMinutes: detail.last_episode_to_air?.runtime ?? detail.episode_run_time?.first(where: { $0 > 0 }),
                releaseDate: clean(detail.first_air_date),
                countries: unique((detail.origin_country ?? []).map { $0.uppercased() }),
                languages: unique((detail.spoken_languages ?? []).compactMap { clean($0.english_name) ?? clean($0.name) }),
                studios: companies(detail.production_companies ?? []),
                networks: companies(detail.networks ?? []),
                landscapeArtworkURLs: artwork.landscape,
                titleLogoURL: artwork.logo
            )
        }

        guard let url = makeURL(
            path: "movie/\(tmdbID)",
            apiKey: key,
            query: [
                URLQueryItem(name: "append_to_response", value: "release_dates,images"),
                URLQueryItem(name: "include_image_language", value: "en,null")
            ]
        ), let detail = await request(MovieDetail.self, url: url) else { return .empty }

        let artwork = artwork(detail.images)
        return VODProductionMetadataSnapshot(
            certification: preferredMovieRating(detail.release_dates?.results ?? []),
            budget: positive(detail.budget),
            revenue: positive(detail.revenue),
            status: clean(detail.status),
            runtimeMinutes: positive(detail.runtime),
            releaseDate: clean(detail.release_date),
            countries: unique((detail.production_countries ?? []).compactMap { clean($0.iso_3166_1)?.uppercased() ?? clean($0.name) }),
            languages: unique((detail.spoken_languages ?? []).compactMap { clean($0.english_name) ?? clean($0.name) }),
            studios: companies(detail.production_companies ?? []),
            networks: [],
            landscapeArtworkURLs: artwork.landscape,
            titleLogoURL: artwork.logo
        )
    }


    private static func artwork(_ images: ArtworkImages?) -> (landscape: [String], logo: String?) {
        let backdropValues = (images?.backdrops ?? [])
            .filter { image in
                guard clean(image.file_path) != nil else { return false }
                let width = image.width ?? 0
                let height = image.height ?? 0
                let aspect = image.aspect_ratio ?? (height > 0 ? Double(width) / Double(height) : 0)
                guard aspect >= 1.45 else { return false }
                return width == 0 || width >= 780
            }
            .sorted { lhs, rhs in
                let leftLanguage = lhs.iso_639_1?.lowercased() == "en" ? 1 : 0
                let rightLanguage = rhs.iso_639_1?.lowercased() == "en" ? 1 : 0
                if leftLanguage != rightLanguage { return leftLanguage > rightLanguage }
                let leftVotes = lhs.vote_count ?? 0
                let rightVotes = rhs.vote_count ?? 0
                if leftVotes != rightVotes { return leftVotes > rightVotes }
                let leftScore = lhs.vote_average ?? 0
                let rightScore = rhs.vote_average ?? 0
                if leftScore != rightScore { return leftScore > rightScore }
                return (lhs.width ?? 0) > (rhs.width ?? 0)
            }

        var seenBackdropPaths = Set<String>()
        let landscape = backdropValues.compactMap { image -> String? in
            guard let path = clean(image.file_path), seenBackdropPaths.insert(path.lowercased()).inserted else { return nil }
            return "https://image.tmdb.org/t/p/w1280\(path)"
        }

        let logo = (images?.logos ?? [])
            .filter { clean($0.file_path) != nil }
            .sorted { lhs, rhs in
                let leftEnglish = lhs.iso_639_1?.lowercased() == "en" ? 1 : 0
                let rightEnglish = rhs.iso_639_1?.lowercased() == "en" ? 1 : 0
                if leftEnglish != rightEnglish { return leftEnglish > rightEnglish }
                let leftVotes = lhs.vote_count ?? 0
                let rightVotes = rhs.vote_count ?? 0
                if leftVotes != rightVotes { return leftVotes > rightVotes }
                let leftScore = lhs.vote_average ?? 0
                let rightScore = rhs.vote_average ?? 0
                if leftScore != rightScore { return leftScore > rightScore }
                return (lhs.width ?? 0) > (rhs.width ?? 0)
            }
            .compactMap { clean($0.file_path) }
            .first
            .map { "https://image.tmdb.org/t/p/w500\($0)" }

        return (landscape, logo)
    }

    private static func request<T: Decodable>(_ type: T.Type, url: URL) async -> T? {
        do {
            var request = URLRequest(url: url, timeoutInterval: 8)
            request.cachePolicy = .returnCacheDataElseLoad
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS-v1108-ProductionArtworkRotation", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard !Task.isCancelled else { return nil }
            if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) { return nil }
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            return nil
        }
    }

    private static func makeURL(path: String, apiKey: String, query: [URLQueryItem]) -> URL? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.themoviedb.org"
        components.path = "/3/\(path)"
        components.queryItems = [
            URLQueryItem(name: "api_key", value: apiKey),
            URLQueryItem(name: "language", value: "en-US")
        ] + query
        return components.url
    }

    private static func companies(_ values: [Company]) -> [VODProductionCompany] {
        var seen = Set<String>()
        return values.compactMap { company in
            guard let name = clean(company.name), seen.insert(name.lowercased()).inserted else { return nil }
            let logoURL = clean(company.logo_path).map { "https://image.tmdb.org/t/p/w185\($0)" }
            return VODProductionCompany(name: name, logoURL: logoURL)
        }
    }

    private static func preferredMovieRating(_ countries: [MovieReleaseCountry]) -> String? {
        let ordered = countries.sorted { lhs, rhs in
            let leftUS = lhs.iso_3166_1?.uppercased() == "US"
            let rightUS = rhs.iso_3166_1?.uppercased() == "US"
            return leftUS && !rightUS
        }
        for country in ordered {
            let entries = (country.release_dates ?? []).sorted { lhs, rhs in
                let left = lhs.type == 3 ? 0 : (lhs.type == 4 ? 1 : 2)
                let right = rhs.type == 3 ? 0 : (rhs.type == 4 ? 1 : 2)
                return left < right
            }
            if let rating = entries.compactMap({ clean($0.certification) }).first {
                return rating.uppercased()
            }
        }
        return nil
    }

    private static func preferredTVRating(_ ratings: [TVContentRating]) -> String? {
        let ordered = ratings.sorted { lhs, rhs in
            let leftUS = lhs.iso_3166_1?.uppercased() == "US"
            let rightUS = rhs.iso_3166_1?.uppercased() == "US"
            return leftUS && !rightUS
        }
        return ordered.compactMap { clean($0.rating) }.first?.uppercased()
    }

    private static func clean(_ value: String?) -> String? {
        let text = value?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return text.isEmpty ? nil : text
    }

    private static func positive(_ value: Int?) -> Int? {
        guard let value, value > 0 else { return nil }
        return value
    }

    private static func unique(_ values: [String]) -> [String] {
        var seen = Set<String>()
        return values.filter { seen.insert($0.lowercased()).inserted }
    }
}
