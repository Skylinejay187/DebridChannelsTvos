# Debrid Channels v1071 — Multi-Debrid Provider Fan-Out and Mix Fix

Base: v1070 (`1.0.598 / 598`)
Release: `1.0.599 / 599`

## Root causes found

1. Source Intelligence stopped scanning manifests as soon as the first fast provider filled the visible 25/50-link cap. The round-robin mixer therefore only received links from the first provider.
2. Manifest deduplication compared every fallback candidate, including each addon's root `/manifest.json`. Two separately configured manifests on the same host—such as Torrentio Real-Debrid and Torrentio TorBox—were collapsed into one.
3. Built-in Comet generation used `else if`, so Real-Debrid prevented the TorBox Comet manifest from being generated when both accounts were configured.
4. Addons such as Debrido, Torrentio, Comet, and MediaFusion can use the same addon name for multiple debrid services. Grouping only by addon name merged Real-Debrid and TorBox into one provider bucket.
5. A provider's fallback media-ID pass was skipped when any earlier provider had already returned links.

## Corrections

- Every configured stream provider is scanned even after 25/50 visible candidates are available.
- Each provider may contribute its own candidate pool; the existing 25/50 setting is applied only after ranking and provider round-robin balancing.
- Configured manifests are deduplicated by their exact configured identity, not by shared root fallbacks.
- Real-Debrid and TorBox built-in Torrentio/Comet manifests can coexist.
- Debrid service identity is inferred from the individual stream first, then from the configured manifest. Mixed Debrido manifests can therefore produce separate `Debrido • Real-Debrid` and `Debrido • TorBox` entries.
- Provider status rows also retain separate configured identities.
- Existing Source Intelligence ranking, Top Recommended Link, paging, scrolling, confirmation, and playback handoff remain unchanged.

## Validation

- All Swift sources passed `swiftc -parse`.
- Main app and Top Shelf plist versions match `project.yml`.
- XML plists and YAML project configuration validated.
- Final ZIP extraction and SHA-256 round-trip verification completed.

GitHub Actions remains the authoritative tvOS/Xcode compile and archive test.
