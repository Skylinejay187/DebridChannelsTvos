# Debrid Channels v1049

Base: v1048 Phase 12A catalog permanence and recovery
Version: 1.0.577
Build: 577

## Purpose

Correct four physical-device regressions without changing the catalog permanence work or playback engine:

1. Keep Connected Popup artwork fully clipped inside the rounded popup.
2. Restore deliberate LEFT/RIGHT VOD timeline movement when controls are hidden or the drawer is collapsed.
3. Keep opening the VOD Control Drawer seek-neutral.
4. Show three visible TV episode cards and remove the Source Intelligence status sentence from the popup.

## Connected Popup artwork containment

- The full-screen dim/gradient layer has been removed from Artwork mode.
- Artwork, material and popup content are composited and clipped together with the popup's 34-point continuous rounded shape.
- The alternate artwork cannot tint or draw outside the popup.
- Transparent mode remains unchanged.
- The small portrait poster in the top information bar remains.

## VOD scrub/control state separation

The VOD remote path now follows one invariant:

`seek preview delta != 0` only after an explicit LEFT or RIGHT gesture.

- LEFT/RIGHT while controls are hidden reveals the timeline and moves its preview.
- LEFT/RIGHT while the control drawer is collapsed routes to the timeline even if tvOS temporarily leaves focus on the chevron.
- UP/DOWN opening the drawer clears passive preview state and never calls the seek/commit path.
- Focus-only transitions no longer create a synthetic scrub session.
- SELECT/UP/DOWN still commit after the user deliberately moved the timeline.

## Episode presentation

- The connected popup shows three episode cards.
- Each card is 252 points wide.
- Three cards plus two 12-point gaps use 780 points, fitting inside the popup's 808-point content width.
- The navigation window and visible window both use three cards, keeping the focused episode visible.

## Source Intelligence status cleanup

- The popup's generic status line was removed.
- The internal "Selected source is opening; Source Intelligence results stay open for return" cancellation reason is no longer published into visible status state.
- Source Intelligence remains mounted behind playback as before.

## Preserved unchanged

- Phase 12A catalog permanence/retry implementation
- All-in-One Catalog toggle and personal catalogs
- KSPlayer and PlaybackKit
- VOD queue 24 / 24 / 16
- Live TV and guide
- Backup/restore payload and credentials
- 30-second focused previews
- Connected-card identity/focus fixes
- Cast hydration
- Audio, subtitles, trailers and Source Intelligence selection logic

GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate.
