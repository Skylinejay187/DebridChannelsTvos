# Debrid Channels v1094 — Phase 1 Stabilization Pass

**Base:** v1093 Phase 1 only  
**Marketing version:** 1.0.622  
**Build:** 622

## Full-screen Live TV Gracenote persistence

This pass fixes the playback-session-only failure where Gracenote program information and artwork could disappear after watching a Live TV channel for a while, then reappear only after exiting and re-entering full-screen playback.

- Full-screen playback now retains compact **current + next** program snapshots instead of a single current-program row.
- The active channel is rebound to the process-wide guide every 30 seconds without performing a network refresh or rebuilding the player.
- Opening the Quick Guide performs one atomic all-channel rebind.
- Program-boundary changes advance current/next metadata in place.
- Partial or empty guide refreshes retain the last-known-good title, description, timing, and artwork.
- A departing playback generation may clear only its local Quick Guide model; it cannot erase the shared snapshot needed by an incoming channel switch.
- A real player dismissal still releases the compact playback snapshot.
- The main Live TV grid, the v1093 premium Quick Guide appearance, channel playback path, and dedicated Live TV overlay remain unchanged.

## Slow constant catalog focus pulse

The single focused slot in standard catalog rails now uses a continuous, restrained pulse:

- Scale range: **1.000 → 1.015**.
- Timing: **2.15 seconds in each direction**, autoreversing continuously.
- Uses `scaleEffect` only; no card-frame, row-layout, scrolling, or timer-driven row state changes.
- Keeps the existing sideways/perspective focused-card presentation and arrival behavior.
- Disabled for Favorites through its existing `allowsRailAnimations: false` path.
- Search and Live TV continue using their specialized card components and are untouched.

## Protected systems

The v1093 eager trailer resolver/runtime, Playback Health panel, premium Live TV UI, KSPlayer surface, Tapframe KSPNUVIO vendor tree, and Phase 0 stable-protection manager are unchanged. No Movie Mode source was added.

## Validation boundary

All 42 Swift files pass syntax parsing. The backend trailer Python source compiles, both plists parse, project and plist versions agree, the focused lifecycle harness passes, protected hashes match v1093, no baseline file was removed, and the final archive is extraction/hash verified. GitHub Actions remains the authoritative Xcode/tvOS compilation test, followed by physical Apple TV testing.
