# Debrid Channels v1047

Base: v1046
Version: 1.0.575
Build: 575

## Purpose

Prevent the VOD timeline from issuing a brief seek when the Up button opens the control drawer, while preserving Up as the drawer-opening gesture.

## Runtime behavior

- Up from the timeline continues to open the VOD control drawer.
- Merely focusing the timeline stores only a passive visual snapshot.
- A real scrub transaction begins only after Left or Right moves the timeline.
- Select, Up, or Down commits only a timeline that was deliberately moved.
- Opening or closing the drawer with an untouched timeline clears the passive snapshot without calling the player seek path.
- Playback time remains unchanged when the controls are opened normally.

## Preserved

- VOD Control Drawer layout, modes, and auto-hide settings.
- Connected Media Information popup and artwork/transparent toggle.
- 30-second focused previews.
- Scrubber Left/Right preview and Select/Up/Down commit after deliberate movement.
- Resume, Restart, Back 30, Forward 60, Audio, Subtitles, Episodes, Player Engine, and Settings actions.
- KSPlayer, PlaybackKit, VOD queue 24/24/16, Live TV, trailers, catalog recovery, cast hydration, Source Intelligence, and full-profile backup/restore.

## Validation

- Every Swift source parsed with `swiftc -frontend -parse`.
- App and Top Shelf versions/builds match.
- Both plists and project.yml parsed successfully.
- Targeted static assertions verify passive focus cannot reach seekAbsolute.
- Critical playback, catalog, backup, preview, artwork, and trailer files match v1046 byte-for-byte.

GitHub Actions/Xcode is the authoritative Apple tvOS SDK compile and archive test.
