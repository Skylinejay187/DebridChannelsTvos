# Debrid Channels v1088 — Favorites Local Centered Details

Base: v1087
Marketing version: 1.0.616
Build: 616

## Change

Favorites now keeps its existing selected-card rail and backdrop mounted when a movie or show is opened. The existing media-information popup is presented in the center of the Favorites screen. The focused-card connector line is disabled for Favorites only. Home, Movies, Shows, and Search retain their existing presentation behavior.

## Focus and dismissal

The selected favorite remains visually anchored while details are open. Back closes the popup and restores focus to the Favorites rail and the same selected index. Playback still enters the normal full-screen VOD path.

## Scope

No Movie Mode code was added. Trailer loading, always-on episode alerts, source-handoff clock fixes, full-width rows, Guide startup, Search ownership, Source Intelligence, and playback behavior from v1087 remain unchanged.

GitHub Actions/Xcode and physical Apple TV testing remain the authoritative full compilation and runtime validation.
