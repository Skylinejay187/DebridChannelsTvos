# Debrid Channels v1067

Base: v1066  
Marketing version: 1.0.595  
Build: 595

## Purpose

Restore focused-card preview startup after the v1065 preview ownership-key change.

## Root cause

v1065 changed the preview request key from the hero key to a stable row + canonical media identity key.
The two delayed async validation guards still compared that new key against `focusedBackdropKey`.
Those key formats can never match, so every preview task exited after the 1.5-second settle delay before resolving a URL.

## Correction

Both pre-resolution and post-resolution guards now compare the request against
`focusedCardPreviewIdentityKey`, the same key used to schedule and present the preview.
This preserves cancellation when focus genuinely moves while allowing the active card preview to start.

## Preserved behavior

- Preview remains pinned to the exact originating row/card through media-popup interactions.
- Popup colored accent remains removed.
- Find Links-to-Source Intelligence connector remains removed.
- Source Intelligence satellite panel retains Top Recommended Link and existing navigation logic.
- Built-in trailer resolver restoration from v1064 remains included.
