import SwiftUI

struct RemoteImageFit: View {
    enum Mode { case fill, fit }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true

    private var resolvedURL: URL? {
        guard var raw = url?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://") {
            // tvOS may refuse non-ATS HTTP artwork depending on provider/app transport settings.
            // Try the secure equivalent first for common image hosts.
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }

    var body: some View {
        Group {
            if let resolvedURL {
                AsyncImage(url: resolvedURL) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .interpolation(.high)
                            .antialiased(true)
                            .aspectRatio(contentMode: mode == .fill ? .fill : .fit)
                    case .empty:
                        placeholder(showSpinner: true)
                    case .failure:
                        placeholder(showSpinner: false)
                    @unknown default:
                        placeholder(showSpinner: false)
                    }
                }
            } else {
                placeholder(showSpinner: false)
            }
        }
        .clipped()
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            if showPlaceholder {
                // v682: never show the filmstrip placeholder over catalog artwork/logo cards.
                // Keep a clean dark placeholder while images load/fail so Streaming Catalogs do not
                // flash generic movie icons across rows that already have valid artwork URLs.
                LinearGradient(colors: [.black.opacity(0.92), .gray.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if showSpinner {
                    ProgressView().scaleEffect(0.78).opacity(0.30)
                }
            } else {
                Color.clear
            }
        }
    }
}
