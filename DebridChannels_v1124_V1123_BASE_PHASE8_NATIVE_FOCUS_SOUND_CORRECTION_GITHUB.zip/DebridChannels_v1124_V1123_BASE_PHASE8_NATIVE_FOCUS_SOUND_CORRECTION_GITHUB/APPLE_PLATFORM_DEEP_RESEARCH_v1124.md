# v1124 Apple platform deep-research findings

The prior v1121-v1123 candidates used notification observation followed by independent AudioServices or AVAudioPlayer playback. Apple provides a dedicated focus-sound path for tvOS instead:

1. Register a local sound once with `UIFocusSystem.register(_:forSoundIdentifier:)`.
2. Register early because focus-sound preparation is nontrivial.
3. Never register the same identifier twice; Apple documents that duplicate registration can assert.
4. Place focused content under a `UIFocusEnvironment` and override `soundIdentifierForFocusUpdate(in:)`.
5. Return the registered identifier for an eligible movement or `.none` for an ineligible movement.

v1124 implements that native path and removes navigation-sound ownership of the app audio session.

System-setting test requirement:

Apple documents Apple TV's Navigation Clicks option as the control for hearing clicks while navigating between items. Apple does not explicitly state in the retrieved API article that every registered custom focus cue is suppressed when this switch is Off. Because v1124 now uses the system focus-sound pipeline rather than independent media playback, physical testing must be performed with Apple TV Settings > Video and Audio > Navigation Clicks set to On. Debrid Channels Settings > Navigation Sounds must also be On.

Apple documentation reviewed:

- https://developer.apple.com/documentation/uikit/using-custom-sounds-for-focus-movement
- https://developer.apple.com/documentation/uikit/uifocussystem/register(_:forsoundidentifier:)
- https://developer.apple.com/documentation/uikit/uifocusenvironment/soundidentifierforfocusupdate(in:)
- https://developer.apple.com/documentation/uikit/uifocussoundidentifier
- https://support.apple.com/guide/tv/change-audio-settings-atvba773c3c9/tvos
