# vBRDC353 — Preview Mirror Chrome Polish

Source base: vBRDC352 Preview Mirror Page Indicator

Included changes:
- Harden 15-second Preview Mirror top-menu auto-hide with a dedicated task owner.
- Lower and better align the revealed Preview Mirror top menu.
- Reduce Preview Mirror search/clock size and place them closer to the Settings end of the top bar.
- Tighten the focused footer chip shape for Categories / Guide / Options.

Regression intent:
- Preview Mirror only.
- Golden Live TV layout and non-Live TV top navigation remain unchanged.
