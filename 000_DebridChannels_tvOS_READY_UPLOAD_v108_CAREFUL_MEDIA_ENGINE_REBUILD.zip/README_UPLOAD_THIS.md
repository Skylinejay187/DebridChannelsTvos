# Debrid Channels tvOS v106 — Aspect-Fit Player Compile Fix

This build fixes the v105 compile error by adding the missing `AVPlayerControllerSurface` renderer.

Player behavior:
- The player view occupies the tvOS canvas so it is not hidden or clipped.
- The video content defaults to `resizeAspect`, so it keeps its intended aspect ratio by default.
- Apple playback controls remain disabled; Debrid Channels custom overlay is used.

Build marker: `DEBRID_CHANNELS_TVOS_BUILD_V106_ASPECT_FIT_PLAYER_COMPILE_FIX`
