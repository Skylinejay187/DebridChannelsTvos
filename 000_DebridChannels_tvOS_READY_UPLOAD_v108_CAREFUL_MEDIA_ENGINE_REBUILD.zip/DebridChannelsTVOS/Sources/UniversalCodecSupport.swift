import SwiftUI
import AVFoundation
import AVKit

#if canImport(TVVLCKit)
import TVVLCKit
#endif

// v95 universal-codec boundary:
// - AVFoundation remains the fast/default Apple-native path.
// - TVVLCKit is used automatically when the framework is present and the URL/container
//   looks like an MKV/DTS/unsupported-codec edge case.
// - Raw magnet/torrent streaming still requires a separate torrent framework/service;
//   this file exposes diagnostics so the app does not claim a magnet is directly playable.

enum UniversalCodecSupport {
    static let buildMarker = "DEBRID_CHANNELS_TVOS_BUILD_V108_CAREFUL_MEDIA_ENGINE_REBUILD"

    static var vlcCompiledIn: Bool {
        #if canImport(TVVLCKit)
        return true
        #else
        return false
        #endif
    }

    static func shouldPreferVLC(for url: URL, hint: String = "") -> Bool {
        let value = (url.absoluteString + " " + hint).lowercased()
        if value.hasPrefix("magnet:") { return false }
        // Keep Apple-native AVFoundation first for normal HLS/MP4/MOV HEVC/H.264/HDR because it is
        // the best path for Apple TV hardware decode, frame pacing, HDR, and Dolby Vision when the
        // stream is authored in an Apple-compatible container/profile.
        if value.contains(".m3u8") || value.contains("application/vnd.apple.mpegurl") { return false }
        if value.contains(".mp4") || value.contains("%2emp4") || value.contains(".mov") || value.contains("%2emov") { return false }

        // Route obvious non-Apple containers / audio codec edge cases to libVLC when present.
        return value.contains(".mkv")
            || value.contains("%2emkv")
            || value.contains("/mkv")
            || value.contains("=mkv")
            || value.contains("matroska")
            || value.contains("dts")
            || value.contains("dts-hd")
            || value.contains("dtshd")
            || value.contains("truehd")
            || value.contains("mlp")
            || value.contains("profile 7")
            || value.contains("dvhe.07")
            || value.contains("dolby vision profile 7")
    }

    static func playbackEngineName(for url: URL, hint: String = "") -> String {
        if shouldPreferVLC(for: url, hint: hint) && vlcCompiledIn { return "TVVLCKit/libVLC fallback" }
        if shouldPreferVLC(for: url, hint: hint) && !vlcCompiledIn { return "AVFoundation fallback; TVVLCKit pod missing" }
        return "AVFoundation hardware path"
    }

    static func magnetDiagnostic(for value: String) -> String? {
        let lower = value.lowercased()
        guard lower.hasPrefix("magnet:") || lower.contains("infohash") else { return nil }
        return "Magnet/infoHash items require the torrent framework/service path before playback. Direct TorBox/debrid HTTP(S) stream URLs play in-app; raw torrent streaming is isolated from AVFoundation."
    }
}

struct UniversalVideoSurface: View {
    let url: URL
    let avPlayer: AVPlayer?
    let videoGravity: AVLayerVideoGravity
    var forceVLC: Bool = false
    var routeHint: String = ""

    var body: some View {
        Group {
            #if canImport(TVVLCKit)
            if forceVLC || UniversalCodecSupport.shouldPreferVLC(for: url, hint: routeHint) {
                TVVLCKitVideoSurface(url: url)
            } else {
                AVPlayerControllerSurface(player: avPlayer, videoGravity: videoGravity)
            }
            #else
            AVPlayerControllerSurface(player: avPlayer, videoGravity: videoGravity)
            #endif
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
    }
}

#if canImport(TVVLCKit)
struct TVVLCKitVideoSurface: UIViewRepresentable {
    let url: URL

    final class Coordinator {
        let player = VLCMediaPlayer()
        var currentURL: URL?
    }

    final class VLCView: UIView {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> VLCView {
        let view = VLCView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: VLCView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func configure(view: VLCView, coordinator: Coordinator) {
        guard coordinator.currentURL != url else { return }
        coordinator.currentURL = url
        coordinator.player.drawable = view
        coordinator.player.media = VLCMedia(url: url)
        coordinator.player.play()
    }

    static func dismantleUIView(_ uiView: VLCView, coordinator: Coordinator) {
        coordinator.player.stop()
    }
}
#endif


// v106: AVPlayerViewController-backed surface used only as a rendering container.
// Apple transport controls remain disabled; Debrid Channels draws its own overlay.
// resizeAspect is the default so video keeps the source aspect ratio and does not crop/stretch.
struct AVPlayerControllerSurface: UIViewControllerRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player {
            controller.player = player
        }
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.player = nil
    }
}
