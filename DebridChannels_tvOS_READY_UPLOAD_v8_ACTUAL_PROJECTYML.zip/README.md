# Debrid Channels tvOS Build Repo

This repo contains a source ZIP and a GitHub Actions workflow that recursively extracts ZIPs, finds `project.yml`, generates the tvOS Xcode project with XcodeGen, builds unsigned, and uploads an IPA artifact.

Run: **00 Build tvOS IPA From Source ZIP**
