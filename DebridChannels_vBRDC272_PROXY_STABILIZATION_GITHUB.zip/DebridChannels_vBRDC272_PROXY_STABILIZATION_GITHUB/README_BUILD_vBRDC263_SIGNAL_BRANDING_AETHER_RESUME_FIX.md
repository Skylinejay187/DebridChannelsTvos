# vBRDC263 — Signal Branding + Aether Durable Resume Fix

Version 1.0.966 (966).

- Built forward from vBRDC262 only.
- Replaces all canonical tvOS AppIcon layers and raw sideload fallbacks with correctly sized Signal artwork (400x240 / 1280x768).
- Replaces canonical normal/wide Top Shelf images and legacy Top Shelf images with Signal branding; no Debrid Channels shelf artwork remains.
- Uses the user-selected metallic SIGNAL/broadcast-wave wordmark treatment.
- Aether VOD now resolves durable resume after transient engine-state clearing and seeds the saved checkpoint into the Aether host's initial load, while retaining the existing seek/clock confirmation/retry path.
- KSPlayer resume behavior and the accepted Aether 6.81 Live TV recovery ladder are unchanged.
