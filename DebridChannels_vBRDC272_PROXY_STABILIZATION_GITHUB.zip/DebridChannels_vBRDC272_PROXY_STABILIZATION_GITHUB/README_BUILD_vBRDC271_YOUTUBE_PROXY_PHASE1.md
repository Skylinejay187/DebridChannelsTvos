# vBRDC271 — Signal YouTube Proxy Phase 1

Version: 1.0.974 (974)

This candidate starts the dedicated YouTube trailer transport before Live TV timeshift and VOD cache.

## App-side
- Adds Settings → Trailers → YouTube Trailer Proxy URL.
- When configured, full trailer resolve is proxy-authoritative and does not fall through to the normal Signal/Debrid `/trailers/resolve` backend.
- Focused trailer preview also uses the proxy at a capped 720p resolve target.
- Proxy returns a local relay URL; the selected trailer player (AetherEngine / KSPlayer / AVPlayer) consumes that URL.
- Existing non-proxy trailer path remains unchanged when no proxy URL is configured.

## Proxy service
`YouTubeProxy/` contains a Docker-ready service for Unraid or any Docker host.

- Uses yt-dlp for metadata/extraction only.
- Does not download trailer files to disk.
- Combined formats are relayed with HTTP Range support.
- Higher-quality separate video/audio representations are remuxed live with ffmpeg `-c copy` into fragmented MP4.
- Resolver metadata and temporary YouTube URLs are held only in RAM for a short TTL.
- Default max height: 2160p.

See `YouTubeProxy/README.md` for deployment.

## Validation performed here
- All Swift sources: `swiftc -parse` pass.
- App and Top Shelf plists: valid.
- `project.yml`: YAML parse pass.
- Proxy `server.mjs`: `node --check` pass.
- Version identifiers synchronized to vBRDC271 / 1.0.974 / 974.

GitHub/Xcode compile and physical Apple TV runtime remain authoritative.
