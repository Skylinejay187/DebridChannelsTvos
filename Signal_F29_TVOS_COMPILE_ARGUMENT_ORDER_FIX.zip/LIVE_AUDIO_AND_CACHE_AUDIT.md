# Signal F29 — Cover Flow decoded-cache reuse checkpoint

## Implemented
- Cover Flow reflection uses same 400-pixel decode bucket as its visible side poster; this avoids a second decoded bitmap request for the same artwork.
- Suppressed loading placeholder in the decorative reflection.
- Entering VOD retains decoded catalog images under the existing 32 MB exclusive-playback cache ceiling instead of explicitly clearing the entire persistent image cache.
- Existing VOD metadata persistence and wizard removal preserved.

## Not yet fixed / needs actual engine + on-device evidence
- Live TV audio cutouts on specific channels. Current bridge only automatically retunes on `.droppedNoPipeline`; valid-pipeline silence requires engine audio clock/output evidence and codec-specific channel samples.
- Live TV exit-induced cumulative UI lag. Need instrument decoder lifetime, live grid preview ownership, EPG work, timer/observer counts, and main-thread stalls over repeated entry/exit cycles.
- Persistent image cache across different users/devices: decoded `NSCache` is local to each running app process and is not a cross-user server cache. Disk/network cache reuse depends on URL, HTTP caching and Kingfisher cache keys. This patch does not add cross-device shared caching.

## Validation
Swift frontend parse and F28 source preflight passed; F29 build identity, diagnostic redaction and thumbnail gate passed. No full tvOS SDK compilation or Apple TV runtime verification.
