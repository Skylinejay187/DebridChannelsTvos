# Signal F29 — Unified dashboard / catalog image reuse checkpoint

Source changes:
- Removed Golden as a separate selectable Live TV dashboard. Existing Golden persisted values normalize to Preview Mirror; new/default/restored selection is Preview Mirror. Preserves old Golden implementation in source for now to avoid deleting shared logic before an actual tvOS compile and regression tests. Gold appearance is NOT YET implemented as a dedicated Preview Mirror theme; do not claim it is.
- 3D side poster and reflection now use the same 400-pixel decode bucket; reflection does not show an independent placeholder.
- VOD entry no longer clears the entire decoded catalog poster cache; the bounded 32MB ceiling remains. This is a local reuse improvement, NOT proof of shared CatalogServer integration.

Unresolved, not claimed fixed:
- Main catalog / Cover Flow card URL path vs CatalogServer Phase 2.14 shared poster-card route and prefetch across devices.
- Live TV AetherEngine audio silence on selected channels; codec-specific diagnostics and decoder recovery.
- Lag accumulating after entering/exiting Live TV; lifecycle/task/observer profiling.
- Gold visual styling within the single Preview Mirror dashboard.
- Full tvOS build, deployment, real hardware verification.

Local checks: Swift syntax parse, F28 preflight, F29 build identity, remote thumbnail gate passed.
