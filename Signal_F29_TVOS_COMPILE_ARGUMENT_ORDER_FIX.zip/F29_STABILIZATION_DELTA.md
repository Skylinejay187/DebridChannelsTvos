# Signal F29 stabilization delta (source candidate)

Base: F29 Unified Dashboard Cache Checkpoint, preserving removal of Acquisition Wizard.

- Preserve unified Preview Mirror dashboard and Cover Flow decoded-image reuse from base.
- Live audio: second confirmed `droppedNoPipeline` retune advances to the existing bounded Aether route fallback rather than blindly repeating the same decoder route. First event retries same route.
- Live recovery: canceled cooldown sleeps no longer continue toward retune.

Not verified: tvOS device playback, server cache integration, silent-audio cases without `droppedNoPipeline`, cumulative UI lag, Golden-as-theme, full Xcode compile. This is NOT the requested final upload-ready release.
