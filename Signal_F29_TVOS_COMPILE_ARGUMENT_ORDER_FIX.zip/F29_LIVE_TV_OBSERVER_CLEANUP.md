# F29 Live TV observer cleanup checkpoint

On Live TV transient teardown, unregister the AVPlayer periodic time observer before discarding its token and invalidate the KVO status observer. Previously both tokens were assigned nil without explicit removal in this path. The existing full teardown remains unchanged.

Validated: Swift syntax parse of modified app source and ZIP integrity. Full tvOS compilation and Apple TV runtime verification still required. This is not a final release candidate.
