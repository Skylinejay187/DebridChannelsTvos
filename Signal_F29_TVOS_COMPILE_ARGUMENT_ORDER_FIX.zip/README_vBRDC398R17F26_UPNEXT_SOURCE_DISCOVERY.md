# vBRDC398R17F26 — Up Next source discovery repair

Patch forward from F25.

## Root cause confirmed in source
- The previous next-episode metadata preparation only invoked source resolution when `!isPlaying`.
- The completed source resolution task discarded its results if `isPlaying` was true.
- The playback watchdog also invoked source preparation only when paused or after EOF.
These three conditions made the intended pre-EOF link preparation impossible during normal playback.

## F26 changes
- Permit independent next-episode source discovery while the current episode is playing, after episode identity is known.
- Retain results when playback is still active, scoped to the originating playback presentation and URL.
- Invoke source preparation from the existing 210-second watchdog window, with existing attempt limits, retry spacing and buffer guards.
- Leave Up Next popup presentation and current playback untouched; do not duplicate the player.
- Simplify MediaFlow Light credential labels and placeholders; preserve F25's separate Light credentials and confirmed-working routing.
- Keep GPU Enhancement removed, with stock rendering retained.

## Validation caveat
Swift syntax parsed on Linux, but full tvOS Xcode compilation and real-provider playback need Apple TV testing. Link discovery may still fail for a specific provider or metadata ID, which requires source diagnostics.
