# vBRDC398R15F2 — Media Information Cover Flow clearance

Base: vBRDC398R15F1 version-synchronized source.

- In 3D Cover Flow catalog mode, suppress the decorative connector from the focused card to Media Information, regardless of the global connector setting, so the line cannot cross the focused landscape card.
- In 3D Cover Flow catalog mode, raise the catalog Media Information panel 86 points (offset y=126 -> y=40). This shifts its credits/cast section upward as one surface without modifying the focused card or carousel geometry.
- Preserve Classic Rows connector and panel positions, Search/Favorites presentation, source links and popup interactions.
- Version synchronized to 1.0.1117 (build 1117) for main app, Top Shelf and project.yml.

Validation: Swift syntax parse, plist parse, version consistency and ZIP integrity. Not compiled in Xcode or device-tested.
