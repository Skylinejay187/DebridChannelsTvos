# F29 Live TV handoff checkpoint

Source change: `teardownLiveTVTransientState()` retains the 32 MB decoded-artwork
budget during a Quick Guide channel-to-channel handoff, restoring the catalog
budget only when Live TV is actually dismissed. This prevents cache-limit
oscillation across consecutive channel changes. It does not fix or claim to
fix channel-specific audio cutouts or prove memory/CPU stability.

Validation: F29 static invariants, Swift frontend syntax parse, F28 74-file
preflight, build 1135 identity. Full Xcode/tvOS compilation and device tests
still required.

Device test sequence:
1. Open 3D Cover Flow and scroll through several poster rows.
2. Start Live TV, switch channels repeatedly using Quick Guide (10+ changes).
3. Exit Live TV to 3D Cover Flow and confirm posters remain populated.
4. Repeat 10 Live TV enter/exit cycles and check responsiveness, CPU/memory,
   background/foreground black screen, and audio on previously failing channels.
5. Verify Live TV timeshift and VOD playback still work.
