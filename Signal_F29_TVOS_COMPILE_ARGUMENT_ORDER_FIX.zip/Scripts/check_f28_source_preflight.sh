#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo 'F28 preflight: all app and packaged bridge Swift syntax'
# macOS ships Bash 3.2, which does not support mapfile/readarray.
# Use portable Bash arrays and NUL-delimited paths to preserve filenames.
SWIFT_FILES=()
while IFS= read -r -d '' file; do
  SWIFT_FILES+=("$file")
done < <(find Sources TopShelfExtension Vendor/AetherPlaybackKit/Sources -name '*.swift' -type f -print0)
if (( ${#SWIFT_FILES[@]} == 0 )); then echo 'No Swift sources found' >&2; exit 1; fi
swiftc -frontend -parse "${SWIFT_FILES[@]}"
echo 'F28 preflight: bridge parity and installer checks'
cmp Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift
bash -n Scripts/check_f28_source_preflight.sh Scripts/fetch_aether_f28_744.sh Scripts/prepare_build_deps_vBRDC280.sh
python3 -m py_compile Scripts/verify_f28_aether_integration.py Scripts/verify_f28_fastzap_wiring.py
python3 Scripts/verify_f28_fastzap_wiring.py
grep -q '7.44.0' Scripts/fetch_aether_f28_744.sh
# Both direct bridge callers and the SwiftUI surface must sanitize resume time.
python3 - <<'PY_RESUME_TIME'
from pathlib import Path
bridge = Path('Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
surface = Path('Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
assert 'startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0' in bridge
assert 'startTimeSeconds.isFinite ? max(0, startTimeSeconds) : 0' in surface
print('F28 bridge and surface resume timestamp guards verified')
PY_RESUME_TIME
# The engine installer must reject overlapping builds before touching the
# existing vendor checkout. Exercise the real script with a held lock.
python3 - <<'PY_INSTALL_LOCK'
from pathlib import Path
import subprocess
root = Path.cwd()
lock = root / '.build-cache' / 'aether-f28-install.lock'
lock.parent.mkdir(parents=True, exist_ok=True)
if lock.exists():
    raise SystemExit(f'Cannot test install lock: existing lock requires inspection: {lock}')
lock.mkdir()
try:
    result = subprocess.run(['bash', 'Scripts/fetch_aether_f28_744.sh'],
                            capture_output=True, text=True, timeout=10)
    if result.returncode == 0 or 'Another F28 AetherEngine installation is active' not in result.stderr:
        raise SystemExit('Concurrent engine installation was not rejected')
    if not lock.is_dir():
        raise SystemExit('Rejected installer removed a lock it did not own')
finally:
    lock.rmdir()
print('F28 concurrent AetherEngine installer lock verified')
PY_INSTALL_LOCK
# The rollback handler must retain the lock until recovery is complete.
python3 - <<'PY_ROLLBACK_LOCK'
from pathlib import Path
s = Path('Scripts/fetch_aether_f28_744.sh').read_text()
start = s.index('restore_previous() {')
end = s.index('\ntrap restore_previous EXIT', start)
handler = s[start:end]
assert handler.index('rm -rf "$TMP"') < handler.index('release_install_lock'), \
    'Installer unlocks before failed-install cleanup finishes'
assert handler.index('mv "$PREVIOUS" "$DEST"') < handler.index('release_install_lock'), \
    'Installer unlocks before restoring the previous engine'
print('F28 installer rollback lock ordering verified')
PY_ROLLBACK_LOCK
# Verify the staged-engine patch keeps finite-value guards at every gain entry.
python3 - <<'PY_GAIN_GUARDS'
from pathlib import Path
source = Path('Scripts/fetch_aether_f28_744.sh').read_text()
required = (
    'let clamped = db.isFinite ? max(0, min(12, db)) : 0',
    'signalAudioGainDB = db.isFinite ? max(0, min(12, db)) : 0',
    'softwareHost?.setAudioGainDB(db.isFinite ? max(0, min(12, db)) : 0)',
)
for guard in required:
    if guard not in source:
        raise SystemExit(f'Missing engine audio-gain finite guard: {guard}')
print('F28 staged Aether audio-gain finite guards verified (3)')
PY_GAIN_GUARDS
# A checkout whose pinned-version marker is intact but whose Git tag drifted
# must enter the rollback path rather than being accepted as a valid engine.
python3 - <<'PY_TAG_ROLLBACK'
from pathlib import Path
source = Path('Scripts/fetch_aether_f28_744.sh').read_text()
recovery = source.split('if [[ -e "$PREVIOUS" && -e "$DEST"', 1)[1].split('if [[ -f "$DEST/.signal-f28-version"', 1)[0]
assert 'git -C "$DEST" describe --tags --exact-match' in recovery
assert 'mv "$PREVIOUS" "$DEST"' in recovery
print('F28 pinned-tag drift recovery path verified')
PY_TAG_ROLLBACK
# A remote/foreground Play assertion must not resurrect the previous episode
# after the terminal event has been delivered to Up Next.
python3 - <<'PY_UPNEXT_END_ASSERTION'
from pathlib import Path
source = Path('Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
assert 'shouldPlay == coordinator.lastShouldPlay && !coordinator.didReachNaturalEnd' in source
assert 'coordinator.didReachNaturalEnd = false\n                Self.performNoArgumentSelector("aetherPlay"' not in source
print('F28 Up Next natural-end assertion guard verified')
PY_UPNEXT_END_ASSERTION
echo "F28 preflight passed (${#SWIFT_FILES[@]} Swift files)."
