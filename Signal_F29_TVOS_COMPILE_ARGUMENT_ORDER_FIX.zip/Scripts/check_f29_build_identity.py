#!/usr/bin/env python3
"""Verify F29 app and Xcode build identities remain aligned."""
from pathlib import Path
import plistlib
import re
root = Path(__file__).resolve().parents[1]
project = (root / 'project.yml').read_text()
info = plistlib.loads((root / 'Sources/Info.plist').read_bytes())
assert info['CFBundleShortVersionString'] == '1.0.1135'
assert info['CFBundleVersion'] == '1135'
assert info['DebridChannelsReleaseID'] == 'Signal-F29'
assert len(re.findall(r'^\s*MARKETING_VERSION:\s*1\.0\.1135\s*$', project, re.M)) == 2
assert len(re.findall(r'^\s*CURRENT_PROJECT_VERSION:\s*1135\s*$', project, re.M)) == 2
print('F29 build 1135 identity verified across app and Xcode targets')
