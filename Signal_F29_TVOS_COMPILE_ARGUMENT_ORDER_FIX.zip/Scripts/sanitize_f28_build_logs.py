#!/usr/bin/env python3
"""Write redacted diagnostic copies; never publish the original build logs."""
from pathlib import Path
import re

LOGS = ('f28-preflight.log', 'f28-engine-install.log', 'f28-engine-verify.log', 'f28-build.log')
OUT = Path('f28-public-diagnostics')


def sanitize(line: str) -> str:
    # URLs can contain signed playback credentials in query parameters.
    line = re.sub(r'(?i)\b(?:https?|rtsp|rtmp)://[^\s\x00-\x1f<>"\']+', '[redacted-url]', line)
    # Both header-style and JSON-style Authorization values.
    line = re.sub(r'(?i)(\b["\']?authorization["\']?\s*[:=]\s*["\']?)(?:bearer\s+|basic\s+)?[^\s,;"\']+', r'\1[redacted]', line)
    # Quoted JSON keys and bare key=value diagnostic fields.
    line = re.sub(r'(?i)(\b(?:access_token|refresh_token|api_key|apikey|password|secret|token)["\']?\s*[:=]\s*["\']?)[^\s,;"\'}]+', r'\1[redacted]', line)
    return line


def main() -> None:
    OUT.mkdir(exist_ok=True)
    for name in LOGS:
        path = Path(name)
        if path.is_file():
            with path.open(errors='replace') as src, (OUT / name).open('w', encoding='utf-8') as dst:
                for line in src:
                    dst.write(sanitize(line))
            print(f'Sanitized {name}')


if __name__ == '__main__':
    main()
