#!/usr/bin/env python3
"""Static guardrails for F29 stabilization; not a tvOS runtime test."""
from pathlib import Path
root = Path(__file__).resolve().parent.parent
art = (root/'Sources/RemoteImageFit.swift').read_text()
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
aether = (root/'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
checks = {
    'shared backend artwork routing': 'sharedBackendArtworkURL(raw)' in art and '/api/image' in art,
    'mounted artwork protected during live playback': 'mountedCatalogKeys.contains($0)' in art,
    'catalog decode budget restored after live playback': 'restoreCatalogDecodeBudgetAfterLiveTV()' in app,
    'live channel handoff keeps reduced decode budget': 'if shouldClearSharedQuickGuide {\n            PremiumRemoteImageLoader.restoreCatalogDecodeBudgetAfterLiveTV()' in app,
    'live playback time observer explicitly unregistered': 'player.removeTimeObserver(timeObserver)' in app,
    'live playback status observer invalidated': 'statusObserver?.invalidate()' in app,
    'full player teardown clears observer handles': 'timeObserver = nil\n        statusObserver?.invalidate()\n        statusObserver = nil' in app,
    'live retune bounded': 'self.liveRetuneCount < 3' in aether,
    'retune tied to current generation': 'self.generation == expectedGeneration' in aether,
    'no secondary KSPlayer import in bridge': 'import KSPlayer' not in aether,
    'vendor bridge matches app bridge': aether == (root/'Vendor/AetherPlaybackKit/Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text(),
}
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if not all(checks.values()):
    raise SystemExit(1)
