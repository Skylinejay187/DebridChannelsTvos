#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
echo "============================================================"
echo "SIGNAL F29 / BUILD 1135 PREFLIGHT + AETHER 7.44.0 DEPENDENCIES"
echo "============================================================"
# Fail fast on local source/asset mistakes before spending minutes downloading/building dependencies.
mkdir -p .build-cache/actool-preflight
echo "Fast preflight: Swift syntax..."
xcrun swiftc -parse Sources/PlaybackKit/PlaybackKitAetherSurface.swift Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift Sources/DebridChannelsTVOSApp.swift TopShelfExtension/ContentProvider.swift
echo "Fast preflight: tvOS asset catalog/AppIcon..."
rm -rf .build-cache/actool-preflight/*
xcrun actool Resources/Assets.xcassets \
  --compile .build-cache/actool-preflight \
  --platform appletvos \
  --minimum-deployment-target 18.0 \
  --target-device tv \
  --app-icon AppIcon \
  --output-partial-info-plist .build-cache/actool-preflight/asset-info.plist >/dev/null
echo "Fast preflight passed. Preparing AetherEngine-only dependency graph."
bash Scripts/fetch_aether_f28_744.sh
# Do not allow the Xcode build to proceed with an unpatched engine or stale bridge.
python3 Scripts/verify_f28_aether_integration.py

echo "AetherEngine 7.44.0 dependency and Signal audio-gain integration verified."
