#!/usr/bin/env python3
"""Static F28 FastZap contract checks; complements (not replaces) tvOS runtime tests."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
app = (root / 'Sources/DebridChannelsTVOSApp.swift').read_text()
surface = (root / 'Sources/UniversalCodecSupport.swift').read_text()
host = (root / 'Sources/PlaybackKit/PlaybackKitAetherSurface.swift').read_text()
bridge = (root / 'Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift').read_text()
key = 'signalFastZapFullScreenV1'

checks = {
    'Full-screen preference defaults off': f'@AppStorage("{key}") private var fastZapFullScreen: Bool = false' in surface,
    'Settings preference defaults off': f'@AppStorage("{key}") private var fastZapFullScreen: Bool = false' in app,
    'Full-screen surface passes live-only opt-in': 'fastLiveJoin: isLiveStream && fastZapFullScreen' in surface,
    'Host forwards opt-in at load': 'view.setValue(NSNumber(value: isLiveStream && fastLiveJoin), forKey: "configuredFastLiveJoin")' in host,
    'Bridge exports FastZap KVC property': '@objc public dynamic var configuredFastLiveJoin: Bool = false' in bridge,
    'Bridge passes opt-in into live options': 'options.liveJoinStartsImmediately = configuredFastLiveJoin' in bridge,
    'Route options reset to standard': re.search(r'private func liveOptions\(.*?options\.liveJoinStartsImmediately = false', bridge, re.S) is not None,
    'First attempt only, recovery uses standard': 'options.liveJoinStartsImmediately = attempt == 1 && baseOptions.liveJoinStartsImmediately' in bridge,
    'Attempt counter reset for new session': 'liveAttemptSerial = 0' in bridge,
    'Setting included in backup': f'"{key}": fastZapFullScreen' in app,
    'Setting restored from backup': f'fastZapFullScreen = settings["{key}"] as? Bool ?? false' in app,
    'Setting reset to stable default': 'fastZapFullScreen = false' in app,
    'Tune timing uses monotonic uptime': 'liveAttemptStartedAt = ProcessInfo.processInfo.systemUptime' in bridge,
    'First-frame timing records FastZap mode': 'elapsedMs=' in bridge and 'liveAttemptFastJoin ? "fast" : "standard"' in bridge,
    'Tune timing resets for new playback': 'liveAttemptStartedAt = nil' in bridge,
    'Stopped sessions clear tune timing': 'liveAttemptStartedAt = nil\n        liveAttemptFastJoin = false\n        liveBaseOptions = nil' in bridge,
    'Failed routes record time-to-timeout': 'noFirstFrame route=' in bridge and 'elapsedMs=' in bridge,
    'Fast initial failure retries same route in Standard': 'let retryStandardOnSameRoute = liveAttemptSerial == 1 && liveAttemptFastJoin' in bridge and 'retryStandardOnSameRoute ? liveRoute : nextLiveRoute(after: liveRoute)' in bridge,
    'Same-route retry cannot reenable FastZap': 'options.liveJoinStartsImmediately = attempt == 1 && baseOptions.liveJoinStartsImmediately' in bridge,
    'Live diagnostics omit raw source hints': r'hintPresent=\(!configuredSourceHint.isEmpty)' in bridge and r'hint=\(configuredSourceHint)' not in bridge,
    'Live load failures omit potentially sensitive error descriptions': 'load failed: domain=' in bridge and r'load failed: \(error.localizedDescription)' not in bridge,
    'Live diagnostics redact path credentials': 'return "\\(scheme)://\\(host)"' in bridge and 'components.string' not in bridge[bridge.index('private static func redactedLiveURL'):bridge.index('private func initialLiveRoute')],
}
for label, ok in checks.items():
    print(f'{"PASS" if ok else "FAIL"}: {label}')
if not all(checks.values()):
    raise SystemExit('F28 FastZap integration contract failed')
