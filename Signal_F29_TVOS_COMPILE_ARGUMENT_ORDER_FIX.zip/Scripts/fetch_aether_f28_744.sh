#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TAG="7.44.0"
URL="https://github.com/superuser404notfound/AetherEngine.git"
DEST="$ROOT/Vendor/AetherEngine"
CACHE="$ROOT/.build-cache"
TMP="$CACHE/aether-f28-${TAG}-incoming"
PREVIOUS="$CACHE/aether-f28-previous"
mkdir -p "$CACHE"
# Two xcodegen/build invocations must never patch or swap the same vendor
# checkout concurrently. mkdir is atomic on both macOS and Linux.
LOCK="$CACHE/aether-f28-install.lock"
if ! mkdir "$LOCK" 2>/dev/null; then
  echo "Another F28 AetherEngine installation is active (lock: $LOCK). Wait for it to finish; inspect the lock if the prior process crashed." >&2
  exit 1
fi
# Retain the lock on abnormal termination only until the shell exits. A hard
# kill can leave it behind deliberately, requiring manual inspection.
release_install_lock() { rmdir "$LOCK" 2>/dev/null || true; }
trap release_install_lock EXIT
# An interrupted rename may leave the newly installed engine present but
# incomplete or its Git checkout no longer matches the pinned release.
# If a verified rollback exists, recover instead of repeatedly
# treating a broken 7.44.0 tree as the installed engine.
if [[ -e "$PREVIOUS" && -e "$DEST" && -f "$DEST/.signal-f28-version" ]] && grep -qx "$TAG" "$DEST/.signal-f28-version"; then
  if [[ "$(git -C "$DEST" describe --tags --exact-match 2>/dev/null || true)" != "$TAG" ]] || ! python3 "$ROOT/Scripts/verify_f28_aether_integration.py" >/dev/null 2>&1; then
    if [[ ! -f "$PREVIOUS/Package.swift" || ! -d "$PREVIOUS/Sources/AetherEngine" ]]; then
      echo 'Installed engine is invalid and rollback checkout is incomplete; preserving both for inspection.' >&2
      exit 1
    fi
    # Preserve the broken checkout for diagnostics; never discard it silently.
    BROKEN="$CACHE/aether-f28-failed-install"
    if [[ -e "$BROKEN" ]]; then
      echo "Installed engine is invalid; existing diagnostic checkout at $BROKEN prevents safe recovery." >&2
      exit 1
    fi
    mv "$DEST" "$BROKEN"
    mv "$PREVIOUS" "$DEST"
    echo 'Recovered previous AetherEngine after incomplete F28 installation; rerun after inspecting failed checkout.' >&2
    exit 1
  fi
fi
if [[ -f "$DEST/.signal-f28-version" && -f "$DEST/Package.swift" && -d "$DEST/Sources/AetherEngine" ]] && grep -qx "$TAG" "$DEST/.signal-f28-version"; then
  [[ "$(git -C "$DEST" describe --tags --exact-match 2>/dev/null)" == "$TAG" ]] || { echo "Installed AetherEngine tag mismatch" >&2; exit 1; }
  python3 "$ROOT/Scripts/verify_f28_aether_integration.py"
  echo "F28 AetherEngine $TAG already staged and verified"; exit 0
fi
if [[ -e "$PREVIOUS" && ! -e "$DEST" ]]; then
  # Power loss or process termination between the two renames can leave only
  # the rollback checkout. Restore it before exiting so the next build does
  # not run against a missing engine or discard the last usable source tree.
  if [[ ! -f "$PREVIOUS/Package.swift" || ! -d "$PREVIOUS/Sources/AetherEngine" ]]; then
    echo "Interrupted upgrade has an incomplete rollback checkout: $PREVIOUS" >&2
    exit 1
  fi
  mv "$PREVIOUS" "$DEST"
  echo 'Restored previous AetherEngine after interrupted upgrade; rerun to retry.' >&2
  exit 1
fi
if [[ -e "$PREVIOUS" ]]; then
  # A prior successful installation intentionally leaves the previous vendor tree.
  # Do not destroy that rollback copy or overwrite it silently.
  if [[ -f "$DEST/.signal-f28-version" ]] && grep -qx "$TAG" "$DEST/.signal-f28-version"; then
    [[ "$(git -C "$DEST" describe --tags --exact-match 2>/dev/null)" == "$TAG" ]] || { echo "Installed AetherEngine tag mismatch" >&2; exit 1; }
    python3 "$ROOT/Scripts/verify_f28_aether_integration.py"
    echo "Existing $TAG source is present and verified, with prior rollback retained."; exit 0
  fi
  echo "Previous engine backup found: $PREVIOUS. Resolve the interrupted or previous upgrade before retrying." >&2
  exit 1
fi
# Install cleanup before cloning and patching: a failed network checkout,
# unexpected upstream API, or interrupted PCM patch must not leave a partial
# source tree that can be mistaken for a valid engine on the next attempt.
swap_started=0
backup_created=0
restore_previous() {
  status=$?
  trap - EXIT
  # Keep the exclusive lock throughout rollback and temporary-tree cleanup.
  # Releasing it first lets a competing installer race with recovery.
  if [[ $status -ne 0 ]]; then
    if [[ $swap_started -eq 1 ]]; then
      rm -rf "$DEST"
      if [[ $backup_created -eq 1 && -d "$PREVIOUS" ]]; then
        mv "$PREVIOUS" "$DEST"
        echo 'Restored previous AetherEngine after failed swap.' >&2
      else
        echo 'Removed failed AetherEngine installation; no previous vendor tree existed.' >&2
      fi
    fi
    rm -rf "$TMP"
  fi
  release_install_lock
  exit "$status"
}
trap restore_previous EXIT
# EXIT alone is not reliable for termination signals while a clone or vendor
# rename is in flight. Convert catchable termination signals into a nonzero
# exit so the same rollback handler runs before releasing the install lock.
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP
rm -rf "$TMP"
# A failed fetch never touches the installed vendor tree.
git clone --depth 1 --branch "$TAG" "$URL" "$TMP"
[[ "$(git -C "$TMP" describe --tags --exact-match 2>/dev/null)" == "$TAG" ]] || { echo "Wrong upstream release checkout" >&2; exit 1; }
[[ -f "$TMP/Package.swift" && -d "$TMP/Sources/AetherEngine" ]] || { echo 'Incomplete upstream checkout' >&2; exit 1; }
grep -q 'swift-tools-version: 6.1' "$TMP/Package.swift" || { echo 'Unexpected upstream package' >&2; exit 1; }
# Patch Signal PCM amplification while source is staged; fail before swapping on upstream API drift.
python3 - "$TMP" <<'PY_AETHER_GAIN'
from pathlib import Path
import sys
root = Path(sys.argv[1]) / "Sources" / "AetherEngine"

audio = root / "Audio" / "AudioDecoder.swift"
s = audio.read_text()
needle = "    private var clock = AudioClockAnchor()\n"
assert needle in s
s = s.replace(needle, needle + "    private var decodedGainLinear: Float = 1.0\n\n    func setGainDB(_ db: Double) {\n        let clamped = db.isFinite ? max(0, min(12, db)) : 0\n        decodedGainLinear = Float(pow(10.0, clamped / 20.0))\n    }\n", 1)
needle = "        guard convertedSamples > 0 else { return }\n\n        // First frame in a new accumulator captures the PTS"
assert needle in s
s = s.replace(needle, "        guard convertedSamples > 0 else { return }\n\n        if decodedGainLinear > 1.0001 {\n            let count = Int(convertedSamples) * Int(channels)\n            tempBuffer.withMemoryRebound(to: Float.self, capacity: count) { samples in\n                for index in 0..<count {\n                    let amplified = samples[index] * decodedGainLinear\n                    samples[index] = max(-1.0, min(1.0, amplified))\n                }\n            }\n        }\n\n        // First frame in a new accumulator captures the PTS", 1)
audio.write_text(s)

host = root / "Native" / "SoftwarePlaybackHost.swift"
s = host.read_text()
needle = "    private(set) var audioDelaySeconds: Double = 0\n"
assert s.count(needle) == 1
s = s.replace(needle, needle + "\n    private var signalAudioGainDB: Double = 0\n    func setAudioGainDB(_ db: Double) {\n        signalAudioGainDB = db.isFinite ? max(0, min(12, db)) : 0\n        audioDecoder?.setGainDB(signalAudioGainDB)\n    }\n", 1)
# A new decoder after audio-track switching must inherit the active gain.
needle = "                self.audioDecoder = aDec\n"
assert s.count(needle) == 1, "Audio decoder assignment changed upstream; review gain inheritance"
s = s.replace(needle, needle + "                aDec.setGainDB(signalAudioGainDB)\n", 1)
host.write_text(s)

ext = root / "AetherEngine+SignalAudioGain.swift"
ext.write_text("""import Foundation

extension AetherEngine {
    @MainActor public func setDecodedAudioGainDB(_ db: Double) {
        softwareHost?.setAudioGainDB(db.isFinite ? max(0, min(12, db)) : 0)
    }
}
""")
PY_AETHER_GAIN
# Swift 6 / Xcode 26.6: avoid sending an FFmpeg codecpar pointer through a
# closure that is invoked across a potential suspension boundary.
# Resolve the hardware capability while still in the current probe context;
# the closure then captures only a Sendable Bool. Preserve DV routing policy.
python3 - "$TMP" <<'PY_AETHER_SWIFT6_CODEC_PARAMETER'
from pathlib import Path
import sys
p = Path(sys.argv[1]) / 'Sources/AetherEngine/AetherEngine.swift'
s = p.read_text()
old = '''                   canHardwareDecode: { VTCapabilityProbe.canHardwareDecode(codecpar: codecpar) })'''
new = '''                   canHardwareDecode: { hardwareDecodeSupported })'''
assert s.count(old) == 1, 'Pinned AetherEngine 7.44.0 codecpar closure changed; review before building'
anchor = '''            let forcesSoftware = {'''
assert s.count(anchor) >= 1
# Restrict the insertion to the same routing-gate block, not another closure.
start = s.index('if !useSoftwarePath, probeOpened,')
pos = s.index(anchor, start)
assert old in s[pos:pos+1600], 'Expected codecpar routing closure not found near probe gate'
s = s[:pos] + '            let hardwareDecodeSupported = VTCapabilityProbe.canHardwareDecode(codecpar: codecpar)\n' + s[pos:]
assert s.count(old) == 1
s = s.replace(old, new, 1)
p.write_text(s)
PY_AETHER_SWIFT6_CODEC_PARAMETER
printf '%s\n' "$TAG" > "$TMP/.signal-f28-version"
# Verify the fully patched incoming checkout BEFORE moving the installed engine.
# An incompatible upstream layout must not trigger a vendor-tree swap.
python3 "$ROOT/Scripts/verify_f28_aether_integration.py" "$TMP"
if command -v swiftc >/dev/null 2>&1; then
  # Parse patched engine files in bounded batches (no Apple SDK required).
  python3 - "$TMP" <<'PY_STAGED_SWIFT_PARSE'
from pathlib import Path
import subprocess
import sys
sources = sorted((Path(sys.argv[1]) / 'Sources').rglob('*.swift'))
if not sources:
    raise SystemExit('Incoming AetherEngine has no Swift source')
for offset in range(0, len(sources), 50):
    subprocess.run(['swiftc', '-frontend', '-parse',
                    *map(str, sources[offset:offset + 50])], check=True)
print(f'Validated syntax of {len(sources)} staged AetherEngine Swift files')
PY_STAGED_SWIFT_PARSE
fi
# All prior stages remain protected by the same cleanup/rollback handler.
# All source patching/validation above occurred in TMP; no installed source
# is touched until the following same-filesystem rename succeeds.
if [[ -e "$DEST" ]]; then
  mv "$DEST" "$PREVIOUS"
  backup_created=1
  swap_started=1
else
  swap_started=1
fi
mv "$TMP" "$DEST"
[[ -f "$DEST/Package.swift" && -d "$DEST/Sources/AetherEngine" ]] || { echo 'Post-swap validation failed' >&2; exit 1; }
python3 "$ROOT/Scripts/verify_f28_aether_integration.py"
# Retain the previous vendor tree as a rollback checkpoint.
trap - EXIT
release_install_lock
echo "Staged upstream AetherEngine $TAG; F28 bridge compatibility still requires compilation and validation."
