DebridChannels tvOS v747_PROVIDER_HEADER_ROLLBACK_AND_FOCUSED_LABEL_FIX

- Restores next-row provider/category labels in the one-row quick panel.
- Keeps the duplicate plain `row.title` text removed from directly above the focused card.
- Uses the flat provider/category `ProviderBrandMark` header for the active row and lower/next visible row.
- Preserves v742+ Libmpv install/signing, VOD overlay, KSPlayer/AVPlayer playback, membership, source intelligence, trailer, and one-row quick panel geometry.
