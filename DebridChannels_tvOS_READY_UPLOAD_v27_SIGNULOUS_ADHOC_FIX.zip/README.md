# Debrid Channels tvOS v27 Signulous Ready

Upload this repo ZIP to GitHub and run `00 Build tvOS IPA From Source ZIP`.
Download the artifact ZIP, extract it, and upload only `DebridChannelsTVOS_v27_signulous_ready.ipa` to Signulous.
