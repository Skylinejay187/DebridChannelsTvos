# vBRDC398R15F5 — targeted source candidate

Base: vBRDC398R15F4 source archive (no earlier codebase substituted).

- **Only when VOD catalog layout is `3D Cover Flow`**, Media Information popup moves up by 180 layout points relative to R15F4, its panel receives a near-opaque black backing to block underlying cards and ghosted lines, and its internal decorative divider is omitted. Classic Rows remains on its prior offset/transparency/divider path.
- Side portraits have more restrained, symmetric inward-facing Y rotation (15–22.5 degrees, 0.30 perspective) and slight color/brightness compensation. This is an experimental correction requiring Apple TV screenshot review.
- Reflection image decode size lowered from 480 to 240 pixels to reduce per-navigation decode pressure. No change to actual card imagery resolution, focused video preview, or catalog selection.
- App and Top Shelf Info.plist plus project.yml version updated to 1.0.1120 (1120), release ID vBRDC398R15F5.

Validation: Swift frontend parse passed on Linux. Xcode/tvOS compilation and Apple TV visual/frame-time testing **not available** in this environment. In particular, smooth scrolling, exact overlay positioning and perceived brightness remain unverified. This is a test candidate, not a confirmed fix.
