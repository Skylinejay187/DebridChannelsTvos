# DebridChannels tvOS v764 Emergency Stability Rollback

Base: v763 clean recovery baseline.

Purpose: remove the unsafe v764 provider-picker / safe-English / scrubber focus patch set after user reported crashes across catalogs, settings, startup, and playback.

Kept only minimal low-risk changes:
- Disabled startup AVURLAsset `loadRealMediaTrackMetadata(from:)` probing that appeared in crash logs.
- Removed VOD Close chip from main control row.
- Source Intelligence cap raised to 50 ranked links.

Explicitly removed/not included:
- Source Intelligence provider picker row.
- New provider options state plumbing.
- Safe English auto-selection hooks.
- New scrubber focus-lock hooks.
- Status chip row additions.
- Mini-player/PiP/multi-view/VOD Links chip experiments.

Validation:
- `swiftc -parse Sources/*.swift` passed.
