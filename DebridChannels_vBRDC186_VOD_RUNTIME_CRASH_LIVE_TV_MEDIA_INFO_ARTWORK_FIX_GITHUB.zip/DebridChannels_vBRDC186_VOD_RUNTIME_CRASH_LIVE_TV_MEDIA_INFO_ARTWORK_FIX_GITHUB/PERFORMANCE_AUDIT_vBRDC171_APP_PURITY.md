# vBRDC171 app-wide purity / runtime audit

This audit was performed against packaged vBRDC170 only.

## Confirmed active-runtime issues corrected

1. Retained Live TV was still being composited behind dedicated Settings/Favorites/Membership/Sports surfaces.
   - State retention is still required for fast Live TV return and artwork continuity.
   - v171 keeps the tree alive but sets its visual opacity to zero while a dedicated surface owns the screen.
   - This removes unnecessary hidden 12-card GPU blending without discarding retained state.

2. Global tickers could remain eligible on Favorites/Membership.
   - v171 explicitly removes those surfaces from global ticker eligibility.

3. Favorites rebuilt the same persisted snapshot collection twice.
   - v171 decodes/merges the durable favorites snapshot store once per rebuild and reuses it for both signature and rendering.

4. Legacy full-Guide side-rail/static-preview implementations remained in the same LiveTVScreen source despite being unreachable.
   - v171 removes the dead implementations.
   - The active Guide has one inline category menu; the Live TV grid has its existing grid-only left tools panel.

5. Live TV focus had multiple visual owners.
   - Motion host stroke + focus-aware base border + focus-ring overlay could all be visible.
   - v171 leaves one focus-ring renderer and keeps v170's spring/3D motion owner.

6. Automatic source failover had a fixed 12-second watchdog despite v168's adaptive low-seeder buffering.
   - v171 makes startup grace source-aware and gives an advancing buffer an additional runway.
   - A transient network/read/HTTP startup error retries the selected link once before ranked fallback.

7. Sports-only M3U parsing reclassified an explicitly Sports-only source by channel-name keywords.
   - Generic PPV/event/provider names could disappear.
   - v171 trusts the user's Sports-only source classification and imports each valid EXTINF URL.

8. Alternate Audio had two readiness deadlocks.
   - Audio-only KSME could be prepared without a play assertion.
   - Initial readiness could depend forever on a seek callback from a remote/non-seekable container.
   - v171 primes the muted decoder, explicitly selects a track when KSME leaves all tracks disabled, and adds bounded alignment fallback.
   - Failed candidates are tried once each before original audio restoration.

## Runtime ownership scan after corrections

- `Timer.scheduledTimer`: 0
- `NotificationCenter.default.addObserver`: 5
- `addPeriodicTimeObserver`: 1
- `repeatForever`: 9
- `while !Task.isCancelled`: 14

The remaining recurring sites are intentional lifecycle-owned animation/task systems. No new polling timer was added in v171.

## Deliberately NOT removed

Historical regression locks, cached identity systems, resume/failover state, artwork persistence, and UNITY surface state are not "dead code" merely because they contain earlier release comments. Wholesale deletion would recreate previously fixed device regressions. v171 removes only proven unreachable UI and redundant active work.
