# vBRDC161 Regression Locks

- Preserve vBRDC160 local on-device Alternate Audio behavior exactly.
- Preserve vBRDC159 Favorites/Search/VOD logo hardening.
- Preserve Live TV implementation unchanged.
- Do not reintroduce backend Alternate Audio bridge into the active Use This Audio path.
- `UniversalVideoSurface` call sites must respect Swift memberwise initializer declaration order.
