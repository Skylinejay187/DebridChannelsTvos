from pathlib import Path
import hashlib, plistlib, re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
CAT = (ROOT / 'Sources/CatalogStore.swift').read_text()
IMG = (ROOT / 'Sources/RemoteImageFit.swift').read_text()
SEC = (ROOT / 'Sources/ReleaseCandidateSecurityManager.swift').read_text()

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

# Search -> detail -> source -> VOD logo ownership.
check('search artwork-only hydration accepted', 'if hydrated != currentDetail {' in APP)
check('search preserved detail keeps hydrated logo', 'logoURL: currentDetail.logoURL ?? hydrated.logoURL' in APP)
check('source playback starts from presentation-restored item', 'let presentationBase = store.presentationArtworkRestoredItem(from: item)' in APP)
check('source playback final movie item restored', 'return store.presentationArtworkRestoredItem(from: anchored)' in APP)
check('episode source playback artwork restored', 'return store.presentationArtworkRestoredItem(from: resolved)' in APP)
check('VOD overlay uses presentation artwork restore', 'store.presentationArtworkRestoredItem(from: playbackMetadataItem ?? item)' in APP)
check('poster themed logo force-publishes during playback', APP.count('forceVisiblePlaybackPublication: true') >= 2)

# Artwork identity + playback metadata retention.
for token in ['tmdb|\\(type)|', 'imdb|\\(imdb.lowercased())', 'tvdb|\\(type)|', 'media|\\(rawID)', 'title|\\(type)|']:
    check(f'artwork alias {token}', token in CAT)
check('artwork cache reads all aliases', 'for key in metadataArtworkCacheIDs(for: item)' in CAT)
check('artwork cache writes all aliases', 'let keys = metadataArtworkCacheIDs(for: item)' in CAT)
check('cached playback metadata requires logo before shortcut', 'if hasLogo || rememberedLogo {' in CAT)
check('playback metadata returns restored artwork', 'return restored' in CAT and 'let restored = presentationArtworkRestoredItem(from: enriched)' in CAT)
check('search tmdb imdb path enriches artwork', 'if let tmdb = await tmdbMetadataFallbackForDetail(rebuilt)' in CAT)

# Visible playback logo request lifetime.
check('foreground publication wait extended', 'maxWait: 1.80' in IMG)
check('foreground publication no longer blocked by sourceOpening', '&& !runtime.sourceOpeningActive' not in IMG[IMG.index('maxWait: 1.80')-1200:IMG.index('maxWait: 1.80')+1800])
check('hidden VOD preserves active <=640 foreground loads', 'protectedForegroundKeys' in IMG and 'key.maxPixelSize <= 640' in IMG)

# Favorites portable restore V2.
check('portable favorites backup key defined', 'favoriteMediaLibraryV2Base64' in APP)
check('portable record exists', 'private struct PortableFavoriteMediaRecord: Codable' in APP)
check('portable records retain clearlogo', 'logoURL = item.logoURL' in APP)
check('portable backup bounded to 900KB', 'data.count <= 900_000' in APP)
check('portable restore tried before v1 fallback', APP.index('restoreFavoriteMediaLibrary(from: encodedLibrary)') < APP.index('let encodedSnapshots = settings[favoriteMediaSnapshotsBackupKey]'))
check('v2 sanitizer allowlisted', '"favoriteMediaLibraryV2Base64"' in SEC)
check('v2 sanitizer bounded', 'decoded.count <= 900_000' in SEC)
check('auto backup prefers v2 and removes v1', 'settings.removeValue(forKey: favoriteMediaSnapshotsBackupKey)' in APP)
check('new profile avoids duplicate large v1 when v2 exists', 'favoriteLegacySnapshotBackup = favoritePortableLibraryBackup.isEmpty ? favoriteMediaSnapshotsBackupString() : ""' in APP)

# Legacy restore and identity migration.
check('legacy favorite schema explicitly recognized', 'let modernKinds = Set(["imdb", "tmdb", "tvdb", "id", "title"])' in CAT)
check('legacy generic id gets direct Cinemeta attempt', 'if identityKind == "id", let rebuilt = await cinemetaDirect(identityValue)' in CAT)
check('restore migrates recovered old keys', 'keys.remove(key)' in APP and 'keys.insert(modern)' in APP)
check('favorites screen migrates hydrated old keys', 'var migratedKeys = keys' in APP and 'favoriteMediaIdsRaw = migratedKeys.sorted().joined(separator: "|")' in APP)

# Favorites navigation hot path.
fav_start = APP.index('struct GlobalFavoritesScreen: View')
fav_end = APP.index('struct FavoriteLiveChannelCard: View', fav_start)
FAV = APP[fav_start:fav_end]
check('favorites backdrop never uses previewURL as image', 'selectedFavorite.previewURL' not in FAV)
check('favorites no longer observes complete store.rows', '.onChange(of: store.rows)' not in FAV)
check('favorites retains settled backdrop update', '180_000_000' in FAV)
check('favorites backdrop decode remains bounded', 'maxPixelSize: 1920' in FAV)
check('favorites rebuild signature excludes catalog row churn', 'hasher.combine(store.rows.count)' not in FAV)
check('favorites rebuild is persisted snapshot first', 'persisted Favorites are the primary render source' in FAV)
check('favorites scans catalog only when favorite snapshots missing', 'if !missingKeys.isEmpty {' in FAV)
check('favorites hydration avoids eager full catalog flatten', 'store.rows.flatMap' not in FAV)

# Live TV implementation must be byte-identical to v158 locked section.
live_start = APP.index('struct LiveTVChannel: Identifiable, Hashable {')
live_end = APP.index('struct SportsLiveEvent: Identifiable {', live_start)
live_hash = hashlib.sha256(APP[live_start:live_end].encode()).hexdigest()
check('Live TV v158 implementation byte lock', live_hash == '981107481bab08218492eb34520d0606c807885ab89d70c60d103f426c7fb2cc')

# Version contract.
with (ROOT/'Sources/Info.plist').open('rb') as f: info = plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top = plistlib.load(f)
check('app release id vBRDC159', info.get('DebridChannelsReleaseID') == 'vBRDC159')
check('app marketing 1.0.862', info.get('CFBundleShortVersionString') == '1.0.862')
check('app build 862', info.get('CFBundleVersion') == '862')
check('topshelf release id vBRDC159', top.get('DebridChannelsReleaseID') == 'vBRDC159')
check('topshelf build 862', top.get('CFBundleVersion') == '862')
project = (ROOT/'project.yml').read_text()
check('project marketing version updated twice', project.count('MARKETING_VERSION: 1.0.862') == 2)
check('project build updated twice', project.count('CURRENT_PROJECT_VERSION: 862') == 2)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} passed')
if failed:
    raise SystemExit(1)
