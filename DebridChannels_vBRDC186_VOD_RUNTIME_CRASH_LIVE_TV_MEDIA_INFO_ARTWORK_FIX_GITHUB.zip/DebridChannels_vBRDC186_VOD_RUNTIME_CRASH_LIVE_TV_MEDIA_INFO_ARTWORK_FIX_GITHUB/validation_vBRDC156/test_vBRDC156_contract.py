from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
sec = (root/'Sources/ReleaseCandidateSecurityManager.swift').read_text()
stable = (root/'Sources/StableFeatureGateManager.swift').read_text()
checks = []
def check(name, ok):
    checks.append((name, bool(ok)))
    print(('PASS' if ok else 'FAIL') + ': ' + name)

check('layout enum has Current and Spread Out', 'static let names = ["Current", "Spread Out"]' in app)
check('settings and Live TV both bind layout preference', app.count('@AppStorage("liveTVGridLayoutStyleV1") private var liveTVGridLayoutStyle: String = "Current"') == 2)
check('settings exposes layout chooser', 'Live TV Grid Layout:' in app and 'focus: .liveGridLayoutStyle' in app)
check('current card height preserved', '(spreadOutGrid ? 238 : 226)' in app)
check('current row spacing preserved', '(spreadOutGrid ? 28 : 22)' in app)
check('column spacing remains unchanged', 'let columnSpacing: CGFloat = gridLockedMode ? 18 : 30' in app)
check('grid remains fixed 4x3 path', 'count: liveTVGridColumnCount' in app and 'liveTVGridPageChannels' in app)
check('backup export includes layout preference', '"liveTVGridLayoutStyleV1": LiveTVGridLayoutStyle.normalized(liveTVGridLayoutStyle)' in app)
check('backup restore includes layout preference', 'liveTVGridLayoutStyle = LiveTVGridLayoutStyle.normalized(settings["liveTVGridLayoutStyleV1"] as? String ?? liveTVGridLayoutStyle)' in app)
check('stable reset defaults to Current', 'liveTVGridLayoutStyle = "Current"' in app)
check('security allowlist includes layout preference', 'liveTVGridLayoutStyleV1' in sec)
check('stable UI reset knows Current layout', 'StableUIDefault(key: "liveTVGridLayoutStyleV1", value: "Current")' in stable)
check('channel-number setting remains present', 'Live TV Channel Numbers:' in app and 'liveTVChannelNumberPositionV1' in app)
check('v155 transport recovery identifiers remain present', 'URLSession' in app and 'PlainHTTPClient' in app)
failed=[n for n,ok in checks if not ok]
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} passed')
if failed:
    raise SystemExit(1)
