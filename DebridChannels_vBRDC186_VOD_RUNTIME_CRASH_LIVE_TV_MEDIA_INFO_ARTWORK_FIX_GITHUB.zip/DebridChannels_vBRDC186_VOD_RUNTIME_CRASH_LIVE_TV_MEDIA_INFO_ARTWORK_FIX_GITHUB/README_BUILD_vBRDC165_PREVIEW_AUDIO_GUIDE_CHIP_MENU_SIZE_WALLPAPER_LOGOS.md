# Debrid Channels vBRDC165 — Preview Audio + Guide Channel Chip + Menu Size + App-Wide Wallpaper + Logo Expansion

Release: **vBRDC165**  
Marketing version: **1.0.868**  
Build: **868**

Built directly from the packaged vBRDC164 source. No mockups or generated-image assets were added.

## Changes

- Restored audio to both Live TV preview surfaces:
  - focused 4x3 grid preview;
  - full Guide live-preview window.
- Live preview KSPlayer surfaces now explicitly identify themselves as Live TV (`isLiveStream: true`) and remain unmuted. The AVPlayer fallback is also unmuted.
- Replaced the vBRDC164 full-Guide use of the large left Guide Tools rail with a compact **Channels** chip and drop-down inside the Guide.
- Pressing **LEFT once** in the full Guide opens the Channels drop-down. It exposes My Favorites, All Channels, HD, Favorites, Sports, Drama, News, Kids, and provider-created categories using the existing indexed Live TV category data.
- The larger left-edge Tools rail remains available from the Live TV grid; it is no longer used as the Guide category selector.
- Added **Top Menu Size** with five global presets: Extra Small, Small, Medium, Large, Extra Large. Medium is the exact prior vBRDC164 scale.
- Top Menu Size is included in settings backup/restore and Stable UI Defaults.
- Expanded Animated Live TV Header Logo styles from 8 to 16 with Prism Broadcast, Aurora Live, Chrome Pulse, Spectrum TV, Quantum Signal, Ember Air, Holo Channel, and Electric Live.
- New animated logo styles receive the currently focused Live TV channel accent and animate color as well as motion. The existing Off toggle still removes the header logo view completely.
- Dynamic Wallpaper is now an app-wide non-playback ambient surface. It no longer pauses for D-pad navigation, scrolling, catalog transitions, Guide, quick panels, Search, Settings, Favorites, Sports, Home, Movies, or Shows.
- Full-screen playback remains the one hard Dynamic Wallpaper suspension boundary so the wallpaper never competes with movie/show/Live TV full-screen playback resources.
- Updated Settings and onboarding copy for the new Guide Channels workflow, audible previews, and app-wide Dynamic Wallpaper behavior.

## Preserved behavior

- 4x3 Live TV page geometry and page-edge navigation remain unchanged.
- Live TV card cleanup from vBRDC164 remains.
- vBRDC163 Favorites equal-width/backdrop corrections remain.
- vBRDC162 VOD first-open hydration and universal local Alternate Audio path remain unchanged.
- Provider/EPG/Gracenote/MediaFlow loading logic is not changed by this pass.
