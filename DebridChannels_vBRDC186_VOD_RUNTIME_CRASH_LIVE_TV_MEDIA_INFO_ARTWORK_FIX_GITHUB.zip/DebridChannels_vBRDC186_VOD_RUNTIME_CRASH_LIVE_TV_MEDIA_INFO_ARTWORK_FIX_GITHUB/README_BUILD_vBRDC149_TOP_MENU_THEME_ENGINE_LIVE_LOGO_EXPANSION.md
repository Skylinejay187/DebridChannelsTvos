# Debrid Channels vBRDC149 — Top Menu Theme Engine Recovery + Live TV Logo Expansion

Release: vBRDC149  
Marketing version: 1.0.852  
Apple build: 852

## Base
Built directly from packaged vBRDC148. No older source was imported into production code.

## Top-menu theme repair
- Keeps all 32 current top-menu themes and the complete `TopMenuTabVisual` renderer.
- Theme resolution is now exact-name first; legacy fuzzy matching runs only as migration fallback.
- The themed menu subtree receives a theme/font/accent identity key so a new selection is rebuilt immediately instead of allowing tvOS/SwiftUI to retain stale focused geometry.
- Settings theme selection closes the picker and restores Settings focus after two main-actor yields, after the live top bar has rebuilt.
- The menu composition is reduced from 0.82 to 0.72 visual scale; no theme renderer is replaced.

## Top-menu DOWN routing
- The menu records the surface that actually entered it.
- Outside Settings, DOWN from Home/Movies/TV Shows/Sports/Favorites labels returns to the persistent Live TV grid even if focus is roaming over those labels.
- Settings keeps its separate contract: DOWN enters the highlighted destination, or returns to the current Settings category when Settings is highlighted.
- The focused tab now receives DOWN directly, with an 80ms duplicate-delivery guard for parent/child command propagation.

## Live TV animated header themes
Existing Signal TV and Retro Tube remain. Added six lightweight compositor-only choices:
- Pulse Beacon
- Orbit Broadcast
- Neon Frequency
- Cinema Signal
- Glass Airwave
- Signal Matrix

All eight use the existing Live TV Header Logo Style setting and the existing On/Off toggle. No timers or provider/grid navigation changes were added.

## Explicitly unchanged
- 4x3 Live TV paging/grid logic and channel ordering
- Guide DOWN-twice open behavior, exit rail, Back/Menu and double-LEFT exit
- Gracenote/XMLTV/channel-logo loading and post-VOD recovery
- focused-card preview pipeline
- Movies/Shows/Sports/Favorites data and scrolling implementations
- playback, resume, Bluetooth, MediaFlow, TorBox/Usenet, provider logic

## Validation
- vBRDC149 cumulative contract: 328/328 passed
- Production Swift parse: 65/65 files, 0 failures
- Backend regression: 36 tests + 2 subtests passed
- Both Info.plists + project.yml parsed successfully
