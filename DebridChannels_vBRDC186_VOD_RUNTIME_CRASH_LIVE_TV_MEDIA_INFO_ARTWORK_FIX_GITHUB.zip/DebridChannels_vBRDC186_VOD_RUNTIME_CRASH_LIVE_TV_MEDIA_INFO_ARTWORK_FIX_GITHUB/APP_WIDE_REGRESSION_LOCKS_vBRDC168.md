# APP-WIDE REGRESSION LOCKS — vBRDC168

- Build only from packaged vBRDC167.
- No mockups or generated UI assets.
- Live TV grid/Guide presentation and focus behavior unchanged.
- Dynamic Wallpaper behavior unchanged.
- Favorites presentation/restore behavior unchanged.
- VOD overlay artwork/cast/Production & Ratings hydration unchanged.
- Universal Alternate Audio behavior unchanged.
- Bluetooth VOD media controls unchanged.
- Main VOD playback engine order unchanged: KSMEPlayer primary, KSAVPlayer fallback.
- Live TV and trailer buffer profiles unchanged.
- Main VOD cache is no longer resolution-only/fixed-time: it is bitrate + physical-memory + source-reliability aware.
- Low-seeder compensation applies only to uncached transport routes; cached debrid files do not spend extra RAM based on original swarm count.
- tvOS memory warning can only reduce the active VOD max-buffer ceiling; it never increases memory pressure.
