# vBRDC155 — Compile Correction for Live TV Bootstrap + Favorites Focus

Base: vBRDC154_FAVORITES_TOP_MENU_DOWN_FOCUS_RECOVERY

Version:
- Marketing: 1.0.858
- Apple build: 858
- Release ID: vBRDC155

## Scope
Compile-only correction for the vBRDC153 transport code inherited by vBRDC154.

GitHub Actions log `logs_91255938953.zip` identified three Swift compiler errors in
`Sources/DebridChannelsTVOSApp.swift` inside the Channels DVR loader:
- assignment of optional `[LiveTVChannel]?` to concrete `[LiveTVChannel]`
- calling `.isEmpty` on optional `[LiveTVChannel]?`
- appending optional `[LiveTVChannel]?` to concrete array

`parseDVRChannelsJSON` intentionally returns an optional array. Both call sites now
coalesce `nil` to `[]` with `?? []`.

No provider ordering, MediaFlow routing, timeout, Favorites navigation, Live TV UI,
channel-number setting, top-menu theme, Guide, artwork, or playback behavior was changed.

## Validation
- All production Swift files parse with `swiftc -parse`.
- Exact compiler-failing call sites now produce concrete arrays.
- vBRDC154 Favorites top-menu DOWN focus recovery remains present.
- vBRDC153 Live TV transport recovery remains present.
- vBRDC151 channel-number position setting remains present.
- Version metadata is synchronized at 1.0.858 / 858 / vBRDC155.
