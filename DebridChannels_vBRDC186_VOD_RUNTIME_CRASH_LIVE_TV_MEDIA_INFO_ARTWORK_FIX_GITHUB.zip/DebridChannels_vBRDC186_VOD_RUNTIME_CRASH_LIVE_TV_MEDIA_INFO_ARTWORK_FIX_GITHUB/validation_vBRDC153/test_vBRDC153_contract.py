from pathlib import Path
import plistlib, re
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
r=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
p=(ROOT/'Sources/PlainHTTPClient.swift').read_text()
checks={}
def ck(name, cond):
    checks[name]=bool(cond)
    assert cond, name
# Transport repair
ck('fetchText_attempts_parameter', 'attempts: Int = 2' in s)
fetch=s[s.index('private func fetchText(_ urlString:'):s.index('// vBRDC119: EXTINF attributes', s.index('private func fetchText(_ urlString:'))]
ck('urlsession_primary_present', 'Self.providerSession.data(for: networkRequest)' in fetch)
ck('urlsession_before_plain_fallback', fetch.index('Self.providerSession.data(for: networkRequest)') < fetch.index('PlainHTTPClient.fetchData'))
ck('raw_http_fallback_only', 'networkURL.scheme?.lowercased() == "http"' in fetch)
ck('identity_encoding_original', 'request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")' in fetch)
ck('identity_encoding_plain', 'Accept-Encoding: identity' in p)
ck('mediaflow_route_still_used', 'MediaFlowProxyRouter.liveTVBootstrapRequestsIfAllowed' in fetch)
ck('mediaflow_stream_bootstrap_preserved', 'epg ? ["/proxy/epg", "/proxy/stream"] : ["/proxy/stream"]' in r)
ck('mediaflow_fail_closed_preserved', 'configurationError(kind: .liveTV' in r)
# Lineup first / bounded probes
refresh=s[s.index('func refreshFromConfiguredSources'):s.index('private struct XtreamAccount', s.index('func refreshFromConfiguredSources'))]
ck('hdhr_before_dvr', refresh.index('loadHDHomeRun') < refresh.index('loadChannelsDVR'))
ck('m3u_before_external_xmltv', refresh.index('for (index, m3uURL)') < refresh.index('for (index, xmltvURL)'))
ck('xtream_lineup_before_external_xmltv', refresh.index('for (index, account) in xtreamAccounts.enumerated()') < refresh.index('for (index, xmltvURL)'))
ck('empty_provider_fast_exit', 'if dedupe(loaded).isEmpty' in refresh and 'isLoading = false' in refresh)
ck('external_xmltv_bounded', 'timeout: 35' in refresh and 'attempts: 1' in refresh)
ck('xtream_xmltv_bounded', 'timeout: 45' in refresh and 'attempts: 1' in refresh)
ck('lineup_first_publisher_preserved', refresh.count('publishLineupFirstIfNeeded') >= 4)
load_dvr=s[s.index('private func loadChannelsDVR'):s.index('private func loadHDHomeRun')]
ck('dvr_primary_m3u_bounded', 'timeout: 10' in load_dvr and 'attempts: 1' in load_dvr)
ck('dvr_any_json_second', load_dvr.index('devices/ANY/channels.m3u') < load_dvr.index('devices/ANY/channels"'))
ck('dvr_named_device_bounded', 'devices.prefix(2)' in load_dvr)
load_hd=s[s.index('private func loadHDHomeRun'):s.index('private struct HDHomeRunDeviceCandidate')]
ck('hdhr_bounded', 'timeout: 10' in load_hd and 'attempts: 1' in load_hd)
load_xt=s[s.index('private func loadXtream(server:'):s.index('private nonisolated func parseXtreamPayloadOffMain')]
ck('xtream_categories_bounded', 'timeout: 12, attempts: 1' in load_xt)
ck('xtream_live_bounded', 'timeout: 28, attempts: 1' in load_xt)
# User-facing accepted features preserved
ck('channel_number_setting_preserved', 'liveTVChannelNumberPosition' in s and 'Top Right' in s and 'Bottom Right' in s)
ck('channel_number_off_preserved', re.search(r'case\s+"off"', s, re.I) is not None or 'Off' in s)
ck('subtle_bottom_page_indicator_preserved', 'liveTVGridPageIndex' in s)
ck('guide_double_down_logic_preserved', 'guideEntryArmed' in s or 'guideDown' in s or 'Press ↓ Again' in s or 'PRESS ↓ AGAIN' in s)
ck('top_menu_theme_engine_preserved', 'TopMenuTabVisual' in s)
# Versions
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with (ROOT/rel).open('rb') as f: d=plistlib.load(f)
    ck(rel+'_marketing', d.get('CFBundleShortVersionString')=='1.0.856')
    ck(rel+'_build', d.get('CFBundleVersion')=='856')
    ck(rel+'_release', d.get('DebridChannelsReleaseID')=='vBRDC153')
y=(ROOT/'project.yml').read_text()
ck('project_marketing', y.count('MARKETING_VERSION: 1.0.856')>=2)
ck('project_build', y.count('CURRENT_PROJECT_VERSION: 856')>=2)
print(f'{sum(checks.values())}/{len(checks)} PASS')
for k in checks: print('PASS',k)
