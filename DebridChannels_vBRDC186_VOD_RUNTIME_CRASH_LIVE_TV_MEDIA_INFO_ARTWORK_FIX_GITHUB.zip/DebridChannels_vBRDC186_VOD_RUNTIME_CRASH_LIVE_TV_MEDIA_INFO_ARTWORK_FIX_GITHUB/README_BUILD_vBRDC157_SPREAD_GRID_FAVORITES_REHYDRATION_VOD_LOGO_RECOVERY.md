# Debrid Channels vBRDC157 — Spread Grid + Favorites Rehydration + VOD Logo Recovery

Release: **vBRDC157**  
Marketing version: **1.0.860**  
Build: **860**  
Base: **vBRDC156 / 1.0.859 / 859**

## Scope

This build is intentionally limited to three user-reported issues. Live TV provider/bootstrap, HDHomeRun, Channels DVR, MediaFlow, M3U/Xtream, XMLTV/Gracenote, playback source resolution, Sports, top-menu themes, Guide navigation, page navigation, channel-number placement, and animated Live TV header-logo logic are not changed.

## 1. Spread Out Live TV grid is visibly more spread

`Current` remains the existing vBRDC156 compact 4 x 3 layout.

`Spread Out` now uses a meaningfully larger vertical envelope while preserving exactly 4 columns, 3 rows and 12 cards per page:

- card height: **252** vs Current **226**
- row spacing: **30** vs Current **22**
- deck spacing: **16** vs Current **13**
- top deck inset: **104** vs Current **132**
- bottom/frame reserve reduced so row 3 and the Guide/page area can sit farther down the display

No paging/focus/provider/artwork logic is conditional on this setting.

## 2. Search-only Favorites survive restore/reinstall identity recovery

Root cause: `favoriteMediaIds` was backed up, but the existing `favoriteMediaSnapshotsV1` MediaItem snapshot map was stored as `Data` and was not part of the supported profile settings payload. A restored favorite could therefore still be recognized as a favorite by identity while Global Favorites had no movie/show object to display until Search recreated it and the user toggled favorite state.

Fixes:

- compact favorite snapshots are now exported as a size-bounded Base64 profile field
- restore validates and writes the snapshot map back to the original `favoriteMediaSnapshotsV1` storage key
- backup security allowlist validates the new payload independently
- already-favorited Media Information pages automatically refresh their snapshot as richer metadata/artwork arrives
- pre-hydration favorite aliases are updated too, so gaining a stronger IMDb/TMDB/TVDB identity cannot strand an older no-logo snapshot
- old ID-only backups are self-repairing: Favorites can reconstruct a bounded set of missing favorite objects from Cinemeta/TMDB without requiring search -> unfavorite -> favorite

`favoriteMediaIds` remains the authoritative favorite identity store.

## 3. Search/Favorites VOD clearlogo persistence

Root cause: the playback launch helper that was intended to carry hydrated detail state into VOD only restored cast/director data and could return early once cast existed. Search/Favorites items can begin as compact snapshots and receive the clearlogo later in Media Information, so VOD could mount a stale item with no logo. A cast-complete metadata cache could also return before the newer hydrated detail was merged.

Fixes:

- VOD launch now fills missing poster/backdrop/logo from the existing artwork cache
- matching hydrated `selectedDetail` can fill missing external IDs, poster, backdrop, logo, preview, cast and directors
- the cast-only early gate is removed
- playback metadata merges current hydrated detail/playback item before the completed-credit cache shortcut
- artwork resolved inside VOD is written to the existing persistent artwork cache
- when the title is already a favorite, VOD-hydrated metadata also upgrades its compact favorite snapshot

This changes presentation metadata only; it does not alter source/link selection or playback engines.

## Regression locks

- 4 columns x 3 rows / 12 cards per Live TV page remain unchanged
- Live TV provider/bootstrap block is byte-identical to vBRDC156
- Current grid geometry remains unchanged
- vBRDC151 Top Right / Bottom Right / Off channel-number setting remains
- vBRDC154 Favorites top-menu DOWN focus recovery remains
- vBRDC149 top-menu theme engine remains
