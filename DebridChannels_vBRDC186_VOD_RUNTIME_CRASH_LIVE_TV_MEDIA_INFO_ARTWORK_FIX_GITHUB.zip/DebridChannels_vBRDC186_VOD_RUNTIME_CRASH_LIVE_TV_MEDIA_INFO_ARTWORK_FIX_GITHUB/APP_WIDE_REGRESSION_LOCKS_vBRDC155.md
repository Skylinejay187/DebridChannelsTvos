# APP-WIDE REGRESSION LOCKS — vBRDC155

vBRDC155 is a compile-only correction built from vBRDC154.

Locked:
- Favorites UP-to-top-menu then DOWN returns to Favorites cards.
- Live TV bootstrap transport behavior from vBRDC153 remains unchanged.
- Live TV channel-number position setting remains Top Right / Bottom Right / Off.
- Live TV paging, Guide, Gracenote artwork, animated header logos, and top-menu theme engine remain unchanged.
- No UI geometry or navigation behavior is intentionally changed in vBRDC155.

Compiler lock:
- `parseDVRChannelsJSON(...)` may return nil.
- Channels DVR loader must coalesce those optional results to an empty concrete array before assignment, `.isEmpty`, or `append(contentsOf:)`.
