# Debrid Channels vBRDC167 — Guide Inline Category Menu

Release: **vBRDC167**  
Marketing version: **1.0.870**  
Build: **870**

Built directly from packaged vBRDC166. No mockups, generated UI images, or replacement visual assets were added.

## Guide correction

- Removed the vBRDC166 manual LEFT-to-category focus handoff from the full Live TV Guide.
- The Live TV grid's existing left-side Tools panel is unchanged and remains grid-only.
- Moved the Guide category control into the Guide timeline header, directly above the channel column, matching standard DVR guide placement.
- The control shows only the current category and a chevron, e.g. `Favorites ▼` or `All Channels ▼`.
- Selecting the control opens a compact 330pt drop-down directly underneath it; it never opens a full-screen category page or separate side rail.
- The drop-down uses the same Live TV categories/provider groups already exposed by the app.
- Selecting a category immediately reprojects Guide rows. The current channel is retained when it exists in the new group; otherwise the content anchor changes to the first channel without a forced focus handoff.
- Guide preview playback is not paused or muted just because the category menu is opened.
- Back/Menu closes the small drop-down first; Back/Menu from the Guide still exits the Guide.

## Preserved

All vBRDC166 behavior outside this Guide interaction is preserved, including Live TV preview audio, 4x3 grid paging, grid Tools rail, Top Menu Size presets, animated Live TV logos, app-wide Dynamic Wallpaper behavior, Favorites corrections, VOD hydration hardening, and universal Alternate Audio.
