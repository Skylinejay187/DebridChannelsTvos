# vBRDC150 App-Wide Regression Lock

vBRDC150 is a presentation-only Live TV page-position change built from packaged vBRDC149.

Locked unchanged:
- top-menu theme engine, current theme inventory, compact sizing, focus and DOWN routing
- Live TV 4x3 paging mechanics and double-edge confirmation
- all animated Live TV header logos and settings
- Guide opening/closing/hints
- Live TV preview ownership
- Gracenote/XMLTV/channel artwork loading, cache and post-VOD recovery
- playback/resume/Bluetooth/MediaFlow/providers/TorBox/Usenet
- Movies, TV Shows, Sports, Favorites and Settings behavior

Only the Live TV page-position badge presentation moved from the top-right header to the bottom-right grid footer and was visually subdued.
