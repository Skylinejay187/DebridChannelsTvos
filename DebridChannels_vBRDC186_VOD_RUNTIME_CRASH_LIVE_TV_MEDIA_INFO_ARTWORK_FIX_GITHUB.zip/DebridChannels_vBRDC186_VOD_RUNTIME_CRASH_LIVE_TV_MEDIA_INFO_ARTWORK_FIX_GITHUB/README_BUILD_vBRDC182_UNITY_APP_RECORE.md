# Debrid Channels vBRDC182 — UNITY App Re-Core

Version: 1.0.885 (build 885)
Donor / rollback point: packaged vBRDC180 only.

## Purpose
vBRDC182 begins the architectural UNITY re-core requested after vBRDC180. The goal is one persistent application shell with independently modifiable surfaces, instead of treating Home, Catalogs, Live TV, Guide, Favorites, Sports and Settings as unrelated trees joined by ad-hoc focus signals.

This is a staged migration, not a destructive rewrite. vBRDC180 remains the immutable rollback point. Playback/data systems that are already hardened remain in place while navigation, theme, focus and lifecycle ownership move into shared UNITY infrastructure.

## UNITY Core
- Added `UnityAppCore` as a process-wide navigation/theme/runtime owner.
- `UnityAppCore.activeTab` is the new shell navigation truth.
- `CatalogStore.selectedTab` remains a temporary compatibility mirror for older feature code and folds legacy writes back into UNITY.
- Added one effective surface owner for Search, Detail and Playback overlays.
- Added shared surface policies so state residency, pixel residency and background work are separate decisions.
- Unified the surface taxonomy used by `UnitySurfaceLifecycleCoordinator` with the new core.

## Persistent Top Navigation
- The global top menu is now one persistent SwiftUI host mounted once at the root.
- Normal surface changes alter visibility/interactivity instead of destroying/recreating the menu tree.
- Top-menu selections route through `UnityAppCore`.
- Top-menu focus requests use a dedicated UNITY revision rather than publishing navigation-only changes through the entire `CatalogStore`.
- Live TV top-menu traversal no longer requires its old custom NotificationCenter signal; Live TV observes the persistent navigation session directly.

## Performance / Runtime Cleanup
- `CatalogStore.menuFocusToken` is no longer `@Published`; legacy callers bridge into the persistent UNITY shell without invalidating every CatalogStore observer.
- Root, catalog overlay and Live TV now observe `UnityAppCore.activeTab` for major shell changes.
- Trailer-exclusive and app-level memory-pressure notifications are centralized in `UnityAppCore`; root/catalog consumers observe core state instead of creating duplicate process-wide subscriptions.
- Live TV, Favorites, Sports and Settings use shared runtime ownership at key lifecycle/focus gates while old behavior remains compatible.
- Dedicated surfaces can keep state while their pixels/expensive work are dormant underneath another owner.

## Unified Theme Foundation, Independent Presentation
UNITY does not force one layout/theme onto every screen. It exposes shared palette tokens while each surface owns its own geometry and presentation.

- `UNITY App Background` is the common base palette.
- `App / Top Menu Accent` is the common accent token.
- Shared background/chrome now feeds Root, Search, Favorites and Settings presentation.
- Pure Black stays genuinely black; no forced blue accent wash is added to Pure Black.
- Guide no longer consumes Live TV Grid theme definitions. It is a separate presentation layer consuming the global UNITY palette.
- Live TV Grid keeps its own card/layout appearance.
- Guide keeps its own timeline/header/program-cell presentation.

## Preserved vBRDC180 Locks
- v161 exact Live TV card appearance remains the visual donor carried by v180.
- v179/v180 All Channels / selected station / Up Next additions remain.
- 4x3 Live TV paging and bottom-right PAGE indicator remain.
- Guide preview and separate Exit/Back hint remain.
- Catalog content/layout behavior is not redesigned in this pass.
- Alternate Audio implementation is untouched.
- Adaptive bitrate + Apple TV memory-aware VOD cache is untouched.
- KSPNUVIO fork is untouched.

## Rollback
If on-device behavior does not meet expectations, restore packaged vBRDC180. v182 does not modify or overwrite the v180 donor ZIP.
