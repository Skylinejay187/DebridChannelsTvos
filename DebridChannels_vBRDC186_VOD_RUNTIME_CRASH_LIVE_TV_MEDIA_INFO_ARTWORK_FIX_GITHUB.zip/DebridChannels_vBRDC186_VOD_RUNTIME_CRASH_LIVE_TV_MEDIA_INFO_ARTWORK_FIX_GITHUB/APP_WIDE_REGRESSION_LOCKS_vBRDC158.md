# APP-WIDE REGRESSION LOCKS — vBRDC158

- Build base is packaged vBRDC157 only.
- Live TV provider/grid implementation is byte-for-byte unchanged from vBRDC157.
- Do not alter HDHomeRun, MediaFlow, Channels DVR, M3U, Xtream, XMLTV or Gracenote loading for this release.
- Preserve vBRDC151 Live TV channel-number Top Right / Bottom Right / Off setting.
- Preserve vBRDC156 Current / Spread Out Live TV grid setting and vBRDC157 spread geometry.
- Preserve vBRDC154 Favorites top-menu DOWN focus recovery.
- Search result focus styling remains Search-style; performance changes may not alter card geometry/navigation.
- Favorites restore is authoritative from favoriteMediaIds plus compact favoriteMediaSnapshotsV1.
- Once a protected backend profile backup code exists, Favorites library mutations auto-sync that existing code after debounce.
- VOD overlay must never replace a known poster/backdrop/clearlogo with an empty later metadata value.
- No playback engine/provider/source-intelligence behavior changed in vBRDC158.
