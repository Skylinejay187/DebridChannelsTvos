# vBRDC123 Regression Lock Addendum

Future builds must preserve all prior locks plus these behavioral contracts.

## Featured Cast

- Automatic Featured Cast rotation remains seven seconds while the VOD cast surface is awake and has more than one image-backed member.
- Compact and Full Poster cast portraits keep `preservePreviousOnURLChange: true`, `publishDuringPlayback: true`, and `forceVisiblePlaybackPublication: true`.
- The visible name/role/select identity remains committed only when the requested portrait bitmap actually publishes.
- Rotation task identity must follow current image-backed member IDs/URLs, not only array count.
- Manual LEFT/RIGHT browsing continues to reset only the existing seven-second auto-rotation clock.

## VOD Episode artwork

- Full Episode Browser episode stills remain display-bounded and explicitly allowed to publish during the mounted/paused VOD session.
- Full Episode Browser must use `forceVisiblePlaybackPublication: true`; switching seasons must never be required to make already-available artwork appear.
- Episode artwork selection must ignore empty strings and fall through landscape, preview, then poster artwork.
- Hero/detail episode cards and Up Next artwork keep the same bounded foreground-VOD publication behavior where they render over an active playback session.

## Shared publication policy

- `forceVisiblePlaybackPublication` stays an explicit opt-in with a short bounded navigation courtesy wait; it must not become the default for normal catalog/background/decorative artwork.
- vBRDC122 protection preventing hidden base VOD chrome from cancelling visible Cast Explorer / Episode Browser / VOD switch artwork remains intact.
- vBRDC119 durable event-driven frame gates remain the default everywhere that is not explicit foreground playback UI.
