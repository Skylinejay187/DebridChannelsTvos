# vBRDC162 Regression Locks

- Preserve packaged vBRDC161 as the only donor/base for this release.
- VOD themed logos, cast artwork, and Production & Ratings must hydrate on the first playback presentation without requiring overlay close/reopen.
- A stale/cancelled VOD hydration task must never clear or block the current generation owner.
- Find English Audio must not reject a resolved copy because of legacy `Incompatible` identity/timing classification.
- The current playback copy must remain eligible as a local audio-only source when no second direct link exists.
- Alternate Audio must keep the primary video URL mounted and must not restore the backend bridge as the active Use This Audio path.
- Turning Animated Live TV Header Logo Off means no Live TV header logo/text replacement is drawn.
- Live TV guide hint auto-hide remains 10 seconds.
- Preserve the existing 4x3 Live TV page/focus/navigation model.
- Do not reintroduce the retired Live TV left-side card rail or generic LIVE badge.
- Premium Live TV decorations must remain static/non-owning: no new focus owners, recurring timers, blur, network work, or video surfaces.
- Do not modify Vendor/KSPNUVIO source for this release.
