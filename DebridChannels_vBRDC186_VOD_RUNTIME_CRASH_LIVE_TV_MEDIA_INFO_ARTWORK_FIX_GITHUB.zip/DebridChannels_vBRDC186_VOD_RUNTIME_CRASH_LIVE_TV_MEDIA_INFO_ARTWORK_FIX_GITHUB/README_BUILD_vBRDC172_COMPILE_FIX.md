# Debrid Channels vBRDC172 — Compile Fix

Base: packaged vBRDC171 only.

This is a compile-only correction for the vBRDC171 Alternate Audio hardening. Xcode 16.4 rejected a direct call from an existentially typed `[MediaPlayerTrack]` element into KSMEPlayer's opaque `select(track: some MediaPlayerTrack)` overload. The selected track is now dispatched through `any MediaPlayerProtocol`, matching KSPlayer's own protocol-facing selection path while preserving the same runtime select/flush behavior.

No Live TV, Favorites, Sports, VOD cache, Guide, navigation, wallpaper, or playback behavior was intentionally changed.
