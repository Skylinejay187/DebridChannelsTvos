# App-Wide Regression Locks — vBRDC153

vBRDC153 preserves all accepted vBRDC152 behavior and adds these Live TV bootstrap contracts:

1. A MediaFlow-routed Live TV bootstrap request must use URLSession as the primary transport even when the configured MediaFlow base is `http://`.
2. `PlainHTTPClient` is a plain-HTTP compatibility fallback only; it may not own normal MediaFlow bootstrap traffic.
3. MediaFlow ON remains fail-closed and uses `/proxy/stream` for normal Live TV bootstrap GETs.
4. XMLTV/Gracenote remains `/proxy/epg` first with `/proxy/stream` fallback.
5. MediaFlow OFF preserves direct provider requests.
6. Explicit HDHomeRun lineup probing stays ahead of a possibly stale Channels DVR source.
7. Channels DVR lineup probing must be bounded and stop on the first authoritative non-empty result.
8. M3U and Xtream channel lineups must be attempted before optional standalone XMLTV enrichment can block them.
9. A non-empty provider lineup must continue using vBRDC152's immediate lineup-first publication corridor.
10. If all configured providers return zero channels, the Live TV loading state must terminate without waiting for guide publication.
11. vBRDC151 channel-number Top Right / Bottom Right / Off behavior remains present.
12. vBRDC150 page-position treatment remains present.
13. vBRDC149 top-menu theme identity/rebuild system and animated Live TV header-logo themes remain present.
14. vBRDC143–146 4×3 paging, edge confirmation, Guide double-DOWN entry, Back/Menu + double-LEFT Guide exit, and bottom-row preview behavior remain unchanged.
15. vBRDC142 post-VOD Gracenote/channel-artwork recovery remains unchanged.
16. No VOD/playback, Sports, Favorites, Search, catalog, debrid/Usenet, or Source Intelligence runtime is intentionally modified by vBRDC153.
