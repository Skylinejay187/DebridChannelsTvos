# vBRDC183 Regression Locks

Compile-only successor to vBRDC182.

- Preserve vBRDC182 UNITY app re-core behavior.
- Preserve vBRDC180 as the rollback baseline.
- Do not change catalog visuals or behavior.
- Preserve Live TV/Guide presentation inherited by vBRDC182.
- Preserve VOD adaptive cache, Alternate Audio, resume, Sports, Favorites, Bluetooth, and playback behavior.
- Only functional source delta: `UnityAppCore.select(_:store:reason:)` is isolated to `@MainActor` so it can safely bridge `CatalogStore.selectedTab`.
