# Debrid Channels vBRDC170 — Guide Redesign / Grid Motion / Wallpaper Geometry

Release: **vBRDC170**  
Marketing version: **1.0.873**  
Apple build: **873**  
Donor/source of truth: packaged **vBRDC169** only.

## Changes

### Full Guide geometry + category drop-down
- Rebuilt Guide geometry from the actual padded Guide viewport instead of full-screen assumptions.
- Added explicit overscan-safe left/right margins shared by the category selector and channel column.
- The Guide category list is a compact 304pt inline drop-down owned by the Guide root, capped at 286pt tall and scrollable when needed.
- Removed the chip-owned overlay path that could be clipped/occluded at the leading screen edge.
- The Live TV grid's existing left-side controls remain completely separate and grid-only.

### Fresh Guide presentation
- Rebuilt the top Guide area as a two-surface broadcast header: a dedicated live monitor plus a separate channel/program information panel.
- Guide live preview now uses a true 16:9 monitor and keeps KSPlayer `scaleAspectFit`, preserving the complete broadcast frame.
- Channel identity, program title, time/category/source, description and program artwork are reorganized without altering provider/EPG logic.
- Dynamic Live TV Wallpaper is intentionally not rendered in the full Guide.

### Dynamic Live TV Wallpaper
- Wallpaper ownership is now Live TV **grid-only**.
- The renderer is mounted as an explicit screen-sized plane using the real LiveTVScreen geometry, outside the card deck.
- It remains active during grid focus/paging and the grid's own quick controls.
- It does not render in Guide, other app tabs, Search/details or playback.

### Live TV grid motion and depth
- Animated Live TV header logo scaled down slightly (92% / 33pt envelope) without changing any style internals.
- Focused grid cards use a stronger physical lift: compound 3D perspective, dual shadow depth and restrained accent edge light.
- The 4×3 deck also gets an unboxed static ambient depth field, adding stage presence without bringing back the large enclosure/rail treatment.
- Incoming and outgoing cards now use overlapping spring motion so defocus no longer snaps flat before the next card rises.
- Card artwork, footer, metadata, channel number, progress line and preview contents are otherwise unchanged.

## Preserved
- vBRDC168 adaptive bitrate + Apple TV memory + source-health VOD cache logic.
- vBRDC169 Guide full-frame preview playback route and audible Live TV preview behavior.
- 4×3 Live TV page system and edge navigation behavior.
- Live TV grid left controls and Guide-independent category behavior.
- Alternate Audio, VOD hydration, Favorites persistence/performance and Bluetooth playback work.

## Validation
- All Swift source files parse successfully with `swiftc -parse`.
- The one existing PlaybackKit line-95 parser warning is also present in untouched vBRDC169 and is not introduced by vBRDC170.
- Both plists report 1.0.873 / 873 / vBRDC170.
- `project.yml` parses and both target version blocks are 1.0.873 / 873.
- Behavior contract checks pass.
- GitHub Actions/Xcode remains the authoritative tvOS/iOS compile test.
