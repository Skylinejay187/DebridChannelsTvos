# vBRDC176 Regression Locks

Compile-only successor to vBRDC175.

- Do not change catalog UI/data behavior.
- Preserve Live TV 4x3 paging/navigation, bottom-right page indicator, card information, focus ring and v170/v175 focus motion.
- Preserve v175 black-glass Live TV/Guide appearance exactly.
- Preserve Guide live preview behavior.
- Preserve v171 Favorites/Sports/runtime hardening.
- Preserve v174 concrete FFmpeg Alternate Audio track selection.
- Preserve v168 adaptive VOD cache.
- Vendor/KSPNUVIO is locked.
