from pathlib import Path
import plistlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))
# exact compiler repair
ck("ANY DVR JSON optional coalesced", 'jsonChannels = parseDVRChannelsJSON(data, base: base, device: "ANY") ?? []' in s)
ck("named DVR JSON optional coalesced", 'let list = parseDVRChannelsJSON(data, base: base, device: device) ?? []' in s)
ck("parser remains optional by design", 'private func parseDVRChannelsJSON(_ text: String, base: String, device: String) -> [LiveTVChannel]?' in s)
# preserve v153 transport
ck("URLSession primary provider transport preserved", 'Self.providerSession.data(for: networkRequest)' in s)
ck("PlainHTTP compatibility fallback preserved", 'PlainHTTPClient.fetchData' in s)
ck("MediaFlow bootstrap routing preserved", 'MediaFlowProxyRouter.liveTVBootstrapRequestsIfAllowed' in s)
# preserve v154 favorites repair
handler=s[s.index('private func handleTopMenuDownCommand()'):s.index('var body: some View', s.index('private func handleTopMenuDownCommand()'))]
ck("Favorites origin handoff preserved", 'if origin == .favorites' in handler)
fav_branch=handler[handler.index('if origin == .favorites'):handler.index('if enteredFromSettings')]
ck("Favorites branch does not select Live TV", 'store.selectedTab = .live' not in fav_branch)
ck("Favorites branch returns before generic Live TV path", 'return' in fav_branch)
ck("Favorites content focus token handoff preserved", 'store.contentFocusToken &+= 1' in fav_branch)
# accepted Live TV UI/settings preserved
ck("channel number preference preserved", 'liveTVChannelNumberPosition' in s)
ck("top menu theme engine preserved", 'TopMenuTabVisual' in s and 'TopMenuThemeStyle.resolve' in s)
ck("Guide double-down state preserved", 'PRESS ↓ AGAIN TO OPEN' in s)
ck("animated Live TV logo styles preserved", 'Signal Matrix' in s and 'Retro Tube' in s)
# metadata
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with (ROOT/rel).open('rb') as f: d=plistlib.load(f)
    ck(rel+" marketing", d.get('CFBundleShortVersionString')=='1.0.858')
    ck(rel+" build", d.get('CFBundleVersion')=='858')
    ck(rel+" release", d.get('DebridChannelsReleaseID')=='vBRDC155')
y=(ROOT/'project.yml').read_text()
ck("project marketing", y.count('MARKETING_VERSION: 1.0.858')>=2)
ck("project build", y.count('CURRENT_PROJECT_VERSION: 858')>=2)
passed=sum(v for _,v in checks)
for name,ok in checks:
    print(("PASS" if ok else "FAIL")+": "+name)
print(f"{passed}/{len(checks)} checks passed")
sys.exit(0 if passed==len(checks) else 1)
