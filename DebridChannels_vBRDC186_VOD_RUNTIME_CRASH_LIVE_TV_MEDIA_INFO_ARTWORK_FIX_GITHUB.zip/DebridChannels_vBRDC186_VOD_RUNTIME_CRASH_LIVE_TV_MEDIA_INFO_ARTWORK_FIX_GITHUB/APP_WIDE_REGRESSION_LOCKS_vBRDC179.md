# vBRDC179 regression locks

- Donor/source of truth: packaged vBRDC178 only.
- Do not change catalog presentation/logic in this release.
- Do not change VOD playback, resume, adaptive cache, Alternate Audio, Bluetooth, Sports, Favorites, Search, or backend behavior in this release.
- Live TV grid: preserve 12-channel page behavior, bottom-right page indicator, focus ring and focus-motion/navigation logic.
- Guide: preserve live preview surface and Exit/Back hint behavior/presentation.
