# Debrid Channels vBRDC168 — Adaptive VOD Cache

Build metadata: **1.0.871 (871)**  
Donor/source of truth: packaged **vBRDC167** only.

## Scope

Playback-only VOD cache evolution. No Live TV UI, Guide UI, Dynamic Wallpaper, Favorites UI, VOD overlay UI, Alternate Audio UI, or catalog navigation redesign is included in this build.

## Adaptive cache policy

The old main-VOD policy used fixed time buckets based mainly on 4K/remux tags and file size. vBRDC168 replaces the main-VOD time ceiling with a byte-budgeted planner using already-owned source metadata:

1. **Apple TV physical-memory tier**
   - Compact: < 2.5 GiB
   - Standard: 2.5–3.5 GiB
   - High: >= 3.5 GiB
2. **Bitrate**
   - Uses an explicit Mbps/Kbps value when the addon/source title exposes one.
   - Otherwise estimates from source size plus a conservative quality/container bitrate floor.
   - As soon as KSPlayer reports the real title duration, the planner refines average bitrate from actual size/duration and retunes the active VOD cache once.
   - 4K/remux is used only as a bitrate-risk hint; resolution itself no longer forces a fixed 30-second cache.
3. **Source reliability**
   - Cached debrid links stay on the normal byte budget.
   - Uncached links receive a modest additional reserve.
   - Uncached sources with <=25 reported seeders receive the largest safe reserve for the current memory tier.

The resulting `maxBufferDuration` is calculated from a compressed-packet MiB budget divided by estimated Mbps, then clamped to a memory-tier ceiling. This allows a compressed 4K encode to cache much farther ahead than a high-bitrate remux without giving both sources the same memory cost.

## Low-seeder resilience

Source Intelligence now parses common seeder formats from already-returned stream titles (`Seeders:`, `Seeds:`, `Peers:`, `S:`, `👤`, `👥`) and forwards the result to PlaybackKit through a **transport-only hidden route hint**. The visible playback label/chips remain unchanged.

Low-seeder compensation increases both the safe packet budget and the rebuffer recovery threshold while preserving KSPlayer/KSPNUVIO instant-open behavior. This helps absorb bursty delivery; it cannot make a source whose sustained throughput remains below the video bitrate play indefinitely without buffering.

## Memory-pressure safety

A real tvOS memory-warning notification immediately clamps the active VOD packet-cache time ceiling to at most 30 seconds (while preserving headroom above the preferred buffer threshold). A new playback session recalculates the normal adaptive plan.

## Preserved behavior

- Live TV and trailer cache profiles are unchanged.
- KSMEPlayer remains main VOD primary with KSAVPlayer fallback.
- Existing decoder/probe safeguards for 4K/remux/lossless-audio content remain in place.
- VOD instant-open, resume, scrubber ghost buffer, Alternate Audio, Bluetooth controls, source failover, and display cadence logic are unchanged except that automatic source failover recalculates the hidden cache-reliability hint for the replacement source.
