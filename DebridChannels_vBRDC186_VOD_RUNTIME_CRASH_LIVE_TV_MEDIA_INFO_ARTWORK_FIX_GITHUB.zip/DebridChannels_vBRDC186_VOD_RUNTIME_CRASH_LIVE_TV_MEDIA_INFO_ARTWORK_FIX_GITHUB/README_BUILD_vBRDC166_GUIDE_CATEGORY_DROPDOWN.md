# Debrid Channels vBRDC166 — Guide Category Drop-Down

Release: **vBRDC166**  
Marketing version: **1.0.869**  
Build: **869**

Built directly from the packaged vBRDC165 source. No mockups, generated UI images, or replacement visual assets were added.

## Change

- Refined the full Live TV Guide category selector to behave like a DVR category drop-down.
- The Guide header now shows one compact current-category control such as **Favorites ▼** or **All Channels ▼**.
- Moving LEFT from the Guide focuses that visible selector instead of silently opening a hidden menu.
- Pressing Select on the selector opens the channel-category list.
- The list uses the same Live TV category source already used by the grid, including My Favorites, All Channels, HD, Favorites, Sports, Drama, News, Kids, and provider-created groups.
- Selecting a group immediately reprojects the Guide rows to that category, rebinds focus, and resumes the selected channel preview.
- Removed the extra Guide helper text so the header stays clean and the selector itself explains the interaction.
- Back/Menu while the drop-down is open closes only the drop-down; Back/Menu from the Guide still closes the Guide.
- The larger left-edge Live TV grid Tools rail remains grid-only.

## Preserved from vBRDC165

- Audible Live TV grid and Guide preview audio.
- Top Menu Size presets.
- Expanded animated Live TV logo library and accent-aware animated styles.
- App-wide non-playback Dynamic Wallpaper lifecycle.
- 4x3 Live TV paging/navigation.
- Favorites geometry/backdrop corrections.
- VOD first-open hydration hardening.
- Universal local Alternate Audio path.
