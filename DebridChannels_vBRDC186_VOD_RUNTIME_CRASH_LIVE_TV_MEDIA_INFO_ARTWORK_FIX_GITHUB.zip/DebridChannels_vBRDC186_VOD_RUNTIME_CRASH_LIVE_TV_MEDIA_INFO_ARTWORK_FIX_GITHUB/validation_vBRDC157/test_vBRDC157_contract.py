from pathlib import Path
import plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
BASE = Path('/mnt/data/v156_work/DebridChannels_vBRDC156_LIVE_TV_GRID_LAYOUT_CHOOSER_GITHUB')
app = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat = (ROOT/'Sources/CatalogStore.swift').read_text()
sec = (ROOT/'Sources/ReleaseCandidateSecurityManager.swift').read_text()
base_app = (BASE/'Sources/DebridChannelsTVOSApp.swift').read_text()
checks=[]
def check(name, cond):
    checks.append((name, bool(cond)))

def between(text, start, end):
    a=text.index(start)
    b=text.index(end,a)
    return text[a:b]

# Live TV layout: Current locked, Spread Out materially larger.
check('layout key remains v1', '@AppStorage("liveTVGridLayoutStyleV1")' in app)
check('Current option retained', 'static let names = ["Current", "Spread Out"]' in app)
check('Spread Out option retained', 'static let names = ["Current", "Spread Out"]' in app)
check('current card height remains 226', 'spreadOutGrid ? 252 : 226' in app)
check('spread card height is 252', 'spreadOutGrid ? 252 : 226' in app)
check('current row spacing remains 22', 'spreadOutGrid ? 30 : 22' in app)
check('spread row spacing is 30', 'spreadOutGrid ? 30 : 22' in app)
check('current deck spacing remains 13', 'spreadOutGrid ? 16 : 13' in app)
check('spread deck spacing is 16', 'spreadOutGrid ? 16 : 13' in app)
check('current top padding remains 132', '"Spread Out" ? 104 : 132' in app)
check('spread top padding is 104', '"Spread Out" ? 104 : 132' in app)
check('spread frame extends lower', 'spreadOutGrid ? 48 : 132' in app)
check('4-column paging invariant retained', 'private let liveTVGridColumnCount: Int = 4' in app)
check('12-card/3-row paging invariant retained', 'private let liveTVGridPageSize: Int = 12' in app and 'private let liveTVGridColumnCount: Int = 4' in app)

# Provider/bootstrap block must be untouched from v156.
start='    func refreshFromConfiguredSources(showLoadingIndicator: Bool = true) async {'
end='struct LiveTVScreen: View {'
check('Live TV provider/bootstrap block byte-identical to v156', between(app,start,end) == between(base_app,start,end))

# Favorites persistence/restore.
check('snapshot backup key declared', 'favoriteMediaSnapshotsV1Base64' in app)
check('snapshot data base64 encoded for backup', 'return data.base64EncodedString()' in app)
check('favorite snapshot identity drift matcher exists', 'favoriteMediaSnapshotIdentityMatches' in app)
check('favorite snapshot refreshes prior alias entries', 'for key in existingKeys { snapshots[key] = compact }' in app)
check('favorite snapshot lookup honors dictionary identity key', 'favoriteKeys.contains(key) || !favoriteKeys.isDisjoint(with: mediaFavoriteKeys(for: item))' in app)
check('snapshot payload included in profile settings', '"favoriteMediaSnapshotsV1Base64": favoriteMediaSnapshotsBackupString()' in app)
check('snapshot key allowed by backup security', '"favoriteMediaIds", "favoriteMediaSnapshotsV1Base64", "followedShowIds"' in sec)
check('snapshot base64 decoded on restore', 'Data(base64Encoded: encodedSnapshots)' in app)
check('snapshot restore validates MediaItem map', 'JSONDecoder().decode([String: MediaItem].self, from: snapshotData)' in app)
check('snapshot restore writes original data key', 'defaults.set(snapshotData, forKey: favoriteMediaSnapshotsDefaultsKey)' in app)
check('temporary backup key removed after restore', 'defaults.removeObject(forKey: favoriteMediaSnapshotsBackupKey)' in app)
check('orphan favorite hydration task exists', 'favoriteSnapshotHydrationTask' in app)
check('orphan favorite hydration is bounded', 'missingKeys.prefix(16)' in app)
check('orphan favorite calls store rehydration', 'store.rehydrateFavoriteMediaItem(fromFavoriteKey: key)' in app)
check('rehydrated favorite snapshot persisted', 'persistFavoriteMediaSnapshot(item)' in app)
check('favorite hydration method exists', 'func rehydrateFavoriteMediaItem(fromFavoriteKey rawKey: String) async -> MediaItem?' in cat)
check('IMDB restore uses direct Cinemeta metadata', 'return await cinemetaDirect(identityValue)' in cat)
check('TMDB restore path supported', 'identityKind == "tmdb"' in cat)
check('title fallback uses Cinemeta search', 'cinemetaSearchMatch(for: seed, fallbackQuery: cleanQuery)' in cat)
check('favorite detail self-upgrades snapshot on item change', '.onChange(of: item) { updated in' in app and 'persistFavoriteSnapshotIfNeeded(updated)' in app)

# VOD artwork/logo inheritance.
restored = between(cat, '    private func vodCastWallRestoredPlaybackItem(from item: MediaItem) -> MediaItem {', '    /// Phase 8:')
check('VOD launch merges cached artwork', 'let rememberedArtwork = cachedArtwork(for: item)' in restored)
check('VOD launch carries cached logo', 'restored.logoURL = rememberedArtwork.logo' in restored)
check('VOD launch carries hydrated detail logo', 'restored.logoURL = detail.logoURL' in restored)
check('VOD launch no cast-only early gate', 'detail.castMembers.isEmpty' not in restored)

pm = between(cat, '    func playbackMetadata(for item: MediaItem) async -> MediaItem {', '    private func playbackMetadataCacheKey')
selected_pos = pm.find('if let selectedDetail')
early_pos = pm.find('if hadCachedMetadata')
check('selected detail merges before cached-credit shortcut', selected_pos >= 0 and early_pos >= 0 and selected_pos < early_pos)
check('playback item merges before cached-credit shortcut', pm.find('if let playbackItem') < early_pos)
check('playback metadata writes enriched artwork cache', 'cacheArtwork(for: enriched, poster: enriched.posterURL, backdrop: enriched.landscapeURL, logo: enriched.logoURL)' in pm)
check('VOD metadata upgrades favorite snapshot', 'if !favoriteKeys.isDisjoint(with: mediaFavoriteKeys(for: enriched))' in app and 'persistFavoriteMediaSnapshot(enriched)' in app)

# Version contract.
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with open(ROOT/rel,'rb') as f: p=plistlib.load(f)
    check(f'{rel} marketing 1.0.860', p['CFBundleShortVersionString']=='1.0.860')
    check(f'{rel} build 860', str(p['CFBundleVersion'])=='860')
    check(f'{rel} release vBRDC157', p['DebridChannelsReleaseID']=='vBRDC157')
proj=yaml.safe_load((ROOT/'project.yml').read_text())
check('project has marketing 1.0.860', (ROOT/'project.yml').read_text().count('MARKETING_VERSION: 1.0.860')==2)
check('project has build 860', (ROOT/'project.yml').read_text().count('CURRENT_PROJECT_VERSION: 860')==2)

failed=[n for n,ok in checks if not ok]
for n,ok in checks:
    print(('PASS' if ok else 'FAIL')+': '+n)
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    sys.exit(1)
