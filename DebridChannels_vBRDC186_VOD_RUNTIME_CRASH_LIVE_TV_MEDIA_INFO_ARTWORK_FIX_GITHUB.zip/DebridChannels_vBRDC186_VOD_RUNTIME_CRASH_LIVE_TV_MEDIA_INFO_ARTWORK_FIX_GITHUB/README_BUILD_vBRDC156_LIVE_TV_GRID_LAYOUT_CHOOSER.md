# vBRDC156 — Live TV Grid Layout Chooser

Base: packaged vBRDC155 only.
Release: vBRDC156 / 1.0.859 / build 859.

## Scope
Adds one Live TV presentation preference only:
- Current — preserves the existing vBRDC155 4x3 grid geometry.
- Spread Out — keeps the same 4x3 paged grid/navigation but uses more vertical screen real estate with slightly taller cards and wider row spacing.

The preference is stored as `liveTVGridLayoutStyleV1`, participates in backup/restore and stable-default recovery, and is allowlisted by ReleaseCandidateSecurityManager.

No provider, MediaFlow, HDHomeRun, XMLTV/Gracenote, playback, paging, Guide, focus routing, card count, artwork ownership, or channel-number logic is changed by this build.
