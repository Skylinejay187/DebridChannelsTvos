# vBRDC178 Regression Locks

- Build strictly from packaged vBRDC177.
- Keep catalog presentation/behavior untouched.
- Keep Live TV fixed 4x3 paging and bottom-right PAGE indicator.
- Keep Live TV card information content unchanged.
- Keep Live TV focused-card ring implementation unchanged.
- Keep v170+ velocity-friendly Live TV focus motion.
- Keep Guide live preview full-frame/aspect-fit behavior and its external Exit/Back hint.
- Dynamic Wallpaper remains Live TV grid-only; full Guide uses the selected static Live TV theme canvas.
- Preserve v168 adaptive VOD cache and v174 concrete FFmpeg Alternate Audio compile correction.
