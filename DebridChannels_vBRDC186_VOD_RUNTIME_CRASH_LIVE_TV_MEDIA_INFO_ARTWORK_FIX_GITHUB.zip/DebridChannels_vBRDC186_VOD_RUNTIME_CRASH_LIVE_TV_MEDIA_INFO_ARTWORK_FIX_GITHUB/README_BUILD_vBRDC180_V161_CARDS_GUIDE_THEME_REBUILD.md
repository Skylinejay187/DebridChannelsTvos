# Debrid Channels vBRDC180 — v161 Card Restoration + Guide Theme Rebuild

Version: **vBRDC180**  
Marketing version: **1.0.883**  
Build: **883**

## Donor policy

- **Authoritative base:** packaged vBRDC179 only.
- **Visual donor only:** user-supplied packaged vBRDC161, used only to restore the Live TV grid card presentation.
- No v161 playback/store/navigation/runtime files were copied into the v180 base.

## Live TV grid cards

The v179 from-scratch header/navigation additions remain in place, including the All Channels status treatment, selected-station information, Up Next treatment, fixed 4x3 paging behavior, smooth card focus-motion owner, and bottom-right PAGE indicator.

Only the card presentation was rolled back to the v161 visual architecture:

- 24pt rounded broadcast card shell.
- Full-card artwork/live-preview plane.
- v161 lower broadcast gradient shelf.
- v161 footer geometry and typography.
- v161 channel-number badge placement.
- v161 focused-card highlight treatment and existing configured focus ring.

The v179 station-logo reliability work is deliberately retained behind that v161 appearance. The card backdrop/footer now use the dedicated station-logo cache, so program-art churn cannot evict the channel identity logos while scrolling.

## Full Guide rebuild

The Guide is no longer painted with a fixed blue/black overlay. It follows `liveTVGridThemePreset` directly:

- **Pure Black:** neutral black/white Guide surfaces with no forced blue tint.
- Midnight/Glass/Frost/Neon/Artwork/etc.: each uses its own selected Live TV theme color language.
- No Dynamic Wallpaper is mounted inside the full Guide.

The proven Guide live preview and the separate Exit / Back Menu hint remain on their existing playback/focus paths.

Everything else in the Guide presentation was restructured:

- One open Now Playing broadcast console replaces the previous stacked channel-card + program-card header.
- Station identity, current program, timing, description, artwork, and Up Next are grouped in a new hierarchy.
- Timeline header is a continuous themed ruler rather than another blue bar.
- Channel lanes and schedule rows use a flatter continuous schedule treatment instead of the previous boxed skin.
- Category selector/drop-down inherits the active Guide theme palette.

## Regression locks

Unchanged from v179:

- CatalogStore and catalog presentation/runtime.
- Adaptive VOD cache.
- Alternate Audio implementation and v174 concrete FFmpeg audio-track compile fix.
- KSPNUVIO fork.
- Live TV preview audio/playback routing.
- Live TV fixed page/navigation logic and v170+ smooth focus movement.
- v179 All Channels / selected station / Up Next grid header additions.
- Bottom-right PAGE indicator.

## Validation

- Full Swift parser pass: PASS.
- Existing inherited PlaybackKit parser warning only; no new parser errors.
- Sources/Info.plist: PASS.
- TopShelfExtension/Info.plist: PASS.
- project.yml parse: PASS.
- Production diff against v179 limited to DebridChannelsTVOSApp.swift plus version metadata.

GitHub Actions / Xcode remains the authoritative tvOS type-check and device compile.
