# vBRDC175 Regression Locks

This release is a Live TV presentation/performance pass only.

Locked and preserved:
- Catalog UI, catalog motion, catalog row logic and CatalogStore behavior.
- 4x3 Live TV page navigation and edge/double-press paging logic.
- Live TV card footer/content payload.
- Live TV configurable focus ring; exactly one focus-ring render call remains.
- Bottom-right Live TV page indicator.
- Full Guide preview implementation/content mode.
- Live TV grid-only Dynamic Wallpaper ownership.
- Adaptive VOD bitrate/memory/low-seeder caching.
- vBRDC174 concrete FFmpeg Alternate Audio track-selection compile fix.
- Sports M3U and Favorites hardening introduced in vBRDC171.
