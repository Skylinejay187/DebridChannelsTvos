# Debrid Channels vBRDC171 — App Purity / Live TV / Alternate Audio / Favorites / Sports

Version: 1.0.874 (build 874)
Base donor: packaged vBRDC170 only.

## Live TV / Guide
- Removed the CHANNEL/LEFT/EXIT helper from the Guide preview pixels.
- Guide exit helper now occupies a reserved slot beside the preview, so it never covers a broadcast.
- Kept vBRDC170's overlapping spring handoff / smooth card movement.
- Removed duplicate focus ownership: the outer motion host and base card chrome no longer draw focus rings; LiveTVGridFocusRingOverlay is the sole ring owner.
- Refreshed cards into a tighter floating broadcast-glass silhouette with a physical depth lip, lighter static chrome, and one specular reflection.
- Removed the old deck divider/stage feel so Dynamic Wallpaper reads through the full Live TV grid canvas.
- Kept the bottom-right PAGE xx OF xx indicator unchanged.
- Dynamic Wallpaper remains Live-TV-grid-only; it does not mount in the full Guide.

## Alternate Audio
- Audio-only KSMEPlayer now receives a real muted play assertion after prepareToPlay(), so remote audio demux/output cannot remain prepared-but-idle.
- If KSME publishes tracks with none enabled, the same exact-stream/English/untagged selection policy is applied explicitly and the track is selected.
- Initial zero-time alignment no longer depends on a seek callback.
- Non-zero start alignment has a bounded fallback to KSOptions.startPlayTime if a remote container never completes the initial seek callback.
- Apply now attempts other resolved Alternate Audio copies once each before restoring original audio.

## VOD link startup / failover
- Replaced the fixed 12-second startup failover watchdog with adaptive source grace:
  - normal source: 21 s
  - 4K/remux: 25 s
  - uncached source: 30 s
  - uncached <=25 seeders: 36 s
  - uncached <=10 seeders: 42 s
- If the player has already delivered buffered data at the deadline, it receives a final 9-second runway before source failover.
- Transient network/read/HTTP startup errors retry the exact selected URL once in-place before moving to a fallback; codec/format failures still move on immediately.
- Stable-first-frame ownership remains unchanged.

## Favorites / UNITY runtime
- Retained Live TV remains mounted for state/artwork continuity, but its pixels are no longer composited underneath Settings, Favorites, Membership, or Sports.
- Global ticker overlays no longer run on Favorites or Membership.
- Favorites durable media snapshots are decoded/merged once per rebuild instead of twice.
- Existing Favorites restoration/identity hydration remains intact.
- Removed obsolete, unreachable Guide side-rail/static-preview implementations so they cannot accidentally regain focus/layout ownership in later edits.

## Sports M3U
- A source explicitly entered under Sports-only M3U is now trusted as sports content.
- Valid channels are no longer discarded merely because provider EXTINF names/groups omit a sports keyword.
- EXTINF metadata is reset after each URL so malformed lists cannot leak previous channel metadata.
- A retained Sports surface reloads if sportsCustomSourcesJSON changes.

## Purity audit
Static runtime scan after this pass:
- NotificationCenter.default.addObserver: 5
- Timer.scheduledTimer: 0
- addPeriodicTimeObserver: 1
- repeatForever animation sites: 9 (view-lifetime animation owners)
- while !Task.isCancelled loops: 14 (bounded/cancel-aware task owners)

This pass deliberately did not delete historical regression locks or rewrite stable playback/catalog systems merely to reduce line count. Cleanup was limited to redundant active work and proven duplicate visual/runtime ownership.
