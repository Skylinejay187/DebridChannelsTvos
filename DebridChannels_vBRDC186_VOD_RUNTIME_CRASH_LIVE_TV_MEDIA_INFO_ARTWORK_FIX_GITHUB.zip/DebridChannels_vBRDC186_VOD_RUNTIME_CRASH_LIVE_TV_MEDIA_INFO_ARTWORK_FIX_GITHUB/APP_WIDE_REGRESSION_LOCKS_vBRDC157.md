# vBRDC157 Regression Locks

The following are explicit no-regression boundaries for vBRDC157:

1. **Live TV loading is out of scope.** No changes to HDHomeRun, Channels DVR, MediaFlow, M3U, Xtream, XMLTV, Gracenote, provider ordering, provider timeout policy, lineup publication or guide publication.
2. **Live TV navigation is unchanged.** Keep 4 x 3 / 12 cards per page, current edge paging, Guide arm/open behavior, page indicator, focus restoration and preview lifetime.
3. **Current grid stays Current.** Only the `Spread Out` branch receives larger vertical geometry.
4. **Channel number presentation stays intact.** Top Right / Bottom Right / Off remains unchanged.
5. **Favorites navigation stays intact.** vBRDC154 top-menu DOWN must return to Favorites cards rather than Live TV.
6. **Top menu is out of scope.** Preserve vBRDC149 theme identity/renderer and compact sizing.
7. **VOD stream selection is out of scope.** Only MediaItem presentation metadata inheritance/cache ordering changes for logo/artwork recovery.
8. **Sports, Bluetooth controls, resume, provider resolution and playback engines are unchanged.**
9. **Favorites identity remains `favoriteMediaIds`.** Snapshot payload is reconstruction/presentation data only.
10. **No mockups or generated UI assets.** All changes are source behavior/layout changes.
