# Debrid Channels vBRDC169 — Guide Dropdown / Live TV Wallpaper / Preview Frame Fix

Release: vBRDC169
Marketing version: 1.0.872
Build: 872
Donor: packaged vBRDC168 only.

## Fixes

- Full Guide category selector stays a compact inline dropdown directly above the Guide channel column.
- Dropdown ownership moved to the Guide timeline header so it is not clipped/occluded by timeline rows.
- Removed tvOS Button-label dependency from the Guide category chip/menu rows; labels remain visible while focus stays local to the Guide control.
- Dynamic Wallpaper is Live-TV-only again. It fills the entire retained Live TV screen and keeps animating through grid scrolling, Guide navigation, top navigation, and Live TV quick panels.
- Dynamic Wallpaper no longer follows the persistent UNITY LiveTVScreen behind Home, Movies, TV Shows, Sports, Favorites, Settings, Search, or detail surfaces.
- Guide live preview changed from crop-to-fill to aspect-fit so the complete broadcast frame is visible, including edge graphics/tickers/score bugs.
- Guide preview host adds an explicit clipping boundary.

## Regression locks

- vBRDC168 bitrate + Apple TV memory-aware adaptive VOD cache is byte-identical.
- CatalogStore source-health/seeder transport metadata from vBRDC168 is byte-identical.
- Live TV grid left-side panel remains separate from the Guide-only category dropdown.
- No mockup/image-generation work is part of this build.
