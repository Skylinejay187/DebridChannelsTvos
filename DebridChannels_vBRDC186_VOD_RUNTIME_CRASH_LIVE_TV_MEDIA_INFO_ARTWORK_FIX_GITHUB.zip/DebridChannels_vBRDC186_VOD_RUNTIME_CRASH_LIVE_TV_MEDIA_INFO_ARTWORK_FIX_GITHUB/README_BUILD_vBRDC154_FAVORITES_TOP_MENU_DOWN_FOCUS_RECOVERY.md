# vBRDC154 — Favorites Top Menu Down Focus Recovery

Base: vBRDC153 package, unchanged except for the scoped Favorites focus/navigation repair and release metadata.

## Fix
- Favorites -> UP to the global top menu -> DOWN no longer falls through the generic non-Settings path that forces Live TV.
- The TopMenuBar recognizes Favorites as a dedicated origin and yields focus back through `contentFocusToken` without changing `selectedTab`.
- GlobalFavoritesScreen explicitly observes that handoff, clears secondary Remove-button focus, then reacquires the Favorites rail on the next run-loop turn.

## Preserved
- Settings-specific top-menu DOWN behavior.
- Existing Live TV top-menu DOWN behavior.
- Favorites Back/Exit -> Home behavior.
- Live TV provider/bootstrap transport from vBRDC153.
- Live TV channel-number Top Right / Bottom Right / Off setting.
- Top-menu theme engine, Live TV grid/Guide, playback, artwork, MediaFlow, Sports, and all unrelated UI/logic.
