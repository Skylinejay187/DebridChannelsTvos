# Debrid Channels vBRDC183 — UNITY Main Actor Compile Fix

- Base/donor: packaged vBRDC182 only.
- Marketing version: 1.0.886
- Build: 886
- Release ID: vBRDC183

## Compile correction
GitHub Actions/Xcode reported three actor-isolation errors in `Sources/UnityAppCore.swift` because `UnityAppCore.select(_:store:reason:)` read and wrote `CatalogStore.selectedTab`, and `CatalogStore` is `@MainActor`.

The navigation bridge is now explicitly `@MainActor`, matching the existing `CatalogStore` isolation boundary. No UNITY navigation behavior, UI, playback, Live TV, Guide, catalog, Favorites, Sports, Alternate Audio, or adaptive-cache logic was changed.
