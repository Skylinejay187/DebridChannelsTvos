# Debrid Channels vBRDC184 — Playback UNITY Catalogs + Compile Fix

Marketing version: **1.0.887**  
Apple build: **887**  
Release ID: **vBRDC184**

Built only from packaged **vBRDC183_COMPILE_FIX_UNITY_MAIN_ACTOR**.

## Build error fixed

The supplied GitHub Actions log fails at `DebridChannelsTVOSApp.swift:1532` because Swift cannot type-check the monolithic `RootView.body` expression within its compiler budget. vBRDC184 preserves modifier order and runtime behavior but splits RootView into four opaque SwiftUI stages (`rootVisualTree`, `rootPlaybackLifecycleTree`, `rootSurfaceObservationTree`, `rootStateObservationTree`).

The new playback browser is also isolated behind its own opaque `playbackUnityCatalogLayer` so the added feature does not recreate the same generic-expression compiler pressure inside `VODPlayerScreen`.

## Playback UNITY browser

- Adds **Home**, **Movies**, and **TV Shows** chips to both VOD playback and Live TV playback controls.
- Opens the existing production `GridOSCatalogOverlay` directly over the still-playing video.
- Uses the exact existing `CatalogStore.rows`, row projection, card renderer, provider ordering, selection identity, Media Information, episode browser, and Source Intelligence / Find Links implementation. There is no copied catalog model or second resolver implementation.
- Video/audio is not paused just because the catalog opens.
- Back/Menu closes Media Information first, then returns from the catalog to the current playback session.
- Choosing a playable title/source naturally starts that title through the existing playback path.

## Playback-specific presentation

- Media Information retains its production layout but gains a small **PLAYBACK BROWSE** identity badge and a cyan/indigo connected-panel edge so it is visually clear the user is browsing from inside playback.
- A lightweight playback-browse header identifies Home / Movies / TV Shows and indicates that Menu returns to playback.

## Frame-budget protection

- The playback browser does not start focused-card trailer previews or speculative connected-popup artwork prewarm.
- Visible catalog artwork is explicitly allowed to publish while playback owns the full-screen render lane, with the playback hero decode bounded to 1920px.
- A narrowly scoped `playbackUnityBrowseActive` interaction lane permits only user-requested detail/source work while the standard VOD-exclusive background gates remain in force.
- General catalog refresh/prefetch/background work remains protected by the existing exclusive-playback rules.

## Validation performed in this package

- Swift frontend parse completed for the modified app/store/gate files.
- Release/version values are synchronized between `project.yml`, app Info.plist and Top Shelf Info.plist.
- The supplied log was rechecked and contains one app compile failure: the RootView type-check timeout addressed above; the KSPlayer messages around it are warnings.
- Full tvOS SDK compilation still belongs to GitHub Actions/Xcode because this packaging environment is Linux and has no `xcodebuild` / Apple tvOS SDK.
