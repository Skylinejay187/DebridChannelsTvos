# Debrid Channels vBRDC142 — Post-VOD Live TV Artwork Rehydration

Release: vBRDC142  
Marketing: 1.0.845  
Apple build: 845

## Scope

Built only from the user-supplied packaged vBRDC141 base. This is a narrow lifecycle correction for one reported regression: after closing movie/show playback, Live TV Gracenote/program artwork and channel imagery could return as generic/blank cards.

## Root cause

Full-screen playback intentionally removes `LiveTVScreen` from the SwiftUI render tree. vBRDC139+ correctly kept a Live TV root mounted behind normal non-playback catalog surfaces and correctly suppressed hidden Live TV image/network work. However, after a movie/show closes, the newly-created Live TV root can remount while Movies/Shows still owns the visible surface. That remount was treated like ordinary covered startup, so the existing bounded post-playback artwork bootstrap was not armed. The grid therefore lost the immediate Gracenote/channel-image rehydration path until a later Live TV interaction/remount woke it.

## Correction

- `CatalogStore.closePlayer` now records one non-published generation only when the closing item is non-Live-TV playback.
- The newly mounted `LiveTVScreen` consumes that generation exactly once.
- That VOD-return generation activates only the existing bounded Live TV artwork bootstrap corridor.
- Gracenote/program artwork and the vBRDC141 independent native channel-logo fallback can therefore rebind before Live TV is exposed again.
- No provider/XMLTV/Gracenote source refresh is started behind Movies/Shows by this recovery path.
- Live TV playback focus restoration remains on its existing dedicated snapshot path.
- Ordinary hidden Live TV startup under catalogs remains quiescent.

## Production delta from vBRDC141

Functional source:
- `Sources/CatalogStore.swift`
- `Sources/DebridChannelsTVOSApp.swift`

Version metadata only:
- `Sources/Info.plist`
- `TopShelfExtension/Info.plist`
- `project.yml`

No other production file changed.

## Validation

- 273/273 cumulative vBRDC142 source/regression contracts passed.
- 74 Swift files parsed cleanly with `swiftc -parse`.
- App and Top Shelf plists lint cleanly.
- `project.yml` parses cleanly.
- 36 backend runtime tests + 2 subtests passed.
- Production-delta audit confirms exactly the five files listed above differ from packaged vBRDC141.

Physical Apple TV testing remains authoritative for SwiftUI/tvOS remount timing and network image presentation.
