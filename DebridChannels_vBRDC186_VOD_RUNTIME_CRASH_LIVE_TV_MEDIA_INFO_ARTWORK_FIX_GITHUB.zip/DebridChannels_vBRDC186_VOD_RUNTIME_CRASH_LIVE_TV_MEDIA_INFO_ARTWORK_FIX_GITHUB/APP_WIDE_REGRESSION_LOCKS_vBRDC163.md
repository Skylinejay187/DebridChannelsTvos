# vBRDC163 Regression Locks

- Preserve packaged vBRDC162 as the only donor/base for this release.
- Preserve all vBRDC162 VOD overlay hydration and Universal Alternate Audio corrections.
- Live TV stays on the existing 4x3 paged focus/navigation engine.
- Do not restore the vBRDC162 giant rounded broadcast-deck enclosure, signal rail, inset card frame, top card marker, or boxed footer shelf.
- Live TV card decoration remains static and focus-passive: no new timers, network work, video surfaces, blur, or focus owners.
- Animated Live TV Header Logo Off draws no generic/static replacement identity.
- Grid Guide hint auto-hide remains 10 seconds.
- Preserve existing Gracenote/channel-logo fallback and forced artwork reload behavior.
- Favorites must not use progressively shrinking/fan-style preview-card widths; equal-width preview geometry is Favorites-only.
- Home/Movies/Shows generic catalog rail fan geometry remains unchanged.
- Favorites full-screen background must never fall back from missing landscape art to a portrait poster.
- Favorites full-screen artwork is constrained to the actual viewport and cannot alter parent layout geometry.
- Do not modify Vendor/KSPNUVIO source for this release.
