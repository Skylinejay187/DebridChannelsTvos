# vBRDC182 UNITY Re-Core Architecture

## Rule
One app shell; independent surfaces.

```
DebridChannelsRoot
├── UnityAppCore
│   ├── navigation truth
│   ├── effective runtime surface
│   ├── top-navigation focus/session
│   ├── shared palette
│   └── process-level app events
├── PersistentTopNavigationHost
└── Surface Presentation
    ├── Home / Movies / TV Shows
    ├── Sports
    ├── Favorites
    ├── Live TV Grid
    ├── Live TV Guide
    ├── Settings
    ├── Search / Detail
    └── Playback
```

## Theme model
A shared palette owns color tokens only:
- base background
- elevated surface
- neutral surface
- border/divider
- app accent
- primary/secondary/tertiary text
- focus accent

Each surface owns its own geometry. Live TV Grid card themes are not Guide themes. Guide can use the same app background/accent while retaining a Guide-specific timeline, channel lane and information hierarchy.

## Runtime model
A surface has separate policy for:
- keeping state resident
- keeping pixels mounted while covered
- permitting ambient motion while visible
- permitting background prefetch while hidden

This prevents the old false choice between destroying state on every navigation event and leaving hidden heavy GPU/network work running underneath another surface.

## Compatibility migration
`CatalogStore.selectedTab` remains during the migration because hundreds of hardened feature paths still reference it. v182 makes it a compatibility mirror; new global navigation uses `UnityAppCore.select(...)` and legacy direct writes immediately synchronize the core.

This avoids a risky one-build rewrite while establishing one navigation truth for new work.

## Next migration stages
After v182 is device-verified, old per-surface focus/lifecycle patches can be removed in bounded stages rather than accumulating another compatibility layer:
1. Catalog focus/token cleanup.
2. Favorites/Search state ownership cleanup.
3. Sports surface residency cleanup.
4. Live TV Grid/Guide ownership split behind shared Live TV model.
5. Settings and remaining overlay ownership.
6. Remove compatibility `selectedTab`/focus-token bridges only after no active feature path needs them.
