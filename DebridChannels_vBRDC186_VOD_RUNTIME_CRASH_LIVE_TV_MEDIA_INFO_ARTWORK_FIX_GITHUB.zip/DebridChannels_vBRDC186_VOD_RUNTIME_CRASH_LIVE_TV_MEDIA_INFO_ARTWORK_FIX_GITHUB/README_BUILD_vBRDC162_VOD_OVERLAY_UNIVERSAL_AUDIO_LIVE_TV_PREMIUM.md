# Debrid Channels vBRDC162 — VOD Overlay Hydration + Universal Local Audio + Live TV Premium Refresh

Release: **vBRDC162**  
Marketing version: **1.0.865**  
Apple build: **865**  
Base: **packaged vBRDC161 only**

## 1. VOD overlay first-open recovery

This build fixes the shared lifecycle failure behind themed logos, Featured Cast artwork, and Production & Ratings sometimes being incomplete until the VOD overlay was closed and reopened.

- VOD metadata hydration now starts once after the first stable frame even while playback is continuing instead of being cancelled as soon as `isPlaying` becomes true.
- Overlay-open, first-frame, and enriched-metadata requests share one bounded single-flight owner instead of repeatedly cancelling/restarting the same request.
- Generation ownership prevents an older cancelled task from clearing or blocking a newer valid metadata request.
- Search/Favorites playback shells that gain richer TMDB/IMDb identity after playback begins immediately refresh Production & Ratings instead of waiting for the next overlay presentation.
- The main VOD title logo, Production artwork, Production title logo, and company logo use the foreground playback publication contract so decoded artwork is allowed to paint while VOD is active.
- Existing Featured Cast retained-frame/forced-publication behavior remains intact.

## 2. Universal local Find English Audio

The old backend-bridge compatibility classification is no longer a playback gate.

- Every resolved alternate copy is locally selectable, including candidates previously labelled `Incompatible` by bridge-era identity/timing checks.
- The **currently playing copy itself** is also a valid audio-only source. Find English Audio therefore still has a local path when only one direct link exists.
- Local candidates are published immediately; backend ffprobe is enrichment only and may add an exact English stream index/codec/title.
- If the backend probe is unavailable, on-device local audio candidates remain usable.
- Sampled video fingerprinting is disabled for discovery because local dual-source playback no longer depends on a video-identity compatibility decision.
- The first discovered candidate is selected automatically when no saved choice exists.
- KSME audio selection now recognizes `en`, `eng`, regional English tags such as `en-US`, explicit English track names, then safely falls back to a non-commentary/non-descriptive untagged track when containers omit language metadata.
- The primary video URL remains mounted; the hidden local KSME/FFmpeg decoder supplies only audio, and the original player audio is muted only after the local audio decoder reports ready.

This makes Alternate Audio universal across the current file and all available resolved copies. It cannot manufacture an English soundtrack when none of the available media files actually contains one.

## 3. Live TV premium page refresh

The existing paged Live TV navigation/focus model is preserved.

- Guide hint auto-hide shortened from 30 seconds to **10 seconds**.
- Turning **Animated Live TV Header Logo** Off now removes the Live TV header identity completely; no generic static replacement is inserted.
- Existing 4×3 page navigation and page boundaries are retained.
- Added a static premium broadcast-deck chassis and signal rail around the page.
- Cards receive a new layered broadcast surface, inset border, compact top signal marker, and premium information shelf.
- Page position badge is redesigned as a compact broadcast-style PAGE indicator.
- The retired left-side card rail and generic LIVE badge are not reintroduced.
- The new visual layers own no focus, timers, network requests, video surfaces, or blur effects.

## Scope / regression protection

- Built only from the supplied vBRDC161 package.
- No Vendor/KSPNUVIO source was modified.
- No provider, MediaFlow, Gracenote, resume, Bluetooth, or catalog navigation logic was redesigned.
- Live TV paging/focus mechanics are preserved; changes are visual plus the requested 10-second hint and header-off behavior.
