# Debrid Channels vBRDC123 — VOD Foreground Artwork + Cast Rotation Hardening

- Release ID: `vBRDC123`
- Marketing version: `1.0.826`
- Apple build: `826`
- Donor: packaged `vBRDC122`

## Physical-test regressions addressed

1. Featured Cast could appear stuck on one actor even though its existing seven-second rotation index continued advancing.
2. Full VOD Season/Episode Browser cards could remain blank until the user switched seasons repeatedly, which remounted the cards and gave artwork another publication opportunity.
3. These regressions could reappear even while earlier source-presence locks still passed because the failure lived in shared foreground-artwork publication ownership rather than missing feature code.

## Root cause

vBRDC119 correctly moved ordinary artwork publication to a durable event-driven frame gate. That is appropriate for catalog/background/decorative work, but two foreground VOD surfaces were still using the durable path:

- Featured Cast retained the outgoing portrait until the requested replacement bitmap actually published. The rotation index could advance every seven seconds while the replacement remained held behind the durable gate, making the visible actor look frozen.
- Phase 15 Episode Browser artwork did not opt into playback publication at all. The episode session remained mounted while the browser was open/paused, so decoded stills could remain withheld until a season remount changed view ownership.

## Hardening

- Compact and Full Poster Featured Cast now opt into the bounded foreground-VOD must-paint path while preserving retained-frame handoff.
- The seven-second Featured Cast cadence remains unchanged.
- Featured Cast rotation ownership now includes the actual image-backed member IDs and URLs, not only member count, so same-count cast metadata replacement restarts the correct current-data rotation owner.
- Full VOD Episode Browser cards use bounded 768 px foreground playback publication.
- Episode Browser artwork selection ignores blank URLs and falls through `landscape -> preview -> poster`.
- Existing detail episode preview cards use the same foreground VOD publication policy.
- Up Next episode artwork uses the same bounded foreground policy.
- The force-publication path remains explicit opt-in only and retains the 0.45-second navigation courtesy window. It is not enabled globally for catalog, wallpaper, Live TV, Sports, Favorites, or decorative 4K surfaces.
- vBRDC122 hidden-chrome protection remains: base VOD cleanup cannot cancel visible Cast Explorer, Episode Browser, or pending VOD switch artwork.

## Preserved behavior

- vBRDC122 Cast Explorer person/Known For artwork recovery is preserved.
- vBRDC121 Bluetooth VOD Play/Pause/Now Playing ownership recovery is preserved.
- vBRDC119 event-driven frame runtime remains the global default.
- vBRDC118 heavy decorative artwork navigation deferral remains intact.
- PlaybackKit, MediaFlow, Live TV/Gracenote, resume, source ranking, Sports, Favorites, Dynamic Wallpaper, and catalog motion logic are not changed by this build.

## Validation

- vBRDC123 regression contract: 108/108 passed.
- Production Swift syntax parse: 65/65 files passed.
- App and Top Shelf plist/version consistency passed.
- GitHub Actions/Xcode remains the authoritative tvOS Release compile.
- Physical Apple TV remains authoritative for timed Featured Cast cycling and complete Episode Browser artwork hydration.
