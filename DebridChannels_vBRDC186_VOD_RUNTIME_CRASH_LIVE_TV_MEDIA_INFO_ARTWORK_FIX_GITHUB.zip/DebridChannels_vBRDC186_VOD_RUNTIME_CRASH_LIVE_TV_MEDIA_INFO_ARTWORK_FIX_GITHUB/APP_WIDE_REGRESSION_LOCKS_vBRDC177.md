# vBRDC177 regression locks

Compile-only correction from vBRDC176. Preserve all vBRDC176 runtime and visual behavior. The only production source logic delta is the `LiveTVGridFocusRingOverlay.cornerRadius` stored-property declaration required for the existing `cornerRadius: 16` call to compile. Version metadata is advanced to vBRDC177 / 1.0.880 / 880.
