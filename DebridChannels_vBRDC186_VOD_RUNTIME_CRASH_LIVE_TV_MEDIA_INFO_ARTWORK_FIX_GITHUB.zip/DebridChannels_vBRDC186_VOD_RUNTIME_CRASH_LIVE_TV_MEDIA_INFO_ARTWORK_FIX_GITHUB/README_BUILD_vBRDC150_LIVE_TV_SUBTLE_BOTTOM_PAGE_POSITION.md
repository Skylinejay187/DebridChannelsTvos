# Debrid Channels vBRDC150 — Live TV Subtle Bottom Page Position

Release: vBRDC150  
Marketing version: 1.0.853  
Apple build: 853

## Base
Built directly from packaged vBRDC149. No rollback and no donor source was imported.

## Change
- Live TV page position moved from the top-right header to the bottom-right edge of the 4x3 grid.
- Replaced the stronger `PAGE 02 / 13` pill with a quieter compact `02 • 13` position badge and a small grid glyph.
- Lower opacity, lighter stroke, smaller type, and a shorter capsule reduce visual competition with Live TV cards and the Guide glow hint.
- Badge remains non-focusable/non-interactive and does not participate in paging or Guide navigation.

## Explicitly unchanged
- top-menu theme engine, sizing, and DOWN routing from vBRDC149
- all eight animated Live TV header logo styles
- 4x3 Live TV channel paging and double-edge navigation
- Guide DOWN-twice opening and Guide exit behavior
- focused-card previews
- Gracenote/XMLTV/channel-logo loading and recovery
- playback, VOD, Sports, Favorites, MediaFlow, Bluetooth, TorBox/Usenet, and all other app behavior
