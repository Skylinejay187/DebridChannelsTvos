# vBRDC154 Regression Lock

1. Favorites UP -> top menu -> DOWN returns to Favorites cards; it must not change selectedTab to Live TV or Home.
2. Favorites DOWN handoff must reacquire the primary Favorites rail, not the Remove button.
3. Settings top-menu handoff remains unchanged.
4. Live TV top-menu handoff remains unchanged.
5. Favorites Back/Exit remains Home.
6. vBRDC153 Live TV bootstrap/MediaFlow transport remains byte-for-byte untouched outside DebridChannelsTVOSApp navigation changes.
7. vBRDC151 channel-number position setting remains available.
8. Top-menu theme system remains present and unchanged by this fix.
