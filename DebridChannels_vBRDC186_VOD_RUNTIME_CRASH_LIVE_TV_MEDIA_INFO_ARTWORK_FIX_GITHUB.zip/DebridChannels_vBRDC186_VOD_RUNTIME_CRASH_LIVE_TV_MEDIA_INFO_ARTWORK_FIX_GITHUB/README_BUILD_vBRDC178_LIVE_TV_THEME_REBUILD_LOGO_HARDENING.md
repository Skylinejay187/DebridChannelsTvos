# Debrid Channels vBRDC178 — Live TV Theme Rebuild + Logo Hardening

Build identity: **vBRDC178 / 1.0.881 / 881**
Base donor: packaged **vBRDC177** only.

## Live TV grid
- Preserves the fixed 4x3 paging/navigation contract, bottom-right page indicator, card information payload, focused-card ring, and smooth focus-motion engine.
- Rebuilds the surrounding Live TV presentation with a lighter premium theme-reactive canvas, refined header identity, new card shell/edge treatment, and theme-reactive grid quick panel.
- Dynamic Wallpaper remains grid-only and visible through the transparent structural canvas.

## Guide
- User-locked live preview and Exit/Back hint are preserved.
- Removes the forced all-black Guide room and returns Guide to the selected Live TV theme colors.
- Rebuilds the current-channel/current-program header into a new theme-reactive program dossier with channel identity, ON NOW state, program title/time/description, and artwork hierarchy.
- Timeline header, channel pills, category selector/drop-down, program cells and empty cells now inherit the active Live TV theme accent instead of a fixed black treatment.

## Channel-logo reliability
- Visible page channel logos are now prefetched into the same bounded Live TV image cache before richer program art.
- Card fallback, footer logo, and Guide channel identity use a shared bounded immediate-publication logo owner rather than independent native AsyncImage/RemoteImageFit request paths.
- 320px logo cache identity is shared across card backdrop/footer/Guide owners, reducing page-turn and fast-scroll refetches.
- Recycled LazyVGrid logo owners suspend while retaining their decoded bitmap instead of throwing it away during brief page transitions.

## Scope locks
- Catalog code is not intentionally redesigned.
- Guide preview playback geometry is unchanged.
- Focus-ring implementation is unchanged.
- Bottom-right Live TV page indicator is unchanged.
- Alternate Audio and adaptive VOD cache are not intentionally modified.
