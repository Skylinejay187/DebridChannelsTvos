# vBRDC152 — Live TV Lineup-First / Guide Decoupling

Base: vBRDC151 only.
Marketing version: 1.0.855
Apple build: 855

## Scope
Fix the Live TV cold/demo bootstrap where real provider channels could be held behind slow or unavailable Gracenote/XMLTV/EPG work, leaving the built-in demo lineup visible with a blocking spinner.

## Changes
- Real Channels DVR, HDHomeRun, M3U, and Xtream lineups publish as soon as the provider returns usable channel identities.
- HDHomeRun/Gracenote/XMLTV enrichment continues after the real lineup is visible.
- Provisional real channel identity is cached immediately without marking the guide refresh clock complete.
- The blocking Live TV spinner is dismissed as soon as real channels are visible; guide/artwork enrichment continues silently.
- Xtream visible-batch publication uses a bounded 450 ms frame courtesy wait rather than an indefinite frame-lane wait. Final guide publication remains durably gated.
- vBRDC151 Live TV channel-number position setting is preserved unchanged.

## Explicit non-changes
No changes to Live TV paging/navigation, Guide entry/exit, card design, top-menu themes, animated Live TV logos, playback, MediaFlow routing, provider credentials, VOD, Sports, Movies, Shows, Favorites, or Settings behavior outside this bootstrap correction.
