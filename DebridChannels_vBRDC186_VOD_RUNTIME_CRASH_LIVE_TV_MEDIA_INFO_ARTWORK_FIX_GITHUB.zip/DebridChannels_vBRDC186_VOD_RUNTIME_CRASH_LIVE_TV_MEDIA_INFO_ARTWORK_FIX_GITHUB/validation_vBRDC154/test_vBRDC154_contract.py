from pathlib import Path
import plistlib
ROOT=Path(__file__).resolve().parents[1]
s=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
checks={}
def ck(name, cond):
    checks[name]=bool(cond)
    assert cond, name
# Exact Favorites regression repair
handler=s[s.index('private func handleTopMenuDownCommand()'):s.index('var body: some View', s.index('private func handleTopMenuDownCommand()'))]
ck('favorites_origin_branch_present', 'if origin == .favorites' in handler)
fav_branch=handler[handler.index('if origin == .favorites'):handler.index('if enteredFromSettings')]
ck('favorites_branch_does_not_select_live', 'store.selectedTab = .live' not in fav_branch)
ck('favorites_branch_keeps_catalog_rows_hidden', 'store.catalogRowsPresented = false' in fav_branch)
ck('favorites_branch_releases_top_menu_focus', 'focusedTab = nil' in fav_branch and 'topMenuEntryOriginTab = nil' in fav_branch)
ck('favorites_branch_hands_content_focus_back', 'store.contentFocusToken &+= 1' in fav_branch)
ck('favorites_branch_returns_before_generic_live_path', 'return' in fav_branch)
# Favorites surface explicitly reacquires its rail
fav=s[s.index('struct GlobalFavoritesScreen: View'):s.index('struct FavoriteLiveChannelCard: View')]
ck('favorites_content_focus_observer', '.onChange(of: store.contentFocusToken)' in fav)
obs=fav[fav.index('.onChange(of: store.contentFocusToken)'):fav.index('.onMoveCommand', fav.index('.onChange(of: store.contentFocusToken)'))]
ck('favorites_observer_guarded_to_surface', 'favoritesSurfaceActive' in obs and 'store.selectedTab == .favorites' in obs)
ck('favorites_observer_clears_remove_focus', 'removeFocused = false' in obs)
ck('favorites_observer_resets_then_reacquires_row', 'focusedRow = nil' in obs and 'focusedRow = 0' in obs)
# Existing paths preserved
ck('settings_top_menu_path_preserved', 'if enteredFromSettings' in handler)
ck('generic_live_return_path_preserved', 'store.selectedTab = .live' in handler)
ck('favorites_up_to_menu_preserved', 'if direction == .up { store.menuFocusToken += 1 }' in fav)
ck('favorites_exit_home_preserved', 'store.selectedTab = .home' in fav)
ck('live_tv_channel_number_setting_preserved', 'liveTVChannelNumberPosition' in s)
ck('top_menu_theme_engine_preserved', 'TopMenuTabVisual' in s and 'TopMenuThemeStyle.resolve' in s)
# Versions
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with (ROOT/rel).open('rb') as f: d=plistlib.load(f)
    ck(rel+'_marketing', d.get('CFBundleShortVersionString')=='1.0.857')
    ck(rel+'_build', d.get('CFBundleVersion')=='857')
    ck(rel+'_release', d.get('DebridChannelsReleaseID')=='vBRDC154')
y=(ROOT/'project.yml').read_text()
ck('project_marketing', y.count('MARKETING_VERSION: 1.0.857')>=2)
ck('project_build', y.count('CURRENT_PROJECT_VERSION: 857')>=2)
print(f'{sum(checks.values())}/{len(checks)} PASS')
for k in checks: print('PASS', k)
