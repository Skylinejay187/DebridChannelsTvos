# APP-WIDE REGRESSION LOCKS — vBRDC167

- Donor/source of truth: packaged vBRDC166 only.
- No mockup/generated UI assets added.
- Live TV grid keeps its existing 4x3 page system and existing left-side Tools panel.
- Full Guide no longer hijacks LEFT to reach category controls.
- Full Guide category switching is a compact inline dropdown anchored above the Guide channel column.
- Opening the Guide category dropdown must not suppress Live TV preview audio or remount playback merely for menu presentation.
- Dynamic Wallpaper, VOD hydration, Favorites persistence/layout, and universal Alternate Audio behavior remain outside this change.
