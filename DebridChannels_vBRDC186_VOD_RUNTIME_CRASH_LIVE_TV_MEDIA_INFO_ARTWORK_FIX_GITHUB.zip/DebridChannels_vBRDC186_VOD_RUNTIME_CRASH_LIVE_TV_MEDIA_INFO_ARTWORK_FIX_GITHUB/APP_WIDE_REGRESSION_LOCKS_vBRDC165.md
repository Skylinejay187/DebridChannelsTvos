# vBRDC165 Regression Locks

1. Build lineage remains packaged vBRDC164 only.
2. Live TV remains a fixed 4x3 paged grid with existing page-edge navigation and bottom-row Guide opening behavior.
3. Focused grid preview and full-Guide preview are intentionally audible and use Live TV KSPlayer configuration; catalog/VOD trailer previews remain untouched.
4. Full Guide LEFT opens only the compact Channels chip/drop-down. The larger Tools rail remains a grid-only action surface.
5. The Guide Channels drop-down reuses the existing Live TV category indexes and includes My Favorites plus provider-created categories; it must not create a second provider scan path.
6. Top Menu Size scales the completed existing theme composition; it must not replace, flatten, or reinterpret the selected top-menu theme.
7. Medium Top Menu Size preserves vBRDC164 geometry exactly (0.72 scale).
8. Animated Live TV Header Logo Off means no header logo view. The expanded style library does not change Live TV provider/EPG/focus ownership.
9. Dynamic Wallpaper remains continuously mounted for every non-playback surface and is not paused by UNITY navigation/scroll activity. Full-screen playback remains its only hard suspension boundary.
10. VOD first-open hydration, themed-logo recovery, cast/Production & Ratings hydration, and universal local Alternate Audio behavior from vBRDC162 remain untouched.
11. Favorites geometry/backdrop corrections from vBRDC163 remain untouched.
12. No mockup or generated-image asset is part of this build.
