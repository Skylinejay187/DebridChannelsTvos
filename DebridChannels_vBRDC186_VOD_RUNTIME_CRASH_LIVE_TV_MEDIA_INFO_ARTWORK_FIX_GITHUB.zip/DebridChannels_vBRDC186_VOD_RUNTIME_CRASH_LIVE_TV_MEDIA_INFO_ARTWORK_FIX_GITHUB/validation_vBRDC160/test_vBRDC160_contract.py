from pathlib import Path
import hashlib, plistlib, re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
CAT = (ROOT / 'Sources/CatalogStore.swift').read_text()
PK = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PKF = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
UNI = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

# Local candidate transport context.
check('alternate source carries request headers', 'var requestHeaders: [StreamRequestHeader] = []' in CAT)
check('discovery reattaches source headers', 'copy.requestHeaders = link.requestHeaders' in CAT)
check('discovery publishes enriched candidates', 'alternateAudioSources = enriched' in CAT and 'return enriched' in CAT)

# VOD UI uses local audio, not backend bridge.
check('audio action calls local use', 'case .alternateAudioPrepareBridge:\n            useSelectedAlternateAudioLocally()' in APP)
check('button label is Use This Audio', '"Use This Audio"' in APP)
check('old prepare and use bridge label removed', 'Prepare & Use Audio Bridge' not in APP)
sync_start = APP.index('case .alternateAudioMinus250:')
sync_end = APP.index('case .alternateAudioClear:', sync_start)
SYNC_ACTIONS = APP[sync_start:sync_end]
check('sync offset does not rebuild bridge', 'adjustAlternateAudioSyncOffset' in SYNC_ACTIONS and 'prepareAlternateAudioBridge' not in SYNC_ACTIONS and 'useSelectedAlternateAudioLocally()' not in SYNC_ACTIONS)

local_start = APP.index('    private func useSelectedAlternateAudioLocally()')
local_end = APP.index('    private func prepareAlternateAudioBridge(', local_start)
LOCAL = APP[local_start:local_end]
check('local use never calls backend bridge prepare', 'store.prepareAlternateAudioBridge' not in LOCAL)
check('local use keeps primary prepared URL clear', 'preparedPlaybackURL = nil' in LOCAL)
check('local use installs external audio URL', 'localAlternateAudioURL = engineURL' in LOCAL)
check('local use installs ffprobe stream index', 'localAlternateAudioTrackIndex = source.audioTrackIndex' in LOCAL)
check('local use forwards provider headers', 'source.requestHeaders.playbackHTTPHeaderDictionary' in LOCAL and 'localAlternateAudioHTTPHeaders = engineHeaders' in LOCAL)
check('local use switches same primary to KS only when needed', 'if !forceKSPlayerSurface {' in LOCAL and 'ksSurfaceToken &+= 1' in LOCAL)
check('local use does not assign bridge hls URL', '.hlsURL' not in LOCAL)

# Local decoder implementation.
check('local direct KSME controller exists', 'final class LocalExternalAudioController: NSObject, MediaPlayerDelegate' in PK)
check('secondary uses KSME directly', 'let newPlayer = KSMEPlayer(url: sourceURL, options: options)' in PK)
check('secondary video decode disabled', 'options.videoDisable = true' in PK)
check('secondary remote controls disabled', 'options.registerRemoteControll = false' in PK)
check('secondary starts at aligned time', 'options.startPlayTime = desiredAudioSeconds' in PK)
check('offset semantics preserved locally', 'targetMainSeconds - Double(offsetMS) / 1000.0' in PK)
check('ffprobe absolute stream id selected before decoder open', 'final class LocalExternalAudioOptions: KSOptions' in PK and 'override func wantedAudio(tracks: [MediaPlayerTrack]) -> Int?' in PK and 'Int($0.trackID) == preferredAudioTrackIndex' in PK and 'LocalExternalAudioOptions(preferredAudioTrackIndex: preferredTrackIndex)' in PK)
check('english fallback remains', 'value.contains("english")' in PK and 'return english' in PK)
check('drift correction is secondary-only seek', 'player.seek(time: desired)' in PK and 'abs(drift) > 0.40' in PK)
check('main clock drives local sync', 'externalAudioController?.syncToMainClock(currentPlaybackSeconds)' in PK)
check('main seek forces local resync', 'externalAudioController?.syncToMainClock(max(0, externalTarget), force: true)' in PK)
check('play pause mirrors to secondary', 'externalAudioController?.update(mainSeconds:' in PK)
check('primary mute uses public KSP API', 'layer.player.isMuted = muteAudio' in PK and 'layer.player.playbackVolume = muteAudio ? 0.0 : 1.0' in PK)
check('legacy KVC mute probing removed', 'setMuted:' not in PK and 'setPlaybackVolume:' not in PK)
check('primary muted only after local ready', 'mainLayer.player.isMuted = true' in PK and 'coordinator.onExternalAudioReady?()' in PK)
check('secondary stays silent until primary mute handoff', 'newPlayer.playbackVolume = 0.0' in PK and 'onReady()\n            player?.playbackVolume = 1.0' in PK)
check('local failure restores primary audio output', 'mainLayer.player.isMuted = coordinator.currentMuteAudio' in PK and 'coordinator.onExternalAudioFailure?(message)' in PK)
check('secondary avoids second KSPlayerLayer global controls', 'KSPlayerLayer(url: sourceURL' not in PK[PK.index('final class LocalExternalAudioController'):PK.index('final class Coordinator')])
check('retired KSME decoders held until primary teardown', 'retiredExternalAudioPlayers: [KSMEPlayer]' in PK and 'retiredExternalAudioPlayers.removeAll()' in PK)

# Plumbing reaches KS surface.
for source, label in [(UNI, 'universal'), (PKF, 'playback kit')]:
    check(f'{label} forwards external audio track index', 'externalAudioTrackIndex' in source)
    check(f'{label} forwards external audio headers', 'externalAudioHTTPHeaders' in source)
check('VOD surface passes local audio fields', 'externalAudioURL: isLivePlayback ? nil : localAlternateAudioURL' in APP and 'externalAudioTrackIndex: isLivePlayback ? nil : localAlternateAudioTrackIndex' in APP)
check('VOD surface handles ready callback', 'onKSExternalAudioReady:' in APP and 'alternateAudioHandoffState = .active' in APP[APP.index('onKSExternalAudioReady:'):APP.index('onKSExternalAudioFailure:')])
check('VOD surface handles failure callback', 'onKSExternalAudioFailure:' in APP and 'restoreOriginalAudio(' in APP[APP.index('onKSExternalAudioFailure:'):APP.index('onKSChaptersDiscovered:')])

# Restore original must be no-recreate for local path.
restore_start = APP.index('    private func restoreOriginalAudio(reason: String, clearSelection: Bool)')
restore_end = APP.index('    private func applyAlternateAudioSelection()', restore_start)
RESTORE = APP[restore_start:restore_end]
check('restore clears local secondary URL', 'localAlternateAudioURL = nil' in RESTORE)
check('restore clears secondary stream/header state', 'localAlternateAudioTrackIndex = nil' in RESTORE and 'localAlternateAudioHTTPHeaders = [:]' in RESTORE)
check('restore does not recreate KS surface', 'ksSurfaceToken &+=' not in RESTORE)
check('restore does not seek primary', 'ksSeekSerial &+=' not in RESTORE and 'ksSeekSeconds =' not in RESTORE)

# Settings copy reflects local behavior.
check('settings explains local on-device audio', 'opens only that audio locally on Apple TV while the current video source keeps playing unchanged' in APP)

# Live TV byte lock: must stay exactly v158/v159.
live_start = APP.index('struct LiveTVChannel: Identifiable, Hashable {')
live_end = APP.index('struct SportsLiveEvent: Identifiable {', live_start)
live_hash = hashlib.sha256(APP[live_start:live_end].encode()).hexdigest()
check('Live TV v158/v159 implementation byte lock', live_hash == '981107481bab08218492eb34520d0606c807885ab89d70c60d103f426c7fb2cc')

# Version contract.
with (ROOT/'Sources/Info.plist').open('rb') as f: info = plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top = plistlib.load(f)
check('app release id vBRDC160', info.get('DebridChannelsReleaseID') == 'vBRDC160')
check('app marketing 1.0.863', info.get('CFBundleShortVersionString') == '1.0.863')
check('app build 863', info.get('CFBundleVersion') == '863')
check('topshelf release id vBRDC160', top.get('DebridChannelsReleaseID') == 'vBRDC160')
check('topshelf build 863', top.get('CFBundleVersion') == '863')
project = (ROOT/'project.yml').read_text()
check('project marketing version updated twice', project.count('MARKETING_VERSION: 1.0.863') == 2)
check('project build updated twice', project.count('CURRENT_PROJECT_VERSION: 863') == 2)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' - ' + name)
print(f'RESULT {len(checks)-len(failed)}/{len(checks)} passed')
if failed:
    raise SystemExit(1)
