# Debrid Channels vBRDC159 — Major Favorites / VOD Logo Hardening

Release: **vBRDC159**  
Marketing version: **1.0.862**  
Apple build: **862**  
Base: **vBRDC158 / 1.0.861 / 861**

## Scope

This build is intentionally limited to the two reported major regressions plus Favorites navigation performance:

1. Search/Favorites-origin VOD themed clearlogos could appear in Media Information and then disappear during Source Intelligence / VOD playback or after playback chrome transitions.
2. Favorites restored by protected restore code could retain favorite IDs but still fail to render Search-only titles on a replacement install until the title was searched and favorited again.
3. Favorites still performed unnecessary catalog/image work while entering and navigating the rail.

The Live TV implementation is explicitly locked to vBRDC158. The `LiveTVChannel` through pre-Sports Live TV source/grid section is byte-identical (SHA-256 `981107481bab08218492eb34520d0606c807885ab89d70c60d103f426c7fb2cc`).

## VOD themed-logo hardening

- Search hydration now accepts artwork-only enrichment; a newly resolved clearlogo is no longer ignored just because id/poster/backdrop did not change.
- Search TMDB→IMDb identity strengthening also completes the TMDB presentation-artwork pass before returning.
- Artwork memory is now alias-aware across TMDB, IMDb, TVDB, raw media id, and normalized title/type/year identities.
- Playback metadata cannot take the old cast-complete cache shortcut unless title-logo artwork is already known/remembered.
- Every completed playback metadata wave re-applies the strongest remembered presentation artwork before publication.
- Source Intelligence launches from the latest presentation-restored Media Information object rather than the original lightweight Search/Favorites shell.
- VOD poster/Production title-logo artwork uses force-visible playback publication.
- The visible foreground publication window was expanded through the Source Intelligence→player handoff.
- Hiding VOD chrome continues cancelling heavyweight decorative artwork work, but preserves actively subscribed <=640px foreground title-logo requests so a mounted logo owner cannot be stranded blank.

## Favorites restore hardening

- New protected backups use `favoriteMediaLibraryV2Base64`, a compact portable Favorites record rather than a second full MediaItem metadata cache.
- V2 retains stable identity, title/type/year/catalog, lightweight description/genres/rating, poster, backdrop, clearlogo, preview and add-on identity.
- Cast/credits/episode/franchise arrays are deliberately excluded from the restore payload.
- V2 raw payload is bounded to 900 KB; new backups do not duplicate the large V1 payload when V2 is available.
- Existing V1 snapshot restore codes remain supported as fallback.
- Older `itemID::catalog::type` favorite keys are explicitly recognized instead of being misread as modern identity-kind keys.
- Generic legacy IDs get a direct Cinemeta metadata attempt before text-search fallback.
- Restored/recovered legacy keys migrate to the current canonical favorite key after hydration.
- Once a protected restore code already exists, favorite library changes continue to update it through the existing debounced auto-sync lane.

## Favorites performance

- Favorites uses its persisted library as the primary render source: normal entry is O(number of favorites), not O(all provider/catalog items).
- Catalog rows are scanned only if a favorite genuinely lacks a durable snapshot; found items are immediately persisted so the fallback disappears on subsequent entries.
- Favorites no longer observes the entire `store.rows` collection while the user navigates.
- `previewURL` is no longer treated as a backdrop image (it can be HLS/MP4/YouTube).
- Existing vBRDC158 settled-focus backdrop behavior remains: 180 ms focus settling and bounded 1920px decode.

## Validation

- vBRDC159 targeted contract: 49/49 passed.
- Swift frontend parse: 65/65 production Swift files, 0 failures.
- Backend runtime suite: 36 tests passed + 2 subtests passed.
- App/TopShelf plists parse successfully and report vBRDC159 / 1.0.862 / 862.
- `project.yml` parses and contains marketing/build values twice as required.
- Live TV source/grid implementation is byte-identical to vBRDC158 in its locked section.
- GitHub Actions / Apple tvOS SDK compile remains the authoritative full platform build validation.
