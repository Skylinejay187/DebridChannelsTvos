# Debrid Channels vBRDC151 — Live TV Channel Number Position

Release: vBRDC151  
Marketing version: 1.0.854  
Apple build: 854

## Base
Built directly from packaged vBRDC150. No rollback and no unrelated donor logic was imported.

## Change
- Added `Settings → Live TV → Live TV Channel Numbers` with three choices:
  - `Top Right` (default, preserves vBRDC150 behavior)
  - `Bottom Right`
  - `Off`
- The preference changes only the channel-number badge presentation on Live TV grid cards.
- Bottom-right mode reserves trailing footer space so the badge does not sit on top of program/channel text.
- Off removes the badge entirely while preserving the actual channel number for tuning, EPG identity, Guide, source matching, and playback.
- Preference participates in settings backup/restore and stable-default reset.

## Explicitly unchanged
- top-menu theme engine, sizing, and DOWN routing from vBRDC149/vBRDC150
- Live TV page-position badge at bottom-right
- all eight animated Live TV header logo styles
- 4x3 Live TV paging and deliberate edge navigation
- Guide DOWN-twice opening and Guide exit behavior
- focused-card previews and dimming
- Gracenote/XMLTV/channel-logo loading and recovery
- playback, VOD, Sports, Favorites, MediaFlow, Bluetooth, TorBox/Usenet, and all other app behavior
