# vBRDC170 Regression Locks

- Build only from packaged vBRDC169 donor.
- No mockup/generated image assets added.
- Preserve 4×3 Live TV paging/navigation semantics.
- Live TV grid left-side panel remains grid-only; Guide uses only its compact inline category selector.
- Guide preview must preserve the complete broadcast frame (`scaleAspectFit`).
- Dynamic Live TV Wallpaper must fill the full Live TV grid canvas, remain alive during grid navigation, and remain OFF in full Guide and non-Live-TV surfaces.
- Live TV card interior layout/metadata remains unchanged; vBRDC170 motion changes are compositor/outside-card presentation only.
- Animated Live TV logo OFF still removes the logo entirely; enabled logos are only slightly smaller.
- Preserve vBRDC168 adaptive VOD cache implementation unchanged.
- Preserve universal local Alternate Audio implementation unchanged.
- Preserve Favorites restore, VOD metadata/logo hydration and Bluetooth playback ownership fixes.
