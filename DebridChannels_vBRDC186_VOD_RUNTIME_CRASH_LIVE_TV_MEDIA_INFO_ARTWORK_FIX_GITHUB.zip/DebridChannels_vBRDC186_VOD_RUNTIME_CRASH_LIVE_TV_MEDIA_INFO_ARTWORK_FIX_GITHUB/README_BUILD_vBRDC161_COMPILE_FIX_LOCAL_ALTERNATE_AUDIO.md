# Debrid Channels vBRDC161 — Local Alternate Audio Compile Fix

Release: vBRDC161
Marketing version: 1.0.864
Build: 864
Base: packaged vBRDC160

## GitHub Actions failure fixed

The vBRDC160 tvOS build stopped in `DebridChannelsTVOSApp.swift` because Swift's generated memberwise initializer for `UniversalVideoSurface` requires supplied arguments in declaration order. vBRDC160 supplied `enableDisplayMatch` before `onKSExternalAudioReady` / `onKSExternalAudioFailure`, although the callback properties are declared first.

vBRDC161 moves only those two callback arguments to their correct location, immediately after the external-audio transport arguments and before display-match arguments.

The secondary `.easeInOut` diagnostic was produced downstream of the invalid initializer expression; the animation itself was not changed.

## Alternate Audio preserved

The vBRDC160 on-device Alternate Audio architecture remains intact: the primary movie/video source stays mounted; a secondary audio-only KSMEPlayer/FFmpeg decoder uses the selected alternate copy; the selected audio stream is chosen before decoder creation; primary audio is muted only after the alternate decoder is ready; play/pause/seek/drift/sync follow the main video clock; Restore Original Audio removes the secondary audio without restarting the video; the backend bridge is not used by the active Use This Audio path.

## Scope lock

No Live TV/provider/MediaFlow/Gracenote code changed. No KSPNUVIO vendor source changed. This is a compile-only correction plus release metadata.
