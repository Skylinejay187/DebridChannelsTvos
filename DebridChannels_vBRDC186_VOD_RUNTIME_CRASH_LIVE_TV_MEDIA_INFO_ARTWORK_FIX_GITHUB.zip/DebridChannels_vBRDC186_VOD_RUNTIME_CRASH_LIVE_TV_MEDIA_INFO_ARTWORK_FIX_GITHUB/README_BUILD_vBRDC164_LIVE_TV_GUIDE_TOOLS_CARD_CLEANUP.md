# Debrid Channels vBRDC164 — Live TV Guide Tools + Card Cleanup

Release: **vBRDC164**  
Marketing version: **1.0.867**  
Build: **867**

Built directly from the packaged vBRDC163 source.

## Changes

- Removed the two decorative signal/capsule lines from the lower-left edge of every Live TV grid card.
- Kept the vBRDC163 4x3 paged Live TV grid, artwork, card geometry, paging, preview, focus-ring settings, and provider/EPG behavior unchanged.
- Made the existing left-side **Guide Tools** rail available inside the full Guide as well as the Live TV grid.
- In the full Guide, **LEFT once** opens Guide Tools.
- Guide Tools exposes the existing category set including **My Favorites**, All Channels, HD, Favorites, Sports, Drama, News, Kids, and provider-defined groups.
- Selecting a Guide Tools category updates the active Guide filter without leaving Live TV.
- Closing Guide Tools restores focus to the full Guide when Guide is open, or to the Live TV grid when the grid is open.
- **Back/Menu** remains the immediate full-Guide exit.
- Updated the Guide-side hint and onboarding copy so LEFT is documented as Guide Tools rather than the retired LEFT-twice exit path.

## Regression locks

- No mockup/image assets were added.
- No provider, Gracenote, MediaFlow, playback, Favorites persistence, VOD overlay hydration, or alternate-audio logic was intentionally changed.
- Existing page navigation and bottom-row Guide opening behavior are preserved.
