# Debrid Channels vBRDC177

Marketing version **1.0.880**, build **880**.

Compile-only successor to packaged vBRDC176.

## Fix
Xcode reported `extra argument 'cornerRadius' in call` for `LiveTVGridFocusRingOverlay`. The focus-ring `cornerRadius` was an immutable stored property with an inline default, so Swift excluded it from the overridable memberwise initializer. vBRDC177 makes `cornerRadius` an explicit initializer property so the existing Live TV card supplies its intended 16pt radius.

No Live TV appearance, motion, paging, Guide, catalog, playback, Alternate Audio, Favorites, Sports, or adaptive VOD cache behavior was otherwise changed.
