# vBRDC172 Regression Locks

- Built only from packaged vBRDC171.
- Compile-only correction in PlaybackKit alternate-audio track selection.
- Preserve vBRDC171 Live TV redesign, smooth focus motion, Guide layout, Favorites/runtime cleanup, Sports M3U fixes, adaptive VOD failover/cache behavior, and Alternate Audio runtime logic.
- No UI redesign or unrelated source cleanup in this candidate.
