"""
Debrid Channels backend built-in trailer resolver helper (v1084 proven loading + split-stream audio finalize).

Drop this helper into the backend trailer/remux service. It keeps the v393
cookies + JS runtime + high-quality selector foundation, and hardens the built-in trailer lane so tvOS receives a finalized mux whose
audio track reaches the full video duration before it is cached or published.

Goals:
- treat muxed progressive URLs as inputs and publish/cache only finalized duration-verified outputs
- use yt-dlp with cookies.txt support when YouTube requires auth/session cookies
- allow yt-dlp's JS runtime path when YouTube signature/player extraction needs it
- prefer a progressive 720p/1080p format containing both video and audio
- when only split streams exist, return videoUrl + audioUrl and require backend remux
- never publish/cache a video-only URL as playbackUrl
- pad remuxed audio to the video duration rather than ending at the short audio input
"""

from __future__ import annotations

import json
import os
import subprocess
import time
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional
from urllib.parse import quote_plus


# v395: process-local single-flight guard. yt-dlp searches/extracts are expensive;
# duplicate requests for the same title/year/type should wait for the first job
# and then reuse its cache result instead of launching another yt-dlp process.
_INFLIGHT_LOCK = threading.Lock()
_INFLIGHT_EVENTS: Dict[str, threading.Event] = {}


@dataclass(frozen=True)
class TrailerRuntimeConfig:
    cookies_path: Optional[str] = None
    node_binary: Optional[str] = None
    cache_dir: str = "./trailer-resolve-cache"
    prefer_4k: bool = False
    min_height: int = 720
    max_height: int = 1080
    cache_ttl_seconds: int = 6 * 60 * 60


def _existing_file(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    path = Path(value).expanduser()
    return str(path) if path.exists() and path.is_file() else None


def trailer_cache_key(title: str, year: str = "", media_type: str = "movie") -> str:
    raw = "|".join(part.strip().lower() for part in [title, year, media_type] if part and part.strip())
    return quote_plus(raw or title.strip().lower())


def _cache_file(config: TrailerRuntimeConfig, key: str) -> Path:
    cache_dir = Path(config.cache_dir).expanduser()
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / f"{key}.json"


def _is_complete_playback_payload(payload: Dict[str, Any]) -> bool:
    playback_url = str(payload.get("playbackUrl") or payload.get("url") or "").strip()
    needs_remux = bool(payload.get("needsRemux") or payload.get("needs_remux"))
    duration_verified = payload.get("audioDurationVerified") is True
    has_muxed_audio = bool(
        payload.get("hasMuxedAudio")
        or payload.get("has_muxed_audio")
        or payload.get("audioIncluded")
        or payload.get("audio_included")
    )
    if not playback_url or needs_remux:
        return False
    # v1084 compatibility policy: a progressive extractor format that already
    # contains video and audio is immediately playable and may be cached. Split streams
    # still require the finalized remux path, whose ffprobe verification remains intact.
    # This restores trailer startup without weakening the only path that actually needs
    # audio padding/EOF repair.
    return duration_verified or has_muxed_audio


def build_complete_remux_ffmpeg_args(
    video_url: str,
    audio_url: str,
    output_path: str,
    *,
    video_duration_seconds: float,
) -> list[str]:
    """Build the v1059 remux command that guarantees audio reaches video EOF.

    The backend must obtain ``video_duration_seconds`` with ffprobe first. ``apad``
    extends a shorter audio stream with silence and ``-t`` ends the completed mux at
    the video duration. Do not replace this with ``-shortest``: that would reproduce
    the mid-trailer audio/video truncation when one input reports an early endpoint.
    """
    duration = float(video_duration_seconds)
    if duration <= 0:
        raise ValueError("video_duration_seconds must be positive")
    return [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", video_url,
        "-i", audio_url,
        "-filter_complex",
        f"[1:a:0]aresample=async=1:first_pts=0,apad=whole_dur={duration:.3f}[a]",
        "-map", "0:v:0",
        "-map", "[a]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", f"{duration:.3f}",
        "-avoid_negative_ts", "make_zero",
        "-fflags", "+genpts",
        "-movflags", "+faststart",
        output_path,
    ]


def build_complete_progressive_finalize_ffmpeg_args(
    source_url: str,
    output_path: str,
    *,
    video_duration_seconds: float,
) -> list[str]:
    """Finalize an already-muxed extractor stream into an immutable verified MP4.

    Even progressive YouTube formats are treated as inputs, not final playback URLs.
    Re-encoding audio normalizes timestamp gaps/edit lists, while copying video avoids an
    unnecessary quality loss. The caller must write to a temporary path, ffprobe the closed
    file, then atomically rename it into the public remux-cache directory.
    """
    duration = float(video_duration_seconds)
    if duration <= 0:
        raise ValueError("video_duration_seconds must be positive")
    return [
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
        "-i", source_url,
        "-filter_complex",
        f"[0:a:0]aresample=async=1:first_pts=0,apad=whole_dur={duration:.3f}[a]",
        "-map", "0:v:0",
        "-map", "[a]",
        "-c:v", "copy",
        "-c:a", "aac",
        "-b:a", "192k",
        "-t", f"{duration:.3f}",
        "-avoid_negative_ts", "make_zero",
        "-fflags", "+genpts",
        "-movflags", "+faststart",
        output_path,
    ]


def finalized_remux_payload(
    playback_url: str,
    *,
    video_duration_seconds: float,
    audio_duration_seconds: float,
    tolerance_seconds: float = 1.25,
    extra: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Return a cacheable payload only after ffprobe confirms full-length audio."""
    video_duration = float(video_duration_seconds)
    audio_duration = float(audio_duration_seconds)
    tolerance = max(0.0, float(tolerance_seconds))
    if video_duration <= 0 or audio_duration < video_duration - tolerance:
        raise ValueError("remux audio does not reach the video duration")
    payload: Dict[str, Any] = dict(extra or {})
    payload.update({
        "url": playback_url,
        "playbackUrl": playback_url,
        "needsRemux": False,
        "requireComplete": True,
        "audioDurationVerified": True,
        "finalized": True,
        "atomicFinalize": True,
        "videoDurationSeconds": video_duration,
        "audioDurationSeconds": audio_duration,
        "audioDurationToleranceSeconds": tolerance,
        "remuxPolicy": "pad-audio-to-video-duration",
    })
    return payload

def probe_media_stream_endpoints(
    input_path_or_url: str,
    *,
    ffprobe_binary: str = "ffprobe",
) -> tuple[Optional[float], Optional[float]]:
    """Return first video/audio stream endpoints in seconds when present."""
    command = [
        ffprobe_binary,
        "-v", "error",
        "-show_entries", "stream=codec_type,start_time,duration:format=duration",
        "-of", "json",
        input_path_or_url,
    ]
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    payload = json.loads(result.stdout or "{}")
    video_end: Optional[float] = None
    audio_end: Optional[float] = None
    has_video = False
    has_audio = False
    for stream in payload.get("streams") or []:
        codec_type = str(stream.get("codec_type") or "").lower()
        if codec_type == "video":
            has_video = True
        elif codec_type == "audio":
            has_audio = True
        try:
            start = float(stream.get("start_time") or 0.0)
            duration = float(stream.get("duration") or 0.0)
        except (TypeError, ValueError):
            continue
        endpoint = max(0.0, start + duration)
        if codec_type == "video" and video_end is None and endpoint > 0:
            video_end = endpoint
        elif codec_type == "audio" and audio_end is None and endpoint > 0:
            audio_end = endpoint
    try:
        format_duration = float((payload.get("format") or {}).get("duration") or 0.0)
    except (TypeError, ValueError):
        format_duration = 0.0
    if has_video and video_end is None and format_duration > 0:
        video_end = format_duration
    if has_audio and audio_end is None and format_duration > 0:
        audio_end = format_duration
    return video_end, audio_end


def probe_media_coverage(input_path_or_url: str, *, ffprobe_binary: str = "ffprobe") -> tuple[float, float]:
    """Return video and audio endpoints; require both streams."""
    video_end, audio_end = probe_media_stream_endpoints(input_path_or_url, ffprobe_binary=ffprobe_binary)
    if video_end is None or audio_end is None:
        raise ValueError("finalized trailer must contain both video and audio streams")
    return video_end, audio_end


def finalize_trailer_media(
    *,
    video_url: str,
    output_path: str,
    audio_url: Optional[str] = None,
    ffmpeg_binary: str = "ffmpeg",
    ffprobe_binary: str = "ffprobe",
    tolerance_seconds: float = 1.25,
) -> tuple[float, float]:
    """Create, verify, and atomically publish one complete MP4 trailer.

    This is the integration boundary the backend endpoint should call for both split
    YouTube formats and progressive formats. The public path is never visible until
    FFmpeg has closed the file and ffprobe proves that audio reaches video EOF.
    """
    destination = Path(output_path).expanduser()
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_name(destination.stem + ".part" + destination.suffix)
    partial.unlink(missing_ok=True)

    source_video_end, _ = probe_media_stream_endpoints(video_url, ffprobe_binary=ffprobe_binary)
    if source_video_end is None or source_video_end <= 0:
        raise ValueError("unable to determine trailer video duration")

    if audio_url:
        args = build_complete_remux_ffmpeg_args(
            video_url,
            audio_url,
            str(partial),
            video_duration_seconds=source_video_end,
        )
    else:
        args = build_complete_progressive_finalize_ffmpeg_args(
            video_url,
            str(partial),
            video_duration_seconds=source_video_end,
        )
    args[0] = ffmpeg_binary
    subprocess.run(args, check=True)

    video_end, audio_end = probe_media_coverage(str(partial), ffprobe_binary=ffprobe_binary)
    allowed_gap = max(0.0, float(tolerance_seconds))
    if video_end <= 0 or audio_end < video_end - allowed_gap:
        partial.unlink(missing_ok=True)
        raise ValueError(
            f"finalized trailer audio ends early: video={video_end:.3f}s audio={audio_end:.3f}s"
        )
    os.replace(partial, destination)
    return video_end, audio_end


def read_cached_trailer(config: TrailerRuntimeConfig, key: str) -> Optional[Dict[str, Any]]:
    path = _cache_file(config, key)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    created = float(payload.get("createdAt") or 0)
    if not _is_complete_playback_payload(payload) or time.time() - created > config.cache_ttl_seconds:
        return None
    return payload


def write_cached_trailer(config: TrailerRuntimeConfig, key: str, payload: Dict[str, Any]) -> None:
    # Never persist an unresolved video-only source as a playable cache entry.
    if not _is_complete_playback_payload(payload):
        return
    path = _cache_file(config, key)
    copy = dict(payload)
    copy.setdefault("createdAt", time.time())
    copy.setdefault("playbackUrl", copy.get("url"))
    path.write_text(json.dumps(copy, indent=2, sort_keys=True), encoding="utf-8")


def _height_score(fmt: Dict[str, Any], config: TrailerRuntimeConfig) -> tuple[int, int, int, int]:
    height = int(fmt.get("height") or 0)
    width = int(fmt.get("width") or 0)
    ext = str(fmt.get("ext") or "").lower()
    preferred_height = 2160 if config.prefer_4k else 1080
    quality = -abs(preferred_height - min(height, config.max_height))
    if height < config.min_height:
        quality -= 10_000
    mp4_bonus = 1 if ext in {"mp4", "m4v", "mov"} else 0
    return (mp4_bonus, quality, height, width)


def _has_video(fmt: Dict[str, Any]) -> bool:
    return str(fmt.get("vcodec") or "none").lower() != "none" and int(fmt.get("height") or 0) > 0


def _has_audio(fmt: Dict[str, Any]) -> bool:
    return str(fmt.get("acodec") or "none").lower() != "none"


def select_best_trailer_media(info: Dict[str, Any], config: TrailerRuntimeConfig) -> Optional[Dict[str, Any]]:
    formats = [f for f in info.get("formats", []) if f.get("url")]
    within_limit = [f for f in formats if int(f.get("height") or 0) <= config.max_height or int(f.get("height") or 0) == 0]
    candidates = within_limit or formats

    # Full-audio rule: a muxed format always wins over a higher-resolution video-only format.
    muxed = [f for f in candidates if _has_video(f) and _has_audio(f)]
    if muxed:
        selected = max(muxed, key=lambda fmt: _height_score(fmt, config))
        return {"video": selected, "audio": None, "needsRemux": False}

    videos = [f for f in candidates if _has_video(f)]
    audios = [f for f in formats if not _has_video(f) and _has_audio(f)]
    if videos and audios:
        video = max(videos, key=lambda fmt: _height_score(fmt, config))
        audio = max(audios, key=lambda fmt: (int(fmt.get("abr") or 0), int(fmt.get("tbr") or 0)))
        return {"video": video, "audio": audio, "needsRemux": True}

    # Some extractors expose only the already-selected direct item at the top level.
    direct_url = info.get("url")
    if direct_url and str(info.get("vcodec") or "none").lower() != "none" and str(info.get("acodec") or "none").lower() != "none":
        return {"video": info, "audio": None, "needsRemux": False}
    return None


def select_best_trailer_format(info: Dict[str, Any], config: TrailerRuntimeConfig) -> Optional[Dict[str, Any]]:
    """Compatibility wrapper for older backend integration code."""
    media = select_best_trailer_media(info, config)
    return media.get("video") if media else None


def build_yt_dlp_options(config: TrailerRuntimeConfig) -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "format": (
            f"best[height<={config.max_height}][vcodec!=none][acodec!=none][ext=mp4]/"
            f"best[height<={config.max_height}][vcodec!=none][acodec!=none]/"
            f"bestvideo[height<={config.max_height}]+bestaudio/best"
        ),
    }
    cookies = _existing_file(config.cookies_path)
    if cookies:
        opts["cookiefile"] = cookies
    # yt-dlp can use Node for JS player/signature work when available. Keep this
    # optional so backend installs without Node still start normally.
    if config.node_binary:
        opts["js_runtimes"] = {"node": {"executable": config.node_binary}}
    return opts


def resolve_trailer_with_ytdlp(
    search_or_url: str,
    config: TrailerRuntimeConfig,
    *,
    title: str = "",
    year: str = "",
    media_type: str = "movie",
    reuse_cache: bool = True,
) -> Optional[Dict[str, Any]]:
    """Return selected direct trailer media info. Caller owns remux-cache handling."""
    key = trailer_cache_key(title or search_or_url, year, media_type)
    if reuse_cache:
        cached = read_cached_trailer(config, key)
        if cached:
            cached["cacheHit"] = True
            cached["singleFlightHit"] = False
            return cached

    owner = False
    with _INFLIGHT_LOCK:
        event = _INFLIGHT_EVENTS.get(key)
        if event is None:
            event = threading.Event()
            _INFLIGHT_EVENTS[key] = event
            owner = True

    if not owner:
        # Wait for the active resolver for this exact media key, then read the
        # cache it wrote. This is the critical fix for logs showing repeated
        # `yt-dlp search start` / `extract start` for the same trailer.
        event.wait(timeout=45)
        cached = read_cached_trailer(config, key) if reuse_cache else None
        if cached:
            cached["cacheHit"] = True
            cached["singleFlightHit"] = True
            return cached
        return None

    try:
        from yt_dlp import YoutubeDL  # imported lazily so backend can boot without hard failure in diagnostics

        query = search_or_url if search_or_url.startswith(("http://", "https://", "ytsearch")) else f"ytsearch1:{search_or_url}"
        with YoutubeDL(build_yt_dlp_options(config)) as ydl:
            info = ydl.extract_info(query, download=False)
        if not info:
            return None
        if "entries" in info:
            entries: Iterable[Dict[str, Any]] = (entry for entry in info.get("entries") or [] if entry)
            info = next(iter(entries), None)
            if not info:
                return None
        media = select_best_trailer_media(info, config)
        if not media:
            return None
        selected = media["video"]
        audio = media.get("audio")
        needs_remux = bool(media.get("needsRemux"))
        payload = {
            "title": info.get("title"),
            "webpageUrl": info.get("webpage_url"),
            "formatId": selected.get("format_id"),
            "height": selected.get("height"),
            "ext": selected.get("ext"),
            "url": selected.get("url") if not needs_remux else None,
            "playbackUrl": selected.get("url") if not needs_remux else None,
            "videoUrl": selected.get("url"),
            "audioUrl": audio.get("url") if audio else None,
            "audioFormatId": audio.get("format_id") if audio else None,
            "needsRemux": needs_remux,
            "requireComplete": True,
            # A selected progressive format is already muxed with video and audio.
            # Split formats still require finalized_remux_payload() after FFmpeg/ffprobe.
            "hasMuxedAudio": not needs_remux,
            "audioDurationVerified": False,
            "requiresLocalFinalize": True,
            "verifyAudioEOF": True,
            "atomicFinalize": True,
            "audioDurationToleranceSeconds": 1.25,
            "remuxPolicy": "pad-audio-to-video-duration",
            "cacheHit": False,
            "singleFlightOwner": True,
        }
        # Only a muxed/direct result is playable now. Split inputs must pass through
        # the backend's remux-cache writer and be cached after the file is finalized.
        if _is_complete_playback_payload(payload):
            write_cached_trailer(config, key, payload)
        return payload
    finally:
        with _INFLIGHT_LOCK:
            event = _INFLIGHT_EVENTS.pop(key, None)
            if event is not None:
                event.set()
