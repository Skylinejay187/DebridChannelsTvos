# Debrid Channels vBRDC058 — TorBox API-Key-Only Usenet Discovery + Playback

- Release ID: **vBRDC058**
- Marketing version: **1.0.761**
- Apple build: **761**
- Backend: **v692 unchanged**
- Fresh base: packaged **vBRDC057 only**

## Scope correction

vBRDC057 was an internal experimental candidate that introduced external NZB/indexer credentials. That direction was rejected before release. vBRDC058 is built from that packaged candidate but deliberately rolls those changes back to the vBRDC056 behavior before adding the actual TorBox correction.

There are **no required NzbNest, NZBIndex, Newznab, NZBGeek, DrunkenSlug, altHUB, or other external indexer API-key fields** in vBRDC058. Native TorBox Usenet uses the single TorBox API key already configured in Debrid Channels.

## Physical-device root cause

The Apple TV proved that:

- `api.torbox.app` authentication works.
- the TorBox account is available and the Main Usenet API works.
- local DNS fails specifically for `search-api.torbox.app`, which prevents Voyager from returning NZB candidates.

The Main Usenet API can process/download an NZB, but Source Intelligence still needs the TorBox Search/Voyager result to discover that NZB. The correction therefore targets only the observed DNS failure rather than introducing another paid service or changing unrelated source settings.

## vBRDC058 correction

### 1. Normal TorBox Search remains first

Source Intelligence first performs the same canonical TorBox Voyager request using the existing TorBox API key:

- host: `https://search-api.torbox.app`
- metadata-ID search first, title-text fallback second
- `check_cache=true`
- `check_owned=true`
- `search_user_engines=true`
- `cached_only=false`

A normal successful request is unchanged.

### 2. DNS-over-HTTPS recovery is used only for the observed DNS failure

Only when URLSession reports `cannotFindHost` / `dnsLookupFailed` for `search-api.torbox.app`, Debrid Channels resolves that exact hostname through Cloudflare DNS-over-HTTPS using literal resolver addresses (`1.1.1.1`, then `1.0.0.1`).

The TorBox API key is **never** sent to the DNS resolver. The DoH request contains only the hostname and A-record query.

After DNS recovery, Debrid Channels opens a direct TLS connection to the returned IP while preserving:

- TLS SNI: `search-api.torbox.app`
- HTTP `Host`: `search-api.torbox.app`
- TorBox bearer authentication only inside that end-to-end TLS connection to TorBox

This avoids replacing HTTPS with an insecure IP request and avoids bypassing TorBox certificate validation.

The fallback is hard-restricted to the TorBox Voyager hostname. Authorization errors, rate limits, and other legitimate TorBox HTTP errors are not hidden or converted into DNS fallbacks.

### 3. Usenet rows only appear after real discovery

A TorBox key by itself does not create a fake `TorBox Usenet` provider row. Source Intelligence surfaces TorBox Usenet only after a real search response returns candidates.

### 4. Existing TorBox Main API playback path remains

Selecting a TorBox Usenet candidate continues through the Main API:

1. send the candidate NZB link to `POST /v1/api/usenet/createusenetdownload` using `multipart/form-data`
2. poll `/v1/api/usenet/mylist` until the download is available/finished
3. select the preferred playable video file
4. request the CDN URL with `/v1/api/usenet/requestdl`
5. hand the playable URL to the existing playback path

The TorBox API key stays on-device in the existing credential flow; this build does not introduce a Debrid Channels backend relay for Voyager requests or media data.

## Connection Status remains truthful

Settings continues to define TorBox health from the core services only:

- Main API authentication
- Main Usenet API

A healthy account displays **API + Usenet connected**. Voyager discovery is not a third mandatory health check, so a separate Search API/DNS issue cannot incorrectly turn the account into `Partially connected`.

## Preserved behavior

- Torrentio remains **off by default** and must be explicitly enabled.
- Entering a Real-Debrid or TorBox API key does not auto-enable Torrentio.
- Cached Only / Cached + Uncached controls remain independent of Torrentio.
- CAM / Low Quality filtering remains independent of Torrentio.
- Managed Debridio remains removed; user-saved Stremio manifests continue to work independently.
- Managed Comet remains removed.
- Backend remains v692.
- vBRDC049 playback/Skip Intro stability files are byte-identical to the vBRDC056 package.

## Validation

GitHub Actions/Xcode remains the authoritative full Apple-platform compile. Local release gates completed for this package:

- 60/60 production Swift files parse
- all vBRDC058 static release contracts pass
- synthetic TorBox search → NZB create → ready-file selection → `requestdl` runtime path passes
- release/plist/project version parity passes
- KSP patch Python syntax passes
- KSP fetch shell syntax passes
- locked playback/Skip Intro files are byte-identical to vBRDC056
- final package manifest and ZIP integrity are verified during packaging
