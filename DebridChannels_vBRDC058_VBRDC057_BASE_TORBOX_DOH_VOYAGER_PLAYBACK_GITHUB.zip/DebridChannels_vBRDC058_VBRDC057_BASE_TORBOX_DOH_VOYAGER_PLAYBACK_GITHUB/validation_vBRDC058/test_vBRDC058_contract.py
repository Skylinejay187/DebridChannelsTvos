from pathlib import Path
import plistlib

ROOT=Path(__file__).resolve().parents[1]

def txt(rel): return (ROOT/rel).read_text(errors='replace')
def ok(name, cond):
    if not cond: raise AssertionError(name)
    print('PASS', name)

proj=txt('project.yml')
store=txt('Sources/CatalogStore.swift')
settings=txt('Sources/DebridChannelsTVOSApp.swift')
health=txt('Sources/ConnectedServicesHealthClient.swift')
tb=txt('Sources/TorBoxUsenetClient.swift')
app=plistlib.load(open(ROOT/'Sources/Info.plist','rb'))
top=plistlib.load(open(ROOT/'TopShelfExtension/Info.plist','rb'))

# Release identity
ok('release id', app.get('DebridChannelsReleaseID')=='vBRDC058')
ok('marketing version', app.get('CFBundleShortVersionString')=='1.0.761')
ok('build number', app.get('CFBundleVersion')=='761')
ok('topshelf version parity', top.get('CFBundleShortVersionString')=='1.0.761' and top.get('CFBundleVersion')=='761')
ok('project version parity', 'MARKETING_VERSION: 1.0.761' in proj and 'CURRENT_PROJECT_VERSION: 761' in proj)

# External-indexer experiment removed completely.
ok('no UsenetIndexer source', not (ROOT/'Sources/UsenetIndexerClient.swift').exists())
ok('no UsenetIndexer project entry', 'UsenetIndexerClient.swift' not in proj)
for needle in ['usenetNzbNestAPIKey','usenetNZBIndexAPIKey','usenetCustomNewznabURL','usenetCustomNewznabAPIKey','NzbNest API key','NZBIndex API key']:
    ok(f'no external indexer setting {needle}', needle not in settings and needle not in store and needle not in health and needle not in tb)

# One TorBox key remains authoritative. Torrentio is still opt-in.
ok('TorBox main key remains', '@AppStorage("torBoxApiKey")' in settings)
ok('Torrentio opt-in default false', '@AppStorage("managedTorrentioEnabled") private var managedTorrentioEnabled: Bool = false' in settings)
ok('TorBox Usenet not dependent on Torrentio', 'let torBoxUsenetAllowed = torBoxUsenetKeyAvailable' in store)
ok('TorBox Usenet only surfaced after search success', 'sourceProviderStatus(for: "TorBox Usenet") == nil' in store and 'TorBoxUsenetClient.search' in store)

# Health card must not test Voyager/Search API.
ok('health uses main TorBox API', 'https://api.torbox.app/v1/api/user/me?settings=false' in health)
ok('health uses main Usenet API', 'https://api.torbox.app/v1/api/usenet/mylist?limit=1' in health)
ok('health does not call search-api', 'https://search-api.torbox.app' not in health)
ok('health connected copy', 'API + Usenet connected' in health)

# Native TorBox discovery: same TorBox key, direct Voyager first, DoH fallback only on DNS failure.
ok('Voyager canonical host', 'private static let searchBase = "https://search-api.torbox.app"' in tb)
ok('Voyager bearer uses same TorBox key', 'request.setValue("Bearer \\(apiKey)", forHTTPHeaderField: "Authorization")' in tb)
ok('Voyager requests user engines', 'search_user_engines' in tb and 'cached_only' in tb)
ok('DNS fallback gated to DNS errors', 'guard isDNSResolutionError(error)' in tb)
ok('DoH fallback uses Cloudflare literal resolver', 'let resolvers = ["1.1.1.1", "1.0.0.1"]' in tb)
ok('DoH query carries no TorBox auth header', 'No TorBox token is sent to DoH' in tb)
ok('TLS SNI preserved for Voyager hostname', 'sec_protocol_options_set_tls_server_name' in tb and 'serverName: host' in tb)
ok('HTTP Host preserved for Voyager hostname', '"Host: \\(serverName)\\r\\n"' in tb)
ok('raw fallback restricted to Voyager', 'DNS fallback is restricted to TorBox Voyager.' in tb)

# Main API handoff/playback remains TorBox-owned and no external indexer credential required.
ok('main Usenet API base', 'https://api.torbox.app/v1/api/usenet' in tb)
ok('create NZB download', '/createusenetdownload' in tb and 'multipart/form-data; boundary=' in tb)
ok('poll Usenet list', '/mylist' in tb and 'bypass_cache' in tb)
ok('request playable CDN URL', '/requestdl' in tb and 'usenet_id' in tb and 'file_id' in tb)
ok('video file selection', 'preferredVideoFile' in tb)
ok('cached and uncached timeout paths', 'result.cached ? 120 : 600' in tb)

# No credential/backend proxy shortcut introduced.
ok('no Debrid backend relay for Voyager', 'backend' not in tb.lower() or 'search-api.torbox.app' in tb)
ok('no external NZB key strings in app', all(x not in settings for x in ['Newznab API key','NZB indexer','DrunkenSlug','altHUB']))

print('ALL CONTRACTS PASS')
