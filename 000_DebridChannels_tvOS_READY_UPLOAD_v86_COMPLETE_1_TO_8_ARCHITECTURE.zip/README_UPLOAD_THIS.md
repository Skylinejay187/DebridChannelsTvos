# Debrid Channels tvOS v86 - Complete 1-8 Architecture Pass

Upload this ZIP directly to GitHub. It preserves the v73-approved Home and media detail visual baseline while completing the requested architecture pass as far as the current Swift/tvOS source can support without external compiled codec frameworks.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V86_COMPLETE_1_TO_8_ARCHITECTURE`

Completed scope:
1. Unified focus routing contract for Home, top menu, detail actions, stream chips, More Like This, settings, and player controls.
2. Custom AVPlayerLayer video surface, avoiding SwiftUI VideoPlayer and Apple's stock playback overlay.
3. Custom Debrid VOD overlay with playback controls, progress, panels, loading/error handling, auto-hide, and close routing.
4. Codec strategy boundary: AVFoundation active; libVLC/FFmpeg fallback isolated for future compiled tvOS framework integration.
5. Old laggy/center-heavy background effect removed from active path and replaced with lightweight full-screen cinematic CALayer motion.
6. Back-stack/navigation path retained through CatalogStore detail stack and player close path.
7. Modular files added for app architecture, focus graph, player engine, and v86 completion audit.
8. Cleanup boundary documented; old stock-player paths are not used for active VOD playback.

Important codec truth:
No pure Swift source-only ZIP can honestly provide every codec on Apple TV. Full MKV/DTS/unsupported-codec coverage requires adding real compiled tvOS libVLC/FFmpeg frameworks in a later package. v86 prepares the app boundary for that without lying or breaking the build.
