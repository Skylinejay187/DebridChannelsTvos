# Debrid Channels tvOS/iOS v1110

Base: v1109 only  
Marketing version: 1.0.638  
Build: 638  
Backend: no update required; continue using backend v669

## Focused VOD corrections

### Featured Cast — Cast Banner mode

- The original portrait poster stays at its full 138 × 207 presentation.
- Compact mode no longer places cast inside the poster or reduces the poster itself.
- A separate 58-point cast banner appears directly underneath the poster.
- The banner shows cast portrait, name, role/character, and current position.
- The VOD Settings selector remains Off / Cast Banner / Full Poster.
- Cast rotation remains exactly every 7 seconds and resumes from the player-owned index after the overlay returns.

### Production & Ratings artwork

- Multiple official backdrop/fanart images remain supported.
- Artwork rotates every exactly 7 seconds and resumes from the same index after overlay hide/show.
- Every landscape image uses aspect-fit so the full image is visible without cropping or stretching.
- Language-tagged backdrop artwork is excluded because that TMDB category commonly contains time-sensitive promotional copy such as “10 days” or “coming tomorrow.”
- Language-neutral official backdrops/fanart are preferred and deduplicated.
- The existing title landscape image is used only as a final fallback when no vetted backdrop is available.
- The transparent title logo and deduplicated studio/network logo remain over the artwork.
- Production artwork remains deferred until after confirmed first frame through the existing v1107/v1108 metadata lifecycle.

## Protected systems

No changes were made to catalog/Search source resolution, Source Intelligence, KSPlayer, Alternate Audio, trailers, Live TV, Catalog Health, Favorites, episode alerts, backend routes, or playback handoff behavior.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required.
