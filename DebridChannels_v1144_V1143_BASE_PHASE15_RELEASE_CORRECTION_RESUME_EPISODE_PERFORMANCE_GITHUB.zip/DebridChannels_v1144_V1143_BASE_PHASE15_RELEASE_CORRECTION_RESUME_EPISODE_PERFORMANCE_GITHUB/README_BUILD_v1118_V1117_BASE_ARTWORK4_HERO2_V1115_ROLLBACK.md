# Debrid Channels v1118 — Artwork 4 / Hero 2 v1115 Rollback

Base: v1117 only  
Marketing version: 1.0.646  
Build: 646

## Purpose

Roll back only Artwork 4 / Hero 2 to its exact v1115 app behavior. The v1116 premium multi-provider resolver, deferred blank hero state, seven-day resolver cache, and backend artwork-resolution request are removed.

Artwork 4 / Hero 2 again uses the proven v1115 path:

```swift
CatalogArtworkCacheManager.preferredBackdropURL(for: item)
```

## Preserved

- v1116 long-season horizontal scrolling in both episode pickers
- v1117 unobstructed Production & Ratings banner artwork
- Phase 6 automatic source failover
- Episode date layout
- Featured Cast modes
- Production & Ratings facts and artwork rotation
- Search/catalog source resolution
- KSPlayer, Alternate Audio, trailers, Live TV, Catalog Health, Favorites, and episode alerts

## Backend

No backend update is required. Continue using backend v669.

## Validation

- All 47 Swift files passed syntax parsing.
- App and Top Shelf plists passed validation.
- Project/plist marketing version and build values match.
- Artwork 4 / Hero 2 focused backdrop block is byte-identical to v1115.
- All v1116 resolver symbols and the resolver source/project entry are removed.
- Season scrolling and Production banner corrections remain present.
- Complete v1117 baseline hash comparison and clean archive extraction verification are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before using v1118 as the next phase base.
