# vBRDC356 — Remove obsolete TVVLCKit build dependency

Derived exclusively from uploaded vBRDC355. Removed obsolete TVVLCKit download step, framework search paths, framework embedding/linkage, fetch script and vendor placeholder. Aether/KSPlayer preparation and dependencies are unchanged. Historical #if canImport(TVVLCKit) guarded code remains inactive when the module is unavailable, avoiding unrelated playback code changes.

Local source checks are syntax-only, not a full tvOS build.
