# vBRDC354 — Preview Mirror Top Menu Search + Up Next

Source base: vBRDC353 Preview Mirror Chrome Polish

Included changes:
- Added compact UP NEXT metadata to the top-left Preview Mirror header.
- Moved Search into the revealed Preview Mirror top menu as a magnifying-glass icon.
- Restored the right-hand Preview Mirror clock as a standalone time readout.

Regression intent:
- Preview Mirror mode only.
- Non-Preview-Mirror top navigation and other app surfaces remain unchanged.
