import Foundation
import UIKit
import AVFoundation
import QuartzCore

/// One restrained navigation cue for genuine directional focus changes.
///
/// v1121 corrects the existing v1120 manager in place. It continues to observe
/// UIKit's single process-wide focus notification, but now converts focus items
/// into stable identities, rejects duplicate/programmatic transitions, applies a
/// post-playback restoration guard, and keeps all asset preparation/playback work
/// on one private serial audio queue.
final class NavigationSoundManager: NSObject {
    static let shared = NavigationSoundManager()
    static let enabledDefaultsKey = "navigationSoundEffectsEnabled"

    enum PlaybackContext: Hashable {
        case vodOrLive
        case trailer
    }

    private enum AudioLoadState {
        case unloaded
        case loading
        case ready(AVAudioPlayer)
        case failed
    }

    private var focusObserver: NSObjectProtocol?
    private var playbackSuppressions: Set<PlaybackContext> = []
    private var lastTransitionSignature: String?
    private var lastTransitionAt: CFTimeInterval = 0
    private var lastPlayedAt: CFTimeInterval = 0
    private var focusSilencedUntil: CFTimeInterval = 0

    private let minimumPlaybackInterval: CFTimeInterval = 0.140
    private let duplicateTransitionInterval: CFTimeInterval = 0.180
    private let postPlaybackRestorationSilence: CFTimeInterval = 0.450

    private let audioQueue = DispatchQueue(
        label: "com.channelsdebrid.navigation-sound.audio",
        qos: .userInteractive
    )
    private var audioLoadState: AudioLoadState = .unloaded

    private override init() {
        super.init()
    }

    static var isEnabled: Bool {
        let defaults = UserDefaults.standard
        guard defaults.object(forKey: enabledDefaultsKey) != nil else { return true }
        return defaults.bool(forKey: enabledDefaultsKey)
    }

    @MainActor
    func start() {
        guard focusObserver == nil else { return }
        focusSilencedUntil = CACurrentMediaTime() + 0.350
        preloadAudio()
        focusObserver = NotificationCenter.default.addObserver(
            forName: UIFocusSystem.didUpdateNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            Task { @MainActor in
                self?.handleFocusUpdate(notification)
            }
        }
    }

    /// Existing playback hook, now context-aware so trailer dismissal cannot
    /// accidentally unsuppress an active VOD or Live TV presentation.
    @MainActor
    func setPlaybackSuppressed(
        _ suppressed: Bool,
        context: PlaybackContext = .vodOrLive
    ) {
        let wasSuppressed = !playbackSuppressions.isEmpty
        if suppressed {
            playbackSuppressions.insert(context)
        } else {
            playbackSuppressions.remove(context)
        }

        if suppressed {
            resetFocusFilter(silenceFor: 0)
            stopAudio()
        } else if wasSuppressed && playbackSuppressions.isEmpty {
            resetFocusFilter(silenceFor: postPlaybackRestorationSilence)
        }
    }

    /// The Settings row owns persistence through AppStorage. This hook performs
    /// no additional defaults write and intentionally never previews the sound.
    @MainActor
    func settingDidChange(isEnabled: Bool) {
        resetFocusFilter(silenceFor: 0.250)
        if !isEnabled { stopAudio() }
    }

    @MainActor
    private func handleFocusUpdate(_ notification: Notification) {
        let now = CACurrentMediaTime()
        guard Self.isEnabled,
              playbackSuppressions.isEmpty,
              !VODExclusivePlaybackGate.isActive,
              UIApplication.shared.applicationState == .active,
              now >= focusSilencedUntil,
              let context = notification.userInfo?[UIFocusSystem.focusUpdateContextUserInfoKey] as? UIFocusUpdateContext,
              !context.focusHeading.isEmpty,
              let previousItem = context.previouslyFocusedItem,
              let nextItem = context.nextFocusedItem else { return }

        let previousID = stableFocusIdentity(for: previousItem)
        let nextID = stableFocusIdentity(for: nextItem)
        guard previousID != nextID else { return }

        let signature = previousID + "->" + nextID
        if signature == lastTransitionSignature,
           now - lastTransitionAt < duplicateTransitionInterval {
            return
        }

        lastTransitionSignature = signature
        lastTransitionAt = now

        guard now - lastPlayedAt >= minimumPlaybackInterval else { return }
        lastPlayedAt = now
        playPreparedAudio()
    }

    @MainActor
    private func resetFocusFilter(silenceFor interval: CFTimeInterval) {
        lastTransitionSignature = nil
        lastTransitionAt = 0
        lastPlayedAt = 0
        focusSilencedUntil = CACurrentMediaTime() + interval
    }

    @MainActor
    private func stableFocusIdentity(for item: UIFocusItem) -> String {
        let object = item as AnyObject
        let typeName = String(reflecting: type(of: object))

        if let view = item as? UIView {
            let identifier = normalizedIdentityComponent(view.accessibilityIdentifier)
            let label = normalizedIdentityComponent(view.accessibilityLabel)
            let semantic = identifier.isEmpty ? label : identifier
            let frame = view.window == nil ? view.frame : view.convert(view.bounds, to: nil)
            let geometry = [frame.midX, frame.midY, frame.width, frame.height]
                .map { String(Int(($0 / 4.0).rounded())) }
                .joined(separator: ",")

            if !semantic.isEmpty {
                return "\(typeName)|\(semantic)|\(geometry)"
            }
        }

        let pointer = UInt(bitPattern: Unmanaged.passUnretained(object).toOpaque())
        return "\(typeName)|object:\(String(pointer, radix: 16))"
    }

    private func normalizedIdentityComponent(_ value: String?) -> String {
        guard let value else { return "" }
        let compact = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "|", with: "/")
        return String(compact.prefix(96))
    }

    private func preloadAudio() {
        audioQueue.async { [weak self] in
            self?.prepareAudioOnQueueIfNeeded()
        }
    }

    private func playPreparedAudio() {
        audioQueue.async { [weak self] in
            guard let self else { return }
            self.prepareAudioOnQueueIfNeeded()
            guard case .ready(let player) = self.audioLoadState else { return }
            player.stop()
            player.currentTime = 0
            player.play()
        }
    }

    private func stopAudio() {
        audioQueue.async { [weak self] in
            guard let self,
                  case .ready(let player) = self.audioLoadState else { return }
            player.stop()
            player.currentTime = 0
        }
    }

    /// Runs only on audioQueue. Missing or corrupt assets transition to `.failed`
    /// once, remain silent, and never perform repeated decode attempts on focus.
    private func prepareAudioOnQueueIfNeeded() {
        switch audioLoadState {
        case .ready, .loading, .failed:
            return
        case .unloaded:
            audioLoadState = .loading
        }

        guard let url = Bundle.main.url(
            forResource: "NavigationFocusSoftTick",
            withExtension: "wav"
        ) else {
            audioLoadState = .failed
            return
        }

        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.volume = 0.50
            player.numberOfLoops = 0
            guard player.prepareToPlay() else {
                audioLoadState = .failed
                return
            }
            audioLoadState = .ready(player)
        } catch {
            audioLoadState = .failed
        }
    }
}
