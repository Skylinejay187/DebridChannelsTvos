import SwiftUI
import Foundation
import UserNotifications

struct CastMember: Identifiable, Hashable {
    var id: String { name.lowercased() + "|" + (role ?? "") }
    var name: String
    var role: String? = nil
    var imageURL: String? = nil
}

struct MediaItem: Identifiable, Hashable {
    let id: String
    var tmdbId: String? = nil
    var imdbId: String? = nil
    var tvdbId: String? = nil
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String? = nil
    // v274: Preserve the Stremio JSON add-on identity that supplied this catalog item
    // so UI cards/details can show the corresponding add-on icon/source name.
    var addonName: String? = nil
    var addonIconURL: String? = nil
    var seasonNumber: Int? = nil
    var episodeNumber: Int? = nil
    // v468: Optional credits surfaced in the movie/show popup.
    // These stay app-local and are hydrated from Stremio/Cinemeta metadata when available.
    var cast: [String] = []
    var directors: [String] = []
    // v469: actor face cards for popup cast row. Uses TMDB credits images when available.
    var castMembers: [CastMember] = []
    // v607: Optional episode air/release date used for next-up alerts.
    var airDateString: String? = nil
    var episodeDateStrings: [String] = []
    // v616: movie-only collection/franchise shelf. Empty unless TMDB confirms a real belongs_to_collection result.
    var franchiseItems: [MediaItem] = []
}

struct NewEpisodeAlertHit: Identifiable, Hashable {
    var id: String { alertKey }
    let alertKey: String
    let show: MediaItem
    let episode: MediaItem
}

struct NewEpisodeAlertScanReport: Equatable {
    var recentWindowDays: Int = 7
    var periodicScannerEnabled: Bool = false
    var scanIntervalMinutes: Int = 0
    var scanFrequencyTestMode: Bool = false
    var selectedScanFrequencyRawValue: String = "10"
    var selectedScanFrequencySeconds: Int = 600
    var activeHeartbeatIntervalSeconds: Int = 0
    var heartbeatTaskActive: Bool = false
    var heartbeatGeneration: Int = 0
    var lastHeartbeatFiredTime: String = "None"
    var nextScheduledScanTime: String = "None"
    var lastScanReason: String = "None"
    var duplicateHeartbeatPreventedCount: Int = 0
    var bannerSideSetting: String = "Right"
    var alertStyleSetting: String = "Banner"
    var alertThemeSetting: String = "Glass"
    var bannerDurationSeconds: Int = 15
    var lastScanTime: String = "None"
    var nextScanEstimate: String = "None"
    var scanAlreadyRunning: Bool = false
    var followedKeysCount: Int = 0
    var followedShowsMatchedInLoadedRows: Int = 0
    var showsChecked: Int = 0
    var metadataFetchAttempted: Bool = false
    var metadataFetchSuccessCount: Int = 0
    var episodesFetchedCount: Int = 0
    var newerTodayEpisodeDetected: Bool = false
    var newestEligibleEpisodeDate: String = "None"
    var recentEpisodeDetected: Bool = false
    var newestRawDateStringSeen: String = "None"
    var newestParsedDate: String = "None"
    var missingDateCount: Int = 0
    var dateParseSuccessCount: Int = 0
    var dateParseFailedCount: Int = 0
    var eligibleButConsumedCount: Int = 0
    var suppressedDuplicateCount: Int = 0
    var alreadyAlertedCount: Int = 0
    var suppressedSameEpisodeCount: Int = 0
    var newestDetectedEpisodeKey: String = "None"
    var lastAlertedEpisodeKeyForShow: String = "None"
    var alertQueuedCount: Int = 0
    var returnedAlertHits: Int = 0
    var alertDisplayed: Bool = false
    var displayedThisCycleCount: Int = 0
    var remainingQueueCount: Int = 0
    var hitSourceSummaries: [String] = []
    var hits: [NewEpisodeAlertHit] = []
}

private struct FollowedShowSnapshot: Codable {
    var id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String?
    var addonName: String?
    var addonIconURL: String?
    var tmdbId: String?
    var imdbId: String?
    var tvdbId: String?

    init(item: MediaItem) {
        id = item.id
        tmdbId = item.tmdbId
        imdbId = item.imdbId
        tvdbId = item.tvdbId
        title = item.title
        year = item.year
        type = item.type
        catalog = item.catalog
        description = item.description
        genres = item.genres
        rating = item.rating
        posterURL = item.posterURL
        landscapeURL = item.landscapeURL
        logoURL = item.logoURL
        previewURL = item.previewURL
        addonName = item.addonName
        addonIconURL = item.addonIconURL
    }

    var mediaItem: MediaItem {
        MediaItem(
            id: id,
            tmdbId: tmdbId,
            imdbId: imdbId,
            tvdbId: tvdbId,
            title: title,
            year: year,
            type: type,
            catalog: catalog,
            description: description,
            genres: genres,
            rating: rating,
            posterURL: posterURL,
            landscapeURL: landscapeURL,
            logoURL: logoURL,
            previewURL: previewURL,
            addonName: addonName,
            addonIconURL: addonIconURL
        )
    }
}


private struct FanartTVImage: Decodable, Hashable {
    var url: String?
    var lang: String?
    var likes: String?

    var likeScore: Int { Int(likes ?? "0") ?? 0 }
}

private struct FanartMovieResponse: Decodable {
    var hdmovielogo: [FanartTVImage]?
    var movielogo: [FanartTVImage]?
    var moviebackground: [FanartTVImage]?
    var movieposter: [FanartTVImage]?
}

private struct FanartTVResponse: Decodable {
    var hdtvlogo: [FanartTVImage]?
    var clearlogo: [FanartTVImage]?
    var showbackground: [FanartTVImage]?
    var tvposter: [FanartTVImage]?
}

private struct TMDBExternalIDsResponse: Decodable {
    var imdb_id: String?
    var tvdb_id: Int?
}

private struct PremiumFanartArtwork: Hashable {
    var backdropURL: String? = nil
    var logoURL: String? = nil
    var posterURL: String? = nil

    var hasAny: Bool { backdropURL != nil || logoURL != nil || posterURL != nil }
}

private struct TMDBMultiSearchResponse: Decodable {
    var results: [TMDBSearchResult]
}

private struct TMDBSearchResult: Decodable {
    var id: Int
    var media_type: String?
    var title: String?
    var name: String?
    var overview: String?
    var release_date: String?
    var first_air_date: String?
    var poster_path: String?
    var backdrop_path: String?
    var vote_average: Double?
}

private struct TMDBListResponse: Decodable {
    var results: [TMDBListItem]
}

private struct TMDBCreditsResponse: Decodable {
    var cast: [TMDBCreditCastMember]?
    var crew: [TMDBCreditCrewMember]?
}

private struct TMDBCreditCastMember: Decodable {
    var name: String?
    var character: String?
    var profile_path: String?
}

private struct TMDBCreditCrewMember: Decodable {
    var name: String?
    var job: String?
}

private struct TMDBFindResponse: Decodable {
    var movie_results: [TMDBFindResult]?
    var tv_results: [TMDBFindResult]?
}

private struct TMDBFindResult: Decodable {
    var id: Int?
}

private struct TMDBListItem: Decodable {
    var id: Int
    var title: String?
    var name: String?
    var overview: String?
    var release_date: String?
    var first_air_date: String?
    var poster_path: String?
    var backdrop_path: String?
    var vote_average: Double?
}

private struct TMDBMovieCollectionLink: Decodable {
    var id: Int?
    var name: String?
}

private struct TMDBMovieDetailWithCollection: Decodable {
    var belongs_to_collection: TMDBMovieCollectionLink?
}

private struct TMDBCollectionResponse: Decodable {
    var id: Int?
    var name: String?
    var parts: [TMDBListItem]?
}

private struct TMDBMovieImagesResponse: Decodable {
    var logos: [TMDBLogoImage]?
}

private struct TMDBLogoImage: Decodable {
    var file_path: String?
    var iso_639_1: String?
    var vote_average: Double?
    var vote_count: Int?
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StremioAddonIdentity: Hashable {
    var name: String
    var iconURL: String?
    var kind: String
}

enum SourceProviderRequestState: String, Hashable {
    case searching
    case returnedLinks
    case noLinks
    case failed
    case timeout
}

struct SourceProviderRequestStatus: Identifiable, Hashable {
    var id: String { provider }
    var provider: String
    var state: SourceProviderRequestState
    var linkCount: Int
    var message: String
}

struct StreamLink: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String?
    var quality: String
    var size: String
    var source: String
    var infoHash: String? = nil
    var fileIndex: Int? = nil
    var subtitleURLs: [String] = []
    var isExternalURL: Bool = false

    var isDirectPlayable: Bool {
        guard let url else { return false }
        if isExternalURL { return false }
        guard let components = URLComponents(string: url), let scheme = components.scheme?.lowercased(), scheme == "http" || scheme == "https" else { return false }
        let lower = url.lowercased()
        // v92: Debrid providers such as TorBox/Real-Debrid often return signed CDN URLs with no file extension.
        // Treat HTTP(S) stream.url as playable unless it is clearly a webpage/configuration/deep-link.
        if lower.hasPrefix("stremio://") || lower.hasPrefix("magnet:") { return false }
        if lower.contains("/configure") || lower.contains("youtube.com") || lower.contains("youtu.be") { return false }
        if lower.contains("/manifest.json") || lower.contains("/catalog/") || lower.contains("/meta/") { return false }
        if lower.contains("imdb.com/title") || lower.contains("themoviedb.org") { return false }
        return true
    }
}



struct LastPlaybackLinkEntry: Codable, Hashable {
    var key: String
    var url: String
    var title: String
    var quality: String
    var size: String
    var source: String
    var updatedAt: Date
}

final class LastPlaybackLinkCacheManager {
    static let shared = LastPlaybackLinkCacheManager()
    private let storageKey = "DebridChannels.v620.lastPlaybackLinks"
    private let maxEntries = 220
    private init() {}

    func entry(for item: MediaItem) -> LastPlaybackLinkEntry? {
        allEntries()[PlaybackResumeCacheManager.shared.playbackKey(for: item)]
    }

    func save(item: MediaItem, link: StreamLink, url: URL) {
        let key = PlaybackResumeCacheManager.shared.playbackKey(for: item)
        var entries = allEntries()
        entries[key] = LastPlaybackLinkEntry(
            key: key,
            url: url.absoluteString,
            title: link.title,
            quality: link.quality,
            size: link.size,
            source: link.source,
            updatedAt: Date()
        )
        if entries.count > maxEntries {
            let keep = entries.values.sorted { $0.updatedAt > $1.updatedAt }.prefix(maxEntries)
            entries = Dictionary(uniqueKeysWithValues: keep.map { ($0.key, $0) })
        }
        write(entries)
    }

    private func allEntries() -> [String: LastPlaybackLinkEntry] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([String: LastPlaybackLinkEntry].self, from: data) else { return [:] }
        return decoded
    }

    private func write(_ entries: [String: LastPlaybackLinkEntry]) {
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: storageKey) }
    }
}

struct AlternateAudioSource: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String
    var quality: String
    var source: String
    var confidence: String

    var displayTitle: String {
        let cleanQuality = quality.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanSource = source.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleanQuality.isEmpty { return "\(title) • \(cleanSource)" }
        return "\(title) • \(cleanQuality) • \(cleanSource)"
    }
}

struct StremioStreamResponse: Decodable {
    var streams: [StremioStream]?
}

struct StremioStream: Decodable {
    var title: String?
    var name: String?
    var url: String?
    var infoHash: String?
    var externalUrl: String?
    var fileIdx: Int?
    var behaviorHints: StremioBehaviorHints?
    var subtitles: [StremioSubtitle]?
}

struct StremioSubtitle: Decodable, Hashable {
    var id: String?
    var url: String?
    var lang: String?
    var language: String?
    var label: String?
}

struct StremioBehaviorHints: Decodable {
    var filename: String?
    var videoSize: Int64?
    var videoHash: String?
    var bingeGroup: String?
}

struct StremioManifest: Decodable {
    var name: String?
    var logo: String?
    var icon: String?
    var catalogs: [StremioCatalog]?
    var resources: [StremioResource]?
    var types: [String]?
    var idPrefixes: [String]?
}

struct StremioResource: Decodable, Hashable {
    var name: String?
    var types: [String]?
    var idPrefixes: [String]?

    enum CodingKeys: String, CodingKey {
        case name
        case types
        case idPrefixes
    }

    init(name: String? = nil, types: [String]? = nil, idPrefixes: [String]? = nil) {
        self.name = name
        self.types = types
        self.idPrefixes = idPrefixes
    }

    // Stremio manifests legally expose resources as either strings:
    //   "resources": ["catalog", "meta", "stream", "subtitles"]
    // or objects:
    //   { "name": "stream", "types": ["movie", "series"] }
    // The old decoder only accepted object form, which could break whole addon/catalog loading.
    init(from decoder: Decoder) throws {
        let single = try decoder.singleValueContainer()
        if let value = try? single.decode(String.self) {
            name = value
            types = nil
            idPrefixes = nil
            return
        }
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        types = try container.decodeIfPresent([String].self, forKey: .types)
        idPrefixes = try container.decodeIfPresent([String].self, forKey: .idPrefixes)
    }
}

struct StremioExtra: Decodable, Hashable {
    var name: String?
    var isRequired: Bool?
    var options: [String]?

    enum CodingKeys: String, CodingKey {
        case name
        case isRequired = "isRequired"
        case options
    }

    init(name: String? = nil, isRequired: Bool? = nil, options: [String]? = nil) {
        self.name = name
        self.isRequired = isRequired
        self.options = options
    }

    // Real Stremio addons do not all encode extras perfectly. Some send option values as
    // numbers/bools/nulls instead of strings. A strict decoder made the whole manifest fail.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        isRequired = try container.decodeIfPresent(Bool.self, forKey: .isRequired)
        if let strings = try? container.decodeIfPresent([String].self, forKey: .options) {
            options = strings
        } else if let values = try? container.decodeIfPresent([LossyJSONValue].self, forKey: .options) {
            options = values.compactMap { $0.stringValue }
        } else {
            options = nil
        }
    }
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
    var extra: [StremioExtra]?
    var extraSupported: [String]?
    var extraRequired: [String]?
}

struct StremioMetaResponse: Decodable {
    var meta: StremioMeta?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?

    enum CodingKeys: String, CodingKey { case metas }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        // Decode metas one by one so a single unusual Stremio item cannot break the whole catalog.
        if var nested = try? container.nestedUnkeyedContainer(forKey: .metas) {
            var decoded: [StremioMeta] = []
            while !nested.isAtEnd {
                if let meta = try? nested.decode(StremioMeta.self) {
                    decoded.append(meta)
                } else {
                    _ = try? nested.decode(LossySkipValue.self)
                }
            }
            metas = decoded
        } else {
            metas = nil
        }
    }
}

struct LossySkipValue: Decodable {}

struct StremioTrailer: Decodable {
    var source: String?
    var type: String?
    var title: String?
}

struct StremioVideo: Decodable {
    var id: String?
    var name: String?
    var url: String?
    var src: String?
    var source: String?
    var type: String?
    var title: String?
    var season: Int?
    var episode: Int?
    var overview: String?
    var description: String?
    var released: String?
    var firstAired: String?
    var airDate: String?
    var premiereDate: String?
    var release_date: String?
    var air_date: String?
    var first_aired: String?
    var thumbnail: String?
    var additionalEpisodeDateStrings: [String] = []

    enum CodingKeys: String, CodingKey {
        case id, name, url, src, source, type, title, season, episode, overview, description
        case released, firstAired, airDate, premiereDate, release_date, air_date, first_aired, thumbnail
        case behaviorHints, metadata, meta, additional, raw
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = Self.decodeString(container, .id)
        name = Self.decodeString(container, .name)
        url = Self.decodeString(container, .url)
        src = Self.decodeString(container, .src)
        source = Self.decodeString(container, .source)
        type = Self.decodeString(container, .type)
        title = Self.decodeString(container, .title)
        season = Self.decodeInt(container, .season)
        episode = Self.decodeInt(container, .episode)
        overview = Self.decodeString(container, .overview)
        description = Self.decodeString(container, .description)
        released = Self.decodeString(container, .released)
        firstAired = Self.decodeString(container, .firstAired)
        airDate = Self.decodeString(container, .airDate)
        premiereDate = Self.decodeString(container, .premiereDate)
        release_date = Self.decodeString(container, .release_date)
        air_date = Self.decodeString(container, .air_date)
        first_aired = Self.decodeString(container, .first_aired)
        thumbnail = Self.decodeString(container, .thumbnail)

        let nestedKeys: [CodingKeys] = [.behaviorHints, .metadata, .meta, .additional, .raw]
        additionalEpisodeDateStrings = nestedKeys.flatMap { Self.decodeNestedEpisodeDateStrings(container, $0) }
    }

    private static func decodeString(_ container: KeyedDecodingContainer<CodingKeys>, _ key: CodingKeys) -> String? {
        if let value = try? container.decodeIfPresent(String.self, forKey: key) { return value }
        if let value = try? container.decodeIfPresent(Int.self, forKey: key) { return String(value) }
        if let value = try? container.decodeIfPresent(Double.self, forKey: key) {
            if value.rounded() == value { return String(Int(value)) }
            return String(value)
        }
        if let value = try? container.decodeIfPresent(Bool.self, forKey: key) { return String(value) }
        return nil
    }

    private static func decodeInt(_ container: KeyedDecodingContainer<CodingKeys>, _ key: CodingKeys) -> Int? {
        if let value = try? container.decodeIfPresent(Int.self, forKey: key) { return value }
        if let value = try? container.decodeIfPresent(String.self, forKey: key) { return Int(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    private static func decodeNestedEpisodeDateStrings(_ container: KeyedDecodingContainer<CodingKeys>, _ key: CodingKeys) -> [String] {
        guard let values = try? container.decodeIfPresent([String: LossyJSONValue].self, forKey: key) else { return [] }
        let dateKeys = ["released", "release_date", "air_date", "firstAired", "first_aired", "premiereDate"]
        return dateKeys.compactMap { values[$0]?.stringValue?.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    }
}

enum LossyJSONValue: Decodable, Hashable {
    case string(String)
    case int(Int)
    case double(Double)
    case bool(Bool)
    case null

    var stringValue: String? {
        switch self {
        case .string(let value): return value
        case .int(let value): return String(value)
        case .double(let value):
            if value.rounded() == value { return String(Int(value)) }
            return String(value)
        case .bool(let value): return String(value)
        case .null: return nil
        }
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() { self = .null; return }
        if let value = try? container.decode(String.self) { self = .string(value); return }
        if let value = try? container.decode(Int.self) { self = .int(value); return }
        if let value = try? container.decode(Double.self) { self = .double(value); return }
        if let value = try? container.decode(Bool.self) { self = .bool(value); return }
        self = .null
    }
}

struct StremioMeta: Decodable {
    var id: String?
    var tmdbId: String?
    var imdbId: String?
    var tvdbId: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
    var trailers: [StremioTrailer]?
    var videos: [StremioVideo]?
    var trailer: String?
    var preview: String?
    var previewVideo: String?
    var cast: [String]?
    var directors: [String]?

    enum CodingKeys: String, CodingKey {
        case id, tmdbId, tmdb_id, imdbId, imdb_id, tvdbId, tvdb_id, name, type, poster, background, logo, description, releaseInfo, genres, imdbRating, trailers, videos, trailer, preview, previewVideo
        case cast, director, directors, credits
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = StremioMeta.decodeString(container, .id)
        tmdbId = StremioMeta.decodeString(container, .tmdbId) ?? StremioMeta.decodeString(container, .tmdb_id)
        imdbId = StremioMeta.decodeString(container, .imdbId) ?? StremioMeta.decodeString(container, .imdb_id)
        tvdbId = StremioMeta.decodeString(container, .tvdbId) ?? StremioMeta.decodeString(container, .tvdb_id)
        name = StremioMeta.decodeString(container, .name)
        type = StremioMeta.decodeString(container, .type)
        poster = StremioMeta.decodeString(container, .poster)
        background = StremioMeta.decodeString(container, .background)
        logo = StremioMeta.decodeString(container, .logo)
        description = StremioMeta.decodeString(container, .description)
        releaseInfo = StremioMeta.decodeString(container, .releaseInfo)
        imdbRating = StremioMeta.decodeString(container, .imdbRating)
        trailer = StremioMeta.decodeString(container, .trailer)
        preview = StremioMeta.decodeString(container, .preview)
        previewVideo = StremioMeta.decodeString(container, .previewVideo)

        if let castArray = try? container.decodeIfPresent([String].self, forKey: .cast) {
            cast = castArray
        } else if let castString = StremioMeta.decodeString(container, .cast) {
            cast = castString.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        } else {
            cast = nil
        }

        if let directorArray = try? container.decodeIfPresent([String].self, forKey: .directors) {
            directors = directorArray
        } else if let directorString = StremioMeta.decodeString(container, .director) ?? StremioMeta.decodeString(container, .directors) {
            directors = directorString.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        } else {
            directors = nil
        }

        if let genreArray = try? container.decodeIfPresent([String].self, forKey: .genres) {
            genres = genreArray
        } else if let singleGenre = try? container.decodeIfPresent(String.self, forKey: .genres) {
            genres = [singleGenre]
        } else if let mixedGenres = try? container.decodeIfPresent([LossyJSONValue].self, forKey: .genres) {
            genres = mixedGenres.compactMap { $0.stringValue }
        } else {
            genres = nil
        }

        // Trailer/video objects vary by addon. Do not let optional media decorations break the whole catalog row.
        trailers = (try? container.decodeIfPresent([StremioTrailer].self, forKey: .trailers)) ?? nil
        videos = (try? container.decodeIfPresent([StremioVideo].self, forKey: .videos)) ?? nil
    }

    private static func decodeString(_ container: KeyedDecodingContainer<CodingKeys>, _ key: CodingKeys) -> String? {
        if let value = try? container.decodeIfPresent(String.self, forKey: key) { return value }
        if let value = try? container.decodeIfPresent(Int.self, forKey: key) { return String(value) }
        if let value = try? container.decodeIfPresent(Double.self, forKey: key) {
            if value.rounded() == value { return String(Int(value)) }
            return String(value)
        }
        if let value = try? container.decodeIfPresent(Bool.self, forKey: key) { return String(value) }
        return nil
    }
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case sports = "Sports"
    case favorites = "Favorites"
    case live = "Live TV"
    case membership = "Membership"
    case settings = "Settings"
    var id: String { rawValue }
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var selectedTab: AppTab = .live
    @Published var status: String = "Build v503: instant search popup open, advisory no-white-card fix, trailer work deferred until requested."
    @Published var addonIdentities: [String: StremioAddonIdentity] = [:]
    @Published var menuFocusToken: Int = 0
    @Published var contentFocusToken: Int = 0
    @Published var topMenuFocusLocked: Bool = false
    @Published var liveQuickPanelOpen: Bool = false
    @Published var isLoading: Bool = false
    @Published var manifestURLs: [String] = []
    @Published var selectedDetail: MediaItem? = nil
    @Published var playbackURL: URL? = nil
    @Published var playbackItem: MediaItem? = nil
    @Published var playbackFallbackURLs: [URL] = []
    @Published var playbackSubtitleURLs: [URL] = []
    @Published var playbackLinkLabel: String = ""
    @Published var playbackSourceTrackSummary: RealMediaTrackSummary? = nil
    @Published var streamLinks: [StreamLink] = []
    @Published var selectedSourceProvider: String = "All Providers"
    @Published var sourceProviderStatuses: [SourceProviderRequestStatus] = []
    @Published var alternateAudioSources: [AlternateAudioSource] = []
    @Published var selectedAlternateAudioSource: AlternateAudioSource? = nil
    @Published var alternateAudioSyncOffsetMS: Int = 0
    @Published var lastStreamMessage: String = ""

    // v462: Track which detail item owns the current link-search results.
    // This prevents Movie A / Show A links from staying visible after the user
    // opens Movie B / Show B, and also blocks older async searches from
    // writing stale links back into the picker after navigation.
    private var activeStreamSearchItemID: String? = nil
    private var detailCreditsTask: Task<Void, Never>? = nil
    @Published var resolvedTrailerAudioURL: URL? = nil
    @Published var detailBackStack: [MediaItem] = []
    // v616: exact quick-panel focus restoration after closing Details Stage.
    @Published var quickPanelRestoreItemID: String? = nil
    @Published var quickPanelRestoreRowID: String? = nil
    @Published var quickPanelRestoreRowIndex: Int = 0
    @Published var quickPanelRestoreItemIndex: Int = 0
    @Published var searchActive: Bool = false
    @Published var onboardingTourActive: Bool = false
    @Published var onboardingForceFullGuide: Bool = false

    private let manifestsKey = "stremioManifestURLs"
    private let coreMetadataManifestURL = "https://v3-cinemeta.strem.io/manifest.json"
    private let trailerResolveCacheKey = "resolvedTrailerPlaybackURLCache.v426.fullks.trailer.restore"
    private let followedShowSnapshotsKey = "followedShowSnapshots.v659"
    private var trailerResolveMemoryCache: [String: String] = [:]
    private var trailerResolveInflightTasks: [String: Task<URL?, Never>] = [:]
    private var catalogRowRefreshDebounceTasks: [String: Task<Void, Never>] = [:]
    private var catalogRowRefreshLastAttempt: [String: Date] = [:]
    private var catalogRowRefreshInFlight = Set<String>()
    private let catalogRowRefreshCooldown: TimeInterval = 95
    private let catalogRowRefreshMaxConcurrent = 2

    init() {
        trailerResolveMemoryCache = UserDefaults.standard.dictionary(forKey: trailerResolveCacheKey) as? [String: String] ?? [:]
        let saved = UserDefaults.standard.stringArray(forKey: manifestsKey) ?? []
        if saved.isEmpty {
            manifestURLs = [coreMetadataManifestURL]
        } else {
            // v465: Preserve the exact user-saved priority order. Cinemeta remains available
            // as a fallback when missing, but it is no longer forcibly inserted above
            // user-selected catalogs.
            manifestURLs = dedupedManifestURLs(saved)
            UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        }
    }


    func searchResults(for query: String) -> [MediaItem] {
        // v467: Search must respect the final user catalog priority order even if
        // rows were originally loaded before the user moved a JSON catalog above
        // Cinemeta. The display layer is the last authority.
        let all = prioritizedRowsForDisplay().flatMap { $0.items }
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return []
        }
        let q = trimmed.lowercased()
        var seen = Set<String>()
        let matches = all.filter { item in
            let haystack = [item.title, item.year, item.type, item.catalog, item.description, item.rating] + item.genres
            return haystack.joined(separator: " ").lowercased().contains(q)
        }
        return matches.filter { seen.insert($0.id).inserted }.prefix(40).map { $0 }
    }


    // v470: Universal Search must actively query every configured Stremio/catalog addon,
    // not only the rows already loaded on Home. TMDB is metadata-only and should never
    // become the only playable identity shown in Search.
    func searchConfiguredCatalogAddons(for query: String) async -> [MediaItem] {
        await searchConfiguredCatalogAddons(for: query, limitToCinemeta: false)
    }

    func searchCinemetaCatalog(for query: String) async -> [MediaItem] {
        await searchConfiguredCatalogAddons(for: query, limitToCinemeta: true)
    }

    private func searchConfiguredCatalogAddons(for query: String, limitToCinemeta: Bool) async -> [MediaItem] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2 else { return [] }

        let urlSession = URLSession.shared
        var results: [MediaItem] = []
        var seen = Set<String>()

        for rawManifest in prioritizedManifestURLsWithMetadataFallback() {
            if limitToCinemeta && !rawManifest.lowercased().contains("cinemeta") { continue }
            let manifestCandidates = manifestURLCandidates(from: rawManifest)
            var manifestDecoded: StremioManifest? = nil
            var workingManifestURL: URL? = nil

            for candidate in manifestCandidates {
                guard let candidateURL = URL(string: candidate) else { continue }
                do {
                    let manifestTimeout: TimeInterval = rawManifest.lowercased().contains("mediafusion") ? 18 : 9
                    var manifestRequest = URLRequest(url: candidateURL, timeoutInterval: manifestTimeout)
                    manifestRequest.setValue("application/json", forHTTPHeaderField: "Accept")
                    manifestRequest.setValue("DebridChannels-tvOS/576 FastExact", forHTTPHeaderField: "User-Agent")
                    let (data, response) = try await urlSession.data(for: manifestRequest)
                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    let decoded = try JSONDecoder().decode(StremioManifest.self, from: data)
                    manifestDecoded = decoded
                    workingManifestURL = candidateURL
                    let identityName = decoded.name ?? candidateURL.host ?? "Stremio"
                    let identityIcon = Self.highest(decoded.logo ?? decoded.icon)
                    await MainActor.run {
                        self.addonIdentities[rawManifest] = StremioAddonIdentity(name: identityName, iconURL: identityIcon, kind: self.addonKind(from: decoded))
                    }
                    break
                } catch {
                    continue
                }
            }

            guard let manifest = manifestDecoded, let manifestURL = workingManifestURL else { continue }
            let catalogs = manifest.catalogs ?? []
            guard !catalogs.isEmpty else { continue }
            let base = URL(string: normalizedStremioBase(from: manifestURL.absoluteString)) ?? manifestURL.deletingLastPathComponent()
            let addonName = manifest.name ?? manifestURL.host ?? "Stremio"
            let addonIconURL = Self.highest(manifest.logo ?? manifest.icon)

            for catalog in catalogs {
                let type = catalog.type ?? "movie"
                guard type.lowercased().contains("movie") || type.lowercased().contains("series") || type.lowercased().contains("tv") else { continue }
                for searchURL in catalogSearchEndpointCandidates(base: base, catalog: catalog, query: trimmed) {
                    do {
                        let (data, response) = try await urlSession.data(from: searchURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(CatalogResponse.self, from: data)
                        let metas = decoded.metas ?? []
                        for meta in metas {
                            guard let id = meta.id?.trimmingCharacters(in: .whitespacesAndNewlines), !id.isEmpty else { continue }
                            let title = (meta.name ?? "Untitled").trimmingCharacters(in: .whitespacesAndNewlines)
                            guard !title.isEmpty else { continue }
                            let queryKey = normalizedMatchText(trimmed)
                            let titleKey = normalizedMatchText(title)
                            let descKey = normalizedMatchText(meta.description ?? "")
                            let catalogKey = normalizedMatchText("\(catalog.name ?? "") \(catalog.id ?? "") \(addonName)")
                            guard titleKey.contains(queryKey) || descKey.contains(queryKey) || catalogKey.contains(queryKey) else { continue }
                            let uniqueKey = "\(addonName.lowercased())|\(catalog.name ?? catalog.id ?? "catalog")|\(id)"
                            guard !seen.contains(uniqueKey) else { continue }
                            seen.insert(uniqueKey)
                            results.append(MediaItem(
                                id: id,
                                tmdbId: meta.tmdbId,
                                imdbId: meta.imdbId,
                                tvdbId: meta.tvdbId,
                                title: title,
                                year: Self.firstYear(from: meta.releaseInfo),
                                type: meta.type ?? type,
                                catalog: catalog.name ?? catalog.id ?? addonName,
                                description: meta.description ?? "No description available yet.",
                                genres: Array((meta.genres ?? [type.capitalized]).prefix(3)),
                                rating: meta.imdbRating ?? "—",
                                posterURL: Self.highest(meta.poster),
                                landscapeURL: Self.highest(meta.background ?? meta.poster),
                                logoURL: Self.highest(meta.logo),
                                previewURL: Self.previewURL(from: meta),
                                addonName: addonName,
                                addonIconURL: addonIconURL,
                                seasonNumber: nil,
                                episodeNumber: nil,
                                cast: Array((meta.cast ?? []).prefix(8)),
                                directors: Array((meta.directors ?? []).prefix(3))
                            ))
                        }
                        if !metas.isEmpty { break }
                    } catch {
                        continue
                    }
                }
            }
        }

        return Array(results.prefix(120))
    }

    private func addonCatalogSearchMatch(for item: MediaItem, fallbackQuery: String) async -> MediaItem? {
        let query = item.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? fallbackQuery : item.title
        let matches = await searchConfiguredCatalogAddons(for: query)
        let targetTitle = normalizedMatchText(item.title)
        let targetYear = item.year.filter { $0.isNumber }
        let targetType = normalizedStremioType(item.type)
        let ranked = matches.sorted { lhs, rhs in
            let lhsExact = normalizedMatchText(lhs.title) == targetTitle
            let rhsExact = normalizedMatchText(rhs.title) == targetTitle
            if lhsExact != rhsExact { return lhsExact && !rhsExact }
            let lhsType = normalizedStremioType(lhs.type) == targetType
            let rhsType = normalizedStremioType(rhs.type) == targetType
            if lhsType != rhsType { return lhsType && !rhsType }
            let lhsYear = lhs.year.filter { $0.isNumber } == targetYear
            let rhsYear = rhs.year.filter { $0.isNumber } == targetYear
            if !targetYear.isEmpty && lhsYear != rhsYear { return lhsYear && !rhsYear }
            return lhs.title < rhs.title
        }
        return ranked.first { candidate in
            let candidateTitle = normalizedMatchText(candidate.title)
            let titleOK = targetTitle.isEmpty || candidateTitle == targetTitle || candidateTitle.contains(targetTitle) || targetTitle.contains(candidateTitle)
            let typeOK = normalizedStremioType(candidate.type) == targetType
            let candidateYear = candidate.year.filter { $0.isNumber }
            let yearOK = targetYear.isEmpty || candidateYear.isEmpty || candidateYear == targetYear
            return titleOK && typeOK && yearOK
        }
    }


    // v393: Universal Search cards can be lightweight TMDB/search objects. Before opening
    // Details from Search, hydrate them back into the same resolver-ready identity used by
    // normal rows so the existing Search Links button can query stream addons successfully.
    func searchHydratedDetailItem(for item: MediaItem, query: String, tmdbApiKey: String) async -> MediaItem {
        if let catalogItem = catalogBackedSearchMatch(for: item) {
            status = "Opened Search result with full catalog resolver metadata."
            return mergedSearchArtwork(from: item, into: catalogItem)
        }

        // v470: If the visible card came from TMDB or a lightweight search result,
        // try every configured catalog/addon by title/year/type before falling back
        // to a TMDB-only IMDb resolver. This restores playable addon handoff.
        if let addonItem = await addonCatalogSearchMatch(for: item, fallbackQuery: query) {
            status = "Opened Search result with configured catalog/addon resolver metadata."
            return mergedSearchArtwork(from: item, into: addonItem)
        }

        if item.id.lowercased().hasPrefix("tmdb:"),
           let imdbID = await tmdbExternalIMDBID(for: item, apiKey: tmdbApiKey) {
            status = "Opened TMDB Search result with IMDb resolver id for Search Links."
            return rebuiltMediaItem(
                from: item,
                id: imdbID,
                catalog: item.catalog == "TMDB" ? "TMDB • IMDb Resolver" : item.catalog,
                addonName: item.addonName ?? "TMDB"
            )
        }

        if let cinemetaItem = await cinemetaSearchMatch(for: item, fallbackQuery: query) {
            status = "Opened Search result with Cinemeta resolver metadata."
            return mergedSearchArtwork(from: item, into: cinemetaItem)
        }

        status = "Opened Search result; no richer resolver metadata was found, using original search identity."
        return item
    }

    private func catalogBackedSearchMatch(for item: MediaItem) -> MediaItem? {
        let all = rows.flatMap { $0.items }
        if let exact = all.first(where: { $0.id == item.id }) { return exact }

        let targetTitle = normalizedMatchText(item.title)
        let targetYear = item.year.filter { $0.isNumber }
        let targetType = normalizedStremioType(item.type)
        return all.first { candidate in
            guard normalizedMatchText(candidate.title) == targetTitle else { return false }
            if normalizedStremioType(candidate.type) != targetType { return false }
            let candidateYear = candidate.year.filter { $0.isNumber }
            return targetYear.isEmpty || candidateYear.isEmpty || targetYear == candidateYear
        }
    }

    private func tmdbExternalIMDBID(for item: MediaItem, apiKey: String) async -> String? {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return nil }
        let parts = item.id.split(separator: ":").map(String.init)
        guard parts.count >= 3, parts[0].lowercased() == "tmdb" else { return nil }
        let tmdbKind = parts[1].lowercased() == "tv" || normalizedStremioType(item.type) == "series" ? "tv" : "movie"
        let tmdbID = parts[2]
        guard let url = URL(string: "https://api.themoviedb.org/3/\(tmdbKind)/\(tmdbID)/external_ids?api_key=\(key)") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 10)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/393 SearchHydration", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else { return nil }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let imdb = (json["imdb_id"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines),
                  imdb.lowercased().hasPrefix("tt") else { return nil }
            return imdb
        } catch {
            return nil
        }
    }

    private func cinemetaSearchMatch(for item: MediaItem, fallbackQuery: String) async -> MediaItem? {
        let cleanQuery = item.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? fallbackQuery : item.title
        guard let encodedSearch = cleanQuery.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed), !encodedSearch.isEmpty else { return nil }
        let type = normalizedStremioType(item.type)
        let typeCandidates = type == "series" ? ["series", "movie"] : ["movie", "series"]
        let targetTitle = normalizedMatchText(item.title)
        let targetYear = item.year.filter { $0.isNumber }

        for candidateType in typeCandidates {
            let endpoints = [
                "https://v3-cinemeta.strem.io/catalog/\(candidateType)/top/search=\(encodedSearch).json",
                "https://v3-cinemeta.strem.io/catalog/\(candidateType)/popular/search=\(encodedSearch).json"
            ]
            for endpoint in endpoints {
                guard let url = URL(string: endpoint) else { continue }
                do {
                    var request = URLRequest(url: url, timeoutInterval: 10)
                    request.setValue("application/json", forHTTPHeaderField: "Accept")
                    request.setValue("DebridChannels-tvOS/393 SearchHydration", forHTTPHeaderField: "User-Agent")
                    let (data, response) = try await URLSession.shared.data(for: request)
                    guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else { continue }
                    let decoded = try JSONDecoder().decode(CatalogResponse.self, from: data)
                    let metas = decoded.metas ?? []
                    let ranked = metas.sorted { lhs, rhs in
                        let lhsExact = normalizedMatchText(lhs.name ?? "") == targetTitle
                        let rhsExact = normalizedMatchText(rhs.name ?? "") == targetTitle
                        if lhsExact != rhsExact { return lhsExact && !rhsExact }
                        let lhsYear = Self.firstYear(from: lhs.releaseInfo).filter { $0.isNumber }
                        let rhsYear = Self.firstYear(from: rhs.releaseInfo).filter { $0.isNumber }
                        if !targetYear.isEmpty && lhsYear != rhsYear { return lhsYear == targetYear }
                        return (lhs.name ?? "") < (rhs.name ?? "")
                    }
                    for meta in ranked {
                        guard let id = meta.id?.trimmingCharacters(in: .whitespacesAndNewlines), !id.isEmpty else { continue }
                        let title = meta.name ?? item.title
                        if !targetTitle.isEmpty, normalizedMatchText(title) != targetTitle, !(normalizedMatchText(title).contains(targetTitle) || targetTitle.contains(normalizedMatchText(title))) { continue }
                        return MediaItem(
                            id: id,
                            tmdbId: meta.tmdbId,
                            imdbId: meta.imdbId,
                            tvdbId: meta.tvdbId,
                            title: title,
                            year: Self.firstYear(from: meta.releaseInfo).isEmpty ? item.year : Self.firstYear(from: meta.releaseInfo),
                            type: meta.type ?? candidateType,
                            catalog: "Cinemeta Search",
                            description: meta.description ?? item.description,
                            genres: Array((meta.genres ?? item.genres).prefix(3)),
                            rating: meta.imdbRating ?? item.rating,
                            posterURL: Self.highest(meta.poster) ?? item.posterURL,
                            landscapeURL: Self.highest(meta.background ?? meta.poster) ?? item.landscapeURL,
                            logoURL: Self.highest(meta.logo) ?? item.logoURL,
                            previewURL: Self.previewURL(from: meta) ?? item.previewURL,
                            addonName: "Cinemeta",
                            addonIconURL: nil,
                            seasonNumber: item.seasonNumber,
                            episodeNumber: item.episodeNumber,
                            cast: Array((meta.cast ?? item.cast).prefix(8)),
                            directors: Array((meta.directors ?? item.directors).prefix(3))
                        )
                    }
                } catch {
                    continue
                }
            }
        }
        return nil
    }

    private func mergedSearchArtwork(from searchItem: MediaItem, into resolverItem: MediaItem) -> MediaItem {
        rebuiltMediaItem(
            from: resolverItem,
            posterURL: resolverItem.posterURL ?? searchItem.posterURL,
            landscapeURL: resolverItem.landscapeURL ?? searchItem.landscapeURL,
            logoURL: resolverItem.logoURL ?? searchItem.logoURL,
            previewURL: resolverItem.previewURL ?? searchItem.previewURL,
            addonName: resolverItem.addonName ?? searchItem.addonName,
            addonIconURL: resolverItem.addonIconURL ?? searchItem.addonIconURL
        )
    }

    private func rebuiltMediaItem(
        from item: MediaItem,
        id: String? = nil,
        catalog: String? = nil,
        posterURL: String? = nil,
        landscapeURL: String? = nil,
        logoURL: String? = nil,
        previewURL: String? = nil,
        addonName: String? = nil,
        addonIconURL: String? = nil
    ) -> MediaItem {
        MediaItem(
            id: id ?? item.id,
            title: item.title,
            year: item.year,
            type: item.type,
            catalog: catalog ?? item.catalog,
            description: item.description,
            genres: item.genres,
            rating: item.rating,
            posterURL: posterURL ?? item.posterURL,
            landscapeURL: landscapeURL ?? item.landscapeURL,
            logoURL: logoURL ?? item.logoURL,
            previewURL: previewURL ?? item.previewURL,
            addonName: addonName ?? item.addonName,
            addonIconURL: addonIconURL ?? item.addonIconURL,
            seasonNumber: item.seasonNumber,
            episodeNumber: item.episodeNumber,
            cast: item.cast,
            directors: item.directors,
            castMembers: item.castMembers
        )
    }

    private func normalizedMatchText(_ value: String) -> String {
        value.lowercased().filter { $0.isLetter || $0.isNumber }
    }

    private func normalizedStremioType(_ value: String) -> String {
        let lower = value.lowercased()
        if lower.contains("series") || lower.contains("show") || lower == "tv" { return "series" }
        return "movie"
    }


    // v708: Premium artwork stack. Fanart.tv is preferred for backdrops, clearlogos, and posters.
    // TMDB /original remains the fallback when Fanart has no matching asset or cannot resolve an id.
    private func fanartTVApiKey() -> String {
        UserDefaults.standard.string(forKey: "fanartTvApiKey")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }

    private func bestFanartImage(_ groups: [[FanartTVImage]?]) -> String? {
        let images = groups.flatMap { $0 ?? [] }
        let ranked = images.sorted { lhs, rhs in
            let lhsLang = (lhs.lang ?? "").lowercased()
            let rhsLang = (rhs.lang ?? "").lowercased()
            let lhsEnglish = lhsLang == "en" || lhsLang.isEmpty
            let rhsEnglish = rhsLang == "en" || rhsLang.isEmpty
            if lhsEnglish != rhsEnglish { return lhsEnglish && !rhsEnglish }
            return lhs.likeScore > rhs.likeScore
        }
        return Self.highest(ranked.compactMap { $0.url?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty }))
    }

    private func fetchFanartArtwork(kind: String, tmdbID: Int, tvdbID: Int? = nil, tmdbApiKey: String) async -> PremiumFanartArtwork? {
        let fanartKey = fanartTVApiKey()
        guard !fanartKey.isEmpty else {
            print("[Fanart] skipped: Fanart.tv API key missing from Settings fanartTvApiKey")
            return nil
        }
        let normalizedKind = kind.lowercased() == "tv" || kind.lowercased() == "series" ? "tv" : "movie"
        var fanartID = String(tmdbID)

        if normalizedKind == "tv" {
            if let tvdbID, tvdbID > 0 {
                fanartID = String(tvdbID)
            } else {
                let key = tmdbApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
                guard tmdbID > 0, !key.isEmpty,
                      let externalURL = URL(string: "https://api.themoviedb.org/3/tv/\(tmdbID)/external_ids?api_key=\(key)") else {
                    print("[Fanart] skipped tv: no TVDB id and no TMDB external_ids path for tmdbID=\(tmdbID)")
                    return nil
                }
                do {
                    var request = URLRequest(url: externalURL, timeoutInterval: 8)
                    request.setValue("application/json", forHTTPHeaderField: "Accept")
                    request.setValue("DebridChannels-tvOS/708 FanartExternalIDs", forHTTPHeaderField: "User-Agent")
                    let (data, response) = try await URLSession.shared.data(for: request)
                    guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else {
                        print("[Fanart] TMDB external_ids failed tv tmdbID=\(tmdbID) status=\((response as? HTTPURLResponse)?.statusCode ?? -1)")
                        return nil
                    }
                    let external = try JSONDecoder().decode(TMDBExternalIDsResponse.self, from: data)
                    guard let tvdbID = external.tvdb_id, tvdbID > 0 else {
                        print("[Fanart] skipped tv tmdbID=\(tmdbID): TMDB external_ids did not include tvdb_id")
                        return nil
                    }
                    fanartID = String(tvdbID)
                } catch {
                    print("[Fanart] TMDB external_ids error tv tmdbID=\(tmdbID): \(error.localizedDescription)")
                    return nil
                }
            }
        }

        let endpoint = normalizedKind == "tv" ? "tv" : "movies"
        guard let encodedKey = fanartKey.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://webservice.fanart.tv/v3/\(endpoint)/\(fanartID)?api_key=\(encodedKey)") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 10)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/708 FanartPremiumArtwork", forHTTPHeaderField: "User-Agent")
            print("[Fanart] request https://webservice.fanart.tv/v3/\(endpoint)/\(fanartID)")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else {
                print("[Fanart] failed \(endpoint)/\(fanartID) status=\((response as? HTTPURLResponse)?.statusCode ?? -1)")
                return nil
            }
            if normalizedKind == "tv" {
                let decoded = try JSONDecoder().decode(FanartTVResponse.self, from: data)
                let artwork = PremiumFanartArtwork(
                    backdropURL: bestFanartImage([decoded.showbackground]),
                    logoURL: bestFanartImage([decoded.hdtvlogo, decoded.clearlogo]),
                    posterURL: bestFanartImage([decoded.tvposter])
                )
                print("[Fanart] response tv/\(fanartID) background=\(artwork.backdropURL != nil) clearlogo=\(artwork.logoURL != nil) poster=\(artwork.posterURL != nil)")
                return artwork.hasAny ? artwork : nil
            } else {
                let decoded = try JSONDecoder().decode(FanartMovieResponse.self, from: data)
                let artwork = PremiumFanartArtwork(
                    backdropURL: bestFanartImage([decoded.moviebackground]),
                    logoURL: bestFanartImage([decoded.hdmovielogo, decoded.movielogo]),
                    posterURL: bestFanartImage([decoded.movieposter])
                )
                print("[Fanart] response movies/\(fanartID) background=\(artwork.backdropURL != nil) clearlogo=\(artwork.logoURL != nil) poster=\(artwork.posterURL != nil)")
                return artwork.hasAny ? artwork : nil
            }
        } catch {
            print("[Fanart] error \(endpoint)/\(fanartID): \(error.localizedDescription)")
            return nil
        }
    }

    private func applyPremiumFanartArtwork(to item: MediaItem, kind: String, tmdbID: Int, tvdbID: Int? = nil, tmdbApiKey: String) async -> MediaItem {
        guard let art = await fetchFanartArtwork(kind: kind, tmdbID: tmdbID, tvdbID: tvdbID, tmdbApiKey: tmdbApiKey) else { return item }
        var copy = item
        if let backdrop = art.backdropURL { copy.landscapeURL = backdrop }
        if let logo = art.logoURL { copy.logoURL = logo }
        if let poster = art.posterURL { copy.posterURL = poster }
        return copy
    }

    // v706: Catalog providers such as Cinemeta usually return imdb ids (tt...).
    // v704/v705 only used Fanart on TMDB-created rows, so regular streaming catalog
    // shelves kept showing Cinemeta/TMDB art. Resolve catalog ids through TMDB first,
    // then fetch Fanart so the visible Home/Movies/Shows rows actually use Fanart art.
    private func applyPremiumFanartArtworkIfResolvable(to item: MediaItem, tmdbApiKey: String) async -> MediaItem {
        let key = tmdbApiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !fanartTVApiKey().isEmpty else { return item }
        if normalizedStremioType(item.type) == "series",
           let explicitTVDB = Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""), explicitTVDB > 0 {
            print("[Fanart] resolved \(item.title) using catalog tvdbId=\(explicitTVDB)")
            return await applyPremiumFanartArtwork(to: item, kind: "tv", tmdbID: 0, tvdbID: explicitTVDB, tmdbApiKey: key)
        }
        guard !key.isEmpty else {
            print("[Fanart] unresolved \(item.title): TMDB key missing and no direct TVDB id")
            return item
        }
        guard let target = await tmdbTargetForCredits(item, apiKey: key), let id = Int(target.id) else {
            print("[Fanart] unresolved \(item.title): id=\(item.id) tmdbId=\(item.tmdbId ?? "") imdbId=\(item.imdbId ?? "") tvdbId=\(item.tvdbId ?? "")")
            return item
        }
        print("[Fanart] resolved \(item.title) via \(target.source) -> \(target.kind)/\(target.id)")
        return await applyPremiumFanartArtwork(to: item, kind: target.kind, tmdbID: id, tvdbID: target.tvdbID, tmdbApiKey: key)
    }

    func tmdbSearchResults(for query: String, apiKey: String) async -> [MediaItem] {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.count >= 2, !key.isEmpty,
              let encoded = trimmed.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://api.themoviedb.org/3/search/multi?api_key=\(key)&query=\(encoded)&include_adult=false&page=1") else { return [] }
        do {
            var request = URLRequest(url: url, timeoutInterval: 12)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/349 UniversalSearch", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else { return [] }
            let decoded = try JSONDecoder().decode(TMDBMultiSearchResponse.self, from: data)
            var output: [MediaItem] = []
            for result in decoded.results.prefix(30) {
                let mediaType = (result.media_type ?? "").lowercased()
                guard mediaType == "movie" || mediaType == "tv" else { continue }
                let title = (result.title ?? result.name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !title.isEmpty else { continue }
                let date = result.release_date ?? result.first_air_date ?? ""
                let year = String(date.prefix(4)).isEmpty ? "TMDB" : String(date.prefix(4))
                let poster = result.poster_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                let backdrop = result.backdrop_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                let rating = result.vote_average.map { String(format: "%.1f", $0) } ?? ""
                let type = mediaType == "movie" ? "movie" : "series"
                let stremioID = mediaType == "movie" ? "tmdb:movie:\(result.id)" : "tmdb:tv:\(result.id)"
                let item = MediaItem(
                    id: stremioID,
                    title: title,
                    year: year,
                    type: type,
                    catalog: "TMDB",
                    description: result.overview ?? "",
                    genres: [mediaType == "movie" ? "Movie" : "Show", "TMDB"],
                    rating: rating,
                    posterURL: poster,
                    landscapeURL: backdrop,
                    logoURL: nil,
                    previewURL: nil,
                    addonName: "TMDB",
                    addonIconURL: nil
                )
                output.append(await applyPremiumFanartArtwork(to: item, kind: mediaType, tmdbID: result.id, tmdbApiKey: key))
            }
            return output
        } catch {
            return []
        }
    }

    func tmdbDefaultCatalogRows(apiKey: String) async -> [MediaRow] {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return [] }

        struct TMDBShelf {
            let id: String
            let title: String
            let path: String
            let type: String
        }

        let shelves: [TMDBShelf] = [
            TMDBShelf(id: "tmdb-trending-movies", title: "TMDB - Trending Movies", path: "/trending/movie/week", type: "movie"),
            TMDBShelf(id: "tmdb-popular-movies", title: "TMDB - Popular Movies", path: "/movie/popular", type: "movie"),
            TMDBShelf(id: "tmdb-top-rated-movies", title: "TMDB - Top Rated Movies", path: "/movie/top_rated", type: "movie"),
            TMDBShelf(id: "tmdb-now-playing", title: "TMDB - Now Playing", path: "/movie/now_playing", type: "movie"),
            TMDBShelf(id: "tmdb-upcoming", title: "TMDB - Upcoming Movies", path: "/movie/upcoming", type: "movie"),
            TMDBShelf(id: "tmdb-trending-shows", title: "TMDB - Trending Shows", path: "/trending/tv/week", type: "series"),
            TMDBShelf(id: "tmdb-popular-shows", title: "TMDB - Popular Shows", path: "/tv/popular", type: "series"),
            TMDBShelf(id: "tmdb-top-rated-shows", title: "TMDB - Top Rated Shows", path: "/tv/top_rated", type: "series")
        ]

        var output: [MediaRow] = []
        for shelf in shelves {
            guard let url = URL(string: "https://api.themoviedb.org/3\(shelf.path)?api_key=\(key)&language=en-US&page=1") else { continue }
            do {
                var request = URLRequest(url: url, timeoutInterval: 12)
                request.setValue("application/json", forHTTPHeaderField: "Accept")
                request.setValue("DebridChannels-tvOS/374 UniversalCatalogs", forHTTPHeaderField: "User-Agent")
                let (data, response) = try await URLSession.shared.data(for: request)
                guard (response as? HTTPURLResponse).map({ (200..<300).contains($0.statusCode) }) ?? true else { continue }
                let decoded = try JSONDecoder().decode(TMDBListResponse.self, from: data)
                var items: [MediaItem] = []
                for result in decoded.results.prefix(24) {
                    let title = (result.title ?? result.name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !title.isEmpty else { continue }
                    let date = result.release_date ?? result.first_air_date ?? ""
                    let year = String(date.prefix(4)).isEmpty ? "TMDB" : String(date.prefix(4))
                    let poster = result.poster_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                    let backdrop = result.backdrop_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                    let rating = result.vote_average.map { String(format: "%.1f", $0) } ?? ""
                    let stremioID = shelf.type == "movie" ? "tmdb:movie:\(result.id)" : "tmdb:tv:\(result.id)"
                    let item = MediaItem(
                        id: stremioID,
                        title: title,
                        year: year,
                        type: shelf.type,
                        catalog: shelf.title,
                        description: result.overview ?? "",
                        genres: [shelf.type == "movie" ? "Movie" : "Show", "TMDB"],
                        rating: rating,
                        posterURL: poster,
                        landscapeURL: backdrop,
                        logoURL: nil,
                        previewURL: nil,
                        addonName: "TMDB",
                        addonIconURL: nil
                    )
                    let fanartKind = shelf.type == "series" ? "tv" : "movie"
                    items.append(await applyPremiumFanartArtwork(to: item, kind: fanartKind, tmdbID: result.id, tmdbApiKey: key))
                }
                if !items.isEmpty { output.append(MediaRow(id: shelf.id, title: shelf.title, items: items)) }
            } catch {
                continue
            }
        }
        return output
    }

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func directPreviewURL(for item: MediaItem) -> URL? {
        guard let preview = item.previewURL, let url = URL(string: preview) else { return nil }
        let lower = preview.lowercased()
        // Internal player needs a direct MP4/M3U8/MOV style URL. YouTube page IDs/links must be converted by backend.
        if lower.contains("youtube.com") || lower.contains("youtu.be") { return nil }
        return url
    }



    func cachedPlayableTrailerURL(for item: MediaItem) -> URL? {
        if let direct = directPreviewURL(for: item) { return direct }
        let cacheKey = trailerCacheKey(for: item)
        if let cached = trailerResolveMemoryCache[cacheKey], let cachedURL = playableTrailerURL(from: cached) {
            return cachedURL
        }
        return nil
    }

    func beginTrailerPrewarm(for item: MediaItem) {
        if cachedPlayableTrailerURL(for: item) != nil { return }
        let cacheKey = trailerCacheKey(for: item)
        if trailerResolveInflightTasks[cacheKey] != nil { return }
        let task = Task { [weak self] () -> URL? in
            guard let self else { return nil }
            return await self.resolvePlayableTrailerURLNetworkOnly(for: item, cacheKey: cacheKey)
        }
        trailerResolveInflightTasks[cacheKey] = task
        Task { [weak self] in
            _ = await task.value
            await MainActor.run { self?.trailerResolveInflightTasks[cacheKey] = nil }
        }
    }

    func resolvePlayableTrailerURL(for item: MediaItem) async -> URL? {
        resolvedTrailerAudioURL = nil
        if let direct = directPreviewURL(for: item) { return direct }

        let cacheKey = trailerCacheKey(for: item)
        if let cached = trailerResolveMemoryCache[cacheKey], let cachedURL = playableTrailerURL(from: cached) {
            lastStreamMessage = "Trailer ready."
            return cachedURL
        }

        // v566 rebuild: Stremio-addon trailer scanning is disabled for now.
        // Trailer button must never trigger normal movie/show source scanning.
        // Keep the legacy trailer resolver path only until addon trailer handling is rebuilt safely.

        // v395 trailer-only fix: single-flight duplicate trailer resolving.
        // The v394 log showed the same title spawning repeated backend yt-dlp
        // searches/extracts, often both 2160p and 1080p. Keep one in-flight
        // resolver task per media key; duplicate button presses/detail refreshes
        // await the same task instead of starting more backend jobs.
        if let existingTask = trailerResolveInflightTasks[cacheKey] {
            lastStreamMessage = "Trailer already resolving…"
            return await existingTask.value
        }

        let task = Task { [weak self] () -> URL? in
            guard let self else { return nil }
            return await self.resolvePlayableTrailerURLNetworkOnly(for: item, cacheKey: cacheKey)
        }
        trailerResolveInflightTasks[cacheKey] = task
        let result = await task.value
        trailerResolveInflightTasks[cacheKey] = nil
        return result
    }


    private func bestPlayableAddonTrailerURL(for item: MediaItem) async -> URL? {
        let priorLinks = streamLinks
        let priorMessage = lastStreamMessage
        let links = await findStreams(for: item)
        let trailers = links
            .filter { isLikelyTrailerStream($0, for: item) && $0.isDirectPlayable }
            .sorted { lhs, rhs in
                trailerRank(lhs) < trailerRank(rhs)
            }
        if !trailers.isEmpty {
            // Restore the normal movie source list if the user was only pressing Trailer.
            streamLinks = priorLinks
            lastStreamMessage = priorMessage.isEmpty ? "Using Stremio addon trailer source." : priorMessage
        }
        guard let best = trailers.first else { return nil }
        return Self.makePlayableURL(from: best.url)
    }

    private func isLikelyTrailerStream(_ link: StreamLink, for item: MediaItem) -> Bool {
        let title = link.title.lowercased()
        let source = link.source.lowercased()
        let haystack = "\(title) \(link.quality.lowercased()) \(link.size.lowercased()) \(source)"
        let markerHit = ["trailer", "teaser", "preview", "official-trailer", "official trailer", "trailer-1", "trailer-2", "[trailer"].contains { haystack.contains($0) }
        guard markerHit else { return false }
        let mediaTitle = item.title.lowercased().replacingOccurrences(of: #"[^a-z0-9]+"#, with: " ", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
        let cleaned = title.replacingOccurrences(of: #"[^a-z0-9]+"#, with: " ", options: .regularExpression)
        let titleMatch = mediaTitle.isEmpty || cleaned.contains(mediaTitle) || mediaTitle.split(separator: " ").prefix(2).allSatisfy { cleaned.contains($0) }
        return titleMatch || source.contains("streailer") || source.contains("debridio")
    }

    private func trailerRank(_ link: StreamLink) -> Int {
        let h = "\(link.title) \(link.quality)".lowercased()
        if h.contains("1080") { return 0 }
        if h.contains("720") { return 1 }
        if h.contains("4k") || h.contains("2160") { return 2 }
        return 3
    }

    func resolveTrailerWatchURL(for item: MediaItem) async -> URL? {
        let configuredBase = (UserDefaults.standard.string(forKey: "backendBaseURL") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let base = configuredBase.isEmpty ? "https://api.skylinejay187.it.com" : configuredBase
        guard let title = item.title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return youtubeSearchURL(for: item) }
        let year = item.year.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let rawId = item.id.trimmingCharacters(in: .whitespacesAndNewlines)
        let id = rawId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let type = (item.type.isEmpty ? "movie" : item.type).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "movie"
        let tmdbId = CatalogStore.extractedTrailerTMDBId(from: rawId).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let imdbId = CatalogStore.extractedTrailerIMDbId(from: rawId).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let providerMode = "legacy"
        let chain = "kinocheck,tmdb,youtube".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "kinocheck,tmdb,youtube"
        let query = "title=\(title)&year=\(year)&type=\(type)&id=\(id)&mediaId=\(id)&tmdbId=\(tmdbId)&imdbId=\(imdbId)&fast=true&reuseCache=true&provider=\(providerMode)&providerChain=\(chain)&stremioTrailers=false&streailer=false&debridioTrailerStreams=false"
        guard let endpoint = URL(string: "\(base)/trailers/resolve?\(query)") else { return youtubeSearchURL(for: item) }
        do {
            var request = URLRequest(url: endpoint, timeoutInterval: 18)
            request.setValue("application/json,text/plain,*/*", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/563 TrailerExternal", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 200
            guard (200..<300).contains(statusCode), data.count < 1024 * 1024 else { return youtubeSearchURL(for: item) }
            if let plain = String(data: data, encoding: .utf8), let url = youtubeWatchURL(from: plain) { return url }
            if let json = try? JSONSerialization.jsonObject(with: data), let url = youtubeWatchURL(fromJSON: json) { return url }
        } catch {
            return youtubeSearchURL(for: item)
        }
        return youtubeSearchURL(for: item)
    }

    private func youtubeSearchURL(for item: MediaItem) -> URL? {
        let text = "\(item.title) \(item.year) official trailer"
        guard let q = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        return URL(string: "https://www.youtube.com/results?search_query=\(q)")
    }

    private func youtubeWatchURL(fromJSON value: Any) -> URL? {
        if let string = value as? String { return youtubeWatchURL(from: string) }
        if let dict = value as? [String: Any] {
            for key in ["watchUrl", "watch_url", "webpageUrl", "webpage_url", "originalUrl", "original_url", "sourceUrl", "source_url", "youtubeUrl", "youtube_url", "url"] {
                if let nested = dict[key], let url = youtubeWatchURL(fromJSON: nested) { return url }
            }
            for key in ["youtubeVideoId", "youtube_video_id", "videoId", "video_id", "youtubeId", "youtube_id", "id", "key"] {
                if let raw = dict[key] as? String, let url = URL(string: "https://www.youtube.com/watch?v=\(raw)") { return url }
            }
            for nested in dict.values {
                if let url = youtubeWatchURL(fromJSON: nested) { return url }
            }
        }
        if let array = value as? [Any] {
            for nested in array {
                if let url = youtubeWatchURL(fromJSON: nested) { return url }
            }
        }
        return nil
    }

    private func youtubeWatchURL(from raw: String) -> URL? {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let range = clean.range(of: #"https?://(www\.)?(youtube\.com/watch\?v=|youtu\.be/)[A-Za-z0-9_?&=./%-]+"#, options: .regularExpression) {
            return URL(string: String(clean[range]))
        }
        let patterns = [#"youtubeVideoId[\"':\s]+([A-Za-z0-9_-]{11})"#, #"youtube_video_id[\"':\s]+([A-Za-z0-9_-]{11})"#, #"youtubeId[\"':\s]+([A-Za-z0-9_-]{11})"#, #"youtube_id[\"':\s]+([A-Za-z0-9_-]{11})"#, #"video_id[\"':\s]+([A-Za-z0-9_-]{11})"#, #"videoId[\"':\s]+([A-Za-z0-9_-]{11})"#, #"youtu\.be/([A-Za-z0-9_-]{11})"#, #"youtube\.com/(?:watch\?v=|embed/|shorts/)([A-Za-z0-9_-]{11})"#]
        for pattern in patterns {
            if let range = clean.range(of: pattern, options: .regularExpression) {
                let match = String(clean[range])
                if let idRange = match.range(of: #"[A-Za-z0-9_-]{11}"#, options: .regularExpression) {
                    return URL(string: "https://www.youtube.com/watch?v=\(String(match[idRange]))")
                }
            }
        }
        return nil
    }

    private func resolvePlayableTrailerURLNetworkOnly(for item: MediaItem, cacheKey: String) async -> URL? {
        let configuredBase = (UserDefaults.standard.string(forKey: "backendBaseURL") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let base = configuredBase.isEmpty ? "https://api.skylinejay187.it.com" : configuredBase
        guard let title = item.title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        let year = item.year.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""

        let rawId = item.id.trimmingCharacters(in: .whitespacesAndNewlines)
        let id = rawId.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let type = (item.type.isEmpty ? "movie" : item.type).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "movie"
        let tmdbId = CatalogStore.extractedTrailerTMDBId(from: rawId).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let imdbId = CatalogStore.extractedTrailerIMDbId(from: rawId).addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let providerMode = "legacy"
        let providerChain = "kinocheck,tmdb,youtube"
        lastStreamMessage = "Resolving trailer…"

        // v566 rebuild: keep addon trailers off. The trailer resolver must not scan Stremio streams
        // or populate normal movie links. Use backend direct/KinoCheck/TMDB/YouTube fallback only.
        let providerQuery = "provider=legacy&providerChain=\(providerChain.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "kinocheck,tmdb,youtube")&stremioTrailers=false&streailer=false&debridioTrailerStreams=false"
        let fastQuery = "title=\(title)&year=\(year)&type=\(type)&id=\(id)&mediaId=\(id)&tmdbId=\(tmdbId)&imdbId=\(imdbId)&quality=720p&prefer4k=false&minHeight=360&maxHeight=1080&allow4k=false&fast=true&reuseCache=true&singleFlight=true&cacheOnly=false&\(providerQuery)"
        let candidates = [
            "\(base)/trailers/resolve?\(fastQuery)",
            "\(base)/api/trailers/resolve?\(fastQuery)"
        ]

        for urlString in candidates {
            guard let endpoint = URL(string: urlString) else { continue }
            do {
                var request = URLRequest(url: endpoint, timeoutInterval: 45)
                request.setValue("application/json,text/plain,*/*", forHTTPHeaderField: "Accept")
                request.setValue("DebridChannels-tvOS/563 StremioTrailerChain", forHTTPHeaderField: "User-Agent")
                request.cachePolicy = .reloadIgnoringLocalCacheData
                let (data, response) = try await URLSession.shared.data(for: request)
                let statusCode = (response as? HTTPURLResponse)?.statusCode ?? 200
                guard (200..<300).contains(statusCode), data.count < 1024 * 1024 else {
                    // Only fallback to the next endpoint on route failure. Do not spawn
                    // a parallel 4K/HQ resolver from the app.
                    lastStreamMessage = "Preparing trailer…"
                    continue
                }

                if let plain = String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines),
                   plain.lowercased().hasPrefix("http"),
                   let url = playableTrailerURL(from: plain) {
                    rememberTrailerURL(url, cacheKey: cacheKey)
                    lastStreamMessage = "Trailer ready."
                    return url
                }

                if let json = try? JSONSerialization.jsonObject(with: data) {
                    if let url = remuxedTrailerPlaybackURL(fromJSON: json) {
                        resolvedTrailerAudioURL = nil
                        rememberTrailerURL(url, cacheKey: cacheKey)
                        lastStreamMessage = "Trailer ready."
                        return url
                    }
                    if let body = String(data: data, encoding: .utf8), let url = remuxedTrailerPlaybackURL(fromRawBody: body) {
                        resolvedTrailerAudioURL = nil
                        rememberTrailerURL(url, cacheKey: cacheKey)
                        lastStreamMessage = "Trailer ready."
                        return url
                    }
                    lastStreamMessage = "Trailer is not ready yet."
                    return nil
                }
            } catch {
                lastStreamMessage = "Preparing trailer…"
                continue
            }
        }
        lastStreamMessage = "Trailer is not ready yet."
        return nil
    }

    private func trailerCacheKey(for item: MediaItem) -> String {
        // v399: lock/cache by the actual trailer identity, not by app catalog ID.
        // The same movie can appear from TMDB/Cinemeta/search/row providers with
        // different IDs; including item.id let duplicates bypass v395 single-flight
        // and spawn repeated yt-dlp jobs for the same title/year.
        let title = item.title
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: #"\s+"#, with: " ", options: .regularExpression)
        let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
        let type = (item.type.isEmpty ? "movie" : item.type)
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        return [title, year, type].filter { !$0.isEmpty }.joined(separator: "|")
    }

    private static func extractedTrailerIMDbId(from raw: String) -> String {
        guard let range = raw.range(of: #"tt\d{5,}"#, options: [.regularExpression, .caseInsensitive]) else { return "" }
        return String(raw[range]).lowercased()
    }

    private static func extractedTrailerTMDBId(from raw: String) -> String {
        if extractedTrailerIMDbId(from: raw).isEmpty == false { return "" }
        if let range = raw.range(of: #"(?:tmdb[:_/\-]|themoviedb[:_/\-])(\d{2,})"#, options: [.regularExpression, .caseInsensitive]) {
            let match = String(raw[range])
            return match.components(separatedBy: CharacterSet.decimalDigits.inverted).joined()
        }
        if raw.range(of: #"^\d{2,}$"#, options: .regularExpression) != nil { return raw }
        return ""
    }

    private func rememberTrailerURL(_ url: URL, cacheKey: String) {
        let raw = url.absoluteString
        guard !raw.isEmpty else { return }
        trailerResolveMemoryCache[cacheKey] = raw
        UserDefaults.standard.set(trailerResolveMemoryCache, forKey: trailerResolveCacheKey)
    }

    private func remuxedTrailerPlaybackURL(fromJSON value: Any) -> URL? {
        var candidates: [URL] = []

        func walk(_ node: Any, keyPath: [String] = []) {
            if let string = node as? String, let url = playableTrailerURL(from: string) {
                let joined = keyPath.joined(separator: ".").lowercased()
                let raw = string.lowercased()
                // Only accept backend-ready playback fields. Never accept split source videoUrl/audioUrl here.
                if joined.contains("playbackurl") || joined.contains("previewurl") || joined.contains("remux") || raw.contains("/remux-cache/") {
                    candidates.append(url)
                }
                return
            }
            if let dict = node as? [String: Any] {
                // Strict first pass: direct remux/playback fields only, in priority order.
                for key in ["playbackUrl", "remuxedUrl", "muxedUrl", "remuxUrl", "previewUrl", "playback_url", "remuxed_url", "muxed_url", "remux_url", "preview_url"] {
                    if let nested = dict[key] { walk(nested, keyPath: keyPath + [key]) }
                }
                for key in ["preview", "trailer", "data", "result", "stream", "source"] {
                    if let nested = dict[key] { walk(nested, keyPath: keyPath + [key]) }
                }
                for (key, nested) in dict where key.lowercased() != "videourl" && key.lowercased() != "video_url" && key.lowercased() != "audiourl" && key.lowercased() != "audio_url" {
                    walk(nested, keyPath: keyPath + [key])
                }
            } else if let array = node as? [Any] {
                for nested in array { walk(nested, keyPath: keyPath) }
            }
        }

        walk(value)
        if let remux = candidates.first(where: { $0.absoluteString.lowercased().contains("/remux-cache/") }) { return remux }
        return candidates.first
    }

    private func remuxedTrailerPlaybackURL(fromRawBody body: String) -> URL? {
        // Last-resort extractor for valid backend bodies that include an escaped remux-cache URL.
        let unescaped = body.replacingOccurrences(of: "\\/", with: "/")
        guard let range = unescaped.range(of: #"https?://[^\"\s]+/api/trailers/remux-cache/[^\"\s]+\.mp4"#, options: .regularExpression) else { return nil }
        return playableTrailerURL(from: String(unescaped[range]))
    }


    private func playableTrailerMedia(fromJSON value: Any) -> (video: URL?, audio: URL?) {
        if let dict = value as? [String: Any] {
            let videoKeys = ["playbackUrl", "playback_url", "streamUrl", "stream_url", "trailerUrl", "trailer_url", "url", "src", "videoUrl", "video_url"]
            let audioKeys = ["audioUrl", "audio_url", "audio", "audioSrc", "audio_src"]
            var bestVideo: URL? = nil
            var bestAudio: URL? = nil
            for key in videoKeys where bestVideo == nil {
                if let nested = dict[key], let url = playableTrailerURL(fromJSON: nested) { bestVideo = url }
            }
            for key in audioKeys where bestAudio == nil {
                if let nested = dict[key], let url = playableTrailerURL(fromJSON: nested) { bestAudio = url }
            }
            // Prefer nested objects that expose playbackUrl/previewUrl over bare videoUrl-only
            // siblings, but keep audioUrl when it belongs to the same result object.
            for key in ["trailer", "preview", "data", "result", "stream", "source"] {
                if let nested = dict[key] {
                    let candidate = playableTrailerMedia(fromJSON: nested)
                    if bestVideo == nil { bestVideo = candidate.video }
                    if bestAudio == nil { bestAudio = candidate.audio }
                }
            }
            for nested in dict.values {
                let candidate = playableTrailerMedia(fromJSON: nested)
                if bestVideo == nil { bestVideo = candidate.video }
                if bestAudio == nil { bestAudio = candidate.audio }
                if bestVideo != nil && bestAudio != nil { break }
            }
            return (bestVideo, bestAudio)
        }
        if let array = value as? [Any] {
            for nested in array {
                let candidate = playableTrailerMedia(fromJSON: nested)
                if candidate.video != nil { return candidate }
            }
            return (nil, nil)
        }
        return (playableTrailerURL(fromJSON: value), nil)
    }

    private func playableTrailerURL(fromJSON value: Any) -> URL? {
        let preferred = ["playbackUrl", "remuxedUrl", "muxedUrl", "remuxUrl", "playback_url", "remuxed_url", "muxed_url", "remux_url", "streamUrl", "stream_url", "trailerUrl", "trailer_url", "url", "src", "videoUrl", "video_url"]
        if let string = value as? String { return playableTrailerURL(from: string) }
        if let dict = value as? [String: Any] {
            for key in preferred {
                if let nested = dict[key], let url = playableTrailerURL(fromJSON: nested) { return url }
            }
            for key in ["trailer", "preview", "data", "result", "stream", "source"] {
                if let nested = dict[key], let url = playableTrailerURL(fromJSON: nested) { return url }
            }
            for nested in dict.values {
                if let url = playableTrailerURL(fromJSON: nested) { return url }
            }
        }
        if let array = value as? [Any] {
            for nested in array {
                if let url = playableTrailerURL(fromJSON: nested) { return url }
            }
        }
        return nil
    }

    private func playableTrailerURL(from raw: String) -> URL? {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let lower = clean.lowercased()
        guard lower.hasPrefix("http"),
              !lower.contains("youtube.com/watch"),
              !lower.contains("youtu.be/"),
              !lower.contains("youtube.com/shorts"),
              !lower.contains("vimeo.com/") else { return nil }
        if lower.contains(".m3u8") || lower.contains(".mp4") || lower.contains(".mov") || lower.contains(".m4v") || lower.contains("video") || lower.contains("playback") || lower.contains("preview") {
            return URL(string: clean)
        }
        return nil
    }

    func findStreams(for item: MediaItem, providerFilter: String? = nil) async -> [StreamLink] {
        let activeProviderFilter = providerFilter ?? selectedSourceProvider
        selectedSourceProvider = activeProviderFilter
        activeStreamSearchItemID = item.id
        lastStreamMessage = activeProviderFilter == "All Providers" ? "Searching every configured Stremio addon for \(item.title)…" : "Searching \(activeProviderFilter) for \(item.title)…"
        streamLinks = []
        sourceProviderStatuses = []
        alternateAudioSources = []
        selectedAlternateAudioSource = nil
        alternateAudioSyncOffsetMS = 0

        let searchItemID = item.id
        let urlSession = URLSession.shared
        let typeCandidates = streamTypeCandidates(for: item)
        let idCandidates = streamIDCandidates(for: item)
        let fallbackIDCandidates = streamIDFallbackCandidates(for: item)
        var found: [StreamLink] = []
        var seenKeys = Set<String>()
        var attempts = 0
        var addonFailures: [String] = []

        // v310: Xtream Codes VOD/series support. This is additive only: it reads the
        // existing Xtream settings and exposes matching movie/episode URLs in the
        // same link picker as Stremio/debrid links. It does not touch Live TV guide loading.
        let xtreamLinks = await findXtreamVODLinks(for: item)
        for link in xtreamLinks {
            guard sourceProviderMatches(selection: activeProviderFilter, provider: link.providerDisplay, manifestURL: link.source) else { continue }
            let key = "\(link.source)|\(link.url ?? link.title)"
            guard !seenKeys.contains(key) else { continue }
            seenKeys.insert(key)
            found.append(link)
        }
        if !found.isEmpty, isCurrentStreamSearch(searchItemID) {
            streamLinks = sortedStreamLinks(found)
            lastStreamMessage = "Found \(streamLinks.count) Xtream link(s). Still scanning configured Stremio addons…"
        }

        for rawManifest in prioritizedManifestURLsWithMetadataFallback() {
            let manifestCandidates = manifestURLCandidates(from: rawManifest)
            var manifestDecoded: StremioManifest? = nil
            var workingManifestURL: URL? = nil

            for candidate in manifestCandidates {
                guard let candidateURL = URL(string: candidate) else { continue }
                do {
                    var manifestRequest = URLRequest(url: candidateURL, timeoutInterval: 7)
                    manifestRequest.setValue("application/json", forHTTPHeaderField: "Accept")
                    manifestRequest.setValue("DebridChannels-tvOS/576 FastExact", forHTTPHeaderField: "User-Agent")
                    let (data, response) = try await urlSession.data(for: manifestRequest)
                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    manifestDecoded = try JSONDecoder().decode(StremioManifest.self, from: data)
                    let identityName = manifestDecoded?.name ?? candidateURL.host ?? "Stremio"
                    let identityIcon = Self.highest(manifestDecoded?.logo ?? manifestDecoded?.icon)
                    await MainActor.run {
                        self.addonIdentities[rawManifest] = StremioAddonIdentity(name: identityName, iconURL: identityIcon, kind: self.addonKind(from: manifestDecoded!))
                    }
                    workingManifestURL = candidateURL
                    break
                } catch {
                    continue
                }
            }

            guard let manifestURL = workingManifestURL else {
                addonFailures.append("Could not load manifest from \(rawManifest). Configure-page URLs must resolve to /manifest.json or a configured addon URL.")
                upsertSourceProviderStatus(provider: providerName(from: rawManifest, manifest: nil), state: .failed, linkCount: 0, message: "Manifest failed")
                continue
            }

            let base = normalizedStremioBase(from: manifestURL.absoluteString)
            let sourceName = manifestDecoded?.name ?? manifestURL.host ?? "Stremio"
            guard sourceProviderMatches(selection: activeProviderFilter, provider: sourceName, manifestURL: rawManifest) else { continue }
            upsertSourceProviderStatus(provider: sourceName, state: .searching, linkCount: 0, message: "searching")
            let addonStartCount = found.count
            let addonTypes = expandedStreamTypes(typeCandidates: typeCandidates, manifest: manifestDecoded)
            let addonIDPasses: [(ids: [String], strictTitleFilter: Bool)] = [
                (idCandidates, false),
                (fallbackIDCandidates, true)
            ].filter { !$0.ids.isEmpty }

            for type in addonTypes {
                for idPass in addonIDPasses {
                    if idPass.strictTitleFilter && !found.isEmpty { continue }
                    for streamID in idPass.ids {
                    guard let encodedID = streamID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let streamURL = URL(string: "\(base)/stream/\(type)/\(encodedID).json") else { continue }
                    attempts += 1
                    do {
                        let isMediaFusionEndpoint = providerCanonical(sourceName + " " + rawManifest).contains("mediafusion")
                        let streamTimeout: TimeInterval = isMediaFusionEndpoint ? 28 : 12
                        var streamRequest = URLRequest(url: streamURL, timeoutInterval: streamTimeout)
                        streamRequest.setValue("application/json", forHTTPHeaderField: "Accept")
                        streamRequest.setValue("DebridChannels-tvOS/688 MediaFusionPatient", forHTTPHeaderField: "User-Agent")
                        let data: Data
                        let response: URLResponse
                        do {
                            (data, response) = try await urlSession.data(for: streamRequest)
                        } catch {
                            guard isMediaFusionEndpoint else { throw error }
                            try? await Task.sleep(nanoseconds: 900_000_000)
                            (data, response) = try await urlSession.data(for: streamRequest)
                        }
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioStreamResponse.self, from: data)
                        for stream in decoded.streams ?? [] {
                            let title = stream.title ?? stream.name ?? stream.behaviorHints?.filename ?? "Stream"
                            guard streamTitleMatchesRequestedEpisode(title, item: item, requireExplicitEpisodeToken: idPass.strictTitleFilter) else { continue }
                            // Stremio convention: `url` is the playable URL when the addon has resolved it.
                            // `externalUrl` is usually a browser/page handoff, so keep it visible but do not treat it as guaranteed playback.
                            let playableURL = stream.url ?? stream.externalUrl
                            let isExternalOnly = (stream.url == nil && stream.externalUrl != nil)
                            let sizeText: String
                            if let bytes = stream.behaviorHints?.videoSize, bytes > 0 {
                                let gb = Double(bytes) / 1_073_741_824.0
                                sizeText = String(format: "%.1f GB", gb)
                            } else {
                                sizeText = parsedSizeText(from: title) ?? "Unknown size"
                            }
                            let quality = parsedQuality(from: title)
                            let key = "\(sourceName)|\(playableURL ?? stream.infoHash ?? title)|\(stream.fileIdx ?? -1)"
                            guard !seenKeys.contains(key) else { continue }
                            seenKeys.insert(key)
                            let subtitleURLs = (stream.subtitles ?? []).compactMap { sub -> String? in
                                guard let raw = sub.url?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
                                return raw
                            }
                            found.append(StreamLink(title: title, url: playableURL, quality: quality, size: sizeText, source: sourceName, infoHash: stream.infoHash, fileIndex: stream.fileIdx, subtitleURLs: subtitleURLs, isExternalURL: isExternalOnly))
                        }

                        if !found.isEmpty, isCurrentStreamSearch(searchItemID) {
                            streamLinks = sortedStreamLinks(found)
                            let scopedText = activeProviderFilter == "All Providers" ? "all addons" : activeProviderFilter
                            lastStreamMessage = "Found \(streamLinks.count) link(s) so far. Still scanning \(scopedText)…"
                        }
                    } catch {
                        if let urlError = error as? URLError, urlError.code == .timedOut {
                            upsertSourceProviderStatus(provider: sourceName, state: .timeout, linkCount: max(0, found.count - addonStartCount), message: sourceName.lowercased().contains("mediafusion") ? "MediaFusion slow endpoint timed out after extended wait" : "timeout")
                        } else {
                            upsertSourceProviderStatus(provider: sourceName, state: .failed, linkCount: max(0, found.count - addonStartCount), message: "failed")
                        }
                        continue
                    }
                    }
                }
            }
            let addonLinkCount = max(0, found.count - addonStartCount)
            if sourceProviderStatus(for: sourceName)?.state == .timeout || sourceProviderStatus(for: sourceName)?.state == .failed {
                if addonLinkCount > 0 {
                    upsertSourceProviderStatus(provider: sourceName, state: .returnedLinks, linkCount: addonLinkCount, message: "returned \(addonLinkCount) link\(addonLinkCount == 1 ? "" : "s") with endpoint warnings")
                }
            } else if addonLinkCount > 0 {
                upsertSourceProviderStatus(provider: sourceName, state: .returnedLinks, linkCount: addonLinkCount, message: "returned \(addonLinkCount) link\(addonLinkCount == 1 ? "" : "s")")
            } else {
                upsertSourceProviderStatus(provider: sourceName, state: .noLinks, linkCount: 0, message: "no links")
            }
        }

        if activeProviderFilter != "All Providers",
           sourceProviderStatuses.allSatisfy({ !sourceProviderMatches(selection: activeProviderFilter, provider: $0.provider, manifestURL: $0.provider) }) {
            upsertSourceProviderStatus(provider: activeProviderFilter, state: .noLinks, linkCount: 0, message: "no matching configured provider")
        }

        let sorted = sortedStreamLinks(found)
        guard isCurrentStreamSearch(searchItemID) else { return sorted }
        streamLinks = sorted
        if sorted.isEmpty {
            let failureHint = addonFailures.isEmpty ? "" : " \(addonFailures.prefix(2).joined(separator: " "))"
            if activeProviderFilter != "All Providers" {
                lastStreamMessage = "No links found from \(activeProviderFilter). Try All Providers."
            } else {
                lastStreamMessage = "No stream links found for \(item.title) after \(attempts) stream endpoint checks.\(failureHint) For Torrentio/TorBox, add the actual configured manifest URL, not only the configure webpage, and make sure the addon returns stream.url/direct links."
            }
        } else {
            let playableCount = sorted.filter { $0.isDirectPlayable }.count
            let scopedText = activeProviderFilter == "All Providers" ? "all configured addons" : activeProviderFilter
            lastStreamMessage = "Found \(sorted.count) total link(s), \(playableCount) direct-playable, for \(item.title) from \(scopedText)."
        }
        return sorted
    }

    private func providerName(from rawManifest: String, manifest: StremioManifest?) -> String {
        manifest?.name ?? URL(string: rawManifest)?.host ?? rawManifest
    }

    private func providerCanonical(_ value: String) -> String {
        value.lowercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: "_", with: "")
    }

    private func isKnownSourceProvider(_ value: String) -> Bool {
        let canonical = providerCanonical(value)
        return ["mediafusion", "torrentio", "comet", "debrido", "torbox"].contains { canonical.contains($0) }
    }

    private func sourceProviderMatches(selection: String, provider: String, manifestURL: String) -> Bool {
        let cleanSelection = selection.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanSelection.isEmpty, cleanSelection != "All Providers" else { return true }
        let providerKey = providerCanonical(provider + " " + manifestURL)
        if cleanSelection == "Other detected providers" { return !isKnownSourceProvider(providerKey) }
        return providerKey.contains(providerCanonical(cleanSelection))
    }

    private func sourceProviderStatus(for provider: String) -> SourceProviderRequestStatus? {
        sourceProviderStatuses.first { $0.provider.caseInsensitiveCompare(provider) == .orderedSame }
    }

    private func upsertSourceProviderStatus(provider rawProvider: String, state: SourceProviderRequestState, linkCount: Int, message: String) {
        let provider = rawProvider.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "Unknown Provider" : rawProvider
        let status = SourceProviderRequestStatus(provider: provider, state: state, linkCount: linkCount, message: message)
        if let index = sourceProviderStatuses.firstIndex(where: { $0.provider.caseInsensitiveCompare(provider) == .orderedSame }) {
            sourceProviderStatuses[index] = status
        } else {
            sourceProviderStatuses.append(status)
        }
    }

    private func isCurrentStreamSearch(_ itemID: String) -> Bool {
        // v566 episode exact-link fix: episode rows use ids such as seriesId:season:episode
        // while selectedDetail remains the parent show id. Gating on selectedDetail?.id == itemID
        // blocks every episode stream update, leaving Source Intelligence stuck spinning.
        // activeStreamSearchItemID already prevents stale searches from overwriting newer ones.
        return activeStreamSearchItemID == itemID && selectedDetail != nil
    }

    private func clearStreamLinkState(statusMessage: String = "") {
        activeStreamSearchItemID = nil
        streamLinks = []
        sourceProviderStatuses = []
        alternateAudioSources = []
        selectedAlternateAudioSource = nil
        alternateAudioSyncOffsetMS = 0
        lastStreamMessage = statusMessage
    }

    private func manifestURLCandidates(from raw: String) -> [String] {
        // v96: Accept the real-world formats people paste from Stremio/Torrentio/TorBox:
        // - https://addon/config/manifest.json
        // - https://addon/configure
        // - https://addon/configure?...
        // - stremio://addon/config/manifest.json
        // - stremio://addon/configure
        // - stremio:///addon/config/manifest.json
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return [] }
        var candidates: [String] = []
        func add(_ value: String) {
            var trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { return }
            if trimmed.hasPrefix("stremio:///") { trimmed = "https://" + String(trimmed.dropFirst("stremio:///".count)) }
            if trimmed.hasPrefix("stremio://") { trimmed = "https://" + String(trimmed.dropFirst("stremio://".count)) }
            while trimmed.hasSuffix("/") { trimmed.removeLast() }
            guard !trimmed.isEmpty, !candidates.contains(trimmed) else { return }
            candidates.append(trimmed)
        }

        add(clean)

        let httpsClean: String
        if clean.hasPrefix("stremio:///") {
            httpsClean = "https://" + String(clean.dropFirst("stremio:///".count))
        } else if clean.hasPrefix("stremio://") {
            httpsClean = "https://" + String(clean.dropFirst("stremio://".count))
        } else {
            httpsClean = clean
        }
        let lower = httpsClean.lowercased()

        // If a configured manifest URL is embedded inside a copied text/link, extract it.
        if let range = httpsClean.range(of: #"https?://[^\s"'<>]+/manifest\.json"#, options: .regularExpression) {
            add(String(httpsClean[range]))
        }

        if lower.contains("/manifest.json?") || lower.contains("/manifest.json#") {
            if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
                add("\(scheme)://\(host)\(url.path)")
            }
        }

        if lower.hasSuffix("/manifest.json") {
            add(httpsClean)
        } else if lower.hasSuffix("/configure") {
            add(String(httpsClean.dropLast("/configure".count)) + "/manifest.json")
        } else if lower.contains("/configure?") || lower.contains("/configure#") {
            if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
                let pathWithoutConfigure = url.path.replacingOccurrences(of: "/configure", with: "")
                if !pathWithoutConfigure.isEmpty, pathWithoutConfigure != "/" {
                    add("\(scheme)://\(host)\(pathWithoutConfigure)/manifest.json")
                }
                add("\(scheme)://\(host)/manifest.json")
            }
        } else if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
            // If user pasted the configured addon base without manifest.json, try preserving its path first.
            if !url.path.isEmpty, url.path != "/" {
                add("\(scheme)://\(host)\(url.path)/manifest.json")
            }
            // Root addon fallback for links like https://torrentio.strem.fun/configure.
            add("\(scheme)://\(host)/manifest.json")
        }
        return candidates
    }

    private func normalizedStremioBase(from manifest: String) -> String {
        var base = manifest
        if base.lowercased().hasSuffix("/configure") { base.removeLast("/configure".count) }
        if base.hasSuffix("/manifest.json") { base.removeLast("/manifest.json".count) }
        if base.hasSuffix("manifest.json") { base.removeLast("manifest.json".count) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    private func catalogEndpointCandidates(base: URL, catalog: StremioCatalog) -> [URL] {
        // Stremio catalog endpoints are:
        //   /catalog/{type}/{id}.json
        //   /catalog/{type}/{id}/{extra}.json
        // where extra is optional but some addons require skip/search/genre. Try only protocol-valid forms.
        let baseString = base.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let type = catalog.type ?? "movie"
        let id = catalog.id ?? "popular"
        let encodedID = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? id
        let encodedType = type.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? type
        var extraCandidates: [String] = []

        func addExtra(_ extra: String?) {
            guard let extra else { return }
            let clean = extra.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, !extraCandidates.contains(clean) else { return }
            extraCandidates.append(clean)
        }

        // Common Stremio extras. skip=0 is the safest first page fallback.
        addExtra("skip=0")
        addExtra("genre=popular")
        addExtra("search=")

        catalog.extraRequired?.forEach { required in
            if required.lowercased() == "skip" { addExtra("skip=0") }
            else if required.lowercased() == "genre" { addExtra("genre=popular") }
            else if required.lowercased() == "search" { addExtra("search=") }
        }
        catalog.extra?.forEach { extra in
            let name = extra.name?.lowercased()
            if name == "skip" { addExtra("skip=0") }
            else if name == "genre" { addExtra("genre=\((extra.options?.first ?? "popular"))") }
            else if name == "search" { addExtra("search=") }
        }

        var strings = ["\(baseString)/catalog/\(encodedType)/\(encodedID).json"]
        strings.append(contentsOf: extraCandidates.map { extra in
            let encodedExtra = extra.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? extra
            return "\(baseString)/catalog/\(encodedType)/\(encodedID)/\(encodedExtra).json"
        })

        var urls: [URL] = []
        for string in strings {
            if let url = URL(string: string), !urls.contains(url) { urls.append(url) }
        }
        return urls
    }

    private func catalogSearchEndpointCandidates(base: URL, catalog: StremioCatalog, query: String) -> [URL] {
        let baseString = base.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let type = catalog.type ?? "movie"
        let id = catalog.id ?? "popular"
        let encodedID = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? id
        let encodedType = type.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? type
        let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? query

        var extras: [String] = []
        func add(_ value: String) {
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, !extras.contains(clean) else { return }
            extras.append(clean)
        }

        // Stremio search extra convention. Try query first so Search does not
        // fall back to only the first/default page of a catalog.
        add("search=\(encodedQuery)")
        add("search=\(encodedQuery)&skip=0")

        catalog.extraRequired?.forEach { required in
            if required.lowercased() == "search" { add("search=\(encodedQuery)") }
            if required.lowercased() == "skip" { add("search=\(encodedQuery)&skip=0") }
        }
        catalog.extra?.forEach { extra in
            let name = extra.name?.lowercased()
            if name == "search" { add("search=\(encodedQuery)") }
            if name == "skip" { add("search=\(encodedQuery)&skip=0") }
        }

        var strings = extras.map { extra in
            "\(baseString)/catalog/\(encodedType)/\(encodedID)/\(extra).json"
        }
        // Last fallback: some catalogs expose searchable/default results from the base catalog endpoint.
        strings.append("\(baseString)/catalog/\(encodedType)/\(encodedID).json")

        var urls: [URL] = []
        for string in strings {
            if let url = URL(string: string), !urls.contains(url) { urls.append(url) }
        }
        return urls
    }


    private func addonKind(from manifest: StremioManifest) -> String {
        let hasCatalogs = !(manifest.catalogs ?? []).isEmpty
        let hasStream = (manifest.resources ?? []).contains { $0.name?.lowercased() == "stream" }
        if hasCatalogs && hasStream { return "catalog+stream" }
        if hasCatalogs { return "catalog" }
        if hasStream { return "stream-only" }
        return "metadata-only"
    }

    private func expandedStreamTypes(typeCandidates: [String], manifest: StremioManifest?) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !clean.isEmpty, !ordered.contains(clean) else { return }
            ordered.append(clean)
        }
        typeCandidates.forEach { add($0) }
        manifest?.types?.forEach { add($0) }
        manifest?.resources?.filter { $0.name?.lowercased() == "stream" }.forEach { resource in
            resource.types?.forEach { add($0) }
        }
        add("movie")
        add("series")
        return ordered
    }

    private func parsedQuality(from title: String) -> String {
        let lower = title.lowercased()
        if lower.contains("2160") || lower.contains("4k") || lower.contains("uhd") { return "4K" }
        if lower.contains("1080") { return "1080p" }
        if lower.contains("720") { return "720p" }
        if lower.contains("480") { return "480p" }
        return "Auto"
    }

    private func parsedSizeText(from title: String) -> String? {
        let pattern = #"(?i)(\d+(?:\.\d+)?)\s*(GB|MB)"#
        guard let regex = try? NSRegularExpression(pattern: pattern), let match = regex.firstMatch(in: title, range: NSRange(title.startIndex..., in: title)), let range = Range(match.range, in: title) else { return nil }
        return String(title[range])
    }

    private func findXtreamVODLinks(for item: MediaItem) async -> [StreamLink] {
        // v318: disabled. Xtream Codes is Live TV channels only for now.
        return []
    }

    private func normalizedXtreamServer(_ raw: String) -> String? {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.isEmpty { return nil }
        if !value.lowercased().hasPrefix("http://") && !value.lowercased().hasPrefix("https://") { value = "http://" + value }
        if value.lowercased().contains("/player_api.php") {
            value = value.replacingOccurrences(of: "/player_api.php", with: "", options: .caseInsensitive)
        }
        while value.hasSuffix("/") { value.removeLast() }
        guard URL(string: value) != nil else { return nil }
        return value
    }

    private func findXtreamMovieLinks(item: MediaItem, base: String, queryUser: String, queryPass: String, pathUser: String, pathPass: String) async -> [StreamLink] {
        // v318: disabled. Xtream Codes Movies/Shows are removed; Live TV channels only.
        return []
    }

    private func findXtreamSeriesLinks(item: MediaItem, base: String, queryUser: String, queryPass: String, pathUser: String, pathPass: String) async -> [StreamLink] {
        // v318: disabled. Xtream Codes Movies/Shows are removed; Live TV channels only.
        return []
    }

    private func fetchXtreamText(_ raw: String, maxBytes: Int) async -> String? {
        guard let url = URL(string: raw) else { return nil }
        do {
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,*/*", userAgent: "DebridChannels-tvOS/325", maxBytes: maxBytes, timeout: 45)
                guard (200...299).contains(plain.statusCode) else { return nil }
                return String(data: plain.data, encoding: .utf8)
            }
            let (data, response) = try await URLSession.shared.data(from: url)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            guard data.count <= maxBytes else { return nil }
            return String(data: data, encoding: .utf8)
        } catch {
            return nil
        }
    }

    private func bestXtreamMatches(in array: [[String: Any]], for item: MediaItem, nameKeys: [String]) -> [[String: Any]] {
        let target = normalizedTitleForMatching(item.title)
        let targetYear = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
        var scored: [(Int, [[String: Any]].Element)] = []
        for obj in array {
            let name = stringValue(obj, keys: nameKeys)
            let normalized = normalizedTitleForMatching(name)
            guard !normalized.isEmpty else { continue }
            var score = 0
            if normalized == target { score += 100 }
            if normalized.contains(target) || target.contains(normalized) { score += 45 }
            if !targetYear.isEmpty {
                let year = stringValue(obj, keys: ["year", "releaseDate", "releasedate"])
                if year.contains(targetYear) { score += 20 }
            }
            if score > 0 { scored.append((score, obj)) }
        }
        return scored.sorted { $0.0 > $1.0 }.map { $0.1 }
    }

    private func normalizedTitleForMatching(_ value: String) -> String {
        value.lowercased()
            .replacingOccurrences(of: "[^a-z0-9]+", with: " ", options: .regularExpression)
            .split(separator: " ")
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func cleanXtreamExtension(_ value: String, fallback: String) -> String {
        let clean = value.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ". /\n\r\t"))
        guard !clean.isEmpty, clean.range(of: "^[a-z0-9]+$", options: .regularExpression) != nil else { return fallback }
        return clean
    }

    private func stringValue(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let s = obj[key] as? String { return s.trimmingCharacters(in: .whitespacesAndNewlines) }
            if let n = obj[key] as? NSNumber { return n.stringValue }
            if let i = obj[key] as? Int { return String(i) }
        }
        return ""
    }

    private func intValue(_ obj: [String: Any], keys: [String]) -> Int {
        for key in keys {
            if let i = obj[key] as? Int { return i }
            if let n = obj[key] as? NSNumber { return n.intValue }
            if let s = obj[key] as? String, let i = Int(s.trimmingCharacters(in: .whitespacesAndNewlines)) { return i }
        }
        return 0
    }

    func findAlternateAudioSources(for item: MediaItem, currentURL: URL, preferredLanguage: String = "English") async -> [AlternateAudioSource] {
        await MainActor.run {
            alternateAudioSources = []
            selectedAlternateAudioSource = nil
        }
        let playable = streamLinks.filter { link in
            guard link.isDirectPlayable, let raw = link.url, let candidate = URL(string: raw) else { return false }
            return candidate.absoluteString != currentURL.absoluteString
        }
        let candidates = buildAlternateAudioCandidates(from: playable, preferredLanguage: preferredLanguage)
        await MainActor.run {
            alternateAudioSources = candidates
            if candidates.isEmpty {
                status = "No alternate playable copies with likely \(preferredLanguage) audio were found yet. Run Find Links first or add more providers."
            } else {
                status = "Found \(candidates.count) alternate audio candidate(s). Select one from Audio to keep the current video and use that copy as the audio source reference."
            }
        }
        return candidates
    }

    private func buildAlternateAudioCandidates(from links: [StreamLink], preferredLanguage: String) -> [AlternateAudioSource] {
        let lowerLanguage = preferredLanguage.lowercased()
        let languageTokens = [lowerLanguage, "english", " eng ", "[eng]", "(eng)", "multi", "dual", "aac", "ac3", "eac3", "dts"]
        var seen = Set<String>()
        let scored = links.compactMap { link -> (Int, AlternateAudioSource)? in
            guard let raw = link.url, !raw.isEmpty else { return nil }
            let combined = "\(link.title) \(link.quality) \(link.size) \(link.source)".lowercased()
            let languageScore = languageTokens.contains(where: { combined.contains($0.trimmingCharacters(in: .whitespacesAndNewlines)) || combined.contains($0) }) ? 0 : 2
            let qualityScore: Int
            if combined.contains("2160") || combined.contains("4k") || combined.contains("uhd") { qualityScore = 4 }
            else if combined.contains("1080") { qualityScore = 2 }
            else if combined.contains("720") { qualityScore = 1 }
            else { qualityScore = 3 }
            let confidence = languageScore == 0 ? "Likely \(preferredLanguage)" : "Playable copy — verify audio"
            let key = raw.lowercased()
            guard !seen.contains(key) else { return nil }
            seen.insert(key)
            return (languageScore * 10 + qualityScore, AlternateAudioSource(title: link.title, url: raw, quality: link.quality, source: link.source, confidence: confidence))
        }
        return scored.sorted { lhs, rhs in lhs.0 == rhs.0 ? lhs.1.title < rhs.1.title : lhs.0 < rhs.0 }.map(\.1).prefix(10).map { $0 }
    }

    func selectAlternateAudioSource(_ source: AlternateAudioSource?, for item: MediaItem) {
        selectedAlternateAudioSource = source
        alternateAudioSyncOffsetMS = storedAlternateAudioSyncOffset(for: item, source: source)
        if let source {
            status = "Alternate audio source selected: \(source.displayTitle). Use sync controls if the copy has a different intro/cut."
        } else {
            status = "Alternate audio source cleared. Playback is using the selected stream audio only."
        }
    }

    func adjustAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?, deltaMS: Int) {
        alternateAudioSyncOffsetMS += deltaMS
        saveAlternateAudioSyncOffset(for: item, source: source, offsetMS: alternateAudioSyncOffsetMS)
        status = "Alternate audio sync offset: \(alternateAudioSyncOffsetMS)ms."
    }

    func resetAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?) {
        alternateAudioSyncOffsetMS = 0
        saveAlternateAudioSyncOffset(for: item, source: source, offsetMS: 0)
        status = "Alternate audio sync reset to 0ms."
    }

    func storedAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?) -> Int {
        UserDefaults.standard.integer(forKey: alternateAudioSyncKey(for: item, source: source))
    }

    private func saveAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?, offsetMS: Int) {
        UserDefaults.standard.set(offsetMS, forKey: alternateAudioSyncKey(for: item, source: source))
    }

    private func alternateAudioSyncKey(for item: MediaItem, source: AlternateAudioSource?) -> String {
        let sourcePart = source?.url ?? "default"
        return "smartAltAudioSyncMS|\(item.id)|\(sourcePart.hashValue)"
    }

    private func sortedStreamLinks(_ links: [StreamLink]) -> [StreamLink] {
        let rank: [String: Int] = ["4K": 0, "1080p": 1, "720p": 2, "480p": 3, "Auto": 4]
        func nativePenalty(_ link: StreamLink) -> Int {
            guard let raw = link.url?.lowercased() else { return 9 }
            if raw.hasPrefix("magnet:") || link.infoHash != nil { return 8 }
            if link.isExternalURL { return 7 }
            if raw.contains(".m3u8") || raw.contains(".mp4") || raw.contains(".mov") || raw.contains(".m4v") { return 0 }
            if raw.contains(".mkv") || raw.contains("dts") || raw.contains("truehd") { return UniversalCodecSupport.vlcCompiledIn ? 1 : 4 }
            // Signed debrid/TorBox HTTP URLs often have no extension; keep them above magnet/browser links.
            return 2
        }
        return links.sorted { lhs, rhs in
            let lDirect = lhs.isDirectPlayable ? 0 : 1
            let rDirect = rhs.isDirectPlayable ? 0 : 1
            if lDirect != rDirect { return lDirect < rDirect }
            let lNative = nativePenalty(lhs)
            let rNative = nativePenalty(rhs)
            if lNative != rNative { return lNative < rNative }
            return (rank[lhs.quality] ?? 9) < (rank[rhs.quality] ?? 9)
        }
    }

    private func streamTypeCandidates(for item: MediaItem) -> [String] {
        // v576: restore the fast Source Intelligence path. Do not cross-query movie
        // endpoints for shows or series endpoints for movies; that doubled requests and
        // made movies feel like they were stalled while slow addons timed out.
        if item.seasonNumber != nil && item.episodeNumber != nil { return ["series"] }
        let lower = item.type.lowercased()
        if lower.contains("series") || lower.contains("show") { return ["series"] }
        return ["movie"]
    }

    private func streamIDCandidates(for item: MediaItem) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !ordered.contains(trimmed) else { return }
            ordered.append(trimmed)
        }

        // v575: exact episode endpoints first. Parent-series fallback is handled by
        // streamIDFallbackCandidates(for:) with strict S/E title filtering so
        // multi-season shows still load without showing neighboring episodes.
        if let season = item.seasonNumber, let episode = item.episodeNumber {
            add(item.id)
            let parts = item.id.split(separator: ":").map(String.init)
            let exactSuffix = ":\(season):\(episode)"
            if !item.id.hasSuffix(exactSuffix) {
                if parts.count >= 1 {
                    let base = streamParentBaseID(from: item.id)
                    add("\(base):\(season):\(episode)")
                }
                if item.id.hasPrefix("tt") == false, let range = item.id.range(of: "tt[0-9]+", options: .regularExpression) {
                    add("\(String(item.id[range])):\(season):\(episode)")
                }
            }
            return ordered
        }

        add(item.id)
        let parts = item.id.split(separator: ":").map(String.init)
        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            add("tmdb:\(parts[2])")
            add(parts[2])
        }
        if let colon = item.id.split(separator: ":").first { add(String(colon)) }
        if item.id.hasPrefix("tt") == false, let range = item.id.range(of: "tt[0-9]+", options: .regularExpression) {
            add(String(item.id[range]))
        }
        return ordered
    }

    private func streamParentBaseID(from rawID: String) -> String {
        let parts = rawID.split(separator: ":").map(String.init)
        if parts.count >= 5, Int(parts[parts.count - 1]) != nil, Int(parts[parts.count - 2]) != nil {
            return parts.dropLast(2).joined(separator: ":")
        }
        if parts.count >= 3, parts[0].lowercased() == "tmdb" { return parts.prefix(3).joined(separator: ":") }
        return parts.first ?? rawID
    }

    private func streamIDFallbackCandidates(for item: MediaItem) -> [String] {
        // v576: do not query the parent series endpoint for an episode click.
        // Some addons answer parent-series stream requests with all seasons/episodes,
        // which caused Source Intelligence to show wrong episodes and also slowed the
        // search path. Exact episode endpoints are the only safe requests here.
        guard item.seasonNumber != nil, item.episodeNumber != nil else { return [] }
        return []
    }

    private func streamTitleMatchesRequestedEpisode(_ title: String, item: MediaItem, requireExplicitEpisodeToken: Bool = false) -> Bool {
        guard let season = item.seasonNumber, let episode = item.episodeNumber else { return true }
        let lower = title.lowercased()
        let paddedSeason = String(format: "%02d", season)
        let paddedEpisode = String(format: "%02d", episode)
        let exactTokens = [
            "s\(paddedSeason)e\(paddedEpisode)",
            "s\(season)e\(episode)",
            "s\(paddedSeason).e\(paddedEpisode)",
            "s\(paddedSeason)-e\(paddedEpisode)",
            "s\(paddedSeason)_e\(paddedEpisode)",
            "s\(paddedSeason) ep\(paddedEpisode)",
            "s\(paddedSeason) ep \(paddedEpisode)",
            "\(season)x\(paddedEpisode)",
            "\(season)x\(episode)",
            "season \(season) episode \(episode)",
            "season.\(season).episode.\(episode)",
            "season_\(season)_episode_\(episode)",
            "episode \(episode)"
        ]
        if exactTokens.contains(where: { lower.contains($0) }) { return true }

        // v577: reject season-wide packs for episode clicks. Some addons answer exact
        // episode endpoints with parent/season pack titles like "Show.S01.2160p".
        // Those must not appear in Source Intelligence for S01E01/S01E02/etc.
        let seasonOnlyPatterns = [
            "\\bs0?\(season)\\b",
            "\\bseason[ ._-]*0?\(season)\\b",
            "\\b0?\(season)[ ._-]*season\\b"
        ]
        for pattern in seasonOnlyPatterns {
            if lower.range(of: pattern, options: .regularExpression) != nil { return false }
        }

        let otherEpisodePatterns = [
            #"\bs\d{1,2}[ ._-]*e\d{1,3}\b"#,
            #"\b\d{1,2}x\d{1,3}\b"#,
            #"\bseason[ ._-]*\d{1,2}[ ._-]*episode[ ._-]*\d{1,3}\b"#,
            #"\bepisode[ ._-]*\d{1,3}\b"#
        ]
        for pattern in otherEpisodePatterns {
            if lower.range(of: pattern, options: .regularExpression) != nil { return false }
        }

        // Exact episode endpoints may return generic titles with no S/E token; keep
        // those because the request id is exact. Explicit wrong season/episode titles
        // and season-wide packs are rejected above.
        return !requireExplicitEpisodeToken
    }

    func playableURLs(from links: [StreamLink], selected: StreamLink? = nil) -> [URL] {
        var urls: [URL] = []
        func add(_ raw: String?) {
            guard let url = Self.makePlayableURL(from: raw) else { return }
            if !urls.contains(url) { urls.append(url) }
        }
        add(selected?.isDirectPlayable == true ? selected?.url : nil)
        for link in links where link.isDirectPlayable { add(link.url) }
        return urls
    }

    static func makePlayableURL(from raw: String?) -> URL? {
        guard var value = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        value = value.replacingOccurrences(of: " ", with: "%20")
        guard value.lowercased().hasPrefix("http") else { return nil }
        return URL(string: value)
    }

    func subtitleURLs(from link: StreamLink?) -> [URL] {
        (link?.subtitleURLs ?? []).compactMap { URL(string: $0) }
    }

    private func vodCastWallRestoredPlaybackItem(from item: MediaItem) -> MediaItem {
        guard item.type.lowercased() != "live" else { return item }
        guard let detail = selectedDetail else { return item }
        let sameTitle = detail.title.trimmingCharacters(in: .whitespacesAndNewlines).localizedCaseInsensitiveCompare(item.title.trimmingCharacters(in: .whitespacesAndNewlines)) == .orderedSame
        let sameID = detail.id == item.id
        let sameSeriesEpisode = detail.id == item.id || item.id.hasPrefix(detail.id) || detail.id.hasPrefix(item.id)
        guard sameID || sameTitle || sameSeriesEpisode else { return item }
        guard (!detail.castMembers.isEmpty && item.castMembers.isEmpty) || (!detail.cast.isEmpty && item.cast.isEmpty) else { return item }

        var restored = item
        if restored.castMembers.isEmpty { restored.castMembers = detail.castMembers }
        if restored.cast.isEmpty { restored.cast = detail.cast }
        if restored.directors.isEmpty { restored.directors = detail.directors }
        return restored
    }

    func playFirstDirectStream(for item: MediaItem) async {
        // v621: if the viewer previously chose a working source, start it immediately instead
        // of waiting for a full addon scan. This restores fast Infuse/external handoff and
        // respects low-bandwidth source choices. A fresh scan is still available via Find Links.
        if let cached = LastPlaybackLinkCacheManager.shared.entry(for: item),
           let cachedURL = Self.makePlayableURL(from: cached.url) {
            startPlayback(item: item, url: cachedURL, alternates: [], subtitles: [], label: "Resuming last selected source for \(item.title): \(cached.quality) • \(cached.size) • \(cached.source).")
            return
        }

        let links = await findStreams(for: item)
        let remembered = LastPlaybackLinkCacheManager.shared.entry(for: item)?.url
        let rememberedDirect = links.first { link in
            guard link.isDirectPlayable, let url = Self.makePlayableURL(from: link.url) else { return false }
            return url.absoluteString == remembered
        }
        if let direct = rememberedDirect ?? links.first(where: { $0.isDirectPlayable }), let url = Self.makePlayableURL(from: direct.url) {
            LastPlaybackLinkCacheManager.shared.save(item: item, link: direct, url: url)
            let rememberedText = rememberedDirect == nil ? "" : " Resuming the last selected source."
            startPlayback(item: item, url: url, alternates: playableURLs(from: links, selected: direct), subtitles: subtitleURLs(from: direct), label: "Playing \(direct.quality) link for \(item.title).\(rememberedText) Audio/subtitle metadata: \(direct.title) • \(direct.size). Adaptive fallback is armed across all direct links.")
        } else if let preview = directPreviewURL(for: item) {
            // v84 real-player test path: when a catalog has no direct movie links yet, PLAY still opens
            // the custom Debrid player with the direct preview/sample URL so the full VOD surface can be tested.
            startPlayback(item: item, url: preview, alternates: [], subtitles: [], label: "No resolved VOD link found, opening direct preview stream in the custom Debrid player for testing.")
        } else {
            let torrentCount = links.filter { $0.url?.lowercased().hasPrefix("magnet:") == true || $0.infoHash != nil }.count
            let externalCount = links.filter { $0.isExternalURL }.count
            status = links.isEmpty ? lastStreamMessage : "Links found, but none are direct-playable yet. \(torrentCount) torrent/infoHash and \(externalCount) browser/external link(s) need a configured debrid direct stream URL from the addon."
        }
    }

    func startPlayback(item: MediaItem, url: URL, alternates: [URL] = [], subtitles: [URL] = [], label: String, sourceTrackSummary: RealMediaTrackSummary? = nil) {
        playbackItem = vodCastWallRestoredPlaybackItem(from: item)
        let ordered = ([url] + alternates).reduce(into: [URL]()) { acc, candidate in
            if !acc.contains(candidate) { acc.append(candidate) }
        }
        playbackFallbackURLs = ordered
        playbackSubtitleURLs = subtitles
        playbackLinkLabel = label
        playbackSourceTrackSummary = sourceTrackSummary
        playbackURL = url
        status = label
    }

    func advanceToNextPlaybackURL(after failedURL: URL) -> URL? {
        guard let index = playbackFallbackURLs.firstIndex(of: failedURL) else { return nil }
        let nextIndex = playbackFallbackURLs.index(after: index)
        guard playbackFallbackURLs.indices.contains(nextIndex) else { return nil }
        let next = playbackFallbackURLs[nextIndex]
        playbackURL = next
        status = "Current stream failed; retrying alternate \(nextIndex + 1) of \(playbackFallbackURLs.count)."
        return next
    }

    func closePlayer() {
        playbackURL = nil
        playbackItem = nil
        playbackFallbackURLs = []
        playbackSubtitleURLs = []
        playbackLinkLabel = ""
        playbackSourceTrackSummary = nil
    }

    func openDetail(_ item: MediaItem, pushCurrent: Bool = false) {
        if selectedDetail?.id != item.id {
            clearStreamLinkState()
        }
        if pushCurrent, let current = selectedDetail {
            detailBackStack.append(current)
        } else if !pushCurrent {
            detailBackStack.removeAll()
        }
        selectedDetail = item
        hydrateCreditsForOpenDetail(item)
    }

    private func hydrateCreditsForOpenDetail(_ item: MediaItem) {
        detailCreditsTask?.cancel()
        detailCreditsTask = Task { [weak self] in
            guard let self else { return }
            guard let enriched = await self.detailItemWithCredits(for: item), !Task.isCancelled else { return }
            guard self.selectedDetail?.id == item.id else { return }
            self.selectedDetail = enriched
            if let index = self.detailBackStack.lastIndex(where: { $0.id == item.id }) {
                self.detailBackStack[index] = enriched
            }
        }
    }

    private func detailItemWithCredits(for item: MediaItem) async -> MediaItem? {
        var enriched = item

        // v497: Before the popup/VOD overlay renders, fill missing Stremio/Cinemeta
        // artwork and descriptions from TMDB when the user has provided a key. This keeps
        // Search -> Details -> VOD metadata consistent without making TMDB required.
        if let metadata = await tmdbMetadataFallbackForDetail(enriched) {
            enriched = metadata
        }

        if let tmdbCredits = await tmdbCreditsForDetail(enriched) {
            enriched.castMembers = tmdbCredits.castMembers
            if !tmdbCredits.cast.isEmpty { enriched.cast = tmdbCredits.cast }
            if !tmdbCredits.directors.isEmpty { enriched.directors = tmdbCredits.directors }
        }

        // v616: Only show Explore the Franchise when TMDB confirms this movie belongs
        // to a real collection. Never use same-genre/popular fallback rows here.
        if let collectionItems = await tmdbCollectionItemsForDetail(enriched), !collectionItems.isEmpty {
            enriched.franchiseItems = collectionItems
        }

        if !enriched.cast.isEmpty || !enriched.directors.isEmpty || !enriched.castMembers.isEmpty || !enriched.franchiseItems.isEmpty {
            return enriched
        }

        let type = normalizedStremioType(item.type)
        let idCandidates = streamIDCandidates(for: item)
        for rawManifest in prioritizedManifestURLsWithMetadataFallback() {
            for candidate in manifestURLCandidates(from: rawManifest) {
                guard let manifestURL = URL(string: candidate) else { continue }
                let base = normalizedStremioBase(from: manifestURL.absoluteString)
                for mediaID in idCandidates {
                    guard let encodedID = mediaID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let metaURL = URL(string: "\(base)/meta/\(type)/\(encodedID).json") else { continue }
                    do {
                        var request = URLRequest(url: metaURL, timeoutInterval: 8)
                        request.setValue("application/json", forHTTPHeaderField: "Accept")
                        request.setValue("DebridChannels-tvOS/469 CreditsHydration", forHTTPHeaderField: "User-Agent")
                        let (data, response) = try await URLSession.shared.data(for: request)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioMetaResponse.self, from: data)
                        guard let meta = decoded.meta else { continue }
                        let cast = Array((meta.cast ?? []).prefix(8))
                        let directors = Array((meta.directors ?? []).prefix(3))
                        guard !cast.isEmpty || !directors.isEmpty else { continue }
                        enriched.cast = cast
                        enriched.directors = directors
                        if enriched.castMembers.isEmpty {
                            enriched.castMembers = cast.map { CastMember(name: $0, role: nil, imageURL: nil) }
                        }
                        return enriched
                    } catch {
                        continue
                    }
                }
            }
        }
        return enriched == item ? nil : enriched
    }


    private func tmdbMetadataFallbackForDetail(_ item: MediaItem) async -> MediaItem? {
        let key = UserDefaults.standard.string(forKey: "tmdbApiKey")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !key.isEmpty else { return nil }
        let query = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard query.count >= 2, let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        let kind = normalizedStremioType(item.type) == "series" ? "tv" : "movie"
        let yearDigits = item.year.filter { $0.isNumber }
        let yearParam = (!yearDigits.isEmpty && kind == "movie") ? "&year=\(yearDigits)" : ((!yearDigits.isEmpty) ? "&first_air_date_year=\(yearDigits)" : "")
        guard let url = URL(string: "https://api.themoviedb.org/3/search/\(kind)?api_key=\(key)&query=\(encoded)&include_adult=false\(yearParam)") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 8)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/497 MetadataFallback", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let decoded = try JSONDecoder().decode(TMDBListResponse.self, from: data)
            guard let result = decoded.results.first else { return nil }
            var updated = item
            let overview = result.overview?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            if !overview.isEmpty && (updated.description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || updated.description.localizedCaseInsensitiveContains("No description")) {
                updated.description = overview
            }
            if updated.posterURL == nil, let poster = result.poster_path { updated.posterURL = "https://image.tmdb.org/t/p/original\(poster)" }
            if updated.landscapeURL == nil, let backdrop = result.backdrop_path { updated.landscapeURL = "https://image.tmdb.org/t/p/original\(backdrop)" }
            if (updated.rating.isEmpty || updated.rating == "—"), let vote = result.vote_average, vote > 0 { updated.rating = String(format: "%.1f", vote) }
            let date = kind == "tv" ? result.first_air_date : result.release_date
            if updated.year.isEmpty, let y = date?.prefix(4), !y.isEmpty { updated.year = String(y) }
            return updated == item ? nil : updated
        } catch {
            return nil
        }
    }

    private func tmdbCollectionItemsForDetail(_ item: MediaItem) async -> [MediaItem]? {
        let key = UserDefaults.standard.string(forKey: "tmdbApiKey")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !key.isEmpty else { return nil }
        guard normalizedStremioType(item.type) != "series" else { return nil }
        guard let target = await tmdbTargetForCredits(item, apiKey: key), target.kind == "movie" else { return nil }
        guard let detailURL = URL(string: "https://api.themoviedb.org/3/movie/\(target.id)?api_key=\(key)") else { return nil }
        do {
            var detailRequest = URLRequest(url: detailURL, timeoutInterval: 8)
            detailRequest.setValue("application/json", forHTTPHeaderField: "Accept")
            detailRequest.setValue("DebridChannels-tvOS/616 TMDBCollectionDetail", forHTTPHeaderField: "User-Agent")
            let (detailData, detailResponse) = try await URLSession.shared.data(for: detailRequest)
            if let http = detailResponse as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let movieDetail = try JSONDecoder().decode(TMDBMovieDetailWithCollection.self, from: detailData)
            guard let collectionID = movieDetail.belongs_to_collection?.id else { return nil }
            guard let collectionURL = URL(string: "https://api.themoviedb.org/3/collection/\(collectionID)?api_key=\(key)") else { return nil }
            var collectionRequest = URLRequest(url: collectionURL, timeoutInterval: 8)
            collectionRequest.setValue("application/json", forHTTPHeaderField: "Accept")
            collectionRequest.setValue("DebridChannels-tvOS/616 TMDBCollection", forHTTPHeaderField: "User-Agent")
            let (collectionData, collectionResponse) = try await URLSession.shared.data(for: collectionRequest)
            if let http = collectionResponse as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let decoded = try JSONDecoder().decode(TMDBCollectionResponse.self, from: collectionData)
            let parts = (decoded.parts ?? []).sorted { lhs, rhs in
                let ly = (lhs.release_date ?? "").prefix(10)
                let ry = (rhs.release_date ?? "").prefix(10)
                if ly != ry { return ly < ry }
                return lhs.id < rhs.id
            }
            guard parts.count > 1 else { return nil }
            let currentKey = "tmdb:movie:\(target.id)"
            var mapped: [MediaItem] = []
            mapped.reserveCapacity(parts.count)
            for part in parts {
                let title = (part.title ?? part.name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !title.isEmpty else { continue }
                let mediaID = "tmdb:movie:\(part.id)"
                let year = String((part.release_date ?? "").prefix(4))
                let poster = part.poster_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                let backdrop = part.backdrop_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                let rating = (part.vote_average ?? 0) > 0 ? String(format: "%.1f", part.vote_average ?? 0) : ""
                let logo = await tmdbMovieLogoURL(movieID: part.id, apiKey: key)
                mapped.append(MediaItem(
                    id: mediaID,
                    title: title,
                    year: year,
                    type: "movie",
                    catalog: decoded.name ?? "Franchise",
                    description: part.overview ?? "",
                    genres: item.genres,
                    rating: rating,
                    posterURL: poster,
                    landscapeURL: backdrop ?? poster,
                    logoURL: logo,
                    addonName: item.addonName,
                    addonIconURL: item.addonIconURL
                ))
            }
            // Hide the shelf unless TMDB's collection actually contains the current movie.
            guard mapped.contains(where: { $0.id == currentKey }) else { return nil }
            return mapped
        } catch {
            return nil
        }
    }

    private func tmdbMovieLogoURL(movieID: Int, apiKey key: String) async -> String? {
        if let fanart = await fetchFanartArtwork(kind: "movie", tmdbID: movieID, tmdbApiKey: key), let fanartLogo = fanart.logoURL {
            return fanartLogo
        }
        guard let url = URL(string: "https://api.themoviedb.org/3/movie/\(movieID)/images?api_key=\(key)&include_image_language=en,null") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 6)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/618 TMDBMovieLogos", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let decoded = try JSONDecoder().decode(TMDBMovieImagesResponse.self, from: data)
            let logos = decoded.logos ?? []
            let preferred = logos.sorted { lhs, rhs in
                let lhsEnglish = (lhs.iso_639_1 ?? "") == "en"
                let rhsEnglish = (rhs.iso_639_1 ?? "") == "en"
                if lhsEnglish != rhsEnglish { return lhsEnglish }
                let lhsVotes = lhs.vote_count ?? 0
                let rhsVotes = rhs.vote_count ?? 0
                if lhsVotes != rhsVotes { return lhsVotes > rhsVotes }
                return (lhs.vote_average ?? 0) > (rhs.vote_average ?? 0)
            }.first
            guard let path = preferred?.file_path, !path.isEmpty else { return nil }
            return "https://image.tmdb.org/t/p/original\(path)"
        } catch {
            return nil
        }
    }

    private func tmdbCreditsForDetail(_ item: MediaItem) async -> (castMembers: [CastMember], cast: [String], directors: [String])? {
        let key = UserDefaults.standard.string(forKey: "tmdbApiKey")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !key.isEmpty else { return nil }
        guard let target = await tmdbTargetForCredits(item, apiKey: key) else { return nil }
        guard let url = URL(string: "https://api.themoviedb.org/3/\(target.kind)/\(target.id)/credits?api_key=\(key)") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 8)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/469 TMDBCredits", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let decoded = try JSONDecoder().decode(TMDBCreditsResponse.self, from: data)
            let castMembers = Array((decoded.cast ?? []).compactMap { member -> CastMember? in
                guard let name = member.name?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { return nil }
                let role = member.character?.trimmingCharacters(in: .whitespacesAndNewlines)
                let image = member.profile_path.map { "https://image.tmdb.org/t/p/original\($0)" }
                return CastMember(name: name, role: (role?.isEmpty == false ? role : nil), imageURL: image)
            }.prefix(10))
            let directors = Array((decoded.crew ?? []).filter { ($0.job ?? "").localizedCaseInsensitiveContains("director") }.compactMap { $0.name }.prefix(3))
            guard !castMembers.isEmpty || !directors.isEmpty else { return nil }
            return (castMembers, castMembers.map { $0.name }, directors)
        } catch {
            return nil
        }
    }

    private func tmdbTargetForCredits(_ item: MediaItem, apiKey: String) async -> (kind: String, id: String, source: String, tvdbID: Int?)? {
        let parts = item.id.split(separator: ":").map(String.init)
        if parts.count >= 3, parts[0].lowercased() == "tmdb" {
            let kind = (parts[1].lowercased() == "tv" || normalizedStremioType(item.type) == "series") ? "tv" : "movie"
            return (kind, parts[2], "tmdb-id", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""))
        }
        if let explicitTMDB = item.tmdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !explicitTMDB.isEmpty {
            let kind = normalizedStremioType(item.type) == "series" ? "tv" : "movie"
            return (kind, explicitTMDB, "catalog-tmdbId", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""))
        }
        let parsedTMDB = Self.extractedTrailerTMDBId(from: item.id)
        if !parsedTMDB.isEmpty {
            let kind = normalizedStremioType(item.type) == "series" ? "tv" : "movie"
            return (kind, parsedTMDB, "parsed-tmdb-id", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""))
        }
        var candidates = streamIDCandidates(for: item)
        if let explicitIMDb = item.imdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !explicitIMDb.isEmpty {
            candidates.insert(explicitIMDb, at: 0)
        }
        if let imdb = candidates.first(where: { $0.lowercased().hasPrefix("tt") }) {
            guard let encoded = imdb.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                  let url = URL(string: "https://api.themoviedb.org/3/find/\(encoded)?api_key=\(apiKey)&external_source=imdb_id") else { return nil }
            do {
                var request = URLRequest(url: url, timeoutInterval: 8)
                request.setValue("application/json", forHTTPHeaderField: "Accept")
                let (data, response) = try await URLSession.shared.data(for: request)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
                let decoded = try JSONDecoder().decode(TMDBFindResponse.self, from: data)
                if normalizedStremioType(item.type) == "series", let id = decoded.tv_results?.compactMap({ $0.id }).first {
                    return ("tv", String(id), "imdb-find", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""))
                }
                if let id = decoded.movie_results?.compactMap({ $0.id }).first { return ("movie", String(id), "imdb-find", nil) }
                if let id = decoded.tv_results?.compactMap({ $0.id }).first { return ("tv", String(id), "imdb-find", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")) }
            } catch {
                print("[Fanart] TMDB find error \(item.title) imdb=\(imdb): \(error.localizedDescription)")
            }
        }
        if let searched = await tmdbTargetByTitleYear(item, apiKey: apiKey) { return searched }
        return nil
    }

    private func tmdbTargetByTitleYear(_ item: MediaItem, apiKey: String) async -> (kind: String, id: String, source: String, tvdbID: Int?)? {
        let title = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty,
              let encodedTitle = title.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else { return nil }
        let kind = normalizedStremioType(item.type) == "series" ? "tv" : "movie"
        let year = item.year.filter { $0.isNumber }
        var query = "api_key=\(apiKey)&query=\(encodedTitle)&include_adult=false&page=1"
        if !year.isEmpty {
            query += kind == "tv" ? "&first_air_date_year=\(year)" : "&year=\(year)"
        }
        guard let url = URL(string: "https://api.themoviedb.org/3/search/\(kind)?\(query)") else { return nil }
        do {
            var request = URLRequest(url: url, timeoutInterval: 8)
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/708 FanartTitleLookup", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            let decoded = try JSONDecoder().decode(TMDBListResponse.self, from: data)
            let titleKey = normalizedMatchText(title)
            let ranked = decoded.results.sorted { lhs, rhs in
                let lhsTitle = normalizedMatchText(lhs.title ?? lhs.name ?? "")
                let rhsTitle = normalizedMatchText(rhs.title ?? rhs.name ?? "")
                let lhsExact = lhsTitle == titleKey
                let rhsExact = rhsTitle == titleKey
                if lhsExact != rhsExact { return lhsExact && !rhsExact }
                let lhsYear = String((lhs.release_date ?? lhs.first_air_date ?? "").prefix(4))
                let rhsYear = String((rhs.release_date ?? rhs.first_air_date ?? "").prefix(4))
                if !year.isEmpty && lhsYear != rhsYear { return lhsYear == year }
                return (lhs.vote_average ?? 0) > (rhs.vote_average ?? 0)
            }
            guard let match = ranked.first else { return nil }
            return (kind, String(match.id), "title-year-search", Int(item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""))
        } catch {
            print("[Fanart] TMDB title lookup error \(item.title): \(error.localizedDescription)")
            return nil
        }
    }

    func closeDetail() {
        if let previous = detailBackStack.popLast() {
            clearStreamLinkState()
            selectedDetail = previous
        } else {
            selectedDetail = nil
            detailCreditsTask?.cancel()
            detailCreditsTask = nil
            clearStreamLinkState()
            // v485: after closing a Movies/Shows/Home popup, return focus to the
            // catalog quick-panel rail instead of letting the top menu reclaim focus.
            topMenuFocusLocked = false
            contentFocusToken += 1
        }
    }
    private func dedupedManifestURLs(_ urls: [String]) -> [String] {
        var output: [String] = []
        var seenCandidates = Set<String>()
        for raw in urls {
            let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty else { continue }
            let candidates = manifestURLCandidates(from: clean).map { $0.lowercased() }
            if candidates.contains(where: { seenCandidates.contains($0) }) { continue }
            output.append(clean)
            seenCandidates.formUnion(candidates)
        }
        return output
    }

    private func persistManifestPriority(_ message: String) {
        manifestURLs = dedupedManifestURLs(manifestURLs)
        if manifestURLs.isEmpty { manifestURLs = [coreMetadataManifestURL] }
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        // v467: Apply ordering to already-loaded rows immediately. This prevents
        // Cinemeta from staying visually pinned at the top until the next reload.
        rows = prioritizedRowsForDisplay(rows)
        status = message
    }

    private func normalizedCatalogName(_ value: String?) -> String {
        (value ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: "_", with: "")
    }

    private func manifestPriorityNameMap() -> [String: Int] {
        var map: [String: Int] = [:]
        for (index, url) in prioritizedManifestURLsWithMetadataFallback().enumerated() {
            if let identity = addonIdentities[url] {
                let key = normalizedCatalogName(identity.name)
                if !key.isEmpty, map[key] == nil { map[key] = index }
            }
            if url.lowercased().contains("v3-cinemeta.strem.io") {
                map["cinemeta"] = index
                map["cinemetasearch"] = index
            }
        }
        return map
    }

    private func priorityIndex(for row: MediaRow, using map: [String: Int]) -> Int {
        let addonKey = normalizedCatalogName(row.items.first?.addonName)
        if let priority = map[addonKey] { return priority }
        let rowKey = normalizedCatalogName(row.title)
        if rowKey.contains("cinemeta") { return map["cinemeta"] ?? 9000 }
        if addonKey.contains("cinemeta") { return map["cinemeta"] ?? 9000 }
        // Unknown/user rows should remain above fallback rows but preserve their
        // existing relative order through Swift's stable enumerated sort below.
        return 1000
    }

    private func prioritizedRowsForDisplay(_ inputRows: [MediaRow]? = nil) -> [MediaRow] {
        let sourceRows = inputRows ?? rows
        let priorityMap = manifestPriorityNameMap()
        return sourceRows.enumerated().sorted { left, right in
            let leftPriority = priorityIndex(for: left.element, using: priorityMap)
            let rightPriority = priorityIndex(for: right.element, using: priorityMap)
            if leftPriority == rightPriority { return left.offset < right.offset }
            return leftPriority < rightPriority
        }.map { $0.element }
    }

    private func prioritizedManifestURLsWithMetadataFallback() -> [String] {
        var ordered = dedupedManifestURLs(manifestURLs)
        if !ordered.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
            ordered.append(coreMetadataManifestURL)
        }
        return ordered
    }

    func moveManifestURLToTop(_ urlString: String) {
        guard let index = manifestURLs.firstIndex(of: urlString), index > 0 else { return }
        let moved = manifestURLs.remove(at: index)
        manifestURLs.insert(moved, at: 0)
        persistManifestPriority("Catalog priority updated. Search and Home catalog loading use this saved order first.")
    }

    func moveManifestURLUp(_ urlString: String) {
        guard let index = manifestURLs.firstIndex(of: urlString), index > 0 else { return }
        manifestURLs.swapAt(index, index - 1)
        persistManifestPriority("Catalog moved up. Higher rows are searched and loaded first.")
    }

    func moveManifestURLDown(_ urlString: String) {
        guard let index = manifestURLs.firstIndex(of: urlString), index < manifestURLs.count - 1 else { return }
        manifestURLs.swapAt(index, index + 1)
        persistManifestPriority("Catalog moved down. Higher rows keep priority.")
    }

    func moveManifestURLToBottom(_ urlString: String) {
        guard let index = manifestURLs.firstIndex(of: urlString), index < manifestURLs.count - 1 else { return }
        let moved = manifestURLs.remove(at: index)
        manifestURLs.append(moved)
        persistManifestPriority("Catalog priority updated. This catalog is now lower priority.")
    }

    func addManifestURL(_ urlString: String) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, URL(string: clean) != nil else {
            status = "Enter a valid Stremio manifest URL before adding."
            return
        }
        let candidateSet = Set(manifestURLCandidates(from: clean))
        let alreadyExists = manifestURLs.contains { existing in
            existing == clean || !Set(manifestURLCandidates(from: existing)).isDisjoint(with: candidateSet)
        }
        guard !alreadyExists else {
            status = "That Stremio JSON/addon is already in your list."
            return
        }
        manifestURLs.append(clean)
        persistManifestPriority("Added Stremio addon at the bottom. Use Move Up or Move to Top to give it search/catalog priority.")
    }

    func removeManifestURL(_ urlString: String) {
        manifestURLs.removeAll { $0 == urlString }
        if manifestURLs.isEmpty { manifestURLs = [coreMetadataManifestURL] }
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Removed Stremio JSON/addon."
    }

    func loadAllManifests() async {
        let urls = prioritizedManifestURLsWithMetadataFallback()
        guard !urls.isEmpty else {
            status = "Add at least one Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }

        let previousRows = rows
        var mergedRows: [MediaRow] = []
        var loadedCatalogNames: [String] = []
        var streamOnlyNames: [String] = []
        var failedNames: [String] = []

        // v96 rule: stream-only addons can NEVER wipe or replace Home/catalog rows.
        // Catalog rows only change when at least one provider returns real metas.
        for url in urls {
            do {
                let result = try await fetchRows(from: url)
                switch result.kind {
                case "stream-only":
                    streamOnlyNames.append(result.name)
                default:
                    if result.rows.isEmpty {
                        failedNames.append("\(result.name): no catalog items")
                    } else {
                        mergedRows.append(contentsOf: result.rows)
                        loadedCatalogNames.append(result.name)
                    }
                }
            } catch {
                failedNames.append("\(url): \(error.localizedDescription)")
            }
        }

        let tmdbRows = await tmdbDefaultCatalogRows(apiKey: UserDefaults.standard.string(forKey: "tmdbApiKey") ?? "")
        if !tmdbRows.isEmpty {
            let existing = Set(mergedRows.map { $0.id })
            mergedRows.append(contentsOf: tmdbRows.filter { !existing.contains($0.id) })
            loadedCatalogNames.append("TMDB default shelves")
        }

        if !mergedRows.isEmpty {
            rows = prioritizedRowsForDisplay(mergedRows)
            let streamNote = streamOnlyNames.isEmpty ? "" : " Stream-only addons active for Find Links: \(streamOnlyNames.joined(separator: ", "))."
            status = "Loaded \(mergedRows.count) catalog row(s) from \(loadedCatalogNames.joined(separator: ", ")).\(streamNote)"
        } else {
            rows = previousRows.isEmpty ? Self.demoRows() : previousRows
            let streamNote = streamOnlyNames.isEmpty ? "" : " Stream-only addons still active for Find Links: \(streamOnlyNames.joined(separator: ", "))."
            let failNote = failedNames.isEmpty ? "" : " Catalog providers returned no rows or failed: \(failedNames.prefix(3).joined(separator: "; "))."
            status = "No catalog rows were replaced; keeping existing Home rows.\(streamNote)\(failNote) Add a real catalog manifest like Cinemeta for Home rows; Torrentio/TorBox are usually stream-only."
        }
    }

    func requestLazyCatalogRowRefresh(row: MediaRow, selectedItem: MediaItem?, reason: String) {
        guard shouldLazyRefreshCatalogRow(row, selectedItem: selectedItem) else { return }
        let key = canonicalCatalogRowRefreshKey(row)
        catalogRowRefreshDebounceTasks[key]?.cancel()
        catalogRowRefreshDebounceTasks[key] = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 420_000_000)
            await refreshCatalogRowIfNeeded(row: row, selectedItem: selectedItem, reason: reason)
        }
    }

    private func shouldLazyRefreshCatalogRow(_ row: MediaRow, selectedItem: MediaItem?) -> Bool {
        if row.items.isEmpty { return true }
        let candidates = Array(([selectedItem].compactMap { $0 } + row.items.prefix(8)).prefix(9))
        if candidates.contains(where: { item in
            let poster = item.posterURL?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let landscape = item.landscapeURL?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            return poster.isEmpty && landscape.isEmpty
        }) { return true }
        if row.items.count < 5 {
            let key = canonicalCatalogRowRefreshKey(row)
            if let last = catalogRowRefreshLastAttempt[key] {
                return Date().timeIntervalSince(last) > 600
            }
            return true
        }
        return false
    }

    private func refreshCatalogRowIfNeeded(row: MediaRow, selectedItem: MediaItem?, reason: String) async {
        let key = canonicalCatalogRowRefreshKey(row)
        let now = Date()
        if let last = catalogRowRefreshLastAttempt[key], now.timeIntervalSince(last) < catalogRowRefreshCooldown {
            status = "Catalog row refresh skipped due to cooldown: \(row.title)"
            print("catalog row refresh skipped due to cooldown", key, reason)
            return
        }
        guard catalogRowRefreshInFlight.count < catalogRowRefreshMaxConcurrent else {
            status = "Catalog row refresh deferred; refresh queue is busy."
            print("catalog row refresh skipped because concurrent limit is active", key, reason)
            return
        }
        guard !catalogRowRefreshInFlight.contains(key) else { return }
        catalogRowRefreshLastAttempt[key] = now
        catalogRowRefreshInFlight.insert(key)
        status = "Catalog row refresh requested: \(row.title)"
        print("catalog row refresh requested", key, reason)
        defer { catalogRowRefreshInFlight.remove(key) }

        var refreshedRowCount = 0
        for url in prioritizedManifestURLsWithMetadataFallback() {
            do {
                let result = try await fetchRows(from: url)
                guard result.kind != "stream-only", !result.rows.isEmpty else { continue }
                if let replacement = matchingRefreshRow(for: row, selectedItem: selectedItem, in: result.rows) {
                    replaceCatalogRow(row, with: replacement)
                    refreshedRowCount = 1
                    status = "Catalog row refresh succeeded: \(replacement.title)"
                    print("catalog row refresh succeeded", key, "refreshed row count", refreshedRowCount)
                    break
                }
            } catch {
                print("catalog row refresh provider failed", key, url, error.localizedDescription)
                continue
            }
        }
        if refreshedRowCount == 0 {
            status = "Catalog row refresh failed or returned no newer row: \(row.title)"
            print("catalog row refresh failed", key, "refreshed row count", refreshedRowCount)
        }
    }

    private func replaceCatalogRow(_ displayedRow: MediaRow, with replacement: MediaRow) {
        let displayedKey = canonicalCatalogRowRefreshKey(displayedRow)
        var didReplace = false
        rows = rows.map { existing in
            if canonicalCatalogRowRefreshKey(existing) == displayedKey || existing.title == displayedRow.title {
                didReplace = true
                return replacement
            }
            return existing
        }
        if !didReplace {
            rows.append(replacement)
        }
        rows = prioritizedRowsForDisplay(rows)
    }

    private func matchingRefreshRow(for displayedRow: MediaRow, selectedItem: MediaItem?, in candidateRows: [MediaRow]) -> MediaRow? {
        let displayedKey = canonicalCatalogRowRefreshKey(displayedRow)
        if let exact = candidateRows.first(where: { canonicalCatalogRowRefreshKey($0) == displayedKey }) {
            return exact
        }
        if let titleMatch = candidateRows.first(where: { $0.title.caseInsensitiveCompare(displayedRow.title) == .orderedSame }) {
            return titleMatch
        }
        if let selectedItem {
            return candidateRows.first(where: { candidate in
                candidate.items.contains { $0.id == selectedItem.id || ($0.title == selectedItem.title && $0.type == selectedItem.type) }
            })
        }
        return nil
    }

    private func canonicalCatalogRowRefreshKey(_ row: MediaRow) -> String {
        row.id
            .replacingOccurrences(of: "-slot-overlay-series", with: "")
            .replacingOccurrences(of: "-slot-overlay-movie", with: "")
            .replacingOccurrences(of: "-slot-overlay", with: "")
    }

    private func fetchRows(from urlString: String) async throws -> (name: String, kind: String, rows: [MediaRow]) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidates = manifestURLCandidates(from: clean)
        var manifestURL: URL? = nil
        var manifestData: Data? = nil
        for candidate in candidates {
            guard let url = URL(string: candidate) else { continue }
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                manifestURL = url
                manifestData = data
                break
            } catch {
                continue
            }
        }
        guard let manifestURL, let manifestData else { throw URLError(.badURL) }
        let manifest = try JSONDecoder().decode(StremioManifest.self, from: manifestData)
        let base = URL(string: normalizedStremioBase(from: manifestURL.absoluteString)) ?? manifestURL.deletingLastPathComponent()
        let catalogs = (manifest.catalogs ?? [])
        let addonName = manifest.name ?? manifestURL.host ?? "Stremio"
        let addonIconURL = Self.highest(manifest.logo ?? manifest.icon)
        await MainActor.run {
            self.addonIdentities[urlString] = StremioAddonIdentity(name: addonName, iconURL: addonIconURL, kind: self.addonKind(from: manifest))
        }
        var builtRows: [MediaRow] = []
        if catalogs.isEmpty {
            // Stream-only addons such as Torrentio/TorBox are valid and should remain saved/active even though
            // they do not create Home rows. Their /stream endpoints are used from Find Links on Cinemeta items.
            return (manifest.name ?? manifestURL.host ?? "stream addon", addonKind(from: manifest), [])
        }
        for catalog in catalogs {
            let type = catalog.type ?? "movie"
            let id = catalog.id ?? "popular"
            var response: CatalogResponse? = nil
            for catalogURL in catalogEndpointCandidates(base: base, catalog: catalog) {
                do {
                    let (catalogData, httpResponse) = try await URLSession.shared.data(from: catalogURL)
                    if let http = httpResponse as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    response = try JSONDecoder().decode(CatalogResponse.self, from: catalogData)
                    break
                } catch {
                    continue
                }
            }
            if let response {
                var items: [MediaItem] = []
                let tmdbKey = UserDefaults.standard.string(forKey: "tmdbApiKey") ?? ""
                for meta in (response.metas ?? []) {
                    let baseItem = MediaItem(
                        id: meta.id ?? UUID().uuidString,
                        tmdbId: meta.tmdbId,
                        imdbId: meta.imdbId,
                        tvdbId: meta.tvdbId,
                        title: meta.name ?? "Untitled",
                        year: Self.firstYear(from: meta.releaseInfo),
                        type: meta.type ?? type,
                        catalog: catalog.name ?? id.capitalized,
                        description: meta.description ?? "No description available yet.",
                        genres: Array((meta.genres ?? [type.capitalized, "Cinema"]).prefix(3)),
                        rating: meta.imdbRating ?? "—",
                        posterURL: Self.highest(meta.poster),
                        landscapeURL: Self.highest(meta.background ?? meta.poster),
                        logoURL: Self.highest(meta.logo),
                        previewURL: Self.previewURL(from: meta),
                        addonName: addonName,
                        addonIconURL: addonIconURL,
                        seasonNumber: nil,
                        episodeNumber: nil,
                        cast: Array((meta.cast ?? []).prefix(8)),
                        directors: Array((meta.directors ?? []).prefix(3))
                    )
                    items.append(await applyPremiumFanartArtworkIfResolvable(to: baseItem, tmdbApiKey: tmdbKey))
                }
                if !items.isEmpty {
                    builtRows.append(MediaRow(id: "\(type)-\(id)-\(manifest.name ?? "manifest")", title: catalog.name ?? id.capitalized, items: items))
                }
            }
        }
        return (manifest.name ?? "manifest", addonKind(from: manifest), builtRows)
    }


    func fetchSeriesEpisodes(for item: MediaItem) async -> [MediaItem] {
        let lowerType = item.type.lowercased()
        guard lowerType.contains("series") || lowerType.contains("show") else { return [] }
        status = "Loading seasons and episodes for \(item.title)…"
        let idCandidates = streamIDCandidates(for: item)
        var episodes: [MediaItem] = []
        var seen = Set<String>()

        for rawManifest in prioritizedManifestURLsWithMetadataFallback() {
            for candidate in manifestURLCandidates(from: rawManifest) {
                guard let manifestURL = URL(string: candidate) else { continue }
                let base = normalizedStremioBase(from: manifestURL.absoluteString)
                for seriesID in idCandidates {
                    guard let encodedID = seriesID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let metaURL = URL(string: "\(base)/meta/series/\(encodedID).json") else { continue }
                    do {
                        let (data, response) = try await URLSession.shared.data(from: metaURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioMetaResponse.self, from: data)
                        let meta = decoded.meta
                        for video in meta?.videos ?? [] {
                            guard let videoID = video.id?.trimmingCharacters(in: .whitespacesAndNewlines), !videoID.isEmpty else { continue }
                            guard seen.insert(videoID).inserted else { continue }
                            let season = video.season ?? 1
                            let episode = video.episode ?? (episodes.filter { $0.seasonNumber == season }.count + 1)
                            let episodeTitle = video.title ?? video.name ?? "Episode \(episode)"
                            let episodeDateCandidates = Self.episodeDateStrings(from: video)
                            let airDate = episodeDateCandidates.first
                            episodes.append(MediaItem(
                                id: videoID,
                                title: "\(item.title)  S\(String(format: "%02d", season))E\(String(format: "%02d", episode))  \(episodeTitle)",
                                year: item.year,
                                type: "series",
                                catalog: "Season \(season)",
                                description: video.overview ?? video.description ?? item.description,
                                genres: item.genres,
                                rating: item.rating,
                                // v569: episode cards need real episode stills/previews, not the repeated
                                // parent show backdrop.  Prefer Stremio/TMDB video thumbnails anywhere the
                                // episode UI asks for poster, landscape, or preview art.
                                posterURL: Self.highest(video.thumbnail ?? item.posterURL),
                                landscapeURL: Self.highest(video.thumbnail ?? item.landscapeURL ?? item.posterURL),
                                logoURL: item.logoURL,
                                previewURL: Self.highest(video.thumbnail ?? video.url ?? video.src ?? video.source),
                                addonName: item.addonName,
                                addonIconURL: item.addonIconURL,
                                seasonNumber: season,
                                episodeNumber: episode,
                                cast: item.cast,
                                directors: item.directors,
                                airDateString: airDate,
                                episodeDateStrings: episodeDateCandidates
                            ))
                        }
                        if !episodes.isEmpty {
                            let sorted = episodes.sorted { lhs, rhs in
                                if (lhs.seasonNumber ?? 0) != (rhs.seasonNumber ?? 0) { return (lhs.seasonNumber ?? 0) < (rhs.seasonNumber ?? 0) }
                                return (lhs.episodeNumber ?? 0) < (rhs.episodeNumber ?? 0)
                            }
                            status = "Loaded \(sorted.count) episode(s) for \(item.title)."
                            return sorted
                        }
                    } catch {
                        continue
                    }
                }
            }
        }
        status = "No episode list was returned for \(item.title). The selected metadata/addon must expose /meta/series/{id}.json videos."
        return []
    }

    // v621: Search result cards may be TMDB/Cinemeta artwork shells. Before Source
    // Intelligence scans streams, upgrade them to the best resolver identity available
    // so configured Stremio addons are always queried with IMDb/Cinemeta/addon ids.
    func resolverReadyStreamItem(for item: MediaItem, tmdbApiKey: String) async -> MediaItem {
        await searchHydratedDetailItem(for: item, query: item.title, tmdbApiKey: tmdbApiKey)
    }

    // v621: app-open/resume verified episode alert scan. tvOS cannot run this while
    // force-closed, so we scan followed shows whenever the app launches/resumes.
    func rememberFollowedShow(_ item: MediaItem) {
        let key = Self.followedShowKey(for: item)
        var snapshots = followedShowSnapshotMap()
        snapshots[key] = FollowedShowSnapshot(item: item)
        persistFollowedShowSnapshotMap(snapshots)
    }

    func forgetFollowedShow(_ item: MediaItem) {
        let key = Self.followedShowKey(for: item)
        var snapshots = followedShowSnapshotMap()
        snapshots.removeValue(forKey: key)
        persistFollowedShowSnapshotMap(snapshots)
    }

    private func followedShowSnapshotMap() -> [String: FollowedShowSnapshot] {
        guard let data = UserDefaults.standard.data(forKey: followedShowSnapshotsKey),
              let decoded = try? JSONDecoder().decode([String: FollowedShowSnapshot].self, from: data) else { return [:] }
        return decoded
    }

    private func persistFollowedShowSnapshotMap(_ snapshots: [String: FollowedShowSnapshot]) {
        guard let data = try? JSONEncoder().encode(snapshots) else { return }
        UserDefaults.standard.set(data, forKey: followedShowSnapshotsKey)
    }

    @MainActor
    func runFollowedEpisodeAlertScan(reason: String) async -> [NewEpisodeAlertHit] {
        let report = await runFollowedEpisodeAlertScanReport(reason: reason)
        return report.hits
    }

    @MainActor
    func runFollowedEpisodeAlertScanReport(reason: String) async -> NewEpisodeAlertScanReport {
        let recentWindowDays = 7
        let raw = UserDefaults.standard.string(forKey: "followedShowIds") ?? ""
        let followed = Set(raw.split(separator: "|").map(String.init).filter { !$0.isEmpty })
        var report = NewEpisodeAlertScanReport(recentWindowDays: recentWindowDays, followedKeysCount: followed.count)
        guard !followed.isEmpty else { return report }
        let all = rows.flatMap { $0.items }
        let visibleMatches = all.filter { followed.contains(Self.followedShowKey(for: $0)) }
        let snapshots = followedShowSnapshotMap()
        var followedItems: [MediaItem] = []
        var seenShowKeys = Set<String>()
        for show in visibleMatches {
            let key = Self.followedShowKey(for: show)
            if seenShowKeys.insert(key).inserted { followedItems.append(show) }
        }
        for key in followed where !seenShowKeys.contains(key) {
            if let snapshot = snapshots[key] {
                followedItems.append(snapshot.mediaItem)
                seenShowKeys.insert(key)
            }
        }
        report.followedShowsMatchedInLoadedRows = visibleMatches.count
        guard !followedItems.isEmpty else {
            status = "Episode alert scan (\(reason)): followed shows will be checked after catalogs load."
            return report
        }
        var hits: [NewEpisodeAlertHit] = []
        for show in followedItems.prefix(30) {
            report.showsChecked += 1
            report.metadataFetchAttempted = true
            let episodes = await fetchSeriesEpisodes(for: show)
            report.episodesFetchedCount += episodes.count
            if !episodes.isEmpty { report.metadataFetchSuccessCount += 1 }
            let eligibility = Self.bestEpisodeInRecentWindow(from: episodes, days: recentWindowDays)
            report.missingDateCount += eligibility.missingDateCount
            report.dateParseSuccessCount += eligibility.parseSuccessCount
            report.dateParseFailedCount += eligibility.parseFailedCount
            if let newest = eligibility.newestParsedDate, report.newestParsedDate == "None" || newest > report.newestParsedDate {
                report.newestParsedDate = newest
                report.newestRawDateStringSeen = eligibility.newestRawDateStringSeen ?? "None"
            }
            guard let eligible = eligibility.eligible else { continue }
            let episode = eligible.episode
            report.recentEpisodeDetected = true
            if eligible.dateKey == Self.todayKey() { report.newerTodayEpisodeDetected = true }
            if report.newestEligibleEpisodeDate == "None" || eligible.dateKey > report.newestEligibleEpisodeDate {
                report.newestEligibleEpisodeDate = eligible.dateKey
            }
            let showKey = Self.followedShowKey(for: show)
            let episodeKey = Self.episodeAlertProgressKey(showKey: showKey, episode: episode, dateKey: eligible.dateKey)
            report.newestDetectedEpisodeKey = episodeKey
            let lastAlertedKey = Self.lastAlertedEpisodeKey(forShowKey: showKey)
            let lastAlerted = UserDefaults.standard.string(forKey: lastAlertedKey) ?? ""
            if !lastAlerted.isEmpty { report.lastAlertedEpisodeKeyForShow = lastAlerted }
            guard lastAlerted.isEmpty || episodeKey > lastAlerted else {
                report.alreadyAlertedCount += 1
                report.suppressedDuplicateCount += 1
                if episodeKey == lastAlerted { report.suppressedSameEpisodeCount += 1 }
                continue
            }
            let alertKey = "episodeAlertShown::\(showKey)::\(episode.id)"
            guard !UserDefaults.standard.bool(forKey: alertKey) else {
                report.eligibleButConsumedCount += 1
                report.suppressedDuplicateCount += 1
                continue
            }
            hits.append(NewEpisodeAlertHit(alertKey: alertKey, show: show, episode: episode))
            let source = [show.addonName, show.catalog].compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }.first(where: { !$0.isEmpty }) ?? "Unknown"
            report.hitSourceSummaries.append("\(show.title): \(source)")
        }
        report.hits = hits
        report.alertQueuedCount = hits.count
        report.returnedAlertHits = hits.count
        status = hits.isEmpty ? "Episode alert scan (\(reason)): no verified new episodes today." : "Episode alert scan (\(reason)): found \(hits.count) new alert(s)."
        return report
    }

    func markEpisodeAlertConsumed(_ hit: NewEpisodeAlertHit) {
        UserDefaults.standard.set(true, forKey: hit.alertKey)
        markEpisodeAlertPresented(hit)
    }

    func markEpisodeAlertPresented(_ hit: NewEpisodeAlertHit) {
        let showKey = Self.followedShowKey(for: hit.show)
        let rawDate = Self.alertEpisodeDateString(for: hit.episode)
        let parsedDate = Self.parseEpisodeAirDate(rawDate).map(Self.episodeDateKey) ?? rawDate
        let episodeKey = Self.episodeAlertProgressKey(showKey: showKey, episode: hit.episode, dateKey: parsedDate)
        UserDefaults.standard.set(episodeKey, forKey: Self.lastAlertedEpisodeKey(forShowKey: showKey))
    }

    private static func followedShowKey(for item: MediaItem) -> String {
        "\(item.id)::\(item.catalog)::\(item.type)"
            .replacingOccurrences(of: "|", with: "_")
            .replacingOccurrences(of: "\n", with: " ")
    }

    private static func episodeAlertProgressKey(showKey: String, episode: MediaItem, dateKey: String) -> String {
        let season = String(format: "%04d", episode.seasonNumber ?? 0)
        let number = String(format: "%04d", episode.episodeNumber ?? 0)
        return "\(showKey)::D\(dateKey)::S\(season)::E\(number)"
            .replacingOccurrences(of: "|", with: "_")
            .replacingOccurrences(of: "\n", with: " ")
    }

    private static func lastAlertedEpisodeKey(forShowKey showKey: String) -> String {
        "episodeAlertLastAlerted::\(showKey)"
    }

    private static func todayKey() -> String {
        let f = DateFormatter()
        f.calendar = Calendar.current
        f.timeZone = .current
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: Date())
    }

    private static func firstEpisodeDateString(from video: StremioVideo) -> String? {
        episodeDateStrings(from: video).first
    }

    private static func episodeDateStrings(from video: StremioVideo) -> [String] {
        ([video.released, video.firstAired, video.airDate, video.premiereDate, video.release_date, video.first_aired, video.air_date] + video.additionalEpisodeDateStrings.map { Optional($0) })
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    private static func bestEpisodeInRecentWindow(from episodes: [MediaItem], days: Int) -> (eligible: (episode: MediaItem, dateKey: String)?, newestRawDateStringSeen: String?, newestParsedDate: String?, missingDateCount: Int, parseSuccessCount: Int, parseFailedCount: Int) {
        let calendar = Calendar.current
        let todayStart = calendar.startOfDay(for: Date())
        let windowStart = calendar.date(byAdding: .day, value: -(max(days, 1) - 1), to: todayStart) ?? todayStart
        let tomorrowStart = calendar.date(byAdding: .day, value: 1, to: todayStart) ?? Date()
        var newestRawDateStringSeen: String? = nil
        var newestParsedDate: String? = nil
        var missingDateCount = 0
        var parseSuccessCount = 0
        var parseFailedCount = 0
        let dated = episodes.compactMap { ep -> (MediaItem, Date, String)? in
            let raw = Self.alertEpisodeDateString(for: ep)
            guard !raw.isEmpty else {
                missingDateCount += 1
                return nil
            }
            guard let date = parseEpisodeAirDate(raw) else {
                parseFailedCount += 1
                return nil
            }
            parseSuccessCount += 1
            let localDay = calendar.startOfDay(for: date)
            let dateKey = episodeDateKey(localDay)
            if newestParsedDate == nil || dateKey > (newestParsedDate ?? "") {
                newestParsedDate = dateKey
                newestRawDateStringSeen = raw
            }
            guard localDay >= windowStart, localDay < tomorrowStart else { return nil }
            return (ep, localDay, dateKey)
        }
        let eligible = dated.sorted { lhs, rhs in
            if lhs.1 != rhs.1 { return lhs.1 > rhs.1 }
            let ls = lhs.0.seasonNumber ?? 0, rs = rhs.0.seasonNumber ?? 0
            if ls != rs { return ls > rs }
            return (lhs.0.episodeNumber ?? 0) > (rhs.0.episodeNumber ?? 0)
        }.first.map { (episode: $0.0, dateKey: $0.2) }
        return (eligible, newestRawDateStringSeen, newestParsedDate, missingDateCount, parseSuccessCount, parseFailedCount)
    }

    private static func alertEpisodeDateString(for episode: MediaItem) -> String {
        ([episode.airDateString] + episode.episodeDateStrings.map { Optional($0) })
            .compactMap { $0?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .first { !$0.isEmpty } ?? ""
    }

    private static func episodeDateKey(_ date: Date) -> String {
        let f = DateFormatter()
        f.calendar = Calendar.current
        f.timeZone = .current
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }

    private static func parseEpisodeAirDate(_ raw: String?) -> Date? {
        guard let value = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        let fractionalISO = ISO8601DateFormatter()
        fractionalISO.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = fractionalISO.date(from: value) { return d }
        let iso = ISO8601DateFormatter()
        if let d = iso.date(from: value) { return d }
        for format in ["yyyy-MM-dd", "yyyy/MM/dd", "MMM d, yyyy", "MMMM d, yyyy"] {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.timeZone = .current
            f.dateFormat = format
            if let d = f.date(from: value) { return d }
        }
        return nil
    }

    private static func sendEpisodeNotification(show: MediaItem, episode: MediaItem) {
        let season = episode.seasonNumber.map { "S\($0)" } ?? ""
        let ep = episode.episodeNumber.map { "E\($0)" } ?? ""
        let message = "\(show.title) \(season)\(ep) is available today."
        #if os(tvOS)
        // tvOS does not expose UNMutableNotificationContent.title/body/sound the same way iOS does.
        // Keep the app-open/resume scanner active and log the verified alert hit; the in-app Details alert UI remains the tvOS-safe presentation path.
        print("New Episode Alert: \(message)")
        #else
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            guard granted else { return }
            let content = UNMutableNotificationContent()
            content.title = "New Episode Alert"
            content.body = message
            content.sound = .default
            let request = UNNotificationRequest(identifier: "episode_alert_\(show.id)_\(episode.id)_\(todayKey())", content: content, trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false))
            center.add(request)
        }
        #endif
    }

    func loadManifest(urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else {
            status = "Enter a valid Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let result = try await fetchRows(from: clean)
            if result.rows.isEmpty {
                status = result.kind == "stream-only" ? "Added stream-only addon \(result.name). It will work in Find Links but does not create Home rows." : "No catalog rows returned from \(result.name). Existing rows kept."
            } else {
                rows = result.rows
                status = "Loaded \(result.rows.count) rows from \(result.name)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo, text.count >= 4 else { return "2026" }
        return String(text.prefix(4))
    }

    static func previewURL(from meta: StremioMeta) -> String? {
        if let direct = meta.previewVideo, direct.hasPrefix("http") { return direct }
        if let direct = meta.preview, direct.hasPrefix("http") { return direct }
        if let direct = meta.trailer, direct.hasPrefix("http") { return direct }
        if let video = meta.videos?.first(where: { ($0.url ?? $0.src ?? $0.source ?? "").hasPrefix("http") }) {
            return video.url ?? video.src ?? video.source
        }
        // Some Stremio manifests expose YouTube trailer IDs; those are kept as metadata only
        // because Internal player needs a direct playable video URL.
        return nil
    }

    static func highest(_ url: String?) -> String? {
        PremiumArtworkURL.upgraded(url)
    }

    static func demoRows() -> [MediaRow] {
        let items: [MediaItem] = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "movie", catalog: "Featured", description: "A temporary small-town sheriff uncovers a violent mystery after a bank robbery exposes a deeper conspiracy.", genres: ["Action", "Crime", "Thriller"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
            MediaItem(id: "apex", title: "APEX", year: "2026", type: "movie", catalog: "Featured", description: "A climber enters a hidden cave system and finds the rescue mission was never about saving him.", genres: ["Adventure", "Thriller"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
            MediaItem(id: "red", title: "RED SIGNAL", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators through a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "BLUE FALL", year: "2026", type: "movie", catalog: "Featured", description: "A detective wakes in a fractured digital city with one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "circle", title: "THE CIRCLE", year: "2026", type: "movie", catalog: "Featured", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "cinema", title: "CENTRAL CINEMA", year: "2026", type: "movie", catalog: "Featured", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "THE LOST PATH", year: "2026", type: "movie", catalog: "Featured", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "STORMLINE", year: "2026", type: "movie", catalog: "Featured", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "night", title: "NIGHT RUN", year: "2026", type: "movie", catalog: "Featured", description: "A driver with no name carries the wrong package across the city before sunrise.", genres: ["Action", "Neo-Noir"], rating: "7.4", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "harbor", title: "HARBOR BLACK", year: "2026", type: "series", catalog: "Featured", description: "A dockside murder opens a case that reaches every powerful family in the city.", genres: ["Series", "Crime"], rating: "7.6", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed())),
            MediaRow(id: "shows", title: "Shows", items: items.map { item in var copy = item; copy.type = "series"; return copy })
        ]
    }
}
