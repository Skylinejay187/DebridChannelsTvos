import Foundation
import SwiftUI
import UIKit
import AVFoundation
import QuartzCore

#if canImport(KSPlayer)
import KSPlayer
#endif

// Phase 12 final extraction: KSPlayer, FFmpeg option construction, display matching,
// render-surface ownership, track handling, and subtitle-layer promotion live under PlaybackKit.

#if os(tvOS)
@available(tvOS 11.2, *)
enum DebridTVOSDisplayMatchCoordinator {
    private static var lastAppliedSignature: String = ""
    private static var pendingLiveWorkItem: DispatchWorkItem? = nil

    private static func keyWindow() -> UIWindow? {
        if let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first(where: { $0.isKeyWindow }) {
            return window
        }
        return UIApplication.shared.windows.first(where: { $0.isKeyWindow }) ?? UIApplication.shared.windows.first
    }

    private static func apply(_ criteria: AVDisplayCriteria?, signature: String, source: String) {
        guard let window = keyWindow() else { return }
        let manager = window.avDisplayManager
        DispatchQueue.main.async {
            guard lastAppliedSignature != signature || criteria != nil else { return }
            manager.preferredDisplayCriteria = criteria
            lastAppliedSignature = signature
            if criteria != nil {
                print("[DebridChannels][DisplayMatch] applied \(source) \(signature)")
            } else {
                print("[DebridChannels][DisplayMatch] reset")
            }
        }
    }

    private static func inferredFrameRate(from value: String) -> Double? {
        let lower = value.lowercased()
        if lower.contains("23.976") || lower.contains("23_976") || lower.contains("24000/1001") { return 24000.0 / 1001.0 }
        if lower.contains("24fps") || lower.contains(" 24 ") || lower.contains(".24.") { return 24.0 }
        if lower.contains("25fps") || lower.contains(" 25 ") || lower.contains(".25.") { return 25.0 }
        if lower.contains("29.97") || lower.contains("30000/1001") { return 30000.0 / 1001.0 }
        if lower.contains("30fps") || lower.contains(" 30 ") || lower.contains(".30.") { return 30.0 }
        if lower.contains("50fps") || lower.contains(" 50 ") || lower.contains(".50.") { return 50.0 }
        if lower.contains("59.94") || lower.contains("60000/1001") { return 60000.0 / 1001.0 }
        if lower.contains("60fps") || lower.contains(" 60 ") || lower.contains(".60.") { return 60.0 }
        return nil
    }


    private static func normalizedLiveFrameRate(_ fps: Double) -> Double {
        if abs(fps - 25.0) < 0.25 { return 50.0 }
        if abs(fps - 30.0) < 0.35 { return 60.0 }
        if abs(fps - (30000.0 / 1001.0)) < 0.35 { return 60000.0 / 1001.0 }
        return fps
    }

    static func cancelPendingLiveDisplayMatch() {
        pendingLiveWorkItem?.cancel()
        pendingLiveWorkItem = nil
    }

    static func applyForLiveChannel(url: URL, hint: String) {
        cancelPendingLiveDisplayMatch()
        let combined = (url.absoluteString + " " + hint)
        let signature = "live|" + combined.lowercased()
        let workItem = DispatchWorkItem {
            let headers: [String: String] = [
                "User-Agent": "DebridChannels-tvOS/612 LiveDisplayMatch",
                "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
                "Accept-Encoding": "identity",
                "Connection": "keep-alive"
            ]
            let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])

            // First try the system-vended criteria. This is safest for HLS and channels that
            // already expose correct range/frame metadata to AVFoundation.
            let preferredCriteria = asset.preferredDisplayCriteria
            apply(preferredCriteria, signature: signature + "|preferred", source: "live-preferred")
            return

            asset.loadValuesAsynchronously(forKeys: ["tracks"]) {
                guard !(pendingLiveWorkItem?.isCancelled ?? true) else { return }
                var error: NSError?
                guard asset.statusOfValue(forKey: "tracks", error: &error) == .loaded else { return }

                let loadedCriteria = asset.preferredDisplayCriteria
                apply(loadedCriteria, signature: signature + "|loaded", source: "live-loaded")
                return
            }
        }
        pendingLiveWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: workItem)
    }

    static func applyForFullScreenVOD(url: URL, hint: String) {
        let combined = (url.absoluteString + " " + hint)
        let signature = combined.lowercased()
        guard !signature.contains("/trailers/") && !signature.contains("trailer") else { return }

        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/612 DisplayMatch",
            "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"
        ]
        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])

        // Apple's preferred path: use the AVAsset-vended criteria and assign it to the key
        // UIWindow's AVDisplayManager before KSPlayer starts drawing. This respects the user's
        // tvOS Match Frame Rate / Match Dynamic Range settings instead of forcing display modes.
        let preferredCriteria = asset.preferredDisplayCriteria
        apply(preferredCriteria, signature: signature, source: "asset-preferred")

        asset.loadValuesAsynchronously(forKeys: ["tracks"]) {
            var error: NSError?
            let status = asset.statusOfValue(forKey: "tracks", error: &error)
            guard status == .loaded else { return }

            let loadedCriteria = asset.preferredDisplayCriteria
            apply(loadedCriteria, signature: signature + "|loaded", source: "asset-loaded")
            return
        }
    }

    static func reset() {
        cancelPendingLiveDisplayMatch()
        apply(nil, signature: "", source: "reset")
        lastAppliedSignature = ""
    }
}
#endif

#if canImport(KSPlayer)
// v988 main-VOD cadence profile.
//
// Keep the memory-safe queue counts from v986, but use KSPNUVIO's stock A/V clock
// recovery again. The v987 custom recovery intentionally tolerated extended lateness;
// on difficult motion that could present as slow-motion frame stepping before catch-up.
// Asynchronous decompression is restored in makeOptions(), while synchronous video and
// audio decode remain disabled so packet reading, decoding, and presentation stay on
// independent queued paths.
private final class DebridFlixorVODOptions: KSOptions {
    override func videoFrameMaxCount(fps: Float, naturalSize: CGSize, isLive: Bool) -> UInt8 {
        guard !isLive else {
            return super.videoFrameMaxCount(fps: fps, naturalSize: naturalSize, isLive: true)
        }

        let frameCount: UInt8
        if naturalSize.width >= 3840 || naturalSize.height >= 2160 {
            frameCount = 16
        } else if naturalSize.width >= 1920 || naturalSize.height >= 1080 {
            frameCount = 24
        } else {
            frameCount = 16
        }

        print("[PlaybackKit][v988] VOD decoded-frame queue=\(frameCount) fps=\(fps) size=\(Int(naturalSize.width))x\(Int(naturalSize.height)) preferredFrame=\(KSOptions.preferredFrame)")
        return frameCount
    }
}

struct KSPlayerVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    let externalAudioURL: URL?
    let externalAudioOffsetMS: Int
    var muteAudio: Bool = false
    var contentMode: UIView.ContentMode = .scaleAspectFit
    var isLiveStream: Bool = false
    var routeHint: String = ""
    var enableDisplayMatch: Bool = false
    var displayMatchIsLive: Bool = false
    var selectedAudioTrackIndex: Int? = nil
    var selectedSubtitleTrackIndex: Int? = nil
    var trackSelectionSerial: Int = 0
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onTracksDiscovered: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)? = nil

    final class KSContainerView: UIView {
        private var cachedBounds: CGRect = .null
        private var cachedFrame: CGRect = .null
        private var cachedSafeAreaInsets: UIEdgeInsets = .zero
        private weak var frozenRenderView: UIView?
        private var didFreezePlayerHierarchy = false

        override var canBecomeFocused: Bool { false }

        override func didMoveToWindow() {
            super.didMoveToWindow()
            isUserInteractionEnabled = false
        }

        func installRenderViewOnce(_ renderView: UIView) {
            guard frozenRenderView == nil else { return }
            frozenRenderView = renderView
            addSubview(renderView)
            freezePlayerHierarchyOnce(in: renderView)
            applyGeometryIfChanged(force: true)
        }

        func updateRenderContentModeIfChanged(_ contentMode: UIView.ContentMode) {
            guard let renderView = frozenRenderView, renderView.contentMode != contentMode else { return }
            renderView.contentMode = contentMode
            let gravity: CALayerContentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
            if renderView.layer.contentsGravity != gravity { renderView.layer.contentsGravity = gravity }
        }

        func resetRenderHostForURLChange() {
            frozenRenderView = nil
            didFreezePlayerHierarchy = false
            cachedBounds = .null
            cachedFrame = .null
            cachedSafeAreaInsets = .zero
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            applyGeometryIfChanged()
        }

        private func applyGeometryIfChanged(force: Bool = false) {
            let geometryChanged = force || bounds != cachedBounds || frame != cachedFrame || safeAreaInsets != cachedSafeAreaInsets
            guard geometryChanged else { return }

            cachedBounds = bounds
            cachedFrame = frame
            cachedSafeAreaInsets = safeAreaInsets
            clipsToBounds = true

            guard let renderView = frozenRenderView else { return }
            if renderView.transform != .identity { renderView.transform = .identity }
            if renderView.frame != bounds { renderView.frame = bounds }
            if renderView.autoresizingMask != [.flexibleWidth, .flexibleHeight] {
                renderView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            }
        }

        private func freezePlayerHierarchyOnce(in root: UIView) {
            guard !didFreezePlayerHierarchy else { return }
            didFreezePlayerHierarchy = true
            stripKSPlayerChromeOnce(in: root)
            promoteKSPlayerSubtitleRendererOnce(in: root)
        }

        private func stripKSPlayerChromeOnce(in root: UIView) {
            for child in root.subviews {
                let className = String(describing: type(of: child)).lowercased()
                let isSubtitleRenderer = className.contains("subtitle") || className.contains("caption") || className.contains("textview")
                let isChrome = !isSubtitleRenderer && (child is UIControl || child is UIStackView || child is UIButton || className.contains("toolbar") || className.contains("control") || className.contains("button") || className.contains("slider") || className.contains("mask"))
                if isChrome {
                    child.isHidden = true
                    child.alpha = 0
                    child.isUserInteractionEnabled = false
                } else {
                    child.isUserInteractionEnabled = false
                    stripKSPlayerChromeOnce(in: child)
                }
            }
        }
    }

    final class PlaybackSurfaceAnchorView: UIView {
        let surface = KSContainerView()

        override var canBecomeFocused: Bool { false }

        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .black
            isUserInteractionEnabled = false
            clipsToBounds = true
            addSubview(surface)
            surface.frame = bounds
            surface.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        }

        @available(*, unavailable)
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

        override func layoutSubviews() {
            super.layoutSubviews()
            if let host = subviews.first(where: { $0 is PlaybackPersistentRenderHostView }) {
                if host.frame != bounds { host.frame = bounds }
            } else if surface.superview === self, surface.frame != bounds {
                surface.frame = bounds
            }
        }
    }

    fileprivate struct UpdateSnapshot: Equatable {
        let url: URL
        let shouldPlay: Bool
        let seekSerial: Int
        let seekSeconds: Double
        let seekIsAbsolute: Bool
        let reloadToken: Int
        let startTimeSeconds: Double
        let externalAudioURL: URL?
        let externalAudioOffsetMS: Int
        let muteAudio: Bool
        let contentModeRawValue: Int
        let isLiveStream: Bool
        let routeHint: String
        let enableDisplayMatch: Bool
        let displayMatchIsLive: Bool
        let selectedAudioTrackIndex: Int?
        let selectedSubtitleTrackIndex: Int?
        let trackSelectionSerial: Int
    }

    private var updateSnapshot: UpdateSnapshot {
        UpdateSnapshot(
            url: url,
            shouldPlay: shouldPlay,
            seekSerial: seekSerial,
            seekSeconds: seekSeconds,
            seekIsAbsolute: seekIsAbsolute,
            reloadToken: reloadToken,
            startTimeSeconds: startTimeSeconds,
            externalAudioURL: externalAudioURL,
            externalAudioOffsetMS: externalAudioOffsetMS,
            muteAudio: muteAudio,
            contentModeRawValue: contentMode.rawValue,
            isLiveStream: isLiveStream,
            routeHint: routeHint,
            enableDisplayMatch: enableDisplayMatch,
            displayMatchIsLive: displayMatchIsLive,
            selectedAudioTrackIndex: selectedAudioTrackIndex,
            selectedSubtitleTrackIndex: selectedSubtitleTrackIndex,
            trackSelectionSerial: trackSelectionSerial
        )
    }

    final class Coordinator: NSObject, KSPlayerLayerDelegate, PlaybackRenderSurfaceLifecycleOwner {
        var playerLayer: KSPlayerLayer?
        var currentURL: URL?
        var lastSeekSerial: Int = 0
        var lastReloadToken: Int = -1
        var currentStartTimeSeconds: Double = 0
        var currentExternalAudioURL: URL?
        var currentExternalAudioOffsetMS: Int = 0
        var currentMuteAudio: Bool = false
        var currentContentMode: UIView.ContentMode = .scaleAspectFit
        var currentShouldPlay: Bool? = nil
        var currentDisplayMatchEnabled: Bool = false
        var currentDisplayMatchIsLive: Bool = false
        var currentPlaybackSeconds: Double = 0
        var currentDurationSeconds: Double = 0
        var didApplyEnglishAudioSelection: Bool = false
        var lastTrackSelectionSerial: Int = -1
        var selectedAudioTrackIndex: Int? = nil
        var selectedSubtitleTrackIndex: Int? = nil
        var pendingExplicitTrackSelection: Bool = false
        var suppressClockUntil: CFTimeInterval = .greatestFiniteMagnitude
        var playbackStateReadyForClock = false
        // v920: once KSPlayer has reached its first ready state, transient state changes
        // must not permanently stop the real VOD clock. Only initial startup and an
        // explicit seek/track flush freeze time publication.
        var hasReachedInitialReadyForClock = false
        var explicitClockFreeze = true
        var clockReadyAfter: CFTimeInterval = .greatestFiniteMagnitude
        var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
        var onTracksDiscovered: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)? = nil
        // Phase 11: prevent SwiftUI invalidations from repeatedly entering the active
        // KSPlayer configuration path when no playback command changed.
        fileprivate var lastAppliedUpdateSnapshot: UpdateSnapshot?
        // Phase 7: session-scoped lease for weak render-host registration.
        var renderSurfaceRegistrationEnabled = false
        let renderSurfaceID = UUID()
        var renderSurfaceRegistration: PlaybackRenderSurfaceRegistration?
        // v929 Phase B: KSPlayer may report time at render cadence. Keep the engine clock
        // current on every callback, but coalesce SwiftUI publication so the VOD screen is
        // not invalidated dozens of times per second while video frames are being presented.
        private var lastTimePublicationHostTime: CFTimeInterval = 0
        private var lastPublishedPlaybackSeconds: Double = -1
        private let minimumTimePublicationInterval: CFTimeInterval = 0.50

        // v957: VOD startup parity test. Normal startup now uses only a play assertion,
        // matching the smooth trailer path. A same-position seek is retained solely as a
        // delayed emergency fallback when the active VOD has neither presented a frame nor
        // advanced its real KSPlayer clock after the initial ready state.
        var firstFrameReleaseEligible = false
        var didEvaluateFirstFrameRelease = false
        var didPerformFirstFrameRelease = false
        var firstFrameRecoveryGeneration = 0

        private func layerTreeHasPresentedVideo(_ layer: CALayer) -> Bool {
            if layer.presentation() != nil, layer.contents != nil { return true }
            return layer.sublayers?.contains(where: { layerTreeHasPresentedVideo($0) }) ?? false
        }

        private func renderHostHasPresentedVideo(_ layer: KSPlayerLayer) -> Bool {
            guard let view = layer.player.view, view.window != nil, !view.isHidden, view.alpha > 0.001 else { return false }
            return layerTreeHasPresentedVideo(view.layer)
        }

        private func evaluateFirstFrameReleaseIfNeeded(_ layer: KSPlayerLayer) {
            guard firstFrameReleaseEligible,
                  !didEvaluateFirstFrameRelease,
                  playerLayer === layer else { return }
            didEvaluateFirstFrameRelease = true

            let resumePlayback = currentShouldPlay ?? true
            let baselinePlaybackSeconds = currentPlaybackSeconds
            firstFrameRecoveryGeneration += 1
            let recoveryGeneration = firstFrameRecoveryGeneration

            // v957 normal path: do not seek during startup. Re-assert the requested play
            // state on the existing layer, matching the smooth trailer behavior without
            // creating a second player or touching the decoder configuration.
            if resumePlayback {
                layer.play()
            } else {
                layer.pause()
            }

            // One delayed, non-polling safety check preserves the old manual-forward rescue.
            // The same-position seek runs only when playback was requested, no rendered frame
            // exists, and the real KSPlayer clock has not advanced meaningfully since ready.
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) { [weak self, weak layer] in
                guard let self, let layer, self.playerLayer === layer,
                      self.firstFrameReleaseEligible,
                      self.firstFrameRecoveryGeneration == recoveryGeneration,
                      !self.didPerformFirstFrameRelease,
                      self.currentShouldPlay ?? true else { return }

                if self.renderHostHasPresentedVideo(layer) {
                    print("[KSPlayer][v957] VOD first frame presented after play assertion; emergency seek not required")
                    return
                }

                let clockAdvanced = self.currentPlaybackSeconds >= baselinePlaybackSeconds + 0.25
                guard !clockAdvanced else {
                    print("[KSPlayer][v957] VOD clock advanced after play assertion; emergency seek not required")
                    return
                }

                self.didPerformFirstFrameRelease = true
                let releaseTime = max(0, max(self.currentStartTimeSeconds, self.currentPlaybackSeconds))
                layer.seek(time: releaseTime, autoPlay: true) { [weak self, weak layer] finished in
                    guard let self, let layer, self.playerLayer === layer else { return }

                    // This is an emergency startup recovery only. Re-arm the existing clock
                    // gate so a stream that needed the rescue cannot remain frozen at 0:00.
                    self.hasReachedInitialReadyForClock = true
                    self.playbackStateReadyForClock = true
                    self.explicitClockFreeze = false
                    self.clockReadyAfter = CACurrentMediaTime() + 0.12
                    self.suppressClockUntil = self.clockReadyAfter
                    print("[KSPlayer][v957] emergency first-frame seek finished=\(finished) at \(releaseTime)s")
                }
            }
        }

        func playbackKitStopAndReleaseSurface() {
            playerLayer?.pause()
            playerLayer?.stop()
            // KSPlayerLayer in the pinned KSPlayer package does not expose a backing `view`.
            // The session-owned persistent host releases the mounted UIView hierarchy separately.
            playerLayer = nil
            #if os(tvOS)
            if currentDisplayMatchEnabled, #available(tvOS 11.2, *) {
                DebridTVOSDisplayMatchCoordinator.reset()
            }
            #endif
        }

        private func publishPlaybackTime(force: Bool = false) {
            let now = CACurrentMediaTime()
            let meaningfulJump = lastPublishedPlaybackSeconds < 0 || abs(currentPlaybackSeconds - lastPublishedPlaybackSeconds) >= 0.75
            guard force || meaningfulJump || now - lastTimePublicationHostTime >= minimumTimePublicationInterval else { return }
            lastTimePublicationHostTime = now
            lastPublishedPlaybackSeconds = currentPlaybackSeconds
            onPlaybackTimeUpdate?(currentPlaybackSeconds, currentDurationSeconds)
        }

        func player(layer: KSPlayerLayer, state: KSPlayerState) {
            currentDurationSeconds = layer.player.duration
            playbackStateReadyForClock = (state == .readyToPlay)
            if playbackStateReadyForClock {
                // readyToPlay can arrive before the first decoded video frame is visible.
                // Hold briefly on initial startup/explicit flush, then release the real clock.
                let delay: CFTimeInterval = hasReachedInitialReadyForClock ? 0.12 : 0.45
                clockReadyAfter = CACurrentMediaTime() + delay
                suppressClockUntil = clockReadyAfter
                hasReachedInitialReadyForClock = true
                explicitClockFreeze = false
            }
            publishPlaybackTime(force: true)
            // v764 safety: only attempt track selection on the explicit ready state, never on
            // generic "play"/buffer states that can fire before KSPlayer exposes stable tracks.
            if state == .readyToPlay {
                evaluateFirstFrameReleaseIfNeeded(layer)
                publishDiscoveredTracks(layer)
                scheduleEnglishAudioTrackSelection(layer)
                if pendingExplicitTrackSelection {
                    applySelectedTracksIfNeeded(layer, force: true, flushAfterSelection: true)
                } else {
                    applySelectedTracksIfNeeded(layer, force: true)
                }
            }
        }

        func scheduleEnglishAudioTrackSelection(_ layer: KSPlayerLayer) {
            guard !didApplyEnglishAudioSelection else { return }
            didApplyEnglishAudioSelection = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) { [weak self, weak layer] in
                guard let self, let layer, self.playerLayer === layer else { return }
                self.applyEnglishAudioTrackIfAvailable(layer)
            }
        }

        func applyEnglishAudioTrackIfAvailable(_ layer: KSPlayerLayer) {
            let audioTracks = layer.player.tracks(mediaType: .audio)
            guard !audioTracks.isEmpty else { return }
            let englishCodes: Set<String> = ["en", "eng", "en-us", "en-gb", "english"]
            guard let english = audioTracks.first(where: { track in
                let lang = (track.languageCode ?? track.language ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                let name = track.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                return englishCodes.contains(lang) || lang.hasPrefix("en") || lang.contains("eng") || name.contains("english") || name.contains(" eng") || name == "eng" || name.contains("en-us") || name.contains("en-gb")
            }) else { return }
            layer.player.select(track: english)
            print("[KSPlayer] selected English audio track: \(english.name)")
        }

        func publishDiscoveredTracks(_ layer: KSPlayerLayer) {
            let audio = layer.player.tracks(mediaType: .audio).enumerated().map { index, track in
                makeRealTrackOption(track: track, index: index, kind: "Audio")
            }
            let subtitles = layer.player.tracks(mediaType: .subtitle).enumerated().map { index, track in
                makeRealTrackOption(track: track, index: index, kind: "Subtitle")
            }
            if !audio.isEmpty || !subtitles.isEmpty {
                DispatchQueue.main.async { [weak self] in
                    self?.onTracksDiscovered?(audio, subtitles)
                }
            }
        }

        func makeRealTrackOption(track: Any, index: Int, kind: String) -> RealMediaTrackOption {
            let mirror = Mirror(reflecting: track)
            func value(_ names: [String]) -> String? {
                for child in mirror.children {
                    guard let label = child.label, names.contains(label) else { continue }
                    if let v = child.value as? String, !v.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return v }
                    if let v = child.value as? String?, let text = v, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return text }
                }
                return nil
            }
            let name = value(["name", "title"]) ?? "\(kind) \(index + 1)"
            let language = value(["languageCode", "language", "locale"]) ?? name
            return RealMediaTrackOption(
                id: "ks-\(kind.lowercased())-\(index)-\(language)-\(name)",
                optionIndex: index,
                label: name,
                languageName: MediaTrackLanguageNormalizer.displayName(code: language, fallback: name),
                codecOrFormat: value(["codec", "codecName", "format"]),
                isDefault: name.lowercased().contains("default"),
                isForced: name.lowercased().contains("forced"),
                isSDH: name.lowercased().contains("sdh")
            )
        }

        func selectOpenedKSPlayerTrack<Track: MediaPlayerTrack>(_ track: Track, on layer: KSPlayerLayer) {
            layer.player.select(track: track)
        }

        @discardableResult
        func applySelectedTracksIfNeeded(_ layer: KSPlayerLayer, force: Bool = false, flushAfterSelection: Bool = false) -> Bool {
            var changedTrack = false
            if let audioIndex = selectedAudioTrackIndex {
                let tracks = layer.player.tracks(mediaType: .audio)
                if tracks.indices.contains(audioIndex) {
                    let track = tracks[audioIndex]
                    selectOpenedKSPlayerTrack(track, on: layer)
                    changedTrack = true
                    print("[KSPlayer] selected audio track index \(audioIndex): \(track.name)")
                }
            }
            let subtitleTracks = layer.player.tracks(mediaType: .subtitle)
            if let subtitleIndex = selectedSubtitleTrackIndex {
                if subtitleTracks.indices.contains(subtitleIndex) {
                    let track = subtitleTracks[subtitleIndex]
                    selectOpenedKSPlayerTrack(track, on: layer)
                    changedTrack = true
                    print("[KSPlayer] selected subtitle track index \(subtitleIndex): \(track.name)")
                }
            } else if force {
                // KSPlayer 6.1.4 select(track:) requires a non-optional concrete track.
                print("[KSPlayer] subtitle Off requested")
                print("[KSPlayer] subtitles off")
            }

            // KSPlayer/FFPlayer can retain already-buffered packets after a runtime
            // embedded-track switch. Flush only for an explicit user selection serial,
            // never during normal SwiftUI refreshes or periodic metadata discovery.
            if flushAfterSelection && changedTrack {
                pendingExplicitTrackSelection = false
                let resumePlayback = currentShouldPlay ?? true
                let flushTime = max(0, currentPlaybackSeconds)
                // Do not let KSPlayer's demux clock advance the visible VOD timeline while
                // the decoder is flushing and no new video frame can be presented yet.
                playbackStateReadyForClock = false
                explicitClockFreeze = true
                suppressClockUntil = .greatestFiniteMagnitude
                clockReadyAfter = .greatestFiniteMagnitude
                // One explicit same-position seek on the active FFPlayer-backed layer flushes
                // already-buffered packets/decoder output without replacing the player.
                layer.seek(time: flushTime, autoPlay: false) { [weak self, weak layer] finished in
                    guard let self, let layer, self.playerLayer === layer else { return }
                    if resumePlayback { layer.play() } else { layer.pause() }
                    // Do not unlock from elapsed wall-clock time.  The next real KSPlayer
                    // readyToPlay callback releases the visible timeline.
                    print("[KSPlayer] active-player track flush finished=\(finished) at \(flushTime)s resume=\(resumePlayback)")
                }
            }
            return changedTrack
        }

        func player(layer _: KSPlayerLayer, currentTime: TimeInterval, totalTime: TimeInterval) {
            currentDurationSeconds = max(currentDurationSeconds, totalTime)
            // FFPlayer can advance its demux clock during initial buffering and immediately
            // after seek/track decoder flushes, before video output resumes. Keep duration
            // metadata flowing, but freeze the user-visible current/remaining time in that gap.
            // Do not require KSPlayer to remain in .readyToPlay forever. Some streams
            // transition through buffering/playing-style states after startup and never send
            // another ready callback, which previously froze the progress bar at 0:00.
            guard hasReachedInitialReadyForClock,
                  !explicitClockFreeze,
                  CACurrentMediaTime() >= suppressClockUntil,
                  CACurrentMediaTime() >= clockReadyAfter else {
                publishPlaybackTime()
                return
            }
            currentPlaybackSeconds = max(0, currentTime)
            publishPlaybackTime()
        }

        func player(layer _: KSPlayerLayer, finish error: Error?) {
            if let error {
                print("[KSPlayer] playback finished with error: \(error.localizedDescription)")
            }
        }

        func player(layer _: KSPlayerLayer, bufferedCount: Int, consumeTime: TimeInterval) {}
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlaybackSurfaceAnchorView {
        let anchor = PlaybackSurfaceAnchorView()
        let view = anchor.surface
        context.coordinator.renderSurfaceRegistrationEnabled = !isLiveStream
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        context.coordinator.lastAppliedUpdateSnapshot = updateSnapshot
        configure(view: view, coordinator: context.coordinator)
        if context.coordinator.renderSurfaceRegistrationEnabled {
            // Registration remains weak and non-mutating; the lease rejects stale-session callbacks.
            context.coordinator.renderSurfaceRegistration = PlaybackController.shared.registerRenderSurfaceCandidate(
                view,
                surfaceID: context.coordinator.renderSurfaceID,
                lifecycleOwner: context.coordinator
            )
        }
        return anchor
    }

    func updateUIView(_ anchor: PlaybackSurfaceAnchorView, context: Context) {
        // Callback closures may be recreated by SwiftUI even when their behavior is the same.
        // Refresh them without touching KSPlayer, then compare only stable playback inputs.
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        let snapshot = updateSnapshot
        guard context.coordinator.lastAppliedUpdateSnapshot != snapshot else { return }
        context.coordinator.lastAppliedUpdateSnapshot = snapshot
        configure(view: anchor.surface, coordinator: context.coordinator)
    }

    private func makeOptions(url: URL, muteAudio: Bool = false, startTimeSeconds: Double = 0) -> KSOptions {
        let lowerURL = url.absoluteString.lowercased()
        let lowerRouteHint = routeHint.lowercased()
        let timingRiskHaystack = lowerURL + " " + lowerRouteHint
        let isTrailerPlayback = lowerURL.contains("/trailers/") || lowerURL.contains("trailer")
        let isVODStylePlayback = !isLiveStream && !isTrailerPlayback
        // v985: the selected Source Intelligence label carries quality/size/container
        // facts into PlaybackKit. Use those facts only to choose a safer memory profile;
        // the 25/50 visible result limit and source ranking remain unchanged.
        let isHighMemoryVOD = isVODStylePlayback && (
            timingRiskHaystack.contains("2160") ||
            timingRiskHaystack.contains("4k") ||
            timingRiskHaystack.contains("uhd") ||
            timingRiskHaystack.contains("remux") ||
            timingRiskHaystack.contains("truehd") ||
            timingRiskHaystack.contains("dts-hd") ||
            timingRiskHaystack.contains("dtshd")
        )
        let options: KSOptions = isVODStylePlayback ? DebridFlixorVODOptions() : KSOptions()
        // Flixor creates the VOD session with autoplay disabled, then issues one
        // explicit play after the stable native view is mounted. Other routes retain
        // their current autoplay behavior.
        KSOptions.isAutoPlay = !isVODStylePlayback
        // The tapframe/KSPNUVIO fork already defaults preferredFrame to true. Keep it
        // explicit for the main-VOD test and restore the same default for every route.
        KSOptions.preferredFrame = true
        let hasCBSMetadataSignal =
            timingRiskHaystack.contains("cbs") ||
            timingRiskHaystack.contains("paramount") ||
            timingRiskHaystack.contains("wcbs") ||
            timingRiskHaystack.contains("kcbs") ||
            timingRiskHaystack.contains("wbbm") ||
            timingRiskHaystack.contains("wkyc")
        let hasLiveRemuxTimingSignal =
            timingRiskHaystack.contains("/devices/") ||
            timingRiskHaystack.contains("channels.m3u") ||
            timingRiskHaystack.contains("/hls/") ||
            timingRiskHaystack.contains("/dvr/") ||
            timingRiskHaystack.contains("format=ts") ||
            timingRiskHaystack.contains(".m3u8") ||
            timingRiskHaystack.contains(".mpg") ||
            timingRiskHaystack.contains("tve") ||
            timingRiskHaystack.contains("channels dvr") ||
            timingRiskHaystack.contains("verizon") ||
            timingRiskHaystack.contains("live tv direct stream") ||
            timingRiskHaystack.contains("ks live tv route")
        let isLikelyCBSLiveTimingRisk =
            !isTrailerPlayback &&
            hasCBSMetadataSignal &&
            hasLiveRemuxTimingSignal
        let hasKnownNonNativeContainer = lowerURL.contains(".mkv") || lowerURL.contains("%2emkv") || lowerURL.contains("matroska") || lowerURL.contains(".avi") || lowerURL.contains("%2eavi") || lowerURL.contains(".webm") || lowerURL.contains("%2ewebm") || lowerURL.contains(".vob") || lowerURL.contains("%2evob")
        let hasHighRiskAudioContainerHint = lowerURL.contains("truehd") || lowerURL.contains("dts-hd") || lowerURL.contains("dtshd") || lowerURL.contains(" mlp") || lowerURL.contains("atmos truehd")
        let shouldTryNativeFirstForTvOSMatch = !isTrailerPlayback && !hasKnownNonNativeContainer && !hasHighRiskAudioContainerHint
        // v833: Match Frame Rate / Dynamic Range crash guard.
        // Preserve the v831 KSPlayer buffer/cache-ahead tuning, but do not force the
        // KSAVPlayer-first path during normal VOD playback. On some tvOS/projector/display
        // combinations the AVFoundation handoff can crash when Match Content is enabled.
        // KSMEPlayer remains the primary KSPlayer route. v961 gives main VOD the
        // same KSAVPlayer fallback order used by Flixor; trailers and Live TV keep
        // the previous KSMEPlayer-only fallback behavior.
        KSOptions.firstPlayerType = KSMEPlayer.self
        KSOptions.secondPlayerType = isVODStylePlayback ? KSAVPlayer.self : KSMEPlayer.self
        options.isSecondOpen = true
        options.isAccurateSeek = true
        options.isSeekedAutoPlay = true
        options.startPlayTime = max(0, startTimeSeconds)
        // v840: restore v832 trailer playback profile only.
        // v839 remains the base for everything else. Trailers go back to the
        // smaller v832 KSPlayer buffer/probe lane that avoided trailer stutter,
        // while movies/episodes keep the current VOD buffer/cache profile.
        // v961: main VOD matches Flixor's high-bitrate buffer profile exactly.
        // Trailers and Live TV retain their existing, proven buffer windows.
        options.preferredForwardBufferDuration = isLikelyCBSLiveTimingRisk ? 8 : (isHighMemoryVOD ? 3 : (isVODStylePlayback ? 5 : (!isLiveStream ? 45 : 6)))
        options.maxBufferDuration = isLikelyCBSLiveTimingRisk ? 12 : (isHighMemoryVOD ? 30 : (isVODStylePlayback ? 300 : (!isLiveStream ? 90 : 12)))
        let playbackConfiguration = isLiveStream ? PlaybackConfiguration.live : PlaybackConfiguration.vod
        options.hardwareDecode = playbackConfiguration.hardwareDecode
        // v943 trailer cadence restoration: apply the same v840 cadence hybrid to
        // trailers as movies/episodes. Live TV remains on its existing path.
        options.asynchronousDecompression = playbackConfiguration.asynchronousDecompression
        options.decoderOptions["threads"] = playbackConfiguration.decoderThreadCount
        if let decoderThreadType = playbackConfiguration.decoderThreadType {
            options.decoderOptions["thread_type"] = decoderThreadType
        } else {
            options.decoderOptions["thread_type"] = nil
        }

        // v988 controlled main-VOD cadence profile. Keep the v985 memory-pressure
        // protections and the full preferred-buffer startup from v987, but restore
        // asynchronous VideoToolbox decompression and KSPNUVIO's stock A/V clock policy.
        // Synchronous video/audio decode remain disabled: those switches replace the
        // independent queued decode workers with synchronous track decoding and are not
        // smoothness options for high-bitrate VOD.
        if isVODStylePlayback {
            options.hardwareDecode = true
            options.asynchronousDecompression = true
            options.syncDecodeVideo = false
            options.syncDecodeAudio = false
            options.videoAdaptable = true
            // Retain the full preferred-buffer startup. The existing one-shot first-frame
            // release remains active, so this does not require a manual skip action.
            options.isSecondOpen = false
            options.isAccurateSeek = false
            options.isSeekImageSubtitle = true
            options.probesize = isHighMemoryVOD ? 12_000_000 : 50_000_000
            options.maxAnalyzeDuration = isHighMemoryVOD ? 3_000_000 : 5_000_000
            options.destinationDynamicRange = nil
            options.decoderOptions["threads"] = "auto"
            options.decoderOptions["thread_type"] = nil
            options.decoderOptions["skip_loop_filter"] = nil
        } else if !isLiveStream {
            options.decoderOptions["skip_loop_filter"] = "none"
        }
        options.videoAdaptable = true

        let effectiveThreads = options.decoderOptions["threads"] as? String ?? "engine-default"
        let effectiveThreadType = options.decoderOptions["thread_type"] as? String ?? "engine-default"
        if isVODStylePlayback || PlaybackDiagnostics.isEnabled {
            print("[PlaybackKit][v988] route=\(isVODStylePlayback ? "main-vod" : (isTrailerPlayback ? "trailer" : "live")) highMemoryVOD=\(isHighMemoryVOD) hardware=\(options.hardwareDecode) async=\(options.asynchronousDecompression) syncVideo=\(options.syncDecodeVideo) syncAudio=\(options.syncDecodeAudio) adaptable=\(options.videoAdaptable) secondOpen=\(options.isSecondOpen) accurateSeek=\(options.isAccurateSeek) probe=\(options.probesize ?? -1) analyze=\(options.maxAnalyzeDuration ?? -1) buffer=\(options.preferredForwardBufferDuration)/\(options.maxBufferDuration) threads=\(effectiveThreads) type=\(effectiveThreadType) autoplay=\(KSOptions.isAutoPlay) fallback=\(String(describing: KSOptions.secondPlayerType))")
        }
        // v915/v840 stability: do not auto-select an embedded subtitle stream during
        // player startup. Explicit user track selection remains available after ready.
        options.autoSelectEmbedSubtitle = false
        options.registerRemoteControll = false
        options.userAgent = isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer"
        options.avOptions = [
            "AVURLAssetHTTPHeaderFieldsKey": [
                "User-Agent": isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
                "Accept": "*/*",
                "Connection": "keep-alive"
            ]
        ]
        var formatOptions: [String: String] = [
            "reconnect": "1",
            "reconnect_streamed": "1",
            "reconnect_delay_max": "5",
            "fflags": isTrailerPlayback ? "+genpts" : (isLikelyCBSLiveTimingRisk ? "+genpts" : (isVODStylePlayback ? "+genpts" : "nobuffer")),
            "flags": isTrailerPlayback ? "" : (isLikelyCBSLiveTimingRisk || isVODStylePlayback ? "" : "low_delay"),
            "cache": isLikelyCBSLiveTimingRisk ? "1500" : (isTrailerPlayback ? "1500" : (isVODStylePlayback ? "1500" : "1500")),
            "rw_timeout": "15000000",
            "user_agent": isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
            "preferred_language": "eng,en,English",
            "preferred_audio_language": "eng,en,English",
            "audio_language": "eng,en,English",
            "alang": "eng,en,English",
            "slang": "eng,en,English",
            "subtitles": "1",
            "sn": "1",
            "analyzeduration": isTrailerPlayback ? "1000000" : (isLikelyCBSLiveTimingRisk ? "3000000" : (isVODStylePlayback ? "3000000" : "100000")),
            "probesize": isTrailerPlayback ? "262144" : (isLikelyCBSLiveTimingRisk ? "1048576" : (isVODStylePlayback ? "1048576" : "16384")),
            "thread_queue_size": isHighMemoryVOD ? "2048" : "8192",
            "max_delay": isTrailerPlayback ? "100000" : (isLikelyCBSLiveTimingRisk ? "700000" : (isVODStylePlayback ? "100000" : "100000")),
            "sync": isLikelyCBSLiveTimingRisk ? "ext" : "audio",
            "fpsprobesize": isTrailerPlayback ? "240" : (isVODStylePlayback ? "240" : "120")
        ]
        // v957: trailer and main VOD parity. Do not pass an empty FFmpeg `flags`
        // entry for either non-live path; Live TV retains its existing behavior.
        if isTrailerPlayback || isVODStylePlayback {
            formatOptions.removeValue(forKey: "flags")
        }
        // v940: VOD-only safe demux tuning. Live TV retains v938 exactly.
        if !isLiveStream {
            formatOptions["reorder_queue_size"] = isHighMemoryVOD ? "512" : "1024"
            formatOptions["buffer_size"] = String((isHighMemoryVOD ? 4 : 8) * 1024 * 1024)
            formatOptions["analyzeduration"] = isHighMemoryVOD ? "5000000" : "10000000"
            formatOptions["probesize"] = isHighMemoryVOD ? "8000000" : "15000000"
        }
        if muteAudio {
            formatOptions["an"] = "1"
            formatOptions["audio_disable"] = "1"
            formatOptions["volume"] = "0"
        }

        if isVODStylePlayback {
            // Flixor does not replace KSOptions' default FFmpeg dictionary with a
            // large raw option set. Keep KSPlayer defaults (scan_all_pmts,
            // reconnect, reconnect_streamed, user_agent) and append only the
            // request headers Debrid links require.
            let vodHeaders = [
                "User-Agent": "DebridChannels-tvOS/158 KSPlayer",
                "Accept": "*/*",
                "Connection": "keep-alive"
            ]
            options.appendHeader(vodHeaders)
            if muteAudio {
                options.formatContextOptions["an"] = "1"
                options.formatContextOptions["audio_disable"] = "1"
                options.formatContextOptions["volume"] = "0"
            }
        } else {
            options.formatContextOptions = formatOptions
        }
        return options
    }

    private func performBestEffortSeek(layer: KSPlayerLayer, seconds: Double, isAbsolute: Bool, resumePlayback: Bool, currentSeconds: Double, durationHint: Double) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async {
                performBestEffortSeek(layer: layer, seconds: seconds, isAbsolute: isAbsolute, resumePlayback: resumePlayback, currentSeconds: currentSeconds, durationHint: durationHint)
            }
            return
        }

        let reportedDuration = max(layer.player.duration, durationHint)
        let hasFiniteDuration = reportedDuration.isFinite && reportedDuration > 1
        let duration = hasFiniteDuration ? reportedDuration : Double.greatestFiniteMagnitude

        // VODPlayerScreen sends Back/Forward/Timeline scrubs as absolute, clamped seconds.
        // v827: do not reject seeks just because duration metadata is late; KSPlayer/FFmpeg
        // can often seek against the stream before a stable total duration is reported.
        let current = hasFiniteDuration ? max(0, min(currentSeconds, duration)) : max(0, currentSeconds)
        let unclampedTarget = isAbsolute ? seconds : current + seconds
        let target = min(max(unclampedTarget, 0), duration)

        print("KSPlayer Seek Requested: current=\(current) target=\(target) duration=\(hasFiniteDuration ? reportedDuration : -1)")
        layer.player.pause()
        layer.seek(time: target, autoPlay: resumePlayback) { finished in
            DispatchQueue.main.async {
                print(finished ? "KSPlayer Seek Completed" : "KSPlayer Seek Failed")
                if resumePlayback { layer.play() }
            }
        }
    }

    private func applyAudioMuteState(_ layer: KSPlayerLayer, muteAudio: Bool) {
        if let object = layer.player as? NSObject {
            let mutedSelector = NSSelectorFromString("setMuted:")
            let volumeSelector = NSSelectorFromString("setVolume:")
            if object.responds(to: mutedSelector) { object.setValue(muteAudio, forKey: "muted") }
            if object.responds(to: volumeSelector) { object.setValue(muteAudio ? 0.0 : 1.0, forKey: "volume") }
        }
    }

    // v902: deliberately no KVC/Mirror subtitle-object probing.  The v901 crash was
    // caused by undefined-key access while loading a link.  Subtitle layout is restricted
    // to real UIView descendants already owned by KSPlayer and is synchronized in
    // KSContainerView.layoutSubviews().

    private func configure(view: KSContainerView, coordinator: Coordinator) {
        if coordinator.currentURL == url, coordinator.lastReloadToken == reloadToken, let layer = coordinator.playerLayer {
            let externalAudioConfigurationChanged =
                coordinator.currentExternalAudioURL != externalAudioURL ||
                coordinator.currentExternalAudioOffsetMS != externalAudioOffsetMS
            let muteChanged = coordinator.currentMuteAudio != muteAudio
            let contentModeChanged = coordinator.currentContentMode != contentMode

            if externalAudioConfigurationChanged || muteChanged || contentModeChanged {
                coordinator.currentExternalAudioURL = externalAudioURL
                coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
                coordinator.currentMuteAudio = muteAudio
                coordinator.currentContentMode = contentMode
                // Smart Alternate Audio v1: keep the main video URL active and carry the selected
                // alternate audio reference/sync offset in the surface state. KSPlayer package APIs
                // differ by version for external audio attachment, so this v1 hook is non-crashing
                // and ready for the engine-specific attachment call when exposed by the compiled SDK.
            }
            if contentModeChanged {
                // Playback profile changes are the only non-geometry updates permitted to
                // touch the frozen render host. Identical assignments are suppressed.
                view.updateRenderContentModeIfChanged(contentMode)
            }
            if seekSerial != coordinator.lastSeekSerial {
                coordinator.lastSeekSerial = seekSerial
                performBestEffortSeek(layer: layer, seconds: seekSeconds, isAbsolute: seekIsAbsolute, resumePlayback: shouldPlay, currentSeconds: coordinator.currentPlaybackSeconds, durationHint: coordinator.currentDurationSeconds)
            }
            if muteChanged {
                applyAudioMuteState(layer, muteAudio: muteAudio)
            }
            if coordinator.lastTrackSelectionSerial != trackSelectionSerial {
                coordinator.lastTrackSelectionSerial = trackSelectionSerial
                // Copy the new UI choice onto the coordinator BEFORE touching the active player.
                // v895 previously applied the coordinator's stale indexes, so audio often changed
                // only after a later rewind/resume and subtitle selection could be lost entirely.
                coordinator.selectedAudioTrackIndex = selectedAudioTrackIndex
                coordinator.selectedSubtitleTrackIndex = selectedSubtitleTrackIndex
                coordinator.pendingExplicitTrackSelection = true
                _ = coordinator.applySelectedTracksIfNeeded(layer, force: true, flushAfterSelection: true)
            }
            // v408: KSPlayer can crash on some tvOS/package builds if play()/pause() is
            // spammed on every SwiftUI state refresh. Only send the command when the
            // requested playback state actually changes. This stabilizes Pause -> Play
            // without changing URL, cache, seek, overlay, or Live TV behavior.
            if coordinator.currentShouldPlay != shouldPlay {
                coordinator.currentShouldPlay = shouldPlay
                if shouldPlay { layer.play() } else { layer.pause() }
            }
            // v436 trailer playback restore: some trailer sources render the first frame
            // while KSPlayer remains internally paused after SwiftUI refreshes. For trailer
            // URLs only, keep the existing single layer alive and re-assert play on update.
            if shouldPlay, isTrailerURL(url) {
                forceStartTrailerLayerIfNeeded(layer, url: url)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.20) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.40) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.50) { forceStartTrailerLayerIfNeeded(layer, url: url) }
            }
            return
        }

        coordinator.playerLayer?.pause()
        coordinator.playerLayer?.stop()
        // URL/reload replacement is the sole path allowed to detach the old render host.
        view.resetRenderHostForURLChange()
        view.subviews.forEach { $0.removeFromSuperview() }
        coordinator.currentURL = url
        coordinator.lastReloadToken = reloadToken
        coordinator.currentStartTimeSeconds = startTimeSeconds
        coordinator.currentExternalAudioURL = externalAudioURL
        coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
        coordinator.currentMuteAudio = muteAudio
        coordinator.currentContentMode = contentMode
        coordinator.currentShouldPlay = shouldPlay
        coordinator.lastSeekSerial = seekSerial
        coordinator.currentPlaybackSeconds = max(0, startTimeSeconds)
        coordinator.currentDurationSeconds = 0
        coordinator.playbackStateReadyForClock = false
        coordinator.suppressClockUntil = .greatestFiniteMagnitude
        coordinator.didApplyEnglishAudioSelection = false
        coordinator.lastTrackSelectionSerial = trackSelectionSerial
        coordinator.selectedAudioTrackIndex = selectedAudioTrackIndex
        coordinator.selectedSubtitleTrackIndex = selectedSubtitleTrackIndex
        coordinator.pendingExplicitTrackSelection = false
        coordinator.firstFrameReleaseEligible = !isLiveStream && !isTrailerURL(url)
        coordinator.didEvaluateFirstFrameRelease = false
        coordinator.didPerformFirstFrameRelease = false
        coordinator.firstFrameRecoveryGeneration += 1
        coordinator.onTracksDiscovered = onTracksDiscovered

        let options = makeOptions(url: url, muteAudio: muteAudio, startTimeSeconds: startTimeSeconds)
        coordinator.currentDisplayMatchEnabled = enableDisplayMatch
        coordinator.currentDisplayMatchIsLive = displayMatchIsLive
        #if os(tvOS)
        if enableDisplayMatch, #available(tvOS 11.2, *) {
            if displayMatchIsLive {
                DebridTVOSDisplayMatchCoordinator.applyForLiveChannel(url: url, hint: routeHint)
            } else {
                DebridTVOSDisplayMatchCoordinator.applyForFullScreenVOD(url: url, hint: routeHint)
            }
        } else if #available(tvOS 11.2, *) {
            DebridTVOSDisplayMatchCoordinator.cancelPendingLiveDisplayMatch()
        }
        #endif
        let isMainVODPlayback = !isLiveStream && !isTrailerURL(url)
        let layer = KSPlayerLayer(url: url, isAutoPlay: !isMainVODPlayback, options: options, delegate: coordinator)
        coordinator.playerLayer = layer
        if let playerView = layer.player.view {
            playerView.backgroundColor = .black
            playerView.isOpaque = true
            playerView.clearsContextBeforeDrawing = false
            playerView.contentMode = contentMode
            playerView.layer.contentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
            // v929 Phase B: leave the KSPlayer/Metal render layer on Core Animation's
            // normal presentation path. Forcing drawsAsynchronously adds an extra CA
            // scheduling lane that can become visible during fast pans and scene cuts.
            playerView.layer.drawsAsynchronously = false
            playerView.layer.contentsScale = UIScreen.main.scale
            playerView.isUserInteractionEnabled = false
            playerView.transform = .identity
            playerView.frame = view.bounds
            playerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            playerView.clipsToBounds = true
            // v924 Phase 1: attach the KSPlayer render host exactly once. Geometry and
            // hierarchy configuration are frozen inside KSContainerView after installation.
            view.installRenderViewOnce(playerView)
        }
        applyAudioMuteState(layer, muteAudio: muteAudio)
        coordinator.publishDiscoveredTracks(layer)
        if !muteAudio, selectedAudioTrackIndex == nil { coordinator.applyEnglishAudioTrackIfAvailable(layer) }
        coordinator.applySelectedTracksIfNeeded(layer, force: true)
        if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url) } else { layer.pause() }
        // v419 trailer-only fix: the trailer URL can load and render its first
        // frame before KSPlayer/FFmpeg is actually in a running state. Keep the
        // rescue tiny and scoped to trailer URLs only so main VOD playback is not
        // affected. This does not create a second layer/player; it nudges the
        // same attached KSPlayerLayer after decoder/track metadata becomes ready.
        if isTrailerURL(url) {
            for delay in [0.10, 0.35, 0.75, 1.20, 2.00, 3.20, 4.80] {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    // v963 VOD Quiet Mode: repeated track scans/play nudges are trailer-only.
                    // Full-screen movies and episodes receive the one initial track application
                    // above and then PlaybackKit leaves the active decoder/session untouched.
                    coordinator.publishDiscoveredTracks(layer)
                    if !muteAudio, selectedAudioTrackIndex == nil { coordinator.applyEnglishAudioTrackIfAvailable(layer) }
                    coordinator.applySelectedTracksIfNeeded(layer, force: true)
                    applyAudioMuteState(layer, muteAudio: muteAudio)
                    if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url) }
                }
            }
        }
    }

    private func isTrailerURL(_ url: URL) -> Bool {
        let lower = url.absoluteString.lowercased()
        return lower.contains("/trailers/") || lower.contains("trailer") || lower.contains("remux-cache") || lower.contains("kinocheck")
    }

    private func forceStartTrailerLayerIfNeeded(_ layer: KSPlayerLayer, url: URL) {
        let isTrailerPlayback = isTrailerURL(url)
        // Main VOD playback keeps its existing conservative play/pause behavior.
        guard isTrailerPlayback else { layer.play(); return }
        layer.play()
        if let object = layer.player as? NSObject {
            let selectors = ["play", "resume", "start"]
            for name in selectors {
                let selector = NSSelectorFromString(name)
                if object.responds(to: selector) { _ = object.perform(selector) }
            }
        }
    }

    private func applyDefaultTracks(_ layer: KSPlayerLayer) {
        // Retained for compatibility with older call sites. The active path now applies
        // English audio once from Coordinator after KSPlayer exposes real tracks.
    }

    static func dismantleUIView(_ anchor: PlaybackSurfaceAnchorView, coordinator: Coordinator) {
        let uiView = anchor.surface
        if coordinator.renderSurfaceRegistrationEnabled,
           let registration = coordinator.renderSurfaceRegistration {
            // Phase 10: an active PlaybackSession owns the surface and coordinator teardown.
            // A SwiftUI invalidation must not stop KSPlayer or destroy its layer tree.
            if PlaybackController.shared.sessionOwnsRenderSurface(registration) {
                return
            }
            PlaybackController.shared.unregisterRenderSurfaceCandidate(uiView, registration: registration)
            coordinator.renderSurfaceRegistration = nil
        }
        coordinator.playbackKitStopAndReleaseSurface()
        uiView.subviews.forEach { $0.removeFromSuperview() }
    }
}
#endif

#if canImport(UIKit)
private extension UIView {
    func promoteKSPlayerSubtitleRendererOnce(in root: UIView) {
        let candidates = root.dcKSPlayerSubtitleCandidateViews()
        for subtitleView in candidates {
            subtitleView.isHidden = false
            subtitleView.alpha = 1.0
            subtitleView.frame = subtitleView.superview?.bounds ?? root.bounds
            subtitleView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            subtitleView.layer.zPosition = 999
            subtitleView.superview?.bringSubviewToFront(subtitleView)
        }
    }

    private func dcKSPlayerSubtitleCandidateViews() -> [UIView] {
        var results: [UIView] = []
        func walk(_ node: UIView) {
            let name = String(describing: type(of: node)).lowercased()
            if name.contains("subtitle") || name.contains("caption") || name.contains("text") {
                results.append(node)
            }
            node.subviews.forEach { walk($0) }
        }
        walk(self)
        return results
    }
}
#endif

