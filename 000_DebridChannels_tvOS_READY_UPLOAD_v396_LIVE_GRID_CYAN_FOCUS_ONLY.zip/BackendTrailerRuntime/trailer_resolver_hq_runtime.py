"""
Debrid Channels backend trailer resolver helper (v395 fast-cache + single-flight patch).

Drop this helper into the backend trailer/remux service. It keeps the v393
cookies + JS runtime + high-quality selector foundation, but changes trailer
startup behavior so tvOS is not waiting on a fresh YouTube/yt-dlp/remux pass
every time a trailer is opened.

Goals:
- return cached resolved trailer playback/remux URLs immediately when present
- use yt-dlp with cookies.txt support when YouTube requires auth/session cookies
- allow yt-dlp's JS runtime path when YouTube signature/player extraction needs it
- prefer fast 1080p-ready muxed playback first; only use 4K as an optional fallback
- return a single direct URL or remux inputs for the existing backend remux-cache flow
"""

from __future__ import annotations

import json
import time
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional
from urllib.parse import quote_plus


# v395: process-local single-flight guard. yt-dlp searches/extracts are expensive;
# duplicate requests for the same title/year/type should wait for the first job
# and then reuse its cache result instead of launching another yt-dlp process.
_INFLIGHT_LOCK = threading.Lock()
_INFLIGHT_EVENTS: Dict[str, threading.Event] = {}


@dataclass(frozen=True)
class TrailerRuntimeConfig:
    cookies_path: Optional[str] = None
    node_binary: Optional[str] = None
    cache_dir: str = "./trailer-resolve-cache"
    prefer_4k: bool = False
    min_height: int = 720
    max_height: int = 1080
    cache_ttl_seconds: int = 6 * 60 * 60


def _existing_file(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    path = Path(value).expanduser()
    return str(path) if path.exists() and path.is_file() else None


def trailer_cache_key(title: str, year: str = "", media_type: str = "movie") -> str:
    raw = "|".join(part.strip().lower() for part in [title, year, media_type] if part and part.strip())
    return quote_plus(raw or title.strip().lower())


def _cache_file(config: TrailerRuntimeConfig, key: str) -> Path:
    cache_dir = Path(config.cache_dir).expanduser()
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / f"{key}.json"


def read_cached_trailer(config: TrailerRuntimeConfig, key: str) -> Optional[Dict[str, Any]]:
    path = _cache_file(config, key)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    created = float(payload.get("createdAt") or 0)
    url = payload.get("playbackUrl") or payload.get("url")
    if not url or time.time() - created > config.cache_ttl_seconds:
        return None
    return payload


def write_cached_trailer(config: TrailerRuntimeConfig, key: str, payload: Dict[str, Any]) -> None:
    path = _cache_file(config, key)
    copy = dict(payload)
    copy.setdefault("createdAt", time.time())
    copy.setdefault("playbackUrl", copy.get("url"))
    path.write_text(json.dumps(copy, indent=2, sort_keys=True), encoding="utf-8")


def _format_score(fmt: Dict[str, Any], config: TrailerRuntimeConfig) -> tuple[int, int, int, int, int]:
    height = int(fmt.get("height") or 0)
    width = int(fmt.get("width") or 0)
    vcodec = str(fmt.get("vcodec") or "none").lower()
    acodec = str(fmt.get("acodec") or "none").lower()
    ext = str(fmt.get("ext") or "").lower()
    has_video = vcodec != "none" and height > 0
    has_audio = acodec != "none"
    muxed_bonus = 50 if has_video and has_audio else 0
    mp4_bonus = 25 if ext in {"mp4", "m4v", "mov"} else 0
    # v394: 1080p starts faster and avoids 4K split stream/remux stalls by default.
    preferred_height = 2160 if config.prefer_4k else 1080
    height_score = -abs(preferred_height - min(height, config.max_height))
    if height < config.min_height:
        height_score -= 10_000
    return (muxed_bonus, mp4_bonus, height_score, height, width)


def select_best_trailer_format(info: Dict[str, Any], config: TrailerRuntimeConfig) -> Optional[Dict[str, Any]]:
    formats = [f for f in info.get("formats", []) if f.get("url") and str(f.get("vcodec") or "none").lower() != "none"]
    if not formats:
        direct_url = info.get("url")
        return {"url": direct_url, "height": info.get("height"), "ext": info.get("ext")} if direct_url else None
    eligible = [f for f in formats if int(f.get("height") or 0) <= config.max_height]
    return max(eligible or formats, key=lambda fmt: _format_score(fmt, config))


def build_yt_dlp_options(config: TrailerRuntimeConfig) -> Dict[str, Any]:
    opts: Dict[str, Any] = {
        "quiet": True,
        "no_warnings": True,
        "skip_download": True,
        "noplaylist": True,
        "format": f"best[height<={config.max_height}][ext=mp4]/best[height<={config.max_height}]/bestvideo[height<={config.max_height}]+bestaudio/best",
    }
    cookies = _existing_file(config.cookies_path)
    if cookies:
        opts["cookiefile"] = cookies
    # yt-dlp can use Node for JS player/signature work when available. Keep this
    # optional so backend installs without Node still start normally.
    if config.node_binary:
        opts["js_runtimes"] = {"node": {"executable": config.node_binary}}
    return opts


def resolve_trailer_with_ytdlp(
    search_or_url: str,
    config: TrailerRuntimeConfig,
    *,
    title: str = "",
    year: str = "",
    media_type: str = "movie",
    reuse_cache: bool = True,
) -> Optional[Dict[str, Any]]:
    """Return selected direct trailer media info. Caller owns remux-cache handling."""
    key = trailer_cache_key(title or search_or_url, year, media_type)
    if reuse_cache:
        cached = read_cached_trailer(config, key)
        if cached:
            cached["cacheHit"] = True
            cached["singleFlightHit"] = False
            return cached

    owner = False
    with _INFLIGHT_LOCK:
        event = _INFLIGHT_EVENTS.get(key)
        if event is None:
            event = threading.Event()
            _INFLIGHT_EVENTS[key] = event
            owner = True

    if not owner:
        # Wait for the active resolver for this exact media key, then read the
        # cache it wrote. This is the critical fix for logs showing repeated
        # `yt-dlp search start` / `extract start` for the same trailer.
        event.wait(timeout=45)
        cached = read_cached_trailer(config, key) if reuse_cache else None
        if cached:
            cached["cacheHit"] = True
            cached["singleFlightHit"] = True
            return cached
        return None

    try:
        from yt_dlp import YoutubeDL  # imported lazily so backend can boot without hard failure in diagnostics

        query = search_or_url if search_or_url.startswith(("http://", "https://")) else f"ytsearch1:{search_or_url} trailer"
        with YoutubeDL(build_yt_dlp_options(config)) as ydl:
            info = ydl.extract_info(query, download=False)
        if not info:
            return None
        if "entries" in info:
            entries: Iterable[Dict[str, Any]] = (entry for entry in info.get("entries") or [] if entry)
            info = next(iter(entries), None)
            if not info:
                return None
        selected = select_best_trailer_format(info, config)
        if not selected:
            return None
        payload = {
            "title": info.get("title"),
            "webpageUrl": info.get("webpage_url"),
            "formatId": selected.get("format_id"),
            "height": selected.get("height"),
            "ext": selected.get("ext"),
            "url": selected.get("url"),
            "playbackUrl": selected.get("url"),
            "needsRemux": str(selected.get("acodec") or "none").lower() == "none",
            "cacheHit": False,
            "singleFlightOwner": True,
        }
        if payload.get("playbackUrl"):
            write_cached_trailer(config, key, payload)
        return payload
    finally:
        with _INFLIGHT_LOCK:
            event = _INFLIGHT_EVENTS.pop(key, None)
            if event is not None:
                event.set()
