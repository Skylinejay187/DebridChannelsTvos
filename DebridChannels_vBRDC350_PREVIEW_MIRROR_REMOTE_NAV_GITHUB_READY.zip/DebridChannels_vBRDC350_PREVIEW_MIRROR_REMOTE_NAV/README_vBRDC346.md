# vBRDC346 — Golden Live TV refinement
Version 1.0.1048 / build 1048.

Authoritative source: vBRDC345 ZIP. This release keeps the v345 4×3 grid, original focus/navigation graph, dual inward/split inward effects, wallpaper lifecycle, and existing header artwork. It does not revive rejected v340–v343 visual themes.

- On new installs, Dual Inward is the initial card effect. An existing saved effect is never overwritten; a stable-UI reset returns to Dual Inward. The original Unity card shape is retained.
- Dual Inward Strong and Split Inward Strong add a greater opposing fixed 3D perspective, retaining split-center gutter and existing focus navigation.
- Wordmark width can be changed between Tiny / Small / Original / Large. Small (88 pt) is the default; changing it preserves the left visual margin.
- The independent Live TV typography option has nine built-in presets, including regular and light weights, exposed in Settings and the same real-card-renderer confirmation screen. No font files are bundled.
- Full Card Artwork now uses aspect-fill and cropping, not forced stretching; only the full-card artwork requests the 768px image decode bucket. The existing 512px bounded path is preserved for frosted cards. Switching styles re-evaluates the same artwork owner without new per-card tasks.
- The live dashboard confirmation now reads saved full/frosted style, program progress, ring color/motion, channel-number position, and logo size. Shape, effect, size, and font remain candidate-only until Apply.
- Profile restore allowlist now includes previously omitted v345 Live TV shape/effect/size, preview style, selected live engine, wide canvas, custom wallpaper settings, and top menu size. It also explicitly includes new font and chrome-logo size preferences. Entitlements, owner state, backup bookkeeping and ephemeral diagnostics are not copied.

Validation limit: the Swift frontend parser validates syntax here. A full Apple tvOS SDK compile, install, and runtime tests require macOS/Xcode and are **not** claimed.
