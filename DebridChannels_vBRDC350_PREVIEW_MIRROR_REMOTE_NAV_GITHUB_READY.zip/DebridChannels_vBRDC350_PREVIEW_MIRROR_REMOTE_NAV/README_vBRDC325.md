# vBRDC325 — App-Wide Invalidation Re-Core
Version 1.0.1027 (1027)

Hardware result from v324: somewhat better, but main catalogs, Settings and app-wide focus
still hitch. This pass targets shared invalidation rather than changing visuals.

Nuvio re-check:
- Current Nuvio tvOS source uses persistent Home state above the view hierarchy.
- It documents cascading body re-renders as a primary tvOS performance failure.
- It uses Equatable Home/card/backdrop boundaries and a main-thread stall watchdog.

Signal findings/fixes:
1. FixedSlotFocusedCatalogCard was an ObservedObject subscriber to the process-wide
   UnityAnimationCoordinator. A navigation burst publishes start, settle and recovery revisions,
   so every visible card could rebuild several times around one D-pad burst. v325 reads the same
   UNITY policy without subscribing each card globally; actual focus props still update visuals.
2. MediaInfoPopup had the same global UNITY subscription. Moving between Play / Trailer /
   Find Links could therefore rebuild the whole popup at navigation start/settle/recovery.
   v325 removes that global subscription while retaining the exact animations/policy.
3. CatalogStore.rows already publishes. catalogRowsRevision was also @Published and incremented
   from rows.didSet, causing two app-wide CatalogStore invalidations for one catalog commit.
   The revision remains for compatibility but is no longer a second publisher.
4. Added a Signal main-thread stall watchdog modeled on the architectural idea used by Nuvio:
   16ms background ping, logs only stalls >=35ms, zero SwiftUI publication. It tags the active
   UNITY surface so remaining 100-1500ms stalls can be tied to Home/Settings/Guide/etc.

No visual changes. UNITY, trailer presentation, wallpapers, focus effects, catalog geometry,
playback and all features remain intact.
