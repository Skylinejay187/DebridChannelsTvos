# vBRDC348 — Preview Mirror Live TV Dashboard

Authoritative source: vBRDC347 / 1.0.1049 / build 1049. This is a focused presentation-only candidate, not a new wallpaper, EPG, backend, or scrolling architecture.

New **Settings → Live TV → Live TV Dashboard** choice: **Golden** (default, preserves v345/v347) or **Preview Mirror**. Separate persistence key `liveTVDashboardStyleV348` participates in profile backup/restore and stable UI reset. The existing card shape, 3D effects (including Dual/Split Strong), size, fonts, artwork style, dynamic wallpaper and Gracenote configuration remain independent.

Preview Mirror brings the visual layout of the full-screen confirmation into the actual provider-backed grid: left SIGNAL + isolated Live TV header, right All Channels/count + working GRID chip, proportionally larger four-column/three-row cards, separate lower NOW ON AIR and interactive CATEGORIES / GUIDE / OPTIONS actions. Golden remains unchanged when selected. The actual twelve focusable channel cards, channel IDs, LiveTVSourceModel current/next programs, bounded artwork pipeline, preview decoder, guide and paging are reused; no mockup/demo lineup, duplicate provider/EPG loading, second focus engine or periodic tasks are added to production.

The confirmation and real dashboard now share SwiftUI header/footer chrome components; its cards continue using the production card renderer. The confirmation remains an offline/cached channel snapshot for Settings only, whereas Preview Mirror always uses the real `liveTVGridPageChannels` and `liveModel.currentProgram(for:)` path. CATEGORIES opens the existing quick tools panel with category-first focus; GUIDE opens the real full EPG; OPTIONS opens the same existing panel with refresh/tools focus. GRID uses the existing Guide toggle. Up on GRID reveals and focuses persistent app navigation; the top menu is visually suppressed when inactive to avoid duplicating SIGNAL over the mirror header. The wordmark image is decoded once and reused, rather than re-reading the large PNG every re-render.

Validation performed: source syntax parse, plist/project version sync, source-level wiring checks and ZIP CRC. The Linux environment lacks Xcode/tvOS SDK and does not provide device screenshots or a full compiler typecheck. Install/build and confirm Live TV grid, focus, Guide, category and options actions on Apple TV before accepting v348 as authoritative.

App version: 1.0.1050; build: 1050.
