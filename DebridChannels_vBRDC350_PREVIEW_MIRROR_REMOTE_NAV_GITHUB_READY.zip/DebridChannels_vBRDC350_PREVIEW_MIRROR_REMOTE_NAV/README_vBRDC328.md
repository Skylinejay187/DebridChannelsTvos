# vBRDC328 — System-Wide Frame-Budget + Build Fix
Version 1.0.1030 (1030)

Built directly from the supplied vBRDC327 package.

Build fix:
- Removed the second/redundant `Equatable` conformance and duplicate `==` implementation for `FixedSlotFocusedCatalogCard`.
- Keeps the vBRDC327 in-struct semantic equality implementation that isolates focused-card updates.

System-wide performance correction:
- Found an app-wide production overhead introduced with the device performance probes: the hidden performance HUD still started a `CADisplayLink` on the MainActor for every display frame, while the stall watchdog independently dispatched a main-queue ping every 16 ms.
- Those two diagnostic systems therefore competed with focus, SwiftUI commits, Guide navigation, artwork publication, Aether/KSPlayer presentation, Bluetooth command handling, and app-switcher resume even when the HUD was OFF.
- vBRDC328 makes both probes strictly opt-in with the existing Performance HUD switch. With the HUD off (normal production state), both are stopped and add zero recurring per-frame/main-queue diagnostic work.
- Added a real watchdog stop path so turning diagnostics off at runtime removes its timer immediately.

Audit findings retained for follow-up profiling:
- CatalogStore remains a large @MainActor ObservableObject with many published properties and many EnvironmentObject subscribers. vBRDC325-v327 already reduced several high-frequency publications and subscriptions; a wholesale store split is intentionally not attempted in this build because it would be a high-regression architectural rewrite.
- Background-priority async metadata tasks that are MainActor-isolated were reviewed. Their network awaits suspend rather than synchronously blocking the actor; moving them wholesale without device traces would add concurrency risk. The newly found always-on 60 Hz diagnostics were a concrete unconditional frame-budget consumer and are removed first.

No intentional visual, navigation, Guide, catalog, trailer, wallpaper, source, Aether, KSPlayer, or Bluetooth behavior changes.
