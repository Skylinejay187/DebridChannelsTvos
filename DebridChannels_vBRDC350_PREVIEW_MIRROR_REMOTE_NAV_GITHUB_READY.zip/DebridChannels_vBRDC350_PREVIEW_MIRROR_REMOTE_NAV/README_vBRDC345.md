# vBRDC345 — Dual inward perspective and Live TV wallpaper continuity

Source: vBRDC344 package only. Version 1.0.1047 / build 1047. No changes to backend, video players, catalog layout, guide or fixed 12-slot focus graph.

- Card Effect choices: Original, Tilt Left, Tilt Right, Dual Inward, Split Inward. Removed Float and Gentle Pop; older persisted unrecognized selections fall back to Original.
- Dual Inward: grid columns 0–1 yaw +4° at rest (+8.5° focused), columns 2–3 yaw -4° at rest (-8.5° focused). This is compositor-only, with no extra focusable objects.
- Split Inward: same 3D projection, with a non-interactive 46-point central gutter per grid row. Four card slots, channel IDs and directional ordering stay the same. Dashboard confirmation uses the same shared card renderer and arrangement, with a proportionate 39-point preview gutter.
- Live TV procedural dynamic wallpaper previously dropped to 6 fps during any navigation burst; this build keeps grid-only motion at 18–20 fps during navigation, with the normal configured cadence at rest. GIF/video wallpaper continues under the existing Live TV ownership condition. The wallpaper is explicitly unmounted in background/inactive scene, Guide, other tabs, search, detail and playback. No increased cadence in non-Live-TV surfaces.
- Existing icon/Live TV artwork is unchanged.

Validation: Swift frontend parsing and ZIP integrity can be checked locally. An Apple SDK typecheck and real Apple TV runtime test are required to confirm motion and navigation.
