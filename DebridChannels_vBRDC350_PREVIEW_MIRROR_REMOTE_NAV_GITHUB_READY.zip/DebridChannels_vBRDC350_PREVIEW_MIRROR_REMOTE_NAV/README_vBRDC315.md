# vBRDC315 — Single-Surface Performance Re-Core
Version: 1.0.1017 (1017)

Hardware evidence that drove this pass:
- Settings performance changes when Live TV Current/Spread Out changes.
- Catalog/system overlays are poor while full-screen playback is smooth.
- v314 was same/worse and poster readiness regressed.

Root cause corrected:
The complete LiveTVScreen SwiftUI/render tree was intentionally kept mounted under the
entire non-playback app. It was opacity 0 under Settings/Favorites/etc and fully composited
under Home/Movies/Shows. Thus even Settings could pay for Live TV layout/focus/card work,
and catalog browsing rendered on top of a second heavyweight screen.

v315 architecture:
- RootView owns one persistent LiveTVSourceModel independently of LiveTVScreen.
- LiveTVScreen pixels mount only when Live TV owns the screen or during the brief
  catalog<->Live transition.
- Steady-state Home/Movies/Shows no longer composite the Live TV grid underneath.
- Dedicated Settings/Favorites/Sports/Membership no longer retain an opacity-0 Live TV tree.
- Removed the unused SignalUIWorkScheduler and its duplicate MainActor Tasks that were
  launched twice for every navigation event.
- Restored the pre-v314 shared-backend poster byte-cache path because direct-origin loading
  regressed poster readiness on hardware.
- Catalog poster hydration is snapshot-driven instead of focus-driven and warms only a
  bounded active/next-row corridor.
- Full-screen VOD and Live TV playback paths are unchanged.
- Trailer playback behavior is unchanged.

This is the first pass that separates persistent DATA from persistent PIXELS, matching the
architecture used by performant tvOS apps: stores/caches survive navigation; heavyweight
render trees do not remain hidden under unrelated screens.

Validation performed here: swift frontend parse of all Sources Swift files and synchronized
version metadata. This is not a full Xcode/tvOS semantic build.
