# vBRDC319 — Phase 2 Spotlight Compiler Decomposition
Version: 1.0.1021 (1021)

The v318 GitHub/Xcode log still failed at VBRDC193SpotlightHubPanel.body with
"compiler is unable to type-check this expression in reasonable time".

v319 decomposes the entire Spotlight Hub body, not only the related-title card:
- header
- content stack
- attribution
- background
- border
- async Spotlight loading task

The async task body is moved into loadSpotlightHub(), substantially reducing the
generic SwiftUI expression Xcode must infer for body.

All Phase 2 poster hydration/queue changes and themed-logo behavior are preserved.
UNITY, trailers, VOD and Live TV playback remain preserved.

Validation here: swiftc frontend parse of all Sources Swift files and synchronized
version metadata. GitHub/Xcode is the semantic compiler test.
