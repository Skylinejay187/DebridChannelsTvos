# vBRDC326 — Triple-Audit System-Wide Re-Core
Version 1.0.1028 (1028)

Requested hardware follow-up:
- Spotlight Hub related Trakt artwork smaller and exactly four cards.
- Repeat the app-wide performance audit multiple times, including Home catalogs,
  top menu, Settings scrolling/loading, and remaining high worst-frame stalls.

Triple audit findings:
1. SettingsScreen instantiated two unused @StateObject runtimes:
   SportsLiveZoneModel and LiveTVSourceModel. They were not referenced anywhere else
   in Settings, yet made Settings an observer/owner of duplicate runtime models.
   Removed; RootView remains the single app-scoped owner.
2. Settings used LazyVStack inside the active category's focus path. Because only one
   category is mounted at a time, lazy mounting provided little memory value while
   adding mount/unmount work as tvOS focus traversed controls. The three category
   wrappers are now ordinary VStack, keeping controls pre-mounted for stable focus.
3. Persistent top navigation subscribed directly to the enormous CatalogStore in both
   its host and TopMenuBar. Unrelated source/cache/playback/catalog publications could
   rebuild top chrome. The menu now receives the app-scoped store as a plain reference
   for synchronous actions/current reads; UnityAppCore remains the observed navigation
   authority.
4. Settings had the same broad CatalogStore subscription. It now keeps a plain reference
   for actions/current reads while its actual Settings state and AppStorage values remain
   reactive. This removes unrelated catalog/source/cache/playback invalidations from the
   Settings scroll path.
5. v325's duplicate CatalogStore row publication fix, poster/MediaInfo UNITY subscriber
   isolation, and main-thread stall watchdog are preserved.

Nuvio comparison:
Current Nuvio tvOS 3.2.8 documents removal of obsolete scroll-tracking state, non-lazy
row containers with pre-mounted card virtualization, Equatable rendering boundaries,
and deferred secondary enrichment to avoid navigation stalls. Signal adapts the relevant
principles without copying Nuvio code or changing Signal visuals.

Spotlight Hub:
- related Trakt cards: 4 (was 3)
- card size: 82x54 (was 94x62)
- themed logo box: 68x18 (was 78x20)
- related artwork prefetch: first 4 (was first 3)
- decode tier reduced to 420px for the smaller card.

No intentional changes to UNITY visuals, trailer presentation, playback, wallpapers,
catalog geometry, top-menu appearance, Settings appearance, or feature set.
