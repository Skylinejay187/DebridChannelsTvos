# vBRDC318 — Phase 2 Build Fix
Version: 1.0.1020 (1020)

Fixes the exact Xcode compiler failure from v317:
DebridChannelsTVOSApp.swift:33562 — compiler unable to type-check VBRDC193SpotlightHubPanel.body in reasonable time.

The new Spotlight themed-logo card expression is split into two smaller @ViewBuilder helpers:
- spotlightRelatedCard(_:)
- spotlightRelatedTitle(_:)

No Phase 2 poster hydration behavior was removed. UNITY, playback, trailers, poster queue,
catalog hydration, and compact Spotlight themed-logo behavior are preserved.

Validation here: all Sources Swift files pass swiftc frontend parse and version metadata is synchronized.
GitHub/Xcode remains the semantic build test.
