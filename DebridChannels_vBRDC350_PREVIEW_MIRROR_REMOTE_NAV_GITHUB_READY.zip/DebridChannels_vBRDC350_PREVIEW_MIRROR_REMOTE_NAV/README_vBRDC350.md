# vBRDC350 — Preview Mirror remote navigation and chrome isolation

Source baseline: **vBRDC349 / 1.0.1051**. This is a scoped Preview Mirror update.

- Preview Mirror hides the duplicated absolute-top-left Signal app wordmark, always retaining its one dashboard logo.
- Global menu/search/time are hidden by default ONLY in Preview Mirror and are disabled as focus targets while hidden. From the top card row, Up focuses GRID; Up again reveals the native top menu. A visible dashboard hint documents that path.
- Optional Settings > Live TV > Preview Mirror Top Menu by Default shows the menu/search/time persistently. All three are positioned at y=28 above the Mirror header, avoiding the All Channels/GRID collision. Golden/other tabs keep their existing positions.
- The Mirror bottom bar now has native focusable Select/OK buttons: CATEGORIES opens a right-side real category chooser; GUIDE opens existing real EPG; OPTIONS navigates to normal Settings. Third-row Down reaches the footer; Up returns to its selected channel.
- Old left Quick Guide rail is not mounted in Mirror; triple-Left on first-column page 1 is disabled only in Mirror. Golden still owns it.
- Category panel uses the existing provider category list and selection function; Guide still reads existing Gracenote state; no duplicate model/subscriptions/timers were introduced.
- Top-menu preference included in settings backup/restore and stable reset, and allowed in security restore key list.

Check full GitHub/Xcode build and Apple TV Siri Remote focus navigation on device; Linux Swift frontend parsing alone is not a tvOS type-check.
