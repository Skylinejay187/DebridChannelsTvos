# vBRDC331 / 1.0.1033 / build 1033

Performance continuation from vBRDC330 only.

- Preserves v328 diagnostics opt-in frame-budget fix.
- Preserves v329 focused-card equality and wallpaper decoder recovery fixes.
- Preserves v330 synchronized version/build validation.
- Settings: long control sections use LazyVStack so offscreen controls are not eagerly materialized.
- Settings: automatic managed-provider verification no longer launches during Settings entry/scroll; Verify Connections remains the explicit refresh path and cached health remains available.
- No playback-engine architecture changes; Aether primary / KSPlayer fallback preserved.
