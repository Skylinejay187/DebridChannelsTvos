# vBRDC331 — Version synchronization build fix

Donor: vBRDC329_GITHUB_BUILD_READY.zip, unchanged source apart from version metadata.

GitHub run 95285817658 failed in the V1041 Production configuration validation build phase: Sources/Info.plist still declared 1.0.1029 while project.yml declared 1.0.1031. TopShelfExtension/Info.plist was stale too.

Fixed both plist marketing/build versions, both release IDs (including DebridRelease), and both project.yml target settings. All synchronized to vBRDC331 / 1.0.1033 (1032). No playback, focused-card, wallpaper, or performance source changes.

Validation: archive CRC and plist/project version checks only. Full Apple tvOS compilation must run on GitHub/Xcode.
