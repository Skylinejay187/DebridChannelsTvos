# vBRDC344 — Live TV card customization and correct isolated branding

Source: vBRDC343 candidate, preserving the v334 focus architecture. This replaces the rejected v342/v343 faux themes, not playback, Guide or catalog navigation. Version 1.0.1046, build 1046.

- Independent Shape (Original UNITY, Squared, Soft Rounded, Cinema Curve, Pill), Effect (Original, Tilt Left, Tilt Right, Float, Gentle Pop) and Size (Compact, Standard, Large).
- Size is compositor-only within existing fixed 4x3 slots, rather than altering grid focus geometry. Large is limited to 1.04 to avoid collisions; Compact is 0.90.
- Settings full-screen preview: real retained channel identities and cached EPG where available, actual production card renderer and animated logo renderer; sample lineup only when no real cached channels exist. Shape/effect/size each independently cycle; Apply commits all three; Cancel commits none.
- No fake card-theme surface layers. Original card materials/metadata retain their established renderer. The same single focus ring is retained.
- Live TV header images are cropped from the user-supplied Live TV design with transparency; no black photo background, full app tile or Signal app icon inside the TV logo.
- No new wallpaper, backend or player changes. No mockups generated.

Validation: Swift frontend parse can be run on non-macOS; Xcode/tvOS compilation and actual device rendering still require CI/device testing.
