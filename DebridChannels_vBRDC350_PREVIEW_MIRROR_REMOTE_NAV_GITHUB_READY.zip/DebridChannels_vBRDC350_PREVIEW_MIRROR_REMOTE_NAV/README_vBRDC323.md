# vBRDC323 — Phase 5 Visual-Lock Performance Final
Version 1.0.1025 (1025)

## Visual regression correction
- Restores Signal's prior trailer/catalog presentation: launching a full trailer no longer
  dismisses or unmounts the catalog rows.
- UNITY and the catalog surface remain visually resident exactly as before.
- Trailer performance isolation is handled internally: focused-card preview/hero auxiliary work
  is suspended while the trailer owns the decoder lane, then resumes after trailer teardown.

## Phase 5 performance work — no visual substitutions
- Ordinary horizontal D-pad movement no longer creates/cancels a catalog lazy-repair task on
  every focus step. Repair is requested from selection movement only when the focused item
  genuinely has no poster/landscape artwork.
- Internal catalog repair cooldown/queue/request/success bookkeeping no longer writes to the
  app-wide observable status string, eliminating avoidable root SwiftUI invalidations.
- Phase 4 persistent EPG/Gracenote recovery is explicitly armed on scene-active while the
  Live/UNITY owner is alive.
- Existing Equatable focused-card isolation, stable structural preview slots, decoder ownership,
  artwork cache, UNITY visuals, trailers, Live TV playback and VOD playback are preserved.

This build intentionally does not remove previews, wallpapers, UNITY, catalog rows, animations,
themes, or trailer presentation to manufacture a performance gain.
