import Foundation
struct Related { let landscapeURL: String?; let posterURL: String?; let logoURL: String? }
func validURL(_ value: String?) -> String? { value }
func check(_ related: [Related]) -> [URL] {
        let spotlightURLs: [URL] = related.prefix(3).flatMap { relatedItem -> [URL] in
            let artwork = validURL(relatedItem.landscapeURL ?? relatedItem.posterURL)
                .flatMap { URL(string: $0) }
            let logo = validURL(relatedItem.logoURL)
                .flatMap { URL(string: $0) }
            return [artwork, logo].compactMap { $0 }
        }
    return spotlightURLs
}
let urls = check([Related(landscapeURL: "https://example.com/poster.jpg", posterURL: nil, logoURL: "https://example.com/logo.png")])
precondition(urls.count == 2)
print("Spotlight String-to-URL compiler fixture: PASS (2 URLs)")
