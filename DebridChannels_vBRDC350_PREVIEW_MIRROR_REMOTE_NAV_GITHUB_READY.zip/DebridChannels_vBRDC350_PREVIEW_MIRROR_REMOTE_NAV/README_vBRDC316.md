# vBRDC316 — Restore UNITY Live TV visual root
Version: 1.0.1018 (1018)

Regression corrected: v315 mounted LiveTVScreen only on the Live tab. This removed the real Live TV visual donor under Home/Movies/TV Shows, causing the black empty right-side/backdrop area and breaking the persistent UNITY composition contract.

Restored the v314 mounting/compositing policy while retaining v315 independent LiveTVSourceModel ownership: the same physical LiveTVScreen remains mounted across non-playback tabs; its pixels are visible behind Home/Movies/TV Shows, hidden under dedicated Settings/Favorites/Sports/Membership screens, and removed only for full playback. The existing inactive-screen cancellation/preview suppression remains. The actual Live TV video/backdrop and artwork are not replaced with synthetic/frozen imagery.

Kept the other v315 changes: removed redundant navigation scheduler, restored shared cached artwork path, snapshot-driven poster hydration, and full-screen VOD/Live TV playback/trailers unchanged.

Regression checks required on Apple TV: 1) Live TV artwork/backdrop visible under Home/Movies/TV Shows; 2) channel/art persists on returning to Live TV; 3) dedicated screens do not visually leak Live; 4) preview/audio/lifecycle and navigation remain functional; 5) measure FPS/overlay smoothness separately. This build restores UNITY visuals; it is NOT claimed to have achieved the performance target.

Static validation: Swift frontend parse, plist/project version checks and structural UNITY assertions. Full semantic build and real Apple TV verification pending.
