import Foundation
typealias UIImage = Int
private actor LiveTVArtworkSharedFetchRegistry {
    struct Key: Hashable {
        let url: URL
        let maxPixelSize: Int
        let allowDuringFullScreenPlayback: Bool
    }

    // vBRDC347: A coalesced fetch belongs to its *subscribers*, not to the last
    // URL that requested it. Cancel the worker when its last visible/prefetch owner
    // disappears. The old registry let orphaned image fetches/decodes run for tens
    // of seconds as the user paged through channels, then an older completion
    // could erase the registry handle for a newer same-URL request.
    private struct Entry {
        let token: UUID
        let task: Task<UIImage?, Never>
        var subscribers: Set<UUID>
    }
    private var tasks: [Key: Entry] = [:]

    func image(
        for key: Key,
        operation: @escaping @Sendable () async -> UIImage?
    ) async -> UIImage? {
        guard !Task.isCancelled else { return nil }
        let subscriber = UUID()
        let token: UUID
        let task: Task<UIImage?, Never>
        if var entry = tasks[key] {
            entry.subscribers.insert(subscriber)
            tasks[key] = entry
            token = entry.token
            task = entry.task
        } else {
            token = UUID()
            task = Task(priority: .utility) { await operation() }
            tasks[key] = Entry(token: token, task: task, subscribers: [subscriber])
        }
        let result = await withTaskCancellationHandler(operation: {
            await task.value
        }, onCancel: {
            Task { await self.unsubscribe(key: key, token: token, subscriber: subscriber) }
        })
        unsubscribe(key: key, token: token, subscriber: subscriber)
        return Task.isCancelled ? nil : result
    }

    private func unsubscribe(key: Key, token: UUID, subscriber: UUID) {
        guard var entry = tasks[key], entry.token == token else { return }
        entry.subscribers.remove(subscriber)
        if entry.subscribers.isEmpty {
            entry.task.cancel()
            tasks.removeValue(forKey: key)
        } else {
            tasks[key] = entry
        }
    }

    func cancelAll() {
        for entry in tasks.values { entry.task.cancel() }
        tasks.removeAll()
    }
}

actor Counter { var started = 0; func increment() { started += 1 }; func count() -> Int { started } }
@main struct ActorOwnerTests {
    static func main() async {
        let shared = LiveTVArtworkSharedFetchRegistry()
        let counter = Counter()
        let key = LiveTVArtworkSharedFetchRegistry.Key(url: URL(string: "https://example.com/one")!, maxPixelSize: 512, allowDuringFullScreenPlayback: false)
        let operation: @Sendable () async -> Int? = {
            await counter.increment()
            try? await Task.sleep(nanoseconds: 180_000_000)
            return Task.isCancelled ? nil : 42
        }
        let first = Task { await shared.image(for: key, operation: operation) }
        try? await Task.sleep(nanoseconds: 20_000_000)
        let second = Task { await shared.image(for: key, operation: operation) }
        try? await Task.sleep(nanoseconds: 40_000_000)
        first.cancel()
        let result1 = await first.value
        let result2 = await second.value
        precondition(result1 == nil && result2 == 42, "cancelled subscriber must not cancel remaining owner")
        let coalescedCount = await counter.count()
        precondition(coalescedCount == 1, "same image must share one worker")
        let abandonedKey = LiveTVArtworkSharedFetchRegistry.Key(url: URL(string: "https://example.com/two")!, maxPixelSize: 512, allowDuringFullScreenPlayback: false)
        let abandoned = Task { await shared.image(for: abandonedKey, operation: operation) }
        try? await Task.sleep(nanoseconds: 20_000_000)
        abandoned.cancel()
        _ = await abandoned.value
        try? await Task.sleep(nanoseconds: 20_000_000)
        let fresh = Task { await shared.image(for: abandonedKey, operation: operation) }
        let freshValue = await fresh.value
        precondition(freshValue == 42, "new generation must be able to start")
        let finalCount = await counter.count()
        precondition(finalCount == 3, "cancelled last owner must not reuse orphan worker")
        print("PASS: coalesced worker shared; cancelled subscriber isolated; final-owner cancellation; new generation restarted")
    }
}
