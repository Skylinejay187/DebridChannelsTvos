# vBRDC320 — Phase 2 Xcode Type Fix and Prefetch Ownership Audit
Version: 1.0.1022 (1022); source of truth: vBRDC319.

## Exact build failure
GitHub Xcode 16.4, DebridChannelsTVOSApp.swift:33680:
`cannot assign value of type '[Array<String>.Element]' to type '[URL]'`.
Spotlight's `validURL` returns `String?`; the new hydration code tried to
assign its compactMapped strings directly to `[URL]`.

Fix: convert each validated string via `URL(string:)` and compactMap the URL
optionals. The accepted `RemoteImageFit` String-facing rendering remains intact.

## Deep audit of Phase 2 queue ownership
- Two other lifecycle entry points (hidden VOD overlay and full-screen Live TV)
  now clear both queued and desired prefetch URLs when cancelling tasks.
- Cancellation/completion race: a canceled URLSession task cannot remove a
  replacement task for the same URL or publish its stale bytes. Per-URL owner
  token guards callback ownership.
- No changes to UNITY visuals, playback engines, trailers, Guide or Live TV
  rendering in this build.

## Phase 4 requirement — EPG + Gracenote reliability (locked scope)
At Phase 4, explicitly audit and repair channel lineup/EPG and Gracenote loading:
- Cold start, sleep/wake, overnight idle, return from playback and network recovery.
- Single owned refresh generation with timeout/retry/backoff and stale-result rejection.
- Persist last-known-good lineup, guide programme data and channel logos; show cached
  data immediately while refreshing; never clear valid displayed data on failed refresh.
- Correct channel identity/mapping and logo fallback: Gracenote first where present,
  channel-supplied logo otherwise; force rehydrate missing visible assets.
- Protect guide/grid responsiveness: fetch/parse/index off main actor where feasible,
  commit one stable, consistent snapshot; measure latency and FPS on Apple TV.
- Verify both Current and Spread Out layouts plus category switching and long idle.
The exact implementation must follow Phase 4 source audit and hardware results.

## Validation
All Sources Swift files pass `swiftc -frontend -parse`, Xcode-specific semantic
build unavailable locally. A standalone Swift compiler fixture typechecks the
exact String? -> URL? -> [URL] mapping. Both targets/plists metadata validated.
