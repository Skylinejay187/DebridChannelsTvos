# vBRDC334 / 1.0.1036 / build 1036

Architectural performance pass based directly on the proven vBRDC333 row-geometry baseline.

- Keeps v333 fixed catalog-row geometry/navigation behavior.
- Settings no longer observes process-wide UnityAppCore publications.
- Settings decorative Canvas no longer subscribes to UnityAppCore.
- Removes the artificial 90 ms catalog-artwork hydration delay.
- Near-visible catalog posters prewarm the exact decoded 384px rail bucket off-main.
- Artwork byte prefetch transport concurrency raised while ImageIO decode remains bounded at two.
- Companion Catalog Server Phase 2.14 serves poster-card (500x750) on catalog/search hot paths instead of poster-detail (1000x1500).
