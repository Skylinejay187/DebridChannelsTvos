# Debrid Channels tvOS v49

True split math layout: top-left landscape hero, bottom-left Continue Watching preview, right side 4x2 equal portrait grid.

Upload this ZIP to GitHub. Run the included workflow. Extract the artifact ZIP, then upload only:

`DebridChannelsTVOS_v49_UPLOAD_THIS_IPA.ipa`

Preserves the v14 Signulous-compatible packaging structure.
