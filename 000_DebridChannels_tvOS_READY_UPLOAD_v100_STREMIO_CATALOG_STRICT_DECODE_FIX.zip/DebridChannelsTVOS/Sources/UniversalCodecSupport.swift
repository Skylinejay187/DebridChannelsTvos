import SwiftUI
import AVFoundation

#if canImport(TVVLCKit)
import TVVLCKit
#endif

// v95 universal-codec boundary:
// - AVFoundation remains the fast/default Apple-native path.
// - TVVLCKit is used automatically when the framework is present and the URL/container
//   looks like an MKV/DTS/unsupported-codec edge case.
// - Raw magnet/torrent streaming still requires a separate torrent framework/service;
//   this file exposes diagnostics so the app does not claim a magnet is directly playable.

enum UniversalCodecSupport {
    static let buildMarker = "DEBRID_CHANNELS_TVOS_BUILD_V97_STREMIO_API_CONTRACT_RESTORE"

    static var vlcCompiledIn: Bool {
        #if canImport(TVVLCKit)
        return true
        #else
        return false
        #endif
    }

    static func shouldPreferVLC(for url: URL) -> Bool {
        let value = url.absoluteString.lowercased()
        if value.hasPrefix("magnet:") { return false }
        return value.contains(".mkv")
            || value.contains("dts")
            || value.contains("truehd")
            || value.contains("eac3")
            || value.contains("atmos")
            || value.contains("x265")
            || value.contains("hevc")
    }

    static func playbackEngineName(for url: URL) -> String {
        if shouldPreferVLC(for: url) && vlcCompiledIn { return "TVVLCKit/libVLC fallback" }
        if shouldPreferVLC(for: url) && !vlcCompiledIn { return "AVFoundation fallback; TVVLCKit pod missing" }
        return "AVFoundation"
    }

    static func magnetDiagnostic(for value: String) -> String? {
        let lower = value.lowercased()
        guard lower.hasPrefix("magnet:") || lower.contains("infohash") else { return nil }
        return "Magnet/infoHash items require the torrent framework/service path before playback. Direct TorBox/debrid HTTP(S) stream URLs play in-app; raw torrent streaming is isolated from AVFoundation."
    }
}

struct UniversalVideoSurface: View {
    let url: URL
    let avPlayer: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    var body: some View {
        #if canImport(TVVLCKit)
        if UniversalCodecSupport.shouldPreferVLC(for: url) {
            TVVLCKitVideoSurface(url: url)
        } else {
            VideoSurface(player: avPlayer, videoGravity: videoGravity)
        }
        #else
        VideoSurface(player: avPlayer, videoGravity: videoGravity)
        #endif
    }
}

#if canImport(TVVLCKit)
struct TVVLCKitVideoSurface: UIViewRepresentable {
    let url: URL

    final class Coordinator {
        let player = VLCMediaPlayer()
        var currentURL: URL?
    }

    final class VLCView: UIView {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> VLCView {
        let view = VLCView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: VLCView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func configure(view: VLCView, coordinator: Coordinator) {
        guard coordinator.currentURL != url else { return }
        coordinator.currentURL = url
        coordinator.player.drawable = view
        coordinator.player.media = VLCMedia(url: url)
        coordinator.player.play()
    }

    static func dismantleUIView(_ uiView: VLCView, coordinator: Coordinator) {
        coordinator.player.stop()
    }
}
#endif
