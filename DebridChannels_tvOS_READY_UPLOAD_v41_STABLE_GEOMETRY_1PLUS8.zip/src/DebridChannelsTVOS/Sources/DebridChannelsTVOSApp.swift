import SwiftUI
import AVKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack(alignment: .top) {
            switch store.selectedTab {
            case .home:
                NineSlotHome(filter: nil)
            case .movies:
                NineSlotHome(filter: "movie")
            case .shows:
                NineSlotHome(filter: "series")
            case .live:
                LiveTVPlaceholder()
            case .settings:
                SettingsScreen()
            }

            TopMenuBar()
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?

    var body: some View {
        HStack(spacing: 34) {
            ForEach(AppTab.allCases) { tab in
                Button {
                    withAnimation(.spring(response: 0.36, dampingFraction: 0.82)) {
                        store.selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 8) {
                        Text(tab.rawValue)
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(store.selectedTab == tab ? .white : .white.opacity(0.58))
                        Capsule()
                            .fill(store.selectedTab == tab ? Color.orange : Color.clear)
                            .frame(width: tab.rawValue.count > 6 ? 78 : 54, height: 5)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 10)
                    .scaleEffect(focusedTab == tab ? 1.08 : 1.0)
                    .shadow(color: focusedTab == tab ? .orange.opacity(0.55) : .clear, radius: 18)
                }
                .buttonStyle(.plain)
                .focused($focusedTab, equals: tab)
            }
        }
        .padding(.horizontal, 34)
        .padding(.vertical, 8)
        .focusSection()
        .background(
            RoundedRectangle(cornerRadius: 28)
                .fill(Color.black.opacity(0.38))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
        )
        .padding(.top, 2)
        .zIndex(999)
        .onChange(of: store.menuFocusToken) { _ in
            focusedTab = store.selectedTab
        }
    }
}


struct NineSlotHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex = 0
    @State private var selectedIndex = 0
    @FocusState private var isCanvasFocused: Bool

    var activeRows: [MediaRow] {
        let rows = store.rows
        guard let filter else { return rows }
        return rows.map { row in
            MediaRow(id: row.id, title: row.title, items: row.items.filter { $0.type.lowercased().contains(filter) })
        }.filter { !$0.items.isEmpty }
    }

    var currentRow: MediaRow {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        return rows[min(rowIndex, rows.count - 1)]
    }

    var items: [MediaItem] {
        currentRow.items.isEmpty ? CatalogStore.demoRows()[0].items : currentRow.items
    }

    var focused: MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        return items[normalized(selectedIndex)]
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                // Full-screen cinematic card board. The focused item is the large left card;
                // all logo/metadata/info is INSIDE that card, matching the reference layout.
                NineSlotDeck(items: items, selectedIndex: selectedIndex, rowTitle: currentRow.title)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

            }
            .contentShape(Rectangle())
            .focusable(true)
            .focused($isCanvasFocused)
            .onAppear { isCanvasFocused = true }
            .onMoveCommand { direction in
                switch direction {
                case .right:
                    nextItem()
                case .left:
                    previousItem()
                case .down:
                    nextRow()
                case .up:
                    if rowIndex > 0 { previousRow() } else { store.menuFocusToken += 1; isCanvasFocused = false }
                default:
                    break
                }
            }
        }
    }

    func normalized(_ value: Int) -> Int {
        guard !items.isEmpty else { return 0 }
        return (value % items.count + items.count) % items.count
    }

    func nextItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.83)) {
            selectedIndex = normalized(selectedIndex + 1)
        }
    }

    func previousItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.58, dampingFraction: 0.83)) {
            selectedIndex = normalized(selectedIndex - 1)
        }
    }

    func nextRow() {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        guard rows.count > 1 else { return }
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = min(rowIndex + 1, rows.count - 1)
            selectedIndex = 0
        }
    }

    func previousRow() {
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}

struct NineSlotDeck: View {
    let items: [MediaItem]
    let selectedIndex: Int
    let rowTitle: String
    @State private var pulse = false

    struct Slot: Identifiable {
        let id: Int
        let x: CGFloat
        let y: CGFloat
        let w: CGFloat
        let h: CGFloat
        let focused: Bool
    }

    // Responsive full-screen layout with stable card geometry.
    // The card containers NEVER change size based on artwork type.
    // Slot 0 is the anchored big focused card; slots 1-8 are equal-size right cards.
    func slots(in size: CGSize) -> [Slot] {
        let W = size.width
        let H = size.height

        // Minimal edge padding: use the full tvOS render area while avoiding clipping the glow.
        let edge = max(6, min(W, H) * 0.006)
        let top = max(18, H * 0.020)
        let bottom = max(6, H * 0.006)
        let gap = max(8, W * 0.005)

        let boardW = W - edge * 2
        let boardH = H - top - bottom

        // Stable left/right split. Left card remains the same size for posters/backdrops/logos.
        // Right cards are calculated as one equal 4x2 matrix.
        let leftW = boardW * 0.405
        let leftH = boardH
        let rightX0 = edge + leftW + gap
        let rightW = max(100, W - rightX0 - edge)

        let cardW = (rightW - gap * 3) / 4
        let cardH = (leftH - gap) / 2

        let leftX = edge + leftW / 2
        let leftY = top + leftH / 2

        var result: [Slot] = [
            Slot(id: 0, x: leftX, y: leftY, w: leftW, h: leftH, focused: true)
        ]

        for row in 0..<2 {
            for col in 0..<4 {
                let id = 1 + row * 4 + col
                let x = rightX0 + CGFloat(col) * (cardW + gap) + cardW / 2
                let y = top + CGFloat(row) * (cardH + gap) + cardH / 2
                result.append(Slot(id: id, x: x, y: y, w: cardW, h: cardH, focused: false))
            }
        }

        return result
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                ForEach(slots(in: geo.size)) { slot in
                    let item = itemFor(slot.id)
                    SlotCard(item: item, rowTitle: rowTitle, isFocusedSlot: slot.focused, pulse: pulse)
                        .frame(width: slot.w, height: slot.h)
                        .position(x: slot.x, y: slot.y)
                        .zIndex(slot.focused ? 40 : Double(20 - slot.id))
                        .id("slot-\(slot.id)-\(item.id)-\(selectedIndex)")
                        .transition(slot.focused ? .asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .move(edge: .leading).combined(with: .opacity)) : .opacity)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.35).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
        }
    }

    func itemFor(_ slot: Int) -> MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        let index = (selectedIndex + slot) % items.count
        return items[index]
    }
}


struct StableArtwork: View {
    let item: MediaItem
    let preferLandscape: Bool

    private var mainURL: String? {
        if preferLandscape, let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        return item.posterURL
    }

    private var hasLandscape: Bool {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return true }
        return false
    }

    var body: some View {
        ZStack {
            // Background always fills the card, so no empty bars appear.
            RemoteImageFit(url: mainURL, mode: .fill)
                .blur(radius: hasLandscape ? 0 : 20)
                .scaleEffect(hasLandscape ? 1.0 : 1.14)
                .opacity(hasLandscape ? 1.0 : 0.55)

            // If the source is a poster/portrait image, keep the card size stable and fit the poster
            // inside instead of resizing the card or blowing the poster up into a huge square crop.
            if !hasLandscape {
                RemoteImageFit(url: item.posterURL ?? mainURL, mode: .fit)
                    .padding(preferLandscape ? 26 : 14)
            }
        }
        .clipped()
    }
}

struct SlotCard: View {
    let item: MediaItem
    let rowTitle: String
    let isFocusedSlot: Bool
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            StableArtwork(item: item, preferLandscape: isFocusedSlot)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .overlay(
                    ZStack {
                        if isFocusedSlot {
                            // Warm person/object glow pass. This is an artwork-level glow overlay,
                            // so it works without backend cutouts or segmentation.
                            RadialGradient(colors: [.orange.opacity(pulse ? 0.45 : 0.22), .clear], center: .center, startRadius: 40, endRadius: 520)
                            LinearGradient(colors: [.clear, .black.opacity(0.48), .black.opacity(0.90)], startPoint: .top, endPoint: .bottom)
                            LinearGradient(colors: [.black.opacity(0.10), .clear, .orange.opacity(0.12)], startPoint: .leading, endPoint: .trailing)
                        } else {
                            Color.black.opacity(0.44)
                        }
                    }
                )
                .saturation(isFocusedSlot ? 1.25 : 0.54)
                .brightness(isFocusedSlot ? 0.065 : -0.18)

            if isFocusedSlot {
                focusedInfoOverlay
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: isFocusedSlot ? 34 : 24))
        .overlay(
            RoundedRectangle(cornerRadius: isFocusedSlot ? 34 : 24)
                .stroke(isFocusedSlot ? Color.orange.opacity(pulse ? 1.0 : 0.72) : Color.orange.opacity(0.24), lineWidth: isFocusedSlot ? 5 : 1)
        )
        .shadow(color: isFocusedSlot ? .orange.opacity(pulse ? 0.92 : 0.45) : .black.opacity(0.70), radius: isFocusedSlot ? 46 : 16)
        .opacity(isFocusedSlot ? 1.0 : 0.58)
        .scaleEffect(isFocusedSlot ? 1.012 : 1.0)
    }

    private var focusedInfoOverlay: some View {
        VStack(alignment: .leading, spacing: 18) {
            AnimatedLogo(item: item)
                .frame(maxWidth: 520, minHeight: 92, maxHeight: 138, alignment: .leading)
                .padding(.bottom, 72)

            HStack(spacing: 12) {
                Text(item.year)
                Text("•")
                Text(item.type.capitalized)
                Text("•")
                Text(rowTitle)
            }
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(.white.opacity(0.92))

            HStack(spacing: 12) {
                ForEach(item.genres.prefix(2), id: \.self) { genre in
                    Text(genre)
                        .font(.system(size: 15, weight: .bold))
                        .padding(.horizontal, 18)
                        .padding(.vertical, 9)
                        .background(Capsule().fill(Color.black.opacity(0.44)))
                        .overlay(Capsule().stroke(.white.opacity(0.16), lineWidth: 1))
                }
            }

            HStack(spacing: 16) {
                Text("IMDb")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(.black)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 9)
                    .background(RoundedRectangle(cornerRadius: 7).fill(Color.yellow))
                Text(item.rating)
                    .font(.system(size: 38, weight: .bold))
            }
            .foregroundStyle(.white)

            Text(item.description)
                .font(.system(size: 19, weight: .semibold))
                .foregroundStyle(.white.opacity(0.95))
                .lineLimit(4)
                .frame(maxWidth: 540, alignment: .leading)
        }
        .padding(.leading, 28)
        .padding(.bottom, 28)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
        .background(
            LinearGradient(colors: [.black.opacity(0.76), .black.opacity(0.18), .clear], startPoint: .bottomLeading, endPoint: .topTrailing)
        )
    }
}

struct AnimatedLogo: View {
    let item: MediaItem
    @State private var pulse = false

    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 11 ? 52 : 78, weight: .black, design: .rounded))
                    .italic()
                    .minimumScaleFactor(0.35)
                    .lineLimit(1)
                    .foregroundStyle(LinearGradient(colors: [.yellow, .orange, .red], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .shadow(color: .black.opacity(0.95), radius: 8)
            }
        }
        .shadow(color: .orange.opacity(pulse ? 0.88 : 0.34), radius: pulse ? 28 : 8)
        .scaleEffect(pulse ? 1.02 : 1.0)
        .onAppear {
            withAnimation(.easeInOut(duration: 1.30).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
        }
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @FocusState private var focused: SettingsFocus?

    enum SettingsFocus: Hashable { case manifest, load, reset, home, movies, shows, live }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .black, .orange.opacity(0.16)], startPoint: .top, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 24) {
                Text("Settings")
                    .font(.system(size: 62, weight: .black))
                    .foregroundStyle(.white)
                    .padding(.top, 132)

                VStack(alignment: .leading, spacing: 18) {
                    Text("Stremio Catalog Manifest")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)

                    TextField("Manifest URL", text: $manifestURL)
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(22)
                        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
                        .focused($focused, equals: .manifest)
                        .frame(width: 1180)

                    HStack(spacing: 18) {
                        SettingsButton(title: store.isLoading ? "Loading..." : "Load Catalog", focus: .load, focused: $focused) {
                            Task { await store.loadManifest(urlString: manifestURL) }
                        }
                        SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                            store.resetDemo()
                        }
                    }

                    Text(store.status)
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .frame(width: 1180, alignment: .leading)
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                VStack(alignment: .leading, spacing: 14) {
                    Text("Quick Navigation")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)
                    HStack(spacing: 18) {
                        SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                        SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                        SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                        SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
                    }
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                Spacer()
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
        }
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct LiveTVPlaceholder: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 24) {
                Text("Live TV")
                    .font(.system(size: 76, weight: .black))
                Text("Live TV layout is preserved for the next native tvOS guide pass.")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            }
            .foregroundStyle(.white)
        }
    }
}
