import SwiftUI

struct RemoteImageFit: View {
    enum Mode { case fill, fit }
    let url: String?
    var mode: Mode = .fill

    var body: some View {
        AsyncImage(url: URL(string: url ?? "")) { phase in
            switch phase {
            case .success(let image):
                image
                    .resizable()
                    .aspectRatio(contentMode: mode == .fill ? .fill : .fit)
            case .empty:
                ZStack {
                    LinearGradient(colors: [.black, .gray.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    ProgressView().scaleEffect(1.2)
                }
            case .failure:
                ZStack {
                    LinearGradient(colors: [.black, .orange.opacity(0.20)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    Image(systemName: "film.stack")
                        .font(.system(size: 60, weight: .bold))
                        .foregroundStyle(.white.opacity(0.35))
                }
            @unknown default:
                Color.black
            }
        }
        .clipped()
    }
}
