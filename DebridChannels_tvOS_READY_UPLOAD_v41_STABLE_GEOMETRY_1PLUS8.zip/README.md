Debrid Channels tvOS v41 stable geometry 1+8 layout. Preserves v14 Signulous-compatible packaging.
