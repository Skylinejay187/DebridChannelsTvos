# Debrid Channels v1035 — Phase 7 Performance, Cache, Memory, and Lifecycle Hardening

Base: `DebridChannels_v1034_V1033_BASE_PHASE6_CATALOG_INTEGRATION_DATA_INTEGRITY_GITHUB.zip`

Version: `1.0.563`
Build: `563`

## Scope

This build is Phase 7 of the final release sequence. It preserves the Phase 5 protected catalog snapshot/recovery layer and the Phase 6 canonical identity/data-integrity layer. PlaybackKit, KSPlayer, Live TV, the VOD decoded-frame queue, cadence, trailers, Source Intelligence, audio, subtitles, and player startup behavior are not modified.

## VOD scrubber visual cleanup

- Removed the large rounded focus outline surrounding the complete timeline control.
- Preserved the enlarged 30-point white scrubber dot.
- Preserved the 44-point blue halo, brighter rail, glow, and latched scrub-session confirmation.
- Left/Right preview scrubbing, Select-to-commit, Up/Down exit, seek feedback, and overlay activation are unchanged.

## Focused preview cache hardening

- Added a seven-day age limit for progressive focused-card preview files.
- Preserved the existing 18-file and 768 MB normal limits.
- Added a 512 MB free-storage reserve before staging another preview file.
- Rejects a download when its known content length would violate the reserve.
- Normal maintenance removes expired/oversized entries.
- Memory-pressure maintenance trims the cache to at most six files / 256 MB.
- HLS/DASH behavior remains unchanged and continues to rely on backend reuse/single-flight behavior.

## Memory cache limits

- Focused-preview URL memory cache is now bounded to 24 entries using insertion-order eviction.
- VOD playback metadata memory cache is bounded to 48 entries.
- Hero TMDB metadata cache is bounded to 192 entries and continues using its six-hour TTL.
- Expired hero metadata is removed during normal access and foreground maintenance.
- Recent unified Search cache retains its existing 12-query / 90-second limits and is released during memory pressure.

## Scene and request lifecycle

When tvOS moves the app out of the active scene:

- Focused-preview disk staging is canceled.
- Lazy row refresh debounce work is canceled.
- Optional catalog enrichment and trailer prewarm tasks are canceled.
- Detail credits and hero metadata network tasks are canceled safely.
- Active Source Intelligence network requests are invalidated.
- Speculative artwork prefetch is canceled without invalidating already-visible image requests.
- Root bootstrap, entitlement, verification, and membership-clock tasks stop.
- Search debounce/hydration tasks stop and cannot publish stale results.

When the scene becomes active:

- Required sessions are recreated.
- Root bootstrap and membership work resume only while the scene is active.
- A detail left open during suspension is rehydrated.
- Preview disk and hero metadata caches run bounded maintenance.

## Memory warning behavior

A tvOS memory warning now:

- Cancels optional catalog refresh/enrichment/prewarm work.
- Invalidates stale Source Intelligence generations.
- Clears recent Search, focused-preview URL, and playback-metadata memory caches.
- Clears decoded artwork NSCache entries while preserving images already retained by visible views.
- Stops the active focused-card preview and clears its hero metadata task.
- Cancels hero metadata in-flight requests.
- Aggressively trims the focused-preview disk cache.

No active KSPlayer or PlaybackKit player is rebuilt or retuned by this handling.

## Duplicate refresh prevention

- Only one complete catalog refresh may execute at a time.
- A simultaneous request waits for the active refresh.
- If the active refresh completes successfully, the waiting request is coalesced.
- If the earlier refresh was canceled by scene suspension, the waiting foreground request performs a fresh load.
- A lifecycle generation prevents a backgrounded or memory-interrupted refresh from publishing rows after it becomes stale.

## Exact changed files

1. `Sources/FocusedCardPreviewDiskCache.swift`
2. `Sources/CatalogHeroMetadataCache.swift`
3. `Sources/CatalogStore.swift`
4. `Sources/RemoteImageFit.swift`
5. `Sources/DebridChannelsTVOSApp.swift`
6. `Sources/Info.plist`
7. `README_BUILD_v1035_V1034_BASE_PHASE7_PERFORMANCE_CACHE_MEMORY_LIFECYCLE_HARDENING.md`
8. `AUDIT_v1035_CHANGED_FILES.txt`

## Validation

- All Swift source files passed Swift frontend syntax parsing.
- The two Foundation-only cache files passed standalone Swift type checking.
- `Info.plist` passed property-list parsing.
- `project.yml` passed YAML parsing.
- Static assertions passed for scrubber-outline removal, preserved dot/halo focus visuals, cache limits, low-storage checks, memory-warning routing, scene cancellation, Search cancellation, and catalog refresh generations.
- Critical playback/service files were verified byte-for-byte unchanged from v1034.
- ZIP compressed-data integrity and extraction round-trip validation are performed before delivery.

A full tvOS SDK compile remains the GitHub Actions validation step.
