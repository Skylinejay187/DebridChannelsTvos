# Debrid Channels tvOS/iOS v1103

## Version
- Marketing version: 1.0.631
- Build: 631
- Base: verified v1098 stable rollback line
- Required backend: v669

## Why this replacement exists
Older app builds also stopped receiving playable links, proving the immediate outage was backend-wide rather than a Search-card-only identity problem. v1103 therefore removes the v1102 Search identity experiment and rebuilds Phase 5 from the proven v1098 app resolver path.

## Source resolution protection
The following v1103 functions are byte-identical to v1098:
- findStreamsForcePopulated
- cancelCurrentStreamSearch
- findStreams
- expandedStreamTypes
- streamTypeCandidates
- streamIDCandidates
- streamIDFallbackCandidates
- playFirstDirectStream
- resolverReadyStreamItem

No Search-only or catalog-only resolver workaround is added in this build.

## Catalog Health scrolling fix
The Catalog Health page remains inside its vertical tvOS ScrollView. Configured-provider rows now join the native focus chain as passive focus anchors, allowing the Siri Remote to advance the page through providers, failure rows, per-row reload controls, and the remaining options. Existing action buttons remain normal focusable controls.

## Phase 5 features retained
- Configured providers and expected/loaded row counts
- Poster count per row and pagination state
- Last successful/full-pagination refresh
- Failed/timed-out providers and failed pages
- Reload one row, reload all catalogs, and safe catalog-cache clearing
- Featured Cast displays only successfully loadable profile images
- Season/episode text stays in information and is not drawn over poster artwork
- Episode air dates include TODAY, AIRED, and UPCOMING future dates

## Protected systems
Tapframe KSPNUVIO, KSPlayer handoff, Alternate Audio lifecycle, trailers, Live TV, episode alerts, Search-contained results, Favorites, full-width rows, and focused-card behavior are retained from v1098.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing must verify Catalog Health scrolling and catalog/Search link retrieval against backend v669.
