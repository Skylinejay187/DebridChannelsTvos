# Debrid Channels v1114 — Compact Episode Date Line

Base: v1113 only  
Marketing version: 1.0.642  
Build: 642  
Backend: no update required; continue using backend v669

## Changes

- Removed the episode air-date badge from the upper-right of the episode artwork.
- Shortened season/episode labels from zero-padded forms such as `S04E06` to compact forms such as `S4E6`.
- Moved the verified date beside the compact episode code at the bottom of the card:
  - `S4E6 • AIRED DEC 28, 2017`
  - `S3E7 • TODAY AUG 4, 2026`
  - `S5E2 • UPCOMING AUG 12, 2026`
- Upcoming dates retain a restrained orange accent.
- Missing dates collapse cleanly to the compact episode code only.
- The shared episode-card renderer covers both the connected main media-information season picker and the manual episode picker.

## Preserved

- Exact dates still come only from `airDateString` / `episodeDateStrings` through the existing verified date resolver.
- Episode artwork, title, description, card size, season navigation, and focus behavior remain unchanged.
- Production & Ratings, Featured Cast, catalog/Search source resolution, KSPlayer, Alternate Audio, trailers, Live TV, Catalog Health, Favorites, and episode-alert scanning remain unchanged.

## Validation

- 44 Swift files parsed successfully.
- Episode compact-line source contract passed 10/10 checks.
- Compact-line behavior test passed 4/4 cases.
- Eleven protected playback/backend files remained byte-identical to v1113.
- App and Top Shelf plists validate at 1.0.642 / 642.
- Project versions match both plists.
- Complete baseline comparison and clean archive extraction verification are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV review remains required.
