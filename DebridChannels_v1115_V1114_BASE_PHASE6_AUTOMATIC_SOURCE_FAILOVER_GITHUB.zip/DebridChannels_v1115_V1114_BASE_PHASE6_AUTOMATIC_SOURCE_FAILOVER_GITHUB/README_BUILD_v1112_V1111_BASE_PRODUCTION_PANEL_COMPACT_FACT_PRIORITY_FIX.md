# Debrid Channels v1112 — Production Panel Compact Fact Priority Fix

Base: v1111 only  
Marketing version: 1.0.640  
Build: 640  
Backend: no update required; continue using backend v669

## Changes

- Reduced the Production & Ratings panel from 440 to 390 points wide.
- Replaced source-ratio-driven panel growth with a fixed 138-point banner canvas.
- Kept artwork fully visible with aspect-fit; no crop or stretch.
- Expanded the information grid from six to eight available facts.
- Prioritized real movie budget and box-office values so decorative rows cannot push them out.
- Added release/first-air date and network/studio fallback information when budget or revenue is unavailable.
- Kept Rotten Tomatoes and IMDb values when space permits.
- Preserved Featured Cast, cast rotation, playback startup quarantine, Search/catalog resolution, KSPlayer, Alternate Audio, trailers, Live TV, Catalog Health, Favorites, and episode alerts.

## Data rule

TMDB supplies budget and revenue for movies. It generally does not supply a series-wide budget or revenue value for television shows. v1112 does not fabricate those values; television panels use real network/studio, first-air date, status, runtime, ratings, country, and language metadata instead.

## Validation

- 46 Swift files parsed successfully.
- App and Top Shelf plists validated at 1.0.640 / 640.
- Project versions validated.
- Production panel source contract passed.
- Nine core source-resolution functions remained byte-identical to v1111.
- Nine protected playback/backend-facing source files remained byte-identical.
- Complete baseline comparison is packaged; archive extraction verification is provided beside the ZIP.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV review remains required.
