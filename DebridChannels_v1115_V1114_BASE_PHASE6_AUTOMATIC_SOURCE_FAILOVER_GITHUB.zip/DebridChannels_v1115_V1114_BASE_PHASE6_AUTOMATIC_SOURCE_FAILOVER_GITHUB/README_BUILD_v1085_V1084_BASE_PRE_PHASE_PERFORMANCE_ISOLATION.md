# Debrid Channels v1085 — Pre-Phase Performance Isolation

Base: v1084 stability baseline. Version: 1.0.613 (613).

This build is a deliberately narrow performance pass before the planned reliability and Alternate Audio phases. It does not redesign the UI or change KSPlayer decoder/cadence/buffer settings.

## VOD / playback isolation

- New-episode alert heartbeat and scan work are suspended while VOD owns the screen, while preserving the persisted deadline for catch-up after playback.
- Stremio/TMDB/credits hydration and runtime fallback requests wait until first-frame presentation is established.
- The startup loading gate performs one bounded state update instead of publishing the same text every 300 ms until first frame.
- Hidden VOD chrome is removed from the SwiftUI tree instead of remaining alive at zero opacity. This suspends hidden cast timers, artwork views, glass materials, and shadow layers while controls are not visible.
- The lightweight transparent player canvas remains the hidden-state focus owner, so remote navigation can restore the existing VOD overlay without rebuilding KSPlayer.

## Catalog / overlay rendering

- The full-screen catalog backdrop host remains stable across focus changes rather than remounting the entire gradient/artwork tree for every card.
- Up to four duplicate full-screen artwork depth passes were consolidated into one restrained premium depth pass.
- Deep trailing portrait cards no longer retain large accent blooms and multiple high-radius shadows. Full-width rail geometry and reachability are unchanged.
- Hero release-date formatters are cached instead of allocated repeatedly during focus movement.

## Deliberately unchanged

- Built-in trailer resolver and working v1084 trailer playback path.
- KSPlayer/KSPNUVIO fork, decoder, queue, cadence, hardware decode, and display-matching behavior.
- Source Intelligence ranking/provider mixing and playback handoff.
- Full-width catalog rows, Guide startup, Search-contained results, Live TV grid/guide, previews, favorites, and episode alerts themselves.
- Smart Alternate Audio remains the existing placeholder until the planned phased rebuild.

## Validation boundary

All Swift files pass syntax parsing and the project/plists/backend helper validate. GitHub Actions remains the authoritative Xcode/tvOS compile, and physical Apple TV testing remains necessary to measure actual focus latency, overlay presentation time, first-frame timing, and playback cadence.
