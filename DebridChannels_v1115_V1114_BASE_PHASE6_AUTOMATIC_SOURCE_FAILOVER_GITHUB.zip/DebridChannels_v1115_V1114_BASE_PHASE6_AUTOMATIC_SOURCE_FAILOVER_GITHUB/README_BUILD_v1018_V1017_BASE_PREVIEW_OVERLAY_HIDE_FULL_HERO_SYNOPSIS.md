# Debrid Channels v1018 — Focused Preview Overlay Hide + Full Hero Synopsis

Base: `DebridChannels_v1017_V1016_BASE_CINEMATIC_HERO_METADATA_RIBBON_GITHUB.zip`

Version: `1.0.546`
Build: `546`

## Scope

This build makes two presentation-only changes while preserving the v1016 Live TV repair and all playback configuration.

### 1. Focused-card preview presentation

- The focused card's themed logo and year/rating line stay visible while the preview is resolving or buffering.
- They fade out only after the isolated AVPlayer reports that preview playback has actually started.
- They remain hidden through the single 20-second preview segment.
- They return when the preview ends, is canceled, focus moves, or the card loses focus.
- The focused-card artwork, preview video, theme overlay, focus ring, and existing preview cache behavior are unchanged.

### 2. Complete hero synopsis

- The three-line synopsis limit was removed from the large themed-logo hero area.
- The full available synopsis expands naturally beneath the metadata ribbon.
- The layout is top-anchored by the large logo so longer text does not move the logo from its established visual position.
- The synopsis area is wider and uses length-aware typography to fit detailed descriptions cleanly.
- When TMDB metadata is available, the app retains its overview and selects the more complete description between the downloaded catalog text and TMDB overview.
- The focused-card logo and rating presentation are unchanged outside active preview playback.

## Playback preservation

No changes were made to:

- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- Live TV first-frame/loading-screen gate behavior
- VOD decoded-frame queues (24 / 24 / 16)
- KSPlayer, FFmpeg, VideoToolbox, cadence, clock, audio, or subtitle settings
- Trailer resolver or trailer player
- CatalogStore playback/resolver logic
- Preview disk-cache policy or auxiliary-player handoff

## Changed files

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/CatalogHeroMetadataCache.swift`
3. `Sources/Info.plist`
4. `README_BUILD_v1018_V1017_BASE_PREVIEW_OVERLAY_HIDE_FULL_HERO_SYNOPSIS.md`
5. `AUDIT_v1018_CHANGED_FILES.txt`

## Validation

- All Swift source files passed Swift frontend syntax parsing.
- `CatalogHeroMetadataCache.swift` passed standalone Swift type checking.
- `Sources/Info.plist` passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- Static assertions confirmed the hero synopsis has no three-line limit.
- Static assertions confirmed focused-card logo/rating visibility is tied to actual AVPlayer playback state.
- Critical playback and resolver files are SHA-256 identical to v1017.
- The final ZIP passed compressed-data integrity and extraction round-trip comparison.

GitHub Actions remains the authoritative full tvOS/iOS SDK compilation environment.
