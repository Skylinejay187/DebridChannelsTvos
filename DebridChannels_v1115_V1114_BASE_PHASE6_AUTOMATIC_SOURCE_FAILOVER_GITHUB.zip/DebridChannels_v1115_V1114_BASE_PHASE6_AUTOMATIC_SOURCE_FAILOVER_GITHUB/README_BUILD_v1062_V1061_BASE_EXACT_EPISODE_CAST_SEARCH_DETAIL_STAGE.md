# Debrid Channels tvOS v1062

Release: v1062 (1.0.590 / 590)  
Base: v1061

## Implemented

### Global exact-episode cast resolution
- Applies to every series automatically; no title-specific exceptions or hardcoded anthology list.
- Resolves credits in this order for an episode: exact episode → current season aggregate → series aggregate → series credits.
- Reads TMDB episode `guest_stars` before ordinary episode cast so anthology and guest-heavy episodes surface the actors who actually appear in that episode.
- Supports aggregate-credit `roles` and `jobs` payloads for cast roles and episode/season directors.
- Caches credits by canonical series identity plus season and episode, preventing neighboring episodes from sharing a cast result.
- Cancels and generation-guards old detail requests so a late cast response cannot overwrite the newly selected episode.
- Episode items preserve TMDB, IMDb, and TVDB parent identifiers but intentionally start with empty credits, preventing parent-series cast from flashing before exact hydration.
- Uses the configured TMDB key, with `TMDB_API_KEY` environment fallback. When exact data is unavailable, the existing Stremio/season/series fallback path remains intact.

### Search-owned media-information presentation
- Opening a title from Search records Search as the presentation origin.
- The connector starts at the measured top-menu Search icon instead of a stale catalog card.
- Search uses the accepted original connected-popup illumination and the same fast draw/reverse-retract behavior.
- Only the media-information stage opened from a Search result receives the darker official backdrop.
- The Search results screen itself is unchanged.
- Catalog and Live TV detail popups retain their existing transparent-glass presentation.
- Episode, related-title, and nested detail navigation preserve the Search origin until the root detail is dismissed.

## Preserved
- v1061 fast connector timing, seven-second hold, dissolving lower glass, and stale hero/logo handoff protection.
- v1060 long-row pagination and force catalog loading.
- Built-in trailer path, advisory, VOD handoff, episode alerts, Live TV, catalog, focus, and playback systems.

## Validation completed in this package
- All 39 Swift source files passed `swiftc -frontend -parse`.
- App and Top Shelf plists parse and report 1.0.590 (590).
- `project.yml` parses and reports 1.0.590 (590) for both targets.
- Backend trailer helper passed Python bytecode compilation.
- Static release checks confirm exact episode endpoints, guest-star priority, per-episode cache identity, Search icon origin, and Search-only dark stage.
- Final ZIP extraction and file-hash comparison are recorded in `VALIDATION_RESULTS_v1062.json`.

GitHub Actions remains the authoritative Xcode/tvOS SDK type-check, link, archive, and signing validation.
