# Debrid Channels tvOS v1060

Release: v1060 (1.0.588 / 588)  
Base: v1059

## Scope

This release modifies the actual tvOS source. It does not include or depend on a visual mockup.

## Force-load complete long catalog rows

The prior catalog repair measured whether all row headers were present, but a row could still contain only the first page of posters. The manual reload now has a separate full-row contract:

- **Settings → Streaming Catalogs → Force Reload Full Debrid Channels Catalogs** refreshes the official row set.
- Rows that reach a likely server page boundary are continued through Stremio `skip` pagination.
- Both query-form (`?skip=`) and path-extra (`/skip=...json`) pagination are supported.
- A candidate page is accepted only when it contributes new media IDs, preventing servers that ignore `skip` from looping or duplicating posters.
- Pagination stops when the provider returns no new items, a short final page, eight additional pages, or 500 posters for one row.
- Existing row order, hidden-row customization, durable snapshots, artwork, focus, and all features remain intact.
- A successful manual reload reports the final visible row and poster totals.
- The protected non-regression merge prevents a later first-page refresh from replacing a previously hydrated longer row.

## Fully transparent connected popup

- Removes the opaque smoked-glass canvas from the connected media-information popup.
- The catalog or Live TV grid remains visible through the full panel silhouette.
- All current information, actions, advisory, cast, seasons, episodes, and focus behavior are preserved.
- Individual information groups retain their existing localized readability treatments.
- The optional popup artwork setting is preserved as an extremely faint transparent sheen rather than an opaque panel background.
- The border and brand accent remain as the panel's only full-surface structure.

## Connector-first presentation

- Restores the original v1053 cubic curve proportions and illuminated line treatment.
- The source anchor remains on the focused poster but is elevated so the glow clears the next poster immediately.
- The landing point stays below the hero logo/description corridor and above the poster rail.
- The line draws completely before the information popup begins presenting.
- The popup then reveals from its left/connector edge with a leading-edge mask, making it appear delivered by the line rather than simply fading in.
- The fully drawn line remains for seven seconds.
- It then retracts along the same path with the same 0.78-second ease-in-out animation used for opening.
- The popup stays visible after retraction.

## Preserved v1059 work

- Built-in trailer-only interface and external YouTube trailer removal.
- Built-in trailer full-audio validation and duration-matched backend remux contract.
- Content Advisory section and official certification lookup.
- Catalog scrolling snapshot/performance improvements.
- VOD link handoff ownership guards and episode-alert reliability work from earlier releases.

## Versions

- Main app: 1.0.588 (588)
- Top Shelf extension: 1.0.588 (588)
- XcodeGen project: 1.0.588 (588)

## Validation boundary

All Swift source files pass syntax parsing, the backend trailer helper passes Python bytecode compilation, both plists and `project.yml` parse, version/bundle identities match, and the release ZIP is verified after round-trip extraction. GitHub Actions/Xcode remains the authoritative tvOS type-check, compile, link, and archive gate. Device testing remains required to confirm the official catalog server's available page depth and the final connector geometry across row styles.
