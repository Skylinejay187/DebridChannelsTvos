# Debrid Channels v1002

Base: v1001.

Compile-only repair for the Phase 2 All-in-One Catalogs toggle.

GitHub Actions reported four `switch must be exhaustive` errors in `DebridChannelsTVOSApp.swift` after `SettingsFocus.allInOneCatalogToggle` was added. The legacy manual settings-focus router contained four switches (right, left, down, up) that did not include the new enum case.

This build adds `allInOneCatalogToggle` to the no-op branches of those four dormant manual switches. Native tvOS focus movement and the working toggle behavior are unchanged.

Preserved unchanged:
- Phase 2 all-in-one catalog integration and themed rows
- optional per-device All-in-One Catalogs toggle
- v999 playback, cadence, subtitle, and glyph fixes
- trailers, Live TV, Source Intelligence, and VOD presentation

Version: 1.0.530 (530)
