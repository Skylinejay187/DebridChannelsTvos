# Debrid Channels tvOS/iOS v1106

## Base

Built only from v1105 (1.0.633 / build 633).

## Version

- Marketing version: 1.0.634
- Build: 634
- Backend update: not required
- Continue using backend v669

## Focused VOD visual pass

### Featured Cast Poster Takeover

- Added `Featured Cast Poster Takeover` to the existing VOD Playback Settings panel.
- The setting defaults On.
- The movie/show portrait poster remains visible for four seconds when the VOD overlay appears.
- The poster then crossfades into a full-poster cast portrait.
- The cast member name, character/role, and position are shown over the lower gradient.
- Rotation advances every seven seconds only while the VOD overlay is awake.
- The player-owned cast index remains persistent when the VOD overlay hides, so reopening resumes from the prior cast position instead of restarting.
- Turning the setting Off keeps the original portrait poster visible at all times.

### Production & Ratings Panel

- Added `Production & Ratings Panel` to the existing VOD Playback Settings panel.
- The setting defaults Off.
- When enabled, the former right-side Featured Cast area becomes a dedicated Production & Ratings panel.
- The right-side panel no longer displays cast.
- The panel shows only real available values and collapses missing values without blank rows.
- Supported facts include content rating, advisory, budget, box office/revenue, runtime, status, country, language, studios, networks, Rotten Tomatoes critic score, and IMDb score.
- The exact requested icons are retained: 🍅 for Rotten Tomatoes critics and 🍿 for IMDb/community rating.
- Production-company and network logos use TMDB image URLs when a user TMDB key is configured.
- No score, budget, revenue, advisory, or studio value is fabricated.

## Metadata architecture

- Added `Sources/VODProductionMetadata.swift`.
- Production metadata is fetched directly in the app from TMDB using the existing user TMDB API key.
- No backend endpoint or backend deployment change is required.
- The request stays idle while the Production & Ratings Panel is Off.
- The request is cancelled when VOD playback closes.

## Protected systems

The following systems were not changed:

- Catalog and Search source resolution
- Source Intelligence
- Alternate Audio discovery, bridge, handoff, and cancellation
- Tapframe KSPNUVIO / PlaybackKit KSPlayer surface
- Trailer resolver and trailer playback
- Live TV, Quick Guide, and Gracenote lifecycle
- Catalog Health
- Episode alerts
- Favorites and specialized focus behavior

## Validation

- 44 Swift files parsed successfully.
- `VODProductionMetadata.swift` passed standalone Swift type-checking.
- The VOD panel option enum/switch passed an exhaustive standalone Swift type-check.
- Both plists passed validation.
- Project and plist version/build values match 1.0.634 / 634.
- Protected source files were compared byte-for-byte with v1105.
- No baseline files were removed.
- Final ZIP extraction and complete file-hash verification are included in the package reports.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before using v1106 as the next stable base.
