# Debrid Channels v1066

Base: v1065  
Marketing version: 1.0.594  
Build: 594

## Purpose

Compile-only correction for the v1065 continuous focused-preview ownership change.

## Correction

`quickPanelRestoreRowID` is an optional `String`. v1065 attempted to call `isEmpty`
and assign it as a non-optional value without binding it first. v1066 safely unwraps the
exact originating row ID before using it in the preview identity key.

## Preserved behavior

- Focused preview continues through media-popup and built-in trailer interactions.
- Popup colored accent remains removed.
- Find Links-to-Source Intelligence connector remains removed.
- Source Intelligence satellite panel retains Top Recommended Link and existing navigation logic.
- All v1064 trailer resolver restoration and earlier catalog/VOD/episode-alert work remains intact.
