import Foundation
import SwiftUI
import UIKit
import AVFoundation
import QuartzCore

#if canImport(KSPlayer)
import KSPlayer
#endif

// Phase 12 final extraction: KSPlayer, FFmpeg option construction, display matching,
// render-surface ownership, track handling, and the subtitle renderer bridge live under PlaybackKit.

#if os(tvOS)
@available(tvOS 11.2, *)
enum DebridTVOSDisplayMatchCoordinator {
    private static var lastAppliedSignature: String = ""
    private static var pendingLiveWorkItem: DispatchWorkItem? = nil

    private static func keyWindow() -> UIWindow? {
        if let window = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .flatMap({ $0.windows })
            .first(where: { $0.isKeyWindow }) {
            return window
        }
        return UIApplication.shared.windows.first(where: { $0.isKeyWindow }) ?? UIApplication.shared.windows.first
    }

    static func isSystemDisplayMatchingEnabled() -> Bool {
        guard let window = keyWindow() else { return false }
        return window.avDisplayManager.isDisplayCriteriaMatchingEnabled
    }

    private static func apply(_ criteria: AVDisplayCriteria?, signature: String, source: String) {
        guard let window = keyWindow() else { return }
        let manager = window.avDisplayManager
        DispatchQueue.main.async {
            guard lastAppliedSignature != signature || criteria != nil else { return }
            manager.preferredDisplayCriteria = criteria
            lastAppliedSignature = signature
            if criteria != nil {
                print("[DebridChannels][DisplayMatch] applied \(source) \(signature)")
            } else {
                print("[DebridChannels][DisplayMatch] reset")
            }
        }
    }

    private static func inferredFrameRate(from value: String) -> Double? {
        let lower = value.lowercased()
        if lower.contains("23.976") || lower.contains("23_976") || lower.contains("24000/1001") { return 24000.0 / 1001.0 }
        if lower.contains("24fps") || lower.contains(" 24 ") || lower.contains(".24.") { return 24.0 }
        if lower.contains("25fps") || lower.contains(" 25 ") || lower.contains(".25.") { return 25.0 }
        if lower.contains("29.97") || lower.contains("30000/1001") { return 30000.0 / 1001.0 }
        if lower.contains("30fps") || lower.contains(" 30 ") || lower.contains(".30.") { return 30.0 }
        if lower.contains("50fps") || lower.contains(" 50 ") || lower.contains(".50.") { return 50.0 }
        if lower.contains("59.94") || lower.contains("60000/1001") { return 60000.0 / 1001.0 }
        if lower.contains("60fps") || lower.contains(" 60 ") || lower.contains(".60.") { return 60.0 }
        return nil
    }


    private static func normalizedLiveFrameRate(_ fps: Double) -> Double {
        if abs(fps - 25.0) < 0.25 { return 50.0 }
        if abs(fps - 30.0) < 0.35 { return 60.0 }
        if abs(fps - (30000.0 / 1001.0)) < 0.35 { return 60000.0 / 1001.0 }
        return fps
    }

    static func cancelPendingLiveDisplayMatch() {
        pendingLiveWorkItem?.cancel()
        pendingLiveWorkItem = nil
    }

    static func applyForLiveChannel(url: URL, hint: String) {
        cancelPendingLiveDisplayMatch()
        let combined = (url.absoluteString + " " + hint)
        let signature = "live|" + combined.lowercased()
        let workItem = DispatchWorkItem {
            let headers: [String: String] = [
                "User-Agent": "DebridChannels-tvOS/613 LiveDisplayMatch",
                "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
                "Accept-Encoding": "identity",
                "Connection": "keep-alive"
            ]
            let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])

            // First try the system-vended criteria. This is safest for HLS and channels that
            // already expose correct range/frame metadata to AVFoundation.
            let preferredCriteria = asset.preferredDisplayCriteria
            apply(preferredCriteria, signature: signature + "|preferred", source: "live-preferred")
            return

            asset.loadValuesAsynchronously(forKeys: ["tracks"]) {
                guard !(pendingLiveWorkItem?.isCancelled ?? true) else { return }
                var error: NSError?
                guard asset.statusOfValue(forKey: "tracks", error: &error) == .loaded else { return }

                let loadedCriteria = asset.preferredDisplayCriteria
                apply(loadedCriteria, signature: signature + "|loaded", source: "live-loaded")
                return
            }
        }
        pendingLiveWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0, execute: workItem)
    }

    static func applyForFullScreenVOD(url: URL, hint: String) {
        let combined = (url.absoluteString + " " + hint)
        let signature = combined.lowercased()
        guard !signature.contains("/trailers/") && !signature.contains("trailer") else { return }

        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/613 DisplayMatch",
            "Accept": "application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive"
        ]
        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])

        // Apple's preferred path: use the AVAsset-vended criteria and assign it to the key
        // UIWindow's AVDisplayManager before KSPlayer starts drawing. This respects the user's
        // tvOS Match Frame Rate / Match Dynamic Range settings instead of forcing display modes.
        let preferredCriteria = asset.preferredDisplayCriteria
        apply(preferredCriteria, signature: signature, source: "asset-preferred")

        asset.loadValuesAsynchronously(forKeys: ["tracks"]) {
            var error: NSError?
            let status = asset.statusOfValue(forKey: "tracks", error: &error)
            guard status == .loaded else { return }

            let loadedCriteria = asset.preferredDisplayCriteria
            apply(loadedCriteria, signature: signature + "|loaded", source: "asset-loaded")
            return
        }
    }

    static func reset() {
        cancelPendingLiveDisplayMatch()
        apply(nil, signature: "", source: "reset")
        lastAppliedSignature = ""
    }
}
#endif

#if canImport(KSPlayer)

// v998: PlaybackKit-owned subtitle bridge. The app uses KSPlayerLayer directly instead
// of IOSVideoPlayerView, so KSPlayer's built-in SRTControl/labels are not mounted for
// this custom VOD surface. Keep the decoder/player untouched and own only the timed
// subtitle model plus a transparent renderer above video and below the SwiftUI VOD UI.
private final class PlaybackExternalSubtitleInfo: SubtitleInfo {
    let subtitleID: String
    let name: String
    var delay: TimeInterval = 0
    var isEnabled: Bool = false

    let url: URL
    private let subtitle = KSSubtitle()

    init(url: URL) {
        self.url = url
        subtitleID = "debrid-external-" + url.absoluteString
        let decoded = url.lastPathComponent.removingPercentEncoding ?? url.lastPathComponent
        name = decoded.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "External Subtitle" : decoded
    }

    func load() async throws {
        try await subtitle.parse(url: url, userAgent: "DebridChannels-tvOS/527 SubtitleBridge")
    }

    func search(for time: TimeInterval) -> [SubtitlePart] {
        subtitle.search(for: time)
    }
}

private final class PlaybackSubtitleOverlayView: UIView {
    private let textLabel = UILabel()
    private let imageView = UIImageView()

    override var canBecomeFocused: Bool { false }

    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = false
        backgroundColor = .clear
        clipsToBounds = false
        layer.zPosition = 50

        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .clear
        imageView.isHidden = true
        imageView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(imageView)

        textLabel.numberOfLines = 0
        textLabel.textAlignment = .center
        textLabel.lineBreakMode = .byWordWrapping
        textLabel.backgroundColor = .clear
        textLabel.isHidden = true
        textLabel.adjustsFontSizeToFitWidth = false
        textLabel.allowsDefaultTighteningForTruncation = false
        textLabel.contentScaleFactor = UIScreen.main.scale
        textLabel.layer.contentsScale = UIScreen.main.scale
        textLabel.layer.shouldRasterize = false
        textLabel.layer.allowsEdgeAntialiasing = true
        textLabel.layer.shadowColor = UIColor.black.cgColor
        textLabel.layer.shadowOpacity = 0.96
        textLabel.layer.shadowRadius = 2.0
        textLabel.layer.shadowOffset = CGSize(width: 0, height: 2)
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(textLabel)

        NSLayoutConstraint.activate([
            textLabel.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 92),
            textLabel.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -92),
            textLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            textLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -82),
            textLabel.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 0.86),

            imageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            imageView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -72),
            imageView.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 0.88),
            imageView.heightAnchor.constraint(lessThanOrEqualTo: heightAnchor, multiplier: 0.28),
        ])
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    func clear() {
        textLabel.attributedText = nil
        textLabel.isHidden = true
        imageView.image = nil
        imageView.isHidden = true
    }

    func render(parts: [SubtitlePart]) {
        guard !parts.isEmpty else {
            clear()
            return
        }

        let images = parts.compactMap(\.image)
        imageView.image = images.first
        imageView.isHidden = images.isEmpty

        let textParts = parts.compactMap(\.text).filter { $0.length > 0 }
        guard !textParts.isEmpty else {
            textLabel.attributedText = nil
            textLabel.isHidden = true
            return
        }

        // Render from the cue strings instead of carrying source ASS/SSA decoration
        // into UILabel. Some streams include their own stroke/shadow/underline attributes;
        // combining those with a thick negative NSStrokeWidth cut into glyph interiors
        // (most visibly e/a/o, commas, and apostrophes). A clean fill plus a layer shadow
        // keeps the v998 bridge intact while preserving sharp CoreText rasterization.
        let cleanLines = textParts
            .map { $0.string.replacingOccurrences(of: "\r", with: "") }
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        guard !cleanLines.isEmpty else {
            textLabel.attributedText = nil
            textLabel.isHidden = true
            return
        }

        let combined = NSMutableAttributedString(string: cleanLines.joined(separator: "\n"))
        let fullRange = NSRange(location: 0, length: combined.length)
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = .center
        paragraph.lineSpacing = 2
        paragraph.lineBreakMode = .byWordWrapping
        combined.setAttributes([
            .font: UIFont.systemFont(ofSize: 58, weight: .medium),
            .foregroundColor: UIColor.white,
            .paragraphStyle: paragraph,
            .ligature: 1,
            .kern: 0,
        ], range: fullRange)

        textLabel.attributedText = combined
        textLabel.isHidden = false
    }
}

// v990 main-VOD cadence refinement, built directly from v987.
//
// v987 successfully avoided KSPNUVIO's aggressive drop/flush cascade, but its six-frame
// lateness allowance could reach 250 ms for 23.976/24 fps cinema. Presenting every frame
// while that far behind can look like tiny slow-motion steps during pans, zooms, and motion.
//
// This refinement keeps the v987 safety rules (no GOP drop, queue flush, or cadence seek),
// but uses a tighter phase window and a short late-frame streak diagnostic. It also lets
// a frame present slightly before the exact half-frame boundary
// to avoid unnecessary one-refresh repeats on matched 23.976/24 Hz output.
private final class DebridFlixorVODOptions: KSOptions {
    private var consecutiveLateDecisions = 0
    private var lateStreakDiagnosticCount = 0
    private var lastLateStreakDiagnosticHostTime: CFTimeInterval = 0

    override func videoFrameMaxCount(
        fps: Float,
        naturalSize: CGSize,
        isLive: Bool
    ) -> UInt8 {
        guard !isLive else {
            return super.videoFrameMaxCount(
                fps: fps,
                naturalSize: naturalSize,
                isLive: true
            )
        }

        // v1012: restore the last preferred static VOD queue profile.
        // Live TV remains fully upstream/adaptive through the guard above.
        let maxDimension = max(naturalSize.width, naturalSize.height)
        let frameCount: UInt8

        if maxDimension >= 3840 {
            frameCount = 24
        } else if maxDimension >= 1920 {
            frameCount = 24
        } else {
            frameCount = 16
        }

        print(
            "[PlaybackKit] VOD decoded-frame queue=\(frameCount) " +
            "fps=\(fps) " +
            "size=\(Int(naturalSize.width))x\(Int(naturalSize.height))"
        )

        return frameCount
    }

    override func videoClockSync(
        main: KSClock,
        nextVideoTime: TimeInterval,
        fps: Double,
        frameCount: Int
    ) -> (Double, ClockProcessType) {
        let safeFPS = max(fps, 1.0)
        let frameDuration = 1.0 / safeFPS
        let desiredTime = main.time.seconds + CACurrentMediaTime() - main.lastMediaTime - videoDelay
        let difference = nextVideoTime - desiredTime

        // KSPNUVIO normally holds until half a frame early. A 0.35-frame window is still
        // safely inside the presentation interval, but avoids repeating the previous frame
        // for a whole display refresh when the next frame is only slightly early.
        let earlyHoldWindow = 0.35 * frameDuration
        if difference >= earlyHoldWindow {
            consecutiveLateDecisions = 0
            return (difference, .remain)
        }

        // v987 allowed six frames of lateness (250 ms at 24 fps). Tighten that to 2.5
        // frames, with a 70 ms floor for high-frame-rate material. This preserves tolerance
        // for a brief decode spike without visibly walking through a deep late queue.
        let softLateWindow = max(2.5 * frameDuration, 0.070)
        if difference >= -softLateWindow {
            consecutiveLateDecisions = 0
            return (difference, .next)
        }

        consecutiveLateDecisions += 1
        let now = CACurrentMediaTime()
        let minimumDiagnosticInterval = max(3.0 * frameDuration, 0.100)
        let diagnosticCooldownElapsed =
            lastLateStreakDiagnosticHostTime == 0 ||
            now - lastLateStreakDiagnosticHostTime >= minimumDiagnosticInterval

        // v1031: do not discard a decoded VOD frame during fast or high-motion scenes.
        // The former forced frame-discard branch could create a visible single-frame
        // discontinuity even while overall playback remained smooth. Keep the exact lateness
        // detection as diagnostics only, then present the next decoded frame normally.
        let shouldReportLateStreak =
            frameCount > 6 &&
            consecutiveLateDecisions >= 3 &&
            diagnosticCooldownElapsed

        if shouldReportLateStreak {
            lastLateStreakDiagnosticHostTime = now
            consecutiveLateDecisions = 0
            lateStreakDiagnosticCount += 1
            if lateStreakDiagnosticCount == 1 || lateStreakDiagnosticCount % 20 == 0 {
                print("[PlaybackKit][v1031] late VOD cadence streak=\(lateStreakDiagnosticCount) dropSuppressed=true diff=\(String(format: "%.4f", difference)) fps=\(String(format: "%.3f", safeFPS)) queued=\(frameCount)")
            }
        }

        return (difference, .next)
    }
}

struct KSPlayerVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    let externalAudioURL: URL?
    let externalAudioOffsetMS: Int
    var muteAudio: Bool = false
    var contentMode: UIView.ContentMode = .scaleAspectFit
    var isLiveStream: Bool = false
    // v1054: immutable owner supplied by the VOD launch. Trailers/Live TV leave this nil.
    var playbackSessionID: UUID? = nil
    var routeHint: String = ""
    var enableDisplayMatch: Bool = false
    var displayMatchIsLive: Bool = false
    var selectedAudioTrackIndex: Int? = nil
    var selectedSubtitleTrackIndex: Int? = nil
    var selectedExternalSubtitleURL: URL? = nil
    var trackSelectionSerial: Int = 0
    var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
    var onTracksDiscovered: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)? = nil
    // Phase 4: failure callback is source-generation scoped by the SwiftUI caller.
    // The coordinator invokes it only while this exact KSPlayerLayer is still active.
    var onPlaybackFailure: ((String) -> Void)? = nil

    final class KSContainerView: UIView {
        private var cachedBounds: CGRect = .null
        private var cachedFrame: CGRect = .null
        private var cachedSafeAreaInsets: UIEdgeInsets = .zero
        private weak var frozenRenderView: UIView?
        private var didFreezePlayerHierarchy = false
        private let subtitleOverlay = PlaybackSubtitleOverlayView()

        override var canBecomeFocused: Bool { false }

        override func didMoveToWindow() {
            super.didMoveToWindow()
            isUserInteractionEnabled = false
        }


        func installRenderViewOnce(_ renderView: UIView) {
            guard frozenRenderView == nil else { return }
            frozenRenderView = renderView
            addSubview(renderView)
            freezePlayerHierarchyOnce(in: renderView)
            if subtitleOverlay.superview == nil {
                addSubview(subtitleOverlay)
                subtitleOverlay.frame = bounds
                subtitleOverlay.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            }
            bringSubviewToFront(subtitleOverlay)
            applyGeometryIfChanged(force: true)
        }

        func updateRenderContentModeIfChanged(_ contentMode: UIView.ContentMode) {
            guard let renderView = frozenRenderView, renderView.contentMode != contentMode else { return }
            renderView.contentMode = contentMode
            let gravity: CALayerContentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
            if renderView.layer.contentsGravity != gravity { renderView.layer.contentsGravity = gravity }
        }

        func resetRenderHostForURLChange() {
            frozenRenderView = nil
            didFreezePlayerHierarchy = false
            cachedBounds = .null
            cachedFrame = .null
            cachedSafeAreaInsets = .zero
            subtitleOverlay.clear()
        }

        func renderSubtitles(_ parts: [SubtitlePart]) {
            if !Thread.isMainThread {
                DispatchQueue.main.async { [weak self] in self?.renderSubtitles(parts) }
                return
            }
            subtitleOverlay.render(parts: parts)
            if subtitleOverlay.superview === self { bringSubviewToFront(subtitleOverlay) }
        }

        func clearSubtitles() {
            if !Thread.isMainThread {
                DispatchQueue.main.async { [weak self] in self?.clearSubtitles() }
                return
            }
            subtitleOverlay.clear()
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            applyGeometryIfChanged()
        }

        private func applyGeometryIfChanged(force: Bool = false) {
            let geometryChanged = force || bounds != cachedBounds || frame != cachedFrame || safeAreaInsets != cachedSafeAreaInsets
            guard geometryChanged else { return }

            cachedBounds = bounds
            cachedFrame = frame
            cachedSafeAreaInsets = safeAreaInsets
            clipsToBounds = true

            guard let renderView = frozenRenderView else { return }
            if subtitleOverlay.frame != bounds { subtitleOverlay.frame = bounds }
            if renderView.transform != .identity { renderView.transform = .identity }
            if renderView.frame != bounds { renderView.frame = bounds }
            if renderView.autoresizingMask != [.flexibleWidth, .flexibleHeight] {
                renderView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            }
        }

        private func freezePlayerHierarchyOnce(in root: UIView) {
            guard !didFreezePlayerHierarchy else { return }
            didFreezePlayerHierarchy = true
            stripKSPlayerChromeOnce(in: root)
        }

        private func stripKSPlayerChromeOnce(in root: UIView) {
            for child in root.subviews {
                let className = String(describing: type(of: child)).lowercased()
                let isSubtitleRenderer = className.contains("subtitle") || className.contains("caption") || className.contains("textview")
                let isChrome = !isSubtitleRenderer && (child is UIControl || child is UIStackView || child is UIButton || className.contains("toolbar") || className.contains("control") || className.contains("button") || className.contains("slider") || className.contains("mask"))
                if isChrome {
                    child.isHidden = true
                    child.alpha = 0
                    child.isUserInteractionEnabled = false
                } else {
                    child.isUserInteractionEnabled = false
                    stripKSPlayerChromeOnce(in: child)
                }
            }
        }
    }

    final class PlaybackSurfaceAnchorView: UIView {
        let surface = KSContainerView()

        override var canBecomeFocused: Bool { false }

        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .black
            isUserInteractionEnabled = false
            clipsToBounds = true
            addSubview(surface)
            surface.frame = bounds
            surface.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        }

        @available(*, unavailable)
        required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

        override func layoutSubviews() {
            super.layoutSubviews()
            if let host = subviews.first(where: { $0 is PlaybackPersistentRenderHostView }) {
                if host.frame != bounds { host.frame = bounds }
            } else if surface.superview === self, surface.frame != bounds {
                surface.frame = bounds
            }
        }
    }

    fileprivate struct UpdateSnapshot: Equatable {
        let url: URL
        let shouldPlay: Bool
        let seekSerial: Int
        let seekSeconds: Double
        let seekIsAbsolute: Bool
        let reloadToken: Int
        let startTimeSeconds: Double
        let externalAudioURL: URL?
        let externalAudioOffsetMS: Int
        let muteAudio: Bool
        let contentModeRawValue: Int
        let isLiveStream: Bool
        let playbackSessionID: UUID?
        let routeHint: String
        let enableDisplayMatch: Bool
        let displayMatchIsLive: Bool
        let selectedAudioTrackIndex: Int?
        let selectedSubtitleTrackIndex: Int?
        let selectedExternalSubtitleURL: URL?
        let trackSelectionSerial: Int
    }

    private var updateSnapshot: UpdateSnapshot {
        UpdateSnapshot(
            url: url,
            shouldPlay: shouldPlay,
            seekSerial: seekSerial,
            seekSeconds: seekSeconds,
            seekIsAbsolute: seekIsAbsolute,
            reloadToken: reloadToken,
            startTimeSeconds: startTimeSeconds,
            externalAudioURL: externalAudioURL,
            externalAudioOffsetMS: externalAudioOffsetMS,
            muteAudio: muteAudio,
            contentModeRawValue: contentMode.rawValue,
            isLiveStream: isLiveStream,
            playbackSessionID: playbackSessionID,
            routeHint: routeHint,
            enableDisplayMatch: enableDisplayMatch,
            displayMatchIsLive: displayMatchIsLive,
            selectedAudioTrackIndex: selectedAudioTrackIndex,
            selectedSubtitleTrackIndex: selectedSubtitleTrackIndex,
            selectedExternalSubtitleURL: selectedExternalSubtitleURL,
            trackSelectionSerial: trackSelectionSerial
        )
    }

    final class Coordinator: NSObject, KSPlayerLayerDelegate, PlaybackRenderSurfaceLifecycleOwner {
        var playerLayer: KSPlayerLayer?
        var currentURL: URL?
        // v1087: URL equality alone is not a playback identity. Reopening the same
        // resolved link must still create a clean clock/render generation for the new
        // VOD presentation instead of inheriting the departing session's coordinator.
        var currentPlaybackSessionID: UUID?
        var lastSeekSerial: Int = 0
        var lastReloadToken: Int = -1
        var currentStartTimeSeconds: Double = 0
        var currentExternalAudioURL: URL?
        var currentExternalAudioOffsetMS: Int = 0
        var currentMuteAudio: Bool = false
        var currentContentMode: UIView.ContentMode = .scaleAspectFit
        var currentShouldPlay: Bool? = nil
        var currentDisplayMatchEnabled: Bool = false
        var currentDisplayMatchIsLive: Bool = false
        var currentPlaybackSeconds: Double = 0
        var currentDurationSeconds: Double = 0
        // v1056: trailer startup work is generation-scoped and stops as soon as the
        // real trailer clock advances. This prevents delayed startup nudges from
        // re-entering an already-playing audio pipeline or reviving an old trailer.
        var currentIsTrailerPlayback: Bool = false
        var trailerStartupGeneration: UInt64 = 0
        var trailerPlaybackHasAdvanced: Bool = false
        var didApplyEnglishAudioSelection: Bool = false
        var englishAudioSelectionScheduled: Bool = false
        var lastTrackSelectionSerial: Int = -1
        var selectedAudioTrackIndex: Int? = nil
        var selectedSubtitleTrackIndex: Int? = nil
        var selectedExternalSubtitleURL: URL? = nil
        var pendingExplicitTrackSelection: Bool = false

        weak var subtitleSurface: KSContainerView?
        let subtitleModel = SubtitleModel()
        private var externalSubtitleInfo: PlaybackExternalSubtitleInfo?
        private var externalSubtitleLoadingURL: URL?
        var externalSubtitleLoadGeneration = 0
        var didAttachEmbeddedSubtitleDataSource = false
        var suppressClockUntil: CFTimeInterval = .greatestFiniteMagnitude
        var playbackStateReadyForClock = false
        // v920: once KSPlayer has reached its first ready state, transient state changes
        // must not permanently stop the real VOD clock. Only initial startup and an
        // explicit seek/track flush freeze time publication.
        var hasReachedInitialReadyForClock = false
        var explicitClockFreeze = true
        var clockReadyAfter: CFTimeInterval = .greatestFiniteMagnitude
        enum ClockFreezeReason: String {
            case startup
            case trackSelection
            case none
        }
        var clockFreezeReason: ClockFreezeReason = .startup
        var clockGateGeneration: UInt64 = 0
        var lastRawPlaybackSeconds: Double = -1
        var firstAdvancingClockHostTime: CFTimeInterval = 0
        var advancingClockSampleCount: Int = 0
        var appliedAudioTrackIndex: Int? = nil
        var appliedSubtitleTrackIndex: Int? = nil
        var appliedExternalSubtitleURL: URL? = nil
        var onPlaybackTimeUpdate: ((Double, Double) -> Void)? = nil
        var onTracksDiscovered: (([RealMediaTrackOption], [RealMediaTrackOption]) -> Void)? = nil
        var onPlaybackFailure: ((String) -> Void)? = nil
        // Phase 11: prevent SwiftUI invalidations from repeatedly entering the active
        // KSPlayer configuration path when no playback command changed.
        fileprivate var lastAppliedUpdateSnapshot: UpdateSnapshot?
        // Phase 7: session-scoped lease for weak render-host registration.
        var renderSurfaceRegistrationEnabled = false
        let renderSurfaceID = UUID()
        var renderSurfaceRegistration: PlaybackRenderSurfaceRegistration?
        // v929 Phase B: KSPlayer may report time at render cadence. Keep the engine clock
        // current on every callback, but coalesce SwiftUI publication so the VOD screen is
        // not invalidated dozens of times per second while video frames are being presented.
        private var lastTimePublicationHostTime: CFTimeInterval = 0
        private var lastPublishedPlaybackSeconds: Double = -1
        private let minimumTimePublicationInterval: CFTimeInterval = 1.00

        // v957: VOD startup parity test. Normal startup now uses only a play assertion,
        // matching the smooth trailer path. A same-position seek is retained solely as a
        // delayed emergency fallback when the active VOD has neither presented a frame nor
        // advanced its real KSPlayer clock after the initial ready state.
        var firstFrameReleaseEligible = false
        var didEvaluateFirstFrameRelease = false
        var didPerformFirstFrameRelease = false
        var firstFrameRecoveryGeneration = 0

        private func layerTreeHasPresentedVideo(_ layer: CALayer) -> Bool {
            if layer.presentation() != nil, layer.contents != nil { return true }
            return layer.sublayers?.contains(where: { layerTreeHasPresentedVideo($0) }) ?? false
        }

        private func renderHostHasPresentedVideo(_ layer: KSPlayerLayer) -> Bool {
            guard let view = layer.player.view, view.window != nil, !view.isHidden, view.alpha > 0.001 else { return false }
            return layerTreeHasPresentedVideo(view.layer)
        }

        private func evaluateFirstFrameReleaseIfNeeded(_ layer: KSPlayerLayer) {
            guard firstFrameReleaseEligible,
                  !didEvaluateFirstFrameRelease,
                  playerLayer === layer else { return }
            didEvaluateFirstFrameRelease = true

            let resumePlayback = currentShouldPlay ?? true
            let baselinePlaybackSeconds = currentPlaybackSeconds
            firstFrameRecoveryGeneration += 1
            let recoveryGeneration = firstFrameRecoveryGeneration

            // v957 normal path: do not seek during startup. Re-assert the requested play
            // state on the existing layer, matching the smooth trailer behavior without
            // creating a second player or touching the decoder configuration.
            if resumePlayback {
                layer.play()
            } else {
                layer.pause()
            }

            // One delayed, non-polling safety check preserves the old manual-forward rescue.
            // The same-position seek runs only when playback was requested, no rendered frame
            // exists, and the real KSPlayer clock has not advanced meaningfully since ready.
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.25) { [weak self, weak layer] in
                guard let self, let layer, self.playerLayer === layer,
                      self.firstFrameReleaseEligible,
                      self.firstFrameRecoveryGeneration == recoveryGeneration,
                      !self.didPerformFirstFrameRelease,
                      self.currentShouldPlay ?? true else { return }

                if self.renderHostHasPresentedVideo(layer) {
                    print("[KSPlayer][v957] VOD first frame presented after play assertion; emergency seek not required")
                    return
                }

                let clockAdvanced = self.currentPlaybackSeconds >= baselinePlaybackSeconds + 0.25
                guard !clockAdvanced else {
                    print("[KSPlayer][v957] VOD clock advanced after play assertion; emergency seek not required")
                    return
                }

                self.didPerformFirstFrameRelease = true
                let releaseTime = max(0, max(self.currentStartTimeSeconds, self.currentPlaybackSeconds))
                layer.seek(time: releaseTime, autoPlay: true) { [weak self, weak layer] finished in
                    guard let self, let layer, self.playerLayer === layer else { return }

                    // This is an emergency startup recovery only. Re-arm the existing clock
                    // gate so a stream that needed the rescue cannot remain frozen at 0:00.
                    self.releaseClockGate(after: 0.12, reason: "emergency first-frame seek completion")
                    print("[KSPlayer][v957] emergency first-frame seek finished=\(finished) at \(releaseTime)s")
                }
            }
        }

        func playbackKitStopAndReleaseSurface() {
            clockGateGeneration &+= 1
            resetSubtitleBridge()
            playerLayer?.pause()
            playerLayer?.stop()
            // KSPlayerLayer in the pinned KSPlayer package does not expose a backing `view`.
            // The session-owned persistent host releases the mounted UIView hierarchy separately.
            playerLayer = nil
            currentURL = nil
            currentPlaybackSessionID = nil
            #if os(tvOS)
            if currentDisplayMatchEnabled, #available(tvOS 11.2, *) {
                DebridTVOSDisplayMatchCoordinator.reset()
            }
            #endif
        }

        private func finiteDuration(_ value: TimeInterval) -> Double? {
            guard value.isFinite, value > 0 else { return nil }
            return value
        }

        func resetClockGateForNewSource(startTime: Double) {
            clockGateGeneration &+= 1
            clockFreezeReason = .startup
            currentPlaybackSeconds = max(0, startTime)
            currentDurationSeconds = 0
            playbackStateReadyForClock = false
            hasReachedInitialReadyForClock = false
            explicitClockFreeze = true
            suppressClockUntil = .greatestFiniteMagnitude
            clockReadyAfter = .greatestFiniteMagnitude
            lastRawPlaybackSeconds = -1
            firstAdvancingClockHostTime = 0
            advancingClockSampleCount = 0
            lastTimePublicationHostTime = 0
            lastPublishedPlaybackSeconds = -1
        }

        private func armClockFreeze(_ reason: ClockFreezeReason, resetRawEvidence: Bool) -> UInt64 {
            clockGateGeneration &+= 1
            clockFreezeReason = reason
            playbackStateReadyForClock = false
            explicitClockFreeze = true
            suppressClockUntil = .greatestFiniteMagnitude
            clockReadyAfter = .greatestFiniteMagnitude
            if resetRawEvidence {
                lastRawPlaybackSeconds = -1
                firstAdvancingClockHostTime = 0
                advancingClockSampleCount = 0
            }
            return clockGateGeneration
        }

        private func releaseClockGate(after delay: CFTimeInterval, reason: String) {
            hasReachedInitialReadyForClock = true
            playbackStateReadyForClock = true
            explicitClockFreeze = false
            clockFreezeReason = .none
            clockReadyAfter = CACurrentMediaTime() + max(0, delay)
            suppressClockUntil = clockReadyAfter
            print("[PlaybackClock][v1087] released gate reason=\(reason) delay=\(delay)")
        }

        private func recordRawClockEvidence(layer: KSPlayerLayer, currentTime: TimeInterval) {
            guard currentTime.isFinite, currentTime >= 0 else { return }
            let now = CACurrentMediaTime()
            if lastRawPlaybackSeconds >= 0 {
                let delta = currentTime - lastRawPlaybackSeconds
                if delta > 0.015 {
                    if advancingClockSampleCount == 0 { firstAdvancingClockHostTime = now }
                    advancingClockSampleCount += 1
                } else if delta < -0.35 {
                    advancingClockSampleCount = 0
                    firstAdvancingClockHostTime = 0
                }
            }
            lastRawPlaybackSeconds = currentTime

            guard explicitClockFreeze else { return }
            let advancedFromStart = currentTime >= max(0, currentStartTimeSeconds) + 0.20
            let sustainedAdvance = advancingClockSampleCount >= 2
                && firstAdvancingClockHostTime > 0
                && now - firstAdvancingClockHostTime >= 0.08
            guard advancedFromStart, sustainedAdvance else { return }

            // KSPNUVIO can omit a second readyToPlay callback after an in-place reload,
            // source replacement, or decoder flush even though decoded playback has resumed.
            // Prefer visible-render evidence, but after several monotonic player-clock samples
            // allow the real engine clock to recover rather than freezing the overlay forever.
            let renderedVideo = renderHostHasPresentedVideo(layer)
            let strongClockEvidence = advancingClockSampleCount >= 4
            guard renderedVideo || strongClockEvidence else { return }
            releaseClockGate(after: 0.08, reason: renderedVideo ? "rendered frame + advancing player clock" : "sustained advancing player clock fallback")
        }

        private func publishPlaybackTime(force: Bool = false) {
            let now = CACurrentMediaTime()
            let meaningfulJump = lastPublishedPlaybackSeconds < 0 || abs(currentPlaybackSeconds - lastPublishedPlaybackSeconds) >= 2.0
            guard force || meaningfulJump || now - lastTimePublicationHostTime >= minimumTimePublicationInterval else { return }
            lastTimePublicationHostTime = now
            lastPublishedPlaybackSeconds = currentPlaybackSeconds
            onPlaybackTimeUpdate?(currentPlaybackSeconds, currentDurationSeconds)
        }

        func resetSubtitleBridge() {
            externalSubtitleLoadGeneration &+= 1
            externalSubtitleInfo = nil
            externalSubtitleLoadingURL = nil
            didAttachEmbeddedSubtitleDataSource = false
            subtitleModel.selectedSubtitleInfo = nil
            subtitleSurface?.clearSubtitles()
        }

        private func attachEmbeddedSubtitleDataSourceIfAvailable(_ layer: KSPlayerLayer) {
            guard !didAttachEmbeddedSubtitleDataSource,
                  let dataSource = layer.player.subtitleDataSouce else { return }
            subtitleModel.addSubtitle(dataSouce: dataSource)
            didAttachEmbeddedSubtitleDataSource = true
            print("[PlaybackKit][v998] attached KSPlayer embedded subtitle data source")
        }

        private func disableEmbeddedSubtitleTracks(_ layer: KSPlayerLayer) {
            for track in layer.player.tracks(mediaType: .subtitle) {
                track.isEnabled = false
            }
        }

        private func disableSubtitles(_ layer: KSPlayerLayer) {
            externalSubtitleLoadGeneration &+= 1
            externalSubtitleInfo = nil
            externalSubtitleLoadingURL = nil
            disableEmbeddedSubtitleTracks(layer)
            subtitleModel.selectedSubtitleInfo = nil
            subtitleSurface?.clearSubtitles()
            print("[PlaybackKit][v998] subtitles disabled and visible cue cleared")
        }

        private func selectExternalSubtitle(_ url: URL, on layer: KSPlayerLayer) {
            if externalSubtitleInfo?.url == url,
               (externalSubtitleLoadingURL == url ||
                subtitleModel.selectedSubtitleInfo?.subtitleID == externalSubtitleInfo?.subtitleID) {
                return
            }

            disableEmbeddedSubtitleTracks(layer)
            subtitleModel.selectedSubtitleInfo = nil
            subtitleSurface?.clearSubtitles()
            externalSubtitleLoadGeneration &+= 1
            let generation = externalSubtitleLoadGeneration
            let info = PlaybackExternalSubtitleInfo(url: url)
            externalSubtitleInfo = info
            externalSubtitleLoadingURL = url

            Task { @MainActor [weak self, weak layer] in
                do {
                    try await info.load()
                    guard let self, let layer,
                          self.playerLayer === layer,
                          self.externalSubtitleLoadGeneration == generation,
                          self.selectedExternalSubtitleURL == url else { return }
                    self.externalSubtitleLoadingURL = nil
                    self.subtitleModel.addSubtitle(info: info)
                    self.subtitleModel.selectedSubtitleInfo = info
                    self.subtitleSurface?.clearSubtitles()
                    print("[PlaybackKit][v998] external subtitle loaded: \(info.name)")
                } catch {
                    guard let self, self.externalSubtitleLoadGeneration == generation else { return }
                    self.externalSubtitleInfo = nil
                    self.externalSubtitleLoadingURL = nil
                    self.subtitleModel.selectedSubtitleInfo = nil
                    self.subtitleSurface?.clearSubtitles()
                    print("[PlaybackKit][v998] external subtitle load failed: \(error.localizedDescription)")
                }
            }
        }

        private func selectEmbeddedSubtitle(index: Int, on layer: KSPlayerLayer) -> Bool {
            let tracks = layer.player.tracks(mediaType: .subtitle)
            guard tracks.indices.contains(index) else { return false }

            externalSubtitleLoadGeneration &+= 1
            externalSubtitleInfo = nil
            externalSubtitleLoadingURL = nil
            attachEmbeddedSubtitleDataSourceIfAvailable(layer)

            let track = tracks[index]
            if let subtitleInfo = track as? any SubtitleInfo,
               track.isEnabled,
               subtitleModel.selectedSubtitleInfo?.subtitleID == subtitleInfo.subtitleID {
                return true
            }
            disableEmbeddedSubtitleTracks(layer)
            track.isEnabled = true
            selectOpenedKSPlayerTrack(track, on: layer)
            if let subtitleInfo = track as? any SubtitleInfo {
                subtitleModel.addSubtitle(info: subtitleInfo)
                subtitleModel.selectedSubtitleInfo = subtitleInfo
                subtitleSurface?.clearSubtitles()
                print("[PlaybackKit][v998] selected embedded subtitle index \(index): \(track.name)")
                return true
            }

            // Keep the player track selected even if a future KSPlayer revision stops
            // exposing SubtitleInfo, but do not claim that rendering is connected.
            subtitleModel.selectedSubtitleInfo = nil
            subtitleSurface?.clearSubtitles()
            print("[PlaybackKit][v998] selected subtitle track lacks SubtitleInfo bridge: \(track.name)")
            return false
        }

        private func refreshSubtitleBridge(_ layer: KSPlayerLayer) {
            guard playerLayer === layer else { return }
            attachEmbeddedSubtitleDataSourceIfAvailable(layer)
            if let externalURL = selectedExternalSubtitleURL {
                selectExternalSubtitle(externalURL, on: layer)
            } else if let subtitleIndex = selectedSubtitleTrackIndex {
                _ = selectEmbeddedSubtitle(index: subtitleIndex, on: layer)
            } else {
                disableSubtitles(layer)
            }
        }

        private func scheduleSubtitleBridgeRefresh(_ layer: KSPlayerLayer) {
            let generation = firstFrameRecoveryGeneration
            for delay in [0.15, 0.75, 1.40] {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self, weak layer] in
                    guard let self, let layer,
                          self.playerLayer === layer,
                          self.firstFrameRecoveryGeneration == generation else { return }
                    self.refreshSubtitleBridge(layer)
                }
            }
        }

        private func renderSubtitleCue(at currentTime: TimeInterval) {
            guard selectedSubtitleTrackIndex != nil || selectedExternalSubtitleURL != nil else {
                subtitleSurface?.clearSubtitles()
                return
            }
            if subtitleModel.subtitle(currentTime: max(0, currentTime)) {
                subtitleSurface?.renderSubtitles(subtitleModel.parts)
            }
        }

        func player(layer: KSPlayerLayer, state: KSPlayerState) {
            // KSPlayer can deliver a final queued state callback after stop(). Ignore it
            // once a replacement layer owns this coordinator; otherwise link A can release
            // link B's clock gate or reapply link A's tracks.
            guard playerLayer === layer else { return }
            if let duration = finiteDuration(layer.player.duration) {
                currentDurationSeconds = max(currentDurationSeconds, duration)
            }
            let stateCanReleaseClock = state == .readyToPlay || state == .bufferFinished
            if stateCanReleaseClock {
                // readyToPlay can arrive before the first decoded video frame is visible.
                // Hold briefly on initial startup/explicit flush, then release the real clock.
                let delay: CFTimeInterval = hasReachedInitialReadyForClock ? 0.12 : 0.45
                releaseClockGate(after: delay, reason: state == .readyToPlay ? "KSPlayer readyToPlay" : "KSPlayer bufferFinished")
            }
            publishPlaybackTime(force: true)
            // v764 safety: only attempt track selection on the explicit ready state, never on
            // generic "play"/buffer states that can fire before KSPlayer exposes stable tracks.
            if state == .readyToPlay {
                evaluateFirstFrameReleaseIfNeeded(layer)
                publishDiscoveredTracks(layer)
                scheduleEnglishAudioTrackSelection(layer)
                if pendingExplicitTrackSelection {
                    applySelectedTracksIfNeeded(layer, force: true, flushAfterSelection: true)
                } else {
                    applySelectedTracksIfNeeded(layer, force: true)
                }
                scheduleSubtitleBridgeRefresh(layer)
            }
        }

        func scheduleEnglishAudioTrackSelection(_ layer: KSPlayerLayer) {
            // Trailer files are already backend-muxed. Re-selecting their default audio
            // track after playback starts can flush or detach the only audio stream.
            guard !currentIsTrailerPlayback,
                  !didApplyEnglishAudioSelection,
                  !englishAudioSelectionScheduled else { return }
            englishAudioSelectionScheduled = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) { [weak self, weak layer] in
                guard let self else { return }
                self.englishAudioSelectionScheduled = false
                guard let layer, self.playerLayer === layer else { return }
                if self.applyEnglishAudioTrackIfAvailable(layer) {
                    self.didApplyEnglishAudioSelection = true
                }
            }
        }

        @discardableResult
        func applyEnglishAudioTrackIfAvailable(_ layer: KSPlayerLayer) -> Bool {
            let audioTracks = layer.player.tracks(mediaType: .audio)
            guard !audioTracks.isEmpty else { return false }
            let englishCodes: Set<String> = ["en", "eng", "en-us", "en-gb", "english"]
            guard let english = audioTracks.first(where: { track in
                let lang = (track.languageCode ?? track.language ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                let name = track.name.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
                return englishCodes.contains(lang) || lang.hasPrefix("en") || lang.contains("eng") || name.contains("english") || name.contains(" eng") || name == "eng" || name.contains("en-us") || name.contains("en-gb")
            }) else { return false }
            guard let index = audioTracks.firstIndex(where: {
                $0.name == english.name && ($0.languageCode ?? $0.language ?? "") == (english.languageCode ?? english.language ?? "")
            }) else {
                layer.player.select(track: english)
                print("[KSPlayer] selected English audio track: \(english.name)")
                return true
            }
            if appliedAudioTrackIndex == index {
                return true
            }
            layer.player.select(track: english)
            appliedAudioTrackIndex = index
            print("[KSPlayer] selected English audio track: \(english.name)")
            return true
        }

        func publishDiscoveredTracks(_ layer: KSPlayerLayer) {
            let audio = layer.player.tracks(mediaType: .audio).enumerated().map { index, track in
                makeRealTrackOption(track: track, index: index, kind: "Audio")
            }
            let subtitles = layer.player.tracks(mediaType: .subtitle).enumerated().map { index, track in
                makeRealTrackOption(track: track, index: index, kind: "Subtitle")
            }
            if !audio.isEmpty || !subtitles.isEmpty {
                DispatchQueue.main.async { [weak self, weak layer] in
                    guard let self, let layer, self.playerLayer === layer else { return }
                    self.onTracksDiscovered?(audio, subtitles)
                }
            }
        }

        func makeRealTrackOption(track: Any, index: Int, kind: String) -> RealMediaTrackOption {
            let mirror = Mirror(reflecting: track)
            func value(_ names: [String]) -> String? {
                for child in mirror.children {
                    guard let label = child.label, names.contains(label) else { continue }
                    if let v = child.value as? String, !v.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return v }
                    if let v = child.value as? String?, let text = v, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return text }
                }
                return nil
            }
            let name = value(["name", "title"]) ?? "\(kind) \(index + 1)"
            let language = value(["languageCode", "language", "locale"]) ?? name
            return RealMediaTrackOption(
                id: "ks-\(kind.lowercased())-\(index)-\(language)-\(name)",
                optionIndex: index,
                label: name,
                languageName: MediaTrackLanguageNormalizer.displayName(code: language, fallback: name),
                codecOrFormat: value(["codec", "codecName", "format"]),
                isDefault: name.lowercased().contains("default"),
                isForced: name.lowercased().contains("forced"),
                isSDH: name.lowercased().contains("sdh")
            )
        }

        func selectOpenedKSPlayerTrack<Track: MediaPlayerTrack>(_ track: Track, on layer: KSPlayerLayer) {
            layer.player.select(track: track)
        }

        @discardableResult
        func applySelectedTracksIfNeeded(_ layer: KSPlayerLayer, force: Bool = false, flushAfterSelection: Bool = false) -> Bool {
            var changedAudioTrack = false
            var changedSubtitleTrack = false

            if let audioIndex = selectedAudioTrackIndex {
                let tracks = layer.player.tracks(mediaType: .audio)
                if tracks.indices.contains(audioIndex), appliedAudioTrackIndex != audioIndex {
                    let track = tracks[audioIndex]
                    selectOpenedKSPlayerTrack(track, on: layer)
                    appliedAudioTrackIndex = audioIndex
                    didApplyEnglishAudioSelection = true
                    changedAudioTrack = true
                    print("[KSPlayer] selected audio track index \(audioIndex): \(track.name)")
                }
            }

            if let externalURL = selectedExternalSubtitleURL {
                if appliedExternalSubtitleURL != externalURL {
                    selectExternalSubtitle(externalURL, on: layer)
                    appliedExternalSubtitleURL = externalURL
                    appliedSubtitleTrackIndex = nil
                    changedSubtitleTrack = true
                }
            } else if let subtitleIndex = selectedSubtitleTrackIndex {
                if appliedSubtitleTrackIndex != subtitleIndex {
                    changedSubtitleTrack = selectEmbeddedSubtitle(index: subtitleIndex, on: layer)
                    if changedSubtitleTrack {
                        appliedSubtitleTrackIndex = subtitleIndex
                        appliedExternalSubtitleURL = nil
                    }
                }
            } else if force {
                disableSubtitles(layer)
                appliedSubtitleTrackIndex = nil
                appliedExternalSubtitleURL = nil
            }

            // Audio decoder changes can retain buffered audio packets, so preserve the
            // existing one-shot same-position flush for explicit audio selection only.
            // Subtitle selection is connected directly to SubtitleModel and must never
            // seek/restart the video or clear the newly selected subtitle queue.
            if flushAfterSelection && changedAudioTrack {
                pendingExplicitTrackSelection = false
                let resumePlayback = currentShouldPlay ?? true
                let flushTime = max(0, currentPlaybackSeconds)
                let freezeGeneration = armClockFreeze(.trackSelection, resetRawEvidence: true)
                layer.seek(time: flushTime, autoPlay: false) { [weak self, weak layer] finished in
                    guard let self, let layer, self.playerLayer === layer,
                          self.clockGateGeneration == freezeGeneration else { return }
                    if resumePlayback { layer.play() } else { layer.pause() }
                    self.releaseClockGate(after: 0.12, reason: "explicit audio-track seek completion")
                    self.publishPlaybackTime(force: true)
                    print("[KSPlayer] active-player audio flush finished=\(finished) at \(flushTime)s resume=\(resumePlayback)")
                }
                // Some FFmpeg-backed sources complete the seek internally but omit the
                // completion callback. Never let that leave the timeline frozen forever.
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.80) { [weak self, weak layer] in
                    guard let self, let layer, self.playerLayer === layer,
                          self.clockGateGeneration == freezeGeneration,
                          self.explicitClockFreeze,
                          self.clockFreezeReason == .trackSelection else { return }
                    if resumePlayback { layer.play() } else { layer.pause() }
                    self.releaseClockGate(after: 0.08, reason: "audio-track flush timeout recovery")
                    self.publishPlaybackTime(force: true)
                }
            } else if flushAfterSelection {
                pendingExplicitTrackSelection = false
            }

            return changedAudioTrack || changedSubtitleTrack
        }

        func player(layer: KSPlayerLayer, currentTime: TimeInterval, totalTime: TimeInterval) {
            // A stopped FFmpeg layer may drain one or more queued time callbacks. Never
            // publish those samples into the replacement source's session clock.
            guard playerLayer === layer else { return }
            if let duration = finiteDuration(totalTime) {
                currentDurationSeconds = max(currentDurationSeconds, duration)
            }
            if currentIsTrailerPlayback, currentTime > 0.25 {
                trailerPlaybackHasAdvanced = true
            }
            // Subtitle timing follows the engine's exact current-time callback, not the
            // one-second SwiftUI overlay publication cadence.
            renderSubtitleCue(at: currentTime)
            // FFPlayer can advance its demux clock during initial buffering and immediately
            // after seek/track decoder flushes, before video output resumes. Keep duration
            // metadata flowing, but freeze the user-visible current/remaining time in that gap.
            // Do not require KSPlayer to remain in .readyToPlay forever. Some streams
            // transition through buffering/playing-style states after startup and never send
            // another ready callback, which previously froze the progress bar at 0:00.
            recordRawClockEvidence(layer: layer, currentTime: currentTime)
            guard hasReachedInitialReadyForClock,
                  !explicitClockFreeze,
                  CACurrentMediaTime() >= suppressClockUntil,
                  CACurrentMediaTime() >= clockReadyAfter else {
                publishPlaybackTime()
                return
            }
            if currentTime.isFinite {
                currentPlaybackSeconds = max(0, currentTime)
            }
            publishPlaybackTime()
        }

        func player(layer: KSPlayerLayer, finish error: Error?) {
            guard playerLayer === layer else { return }
            if let error {
                let message = error.localizedDescription
                print("[KSPlayer] playback finished with error: \(message)")
                DispatchQueue.main.async { [weak self] in
                    guard let self, self.playerLayer === layer else { return }
                    self.onPlaybackFailure?(message)
                }
            }
        }

        func player(layer: KSPlayerLayer, bufferedCount: Int, consumeTime: TimeInterval) {
            guard playerLayer === layer else { return }
        }
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> PlaybackSurfaceAnchorView {
        let anchor = PlaybackSurfaceAnchorView()
        let view = anchor.surface
        context.coordinator.renderSurfaceRegistrationEnabled = !isLiveStream && playbackSessionID != nil
        context.coordinator.subtitleSurface = view
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.lastAppliedUpdateSnapshot = updateSnapshot
        configure(view: view, coordinator: context.coordinator)
        if context.coordinator.renderSurfaceRegistrationEnabled,
           let playbackSessionID {
            // Registration is explicitly tied to the VOD launch UUID. A surface from link A
            // can never be adopted by link B, even when makeUIView precedes onAppear.
            context.coordinator.renderSurfaceRegistration = PlaybackController.shared.registerRenderSurfaceCandidate(
                view,
                surfaceID: context.coordinator.renderSurfaceID,
                sessionID: playbackSessionID,
                lifecycleOwner: context.coordinator
            )
        }
        return anchor
    }

    func updateUIView(_ anchor: PlaybackSurfaceAnchorView, context: Context) {
        // Callback closures may be recreated by SwiftUI even when their behavior is the same.
        // Refresh them without touching KSPlayer, then compare only stable playback inputs.
        context.coordinator.onPlaybackTimeUpdate = onPlaybackTimeUpdate
        context.coordinator.onTracksDiscovered = onTracksDiscovered
        context.coordinator.onPlaybackFailure = onPlaybackFailure
        context.coordinator.subtitleSurface = anchor.surface
        let snapshot = updateSnapshot
        guard context.coordinator.lastAppliedUpdateSnapshot != snapshot else { return }
        context.coordinator.lastAppliedUpdateSnapshot = snapshot
        configure(view: anchor.surface, coordinator: context.coordinator)
    }

    private func makeOptions(url: URL, muteAudio: Bool = false, startTimeSeconds: Double = 0) -> KSOptions {
        let lowerURL = url.absoluteString.lowercased()
        let lowerRouteHint = routeHint.lowercased()
        let timingRiskHaystack = lowerURL + " " + lowerRouteHint
        let isTrailerPlayback = isTrailerURL(url) || lowerRouteHint.contains("trailer")
        let isVODStylePlayback = !isLiveStream && !isTrailerPlayback
        // v985: the selected Source Intelligence label carries quality/size/container
        // facts into PlaybackKit. Use those facts only to choose a safer memory profile;
        // the 25/50 visible result limit and source ranking remain unchanged.
        let isHighMemoryVOD = isVODStylePlayback && (
            timingRiskHaystack.contains("2160") ||
            timingRiskHaystack.contains("4k") ||
            timingRiskHaystack.contains("uhd") ||
            timingRiskHaystack.contains("remux") ||
            timingRiskHaystack.contains("truehd") ||
            timingRiskHaystack.contains("dts-hd") ||
            timingRiskHaystack.contains("dtshd")
        )
        let options: KSOptions = isVODStylePlayback ? DebridFlixorVODOptions() : KSOptions()
        // Flixor creates the VOD session with autoplay disabled, then issues one
        // explicit play after the stable native view is mounted. Other routes retain
        // their current autoplay behavior.
        KSOptions.isAutoPlay = !isVODStylePlayback
        // v990: when tvOS Match Content is enabled for main VOD, let CADisplayLink follow
        // the physically matched output cadence directly. KSPNUVIO's preferredFrame path
        // rounds 23.976 to 24 and 29.97 to 30; bypassing that rounding on an already matched
        // display removes a possible long-interval phase correction. If Match Content is off,
        // keep KSPNUVIO's preferred-frame scheduling behavior.
        #if os(tvOS)
        let usesMatchedVODDisplayLink =
            isVODStylePlayback &&
            enableDisplayMatch &&
            DebridTVOSDisplayMatchCoordinator.isSystemDisplayMatchingEnabled()
        KSOptions.preferredFrame = !usesMatchedVODDisplayLink
        #else
        KSOptions.preferredFrame = true
        #endif
        let hasCBSMetadataSignal =
            timingRiskHaystack.contains("cbs") ||
            timingRiskHaystack.contains("paramount") ||
            timingRiskHaystack.contains("wcbs") ||
            timingRiskHaystack.contains("kcbs") ||
            timingRiskHaystack.contains("wbbm") ||
            timingRiskHaystack.contains("wkyc")
        let hasLiveRemuxTimingSignal =
            timingRiskHaystack.contains("/devices/") ||
            timingRiskHaystack.contains("channels.m3u") ||
            timingRiskHaystack.contains("/hls/") ||
            timingRiskHaystack.contains("/dvr/") ||
            timingRiskHaystack.contains("format=ts") ||
            timingRiskHaystack.contains(".m3u8") ||
            timingRiskHaystack.contains(".mpg") ||
            timingRiskHaystack.contains("tve") ||
            timingRiskHaystack.contains("channels dvr") ||
            timingRiskHaystack.contains("verizon") ||
            timingRiskHaystack.contains("live tv direct stream") ||
            timingRiskHaystack.contains("ks live tv route")
        let isLikelyCBSLiveTimingRisk =
            !isTrailerPlayback &&
            hasCBSMetadataSignal &&
            hasLiveRemuxTimingSignal
        let hasKnownNonNativeContainer = lowerURL.contains(".mkv") || lowerURL.contains("%2emkv") || lowerURL.contains("matroska") || lowerURL.contains(".avi") || lowerURL.contains("%2eavi") || lowerURL.contains(".webm") || lowerURL.contains("%2ewebm") || lowerURL.contains(".vob") || lowerURL.contains("%2evob")
        let hasHighRiskAudioContainerHint = lowerURL.contains("truehd") || lowerURL.contains("dts-hd") || lowerURL.contains("dtshd") || lowerURL.contains(" mlp") || lowerURL.contains("atmos truehd")
        let shouldTryNativeFirstForTvOSMatch = !isTrailerPlayback && !hasKnownNonNativeContainer && !hasHighRiskAudioContainerHint
        // v833: Match Frame Rate / Dynamic Range crash guard.
        // Preserve the v831 KSPlayer buffer/cache-ahead tuning, but do not force the
        // KSAVPlayer-first path during normal VOD playback. On some tvOS/projector/display
        // combinations the AVFoundation handoff can crash when Match Content is enabled.
        // KSMEPlayer remains the primary KSPlayer route. v961 gives main VOD the
        // same KSAVPlayer fallback order used by Flixor; trailers and Live TV keep
        // the previous KSMEPlayer-only fallback behavior.
        KSOptions.firstPlayerType = KSMEPlayer.self
        KSOptions.secondPlayerType = isVODStylePlayback ? KSAVPlayer.self : KSMEPlayer.self
        options.isSecondOpen = true
        options.isAccurateSeek = true
        options.isSeekedAutoPlay = true
        options.startPlayTime = max(0, startTimeSeconds)
        if isTrailerPlayback {
            // v1059 built-in trailer audio integrity: do not let KSPlayer declare the
            // session open from the first partially parsed stream. Wait for the finalized
            // mux to expose stable video + audio tracks before playback becomes authoritative.
            options.isSecondOpen = false
            options.isAccurateSeek = false
            options.syncDecodeAudio = false
        }
        // v840: restore v832 trailer playback profile only.
        // v839 remains the base for everything else. Trailers go back to the
        // smaller v832 KSPlayer buffer/probe lane that avoided trailer stutter,
        // while movies/episodes keep the current VOD buffer/cache profile.
        // v961: main VOD matches Flixor's high-bitrate buffer profile exactly.
        // Trailers and Live TV retain their existing, proven buffer windows.
        options.preferredForwardBufferDuration = isLikelyCBSLiveTimingRisk ? 8 : (isHighMemoryVOD ? 3 : (isVODStylePlayback ? 5 : (!isLiveStream ? 45 : 6)))
        options.maxBufferDuration = isLikelyCBSLiveTimingRisk ? 12 : (isHighMemoryVOD ? 30 : (isVODStylePlayback ? 300 : (!isLiveStream ? 90 : 12)))
        let playbackConfiguration = isLiveStream ? PlaybackConfiguration.live : PlaybackConfiguration.vod
        options.hardwareDecode = playbackConfiguration.hardwareDecode
        // v943 trailer cadence restoration: apply the same v840 cadence hybrid to
        // trailers as movies/episodes. Live TV remains on its existing path.
        options.asynchronousDecompression = playbackConfiguration.asynchronousDecompression
        options.decoderOptions["threads"] = playbackConfiguration.decoderThreadCount
        if let decoderThreadType = playbackConfiguration.decoderThreadType {
            options.decoderOptions["thread_type"] = decoderThreadType
        } else {
            options.decoderOptions["thread_type"] = nil
        }

        // v990 refined main-VOD cadence profile, retaining the v987 decode/buffer base. Keep the v985 memory-pressure
        // protections and v986 decoded-frame timestamp ordering, then disable the
        // instant "second open" path so playback reaches ready state with the full
        // preferred VOD buffer instead of only a couple of decoded frames.
        if isVODStylePlayback {
            options.hardwareDecode = true
            // KSPNUVIO default. Decode/presentation timestamps are taken from decoded
            // frames instead of the asynchronous compressed-packet path. The existing
            // one-shot first-frame play assertion/emergency same-position seek remains
            // active, so disabling asynchronous decompression does not restore the old
            // manual Skip Forward/Back startup requirement.
            // v993: restore the smoother decoded-frame FFmpeg path from v990/v987. The
            // pinned local KSPNUVIO package now clamps malformed/oversized HDR metadata and
            // bounds SEI reads, fixing the HEVC SIGTRAP at its source without forcing the
            // asynchronous VideoToolbox callback path that produces slow-scene stepping.
            options.asynchronousDecompression = false
            options.syncDecodeVideo = false
            options.syncDecodeAudio = false
            options.videoAdaptable = true
            // KSPNUVIO default is false. The app already owns a one-shot first-frame
            // release, so main VOD no longer needs to declare itself playable with only
            // the minimum two decoded frames.
            options.isSecondOpen = false
            options.isAccurateSeek = false
            options.isSeekImageSubtitle = true
            options.probesize = isHighMemoryVOD ? 12_000_000 : 50_000_000
            options.maxAnalyzeDuration = isHighMemoryVOD ? 3_000_000 : 5_000_000
            options.destinationDynamicRange = nil
            options.decoderOptions["threads"] = "auto"
            options.decoderOptions["thread_type"] = nil
            options.decoderOptions["skip_loop_filter"] = nil
        } else if !isLiveStream {
            options.decoderOptions["skip_loop_filter"] = "none"
        }
        options.videoAdaptable = true

        let effectiveThreads = options.decoderOptions["threads"] as? String ?? "engine-default"
        let effectiveThreadType = options.decoderOptions["thread_type"] as? String ?? "engine-default"
        if isVODStylePlayback || PlaybackDiagnostics.isEnabled {
            print("[PlaybackKit][v1059] route=\(isVODStylePlayback ? "main-vod" : (isTrailerPlayback ? "trailer" : "live")) highMemoryVOD=\(isHighMemoryVOD) hardware=\(options.hardwareDecode) async=\(options.asynchronousDecompression) syncVideo=\(options.syncDecodeVideo) syncAudio=\(options.syncDecodeAudio) adaptable=\(options.videoAdaptable) secondOpen=\(options.isSecondOpen) accurateSeek=\(options.isAccurateSeek) probe=\(options.probesize ?? -1) analyze=\(options.maxAnalyzeDuration ?? -1) buffer=\(options.preferredForwardBufferDuration)/\(options.maxBufferDuration) threads=\(effectiveThreads) type=\(effectiveThreadType) autoplay=\(KSOptions.isAutoPlay) fallback=\(String(describing: KSOptions.secondPlayerType))")
        }
        // v915/v840 stability: do not auto-select an embedded subtitle stream during
        // player startup. Explicit user track selection remains available after ready.
        options.autoSelectEmbedSubtitle = false
        options.registerRemoteControll = false
        options.userAgent = isTrailerPlayback ? "DebridChannels-tvOS/1059 BuiltInTrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer"
        options.avOptions = [
            "AVURLAssetHTTPHeaderFieldsKey": [
                "User-Agent": isTrailerPlayback ? "DebridChannels-tvOS/1059 BuiltInTrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
                "Accept": "*/*",
                "Connection": "keep-alive"
            ]
        ]
        var formatOptions: [String: String] = [
            "reconnect": "1",
            "reconnect_streamed": "1",
            "reconnect_delay_max": "5",
            "fflags": isTrailerPlayback ? "+genpts" : (isLikelyCBSLiveTimingRisk ? "+genpts" : (isVODStylePlayback ? "+genpts" : "nobuffer")),
            "flags": isTrailerPlayback ? "" : (isLikelyCBSLiveTimingRisk || isVODStylePlayback ? "" : "low_delay"),
            "cache": isLikelyCBSLiveTimingRisk ? "1500" : (isTrailerPlayback ? "1500" : (isVODStylePlayback ? "1500" : "1500")),
            "rw_timeout": "15000000",
            "user_agent": isTrailerPlayback ? "DebridChannels-tvOS/1059 BuiltInTrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
            "preferred_language": "eng,en,English",
            "preferred_audio_language": "eng,en,English",
            "audio_language": "eng,en,English",
            "alang": "eng,en,English",
            "slang": "eng,en,English",
            "subtitles": "1",
            "sn": "1",
            "analyzeduration": isTrailerPlayback ? "1000000" : (isLikelyCBSLiveTimingRisk ? "3000000" : (isVODStylePlayback ? "3000000" : "100000")),
            "probesize": isTrailerPlayback ? "262144" : (isLikelyCBSLiveTimingRisk ? "1048576" : (isVODStylePlayback ? "1048576" : "16384")),
            "thread_queue_size": isHighMemoryVOD ? "2048" : "8192",
            "max_delay": isTrailerPlayback ? "100000" : (isLikelyCBSLiveTimingRisk ? "700000" : (isVODStylePlayback ? "100000" : "100000")),
            "sync": isLikelyCBSLiveTimingRisk ? "ext" : "audio",
            "fpsprobesize": isTrailerPlayback ? "240" : (isVODStylePlayback ? "240" : "120")
        ]
        // v957: trailer and main VOD parity. Do not pass an empty FFmpeg `flags`
        // entry for either non-live path; Live TV retains its existing behavior.
        if isTrailerPlayback || isVODStylePlayback {
            formatOptions.removeValue(forKey: "flags")
        }
        // v940: VOD-only safe demux tuning. Live TV retains v938 exactly.
        if !isLiveStream {
            formatOptions["reorder_queue_size"] = isHighMemoryVOD ? "512" : "1024"
            formatOptions["buffer_size"] = String((isHighMemoryVOD ? 4 : 8) * 1024 * 1024)
            formatOptions["analyzeduration"] = isHighMemoryVOD ? "5000000" : "10000000"
            formatOptions["probesize"] = isHighMemoryVOD ? "8000000" : "15000000"
        }
        if muteAudio {
            formatOptions["an"] = "1"
            formatOptions["audio_disable"] = "1"
            formatOptions["volume"] = "0"
        }

        if isVODStylePlayback {
            // Flixor does not replace KSOptions' default FFmpeg dictionary with a
            // large raw option set. Keep KSPlayer defaults (scan_all_pmts,
            // reconnect, reconnect_streamed, user_agent) and append only the
            // request headers Debrid links require.
            let vodHeaders = [
                "User-Agent": "DebridChannels-tvOS/158 KSPlayer",
                "Accept": "*/*",
                "Connection": "keep-alive"
            ]
            options.appendHeader(vodHeaders)
            if muteAudio {
                options.formatContextOptions["an"] = "1"
                options.formatContextOptions["audio_disable"] = "1"
                options.formatContextOptions["volume"] = "0"
            }
        } else {
            options.formatContextOptions = formatOptions
        }
        return options
    }

    private func performBestEffortSeek(coordinator: Coordinator, layer: KSPlayerLayer, seconds: Double, isAbsolute: Bool, resumePlayback: Bool, currentSeconds: Double, durationHint: Double) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async {
                performBestEffortSeek(coordinator: coordinator, layer: layer, seconds: seconds, isAbsolute: isAbsolute, resumePlayback: resumePlayback, currentSeconds: currentSeconds, durationHint: durationHint)
            }
            return
        }

        let reportedDuration = max(layer.player.duration, durationHint)
        let hasFiniteDuration = reportedDuration.isFinite && reportedDuration > 1
        let duration = hasFiniteDuration ? reportedDuration : Double.greatestFiniteMagnitude

        // VODPlayerScreen sends Back/Forward/Timeline scrubs as absolute, clamped seconds.
        // v827: do not reject seeks just because duration metadata is late; KSPlayer/FFmpeg
        // can often seek against the stream before a stable total duration is reported.
        let current = hasFiniteDuration ? max(0, min(currentSeconds, duration)) : max(0, currentSeconds)
        let unclampedTarget = isAbsolute ? seconds : current + seconds
        let target = min(max(unclampedTarget, 0), duration)

        print("KSPlayer Seek Requested: current=\(current) target=\(target) duration=\(hasFiniteDuration ? reportedDuration : -1)")
        layer.player.pause()
        layer.seek(time: target, autoPlay: resumePlayback) { [weak coordinator, weak layer] finished in
            DispatchQueue.main.async {
                guard let coordinator, let layer, coordinator.playerLayer === layer else { return }
                print(finished ? "KSPlayer Seek Completed" : "KSPlayer Seek Failed")
                if resumePlayback { layer.play() }
            }
        }
    }

    private func applyAudioMuteState(_ layer: KSPlayerLayer, muteAudio: Bool) {
        if let object = layer.player as? NSObject {
            let mutedSelector = NSSelectorFromString("setMuted:")
            let volumeSelector = NSSelectorFromString("setVolume:")
            if object.responds(to: mutedSelector) { object.setValue(muteAudio, forKey: "muted") }
            if object.responds(to: volumeSelector) { object.setValue(muteAudio ? 0.0 : 1.0, forKey: "volume") }
        }
    }

    // v902: deliberately no KVC/Mirror subtitle-object probing.  The v901 crash was
    // caused by undefined-key access while loading a link.  Subtitle layout is restricted
    // to real UIView descendants already owned by KSPlayer and is synchronized in
    // KSContainerView.layoutSubviews().

    private func configure(view: KSContainerView, coordinator: Coordinator) {
        coordinator.subtitleSurface = view
        if coordinator.currentURL == url,
           coordinator.currentPlaybackSessionID == playbackSessionID,
           coordinator.lastReloadToken == reloadToken,
           let layer = coordinator.playerLayer {
            let externalAudioConfigurationChanged =
                coordinator.currentExternalAudioURL != externalAudioURL ||
                coordinator.currentExternalAudioOffsetMS != externalAudioOffsetMS
            let muteChanged = coordinator.currentMuteAudio != muteAudio
            let contentModeChanged = coordinator.currentContentMode != contentMode

            if externalAudioConfigurationChanged || muteChanged || contentModeChanged {
                coordinator.currentExternalAudioURL = externalAudioURL
                coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
                coordinator.currentMuteAudio = muteAudio
                coordinator.currentContentMode = contentMode
                // Smart Alternate Audio v1: keep the main video URL active and carry the selected
                // alternate audio reference/sync offset in the surface state. KSPlayer package APIs
                // differ by version for external audio attachment, so this v1 hook is non-crashing
                // and ready for the engine-specific attachment call when exposed by the compiled SDK.
            }
            if contentModeChanged {
                // Playback profile changes are the only non-geometry updates permitted to
                // touch the frozen render host. Identical assignments are suppressed.
                view.updateRenderContentModeIfChanged(contentMode)
            }
            if seekSerial != coordinator.lastSeekSerial {
                coordinator.lastSeekSerial = seekSerial
                performBestEffortSeek(coordinator: coordinator, layer: layer, seconds: seekSeconds, isAbsolute: seekIsAbsolute, resumePlayback: shouldPlay, currentSeconds: coordinator.currentPlaybackSeconds, durationHint: coordinator.currentDurationSeconds)
            }
            if muteChanged {
                applyAudioMuteState(layer, muteAudio: muteAudio)
            }
            if coordinator.lastTrackSelectionSerial != trackSelectionSerial {
                coordinator.lastTrackSelectionSerial = trackSelectionSerial
                // Copy the new UI choice onto the coordinator BEFORE touching the active player.
                // v895 previously applied the coordinator's stale indexes, so audio often changed
                // only after a later rewind/resume and subtitle selection could be lost entirely.
                coordinator.selectedAudioTrackIndex = selectedAudioTrackIndex
                coordinator.selectedSubtitleTrackIndex = selectedSubtitleTrackIndex
                coordinator.selectedExternalSubtitleURL = selectedExternalSubtitleURL
                coordinator.pendingExplicitTrackSelection = true
                _ = coordinator.applySelectedTracksIfNeeded(layer, force: true, flushAfterSelection: true)
            }
            // v408: KSPlayer can crash on some tvOS/package builds if play()/pause() is
            // spammed on every SwiftUI state refresh. Only send the command when the
            // requested playback state actually changes. This stabilizes Pause -> Play
            // without changing URL, cache, seek, overlay, or Live TV behavior.
            if coordinator.currentShouldPlay != shouldPlay {
                coordinator.currentShouldPlay = shouldPlay
                if shouldPlay { layer.play() } else { layer.pause() }
            }
            // v1056: never schedule a new chain of trailer play/start commands from a
            // routine SwiftUI update. A single harmless play assertion is allowed only
            // before the real trailer clock has advanced.
            if shouldPlay, coordinator.currentIsTrailerPlayback, !coordinator.trailerPlaybackHasAdvanced {
                layer.play()
            }
            return
        }

        coordinator.playerLayer?.pause()
        coordinator.playerLayer?.stop()
        // URL/reload replacement is the sole path allowed to detach the old render host.
        view.resetRenderHostForURLChange()
        view.subviews.forEach { $0.removeFromSuperview() }
        coordinator.resetSubtitleBridge()
        coordinator.subtitleSurface = view
        coordinator.currentURL = url
        coordinator.currentPlaybackSessionID = playbackSessionID
        coordinator.lastReloadToken = reloadToken
        coordinator.currentStartTimeSeconds = startTimeSeconds
        coordinator.currentExternalAudioURL = externalAudioURL
        coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
        coordinator.currentMuteAudio = muteAudio
        coordinator.currentContentMode = contentMode
        coordinator.currentShouldPlay = shouldPlay
        coordinator.lastSeekSerial = seekSerial
        coordinator.resetClockGateForNewSource(startTime: startTimeSeconds)
        coordinator.currentIsTrailerPlayback = isTrailerURL(url) || routeHint.lowercased().contains("trailer")
        coordinator.trailerStartupGeneration &+= 1
        coordinator.trailerPlaybackHasAdvanced = false
        coordinator.didApplyEnglishAudioSelection = false
        coordinator.englishAudioSelectionScheduled = false
        coordinator.appliedAudioTrackIndex = nil
        coordinator.appliedSubtitleTrackIndex = nil
        coordinator.appliedExternalSubtitleURL = nil
        coordinator.lastTrackSelectionSerial = trackSelectionSerial
        coordinator.selectedAudioTrackIndex = selectedAudioTrackIndex
        coordinator.selectedSubtitleTrackIndex = selectedSubtitleTrackIndex
        coordinator.selectedExternalSubtitleURL = selectedExternalSubtitleURL
        coordinator.pendingExplicitTrackSelection = false
        coordinator.firstFrameReleaseEligible = !isLiveStream && !coordinator.currentIsTrailerPlayback
        coordinator.didEvaluateFirstFrameRelease = false
        coordinator.didPerformFirstFrameRelease = false
        coordinator.firstFrameRecoveryGeneration += 1
        coordinator.onTracksDiscovered = onTracksDiscovered

        let options = makeOptions(url: url, muteAudio: muteAudio, startTimeSeconds: startTimeSeconds)
        coordinator.currentDisplayMatchEnabled = enableDisplayMatch
        coordinator.currentDisplayMatchIsLive = displayMatchIsLive
        #if os(tvOS)
        if enableDisplayMatch, #available(tvOS 11.2, *) {
            if displayMatchIsLive {
                DebridTVOSDisplayMatchCoordinator.applyForLiveChannel(url: url, hint: routeHint)
            } else {
                DebridTVOSDisplayMatchCoordinator.applyForFullScreenVOD(url: url, hint: routeHint)
            }
        } else if #available(tvOS 11.2, *) {
            DebridTVOSDisplayMatchCoordinator.cancelPendingLiveDisplayMatch()
        }
        #endif
        // v1014: restore the proven v999 Live TV construction path exactly.
        // Live TV and trailers retain constructor autoplay; full-screen VOD remains
        // mounted first and then receives the existing explicit play command.
        let isMainVODPlayback = !isLiveStream && !coordinator.currentIsTrailerPlayback
        let layer = KSPlayerLayer(url: url, isAutoPlay: !isMainVODPlayback, options: options, delegate: coordinator)
        coordinator.playerLayer = layer
        if let playerView = layer.player.view {
            playerView.backgroundColor = .black
            playerView.isOpaque = true
            playerView.clearsContextBeforeDrawing = false
            playerView.contentMode = contentMode
            playerView.layer.contentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
            // v929 Phase B: leave the KSPlayer/Metal render layer on Core Animation's
            // normal presentation path. Forcing drawsAsynchronously adds an extra CA
            // scheduling lane that can become visible during fast pans and scene cuts.
            playerView.layer.drawsAsynchronously = false
            playerView.layer.contentsScale = UIScreen.main.scale
            playerView.isUserInteractionEnabled = false
            playerView.transform = .identity
            playerView.frame = view.bounds
            playerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            playerView.clipsToBounds = true
            // v924 Phase 1: attach the KSPlayer render host exactly once. Geometry and
            // hierarchy configuration are frozen inside KSContainerView after installation.
            view.installRenderViewOnce(playerView)
        }
        applyAudioMuteState(layer, muteAudio: muteAudio)
        coordinator.publishDiscoveredTracks(layer)
        if !coordinator.currentIsTrailerPlayback, !muteAudio, selectedAudioTrackIndex == nil {
            coordinator.didApplyEnglishAudioSelection = coordinator.applyEnglishAudioTrackIfAvailable(layer)
        }
        coordinator.applySelectedTracksIfNeeded(layer, force: true)
        if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url, deepNudge: true) } else { layer.pause() }
        // v1056 trailer full-audio guard: startup rescue is tied to the exact layer and
        // generation, never re-selects audio, never reapplies volume, and stops forever
        // once the real trailer clock advances. Old delayed work therefore cannot revive
        // a dismissed trailer or interrupt a newer/current audio pipeline.
        if coordinator.currentIsTrailerPlayback {
            let startupGeneration = coordinator.trailerStartupGeneration
            for delay in [0.15, 0.55, 1.10, 2.00] {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                    guard coordinator.playerLayer === layer,
                          coordinator.currentURL == url,
                          coordinator.trailerStartupGeneration == startupGeneration,
                          !coordinator.trailerPlaybackHasAdvanced else { return }
                    if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url, deepNudge: false) }
                }
            }
        }
    }

    private func isTrailerURL(_ url: URL) -> Bool {
        let lower = url.absoluteString.lowercased()
        return lower.contains("/trailers/") || lower.contains("trailer") || lower.contains("remux-cache") || lower.contains("kinocheck")
    }

    private func forceStartTrailerLayerIfNeeded(_ layer: KSPlayerLayer, url: URL, deepNudge: Bool = false) {
        let isTrailerPlayback = isTrailerURL(url) || routeHint.lowercased().contains("trailer")
        // Main VOD playback keeps its existing conservative play/pause behavior.
        guard isTrailerPlayback else { layer.play(); return }
        layer.play()
        guard deepNudge, let object = layer.player as? NSObject else { return }
        // `start` can rebuild/reset an already-created FFmpeg audio path. Limit the
        // one-time trailer startup nudge to idempotent play/resume selectors only.
        for name in ["play", "resume"] {
            let selector = NSSelectorFromString(name)
            if object.responds(to: selector) { _ = object.perform(selector) }
        }
    }

    private func applyDefaultTracks(_ layer: KSPlayerLayer) {
        // Retained for compatibility with older call sites. The active path now applies
        // English audio once from Coordinator after KSPlayer exposes real tracks.
    }

    static func dismantleUIView(_ anchor: PlaybackSurfaceAnchorView, coordinator: Coordinator) {
        let uiView = anchor.surface
        if coordinator.renderSurfaceRegistrationEnabled,
           let registration = coordinator.renderSurfaceRegistration {
            // Phase 10: an active PlaybackSession owns the surface and coordinator teardown.
            // A SwiftUI invalidation must not stop KSPlayer or destroy its layer tree.
            if PlaybackController.shared.sessionOwnsRenderSurface(registration) {
                return
            }
            PlaybackController.shared.unregisterRenderSurfaceCandidate(uiView, registration: registration)
            coordinator.renderSurfaceRegistration = nil
        }
        coordinator.playbackKitStopAndReleaseSurface()
        uiView.subviews.forEach { $0.removeFromSuperview() }
    }
}
#endif
