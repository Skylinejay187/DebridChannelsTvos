# Debrid Channels v1052 — Cast Presentation, Featured Cast Theme, and Clock Rail

Base: v1051  
Version: 1.0.580  
Build: 580

## Connected Media Information cast behavior

The connected popup now uses different cast presentations for movies and series:

- Movies display a full-width **Credits** row with up to six large circular cast portraits. Actor names and character/role labels remain underneath each portrait.
- Series preserve the existing compact landscape-style cast cards so the episode section retains its current vertical space and scrolling behavior.
- Empty cast states continue to show a bounded loading message rather than collapsing the popup.

## Premium Featured Cast panel

The VOD Featured Cast panel remains isolated on the right and now has a distinct themed identity:

- Artwork/genre-derived accent glow
- Larger cinematic portrait
- Gradient edge lighting and top accent line
- Stronger native tvOS typography
- Actor and role hierarchy
- Rotating cast counter and progress dots
- Smooth crossfade between cast members

No clock, playback status, or unrelated information is placed inside the panel.

## VOD current time placement

The current clock was removed from beneath the poster. It now appears as the final item in the left playback-information rail, immediately after the Source/format field such as `4K • HEVC/H.265 • MKV • HDR`.

## In-place upgrade preservation

The following remain unchanged from v1051:

- Main app bundle identifier: `com.channelsdebrid.tvos`
- Top Shelf bundle identifier: `com.channelsdebrid.tvos.TopShelf`
- Entitlements file and signing configuration paths
- UserDefaults keys and backup/restore keys
- Catalog caches and catalog recovery implementation
- PlaybackKit / KSPlayer
- Live TV, guide, Source Intelligence, trailers, previews, and backup systems

Installing v1052 over v1051 with the same certificate and provisioning profile is designed to preserve app data. The physical Apple TV installation remains the authoritative upgrade test.

## Local validation

- 39 Swift files passed `swiftc -frontend -parse`.
- Main and Top Shelf plists passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- App, Top Shelf, and XcodeGen versions match at 1.0.580 / 580.
- 30 targeted presentation, upgrade, and unchanged-file assertions passed.
- Critical catalog, playback, backup, preview, trailer, Source Intelligence, and entitlement files match v1051 byte-for-byte.
- GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate.
