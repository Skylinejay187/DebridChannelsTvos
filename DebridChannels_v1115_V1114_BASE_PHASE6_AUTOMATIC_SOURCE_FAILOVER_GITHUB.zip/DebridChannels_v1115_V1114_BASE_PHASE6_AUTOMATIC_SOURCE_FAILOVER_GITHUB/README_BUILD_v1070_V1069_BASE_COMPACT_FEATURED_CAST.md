# Debrid Channels v1070 — Compact Featured Cast

Base: v1069
Version: 1.0.598 (598)

## UI changes
- Renamed all active user-facing “Cast Wall” labels to “Featured Cast”.
- Reduced the media-information Featured Cast card from 400 pt to 348 pt wide.
- Reduced the VOD overlay Featured Cast panel from 520 pt to 430 pt wide.
- Rebalanced portrait sizes and typography so actor and character names can use two lines and remain readable.
- Preserved cast rotation, episode-specific cast resolution, images, focus behavior, and metadata logic.
