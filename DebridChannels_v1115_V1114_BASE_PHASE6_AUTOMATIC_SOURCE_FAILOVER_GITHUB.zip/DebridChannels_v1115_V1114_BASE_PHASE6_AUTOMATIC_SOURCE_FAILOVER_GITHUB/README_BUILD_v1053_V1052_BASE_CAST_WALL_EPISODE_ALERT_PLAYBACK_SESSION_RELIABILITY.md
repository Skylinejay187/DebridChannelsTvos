# Debrid Channels v1053 — Cast Wall, Episode Alert, and VOD Session Reliability

Base: v1052 (1.0.580 / 580)
Release: v1053 (1.0.581 / 581)

## Scope

This is a targeted publication-blocker correction. It does not redesign catalogs,
Live TV, the connected media-information popup, the VOD control drawer, the decoded
frame queue, audio/subtitle switching, trailers, previews, or backup/restore.

## 1. VOD Cast Wall restored

The active VOD overlay now uses the simpler proven `V841DynamicCastWall` presentation
shown in the supplied physical-device screenshots:

- `CAST WALL` heading
- one large portrait
- actor name and role
- cast position counter
- compact progress dots
- restrained transparent glass treatment
- six-second crossfade rotation

The v1052 premium Featured Cast component remains in source only for rollback/reference;
it is no longer called by the active VOD information stage.

## 2. Episode alert reliability

The alert scanner was depending primarily on configured Stremio metadata even though the
Follow Center UI described TVMaze-first verification. v1053 restores the intended order:

1. exact TVMaze lookup by TVDB or IMDb identity
2. exact title/year TVMaze search fallback
3. TVMaze episode list with verified air dates
4. existing Stremio/Cinemeta metadata fallback

Additional fixes:

- accepts `series`, `show`, `tv`, and episode-shaped identities
- repairs missing followed-show snapshots from loaded catalog rows
- canonicalizes legacy followed-show aliases during repair
- runs an immediate reliability catch-up after catalog load only when snapshots were
  repaired, no successful scan exists, or the previous scan failed
- preserves the normal persisted schedule when the scanner is already healthy
- keeps the pending-delivery queue and duplicate suppression unchanged

## 3. Repeated VOD link handoff / frozen clock

A departing KSPlayer surface could briefly overlap a newly opened VOD screen. Its delayed
clock callback or `onDisappear` teardown could mutate or stop the new shared PlaybackKit
session. The video engine could continue decoding, but the authoritative overlay clock was
then detached or frozen.

v1053 adds session ownership:

- every VOD screen stores its PlaybackKit session UUID
- KSPlayer clock callbacks are accepted only for that UUID
- stale callbacks from the previous source are ignored
- teardown stops only the session owned by the departing screen
- a delayed old `onDisappear` cannot stop a newer link
- authoritative overlay snapshots must match both session UUID and playback URL

This targets the reported sequence: play link A, exit/reopen, exit again, then play link B.

## Upgrade behavior

Bundle identifiers, entitlements, app group, signing configuration paths, and existing
UserDefaults keys remain unchanged. v1053 is designed to install over v1052 without deleting
the app when built and installed with the same signing path.

## Validation

- 39 Swift files passed `swiftc -frontend -parse`
- both plists passed `plutil -lint`
- `project.yml` passed YAML parsing
- app/extension/project versions match 1.0.581 (581)
- static assertions cover cast-wall routing, TVMaze fallback, snapshot repair,
  session-scoped clock ingestion, and owned teardown
- ZIP integrity and extraction round-trip are performed during packaging

GitHub Actions remains the authoritative full tvOS SDK compile/archive gate.
