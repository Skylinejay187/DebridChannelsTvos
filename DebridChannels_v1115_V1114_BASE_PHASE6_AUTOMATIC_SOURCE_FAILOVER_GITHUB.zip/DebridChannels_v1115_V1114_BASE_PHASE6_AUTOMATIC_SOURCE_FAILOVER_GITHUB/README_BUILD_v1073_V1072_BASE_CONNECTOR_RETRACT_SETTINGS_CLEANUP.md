# Debrid Channels v1073

Base: v1072 (locked base)
Version: 1.0.601
Build: 601

## Scope

- Keep the focused-card connector's fast 0.26-second opening draw.
- Keep the completed connector visible for seven seconds.
- Slow only the reverse trim to 1.18 seconds with a cinematic easing curve.
- Give Trailer and Find Links a subtle black/navy material with a restrained blue focus glow.
- Add a 15-second Expanded Shelf Auto-Hide choice and preserve it through profile backup/restore.
- Remove obsolete settings UI for:
  - Show Media Info Portrait Poster
  - Top Bar Media Info Layout
  - Media Info Top Bar Transparency
  - Live TV default to AVPlayer
  - Match Live TV Display
  - Internal-player Apple TV Match Content reminder messages
- Lock the legacy top media-information presentation to its established portrait/centered/solid values.
- Retire the removed Live TV AVPlayer-default and Live TV display-match behavior from playback.

## Preserved

- v1072 Source Intelligence provider mixing, ranking, paging, controls, and playback handoff.
- Embedded lower-half Source Intelligence layout and neutral confirmation glass.
- Built-in trailer resolver and full-audio reliability path.
- Focused-card previews, media popup, advisory, Featured Cast, catalogs, Live TV, and VOD playback logic.
