# v1037 Known Limitations and Required Device Verification

- Full Apple tvOS SDK compilation, signing, and App Store validation cannot run in the Linux packaging environment.
- Physical Apple TV testing is required for HDR/Dolby Vision presentation, Match Content behavior, remote focus geometry, Top Shelf, and long-session decoder behavior.
- The main app intentionally permits user-configured HTTP/local-network media sources for IPTV, XMLTV, M3U, DVR, and tuner compatibility. The Top Shelf extension remains HTTPS-only.
- Credentials and private source URLs intentionally remain local and must be re-entered on a second Apple TV after profile restore.
- The VOD Year and Rating badges depend on metadata availability; unavailable values are deliberately omitted rather than fabricated.
- Publication should wait until the GitHub Release build and the physical-device checklist pass.
