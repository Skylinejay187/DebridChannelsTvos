# Debrid Channels v1048 — Phase 12A

Base: v1047
Version: 1.0.576
Build: 576

## Purpose

Make the built-in All-in-One catalog remain responsive and visible indefinitely while it is enabled, without removing or changing the existing All-in-One toggle or the person's ability to use personal catalogs.

## Toggle behavior remains unchanged

- All-in-One **On**: the hidden built-in catalog is the authoritative browsing catalog.
- All-in-One **Off**: built-in rows are removed from browsing and the person's saved manifests/Cinemeta behavior remains active.
- The app does not force-enable the built-in catalog.
- Personal manifests remain saved while All-in-One is on and become browseable again when it is turned off.
- Hidden-row choices and custom row order remain applied locally.

## Phase 12A catalog permanence

- Cold launch selects the fullest valid current or rollback protected snapshot instead of blindly preferring the current file.
- If the rollback snapshot is fuller, it atomically heals the current snapshot before the next launch.
- The protected snapshot, compact launch cache, and currently visible official rows form a layered recovery baseline.
- Cached rows are republished synchronously before a foreground/network refresh begins.
- Empty, failed, canceled, malformed, or partial responses cannot clear healthy rows.
- A fresh response cannot shrink the durable row set or severely truncate an existing row.
- The first complete official snapshot requires the published 83-row set.
- Empty refresh output no longer erases the compact launch cache.
- A direct personal-manifest test cannot replace the enabled built-in catalog.
- The legacy cache-reset action preserves the protected official snapshot while All-in-One is enabled.

## Persistent background recovery

- A failed official refresh is not recorded as a successful completion merely because cached rows were republished.
- Recovery retries use bounded backoff: 4, 10, 20, 45, 90, 180, then 300 seconds.
- Five minutes is the continuing maximum delay; retrying does not stop until a complete fresh set is verified.
- Retry work pauses while the app is inactive or VOD-exclusive playback is active.
- Foreground activation immediately republishes the durable catalog, then resumes recovery.
- Successful fresh publication cancels the retry and resets the backoff.

## Performance behavior

The visible catalog no longer waits on the network. Existing verified rows are usable immediately while manifest, batch-row, and row-endpoint work happens asynchronously. The network refresh never replaces the current view until the candidate has passed structural, poster, row-count, item-count, canonical identity, and non-regression checks.

## Preserved

- All-in-One toggle, personal catalogs, Cinemeta fallback behavior when All-in-One is off, row customization, hidden-row Search, and catalog ordering.
- Connected Media Information popup and transparent/artwork setting.
- 30-second focused previews.
- VOD Control Drawer and v1047 passive scrub guard.
- Full-profile backup/restore including Live TV, M3U/XMLTV, Source Intelligence, provider credentials, and API keys.
- KSPlayer, PlaybackKit, VOD queue 24/24/16, Live TV, guide, trailers, audio, subtitles, cast hydration, Source Intelligence, Favorites, alerts, and playback state.

## Validation

- Every Swift source parsed with `swiftc -frontend -parse`.
- Main app and Top Shelf versions/builds match project.yml.
- Both property lists and project.yml parsed successfully.
- Static Phase 12A assertions verify the toggle remains, durable rows cannot regress, empty refreshes cannot erase caches, retries continue with bounded backoff, and personal catalogs remain available when the toggle is off.
- Critical playback, VOD UI, backup, preview, artwork, trailer, and service files match v1047 byte-for-byte.

GitHub Actions/Xcode remains the authoritative Apple tvOS SDK compile and archive test.
