# Debrid Channels v1054 — VOD Handoff Ownership + Connected Popup Geometry

Base: v1053 (1.0.581 / 581)
Release: v1054 (1.0.582 / 582)

## Why v1053 did not fully fix repeated VOD link handoff

v1053 scoped only the KSPlayer clock callback and final `stop(sessionID:)` call. Several
shared PlaybackKit paths were still process-global:

- the pending UIKit render-surface candidate had no session identity;
- `PlaybackController.play(_:)` could adopt the departing link's surface while opening the
  new link;
- overlay visibility, loading, first-frame, and render-host lifecycle mutations were not
  session-scoped;
- an old screen could receive the new session's published snapshot because the local bridge
  accepted any non-nil session;
- SwiftUI keyed the full-screen player only by URL, so reopening the exact same source could
  reuse a departing player identity;
- the delayed dismissal called `closePlayer()` without proving it still owned the active
  playback launch.

Those remaining paths explain why link A could still disturb link B even though stale clock
updates and stale `stop(sessionID:)` calls were rejected.

## v1054 VOD handoff correction

v1054 makes the playback launch UUID authoritative from Source Intelligence through SwiftUI,
PlaybackKit, KSPlayer's UIKit surface, overlay snapshots, and teardown:

1. `CatalogStore` creates a fresh `playbackPresentationID` before every selected-link launch
   and before every automatic fallback handoff.
2. The full-screen player identity includes that UUID, so reopening the same URL always creates
   a fresh player screen.
3. `PlaybackRequest` uses the same UUID instead of allocating a second unrelated identity.
4. The KSPlayer render surface registers with the exact playback UUID. A pending surface can
   only be adopted by the matching session.
5. PlaybackKit preserves only the incoming session's pending surface when replacing an active
   session; stale link-A candidates are cleared.
6. Overlay visibility, loading, first-frame, presentation dismissal, and render-host lifecycle
   commands are all guarded by session UUID.
7. The overlay accepts snapshots only when session UUID, launch UUID, and playback URL match.
8. Delayed close requests carry both the launch UUID and URL and are ignored if a newer source is active.

This targets both:

- play link A, exit, reopen the same link;
- play link A, exit, then play link B or trigger an automatic fallback.

## Connected media popup line correction

The actual tvOS layout source is adjusted without replacing the UI or creating a mockup:

- hero logo, metadata, and synopsis are lifted slightly;
- the connector starts near the focused card's upper-right edge instead of its center;
- the curve rises immediately into the empty corridor above the poster rail;
- it no longer sweeps across the next poster;
- the popup endpoint remains below the hero text and above the poster row.

## Preserved

- v1053 TVMaze-first episode alert correction and snapshot repair
- v1053 classic VOD Cast Wall
- KSPlayer decode/cadence/queue/first-frame code
- VOD controls, seeking, resume, audio/subtitle switching
- Source Intelligence result ordering and provider filtering
- trailers, previews, Live TV, guide, settings, catalogs, backup/restore

## Validation

- 39 Swift files passed `swiftc -frontend -parse`
- both plists passed `plutil -lint`
- `project.yml` passed YAML parsing
- app/extension/project versions match 1.0.582 (582)
- static assertions cover launch identity, scoped presentation lifecycle, surface ownership,
  snapshot filtering, guarded delayed close, and connector geometry

GitHub Actions remains the authoritative full tvOS SDK compile/archive gate.
