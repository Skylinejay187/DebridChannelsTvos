# Debrid Channels v1007

Base: v1006.

## Changes

- 4K decoded-frame queue changed from 24 to 25.
- 1080p remains 24; lower resolutions remain 16.
- The official All-in-One catalog is now a hidden built-in app service.
- The built-in manifest URL is never stored in or rendered with the user's saved JSON catalog list.
- The All-in-One Catalogs toggle is the only user-facing control for the official catalog.
- Personal catalog URLs remain visible, saved, reorderable, and usable when All-in-One is off.
- Legacy local/public official manifest URLs are removed from visible restored profile data.
- The current hidden endpoint remains the in-home NAS URL for local testing; the future public HTTPS endpoint will replace only the private constant.

## Preserved

- Phase 2.8/2.9 catalog protocol and text-only row headers.
- Cinemeta invisible metadata/artwork fallback.
- Poster guarantee behavior.
- Playback cadence, subtitle renderer, trailers, Live TV, Source Intelligence, VOD overlay, and catalog lifecycle recovery.
