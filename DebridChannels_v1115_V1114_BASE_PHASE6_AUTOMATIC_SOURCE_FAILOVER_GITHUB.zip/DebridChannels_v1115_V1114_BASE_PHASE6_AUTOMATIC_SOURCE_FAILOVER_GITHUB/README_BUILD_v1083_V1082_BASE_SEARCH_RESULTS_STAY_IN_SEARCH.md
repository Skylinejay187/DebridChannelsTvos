# Debrid Channels v1083 — Search Results Stay in Search

Base: v1082 clean rollback line.

- Search-origin media details now open over the existing Search results instead of dismissing Search and exposing Home/main catalogs.
- Closing a media-information popup returns directly to the same Search query and focused result.
- Returning from VOD playback restores the Search query and reruns the same unified provider search inside Search.
- Explicitly backing out of Search clears its temporary query/focus state and returns to normal navigation.
- Existing Search providers, result layout, hydration, Source Intelligence, trailers, full-width rows, Guide startup, and playback logic are unchanged.
- No Movie Mode code was reintroduced.
