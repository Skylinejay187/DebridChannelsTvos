# Debrid Channels v1087

Base: v1086
Version: 1.0.615 (615)

## Purpose

Repair the frozen VOD clock seen after selecting another source for a television episode, then harden adjacent playback handoff paths without changing the working trailer resolver, episode-alert behavior, catalog UI, or KSPlayer decode/cadence profile.

## Root cause

The KSPlayer surface could retain clock-gate state across a URL/reload generation, and the gate depended too heavily on a second `readyToPlay` callback. KSPNUVIO can resume decoded playback after a source replacement or decoder/track flush without emitting that second ready callback. The video then played while the overlay clock remained frozen.

Queued callbacks from a stopped source could also arrive after the replacement source became active. Without an active-layer/session check, the departing source could release, overwrite, or restart state owned by the new source.

## v1087 corrections

- Fully resets the PlaybackKit clock gate for every source/reload generation.
- Accepts both `readyToPlay` and `bufferFinished` as legitimate clock-release states.
- Uses sustained advancement of the real KSPlayer clock, preferably with rendered-video evidence, to recover when KSPNUVIO omits a second ready callback.
- Makes source identity include the immutable playback-presentation UUID, not only URL equality.
- Rejects state, time, finish, track, seek-completion, metadata, AVPlayer, and delayed-task callbacks that no longer own the active source/session.
- Prevents a late seek completion from restarting a stopped previous source.
- Adds a bounded recovery when an explicit audio-track decoder flush completes internally but omits its completion callback.
- Prevents duplicate English-audio and duplicate embedded/external subtitle selections from repeatedly flushing the active decoder.
- Rejects NaN, infinite, zero, and negative duration values before they enter the VOD timeline.
- Prevents a departing VOD screen from overwriting resume progress after a newer source owns playback.
- Stops the old helper clock after KSPlayer first-frame startup is resolved; PlaybackKit remains the sole KSPlayer VOD timeline authority.

## Preserved

- v1084 proven built-in trailer loading path and trailer audio isolation.
- v1086 always-on episode-alert scans during VOD.
- Full-width catalog rows.
- Launch App in Guide.
- Search results remain in Search.
- Single Play Source confirmation chip.
- Existing Source Intelligence, provider mixing, Live TV, subtitles, focus, and production UI.
- Existing KSPNUVIO fork, hardware decode, synchronous VOD presentation/cadence, buffer, probe, and display-match policy.
- No Movie Mode code.

## Validation boundary

All project Swift sources are syntax parsed locally. Plists, project versions, backend Python, source invariants, and the final ZIP are validated. GitHub Actions/Xcode and physical Apple TV playback remain authoritative for full tvOS type checking and device behavior.
