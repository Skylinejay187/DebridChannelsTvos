# Debrid Channels v1055 — Catalog Completeness Recovery + Manual Debrid Channels Reload

Base: v1054 (1.0.582 / 582)
Release: v1055 (1.0.583 / 583)

## Confirmed row-loading failure

The app intentionally keeps a compact eight-row `UserDefaults` cache for fast launch. During
startup, those eight rows were also captured as the current built-in row descriptor set.
The old recovery test compared the visible rows only against that descriptor set, so:

- compact cache rows visible: 8
- descriptor rows known at that moment: 8
- old completeness result: 8 of 8, incorrectly treated as complete

That explains why Home could remain at eight rows until the existing **Load All Catalogs**
button was pressed manually. The network loader itself could still retrieve the complete
catalog; the automatic recovery detector had accepted the compact cache as the full catalog.

## v1055 correction

1. Catalog completeness now uses the known complete publication target of 83 rows as its floor,
   rather than treating the compact descriptor count as authoritative.
2. Valid hidden-row customization is subtracted after the full descriptor identities are known,
   so intentionally hidden rows do not create permanent reload loops.
3. RootView starts a lightweight completeness watchdog after launch and whenever the scene or
   VOD session returns to the catalog UI.
4. The watchdog checks every 12 seconds, but does nothing while a catalog load, backoff retry,
   inactive scene, or VOD-exclusive playback session already owns the work.
5. A row-count publication also requests an immediate completeness check. This catches the exact
   eight-row launch-cache state without waiting for user scrolling.
6. In Settings > Streaming Catalogs, a dedicated **Reload Debrid Channels Catalogs** button now
   performs an immediate official-catalog refresh, separately from personal JSON addons.
7. The settings panel reports the visible Debrid Channels row count against the expected count.
8. Manual reload cancels a delayed official-catalog retry and forces a fresh request while keeping
   the fullest existing rows visible until the replacement is verified.

## Preserved

- v1054 VOD playback-session/render-surface ownership guards
- v1054 connector-line and hero-information geometry adjustment
- v1053 TVMaze-first episode alert verification and snapshot repair
- protected current/previous official catalog snapshots
- provisional snapshot and non-regression behavior
- catalog row customization and hidden-row ordering
- personal Stremio JSON catalogs
- KSPlayer, VOD controls, Live TV, trailers, Source Intelligence, backup/restore

## Physical-device checks

1. Launch with the compact cache present and verify the app automatically progresses beyond eight rows.
2. Leave the app on Home/Movies/Shows for at least 15 seconds and confirm no manual scrolling is needed.
3. Open Settings > Streaming Catalogs and verify the dedicated Debrid Channels reload button is present.
4. Press it and confirm the status/progress text updates while existing rows remain visible.
5. Hide several official rows through customization and confirm the watchdog does not restore hidden rows.
6. Start and close VOD playback while catalogs are incomplete; confirm recovery resumes only after playback closes.

## Validation

- all 39 Swift source files pass `swiftc -parse`
- app and Top Shelf plists parse successfully
- `project.yml` parses as YAML
- app, extension, and project versions match 1.0.583 (583)
- static assertions cover the 83-row floor, automatic watchdog, row-count trigger,
  dedicated manual reload button, and forced official refresh

GitHub Actions remains the authoritative tvOS SDK compile/archive gate.
