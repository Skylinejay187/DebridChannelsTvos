# Debrid Channels v1096 — Phase 3 Alternate Audio Bridge

- Base: v1095 only
- Marketing version: 1.0.624
- Build: 624
- Scope: Phase 3 bridge preparation only

## What changed

Phase 2 discovery results can now be sent to `POST /api/alternate-audio/bridge`. The included backend runtime re-probes the current video source and selected English-audio candidate, verifies exact movie or season/episode ownership, validates the selected real stream index, and creates one temporary fMP4 HLS session.

The VOD Audio panel now includes **Prepare Audio Bridge** after a compatible discovery candidate is selected. Preparation is explicit and remains behind the versioned Alternate Audio Bridge feature flag, which defaults to Off. Pressing the button enables only the master/discovery/bridge flags for this experiment.

## Bridge media policy

- Video always comes from the currently selected high-quality source.
- Video is always stream-copied (`-c:v copy`).
- Compatible AAC, AC3, and EAC3 audio is stream-copied when no timing correction is required.
- Audio alone is re-encoded to AAC when offset correction, drift correction, or HLS codec compatibility requires it.
- Every bridge receives a unique UUID and a short-lived HLS URL.
- The untouched original playback URL is returned and retained for immediate Phase 4 restoration.
- `Possible Match` and `Incompatible` candidates cannot create a bridge.

## Playback safety

Phase 3 does **not** hand the bridge URL to KSPlayer, does not reload the VOD surface, and does not change timestamp, play/pause state, subtitles, or the active source. All engine-facing external-audio inputs are forced to `nil`/`0`. Phase 4 will own the generation-safe source handoff.

## Backend installation

Install both backend directories on the Debrid Channels backend:

- `BackendAlternateAudioRuntime` from Phase 2
- `BackendAlternateAudioBridgeRuntime` from Phase 3

Register `create_fastapi_router()` from the Phase 3 runtime on the authenticated FastAPI application. The backend host requires `ffprobe` and `ffmpeg` on `PATH`. See `BackendAlternateAudioBridgeRuntime/README_PHASE3_ALTERNATE_AUDIO_BRIDGE.md`.

## Protected v1095 behavior

- Tapframe KSPNUVIO remains unchanged.
- PlaybackKit KSPlayer surface remains byte-identical to v1095.
- v1073 eager trailer runtime and trailer manager remain byte-identical to v1095.
- Phase 0 Stable Feature Gate manager remains byte-identical to v1095.
- v1094 Gracenote persistence and slow catalog pulse remain unchanged.
- v1093 premium Live TV UI remains unchanged.
- No Movie Mode code was added.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Backend bridge endpoint testing and physical Apple TV testing are required before Phase 4.
