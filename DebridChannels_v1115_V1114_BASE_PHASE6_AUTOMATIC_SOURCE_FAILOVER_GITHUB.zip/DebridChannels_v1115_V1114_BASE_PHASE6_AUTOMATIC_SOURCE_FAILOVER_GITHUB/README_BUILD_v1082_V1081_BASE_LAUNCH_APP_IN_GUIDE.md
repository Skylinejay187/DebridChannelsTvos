# Debrid Channels v1082 — Launch App in Guide

Base: v1081 clean rollback line.

- Adds Settings → Live TV → Launch App in Guide.
- Enabling shows a one-chip confirmation explaining that the app must be closed and reopened.
- A true cold launch opens the existing full Live TV guide once; scene resume, tab changes, playback return, and Settings return do not force it open again.
- Restores the last selected Live TV channel when available, otherwise the first available channel.
- Left from the guide still returns to the unchanged Live TV grid.
- Preference participates in profile backup/restore.
- No Movie Mode code was reintroduced.
