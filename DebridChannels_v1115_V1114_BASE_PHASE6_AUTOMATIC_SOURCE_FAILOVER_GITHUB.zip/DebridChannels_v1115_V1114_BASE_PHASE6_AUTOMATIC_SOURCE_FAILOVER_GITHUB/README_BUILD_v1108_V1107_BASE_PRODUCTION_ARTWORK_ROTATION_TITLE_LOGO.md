# Debrid Channels tvOS/iOS v1108

## Base

Built only from v1107 (1.0.635 / build 635).

## Version

- Marketing version: 1.0.636
- Build: 636
- Backend update: not required
- Continue using backend v669

## Production & Ratings artwork header

- The landscape artwork now fills the complete outlined header edge-to-edge using aspect-fill cropping without stretching.
- The plain movie/show text title was removed from the artwork header.
- A real transparent title logo/clearlogo is overlaid when available from the existing media item or TMDB title images.
- The primary deduplicated studio/network logo remains available inside the header.
- The rest of the panel retains the v1107 unified information layout and real-data-only behavior.

## Seven-second artwork rotation

- The existing title landscape image is placed first in the rotation pool.
- TMDB backdrops and suitable title artwork are retrieved in the same post-first-frame Production metadata request; no extra startup request was added.
- English and language-neutral artwork are accepted.
- Landscape images must have a valid path, landscape aspect ratio, and usable resolution.
- Duplicate, placeholder, default, missing, malformed, and repeated artwork is excluded.
- The visible artwork changes every exactly 7.0 seconds with a restrained crossfade.
- Only the current image is mounted; the full artwork list is not rendered simultaneously.
- The active artwork index is owned by VODPlayerScreen, so hiding and reopening the overlay resumes at the same image instead of restarting at the first image.
- The timer exists only while the Production & Ratings panel is mounted, which remains gated behind confirmed first-frame playback.

## Playback protection

- Production metadata remains blocked until first frame is confirmed and the existing 1.5-second quiet period completes.
- Catalog/Search source resolution, Source Intelligence, KSPlayer, trailers, Live TV, Alternate Audio, Catalog Health, Favorites, episode alerts, and stable focus behavior were not changed.

## Validation

- All Swift files passed syntax parsing.
- VODProductionMetadata.swift passed standalone Swift type-checking.
- Both plists passed property-list validation.
- Project and plist versions match 1.0.636 / 636.
- The VOD artwork-rotation source contract passed.
- Nine protected source/playback files are byte-identical to v1107.
- Complete baseline hash comparison and final archive extraction verification are provided separately.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before v1108 becomes the active base.
