# Debrid Channels tvOS/iOS v1115

## Phase 6 — Automatic Source Failover

- Base: v1114 only
- Marketing version: 1.0.643
- Build: 643
- Backend: continue using v669; no backend update is required for Phase 6

## Behavior

Automatic recovery uses the selected Source Intelligence link followed by the next already-ranked direct links retained by the exact playback session.

A source may change automatically only while the playback presentation has not produced a genuine first frame/player-clock signal. The older bounded loading-cover safety release does not count as stable playback.

When a startup source fails or does not reach a stable first frame within 12 seconds, the app displays:

`Source unavailable — trying the next ranked link`

The replacement source receives a new immutable playback-presentation UUID. The exact movie/episode item remains unchanged, and the highest valid saved/current resume position is queued on the replacement player.

After genuine playback has begun, automatic source switching is disabled. A later failure is shown to the user rather than silently changing the stream.

Any prepared or active Alternate Audio backend work owned by the failed video source is cancelled before the source changes. The replacement video remains the new stable source for any later manual Alternate Audio preparation.

## Protected systems

The following remained byte-identical to v1114:

- Tapframe KSPNUVIO PlaybackKit surface
- Source Intelligence ranking manager
- Alternate Audio discovery, bridge, and cancellation clients
- Trailer service
- Live TV Gracenote cache
- Production & Ratings metadata runtime
- Playback resume cache
- Stable feature-gate manager

## Required testing

1. Select a title with at least two direct ranked links.
2. Make the first URL fail before first frame and confirm the exact notice appears.
3. Confirm the next ranked source opens and preserves the title/episode and resume position.
4. Confirm Alternate Audio work is cancelled when the video source changes.
5. After stable playback begins, interrupt the source and confirm the app does not silently switch.
6. Confirm Live TV never uses this VOD failover path.

GitHub Actions remains the authoritative Xcode/tvOS compiler test. Physical Apple TV testing is required before starting Phase 7.
