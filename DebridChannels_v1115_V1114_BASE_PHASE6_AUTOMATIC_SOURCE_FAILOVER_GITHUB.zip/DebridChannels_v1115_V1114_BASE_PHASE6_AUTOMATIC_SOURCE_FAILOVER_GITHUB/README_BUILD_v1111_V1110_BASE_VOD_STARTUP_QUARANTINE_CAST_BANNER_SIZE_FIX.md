# Debrid Channels v1111 — VOD Startup Quarantine / Cast & Banner Correction

Base: v1110 only
Marketing version: 1.0.639
Build: 639
Backend update: No. Continue using backend v669.

## Root-cause finding

The source resolver and KSPlayer opening functions remain byte-identical to the v1098 playback reference. Alternate Audio does not run automatically when a title starts. The regression was the later VOD review lookup, which was launched directly from the player `onAppear` immediately after `setupPlayer()`. That lookup can resolve IMDb identity and perform OMDb requests while KSPlayer is opening the selected media URL.

v1111 removes all review/production artwork work from the source-opening window. Review data now requires a confirmed first frame, waits 2.4 seconds, runs at background priority, and is deduplicated for the title. Production metadata remains first-frame gated.

## UI corrections

- Removes `1/10`, `2/10`, etc. from both compact and full-poster cast modes.
- Keeps cast name and role only.
- Expands Production & Ratings to a 440-point banner width.
- Preserves each official artwork asset's source aspect ratio so it fills the width while remaining fully visible and uncropped.
- Keeps exact seven-second artwork rotation and the language-neutral filter for avoiding countdown/pre-release copy.

## Protected systems

No changes were made to KSPlayer, source ranking/resolution, Source Intelligence, automatic fallback, Alternate Audio clients, trailers, Live TV, Catalog Health, Favorites, Search, or episode alerts.

GitHub Actions remains the authoritative tvOS/Xcode compilation test. Physical Apple TV playback testing remains required.
