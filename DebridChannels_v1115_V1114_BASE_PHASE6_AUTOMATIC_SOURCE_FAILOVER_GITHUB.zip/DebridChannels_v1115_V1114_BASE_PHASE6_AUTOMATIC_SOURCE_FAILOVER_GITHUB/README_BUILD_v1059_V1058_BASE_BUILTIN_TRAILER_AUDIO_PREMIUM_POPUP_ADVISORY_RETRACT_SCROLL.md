# Debrid Channels tvOS v1059

Release: v1059 (1.0.587 / 587)  
Base: v1058

## Scope

This release changes the actual tvOS source. It does not include or rely on a visual mockup.

## Built-in trailers only

- Removed the external YouTube trailer action, chip, launcher helpers, URL schemes, settings state, and legacy focus nodes.
- The existing **Trailer** action now has one destination: the built-in Debrid Channels trailer popup.
- Direct web/watch pages remain rejected by the internal media URL guard; the backend must return a direct MP4/HLS or finalized remux URL.

## Built-in trailer full-audio reliability

The prior guard stopped delayed player commands, but a backend result could still be opened before its muxed audio duration was proven to reach the video endpoint.

v1059 adds the following gates:

- Invalidates the old trailer URL cache with a new duration-verified cache namespace.
- Waits for remux-cache `Content-Length` to settle before opening.
- Uses `AVURLAsset` to require both video and audio tracks.
- For finite assets, rejects playback when the audio track ends more than 1.25 seconds before the video/asset duration.
- Requests complete, muxed, audio-duration-matched results from the backend.
- Disables KSPlayer's early `isSecondOpen` trailer path so the finalized mux exposes stable audio/video tracks before the session is considered open.
- Keeps delayed trailer startup work session-scoped and prevents audio-track reselection after playback begins.
- Updates the included backend helper with an `apad` + video-duration FFmpeg remux contract. It explicitly avoids `-shortest`, which can reproduce early audio/video termination.

## Original connector restored with reverse retraction

- Restores the thin illuminated v1056 connector appearance and original single-sweep curvature.
- The connector starts at the focused poster's upper-right edge.
- Its first control point lifts into the open corridor so the next poster is not crossed.
- The line holds for three seconds.
- It then animates the same trim path from 1 back to 0, physically retracting into the focused poster.
- Opening and closing use the same 0.72-second ease-in-out timing.
- The media-information popup remains visible after the connector retracts.

## Premium media-information popup and advisory

- Rebuilds the popup as a smoked-glass media profile with an editorial title treatment, Avenir Next typography, cleaner metric hierarchy, refined borders, and brand accenting.
- Keeps actions, favorites/following, cast/credits, seasons, episodes, and source intelligence behavior.
- Adds a clean in-panel **Content Advisory** strip.
- Advisory uses the official US-first TMDB movie certification or TV content rating when available.
- It does not invent content descriptors from the synopsis. When the provider has no certification, it clearly shows that advisory data is unavailable.
- The existing advisory setting now controls both the media bar and the popup advisory.

## Catalog scrolling performance

No catalog, artwork, preview, focus, popup, or playback feature was removed.

- Creates a stable rendered-row snapshot only when `CatalogStore` publishes a real row revision, instead of mapping/filtering all 70+ rows during every Siri Remote focus update.
- Keeps row/item focus indexes clamped and preserved across catalog refreshes.
- Avoids redundant focused-preview state publications when no preview is active.
- Keeps stale hero metadata hidden by identity while avoiding extra state writes on every card move.
- Increases metadata dwell slightly so fast DPAD traversal does not create unnecessary actor/network churn.
- Moves per-card artwork-provider console logging behind `DEBUG`.
- Debounces incomplete-row refresh requests to reduce network/task churn while scrolling.
- Limits only offscreen preview-card construction; every catalog item remains reachable.

## Versions

- Main app: 1.0.587 (587)
- Top Shelf extension: 1.0.587 (587)
- XcodeGen project: 1.0.587 (587)

## Validation boundary

All Swift files pass source parsing, the backend helper passes Python bytecode compilation, both plists and `project.yml` parse, and the release archive is verified after round-trip extraction. GitHub Actions/Xcode remains the authoritative tvOS type-check, compile, link, and archive gate. Apple TV testing remains required to confirm the specific backend trailer source now returns full-duration audio.
