# Debrid Channels tvOS v1061

Release: v1061 (1.0.589 / 589)  
Base: v1060

## Implemented

### Faster connected-popup presentation
- Preserves the accepted original connector curve, color treatment, poster anchor, and collision-safe route.
- Starts after a 0.055-second guarded mount preflight instead of 0.18 seconds.
- Draws/retracts over 0.26 seconds instead of 0.78 seconds, using the same path and timing curve in reverse.
- Reveals the media popup only after the connector reaches its landing point.
- Keeps the completed connector visible for seven seconds before retracting.

### Dissolving lower glass edge
- Keeps the transparent premium glass, top edge, side edges, and left accent.
- Applies a vertical alpha dissolve only to the glass tint, border, and shadow.
- Removes the hard bottom outline over catalog/Live TV cards.
- Leaves popup text, controls, advisory, credits, seasons, and episodes fully visible.

### Previous-title/logo flash removal
- Adds a store-owned detail presentation anchor and monotonically increasing presentation revision.
- Pins the exact clicked media identity through the one-run-loop popup mount gap and Back focus restoration.
- Keys hero state by canonical media identity/artwork rather than transient row focus.
- Gives every popup opening a fresh SwiftUI identity, even when reopening the same title.
- Disables cross-identity hero animation while the detail handoff is active.
- Restores the exact originating row first, before global duplicate-title searches.
- Releases the anchor only after the visible row/card canonically matches the closing detail.
- Consumes old restore fields after successful focus recovery so later catalog refreshes cannot snap back to an old row.

## Preserved
- v1060 full long-row catalog pagination and manual force reload.
- Transparent connected media popup layout and advisory.
- Built-in trailer path and trailer audio protections.
- Seven-second connector hold.
- VOD handoff, episode-alert, Live TV, catalog, focus, and playback systems.

## Validation completed in this package
- All 39 Swift source files passed `swiftc -frontend -parse`.
- App and Top Shelf plists parsed and report 1.0.589 (589).
- `project.yml` parsed and reports 1.0.589 (589) for both targets.
- Backend trailer helper passed Python bytecode compilation.
- Final ZIP extraction and file hash comparison are recorded in `VALIDATION_RESULTS_v1061.json`.

GitHub Actions remains the authoritative Xcode/tvOS type-check, link, archive, and signing validation.
