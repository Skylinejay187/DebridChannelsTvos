# Debrid Channels v1046

## Base

- Base release: v1045
- Marketing version: 1.0.574
- Build: 574

## Purpose

v1046 makes the connected Media Information popup background reversible through one tvOS setting.

## New setting

Settings → Appearance → Connected Popup Background Artwork

- Off (default): the connected popup remains fully transparent, preserving the visible Home/Movies/Shows/Live TV surface behind its information.
- On: restores the selected title's alternate landscape artwork inside the popup with a dark readability gradient, subtle material treatment, border, and shadow.

The setting changes only the popup background presentation. It does not change the small portrait poster in the information bar, selected-card focus latch, connector line, exact selected-item hero binding, action buttons, cast, episode navigation, Source Intelligence, or playback.

## Artwork mode details

- Uses the selected item's non-empty landscape artwork first.
- Falls back to the portrait poster when no landscape artwork exists.
- Keeps the selected catalog card and connector visible.
- Uses a restrained right-side dim gradient rather than hiding the whole catalog.
- Preserves popup dimensions, content positions, and focus routes.

## Transparent mode details

- Remains the default for new and upgraded installs with no saved preference.
- Uses no popup backdrop, material, border, or shadow.
- Keeps catalog or Live TV cards visible behind all popup content.

## Backup and restore

`connectedMediaPopupArtworkEnabled` is included in the full-profile backup payload, restore assignment, and explicit release-security allowlist. The export and restore allowlists remain identical at 83 settings.

## Preserved from v1045

- Exact clicked-card visual focus remains latched while popup controls own tvOS focus.
- Left hero remains bound to the exact clicked movie/show.
- Episode rail remains a two-card visible/navigation window so focused episodes stay visible.
- Portrait poster remains in the top production-information bar.
- Connected line, popup actions, cast, favorites, alerts, trailers, and Source Intelligence remain.
- Focused-card previews remain muted, no-loop, and 30 seconds.
- Full Live TV, M3U/XMLTV, Xtream, debrid, metadata API-key, and Source Intelligence profile backup remains.

## Explicitly untouched

- PlaybackKit and KSPlayer
- VOD decoded queue and cadence behavior
- Live TV playback, guide, and first-frame behavior
- VOD scrubber and Control Drawer
- Audio and subtitle switching
- Catalog recovery and canonical identity
- Cast hydration
- Trailer and preview engines

## Local validation

- 39 Swift files passed `swiftc -frontend -parse`.
- `ReleaseCandidateSecurityManager.swift` passed standalone Swift type checking.
- Main app and Top Shelf plists parsed and match version/build 1.0.574 (574).
- `project.yml` parsed successfully and contains matching app/extension versions.
- 35 targeted v1046 assertions passed.
- All 83 exported backup settings exactly match the 83-key restore allowlist.
- Eight critical playback/catalog/service files are byte-for-byte identical to v1045.

GitHub Actions is the authoritative Apple tvOS SDK compile/archive test.
