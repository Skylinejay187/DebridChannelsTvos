# Debrid Channels v1038 — Active VOD Metadata Stage Correction

Base: v1037
Version: 1.0.566
Build: 566

## Reason for correction

The v1037 archive contained VOD metadata styling changes, but the physical Apple TV presentation appeared unchanged. v1038 removes ambiguity by replacing the active non-Live VOD call site with a newly named `V1038VODInformationStage` and gives the year/rating presentation a stronger, unmistakable visual treatment.

## Changes

- The active VOD overlay now calls `V1038VODInformationStage` directly.
- The previous legacy stage name is no longer referenced by the active VOD path.
- Year uses a clearly bordered genre-accented glass badge.
- Rating uses a high-contrast gold star badge.
- Genre text is uppercase, tracked, and rendered with cinematic serif typography.
- Synopsis typography is larger, serif, higher contrast, and more widely spaced.
- Duplicate plain rating metadata remains removed.

## Preserved

No changes were made to PlaybackKit, KSPlayer, decoded-frame queues, cadence, Live TV, seek/scrubber behavior, audio, subtitles, trailers, focused previews, Source Intelligence, catalog reliability, Search, or security systems.

## Validation

- All Swift sources passed frontend parsing.
- Main app and Top Shelf versions match 1.0.566 (566).
- Plists and project YAML parsed successfully.
- Active VOD call-site assertions passed.
- PlaybackKit files are byte-for-byte unchanged from v1037.
- ZIP integrity and extraction round-trip validation passed.
