# Debrid Channels v1041 — Phase 11 Active VOD Apple TV Information + Backup Reliability

## Release identity

- Base: v1040
- Marketing version: 1.0.569
- Build: 569
- Target: tvOS 17+
- Build path: GitHub Actions / XcodeGen

## Active VOD runtime correction

The physical-device report showed that earlier VOD presentation work was not visibly replacing the information layout. v1041 removes ambiguity at the production call site:

- `VODPlayerScreen.vodOverlayHeroInfoBlock` directly invokes `V1041AppleTVMediaInformationStage`.
- The previous `V1040VODCinematicInformationStage` definition is removed.
- The active stage has the runtime accessibility identifier `V1041AppleTVMediaInformationStage`.
- The visible `NOW PLAYING • MOVIE/SERIES` header makes the active replacement immediately recognizable during device testing.
- Legacy/fallback `VODInfoPill` and `AppleVODBadge` components no longer draw capsule backgrounds, so an older auxiliary path cannot reproduce the rejected Year/Rating pill treatment.

## Apple TV-style VOD information redesign

The new information stage follows the supplied premium-player references while preserving Debrid Channels' existing poster, logo, cast, timeline, and control placement.

- Uses the native tvOS system typeface through SwiftUI `.system(..., design: .default)`—no Avenir/Baskerville override and no bundled font files.
- Year is borderless and paired with the SF Symbol calendar icon.
- Rating is borderless and paired with a gold SF Symbol star.
- Episode and genre information use SF Symbols and a clean inline editorial hierarchy.
- Adds an Apple TV-style `OVERVIEW` story block using `text.quote` and improved system-font spacing.
- Adds a compact `DIRECTED BY` credit when director metadata exists.
- Replaces the old playback-status pill shelf with a borderless icon information rail for position, remaining time, progress, cache, source quality, and clock.
- Replaces the old cast presentation in the active stage with a `FEATURED CAST` spotlight that rotates one member at a time and exposes role plus progress indicators.
- No changes to playback engines, time authority, seek behavior, or control focus.

## Backup and restore reliability

A new `BackendProfileBackupClient` isolates and hardens the backend profile transport.

- Validates HTTP response codes instead of treating any response body as success.
- Uses an ephemeral, no-cache session with bounded request/resource timeouts.
- Omits an empty backup code so the backend can generate a new code correctly.
- Supports both route-based and body-based restore/clear APIs when a backend responds with HTTP 404 or 405.
- Accepts current and older response envelopes (`profile`, `payload`, nested `data`, or JSON-string profile).
- Displays backend status/error details instead of failing silently.
- Immediately downloads a newly saved backup to verify that it is restorable.
- Reports how many compatible settings were applied during restore.
- Accepts v1-style direct settings payloads as well as v2 wrapped payloads.
- Restores catalog hidden-row IDs and custom row order.
- Restores additional safe UI/player settings: VOD dock style, focused previews, Live TV display matching, guide progress, artwork style, media-info poster choice, and full alert presentation settings.
- Provider credentials, debrid keys, Xtream passwords, private Live TV URLs, private backend configuration, and credential-bearing addon URLs remain excluded.

## Preserved from v1040

The following are byte-for-byte unchanged:

- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/PlaybackKit/PlaybackKitFoundation.swift`
- `Sources/CatalogStore.swift`
- `Sources/TrailerServiceManager.swift`
- `Sources/SourceIntelligenceManager.swift`
- `Sources/FocusedCardPreviewDiskCache.swift`
- `Sources/CatalogHeroMetadataCache.swift`
- `Sources/RemoteImageFit.swift`
- `Sources/VODExclusivePlaybackGate.swift`

This preserves:

- KSPlayer and the VOD decoded-frame queue `24 / 24 / 16`
- Live TV first-frame behavior
- Fast-scene forced-drop suppression
- VOD scrubber and seek behavior
- Audio/subtitle switching
- Trailers and focused-card previews
- Source Intelligence
- v1040 catalog-row recovery and cast metadata retry fixes

## Validation completed locally

- 39 Swift files passed `swiftc -frontend -parse`.
- `BackendProfileBackupClient.swift` and `ReleaseCandidateSecurityManager.swift` passed standalone Swift type checking.
- Backup allowlist/security behavior test passed.
- Main app and Top Shelf plists parse and match at `1.0.569 (569)`.
- `project.yml` parses and matches the same release identity.
- 38 Phase 11 static regression assertions passed.
- No `.ttf` or `.otf` font files are bundled.
- ZIP compressed-data integrity and extraction round-trip checks are performed during packaging.

A Linux environment cannot perform the authoritative tvOS SDK compile/archive. GitHub Actions remains the full Apple SDK build gate, followed by physical Apple TV validation.
