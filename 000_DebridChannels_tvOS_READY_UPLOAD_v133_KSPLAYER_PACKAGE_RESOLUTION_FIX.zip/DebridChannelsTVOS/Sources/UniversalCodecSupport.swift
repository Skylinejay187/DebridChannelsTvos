import SwiftUI
import AVFoundation
import AVKit

#if canImport(TVVLCKit)
import TVVLCKit
#endif
#if canImport(MPVKit)
import MPVKit
#endif
#if canImport(KSPlayer)
import KSPlayer
#endif

// v126 VLC-first / mpv-FFmpeg boundary:
// - AVPlayer is removed from the VOD decision path.
// - TVVLCKit/libVLC is the primary internal renderer under the Debrid overlay.
// - mpv/FFmpeg is staged as the next internal engine boundary once a compiled tvOS libmpv package is vendored.
// - Raw magnet/torrent streaming still requires a separate torrent framework/service; this file exposes diagnostics clearly.



struct NativePlaybackProfile {
    let normalizedHint: String
    let isHLS: Bool
    let isAppleContainer: Bool
    let isMatroskaOrUnsupportedContainer: Bool
    let isLikelyDolbyVision: Bool
    let isNativeDolbyVisionPreferred: Bool
    let isLikelyHDR: Bool
    let isLikelyUnsupportedAudioOnlyRisk: Bool
    let requiresVLCForContainer: Bool

    var diagnostic: String {
        var flags: [String] = []
        if isHLS { flags.append("HLS") }
        if isAppleContainer { flags.append("Apple container") }
        if isLikelyDolbyVision { flags.append("Dolby Vision hint") }
        if isNativeDolbyVisionPreferred { flags.append("Native DV preferred") }
        if isLikelyHDR { flags.append("HDR hint") }
        if isMatroskaOrUnsupportedContainer { flags.append("MKV/unsupported container") }
        if isLikelyUnsupportedAudioOnlyRisk { flags.append("audio-only risk") }
        return flags.isEmpty ? "generic HTTP stream" : flags.joined(separator: " • ")
    }
}

enum UniversalCodecSupport {
    static let buildMarker = "DEBRID_CHANNELS_TVOS_BUILD_V133_KSPLAYER_PACKAGE_RESOLUTION_FIX"

    static var vlcCompiledIn: Bool {
        #if canImport(TVVLCKit)
        return true
        #else
        return false
        #endif
    }

    static var mpvCompiledIn: Bool {
        #if canImport(MPVKit)
        return true
        #else
        return false
        #endif
    }

    static var ksPlayerCompiledIn: Bool {
        #if canImport(KSPlayer)
        return true
        #else
        return false
        #endif
    }

    static func profile(for url: URL, hint: String = "") -> NativePlaybackProfile {
        let value = (url.absoluteString + " " + hint).lowercased()
        let isHLS = value.contains(".m3u8") || value.contains("application/vnd.apple.mpegurl") || value.contains("mpegurl")
        let isAppleContainer = isHLS || value.contains(".mp4") || value.contains("%2emp4") || value.contains(".m4v") || value.contains("%2em4v") || value.contains(".mov") || value.contains("%2emov")
        let isMatroska = value.contains(".mkv") || value.contains("%2emkv") || value.contains("matroska")
        let unsupportedContainer = isMatroska || value.contains(".avi") || value.contains("%2eavi") || value.contains(".webm") || value.contains("%2ewebm") || value.contains(".vob") || value.contains("%2evob")
        let isDolbyVision = value.contains("dolby vision") || value.contains(" dolbyvision") || value.contains(" dv ") || value.contains("dvhe") || value.contains("dvh1") || value.contains("profile 5") || value.contains("profile 7") || value.contains("profile 8")
        let nativeDVPreferred = isAppleContainer && (value.contains("profile 5") || value.contains("profile 8") || value.contains("dvhe.05") || value.contains("dvhe.08") || value.contains("dvh1") || isHLS)
        let hdr = isDolbyVision || value.contains("hdr10") || value.contains("hdr10+") || value.contains("hlg") || value.contains("bt2020") || value.contains("main10")
        let audioRisk = value.contains(" dts") || value.contains("dts-hd") || value.contains("dtshd") || value.contains("truehd") || value.contains("mlp") || value.contains("atmos truehd") || value.contains("vp9") || value.contains("av1")
        let profile7 = value.contains("profile 7") || value.contains("dvhe.07") || value.contains("dolby vision profile 7")
        let requiresVLC = unsupportedContainer || profile7 || audioRisk
        return NativePlaybackProfile(
            normalizedHint: value,
            isHLS: isHLS,
            isAppleContainer: isAppleContainer,
            isMatroskaOrUnsupportedContainer: unsupportedContainer,
            isLikelyDolbyVision: isDolbyVision,
            isNativeDolbyVisionPreferred: nativeDVPreferred,
            isLikelyHDR: hdr,
            isLikelyUnsupportedAudioOnlyRisk: audioRisk || profile7,
            requiresVLCForContainer: requiresVLC
        )
    }

    static func shouldPreferVLC(for url: URL, hint: String = "") -> Bool {
        let p = profile(for: url, hint: hint)
        if p.normalizedHint.hasPrefix("magnet:") { return false }
        // v126: AVPlayer is no longer the internal VOD default. Use VLC for all direct internal playback.
        return true
    }

    static func playbackEngineName(for url: URL, hint: String = "") -> String {
        if ksPlayerCompiledIn && vlcCompiledIn { return "KSPlayer/FFmpeg/Metal primary + TVVLCKit/libVLC fallback" }
        if ksPlayerCompiledIn { return "KSPlayer/FFmpeg/Metal internal engine" }
        if mpvCompiledIn && vlcCompiledIn { return "MPV/FFmpeg + TVVLCKit/libVLC internal engines" }
        if mpvCompiledIn { return "MPV/FFmpeg internal engine" }
        if vlcCompiledIn { return "TVVLCKit/libVLC internal engine" }
        return "No internal engine compiled; TVVLCKit/libmpv missing"
    }

    static func magnetDiagnostic(for value: String) -> String? {
        let lower = value.lowercased()
        guard lower.hasPrefix("magnet:") || lower.contains("infohash") else { return nil }
        return "Magnet/infoHash items require the torrent framework/service path before playback. Direct TorBox/debrid HTTP(S) stream URLs play in-app; raw torrent streaming is isolated from AVFoundation."
    }
}

struct UniversalVideoSurface: View {
    let url: URL
    let avPlayer: AVPlayer?
    let videoGravity: AVLayerVideoGravity
    var forceVLC: Bool = true
    var routeHint: String = ""
    var vlcShouldPlay: Bool = true
    var vlcSeekSerial: Int = 0
    var vlcSeekSeconds: Double = 0
    var vlcSurfaceToken: Int = 0
    var preferMPV: Bool = false
    var preferKSPlayer: Bool = true

    var body: some View {
        Group {
            if preferKSPlayer {
                #if canImport(KSPlayer)
                KSPlayerVideoSurface(url: url)
                #else
                MissingInternalEngineSurface(message: "KSPlayer/FFmpeg/Metal was not compiled into this IPA. Use VLC Internal while the KSPlayer package resolves.")
                #endif
            } else if preferMPV {
                #if canImport(MPVKit)
                MPVKitVideoSurface(url: url)
                #else
                MissingInternalEngineSurface(message: "MPVKit/libmpv/FFmpeg was not compiled into this IPA. Use VLC Internal or external players until the MPVKit package resolves successfully.")
                #endif
            } else {
                #if canImport(TVVLCKit)
                TVVLCKitVideoSurface(url: url, shouldPlay: vlcShouldPlay, seekSerial: vlcSeekSerial, seekSeconds: vlcSeekSeconds, reloadToken: vlcSurfaceToken)
                #else
                MissingInternalEngineSurface(message: "TVVLCKit/libVLC was not compiled into this IPA. Internal AVPlayer has been disabled by design in v127; use MPV Internal if compiled or external Infuse/VLC/SenPlayer.")
                #endif
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black)
    }
}


#if canImport(KSPlayer)
struct KSPlayerVideoSurface: View {
    let url: URL

    var body: some View {
        KSVideoPlayerView(url: url, options: KSOptions())
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
    }
}
#endif

#if canImport(MPVKit)
struct MPVKitVideoSurface: View {
    let url: URL

    var body: some View {
        // v128 safety: MPVKit package can compile while its tvOS render surface still crashes at runtime.
        // The MPV button is guarded in VODPlayerScreen, but keep this fallback non-crashing if a state bug reaches it.
        MissingInternalEngineSurface(message: "MPV is not active in this rollback build. VLC Internal remains the active internal player.")
    }
}
#endif

struct MissingInternalEngineSurface: View {
    let message: String
    var body: some View {
        ZStack {
            Color.black
            VStack(spacing: 18) {
                Text("Internal Engine Missing")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                Text(message)
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.72))
                    .frame(maxWidth: 980)
            }
            .foregroundStyle(.white)
            .padding(42)
        }
    }
}

#if canImport(TVVLCKit)
struct TVVLCKitVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double
    let reloadToken: Int

    final class Coordinator {
        let player = VLCMediaPlayer()
        var currentURL: URL?
        var lastSeekSerial: Int = 0
        var lastReloadToken: Int = -1
    }

    final class VLCView: UIView {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> VLCView {
        let view = VLCView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: VLCView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func configure(view: VLCView, coordinator: Coordinator) {
        // v129: Always attach the drawable before playback. Without this, TVVLCKit can start
        // decoding audio before the tvOS UIView is attached, causing black video until VLC is
        // selected manually.
        coordinator.player.drawable = view

        let shouldReload = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken
        if shouldReload {
            coordinator.currentURL = url
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.player.stop()
            coordinator.player.drawable = view

            let media = VLCMedia(url: url)
            media.addOptions([
                "network-caching": "10000",
                "file-caching": "10000",
                "live-caching": "3000",
                "http-reconnect": "1",
                "avcodec-hw": "any",
                "drop-late-frames": "1",
                "skip-frames": "1"
            ])
            coordinator.player.media = media

            if shouldPlay {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
                    coordinator.player.drawable = view
                    if coordinator.currentURL == url {
                        coordinator.player.play()
                    }
                }
            }
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = max(0, coordinator.player.time.intValue + Int32(seekSeconds * 1000.0))
            coordinator.player.time = VLCTime(int: target)
        }

        if shouldPlay {
            if !coordinator.player.isPlaying {
                coordinator.player.drawable = view
                coordinator.player.play()
            }
        } else {
            if coordinator.player.isPlaying { coordinator.player.pause() }
        }
    }

    static func dismantleUIView(_ uiView: VLCView, coordinator: Coordinator) {
        coordinator.player.stop()
    }
}
#endif


// v106: AVPlayerViewController-backed surface used only as a rendering container.
// Apple transport controls remain disabled; Debrid Channels draws its own overlay.
// resizeAspect is the default so video keeps the source aspect ratio and does not crop/stretch.
struct AVPlayerControllerSurface: UIViewControllerRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player {
            controller.player = player
        }
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.player = nil
    }
}

// DEBRID_CHANNELS_TVOS_BUILD_V133_KSPLAYER_PACKAGE_RESOLUTION_FIX
