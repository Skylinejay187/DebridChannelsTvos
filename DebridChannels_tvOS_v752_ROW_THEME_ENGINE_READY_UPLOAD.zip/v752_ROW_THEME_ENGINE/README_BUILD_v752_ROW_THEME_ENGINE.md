DebridChannels tvOS v752 ROW THEME ENGINE

Scope:
- Adds Settings -> Appearance -> Row Theme.
- Persists rowThemePreset in UserDefaults through @AppStorage.
- Default is 0 Classic.
- Classic is a no-op rollback path.

Themes:
- 0 Classic
- 1 Flat Enhanced
- 2 Subtle 3D
- 3 Movie Case
- 4 Steelbook
- 5 Apple TV Hybrid

Applies only to:
- Movies / TV Shows streaming catalog rails
- Streaming Catalogs quick panel/favorites rails
- Search Results cards

Intentionally untouched:
- Live TV
- Sports
- Quick Guide
- Source Intelligence
- Episode rows
- Season rows
- Guide rows
- player/seek/cache/artwork fetch logic

Implementation notes:
- Pure SwiftUI rendering changes only: rotation3DEffect, shadow, scaleEffect, offset, and overlay.
- No poster reloads, cache clears, artwork regeneration, or network fetch changes.
- Invalid stored rowThemePreset values resolve to 0 Classic.
