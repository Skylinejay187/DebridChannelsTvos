# vBRDC267 / 1.0.970 / 970

Focused stabilization candidate built from vBRDC266 only.

- Fixes KSPlayer -> Aether in-session handoff retaining the old KS decoder/audio graph.
  PlaybackKit now supports releasing the active render surface without destroying the VOD
  PlaybackSession, so the outgoing KS surface is stopped before Aether mounts and a later
  return to KS can register/activate a fresh surface in the same session.
- Adds an Aether renderer-ready automatic-resume reconciliation edge. The shared bounded
  seek lane remains authoritative; this catches sources whose first Aether clock sample is
  late and prevents a saved resume checkpoint from being silently skipped.
- Replaces the generic top-left Signal text treatment with an asset derived directly from
  the already-approved app identity: metallic SIGNAL, broadcast waves over I, orange A/baseline.
- No changes to the accepted Aether 6.81 Live TV recovery ladder.
- No VOD cache or Live TV timeshift work in this candidate.
