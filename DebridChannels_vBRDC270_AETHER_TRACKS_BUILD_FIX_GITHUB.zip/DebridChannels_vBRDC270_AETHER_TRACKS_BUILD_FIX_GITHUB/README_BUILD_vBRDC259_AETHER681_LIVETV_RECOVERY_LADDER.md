# Debrid Channels vBRDC259 — Aether 6.81 Live TV Recovery Ladder

Version: 1.0.962 (962)

## Why this build exists
vBRDC258 proved that merely updating Aether and wiring `liveSourceReset` was not sufficient: some Live TV channels still reached a black Aether surface while the same source played under KSPlayer.

This candidate treats that as a transport/decode-route problem rather than a single-header problem.

## Aether upstream update
- AetherEngine 6.81.0, pinned to commit `c7e7adb5476f8d86fa484e249f6443d01d6999f8`.
- AetherFFmpegBuild 3.2.1.
- Keep Aether's namespaced FFmpeg graph isolated from KSPNUVIO/FFmpegKit.
- Preserve the Xcode 16.4 compatibility shim and Swift 5 package language mode used by v258 build fix 2.

## Live TV recovery ladder
Aether remains the selected/primary Live TV engine. A healthy stream is never delayed intentionally.

Only when a route errors or produces no displayable first frame does the bridge move through Aether-native recovery:
1. Automatic URL route. Obvious HLS starts on Aether's native remote-HLS path.
2. Explicit `HLSLiveIngestReader` for HLS, carrying headers across playlist/segment/key fetches.
3. Aether per-session `preferredDecodePath = .software` for ready-but-black VideoToolbox/native-decoder cases.
4. KSPlayer receives the same source only after the Aether routes are exhausted.

Live FFmpeg probing is bounded to 4 MiB / 5 s so a bad/sparse origin cannot consume Aether's 50 MiB / 60 s default probe budget before recovery can make a decision.

The app-level KSPlayer watchdog is extended only as a final circuit breaker so it cannot pre-empt the Aether recovery ladder.

## First-frame correctness
Aether Live TV no longer treats a clock callback as a visible frame. Only Aether's `hasFirstFrameReadyForDisplay` lifts the Aether first-frame gate. KSPlayer retains its historical clock fallback because it has no equivalent bridge signal.

## HTTP parity
Provider-supplied headers are preserved case-insensitively. Missing direct-IPTV defaults now match the lean request profile used by the working KSPlayer Live TV path (`User-Agent`, `Accept: */*`, `Connection: keep-alive`) and no longer force `Accept-Encoding: identity`.

## Still locked
- No MPVKit.
- Native SwiftPM/Xcode embedding remains.
- No manual DerivedData framework injection.
- Aether primary, KSPlayer fallback.
- No Live TV timeshift/DVR yet. Reliable ordinary Aether Live TV remains the prerequisite.
- Existing UI/navigation/resume/regression locks remain in force.
