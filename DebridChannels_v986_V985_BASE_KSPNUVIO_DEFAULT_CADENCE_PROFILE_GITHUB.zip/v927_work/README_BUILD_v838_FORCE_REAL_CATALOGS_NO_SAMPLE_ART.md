# DebridChannels v838 — Force Real Catalogs / No Sample Artwork

Baseline: v837 rollback + poster/cast polish.

Fixes:
- Removed the startup sample/demo catalog rows from the Home screen.
- Home now starts empty or with cached real catalog rows only.
- App startup still force-loads real configured catalogs immediately.
- Demo fallback rows are disabled so NORMAL/APEX/sample Unsplash artwork cannot appear.
- If providers return no real catalog rows, the app keeps existing real rows or remains empty instead of restoring samples.

Preserved:
- v835 alerts hardening.
- v833/v834 playback behavior.
- v837 poster/cast polish.
- Source Intelligence and backend behavior.
