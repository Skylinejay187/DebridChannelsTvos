# DebridChannels v894 — v893 Compile Fix: KSPlayer Flush autoPlay Bool

Base: v893_V892_BASE_KSPLAYER_TRACK_SWITCH_BUFFER_FLUSH

Fix:
- Corrected the KSPlayer track-switch flush compile error in `UniversalCodecSupport.swift`.
- `currentShouldPlay` is optional, while `KSPlayerLayer.seek(time:autoPlay:)` requires a concrete `Bool`.
- The flush now uses `currentShouldPlay ?? true` so the build compiles and active playback resumes when play state is not yet known.

Kept unchanged:
- KSPlayer real track discovery/selection bridge.
- Audio/subtitle menu population.
- Buffer flush after explicit track selection.
- VOD layout/time/progress/cast wall.
- Live TV/grid/guide/focus/source loading.
