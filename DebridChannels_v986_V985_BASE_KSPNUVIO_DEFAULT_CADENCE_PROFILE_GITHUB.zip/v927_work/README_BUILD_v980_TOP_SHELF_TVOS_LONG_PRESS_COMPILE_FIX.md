# Debrid Channels v980

Base: v979 view-only Movies/Shows Top Shelf.

## GitHub Actions build fix

The tvOS 18.5 SDK in Xcode 16.4 rejects the SwiftUI long-press overload that includes `maximumDistance` (the compiler resolves it to the unavailable `perform:onPressingChanged:` tvOS API).

Changed the Live TV card action gesture from:

```swift
.onLongPressGesture(minimumDuration: 0.42, maximumDistance: 80) { ... }
```

to the tvOS-supported form already proven by the earlier building base:

```swift
.onLongPressGesture(minimumDuration: 0.32) { ... }
```

The action still suppresses the matching tap before presenting the custom Favorites/Sports panel.

## Preserved

- View-only `Watchable Today` Top Shelf extension
- Random/day-stable Movies + TV Shows poster row
- No Top Shelf display/play/deep-link actions
- v978 Live TV exact-card restoration and custom action panel
- Gracenote Quick Guide snapshot
- VOD playback, VOD Exclusive Mode, overlay and cast wall
- VOD decoded-frame queue 32/24/16
- Live TV stock adaptive queue

## Validation

- Parsed all 33 main-app Swift source files
- Parsed and type-checked Top Shelf provider against the TVServices API stub
- Validated both plist files and project.yml
- Confirmed only `Sources/DebridChannelsTVOSApp.swift` changed in executable source from v979
- Confirmed no `maximumDistance` or `onPressingChanged` long-press overload remains
