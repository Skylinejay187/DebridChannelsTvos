# Debrid Channels v969

## Base
- Built directly from v968.
- v966 remains the locked golden playback baseline; this archive is an isolated decoded-frame queue experiment.

## Controlled playback change
Main movie/episode VOD now returns:
- 60 decoded frames for 3840x2160 or greater
- 32 decoded frames for 1920x1080 or greater
- 24 decoded frames below 1080p

This is decoded-frame queue capacity only. It does not force tvOS to 60 Hz and does not change automatic frame-rate or dynamic-range matching.

## Preserved unchanged
- v968 episode-alert reliability system
- v968 premium catalog branding
- v961 Flixor KSPlayer profile other than frame-queue capacity
- VOD overlay, cast wall, focus, timing and controls
- VOD Exclusive Mode/background-process cancellation
- episode alerts during VOD
- MPV removal and temporary-cache removal
- trailers and Live TV
