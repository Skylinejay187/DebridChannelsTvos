# DebridChannels v829 — Link Cache + Favorites Fix

Baseline: `DebridChannels_v828_STREMIO_LINK_PARITY_FIX.zip`

Scope locked to the user-reported regressions:

1. Source Intelligence reopen cache
- Added a tiny session-only, bounded Source Intelligence memory cache.
- Reopening Find Links for the same movie/show/episode immediately restores the last found links while addons refresh in the background.
- Cache is memory-only, capped to 24 media items and 80 links per item, so it does not grow persistent storage or affect long-term memory.
- Find Links now starts from All Providers on explicit searches so an old provider chip cannot make the same movie/show appear empty.
- Provider-specific searches can still be selected manually after results are restored.

2. Favorites normalization
- Replaced catalog-specific favorite keys with stable catalog-agnostic keys.
- Favorites now prefer IMDb ID, then TMDB ID, then TVDB ID, then media ID, then title/year/type.
- Global Favorites also recognizes old legacy keys so existing saved items still appear.
- Removing favorites removes both the new stable key and legacy key.

Preserved:
- v828 Stremio link parity behavior
- Source Intelligence UI
- VOD overlay geometry
- Playback engines
- Backend
- Home/Live TV/Sports/Membership/Navigation/Focus architecture
