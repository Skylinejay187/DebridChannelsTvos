# DebridChannels v834 — Shared KSPlayer Playback Profiles

Base: v833 KSPlayer Frame Pacing + Match Content Fix.

Scope:
- Preserve the v831 KSPlayer buffer/cache-ahead improvements.
- Preserve the v833 frame pacing fix that removed the once-per-second graphical hitch.
- Promote the working movie/episode KSPlayer playback profile into one shared VOD-style profile for:
  - Movies
  - TV Shows / episodes
  - Trailers
- Keep Live TV on a separate KSPlayer profile tuned for faster channel changes and smaller rolling buffer.

Implementation:
- `KSPlayerVideoSurface.makeOptions(...)` now treats all non-live playback as `isVODStylePlayback`.
- Trailers now inherit the VOD-style read-ahead/cache-ahead values instead of the older low-latency trailer lane.
- Live TV retains smaller buffer values and low-delay/nobuffer FFmpeg options.

Profile split:
- VOD-style profile: 45s preferred forward buffer, 90s max buffer, larger probe/analyze/cache settings.
- Live TV profile: 6s preferred forward buffer, 12s max buffer, low-delay settings.

Untouched:
- Source Intelligence UI
- Link resolver/cache behavior
- Favorites
- Episode alerts
- Membership
- Live TV navigation/focus
- v833 timer/frame pacing fix
- v831 playback cache behavior
