# DebridChannels v820 — Artwork 3 Startup Sample Ghost Fix

Scope locked to Artwork 3 Hero only.

Changes:
- Removed the remaining startup/demo Live TV sample wall from Artwork 3 ambient background.
- Artwork 3 no longer renders sample channels such as The Young and the Restless, black-ish, Catfish, Mike & Molly, etc.
- Artwork 3 ambient wall now uses only real persisted/session Live TV channels.
- If no real Live TV channels are available, Artwork 3 falls back to the plain dark gradient only.
- Real Live TV ambient tiles are about 10% more visible.

Not changed:
- Rows, focus, geometry, navigation, playback, sports, membership, add-ons, source intelligence, and all other artwork themes.
