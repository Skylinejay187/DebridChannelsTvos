# Debrid Channels v972 — Phase 1

## Purpose
Remove the v971 persistent Live TV grid workaround after the Jetsam memory-pressure report.

## Change
- Full-screen playback once again removes the heavy Live TV/catalog/settings render tree.
- Live TV is no longer retained behind channel playback.
- VOD playback behavior and PlaybackKit are unchanged.

## Important
This is Phase 1 only. It removes the memory-risk workaround. Deterministic lightweight Live TV focus snapshot/rebuild is the next phase.
