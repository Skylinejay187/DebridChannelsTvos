# Debrid Channels tvOS v982

Base: v981

## Scope

VOD Cast Wall lifecycle only. Episode alerts, Live TV, Top Shelf, catalog UI, playback engines, frame matching, VOD Exclusive Mode, and the 32/24/16 VOD decoded-frame queue remain unchanged.

## Change

- The Cast Wall is no longer kept active behind an invisible VOD overlay.
- When VOD controls are hidden or a player panel replaces the chrome, the Cast Wall view is removed from the active render tree.
- Removing the view stops its six-second main-run-loop timer, cast-image view lifecycle, transition animation, and rotation state updates during steady playback.
- The current cast spotlight index is retained by the parent VOD information stage.
- When the user brings the overlay back, the Cast Wall appears immediately at the previously displayed cast member and resumes rotation from there.
- No alert scheduler code was changed.

## Version

App and Top Shelf extension bundle versions: 1.0.514 (514)
