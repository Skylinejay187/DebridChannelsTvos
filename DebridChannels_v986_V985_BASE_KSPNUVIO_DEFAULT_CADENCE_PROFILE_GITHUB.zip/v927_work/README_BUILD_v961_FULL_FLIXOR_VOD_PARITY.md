# Debrid Channels v961 — Full Flixor VOD Performance Parity

Base: v960 VOD all-core decoder + decoded-frame queue + clock-pill build.

## Main VOD changes
This build replaces the accumulated main-VOD raw FFmpeg tuning with the published Flixor high-bitrate KSPlayer profile so the comparison is meaningful:

- KSMEPlayer primary engine.
- KSAVPlayer fallback, matching Flixor's fallback order.
- Autoplay disabled at construction, followed by one explicit play after the native surface is mounted.
- `preferredForwardBufferDuration = 5`.
- `maxBufferDuration = 300`.
- `isSecondOpen = true`.
- `isAccurateSeek = false` (Flixor/default behavior).
- `probesize = 50_000_000`.
- `maxAnalyzeDuration = 5_000_000`.
- `hardwareDecode = true`.
- `asynchronousDecompression = true`.
- `syncDecodeVideo = false`.
- `syncDecodeAudio = false`.
- `videoAdaptable = true`.
- `destinationDynamicRange = nil` (automatic content range).
- `decoderOptions["threads"] = "0"`.
- No forced `thread_type`.
- No forced `skip_loop_filter`.
- `isSeekImageSubtitle = true`.
- Retains the v959/v960 resolution-aware decoded-frame queue: 32 frames for 4K, 24 for 1080p, 16 below HD.
- Keeps KSPlayer's default FFmpeg dictionary and appends only Debrid-required request headers instead of replacing it with the previous large raw VOD option set.

## Intentionally not copied
- Flixor's forced FFmpeg stereo downmix filter is not included because it can alter or damage multichannel, spatial, TrueHD, DTS, or Atmos behavior and is unrelated to video hitching.
- React Native, AirPlay, and Flixor-specific UI/subtitle wiring are not part of the playback-performance profile.

## Preserved
- Trailer settings and playback route are unchanged.
- Live TV settings and playback route are unchanged.
- PlaybackKit lifecycle, persistent host, update gate, and v957 emergency first-frame recovery remain unchanged.
- v959 clock pill remains at the end of the information-chip row with AM/PM formatting.
- v958 render-backing experiment is not included.
