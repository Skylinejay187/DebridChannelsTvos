DebridChannels v888 — v887 base

Changes:
- VOD overlay: added current clock/time in the top-right corner while VOD controls/settings are visible.
- Live TV HDHomeRun: disabled unstable Gracenotes/now-playing artwork lookup for HDHomeRun sources and falls back to channel logo artwork only.
- Source Intelligence: when a movie/show source is launched and playback is exited, Source Intelligence remains open on the same link panel instead of dumping focus back to catalog rows.

Untouched:
- v887 Passenger progress bar geometry.
- VOD control design and layout.
- Live TV grid/guide scrolling and playback logic.
- Player engines and trailer logic.
