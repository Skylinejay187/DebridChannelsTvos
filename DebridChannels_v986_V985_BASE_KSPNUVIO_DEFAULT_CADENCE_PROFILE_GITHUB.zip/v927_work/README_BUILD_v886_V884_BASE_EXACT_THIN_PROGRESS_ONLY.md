# v886 — v884 Base — Exact Thin VOD Progress Rail Only

Base: v884.

Only change:
- VOD progress rail height is fixed to 2 pt in both focused and unfocused states to match the thin mock-up.
- White scrubber dot, bar width, bar position, focus behavior, VOD geometry, Cast Wall, poster logic, TV show main-poster fix, playback, Live TV, guide, and scrolling are unchanged.
