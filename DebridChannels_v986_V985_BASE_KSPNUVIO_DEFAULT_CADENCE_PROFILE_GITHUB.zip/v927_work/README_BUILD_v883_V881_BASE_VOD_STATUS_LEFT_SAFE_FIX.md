# DebridChannels v883 - v881 Base VOD Status Left Safe Fix

Base: v881 successful VOD layout.

Changes are VOD overlay only:
- Restored v881 overlay geometry and avoided v882's independent timeline relocation.
- Moved the status chips row left under the Movie/New/Rating media information group.
- Removed visible white current/duration labels beside the progress bar using hidden placeholders to preserve the v881 timeline position.
- Made the existing progress bar thinner while keeping its compact width and white scrubber dot.

Unchanged:
- Live TV grid, guide, playback logic, settings, focus, cast wall geometry, and card artwork logic.
