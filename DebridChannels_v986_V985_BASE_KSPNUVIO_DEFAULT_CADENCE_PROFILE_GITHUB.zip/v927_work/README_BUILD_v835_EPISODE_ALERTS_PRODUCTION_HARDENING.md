# DebridChannels v835 — Episode Alerts Production Hardening

Baseline: `DebridChannels_v834_SHARED_KSPLAYER_PLAYBACK_PROFILES.zip`

Scope:
- Episode alerts only.
- No playback, KSPlayer profile, Source Intelligence, catalog UI, Live TV, membership, or backend changes.

Changes:
- Widened alert eligibility window from 14 days to 45 days so alerts still fire after app downtime, UTC/date drift, late addon metadata, or missed app-open windows.
- Scans up to 150 followed shows instead of only the first 30 followed items, so larger follow lists and mixed-catalog follows are covered.
- Fixed followed-show identity mismatch after metadata hydration: scanner now fetches metadata from hydrated resolver-ready items while preserving the original followed-show key for duplicate suppression and progress tracking.
- Alerts now target the latest known aired/grace-window season first, then newest episode date and episode number.
- Added a 2-day future grace window to tolerate UTC/date-line metadata without announcing far-future episodes.
- Expanded episode date parsing formats for more addon metadata variants.
- Foreground resume now performs an immediate catch-up scan instead of waiting for the stored heartbeat time.

Preserved:
- v833 frame pacing fix.
- v834 shared KSPlayer movie/show/trailer profile.
- Live TV profile.
- Source Intelligence UI and resolver behavior.
- Playback buffer/cache behavior.
- Existing alert banner/popup styling and duration settings.
