# v809 — Sports Content Expansion + Premium VOD Chips

Base: DebridChannels_v808_SPORTS_ONE_ROW_ARCHITECTURE_ADVISORY_COMPILE_FIX.zip

Scope applied carefully:
- Sports keeps v808 one-row-at-a-time architecture.
- Added Sports rows:
  1. Live & Upcoming Games
  2. Leagues
  3. Favorite Teams
  4. Highlights
  5. Sports News
  6. Remove Channel
- Remove Channel row removes channels from Sports only; Live TV lineup is unchanged.
- Added fresh premium Kodi/movie-style VOD control chips while preserving the existing horizontal ScrollViewReader/focus/scrollTo logic.

Not included:
- v810 hero/widget scoreboard system.
- No backend changes.
- No Source Intelligence changes.
- No membership changes.
