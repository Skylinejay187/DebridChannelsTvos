# Debrid Channels v985 — 2160p Memory-Pressure / No-IPS Fix

Base: v984 Source Intelligence 25/50 total-cap build.

## Reported symptom

Large 2160p files can terminate the app without a normal Debrid Channels IPS report.
That pattern is consistent with tvOS memory-pressure/jetsam or media-process termination,
not necessarily a Swift exception. The selected 25/50 setting remains supported.

## Root-risk findings

- Source Intelligence displayed 25 or 50 results and handed every direct result to the
  active player as an adaptive fallback list.
- Main VOD retained 32 decoded frames for 4K. A single 3840x2160 NV12 frame is roughly
  12 MB before IOSurface/GPU overhead, so this queue alone can occupy hundreds of MB.
- The Flixor-style VOD profile allowed a 300-second maximum packet buffer and a 50 MB
  probe even for large 4K/remux sources.

## Fix

- Keep Source Intelligence result display and scanning at the user-selected 25 or 50.
- Decouple player handoff from display count: selected URL plus at most three ranked
  direct fallbacks are retained by the active playback session.
- Reduce only the 4K decoded-frame queue from 32 to 12. 1080p remains 24 and lower
  resolutions remain 16. Live TV is unchanged.
- Apply a high-memory VOD profile when the selected label indicates 2160p/4K/UHD/remux
  or high-risk lossless audio: 3-second preferred buffer, 30-second maximum buffer,
  smaller probe/analyze windows, packet queue, reorder queue, and demux buffer.
- Add a redacted persistent playback-session marker. On next launch, an unclosed marker
  prints a diagnostic identifying a likely jetsam/watchdog/media-process termination.
  Full signed debrid URLs are never persisted.

## Locked / unchanged

- Source Intelligence 25/50 setting and visible result cap.
- Provider ranking and balanced ordering.
- Resolver/debrid authentication.
- KSPlayer primary engine, AVPlayer fallback order, hardware decoding, asynchronous
  decompression, frame-rate/dynamic-range matching, tracks, subtitles, overlay, Cast Wall.
- Trailers and Live TV playback profiles.
- Catalogs, focus, scrolling, alerts, Top Shelf, and artwork.
