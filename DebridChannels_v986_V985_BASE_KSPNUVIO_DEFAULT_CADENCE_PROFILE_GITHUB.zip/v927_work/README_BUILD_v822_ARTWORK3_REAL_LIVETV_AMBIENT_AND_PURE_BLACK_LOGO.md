# DebridChannels v822 - Artwork 3 Real Live TV Ambient + Pure Black Logo

Base: v821 `DebridChannels_v821_ARTWORK3_DEDICATED_AMBIENT_RENDERER_FIX.zip`

Scope locked visual patch:

- Artwork 3 Hero now uses real loaded/persisted Live TV grid cards as its ambient wall.
- Removed the isolated text-only ambient placeholders from v821.
- Ambient wall does not use Home/Movie catalog rows and does not use startup demo sample channels.
- Real Live TV ambient cards are approximately 10% more visible while staying behind the logo.
- Pure Black catalog theme now shows the focused item themed logo/title in the hero area.
- No playback, source, sports, membership, backend, navigation, or row geometry changes.
