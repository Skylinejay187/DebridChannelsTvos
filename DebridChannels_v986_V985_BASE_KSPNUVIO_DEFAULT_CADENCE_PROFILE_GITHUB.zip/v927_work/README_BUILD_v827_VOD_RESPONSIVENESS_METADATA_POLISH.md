# DebridChannels v827 — VOD Responsiveness, Metadata Recovery & Overlay Polish

Base: `DebridChannels_v826_VOD_FULL_WIDTH_RED_PROGRESS_FIX.zip`

Scope kept locked to v827 request only.

## Implemented

- VOD episode link resolution no longer waits before leaving the Source Intelligence panel interactive.
- Episode/source searches cancel the previous provider resolve task before starting a new one.
- Provider results remain incremental through the existing stream link publishing path.
- Stale provider updates are guarded by the active stream search generation and selected episode identity.
- Added post-start timeline metadata recovery monitoring for AVPlayer-backed playback.
- Added KSPlayer playback time/duration callback plumbing back into the VOD overlay state.
- Seeking remains available for VOD even when total duration metadata is late.
- KSPlayer no longer rejects best-effort seek requests solely because duration is not yet finite.
- Restored reliable 30s rewind / 60s forward behavior against late-duration streams.
- Cast Wall reduced approximately 10–15% while preserving glass style/location/animation intent.
- Actor portrait display keeps fit-style portrait framing and reduced card sizing to avoid aggressive crop/zoom.
- VOD poster reduced approximately 10–15% with the same visual style.

## Preserved

No intentional changes to Live TV, backend, membership, home screen, playback engine selection, VOD overlay geometry, red progress bar, Character Spotlight behavior, advisory, sports, artwork themes, navigation, or focus engine outside the VOD responsiveness and polish paths above.
