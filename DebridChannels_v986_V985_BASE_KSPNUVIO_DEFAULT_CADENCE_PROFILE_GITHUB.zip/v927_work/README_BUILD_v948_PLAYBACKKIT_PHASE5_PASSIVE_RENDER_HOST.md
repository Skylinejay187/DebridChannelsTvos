# v948 PlaybackKit Phase 5 — Passive Render Host Ownership

Base: confirmed-working v947 Phase 4, originally rebuilt from v943.

This phase adds one session-owned `PlaybackRenderHost` lifecycle boundary for non-Live-TV VOD playback.
It is intentionally passive: it stores no UIKit view, CALayer, KSPlayer, decoder, renderer, or callback references.
The existing v943 render hierarchy and `KSPlayerVideoSurface` remain authoritative and unchanged.

Lifecycle mirrored:
- attach and activate after the PlaybackSession is created
- suspend and detach during VOD disappearance
- destroy during session stop

Untouched:
- UniversalCodecSupport.swift
- KSPlayerVideoSurface and updateUIView
- FFmpeg / VideoToolbox / decoder configuration
- first-frame gate and loading overlay
- playback clock and timeline behavior
- audio/subtitle switching
- Live TV, Guide, Grid, trailers, Source Intelligence, and UI visuals
