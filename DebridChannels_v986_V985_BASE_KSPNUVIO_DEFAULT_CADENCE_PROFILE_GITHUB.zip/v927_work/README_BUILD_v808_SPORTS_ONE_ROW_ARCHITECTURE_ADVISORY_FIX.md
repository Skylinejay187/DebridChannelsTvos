# DebridChannels v808 — Sports One-Row Architecture + Advisory Refresh Fix

Base: `DebridChannels_v807_SPORTS_HARMONY_TICKER_MATCH_POSITION_FIX.zip`

Scope kept intentionally narrow.

## Sports Foundation
- Replaced the Sports stacked/visible-all-rows layout with a Movies/Shows-style one-row-at-a-time quick panel.
- Only the active Sports row is visible.
- UP/DOWN swaps the active Sports row instead of stacking rows vertically.
- Sports cards use the larger v702/v805 quick-panel geometry: 390x220 focused landscape card rail.
- The next row appears only as a small context title under the current row, matching the existing quick-panel pattern.
- Live TV grid remains visible behind Sports; Sports stays as a bottom quick-panel overlay and does not become a fullscreen page.

## v808 Rows
1. Live & Upcoming Games
2. Leagues
3. Favorite Teams

## Advisory Fix
- Advisory now has a full selection token built from item id/title/year/type/rating/description/catalog/addon/genres/details.
- Advisory banner is keyed by that token so stale advisory/certification/descriptors cannot survive between selected titles.
- OMDb advisory facts are cleared and refetched on every selection-token change.
- The media-info top bar also uses the token to force correct rebinding per selected title.

## Intentionally Left Alone
- Playback
- Source Intelligence
- Membership
- Backend
- v809 content rows
- v810 hero/widget system

## v808 Compile Fix
- Fixed Swift type-check timeout at `advisorySelectionToken` by breaking the large optional-heavy token array into simple appended string parts.
- No behavior change: advisory still refreshes from the selected title/details/genres/runtime inputs.
