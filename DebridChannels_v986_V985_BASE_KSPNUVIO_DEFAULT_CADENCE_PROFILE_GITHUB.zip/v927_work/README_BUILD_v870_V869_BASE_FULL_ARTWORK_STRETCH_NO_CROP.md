# DebridChannels v870 — v869 Base Full Card Artwork Fill No Crop

Base: v869.

Changes:
- Live TV Full Card Artwork mode now uses a dedicated stretch-to-card image renderer.
- Removes the black side gutters that came from aspect-fit.
- Keeps the complete artwork visible and fills the existing card bounds without using the frosted renderer.

Not changed:
- Frosted Edges mode.
- Live TV card geometry, rows, text overlay, progress line, focus rings, scrolling, Guide, playback return.
- VOD overlay alignment from v869.
