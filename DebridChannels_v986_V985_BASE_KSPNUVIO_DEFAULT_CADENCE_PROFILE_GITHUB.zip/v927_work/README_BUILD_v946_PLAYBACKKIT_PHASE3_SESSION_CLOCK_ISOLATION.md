# v946 PlaybackKit Phase 3 — Session Clock Isolation

Base: confirmed-working v945 Phase 2 built from v943.

## Scope
- PlaybackClock ownership moved from the global PlaybackController into each PlaybackSession.
- PlaybackSnapshotPublisher now rebinds atomically when a session starts and clears when it stops.
- Existing KSPlayer time callback still enters through PlaybackController.ingestClock.
- Existing overlay timing/UI remains unchanged; the PlaybackKit overlay lane remains passive.

## Explicitly unchanged
- KSPlayerVideoSurface and updateUIView
- FFmpeg/decoder/buffer configuration
- render hierarchy and first-frame gate
- seek/play/pause command path
- VOD overlay visuals/focus/controls
- trailers and Live TV
