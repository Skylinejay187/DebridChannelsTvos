# v813 Advisory Coverage + VOD Spotlight Stability Fix

Base: `DebridChannels_v813_RECOVERY_DYNAMIC_ADVISORY_VOD_CHARACTER_SPOTLIGHT_BUILD_FIX.zip`

Scope only:
- Expanded advisory coverage using real dynamic metadata from current item, OMDb, and TMDB rating endpoints when keys/IDs are available.
- Advisory now treats R / NC-17 / TV-MA as adult/mature advisory content and recognizes nudity, nude, sex scenes, adult scenes, explicit, erotic, gore, drug, language, and violence descriptors from available metadata.
- No stale advisory reuse: external facts remain keyed by current focused item lookup key.
- VOD Character Spotlight rotation changed from 5 seconds to 10 seconds.
- Spotlight now preloads the small member image stack and crossfades opacity instead of recreating the image view on every rotation, reducing overlay churn that could glitch video playback.

Untouched:
- VOD scrolling
- Timeline focus
- Chip scrolling
- Playback engine
- Source Intelligence
- Sports / Live TV / Membership / Backend / MVVM
