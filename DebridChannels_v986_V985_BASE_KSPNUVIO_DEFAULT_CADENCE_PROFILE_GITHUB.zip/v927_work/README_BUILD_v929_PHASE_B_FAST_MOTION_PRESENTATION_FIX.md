# Debrid Channels v929 — Phase B Fast-Motion Presentation Pass

Base: v928 Phase A compile-fix (v924 KSPlayer render-host lineage).

## Changes
- Removed the forced Core Animation asynchronous-drawing override from the KSPlayer render view. KSPlayer/Metal now remains on the normal Core Animation presentation path.
- Kept KSPlayer's internal playback time updated on every callback while coalescing only the SwiftUI-facing time publication to a maximum of four updates per second, with immediate publication for meaningful jumps and player state changes.
- No timers were added.
- No player recreation, replay recovery, decoder, FFmpeg, VideoToolbox, seeking, audio, subtitle, buffer, profile, Live TV, or playback-lifecycle behavior was changed.
- v928 Visible Dock / Floating Controls setting is preserved.

## Validation
- UniversalCodecSupport.swift passed `swiftc -frontend -parse`.
- Existing unrelated line-126 warning remains unchanged.
