# Debrid Channels v955 — PlaybackKit Phase 12 Final Extraction

Base: corrected v954 Phase 11 SwiftUI update-gate build.

## Final PlaybackKit boundary

- Moved the complete `KSPlayerVideoSurface` implementation from `UniversalCodecSupport.swift` into `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`.
- Moved KSPlayer display matching and subtitle-renderer promotion into the same PlaybackKit tree.
- Moved all KSPlayer `KSOptions`, FFmpeg format options, decoder options, track handling, first-frame release, render-surface lifecycle, and teardown behavior into PlaybackKit.
- `UniversalCodecSupport` now routes to `PlaybackKitKSPlayerHost`; it no longer contains a second KSPlayer surface/configuration tree.

## Hardware decode policy

- Removed the VOD Hardware Acceleration Auto / Force On / Force Off controls from the in-player settings panel.
- Removed the same controls from the main VOD Player settings page.
- Removed the `vodHardwareAccelerationMode` preference and all playback-restart branches tied to it.
- KSPlayer hardware decoding remains enabled internally through `PlaybackConfiguration.vod` / `.live`.
- Current proven KSPlayer/FFmpeg options are preserved; no speculative pixel-format or codec-profile flags were added.

## VOD overlay clock

- Removed the separate top-right VOD clock.
- Added current time to the progress-information row beside remaining time, percentage, and cache state.
- Changed it to smaller plain monospaced text with no pill, glass, border, or shadow.

## Preserved

- Phase 10 persistent render ownership and ordered teardown.
- Phase 11 SwiftUI update snapshot gate.
- Existing v943/v940 first-frame release path.
- Current FFmpeg buffering, probing, queue, cadence, track-switch, and display-match behavior.
- Live TV UI, guide, focus, and source logic.
