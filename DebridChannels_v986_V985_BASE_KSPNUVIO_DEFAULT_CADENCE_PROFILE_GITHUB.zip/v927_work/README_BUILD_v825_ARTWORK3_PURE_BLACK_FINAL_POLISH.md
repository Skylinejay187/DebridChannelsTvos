# DebridChannels v825 — Artwork Hero 3 Pure Black Final Polish

Baseline: `DebridChannels_v824_ARTWORK3_PURE_BLACK_RENDERER_RESTORE.zip`

Scope locked to Artwork Hero 3 only.

## Changes

- Kept Artwork Hero 3 on the same real `LiveTVScreen()` / Pure Black renderer path used by v824.
- Removed the stale Artwork 3 ambient wall/tile renderer code path from the catalog overlay.
- Added an Artwork Hero 3-only polish overlay that darkens the real Live TV grid without drawing fake grids, snapshots, placeholders, startup channels, or movie artwork.
- Increased Artwork Hero 3 dimming by roughly 25% compared with v824 while keeping the live grid visible.
- Added stronger left-to-center cinematic logo protection using a smooth black gradient with no hard edge, rectangle, or box.

## Untouched

VOD overlay, playback, character spotlight, advisory, sports, sports widgets, Live TV logic, membership, Source Intelligence, backend, MVVM architecture, and all other Artwork themes were left unchanged.
