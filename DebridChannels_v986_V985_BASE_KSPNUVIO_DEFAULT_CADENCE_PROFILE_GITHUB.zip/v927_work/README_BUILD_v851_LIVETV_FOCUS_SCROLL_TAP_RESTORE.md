# v851 Live TV Focus/Scroll/Tap Restore

Base: DebridChannels_v849_V840_NATIVE_SWIFTUI_SPEED_V847_VOD_TRAILER.zip

Scope:
- Restored the Live TV grid tile rendering path to native v840 SwiftUI behavior.
- Removed `.drawingGroup()` from Live TV tiles because it restored speed but could rasterize/alter the focus/tap region and caused:
  - inability to scroll past the third row
  - artwork disappearing/reappearing during scroll
  - selected cards not launching playback
  - guide / left tools navigation failure

Preserved:
- v840 Live TV card design, rings, layout, navigation, guide, and playback return behavior.
- v847 VOD design and trailer design already imported in v849.
- No UIKit hybrid code added.

Compile-safety note:
- Avoided duplicate Swift declarations for TheaterAmbientArtworkGlow and VODTheaterModeStrip.
- No `.systemMaterialDark` tvOS-only issue introduced.

Changed file:
- Sources/DebridChannelsTVOSApp.swift

Validation:
- Static source validation in Linux container.
- Confirmed no remaining Live TV `.drawingGroup()` in `liveTile(channel:)`.
