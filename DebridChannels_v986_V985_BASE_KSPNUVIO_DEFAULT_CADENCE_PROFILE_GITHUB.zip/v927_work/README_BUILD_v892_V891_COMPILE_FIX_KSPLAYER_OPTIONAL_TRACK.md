# v892 — v891 compile fix: KSPlayer optional track

- Base: v891.
- Fixed the exact GitHub Actions error in `UniversalCodecSupport.swift:630`.
- KSPlayer 6.1.4 `select(track:)` requires a non-optional concrete track; the previous typed `Optional<Track>.none` still could not compile.
- Removed only that invalid optional generic call.
- Audio/subtitle discovery and real concrete track selection remain unchanged.
