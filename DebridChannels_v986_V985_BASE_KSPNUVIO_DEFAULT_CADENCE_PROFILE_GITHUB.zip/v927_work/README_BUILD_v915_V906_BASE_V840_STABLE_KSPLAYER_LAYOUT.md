# Debrid Channels v915

Base: v906.

Scope:
- Restored the v840 stable KSPlayer container/layout behavior.
- Removed recursive subtitle renderer collection, re-parenting, bring-to-front calls, and forced layout passes from KSContainerView.layoutSubviews.
- Retained v906 active audio/subtitle track discovery and selection plumbing.
- Kept native KSPlayer subtitle/caption renderer descendants in their original hierarchy without hiding them.
- Restored v840 startup behavior by disabling automatic embedded-subtitle selection; explicit track selection remains available after player readiness.
- No Live TV grid/guide, focus, scrolling, VOD layout, or Source Intelligence UI changes.
