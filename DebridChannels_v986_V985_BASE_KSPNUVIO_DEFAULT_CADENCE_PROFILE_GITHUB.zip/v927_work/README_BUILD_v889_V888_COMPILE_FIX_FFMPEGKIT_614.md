# DebridChannels v889

Base: v888.

Build fix only:
- Updated project.yml FFmpegKit SwiftPM exactVersion from 6.1.3 to 6.1.4 to match KSPlayer main dependency constraint (`ffmpegkit` 6.1.4..<7.0.0).
- No app code, UI layout, playback logic, Live TV, Source Intelligence, or VOD overlay behavior changed.
