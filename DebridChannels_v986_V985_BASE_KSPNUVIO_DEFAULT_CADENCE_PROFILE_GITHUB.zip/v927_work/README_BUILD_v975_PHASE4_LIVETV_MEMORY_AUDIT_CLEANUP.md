# Debrid Channels v975 — Phase 4 Live TV Memory Audit + Cleanup

Base: v974 Phase 3.

## Scope

This phase targets the Live TV Jetsam/per-process memory termination without changing the locked VOD playback pipeline.

## Live TV memory lifecycle

- Captures process physical-footprint/resident memory at:
  - Live TV grid exit
  - Full-screen player presentation
  - Player teardown
  - Restored grid focus
  - Restored grid settled state (1.25 seconds later)
- Logs retained-memory delta for each cycle using `[LiveTVMemory][v975]`.
- Emits a warning marker when the settled process remains more than 160 MB above the pre-playback baseline.

## Cleanup

- Cancels and releases Live TV-only player tasks and observer references on exit.
- Releases the full-screen Quick Guide model's channel/guide arrays on teardown.
- The player Quick Guide now keeps a lightweight channel-only snapshot and does not duplicate the full EPG dictionary.
- Releases the disappearing grid model's view-owned channel/guide arrays before full-screen playback.
- Cancels artwork network/prefetch work and clears the decoded artwork NSCache before Live TV playback. The grid is not visible during playback, so retaining up to 220 MB of decoded card artwork is unnecessary.
- The store-owned Phase 2 focus snapshot remains the only Live TV navigation state carried across playback.

## Preserved

- v974 deterministic focus rebuild.
- Exact channel/category/guide/window restoration.
- VOD decoded-frame queue remains 32/24/16.
- Live TV remains on KSPlayer stock adaptive frame queue.
- PlaybackKit sources are byte-for-byte unchanged from v974.
- VOD Exclusive Mode, VOD overlay, cast wall, alerts, catalogs, frame matching and dynamic-range matching are unchanged.

## Suggested device test

Repeat at least 10 cycles:

1. Focus a channel card in the middle of a large Live TV category.
2. Open the channel and let it play for 20–30 seconds.
3. Exit playback.
4. Confirm focus returns to the exact card.
5. Repeat with different channels and once from the guide.
6. Inspect device logs for `[LiveTVMemory][v975] ... stage=grid-settled` and verify the delta does not steadily climb each cycle.
