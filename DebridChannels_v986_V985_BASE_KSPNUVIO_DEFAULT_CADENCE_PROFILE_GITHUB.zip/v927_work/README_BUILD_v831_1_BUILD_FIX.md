# DebridChannels v831.1 Build Fix

Base: DebridChannels_v831_PLAYBACK_BUFFER_CACHE_FIX.zip

## Fix
- Resolved tvOS compile error in `UniversalCodecSupport.swift`:
  - `cannot find 'isLiveStream' in scope`
- Passed `isLiveStream` from `UniversalVideoSurface` into `KSPlayerVideoSurface`.
- Added `isLiveStream` as a KSPlayer surface property so the v831 VOD buffering profile can correctly distinguish VOD from Live TV.

## Scope
- Build-only fix.
- No playback-engine redesign.
- No UI changes.
- v831 playback buffer/cache behavior preserved.
