# Debrid Channels v986 — KSPNUVIO Default Cadence Profile

Base: v985 2160p memory-pressure / no-IPS fix.

## Purpose

Retain the v985 crash fix while restoring the KSPNUVIO defaults most directly related
to decoded-frame scheduling and timestamp presentation for main movie/episode playback.
The target symptom is the remaining micro-glitch during camera pushes, zooms, pans,
scene cuts, and fast motion.

## Main VOD changes

- 2160p decoded-frame queue: 12 -> 16 frames (KSPNUVIO VOD default).
- FFmpeg decoder threads: `"0"` -> explicit `"auto"`.
- Asynchronous decompression: `true` -> `false` (KSPNUVIO default).
- Preserve `syncDecodeVideo = false`, `syncDecodeAudio = false`, hardware decoding,
  preferred-frame presentation, and video adaptability.
- Preserve the existing automatic first-frame release: autoplay stays disabled for the
  initial main-VOD construction, one explicit play is asserted after the stable render
  host is mounted, and the delayed same-position seek remains emergency-only.

## v985 protections retained

- Source Intelligence still displays/scans the selected 25 or 50 results.
- The active player retains only the selected source plus three ranked fallbacks.
- 2160p/4K/UHD/remux/high-risk lossless-audio sources retain the 3-second preferred /
  30-second maximum buffer profile and reduced probe/analyze windows.
- The no-IPS playback-session journal remains enabled.

## Unchanged

- Resolver and debrid authentication.
- Audio/subtitle selection and explicit track flush.
- Frame-rate and dynamic-range matching.
- VOD overlay, Cast Wall, resume, history, and playback controls.
- Trailer and Live TV playback profiles.
- Catalogs, Source Intelligence ordering, focus, scrolling, artwork, and settings.

## Test target

Replay the exact large 2160p source and the same zoom/pan/fast-action scenes used to
validate v985. Confirm: no termination, automatic first frame, stable clock, smooth
fast motion, seek recovery, and audio/subtitle switching.
