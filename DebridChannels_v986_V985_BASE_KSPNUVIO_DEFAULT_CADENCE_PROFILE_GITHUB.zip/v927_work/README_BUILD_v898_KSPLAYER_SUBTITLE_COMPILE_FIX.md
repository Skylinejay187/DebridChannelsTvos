# v898 KSPlayer Subtitle Compile Fix

Base: v897.

This build fixes the tvOS compile error from v897 by removing the unsupported `KSOptions.subtitleDisable` assignment.

Kept intact:
- v896 active FFPlayer-backed audio track apply path.
- v897 active KSPlayer subtitle renderer mounting/search path.
- v897 one-shot decoder/output flush clock gate behavior.

Not touched:
- Live TV grid/guide/playback layout.
- VOD chip design/layout/focus/scrolling.
