# DebridChannels v856 — v855 Base Artwork Decode Cache Performance

Base: `DebridChannels_v855_ARTWORK_SUBLAYER_SCROLL_OPTIMIZATION.zip`.

Scope kept intentionally narrow. Live TV grid layout, card design, focus rings, playback return, Guide, left tools, VOD overlay, and trailer overlay were not changed.

Files changed:
- `Sources/RemoteImageFit.swift`

Performance change:
- Added bounded decoded-image memory cache limits.
- Added shared in-flight artwork request coalescing so duplicate URL requests reuse the same network/decode result.
- Added off-main-thread image decompression before SwiftUI displays the image, reducing first-draw scroll hitching.
- Kept full source image quality. No downsample or visual size reduction was added.
- Kept the v855 artwork-sublayer-only `drawingGroup()` placement unchanged.

Focus safety:
- No Live TV focus code changed.
- No SwiftUI grid logic changed.
- No UIKit bridge added.
- No full-card `drawingGroup()` restored.

Validation performed in this environment:
- Static source diff review.
- Brace/parenthesis balance check on changed Swift source.
- Checked that only `RemoteImageFit.swift` changed plus this build note.

Full tvOS/Xcode build was not available in this Linux environment, so device/Xcode build verification still needs to be run in GitHub/Xcode.
