# DebridChannels v857 — v856 Base Prefetch + Obsolete Artwork Cancel

Base: `DebridChannels_v856_V855_BASE_DECODE_CACHE_PERFORMANCE.zip`

Scope:
- Kept v855/v856 Live TV focus, tap, Guide, left tools, playback return, layout, and artwork-only `drawingGroup()` unchanged.
- Added the next safe performance pass only: Live TV artwork prefetch for the focused row neighborhood and cancellation of obsolete prefetch-only artwork tasks.

Files changed:
- `Sources/RemoteImageFit.swift`
- `Sources/DebridChannelsTVOSApp.swift`

Implementation notes:
- `PremiumRemoteImageLoader` now has bounded prefetch support using the same decoded memory cache and URL upgrade path as normal artwork loading.
- Shared in-flight visible loads are not cancelled when an offscreen cell disappears.
- Only prefetch-specific tasks outside the current focused window are cancelled.
- Live TV grid now prefetches artwork around the current focused/selected channel without changing the SwiftUI focus tree or tile geometry.

Validation performed in this environment:
- Checked changed Swift source brace balance.
- Confirmed the prior full-card/conditional `drawingGroup()` path was not reintroduced.
- No tvOS/Xcode build was run here because this Linux environment does not include the Apple tvOS SDK.
