# DebridChannels v813 Recovery Dynamic Advisory + VOD Character Spotlight

Base: `DebridChannels_v811_CHARACTER_SPOTLIGHT_ADVISORY_RESTORE.zip`

Scope locked recovery build. v812 was not used.

## Changes

1. Restored advisory binding behavior so the advisory pill is rebuilt from the currently focused title identity and detail metadata.
   - Certification
   - MPAA/TV rating
   - Advisory tags
   - Content descriptors
   - Region rating when present in metadata text
   - No runtime/genre/source filler in the advisory panel
   - Empty advisory metadata hides the advisory instead of reusing stale/cached values

2. Removed Character Spotlight wording from Media Information fallback text.
   - Media Information remains the v811-style metadata layout.
   - No extra Character Spotlight panel was added there.

3. Franchise row remains landscape poster based.
   - Uses `landscapeURL ?? posterURL` with landscape card geometry.

4. VOD overlay Cast Wall was replaced with one Character Spotlight panel.
   - Character artwork/portrait area
   - Character name
   - Actor name
   - No hidden Cast Wall beneath it
   - Fixed-width layout to prevent overlap/cropping

5. Character rotation polished.
   - 5 seconds per character
   - Smooth crossfade
   - Rotation pauses after overlay interaction and resumes afterward

6. Pause behavior fixed.
   - Paused playback keeps the VOD overlay visible indefinitely.
   - Resume restarts the existing auto-hide timer.

7. Seek buttons updated.
   - Forward: 60 seconds
   - Back: 30 seconds unchanged

## Untouched Areas

No intentional changes were made to VOD scrolling, timeline focus, chip scrolling, playback engine, Source Intelligence, Sports, Live TV, Membership, Backend, or MVVM architecture.
