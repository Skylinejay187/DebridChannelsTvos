# Debrid Channels v966 — v965 Compile Fix

Base: v965 V961 overlay restore + VOD exclusive mode + temporary cache removal.

Compiler fixes only:

- Added explicit `self.` captures inside the real-media probe completion closure as required by Swift 6 capture semantics.
- Removed the final stale `cacheMB` interpolation from the startup loading message after the temporary VOD cache subsystem was deleted.

No playback, VOD overlay, cast wall, KSPlayer/Flixor profile, display matching, background-exclusive gating, Live TV, catalog, Source Intelligence, or episode-alert behavior was changed.
