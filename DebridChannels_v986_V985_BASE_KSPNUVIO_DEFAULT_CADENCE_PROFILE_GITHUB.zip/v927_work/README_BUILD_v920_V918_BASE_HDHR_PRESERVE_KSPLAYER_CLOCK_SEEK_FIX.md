# Debrid Channels v920

Base: v918 (preserves the HDHomeRun/Gracenote authoritative refresh fix and search-all-catalog behavior exactly).

Changes:
- Fix KSPlayer real playback clock freezing at 0:00 after startup.
- Do not require KSPlayer to remain forever in `.readyToPlay`; transient playback/buffering state changes no longer permanently stop time callbacks.
- Keep initial startup and explicit track-flush clock gates, then release the real clock after KSPlayer reaches ready.
- Continuously publish the real KSPlayer time after the existing first-frame gate so progress, remaining time, Back 30, Forward 60, and timeline seeking work.
- Synthetic SwiftUI playback time remains disabled.

Unchanged:
- HDHomeRun/Gracenote authoritative guide merge from v918.
- Search-all-catalog behavior from v918.
- Live TV grid/guide layout and focus.
- VOD layout and player startup lifecycle.
