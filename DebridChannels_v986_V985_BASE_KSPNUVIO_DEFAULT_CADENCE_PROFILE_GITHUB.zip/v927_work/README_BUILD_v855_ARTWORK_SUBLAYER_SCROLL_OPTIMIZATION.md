# v855 Artwork Sublayer Scroll Optimization

Base: DebridChannels_v851_LIVETV_FOCUS_SCROLL_TAP_RESTORE.zip

Changed only `Sources/DebridChannelsTVOSApp.swift`.

The Live TV grid, card geometry, card design, focus host, focus rings, focus scale/pop, footer, progress line, taps, playback return, Guide navigation, and left tools remain unchanged.

The only performance change is `.drawingGroup()` on the `LiveTVGridTileArtwork` child layer inside `LiveTVGridTileContent`. The outer `liveTile` and all interactive/focus layers remain native SwiftUI.

Static checks:
- Exactly one Live TV `.drawingGroup()` exists and it is on the artwork child layer only.
- No conditional focused/unfocused view-tree switching was added.
- Duplicate declaration guard checked for `TheaterAmbientArtworkGlow` and `VODTheaterModeStrip`.
- Full tvOS xcodebuild was not available in this environment.
