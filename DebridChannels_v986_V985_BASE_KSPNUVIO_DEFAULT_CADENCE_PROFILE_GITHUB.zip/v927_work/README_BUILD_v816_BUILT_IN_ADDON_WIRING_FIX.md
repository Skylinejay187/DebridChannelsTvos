# DebridChannels v816 Built-In Addon Wiring Fix

Base: v815 BUILT_IN_ADDON_DEBRID_MANAGER

Scope:
- Removed MediaFusion from the built-in Addon/Debrid Manager UI.
- Fixed Torrentio configured manifest generation so quality preferences do not accidentally exclude 4K/1080p/720p results.
- Added generated Torrentio/Comet/TorBox manifests directly into Source Intelligence search at runtime from saved settings/API keys.
- Added IMDb-first stream IDs for movie and episode stream endpoint calls so Torrentio/Comet receive resolver-ready IDs.
- Added configured-addon root manifest fallback for Torrentio/Comet.

Do not touch:
- Playback engine
- Sports
- Live TV
- Membership
- VOD overlay/focus/scrolling
