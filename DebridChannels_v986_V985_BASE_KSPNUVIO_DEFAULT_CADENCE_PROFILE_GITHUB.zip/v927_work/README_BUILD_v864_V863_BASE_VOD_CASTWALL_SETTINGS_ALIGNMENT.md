# DebridChannels v864 — v863 Base VOD Cast Wall + Hardware Setting Visibility

Base: v863 successful build.

Changes:
- VOD overlay only:
  - Cast Wall right edge is aligned to the end of the progress/time bar, before the duration label area.
  - Cast Wall sits lower/closer to the time bar.
  - Poster remains at the very start of the first time label zone.
  - Logo/info column spacing from poster increased so it never touches the poster.
- Settings visibility:
  - VOD Player category subtitle now explicitly mentions hardware acceleration.
  - VOD section header now says "VOD Internal Player + Hardware Acceleration".
  - Existing Auto / Force On / Force Off hardware settings remain in Settings only.

Unchanged:
- Live TV grid/card setting from v863.
- Live TV scrolling/focus/Guide/playback return.
- VOD playback engines.
- Trailer overlay.
