# DebridChannels v890 — v889 Base KSPlayer Real Track Bridge

Base: `DebridChannels_v889_V888_COMPILE_FIX_FFMPEGKIT_614.zip`

Scope: KSPlayer VOD audio/subtitle selection only.

Changes:
- Added KSPlayer runtime embedded track discovery after `readyToPlay`.
- KSPlayer now publishes real embedded audio/subtitle tracks back into the VOD overlay menus.
- Selecting an Audio track now sends the selected real KSPlayer audio track index into `KSPlayerVideoSurface` and calls `layer.player.select(track:)`.
- Selecting a Subtitle track now sends the selected real KSPlayer subtitle track index into `KSPlayerVideoSurface` and calls `layer.player.select(track:)`.
- Subtitle Off now sends nil subtitle selection to KSPlayer and increments a serial so the active player applies it immediately.
- English audio auto-select remains single-shot, but user-selected audio overrides it.
- AVPlayer, MPV, VLC, Live TV, VOD overlay layout, progress bar, Source Intelligence, guide, grid, catalogs, and playback-return logic were not visually changed.

Verification:
- Swift parse check passed for all `Sources/*.swift`.
