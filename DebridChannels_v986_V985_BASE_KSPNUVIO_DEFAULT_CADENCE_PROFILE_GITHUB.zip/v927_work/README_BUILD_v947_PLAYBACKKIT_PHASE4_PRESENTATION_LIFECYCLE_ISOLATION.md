# v947 PlaybackKit Phase 4 — Presentation Lifecycle Isolation

Base: confirmed-working v946 Phase 3 archive.

This phase adds a passive `PlaybackPresentationCoordinator` owned one-to-one by each non-Live-TV `PlaybackSession`. Existing SwiftUI loading, first-frame, overlay, dismissal, and error behavior remains authoritative; those events are mirrored into the coordinator for later extraction.

No KSPlayer, FFmpeg, renderer, `updateUIView`, buffering, track selection, Live TV, overlay layout, focus, or remote-command behavior was changed.
