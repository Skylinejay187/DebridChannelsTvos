# Debrid Channels v930 — Favorites Performance Isolation

Base: v929 Phase B only.

Changes:
- Favorites is removed from the active SwiftUI render tree while details, search, or VOD playback is presented.
- A static dormant background replaces the hidden Favorites UI beneath overlays/player.
- Favorites movie/show items are cached and rebuilt only when favorite IDs or catalog row structure changes.
- Favorites selected index persists through SceneStorage and is restored on return.
- Favorites disables shared rail lazy-refresh requests and spring animations.
- Removed Favorites backdrop transition/animation churn.

Untouched:
- UniversalCodecSupport.swift (byte-for-byte unchanged)
- KSPlayer, FFmpeg, VideoToolbox, decoder, seeking, clock, audio, subtitles
- Live TV, Catalog, Search, dock controls, playback profiles

Validation:
- All Swift source files pass `swiftc -parse`.
- Existing unrelated UniversalCodecSupport warning remains unchanged.
