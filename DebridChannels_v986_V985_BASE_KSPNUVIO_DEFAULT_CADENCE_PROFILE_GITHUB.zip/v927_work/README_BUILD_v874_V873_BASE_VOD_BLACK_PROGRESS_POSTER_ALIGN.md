# DebridChannels v874 - v873 Base VOD Black Progress + Poster Alignment

Base: v873 compile fix.

Changes:
- VOD poster/info group corrected so visible poster edge aligns with the start of the progress bar.
- VOD played progress changed from blue to pure black while keeping the white scrubber dot.
- VOD chip focused state changed from blue to black/white styling.
- No Live TV grid, Guide, playback engine, source loading, catalogs, or trailer changes.
