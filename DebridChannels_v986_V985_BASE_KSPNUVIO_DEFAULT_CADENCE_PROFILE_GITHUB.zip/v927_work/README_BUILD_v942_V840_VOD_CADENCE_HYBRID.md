# Debrid Channels v942 — v840 VOD Cadence Hybrid

Base: v941 TV Clock Recovery + Frame Cadence.

VOD-only changes:
- Restored v840 movie/episode forward buffer: 45 seconds preferred, 90 seconds maximum.
- Restored asynchronous decompression for movies and episodes.
- Preserved the v941 trailer and Live TV routing/settings.
- Retained v940/v941 decoder overrides: threads=auto, thread_type=slice, skip_loop_filter=none.
- Retained demux overrides: reorder_queue_size=1024, buffer_size=8388608, analyzeduration=10000000, probesize=15000000.
- Retained KSMEPlayer lock, hardware decode, first-frame release, clock recovery, Source Intelligence, Favorites, and render-host freezes.
