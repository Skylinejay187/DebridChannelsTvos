# v804 Ticker Nudge + Search Focus + Sports One Row Rebuild

Base: v803 ticker final geometry sports scratch rebuild.

Scope only:
- Moved movie/show and sports ticker geometry lower, closer to the top-right Live TV card, using the same top-row card frame math.
- Kept ticker above the card with a small gap and away from the search/time area.
- Disabled the default tvOS white focus halo on the top search button so the orange search icon does not get a white block around it.
- Hard reset the active Sports tab surface to a new one-row quick panel path.
- The previous multi-row/full SportsScratchQuickPanelSurface remains compiled but is no longer active.
- Active Sports now shows one clean hero plus one Live and Upcoming row as a starting point for rebuilding from scratch.

Untouched:
- KSPlayer / AVPlayer / playback controls
- Source Intelligence
- Membership
- Live TV guide/cache/parsing
- Backend
- Media Info screen
