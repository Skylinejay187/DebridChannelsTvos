# v905 — v904 Compile Fix

Base: v904

Fix:
- Removed one extra closing brace at the end of `Sources/DebridResolverPreflightManager.swift`.
- This caused the repeated Swift compile failure:
  `error: extraneous '}' at top level`

No behavior changes beyond making v904 compile.
