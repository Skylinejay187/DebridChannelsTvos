# v902 — v898 base only

Scope: KSPlayer VOD audio/subtitle/time path only.

- Base reset to v898 as requested.
- Removes all v901 KVC/undefined-key subtitle probing.
- Does not re-parent arbitrary reflected KSPlayer objects.
- Keeps the working v898 active FFPlayer audio track selection path.
- Forces only real KSPlayer-owned subtitle/caption/text UIView descendants to full parent bounds during every KSContainerView layout pass.
- Keeps those subtitle descendants visible and frontmost inside the KSPlayer surface.
- Visible KSPlayer time is frozen from initial load and explicit track flush until KSPlayer reports readyToPlay again.
- Track-switch flush preserves prior play/pause intent and resumes automatically when playback was active.
- No Live TV/grid/guide/VOD layout/focus/chip changes.
