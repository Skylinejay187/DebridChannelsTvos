# DebridChannels v815 — Built-in Addon / Debrid Manager

Base: DebridChannels_v814_V813_REAL_POLISH_FIX.zip

Scope:
- Added Settings → Streaming Catalogs → Built-in Addon / Debrid Manager.
- Added local key fields for Real-Debrid and TorBox.
- Added optional Torrentio-specific key override fields.
- Added quality filter field for 4K/1080p/720p style preferences.
- Added Cached Only toggle.
- Added Exclude CAM / Low Quality toggle.
- Added one-click installer buttons for:
  - Torrentio + Real-Debrid
  - Torrentio + TorBox
  - Comet
  - MediaFusion
  - TorBox Search
- Installer buttons generate addon manifest URLs and add them to Saved JSON URLs.
- Existing Find Links / Source Intelligence pipeline uses these manifests, preserving TMDB/Cinemeta browsing.

Not touched:
- Playback engines
- Sports
- Live TV
- Membership
- Backend
- MVVM architecture
- VOD overlay focus/scrolling

Notes:
- This is the built-in addon manager layer requested, similar to a Streamer-style setup page.
- Real-Debrid and TorBox direct API key fields are present so future direct resolver calls can reuse the same stored keys.
- Stream/provider discovery still flows through existing Stremio-compatible manifests to avoid redesigning Source Intelligence.
