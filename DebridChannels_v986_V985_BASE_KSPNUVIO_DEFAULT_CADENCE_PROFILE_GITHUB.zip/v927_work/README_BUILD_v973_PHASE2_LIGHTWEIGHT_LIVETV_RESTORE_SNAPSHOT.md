# Debrid Channels v973 — Phase 2 Lightweight Live TV Restore Snapshot

Base: v972 Phase 1

## Scope

Phase 2 only. No focus timing/rebuild choreography is changed yet.

The Live TV screen now records a lightweight store-owned snapshot before full-screen channel playback removes the heavy grid tree:

- played channel ID
- exact focused card ID
- filtered-list index
- selected category/filter
- virtualized window start
- grid versus guide mode
- launch origin
- capture timestamp

The snapshot contains no SwiftUI views, artwork, guide cells, image loaders, or player references. It survives `LiveTVScreen` teardown because it is owned by `CatalogStore`.

Restore targeting now prefers the exact focused card, then the played channel, then the nearest saved index when provider refresh changes channel identity.

## Locked

No PlaybackKit, KSPlayer, VOD overlay, VOD Exclusive Mode, decoded-frame queue, frame matching, alerts, or catalog UI changes.
