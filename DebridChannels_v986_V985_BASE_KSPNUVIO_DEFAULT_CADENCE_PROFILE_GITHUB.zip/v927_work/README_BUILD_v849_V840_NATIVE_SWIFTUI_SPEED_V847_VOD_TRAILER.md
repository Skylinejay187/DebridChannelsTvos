# DebridChannels v849 — v840 Native SwiftUI Grid + v847 VOD/Trailer Design

Base: v840.

- v840 Live TV card design/layout/focus/remote behavior preserved.
- No v847 UIKit grid and no v847 Live TV card redesign imported.
- Only v847 trailer visual design and VOD overlay visual design imported.
- Pure SwiftUI speed layer: `drawingGroup` is attached to `LiveTVGridTileContent` before focus modifiers, preserving the native focusable host and existing `.id(channel.id)`.
- No forced UIKit focus restore token or UICollectionView bridge.
- Duplicate compile regression avoided: one `TheaterAmbientArtworkGlow`, one `VODTheaterModeStrip`.
