# DebridChannels v891 — v890 Compile Fix: KSPlayer Existential Tracks

Base: v890_V889_BASE_KSPLAYER_REAL_TRACK_BRIDGE

Scope: compile fix only for KSPlayer real audio/subtitle bridge.

Fix:
- Swift build failed because `layer.player.tracks(mediaType:)` returns existential `any MediaPlayerTrack` values, while KSPlayer's `select(track:)` expects a generic concrete `MediaPlayerTrack`.
- Added small generic helpers to open the existential before selecting KSPlayer audio/subtitle tracks.
- Changed subtitle Off from raw `select(track: nil)` to a typed nil using an opened sample subtitle track, avoiding generic inference failure.

No visual changes.
No Live TV/grid/guide changes.
No AVPlayer track logic changes.
No playback engine switching changes.
