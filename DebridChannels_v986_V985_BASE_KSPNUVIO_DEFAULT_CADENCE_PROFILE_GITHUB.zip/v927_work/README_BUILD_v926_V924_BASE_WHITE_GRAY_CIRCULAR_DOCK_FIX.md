# Debrid Channels v926

Base: v924 Phase 1 only.

## Scope
- Preserves v924 KSPlayer render-host freeze unchanged.
- Rebuilds only VOD control dock visuals.
- Removes orange dock outline.
- Removes white rectangular focused-chip background.
- Keeps circular controls.
- Uses white/gray circular focus ring and subtle glow.
- Increases dock/control height to prevent clipping.
- Removes animated whole-rail scrolling during focus movement.
- Keeps existing actions, focus bindings, and playback callbacks unchanged.

## Validation
- UniversalCodecSupport.swift is byte-for-byte identical to v924.
- All Swift source files pass `swiftc -parse`.
