# v821 Artwork 3 Dedicated Ambient Renderer Fix

Base: v820 ARTWORK3_STARTUP_SAMPLE_GHOST_FIX

Scope locked to Artwork 3 Hero only.

Changes:
- Artwork 3 no longer keeps LiveTVScreen/Home row hierarchy rendered underneath the catalog overlay.
- Added `artwork3CatalogOverlayActive` so Home/Movies/Shows use `StaticAppBackground` underneath when Artwork 3 Hero is selected.
- The only Artwork 3 background is now the dedicated `artwork3AmbientContentWall` inside `GridOSCatalogOverlay`.
- This prevents foreground movie rows, startup sample cards, and cached Live TV preview cards from ghosting behind the hero logo.
- Increased the dedicated real Live TV ambient tiles visibility by ~10% (`0.77 -> 0.85`).

No changes to:
- Other artwork themes
- Row geometry/brightness/focus
- Live TV screen behavior outside Artwork 3 catalog overlay
- Playback, Sports, Membership, Source Intelligence, Advisory
