# DebridChannels v831 — Always-On Playback Buffer Cache Fix

Baseline: DebridChannels_v830_FIND_LINKS_UI_PARITY_ALERTS_FIX.zip

Scope:
- Playback buffering only.
- No source/link cache behavior changes.
- No Source Intelligence UI redesign.
- No playback engine replacement.
- No Live TV, membership, sports, artwork, advisory, or navigation changes.

Changes:
- Confirmed AVPlayer VOD path already had player-level forward buffering configured.
- Fixed KSPlayer VOD direct-stream path that was still using low-latency/no-buffer style options for normal VOD playback.
- Playback buffer is now independent from Link Cache.
- When Link Cache is off, direct streams still use standard playback read-ahead buffering.
- VOD direct streams now use:
  - preferred forward buffer window
  - larger max buffer window
  - non-zero FFmpeg/KS cache
  - genpts instead of nobuffer
  - no low_delay flag for normal VOD
  - larger analyze/probe values for more stable direct streams
- Live TV and trailers keep lower-latency buffering.

Goal:
- Reduce buffering/stalling during VOD direct-stream playback.
- Keep Link Cache setting only for remembered source results, not video read-ahead.
