# Debrid Channels v984 — Source Intelligence 25/50 Total Cap

Base: v983 (which is v982 plus the Live TV Select-hold menu fix).

## Scope

Only Source Intelligence result limiting was changed.

- `sourceIntelligenceMaximumLinks` now normalizes strictly to 25 or 50.
- Missing, legacy, or invalid values default to 25.
- Every incremental published result is capped.
- Network endpoint scanning stops as soon as the selected total is reached, so 25-link mode is materially faster than 50-link mode.
- Final results are capped.
- Provider-filtered searches are capped.
- Cancellation return paths are capped.
- All Providers mode keeps balanced provider ordering within the selected total limit.

## Locked / unchanged

PlaybackKit, KSPlayer, VOD 32/24/16 queue, VOD Exclusive Mode, Cast Wall sleep, alerts, Live TV, Top Shelf, catalogs, scrolling, focus, and artwork behavior are unchanged.
