# Debrid Channels v983 — v982 Base Live TV Select-Hold Menu Fix

Base: v982 CAST WALL SLEEP WHEN OVERLAY HIDDEN.

## Scope

Only the focused Live TV grid-card Select-hold path was changed.

- Replaced the unreliable per-card SwiftUI simultaneous LongPressGesture.
- Added one UIKit UILongPressGestureRecognizer attached to the active tvOS window.
- Restricted the recognizer to the Siri Remote / controller Select press.
- Opens the existing Favorites / Sports action panel after a 0.32-second hold while Select remains down.
- Preserves normal short Select playback.
- Preserves tap suppression after a recognized hold so releasing Select cannot also launch the channel.
- The recognizer is enabled only while a Live TV grid tile owns focus and no other Live TV panel is open.

## Locked and unchanged

- v982 VOD cast-wall sleep/wake behavior
- Episode alerts
- KSPlayer / PlaybackKit
- VOD 32 / 24 / 16 decoded-frame queue
- Live TV playback queue
- Live TV grid focus return and memory lifecycle
- Gracenote Quick Guide
- Top Shelf
- Catalog UI
- Action-panel appearance and Favorites / Sports logic

## Validation

- All 33 Swift sources parse successfully.
- Main and Top Shelf property lists validate.
- Only DebridChannelsTVOSApp.swift and bundle version properties differ from v982, plus this build note.
- Full tvOS SDK compile/link remains the GitHub Actions verification step.
