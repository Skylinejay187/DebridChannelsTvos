# Debrid Channels v934 — v930 Base + Tapframe KSPNUVIO Defaults

Base: DebridChannels v930 Favorites Performance Isolation.

Single dependency migration:
- KSPlayer Swift package URL changed from `https://github.com/kingslay/KSPlayer.git`
  to `https://github.com/tapframe/KSPNUVIO.git` on branch `main`.

The fork keeps the same Swift package/product/module name (`KSPlayer`), so no source imports or target product mappings were changed.

No v931/v932/v933 experiments are included:
- no async-decompression-off test
- no runtime async-decompression switching
- no syncDecodeVideo test
- no clock selection patch
- no buffering or hardware decode changes

All v930 app-side fixes remain intact.
