# DebridChannels v814 / v813 Real Polish Fix

Base: DebridChannels_v813_ADVISORY_COVERAGE_SPOTLIGHT_STABILITY_FIX.zip

Scope:
- Advisory top-right pill now only shows basic user-facing warning facts:
  - Rated R / TV-MA / NC-17 / etc.
  - Content Descriptor: Nudity, Sexual content, Adult scenes, Gore, Scary scenes, Language, Violence, Drug use, etc.
  - Removed duplicate Certification / MPAA Rating / Region Rating rotation from the visible pill.
- VOD overlay Character Spotlight / Cast Wall:
  - Keeps 10 second rotation.
  - Removes the interaction-token reset that could keep rotation paused for the whole overlay session.
  - Uses one active portrait render instead of stacking all cast portraits, reducing video compositing load/glitching.
  - Compacts card size so it feels natural on the overlay.
- Pause behavior:
  - Pause now pins overlay open indefinitely.
  - Resume restarts the normal auto-hide timer.
- Seek behavior:
  - Forward chip/action is explicitly 60 seconds.
  - Back remains 30 seconds.
  - Forward chip label is forced to show Forward 60 / 60.
- VOD overlay sizing:
  - Control chips reduced from 168x104 to 148x92.
  - Spotlight card reduced from 540 width to 430 width.

Do not touch:
- Sports
- Live TV
- Membership
- Source Intelligence
- Backend
- Playback engine selection
