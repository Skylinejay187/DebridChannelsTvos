DebridChannels v865 — v864 Base VOD Overlay Settings Hardware Fix

Base:
- DebridChannels_v864_V863_BASE_VOD_CASTWALL_SETTINGS_ALIGNMENT.zip

Scope:
- VOD overlay settings only.
- No Live TV grid, Guide, scrolling, playback-return focus, or Live TV artwork setting changes.

Changes:
- Hardware Acceleration is now available inside the active VOD playback overlay Settings panel.
- Open VOD overlay -> Settings -> choose:
  - Hardware: Auto
  - Hardware: Force On
  - Hardware: Force Off
- Selection applies immediately while playback is active by saving the selected mode, reopening the active engine, and seeking back to the current playback time.
- Kept the existing Settings -> VOD Player hardware acceleration options too.

Validation:
- Swift parser passed for Sources/DebridChannelsTVOSApp.swift.
