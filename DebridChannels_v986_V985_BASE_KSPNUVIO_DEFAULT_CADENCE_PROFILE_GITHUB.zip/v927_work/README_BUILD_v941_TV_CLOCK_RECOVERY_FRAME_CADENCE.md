# Debrid Channels v941 — TV Clock Recovery + Frame Cadence Isolation

Base: v940, which was built exclusively from locked v938.

Changes:
- First-frame release now uses the seek transaction's own `autoPlay` state instead of a separate `play()` call.
- Re-arms the existing KSPlayer clock gate after the one-shot startup refresh, preventing episodic playback from remaining at 0:00 when KSPlayer does not emit a second ready callback.
- Reduces SwiftUI playback-time publication from 4 Hz to 2 Hz while keeping the internal KSPlayer time current on every callback, reducing periodic main-thread invalidation during video presentation.

No changes to Live TV, Guide, Grid, Focus, Source Intelligence, Favorites, audio selection, subtitle selection/rendering, overlay layout, FFmpeg core, VideoToolbox, or buffer values.
