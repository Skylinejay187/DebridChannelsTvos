# DebridChannels v807 — Sports Harmony + Ticker Match Position Fix

Base: `DebridChannels_v806_REAL_SPORTS_ROW_TICKER_ADVISORY_FIX.zip`

Scope kept intentionally narrow:

- Sports remains the corrected bottom quick-panel row.
- Live TV grid remains rendered behind Sports so the Sports row lives in harmony with the grid instead of feeling like a fullscreen Sports screen.
- Sports fade/background constrained to the lower shelf only.
- Movies/Shows release ticker now uses matched safe-gap placement between the Search/Time top area and the top-right Live TV grid card.
- Global Sports ticker uses the same matched placement logic for consistency.

Left untouched:

- Playback
- Source Intelligence
- Membership
- Backend
- VOD/player internals
