# v863 — v862 Base + Optional Live TV Full Card Artwork

Base: v862 successful build.

Changes only:
- Added Settings option under Live TV Sources: Live TV Card Artwork.
- Frosted Edges (default): preserves the existing v857/v862 artwork path.
- Full Card Artwork: uses one full-card program artwork layer with no frosted side panels or inset center artwork.
- Existing card geometry, rows, focus rings, focus scale, footer, progress, scrolling, Guide, playback and return-focus logic are untouched.

Validation:
- Swift source parse passed with swiftc -parse.
