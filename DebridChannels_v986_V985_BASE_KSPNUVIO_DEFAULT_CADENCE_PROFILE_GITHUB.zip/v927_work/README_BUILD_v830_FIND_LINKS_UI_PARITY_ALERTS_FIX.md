# DebridChannels v830 — Find Links UI Parity + Episode Alert Reliability Fix

Baseline: v829_LINK_CACHE_FAVORITES_FIX.

Scope stayed limited to the reported regressions:

- Fixed Find Links showing zero while Play can still find a best link.
  - Stale/non-stream provider selections now fall back to All Providers instead of silently filtering every result.
  - Any addon that advertises a Stremio `stream` resource is queried; catalog+stream addons are no longer skipped by the old kind gate.
  - If a refresh returns no fresh results, the UI keeps the last cached Source Intelligence links instead of blanking the picker.

- Improved Stremio episode link parity.
  - Exact episode endpoints are still queried first.
  - Parent-series fallback is restored as a second pass with strict S/E title filtering so addons that behave like Stremio can return episode links without showing wrong episodes.

- Hardened episode alerts.
  - Followed shows are hydrated to a resolver-ready identity before scanning episodes.
  - Alert scan window increased from 7 to 14 days to tolerate delayed/UTC addon air-date reporting and missed app-open days.
  - Alert hits use the hydrated show identity/source for more reliable follow detection and display.

Preserved:
- Source Intelligence UI layout.
- VOD overlay geometry.
- Playback engines.
- Backend.
- Home/Live TV/navigation/focus behavior.
