# Debrid Channels v927

Base: v924 playback/render-host implementation, carried through v926 UI branch.

UI-only changes:
- Removed the native tvOS Button wrapper from VOD circular controls to prevent the system rectangular white focus plate.
- Preserved focus and activation with `.focusable`, `@FocusState`, and the existing action closure.
- Constrained the dock to a centered 1510-point maximum width so it ends close to the outer controls instead of spanning nearly the full screen.
- Preserved circular white/gray focus styling, control order, action routing, playback callbacks, and v924 KSPlayer render-host code.
