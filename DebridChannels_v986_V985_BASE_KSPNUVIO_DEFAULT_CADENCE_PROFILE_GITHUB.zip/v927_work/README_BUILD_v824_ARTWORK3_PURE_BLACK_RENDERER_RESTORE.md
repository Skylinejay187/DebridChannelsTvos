# DebridChannels v824 - Artwork 3 Pure Black Renderer Restore

Base: v823

Scope locked:
- Artwork 3 Hero background only.
- Preserve v823 VOD overlay compact/centered chips changes.
- Preserve Pure Black themed logo support.

Fix:
- Removed the custom Artwork 3 ambient wall renderer from the active background path.
- Artwork 3 now keeps the real Live TV grid renderer alive behind Home/Movies/Shows, matching the Pure Black theme rendering path.
- Artwork 3 applies only a dimming layer over the real Live TV grid, so the cards live in harmony with the logo instead of using fake/sample/custom ambient cards.
- Prevented Artwork 3 from using movie row artwork as a backdrop.

Do not touch:
- Sports
- Live TV behavior
- Membership
- Playback engine
- Source Intelligence
- Advisory
- Addon/debrid manager
