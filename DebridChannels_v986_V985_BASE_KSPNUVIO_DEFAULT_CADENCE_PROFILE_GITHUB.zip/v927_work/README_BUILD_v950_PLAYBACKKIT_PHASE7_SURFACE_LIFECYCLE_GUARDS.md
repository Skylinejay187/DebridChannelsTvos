# v950 PlaybackKit Phase 7 — Surface Lifecycle Guards

Built from the confirmed-working v949 Phase 6 archive.

## Added
- Session-scoped render-surface registration leases.
- Stable per-surface UUID validation.
- Explicit registered, activating, active, suspending, suspended, detached, and destroyed lifecycle states.
- Ordered suspend-before-detach teardown.
- Rejection of stale callbacks from a previous playback session or surface.

## Unchanged
- KSPlayer and FFmpeg configuration.
- Decoder, VideoToolbox, buffering, and player lifetime.
- UIView hierarchy, layer hierarchy, layout, visibility, and focus.
- KSPlayerVideoSurface updateUIView and configure behavior.
- Live TV surfaces and playback.
