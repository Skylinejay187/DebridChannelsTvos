# Debrid Channels v981

- Forces GitHub Actions to select the main app scheme first (`00_DebridChannelsTVOS`).
- Embeds and verifies the Top Shelf extension through the main app target.
- Returns bundled Top Shelf poster metadata immediately; network refresh is non-blocking.
- Invalidates Top Shelf cache at app launch and bumps app/extension build version to 513.
- Opens Live TV quick actions during the Select hold using `LongPressGesture.onChanged`.
- Removes the native Button platter by using custom focusable action chips.
- Restores off-screen Live TV cards only after the exact LazyVGrid tile materializes.
- PlaybackKit and VOD settings are unchanged.
