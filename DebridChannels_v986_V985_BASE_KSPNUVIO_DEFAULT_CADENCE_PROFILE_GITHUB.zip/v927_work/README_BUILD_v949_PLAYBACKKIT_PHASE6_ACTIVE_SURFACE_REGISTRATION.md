# v949 PlaybackKit Phase 6 — Active Surface Registration

Base: confirmed-working v948 Phase 5 archive.

## Scope
- Registers the existing non-Live-TV `KSContainerView` weakly with the active session render host.
- Registration occurs from `makeUIView`; unregister occurs from `dismantleUIView`.
- The controller supports creation-order differences by retaining only a weak candidate reference.
- Each session render host reports whether a surface is registered.

## Safety boundaries
- No view reparenting, insertion, removal, layout, visibility, alpha, or layer changes.
- No changes to `updateUIView` or `configure`.
- No KSPlayer, FFmpeg, VideoToolbox, decoder, buffering, clock, subtitle, audio, or first-frame changes.
- Live TV surfaces do not enter this registration path.
