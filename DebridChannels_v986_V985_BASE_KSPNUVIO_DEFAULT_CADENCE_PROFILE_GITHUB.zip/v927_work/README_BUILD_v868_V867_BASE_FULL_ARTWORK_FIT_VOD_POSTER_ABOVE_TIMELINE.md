# DebridChannels v868

Base: v867 compile fix.

Changes only:
- Live TV Full Card Artwork mode now keeps complete artwork visible using a blurred fill backdrop plus an aspect-fit foreground image. This prevents program logos/faces/text from being cropped off while still filling the full card area.
- VOD overlay information stage is lifted so the poster/info starts above the current-time label and progress timeline instead of overlapping the bar.

Untouched:
- Live TV focus/scroll/playback return logic
- Frosted Edges style
- Guide/left tools
- VOD playback engines
- VOD overlay hardware settings flow
