# DebridChannels v867 — v866 Compile Fix

Base: v866.

Fix only:
- Added missing `.liveCardArtworkStyle` handling to the Settings focus down-navigation switch.

No VOD overlay layout changes.
No hardware behavior changes.
No Live TV grid visual/focus/scrolling changes.
