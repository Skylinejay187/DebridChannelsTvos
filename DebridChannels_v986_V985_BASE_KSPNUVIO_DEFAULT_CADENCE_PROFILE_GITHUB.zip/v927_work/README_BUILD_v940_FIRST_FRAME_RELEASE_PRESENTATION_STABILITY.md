# Debrid Channels tvOS/iOS v940

Base: v938 only.

Implemented:
- One-shot, event-driven first-frame presentation release for Movies/TV after KSPlayer `readyToPlay`.
- Checks the attached render host's Core Animation presentation tree before issuing one same-position active-layer seek/queue refresh.
- Preserves timestamp, resume position, requested play/pause state, and the active audio/subtitle selections because the existing KSMEPlayer instance is retained.
- Executes no more than once per URL/reload session; no timer, polling loop, repeated seek, or repeated play calls.
- Keeps `asynchronousDecompression = false` for VOD, `hardwareDecode = true`, and KSMEPlayer locked as both player types.
- Adds only the requested VOD decoder options: `threads=auto`, `thread_type=slice`, `skip_loop_filter=none`.
- Adds only the requested VOD demux values: `reorder_queue_size=1024`, `buffer_size=8388608`, `analyzeduration=10000000`, `probesize=15000000`.

Preserved:
- Live TV settings/path unchanged.
- Source Intelligence, Favorites, render host, geometry/layer/layout freeze, dock, frame-rate matching, buffers, audio/subtitle logic, and overlay unchanged.
