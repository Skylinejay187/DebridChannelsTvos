# v805 — Ticker Visibility + Search Focus + Sports Minimal Row Fix

Scoped fixes from v804:

- Restored movie/show ticker visibility by fixing the mismatched safe-gap guard.
- Kept ticker close to the top-right Live TV card with a small non-overlap gap.
- Applied same guard fix to compact sports ticker.
- Hardened the search icon focus rendering to remove the white system focus square.
- Replaced the active Sports route with a minimal one-row quick-panel surface so the old fullscreen-style sports layout is not active.

No playback, Source Intelligence, membership, Live TV guide/cache, backend, or media info changes.
