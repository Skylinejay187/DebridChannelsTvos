# DebridChannels v819 — Artwork 3 Ghosting Layer Cleanup

Base: v818 `DebridChannels_v818_ARTWORK3_HERO_LOGO_AMBIENT_WALL_ONLY`

Scope locked to Artwork Hero 3 only.

Changes:
- Removed catalog/movie/show row artwork reuse from Artwork Hero 3 ambient background.
- Replaced the ghosting-prone ambient row-art layer with a quiet Live TV-style tile wall.
- Kept one dark overlay stack above the ambient wall so the logo remains the main subject.
- Kept existing rows unchanged: no brightness, spacing, geometry, focus, or animation changes.
- Did not touch other artwork themes, playback, Sports, Live TV, Membership, advisory, source intelligence, or backend.

Purpose:
- Fix visible ghosting/bleed of previous/current artwork rows in the Artwork Hero 3 background.
