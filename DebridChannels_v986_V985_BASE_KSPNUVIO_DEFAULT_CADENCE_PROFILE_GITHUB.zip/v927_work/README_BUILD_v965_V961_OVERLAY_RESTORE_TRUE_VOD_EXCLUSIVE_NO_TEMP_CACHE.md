# Debrid Channels v965

Base lineage: **v961 Full Flixor VOD Parity + Clock Pill**.

This build restores the complete v961 VOD overlay behavior while cherry-picking the non-visual playback-exclusive work cancellation from v963/v964.

## Restored exactly from v961
- VOD bottom chrome remains mounted and uses its original opacity/focus/auto-hide behavior.
- Cast wall remains part of the normal VOD information stage and is not gated or disabled.
- Clock pill, progress rail, poster, chips, settings panels, focus navigation, and overlay reopening behavior use the v961 path.
- Main VOD decoded-frame queue is restored to 32 frames for 4K, 24 for 1080p, and 16 below 1080p.
- tvOS display matching remains the v961 Flixor-parity automatic/native-content path; no forced 60 Hz test is included.

## Retained from the v963/v964 audit
- Full-screen VOD removes catalog, Live TV, Sports, Favorites, Settings, and detail screens from the active render tree.
- Source Intelligence resolver/network work is cancelled and blocked while VOD is active.
- Catalog/detail/trailer/sports/entitlement/artwork prefetch and non-alert work are cancelled and blocked during VOD.
- Repeated delayed KSPlayer track scans/play nudges are trailer-only.
- MPV/libmpv remains completely removed from source, project, scripts, and vendor files.
- New-episode alerts remain active and visible during playback.

## Temporary VOD cache removed
The custom 5GB / 10GB / Unlimited proxy-cache implementation is removed entirely:
- no TemporaryVODCache source file
- no cache session/proxy startup
- no cache settings or overlay menu options
- no cache project source entry

The existing VOD status pill keeps the v961 overlay geometry and now reports `Direct Stream`.
