# v895 — v894 base — KSPlayer embedded track renderer path

- Keeps v894 as the base.
- Preserves the real KSPlayer audio/subtitle track discovery and explicit selection/flush path.
- Keeps VOD on the project's compiled FFmpeg-backed KSMEPlayer path rather than inventing an unavailable FFPlayer type.
- Enables embedded subtitle pipeline for VOD.
- Fixes the custom chrome stripper so it no longer hides KSPlayer subtitle/caption renderer views.
- Promotes discovered subtitle renderer views above the video surface without making them focusable.
- No Live TV, guide, grid, catalog, VOD geometry, Source Intelligence, or AVPlayer logic changes.
