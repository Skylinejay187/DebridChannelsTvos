# Debrid Channels v938 — Tapframe Blueprint Playback Profile

Base: v936
KSPlayer: Tapframe KSPNUVIO

Applied to KSPlayer VOD/trailer sessions:
- KSMEPlayer locked as primary and secondary engine
- VideoToolbox hardware decode enabled
- 10-second preferred forward buffer
- 30-second maximum buffer
- second-open enabled
- accurate seek retained
- decoder threads set to auto
- asynchronous decompression disabled
- tvOS AVDisplayCriteria frame-rate/dynamic-range matching enabled for full-screen VOD

Preserved:
- Live TV rolling buffer and async decompression path
- Source Intelligence recovery
- Favorites isolation
- v930/v924 render-host optimizations
- dock appearance setting

Excluded:
- syncDecodeVideo
- syncDecodeAudio
- video-master mainClock patch
- fflags=nobuffer for VOD
- infinite_buffer
- framedrop
- thread_type=slice
