# v903 — v902 base / KSPlayer instant open + subtitle mount + clock gate

- Removes blocking 3.5 second HEAD preflight before opening already-resolved direct debrid links.
- Keeps existing alternate URL fallback for real playback failures.
- No KVC or undefined-key probing.
- Finds KSPlayer-created subtitle/caption UIView descendants and mounts the actual renderer at the KS container top level on every layout pass.
- Keeps subtitle renderer full-screen, visible, and above the video surface while remaining below SwiftUI VOD chrome.
- Freezes visible KSPlayer time during non-ready states, explicit track flushes, and the short ready-to-first-frame handoff.
- Preserves v898/v902 working audio switching.
- No Live TV/grid/guide/VOD layout/focus/scrolling/chip changes.
