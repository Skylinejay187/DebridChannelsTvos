from pathlib import Path
import plistlib
root=Path(__file__).resolve().parents[1]
play=(root/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
assert 'isVODStylePlayback ? 300 : (!isLiveStream ? 90 : 12)' in play
assert 'isHighMemoryVOD ? 3 : (isVODStylePlayback ? 5' in play
proj=(root/'project.yml').read_text()
assert 'MARKETING_VERSION: 1.0.764' in proj
assert 'CURRENT_PROJECT_VERSION: 764' in proj
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with open(root/rel,'rb') as f: p=plistlib.load(f)
    assert p['CFBundleShortVersionString']=='1.0.764'
    assert p['CFBundleVersion']=='764'
    assert p['DebridChannelsReleaseID']=='vBRDC061'
print('PASS vBRDC061 contract')
