from pathlib import Path
import hashlib
import plistlib
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
COORD = (ROOT / 'Sources/UnityAnimationCoordinator.swift').read_text()
UNIVERSAL = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()
FOUNDATION = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []


def ck(name, cond):
    checks.append((name, bool(cond)))


def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]


app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC087', app_plist.get('DebridChannelsReleaseID') == 'vBRDC087' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC087')
ck('marketing version 1.0.790', app_plist.get('CFBundleShortVersionString') == '1.0.790' and top_plist.get('CFBundleShortVersionString') == '1.0.790')
ck('build version 790', app_plist.get('CFBundleVersion') == '790' and top_plist.get('CFBundleVersion') == '790')
ck('project marketing 1.0.790', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.790')
ck('project build 790', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '790')

# Single artwork-owner invariant.
art_gate = section(APP, 'private var connectedPopupArtworkLayerAllowed', '// v1051: Keep the optional artwork layer')
ck('connected popup artwork requires setting enabled', 'connectedMediaPopupArtworkEnabled' in art_gate)
ck('connected popup artwork is catalog-only', 'connectorOrigin == .catalog' in art_gate)

popup_background = section(APP, 'private var popupPanelBackground', 'private var popupPanelDissolvingShadow')
ck('popup background uses single-owner gate', 'if connectedPopupArtworkLayerAllowed' in popup_background)
ck('popup background never directly gates on raw setting', 'if connectedMediaPopupArtworkEnabled' not in popup_background)
ck('popup still uses one contained artwork host', popup_background.count('RemoteImageFit(') == 1)

popup_layer = section(APP, 'private var popupPanelLayer', '@ViewBuilder\n    private var popupPanelBackground')
ck('popup artwork animation observes scoped gate', 'value: connectedPopupArtworkLayerAllowed' in popup_layer)

popup_dim = section(APP, 'private var popupDimLayer', 'private var popupPanelLayer')
ck('Search retains one cinematic selected-title backdrop', 'if connectorOrigin == .search' in popup_dim and 'VBRDC020SearchCinematicMediaInformationStage' in popup_dim and 'RemoteImageFit(url: backdropURL' in popup_dim)
ck('Favorites retains local underlying backdrop without popup art', 'else if connectorOrigin == .favorites' in popup_dim and 'V1088FavoritesLocalPopupBackdrop' in popup_dim)
ck('settings copy documents single-owner Search/Favorites behavior', 'Search and Favorites already own one selected-title backdrop' in APP)

favorites_screen = section(APP, 'struct GlobalFavoritesScreen: View', 'struct FavoriteLiveChannelCard: View')
ck('Favorites screen owns its own selected backdrop', 'selectedFavoriteBackdropURL' in favorites_screen and 'RemoteImageFit(url: artworkURL, mode: .fill)' in favorites_screen)

# Animation isolation invariant: detail/source overlay owns scale-transform budget.
rail = section(APP, 'struct GridOSFixedSlotCatalogRail: View', 'private var cardIsVisuallyFocused')
pulse_gate = section(rail, 'private var coordinatedPulseAnimation', 'private var cardIsVisuallyFocused')
ck('rail pulse requires no selected detail', 'store.selectedDetail == nil' in pulse_gate)
ck('rail pulse still requires user setting', 'focusedCardPulseAnimationEnabled' in pulse_gate)
ck('rail pulse still requires UNITY permit', 'unityAnimations.allows(.catalogPulse)' in pulse_gate)

coord_pulse = section(COORD, 'case .catalogPulse:', 'case .catalogFocusArrival')
coord_preview = section(COORD, 'case .catalogPreview:', 'case .catalogPulse:')
ck('UNITY pulse yields to Media Information', '!context.detailActive' in coord_pulse)
ck('UNITY preview remains independent of detail scale isolation', '!context.detailActive' not in coord_preview)
ck('UNITY preview still blocked by global Search', '!context.globalSearchActive' in coord_preview)
ck('UNITY source opening remains exclusive', 'if sourceOpeningActive' in COORD and 'return feature == .overlayChrome || feature == .alertMotion' in COORD)

fixed_card = section(APP, 'struct FixedSlotFocusedCatalogCard: View', 'struct FixedSlotPreviewCatalogCard')
update_pulse = section(fixed_card, 'private func updateSlowFocusedPulse', 'private func replaySearchStyleFocusArrival')
ck('pulse reset disables animation before yielding', 'reset.disablesAnimations = true' in update_pulse and 'slowPulseExpanded = false' in update_pulse)
ck('pulse is transform-only', '.scaleEffect(focused && coordinatedPulseEnabled && slowPulseExpanded ? 1.015 : 1.0)' in fixed_card)

preview_scheduler = section(APP, 'private func scheduleFocusedCardPreview', 'private func finishFocusedCardPreview')
ck('same preview instance survives catalog detail when already ready', 'focusedCardPreviewKey == requestedKey' in preview_scheduler and 'focusedCardPreviewPresentationAllowed(for: item)' in preview_scheduler)
ck('preview uses UNITY preview permit, not pulse permit', 'unityAnimations.allows(.catalogPreview)' in preview_scheduler and 'unityAnimations.allows(.catalogPulse)' not in preview_scheduler)

# vBRDC086 Favorites identity lock remains intact.
hero_gate = section(APP, 'private var catalogMayUseDetailPresentationAnchor', 'private var rowFocusedBackdropItem')
ck('catalog hero still rejects favorites origin', 'store.detailPresentationOrigin != .favorites' in hero_gate)
ck('catalog hero still rejects favorites restore owner', 'store.quickPanelRestoreSection != "favoritesCatalog"' in hero_gate)
close_favorites = section(APP, 'private func closeFavoritesSurface()', 'private func scheduleFavoritesCacheRebuild')
ck('Favorites exit still scrubs identity before Home', close_favorites.find('clearFavoritesPresentationStateForNavigation') < close_favorites.find('store.selectedTab = .home'))

# vBRDC085 resume/autoplay and Production decoupling locks remain intact.
ck('VOD explicit KS play assertion serial preserved', '@State private var ksPlayAssertionSerial = 0' in APP)
confirm = section(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
ck('automatic resume still emits KS Play assertion', 'ksPlayAssertionSerial &+= 1' in confirm)
ck('UniversalVideoSurface still forwards play assertion', 'playAssertionSerial: ksPlayAssertionSerial' in UNIVERSAL)
ck('PlaybackKit host still forwards play assertion', 'playAssertionSerial: playAssertionSerial' in FOUNDATION)
play_assert = section(KS, 'if coordinator.lastPlayAssertionSerial != playAssertionSerial', '// v408: KSPlayer can crash')
ck('KS surface still calls layer.play for assertion', 'layer.play()' in play_assert)
ck('KS resume liveness recovery remains bounded', 'let delays: [TimeInterval] = [0.32, 0.52, 0.82, 1.18]' in KS)
production_loader = section(APP, 'private func loadVODProductionMetadata(', 'private func showVODCastExplorerOnboardingIfNeeded')
ck('Production remains first-frame gated', 'isFirstFrameReady' in production_loader)
ck('Production remains independent from pause', '!isPlaying' not in production_loader)
ck('Production remains background priority', 'Task(priority: .background)' in production_loader)

# Sensitive systems not targeted in vBRDC087 stay exact packaged-v086 bytes.
BASE_HASHES = {
    'Sources/CatalogStore.swift': '07d1bd218cdf3315298496ff7dd57d11ef15a102a943989f2312cef3c22ac5df',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
    'Sources/UnityCatalogVisualSystem.swift': 'cc954cb07319a98dd288eadea8a4976514d9bccad5b78134bc939d18613799c4',
    'Sources/UniversalCodecSupport.swift': 'b315a3fb05c7115f94c70234827b15af8be2e502efaa8398d9413a20dee191d7',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift': 'cd22fb911d06af7b4b4d103c8007b14c168ef80e21451253d514c0f1b5f2cdaf',
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift': '9fabac610a23f7d96ecd8dc4eca7e680986bb3bc8734cbc75fa1cb4655b483db',
}
for rel, expected in BASE_HASHES.items():
    ck('v086 donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
