from pathlib import Path
import plistlib, hashlib

root = Path(__file__).resolve().parents[1]
donor = Path('/mnt/data/v66work/DebridChannels_vBRDC066_UNITY_VISUAL_FRANCHISE_SEARCH_FIX_GITHUB')
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
visual = (root/'Sources/UnityCatalogVisualSystem.swift').read_text()
proj = (root/'project.yml').read_text()

# Release contract.
assert 'MARKETING_VERSION: 1.0.770' in proj
assert 'CURRENT_PROJECT_VERSION: 770' in proj
for rel in ['Sources/Info.plist', 'TopShelfExtension/Info.plist']:
    with open(root/rel, 'rb') as f:
        p = plistlib.load(f)
    assert p['CFBundleShortVersionString'] == '1.0.770'
    assert p['CFBundleVersion'] == '770'
    assert p['DebridChannelsReleaseID'] == 'vBRDC067'

# Card chrome: decorative status-like marks are gone, glass frame remains.
card = visual.split('struct UnityCatalogCardChrome: View {', 1)[1].split('struct UnityCatalogHeroAura: View {', 1)[0]
assert 'RoundedRectangle(cornerRadius:' in card
assert '.strokeBorder(' in card
assert 'specular' in card.lower()
assert 'Capsule()' not in card
assert 'Circle()' not in card
assert '.frame(height: focused ? 1.4 : 0.7)' not in card
assert 'unexplained playback or cache indicators' in card

# Franchise: preserve complete art, expose title text, retain compact upward animation.
assert 'UnityCompactFranchiseRibbon' in visual
assert 'RemoteImageFit(url: franchiseItem.posterURL ?? franchiseItem.landscapeURL, mode: .fit' in visual
assert 'RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fit' in visual
assert 'Text(item.title)' in visual
assert 'Text(item.year)' in visual
assert '.frame(width: 808, height: 150, alignment: .leading)' in visual
assert '.offset(y: -100)' in visual
assert '.frame(width: 808, height: 66, alignment: .bottomLeading)' in visual

# Preview video itself remains, badge is gone.
assert 'FocusedCardPreviewSurface(' in app
assert 'inlinePreviewIsPlaying' in app
assert 'PREVIEW 🍿' not in app
assert 'focused-card preview video is self-explanatory' in app

# vBRDC066 Search/franchise regressions remain fixed.
for token in [
    'store.recoverCatalogInteractivity(reason: "Search appeared")',
    'store.recoverCatalogInteractivity(reason: "Search returned from playback")',
    '.onChange(of: store.playbackURL?.absoluteString)',
    'franchiseItems: currentDetail.franchiseItems.isEmpty ? hydrated.franchiseItems : currentDetail.franchiseItems',
    'UnityCompactFranchiseRibbon(',
]:
    assert token in app

# vBRDC065 XMLTV watchdog fix remains.
for token in [
    'private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) async',
    'Task.detached(priority: .utility)',
    'LiveTVXMLTVBackgroundParser.parse(',
    'withTaskCancellationHandler',
    'worker.cancel()',
]:
    assert token in app

# Playback/KSP/provider/core state remains byte-identical to vBRDC066.
locked = [
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift',
    'Sources/UniversalCodecSupport.swift',
    'Sources/TorBoxUsenetClient.swift',
    'Sources/CatalogStore.swift',
    'Sources/UnitySurfaceSystem.swift',
    'Sources/LocalIntroDetectionEngine.swift',
    'Sources/PlaybackStateManager.swift',
    'Sources/VODExclusivePlaybackGate.swift',
    'Scripts/fetch_patch_kspnuvio_vBRDC064.sh',
    'Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py',
    'BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py',
]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for rel in locked:
    assert sha(root/rel) == sha(donor/rel), rel

print('PASS vBRDC067 contract')
