# Debrid Channels vBRDC111 — Bluetooth VOD Media Controls

- Marketing version: **1.0.814**
- Apple build: **814**
- Donor: **vBRDC110**

## Scope
Adds an opt-in/out VOD media-button bridge for connected Bluetooth/external media accessories while preserving the existing Siri Remote path.

## Behavior
- New **Bluetooth Media Play/Pause** setting in Settings → VOD Player and in the in-playback Playback Settings panel.
- Default: **On**.
- Registers system `Play`, `Pause`, and `Toggle Play/Pause` commands through `MPRemoteCommandCenter`.
- The bridge is enabled only while a movie/show VOD presentation owns playback.
- Live TV, catalog previews, trailers outside the VOD owner, navigation, and idle app surfaces do not claim this bridge.
- Dedicated Pause only pauses an actively playing VOD; dedicated Play only resumes a paused VOD; Toggle switches state.
- 180 ms duplicate-event guard prevents one physical accessory press from toggling twice when an accessory is delivered through both the system media-command path and SwiftUI's existing Play/Pause path.
- Existing VOD guards remain authoritative for Cast Explorer, episode switching, and other modal playback ownership.
- Preference is included in the protected backup/restore allowlist.

## Regression scope
No catalog scrolling/theme files, Live TV source/bootstrap files, Gracenote logic, MediaFlow Proxy, VOD cast/production rotation, Dynamic Wallpaper, provider resolution, or resume logic were modified.
