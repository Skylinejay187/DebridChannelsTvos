from pathlib import Path
import re, hashlib

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources' / 'DebridChannelsTVOSApp.swift').read_text()
PROJECT = (ROOT / 'project.yml').read_text()
APP_PLIST = (ROOT / 'Sources' / 'Info.plist').read_text()
TOP_PLIST = (ROOT / 'TopShelfExtension' / 'Info.plist').read_text()

EXPECTED = [
    'Digital Rain','Emerald Code','Cyber Rain','Falling Stars','Deep Galaxy','Warp Space',
    'Cosmic Dust','Aurora','Meteor Shower','Black Hole','Constellations','Neon Grid',
    'Data Grid','Electric Storm','Fire Embers','Snowfall','Rain on Glass','Underwater',
    'OLED Particles','Spotlight Smoke','Cinematic Smoke','Cinema Projector','Black Velvet Smoke',
    'OLED Cinema','Midnight Smoke'
]

checks = []
def check(name, condition):
    checks.append((name, bool(condition)))

# Release identity
check('release id', 'vBRDC079' in APP_PLIST and 'vBRDC079' in TOP_PLIST)
check('marketing version', '1.0.782' in PROJECT and '1.0.782' in APP_PLIST and '1.0.782' in TOP_PLIST)
check('build number', 'CURRENT_PROJECT_VERSION: 782' in PROJECT and '<string>782</string>' in APP_PLIST)

# Curated theme system
style_scope = APP[APP.index('struct DynamicMainGridWallpaperStyle {'):]
m = re.search(r'static let presets = \[(.*?)\]\n\n    static func normalized', style_scope, re.S)
found = re.findall(r'"([^"]+)"', m.group(1)) if m else []
check('25 curated presets', found == EXPECTED)
for theme in EXPECTED:
    check(f'theme present: {theme}', theme in APP)
check('legacy normalization', 'static func normalized(_ raw: String)' in APP and 'return "Cinematic Smoke"' in APP)
check('digital rain renderer', 'drawDigitalRain(' in APP and 'design: .monospaced' in APP)
check('space renderers', all(token in APP for token in ['drawWarpSpace(', 'drawGalaxy(', 'drawMeteorShower(', 'drawBlackHole(']))
check('atmospheric renderers', all(token in APP for token in ['drawAurora(', 'drawSnow(', 'drawRainOnGlass(', 'drawUnderwater(']))
check('grid renderers', 'drawPerspectiveGrid(' in APP and 'drawDataParticles(' in APP)

# Custom animated wallpaper contract
check('custom toggle storage', '@AppStorage("dynamicMainGridWallpaperCustomEnabledV1")' in APP)
check('custom url storage', '@AppStorage("dynamicMainGridWallpaperCustomURLV1")' in APP)
check('custom settings controls', 'Custom Animated Wallpaper URL' in APP and 'dynamicWallpaperCustomURL' in APP)
check('https only', 'remoteURL.scheme?.lowercased() == "https"' in APP)
check('32 MB cap', '32 * 1024 * 1024' in APP)
check('supported formats', all(ext in APP for ext in ['"gif"', '"webp"', '"mp4"', '"mov"', '"m4v"']))
check('local cache', 'DebridChannelsDynamicWallpaper' in APP and 'URLSession.shared.download(for: request)' in APP)
check('video is muted', 'player.isMuted = true' in APP)
check('video loops', 'AVPlayerLooper(player: player, templateItem: item)' in APP)
check('animated frame budget', 'frameLimit = VisualPerformanceProfile.normalized(performanceMode)' in APP and 'maxPixel = VisualPerformanceProfile.normalized(performanceMode)' in APP)
check('custom falls back built-in', 'if customEnabled, let cachedCustomURL' in APP and 'DynamicSmokeWallpaper(style:' in APP)
check('custom in profile backup', '"dynamicMainGridWallpaperCustomEnabledV1": dynamicMainGridWallpaperCustomEnabled' in APP and '"dynamicMainGridWallpaperCustomURLV1": dynamicMainGridWallpaperCustomURL' in APP)
check('custom reset off', 'dynamicMainGridWallpaperCustomEnabled = false' in APP and 'dynamicMainGridWallpaperCustomURL = ""' in APP)

# Critical playback isolation remains unchanged in ownership gate and custom renderer mounts only inside it.
check('playback hard gate', '&& store.playbackURL == nil' in APP)
check('detail hard gate', '&& store.selectedDetail == nil' in APP)
check('guide hard gate', '&& !showGuide' in APP)
check('search hard gate', '&& !store.searchActive' in APP)
check('surface mount under budget', 'if liveWallpaperOwnsRenderBudget' in APP and 'DynamicWallpaperSurface(' in APP)

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit('Failed: ' + ', '.join(failed))
