# vBRDC115 regression locks

1. MediaFlow OFF must preserve the original direct Live TV bootstrap request.
2. MediaFlow ON must never use `/proxy/forward` for ordinary Live TV GET bootstrap.
3. Channels DVR, HDHomeRun, M3U and Xtream bootstrap GETs route through `/proxy/stream`.
4. XMLTV/Gracenote prefers `/proxy/epg`, with `/proxy/stream` as the compatibility fallback.
5. Invalid MediaFlow configuration fails closed.
6. Destination Accept/User-Agent headers are encoded as MediaFlow `h_*` upstream headers.
7. Final channel playback and Live TV focused-card preview remain on the dedicated `.liveTV` playback wrapper.
8. Successful Live TV provider results retain vBRDC110's durable publication behavior.
9. vBRDC103+ row scrolling, vBRDC109 catalog transition, vBRDC106 VOD overlay rotation, vBRDC107 focused preview ownership, and vBRDC111+ Bluetooth VOD media controls must remain present.
