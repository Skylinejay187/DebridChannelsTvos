from pathlib import Path
import hashlib, plistlib, unittest

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
BRIDGE = (ROOT/'Sources'/'DebridCredentialBridge.swift').read_text()
MANAGED = (ROOT/'Sources'/'ManagedAddonBridge.swift').read_text()
CATALOG = (ROOT/'Sources'/'CatalogStore.swift').read_text()
SOURCE = (ROOT/'Sources'/'SourceIntelligenceManager.swift').read_text()
TORBOX = (ROOT/'Sources'/'TorBoxUsenetClient.swift').read_text()
SEC = (ROOT/'Sources'/'ReleaseCandidateSecurityManager.swift').read_text()
STABLE = (ROOT/'Sources'/'StableFeatureGateManager.swift').read_text()
YML = (ROOT/'project.yml').read_text()

class Contract(unittest.TestCase):
    def test_01_version(self):
        for p in [ROOT/'Sources'/'Info.plist', ROOT/'TopShelfExtension'/'Info.plist']:
            d = plistlib.loads(p.read_bytes())
            self.assertEqual(d['CFBundleShortVersionString'], '1.0.778')
            self.assertEqual(d['CFBundleVersion'], '778')
            self.assertEqual(d['DebridChannelsReleaseID'], 'vBRDC075')
        self.assertEqual(YML.count('MARKETING_VERSION: 1.0.778'), 2)
        self.assertEqual(YML.count('CURRENT_PROJECT_VERSION: 778'), 2)

    def test_02_bridge_setting_exists_and_is_passed_to_torbox(self):
        self.assertIn('@AppStorage("torBoxUsenetBridgeManifestURLV1")', APP)
        self.assertIn('UserDefaults.standard.string(forKey: "torBoxUsenetBridgeManifestURLV1")', CATALOG)
        call = CATALOG[CATALOG.index('TorBoxUsenetClient.search('):CATALOG.index('TorBoxUsenetClient.search(')+1800]
        self.assertIn('bridgeManifestURL: bridgeManifestURL', call)

    def test_03_whitelisted_bridge_is_first_discovery_route(self):
        block = TORBOX[TORBOX.index('static func search('):TORBOX.index('private static func searchNewznabDirect')]
        self.assertLess(block.index('searchViaConfiguredBridge'), block.index('searchNativeVoyagerDirect'))
        self.assertLess(block.index('searchNativeVoyagerDirect'), block.index('searchViaBackendRelay'))
        self.assertLess(block.index('searchViaBackendRelay'), block.index('searchNewznabDirect'))

    def test_04_bridge_never_receives_debrid_api_key(self):
        sig = TORBOX[TORBOX.index('private static func searchViaConfiguredBridge('):TORBOX.index(') async throws -> [TorBoxUsenetSearchResult]', TORBOX.index('private static func searchViaConfiguredBridge('))+1]
        self.assertNotIn('apiKey', sig)
        body = TORBOX[TORBOX.index('private static func searchViaConfiguredBridge('):TORBOX.index('private static func bridgeStreamIDs')]
        self.assertNotIn('Authorization', body)
        self.assertNotIn('Bearer', body)
        self.assertNotIn('api_key', body)

    def test_05_bridge_normalizes_stremio_and_requires_https(self):
        body = TORBOX[TORBOX.index('private static func searchViaConfiguredBridge('):TORBOX.index('private static func bridgeStreamIDs')]
        self.assertIn('clean.lowercased().hasPrefix("stremio://")', body)
        self.assertIn('return "https://"', body)
        self.assertIn('manifest.scheme?.lowercased() == "https"', body)
        self.assertIn('/manifest.json', body)

    def test_06_bridge_builds_stremio_movie_series_stream_resource(self):
        body = TORBOX[TORBOX.index('private static func searchViaConfiguredBridge('):TORBOX.index('private static func isSeriesItem')]
        self.assertIn('let mediaType = isSeriesItem(item) ? "series" : "movie"', body)
        self.assertIn(r'/stream/\(mediaType)/\(encodedID).json', body)
        ids = TORBOX[TORBOX.index('private static func bridgeStreamIDs'):TORBOX.index('private static func isSeriesItem')]
        for token in ['item.imdbId', 'tmdb:', 'tvdb:', 'seasonNumber', 'episodeNumber']:
            self.assertIn(token, ids)

    def test_07_bridge_maps_only_direct_http_streams(self):
        body = TORBOX[TORBOX.index('private static func searchViaConfiguredBridge('):TORBOX.index('private static func bridgeStreamIDs')]
        self.assertIn('stream.url ?? stream.externalUrl', body)
        self.assertIn('["http", "https"]', body)
        self.assertIn('directPlaybackURL: direct', body)
        self.assertIn('AIOStreams TorBox Search Bridge', body)

    def test_08_direct_bridge_results_stay_in_usenet_lane(self):
        self.assertIn('var torBoxUsenetBridgeDirect: Bool = false', CATALOG)
        candidate = CATALOG[CATALOG.index('var isTorBoxUsenetCandidate'):CATALOG.index('var isDirectPlayable')]
        self.assertIn('torBoxUsenetBridgeDirect ||', candidate)
        marker = CATALOG.index('torBoxUsenetBridgeDirect: !result.directPlaybackURL.isEmpty')
        mapping = CATALOG[marker-900:marker+300]
        self.assertIn('url: result.directPlaybackURL.isEmpty ? nil : result.directPlaybackURL', mapping)

    def test_09_bridge_direct_result_resolves_without_nzb_roundtrip(self):
        resolve = TORBOX[TORBOX.index('static func resolve('):]
        self.assertIn('if !result.directPlaybackURL.isEmpty', resolve)
        self.assertIn('return direct', resolve)

    def test_10_unconfigured_bridge_cannot_fall_back_to_fake_zero(self):
        block = TORBOX[TORBOX.index('static func search('):TORBOX.index('private static func searchViaConfiguredBridge')]
        self.assertIn('if completedDiscoveryRoute {', block)
        self.assertIn('if cleanBridge.isEmpty', block)
        self.assertIn('TorBox Search is IP-whitelisted by TorBox', block)
        self.assertIn('TorBox Pro Search Bridge', block)

    def test_11_owned_library_does_not_mask_search_failure(self):
        block = TORBOX[TORBOX.index('static func search('):TORBOX.index('private static func searchViaConfiguredBridge')]
        owned = block[block.index('let owned = try await searchOwnedLibrary'):block.index('if completedDiscoveryRoute')]
        self.assertNotIn('completedDiscoveryRoute = true', owned)

    def test_12_torbox_failure_is_visible_in_source_intelligence_empty_state(self):
        self.assertIn('sourceIntelligenceBatchStatus = torBoxStatus.message', CATALOG)
        self.assertIn('lastStreamMessage = torBoxStatus.message', CATALOG)

    def test_13_usenet_lane_remains_uncapped(self):
        start = CATALOG.index('func cappedRankedLinks(_ links: [StreamLink])')
        end = CATALOG.index('func publishBatch', start)
        block = CATALOG[start:end]
        self.assertIn('links.filter(\\.isTorBoxUsenetCandidate)', block)
        self.assertIn('return usenetLinks', block)
        self.assertIn('cappedOrdinary + usenetLinks', block)
        self.assertNotIn('Array(usenetLinks.prefix', block)

    def test_14_connector_line_toggle_is_persistent_and_controls_render_and_delay(self):
        self.assertGreaterEqual(APP.count('@AppStorage("mediaInfoConnectorLineEnabledV1")'), 2)
        self.assertIn('title: "Media Information Connector Line"', APP)
        self.assertIn('if connectorOrigin == .catalog && mediaInfoConnectorLineEnabled', APP)
        present = APP[APP.index('private func presentPremiumConnector'):APP.index('// Reset both stages without animation', APP.index('private func presentPremiumConnector'))]
        self.assertIn('!mediaInfoConnectorLineEnabled', present)
        self.assertIn('StableUIDefault(key: "mediaInfoConnectorLineEnabledV1", value: true)', STABLE)

    def test_15_top_left_logo_toggle_is_persistent_and_controls_wordmark(self):
        self.assertGreaterEqual(APP.count('@AppStorage("topLeftDebridChannelsLogoEnabledV1")'), 2)
        self.assertIn('title: "Top-Left Debrid Channels Logo"', APP)
        start = APP.index('struct TopMenuBar')
        top = APP[start:start+12000]
        self.assertIn('if topLeftDebridChannelsLogoEnabled', top)
        self.assertIn('DebridChannelsChromeWordmark()', top)
        self.assertIn('StableUIDefault(key: "topLeftDebridChannelsLogoEnabledV1", value: true)', STABLE)

    def test_16_new_settings_participate_in_backup_restore_and_security_boundary(self):
        for key in ['torBoxUsenetBridgeManifestURLV1', 'mediaInfoConnectorLineEnabledV1', 'topLeftDebridChannelsLogoEnabledV1']:
            self.assertGreaterEqual(APP.count(f'"{key}"'), 3)
            self.assertIn(f'"{key}"', SEC)
        # The manifest is credential-like and must be scrubbed from fresh install state.
        fresh = SEC[SEC.index('private static func enforceFreshInstallCredentialBoundary'):SEC.index('/// Runs before CatalogStore reads persisted manifests')]
        self.assertIn('torBoxUsenetBridgeManifestURLV1', fresh)

    def test_17_fanart_key_is_live_again(self):
        keyfunc = CATALOG[CATALOG.index('private func fanartTVApiKey()'):CATALOG.index('private func fetchFanartArtwork')]
        self.assertIn('UserDefaults.standard.string(forKey: "fanartTvApiKey")', keyfunc)
        self.assertNotIn('return ""', keyfunc)
        fetch = CATALOG[CATALOG.index('private func fetchFanartArtwork'):CATALOG.index('private func applyPremiumFanartArtwork')]
        self.assertNotIn('disabled for v711 stability', fetch.lower())
        self.assertIn('webservice.fanart.tv/v3', fetch)

    def test_18_detail_artwork_uses_rotating_pool_not_single_cached_url(self):
        self.assertIn('private var detailPremiumBackdropSessionCache: [String: [String]] = [:]', CATALOG)
        self.assertIn('private var detailPremiumBackdropRotationCursor: [String: Int] = [:]', CATALOG)
        rotate = CATALOG[CATALOG.index('private func nextPremiumDetailBackdrop'):CATALOG.index('private func schedulePremiumDetailArtwork')]
        self.assertIn('detailPremiumBackdropRotationCursor', rotate)
        self.assertIn('(index + 1) % pool.count', rotate)

    def test_19_detail_artwork_uses_fanart_backend_tmdb_concurrently(self):
        pool = CATALOG[CATALOG.index('private func resolvePremiumDetailBackdropPool'):CATALOG.index('private func nextPremiumDetailBackdrop')]
        self.assertIn('async let fanart', pool)
        self.assertIn('async let backend', pool)
        self.assertIn('async let tmdb', pool)
        self.assertIn('let pools = [fanartResults, backendResults, tmdbResults]', pool)
        self.assertIn('for pool in pools where index < pool.count', pool)
        direct = CATALOG[CATALOG.index('private func directFanartDetailBackdrops'):CATALOG.index('private func tmdbPremiumDetailBackdrops')]
        self.assertIn('fanartTVApiKey()', direct)
        self.assertIn('item.tmdbId', direct)
        self.assertIn('item.tvdbId', direct)

    def test_20_backend_artwork_pool_prioritizes_non_default_providers(self):
        block = CATALOG[CATALOG.index('private func backendPremiumDetailBackdrops'):CATALOG.index('private func directFanartDetailBackdrops')]
        self.assertIn('source.contains("fanart") { return 0 }', block)
        self.assertIn('source.contains("tvdb") { return 1 }', block)
        self.assertIn('source.contains("tmdb") { return 2 }', block)
        self.assertIn('artworkPool', block)

    def test_21_shared_source_session_is_still_not_invalidated(self):
        self.assertNotIn('sourceIntelligenceURLSession.invalidateAndCancel()', CATALOG)
        rotate = CATALOG[CATALOG.index('private func rotateSourceIntelligenceURLSession()'):CATALOG.index('private func cancelActiveSourceProviderTasks()')]
        self.assertIn('retiringSession.getAllTasks', rotate)
        self.assertIn('task.cancel()', rotate)
        self.assertNotIn('invalidateAndCancel', rotate)

    def test_22_resume_and_ksplayer_locked_donor_hashes(self):
        expected = {
            ROOT/'Sources'/'PlaybackResumeCache.swift': '4cdf1bf8d2a78904b4bca221f23388a72ee16b63e2c8be8cd59d1f1fdc95364e',
            ROOT/'Sources'/'PlaybackKit'/'PlaybackKitKSPlayerSurface.swift': '1f808e77b2d3e6358a64078af3447943f17d43b2f1beafd7f3d22285d920279f',
            ROOT/'Sources'/'UnityCatalogVisualSystem.swift': 'cc954cb07319a98dd288eadea8a4976514d9bccad5b78134bc939d18613799c4',
        }
        for path, digest in expected.items():
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), digest, path.name)

    def test_23_automatic_resume_clock_confirmation_still_present(self):
        scheduler = APP[APP.index('private func scheduleAutomaticResumeAfterSurfaceStart'):APP.index('private func forceResumeFromSavedPosition')]
        self.assertIn('reconcileAutomaticResumePlaybackClock', scheduler)
        self.assertIn('confirmAutomaticResume', scheduler)
        callback = APP[APP.index('onPlaybackTimeUpdate: { current, total in'):APP.index('onKSBufferUpdate:', APP.index('onPlaybackTimeUpdate: { current, total in'))]
        self.assertIn('reconcileAutomaticResumePlaybackClock(current: current)', callback)

    def test_24_multi_debrid_account_support_remains(self):
        for token in ['realDebrid','torBox','premiumize','allDebrid','debridLink','easyDebrid','offcloud','putio']:
            self.assertRegex(BRIDGE, rf'case {token}\b')
        self.assertNotIn('guard defaults.bool(forKey: "managedTorrentioEnabled")', MANAGED)
        self.assertIn('DebridCredentialBridge.torrentioEnabled(for: service', MANAGED)
        for marker in ['easydebrid','offcloud','putio']:
            self.assertIn(marker, SOURCE.lower())

if __name__ == '__main__':
    unittest.main(verbosity=2)
