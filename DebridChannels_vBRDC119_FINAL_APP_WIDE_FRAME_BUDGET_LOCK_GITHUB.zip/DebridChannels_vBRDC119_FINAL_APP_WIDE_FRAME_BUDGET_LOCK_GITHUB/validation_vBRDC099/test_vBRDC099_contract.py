from pathlib import Path
import hashlib, plistlib, re, sys, yaml
ROOT = Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
CAT=(ROOT/'Sources/CatalogStore.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
UNITY=(ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
SYSTEM=(ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
PROJECT=yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(n,c): checks.append((n,bool(c)))
def pl(rel):
    with open(ROOT/rel,'rb') as f:return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release vBRDC099', app.get('DebridChannelsReleaseID')=='vBRDC099' and top.get('DebridChannelsReleaseID')=='vBRDC099')
ck('marketing 1.0.802', app.get('CFBundleShortVersionString')=='1.0.802' and top.get('CFBundleShortVersionString')=='1.0.802')
ck('build 802', app.get('CFBundleVersion')=='802' and top.get('CFBundleVersion')=='802')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.802')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='802')

root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
catalog=section(APP,'struct GridOSCatalogOverlay: View','private struct GridOSFixedSlotCatalogRail')
live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
art_ids=section(live,'private func liveTVArtworkLoadIDs(in mountedChannels: [LiveTVChannel]) -> Set<Int>','private func scheduleGuideHintAutoHide')
bootstrap=section(live,'private func beginForcedLiveTVArtworkBootstrap','private func scheduleGuideHintAutoHide')
art=section(APP,'private struct LiveTVGridTileArtwork','private struct LiveTVGridTileFooter')
loader=section(APP,'private final class LiveTVBoundedArtworkLoader','private struct LiveTVQuickGuideContainedArtworkFrame')
recover=section(root,'private func schedulePostPlaybackExitRecovery','private func synchronizeUnityCatalogBranchPresentation')

# Live TV playback-return continuity
ck('live rolling playback return cache exists', 'playbackReturnCache' in loader and '32 * 1024 * 1024' in loader)
ck('live successful decodes roll into return cache', 'playbackReturnCache.setObject(image' in loader)
ck('live pre-playback snapshot exists', 'snapshotMountedArtworkForReturn' in loader and 'prepareForFullScreenPlayback' in loader)
ck('live snapshot does not clear before recapture', 'private static func snapshotMountedArtworkForReturn' in loader and 'snapshotMountedArtworkForReturn(reason' in loader and 'playbackReturnCache.removeAllObjects()\n        var retained' not in loader)
play_channel=section(live,'private func play(channel: LiveTVChannel)','static let sampleChannels')
ck('live playback entry snapshots before startPlayback', play_channel.find('LiveTVBoundedArtworkLoader.prepareForFullScreenPlayback(reason: "Live TV playback entry")') >= 0 and play_channel.find('LiveTVBoundedArtworkLoader.prepareForFullScreenPlayback(reason: "Live TV playback entry")') < play_channel.find('store.startPlayback(item: item'))
ck('root suspension preserves live requests and return cache', 'preserveVisibleRequests: true' in loader and 'preservePlaybackReturnCache: true' in loader)
ck('root close resumes retained live requests', 'LiveTVBoundedArtworkLoader.resumeRetainedRequests()' in root)
ck('live resume clears stale failed URL ladder', 'resetFailedURLsForAuthoritativeRefresh()' in section(loader,'static func resumeRetainedRequests','private func releaseViewOwnedImage'))
ck('live playback close bootstraps artwork', 'beginForcedLiveTVArtworkBootstrap(reason: "playback URL cleared")' in live)
ck('live root mount bootstraps artwork', 'beginForcedLiveTVArtworkBootstrap(reason: "Live TV root mounted")' in live)
ck('live tab selection bootstraps artwork', 'beginForcedLiveTVArtworkBootstrap(reason: "Live tab selected")' in live)
ck('live covered bootstrap allowed', 'interactiveLiveTV || liveTVForcedArtworkBootstrapActive' in art_ids)
ck('live covered bootstrap remains bounded', 'let radius = interactiveLiveTV ? 3 : 2' in art_ids)
ck('live bootstrap has two reinforcement epochs', bootstrap.count('liveTVArtworkRefreshToken &+= 1') >= 3 and '650_000_000' in bootstrap and '1_350_000_000' in bootstrap)
ck('live bootstrap is bounded not repeating', '8_000_000_000' in bootstrap and 'while' not in bootstrap)
ck('live cold-start focus-independent anchor retained', '}.first ?? 0' in art_ids)
ck('live Gracenote fallback ladder retained', art.find('program?.imageURL') < art.find('channel.iconURL') < art.find('providerChannelPosterURL'))
ck('live retained pixels remain while covered', 'artworkLoader.suspendPreservingImage()' in art and 'preserveCurrentImage: true' in art)
ck('live image session waits for connectivity', 'configuration.waitsForConnectivity = true' in loader)
ck('live bounded transient retry retained', '650_000_000' in loader)

# Catalog / streaming return self-heal
ck('catalog visible readiness API exists', 'func forceVisibleCatalogReadiness(reason: String) -> Bool' in CAT)
ck('catalog readiness is synchronous durable restore', 'restoreBestOfficialCatalogCacheIfNeeded(reason: reason)' in section(CAT,'func forceVisibleCatalogReadiness','func ensureDebridChannelsCatalogCompleteness'))
ck('catalog visible readiness blocks during playback', all(x in section(CAT,'func forceVisibleCatalogReadiness','func ensureDebridChannelsCatalogCompleteness') for x in ['fullScreenPlaybackResourceSuspended','vodExclusivePlaybackActive','VODExclusivePlaybackGate.isActive']))
ck('catalog overlay refuses transient empty replacement', 'retained visible rows during transient empty revision' in catalog)
ck('catalog overlay force readiness on appear', 'forceVisibleCatalogReadiness(reason: "catalog overlay appear")' in catalog)
ck('catalog overlay force readiness after playback', 'forceVisibleCatalogReadiness(reason: "catalog playback closed")' in catalog)
ck('catalog overlay post-mount blank pass always scheduled', 'post-mount image pass' in catalog and '180_000_000' in catalog)
ck('catalog completeness repair still bounded', 'ensureDebridChannelsCatalogCompleteness' in catalog)
ck('root post-playback readiness checkpoint exists', 'post-playback readiness' in recover)
ck('root post-playback artwork checkpoint exists', 'post-playback checkpoint' in recover)
ck('UNITY catalog handoff settles with readiness force', 'UNITY catalog handoff settled' in root)

# Premium image loader systemic fixes
ck('premium rehydration coordinator is direct not published', 'final class PremiumArtworkRehydrationCoordinator {' in IMG and 'ObservableObject' not in section(IMG,'final class PremiumArtworkRehydrationCoordinator','final class PremiumRemoteImageLoader'))
ck('premium mounted weak loader registry exists', 'private static var mountedLoaders' in IMG and 'WeakBox' in IMG)
ck('premium direct mounted blank rehydrate exists', 'forceMountedBlankRehydration' in IMG and 'forceRehydrateCurrentIfBlank' in IMG)
ck('premium same-key failed no longer permanently short-circuits', 'if currentKey == key, image != nil { return }' in IMG and 'image != nil || failed' not in IMG)
ck('premium transient retries bounded to two', 'transientRetryAttempt < 2' in IMG and '500_000_000' in IMG and '1_400_000_000' in IMG)
ck('premium permanent 4xx avoids repeated force', 'nonRetryableFailures' in IMG and '!Self.nonRetryableFailures.contains(key)' in IMG)
ck('premium network waits for connectivity', 'configuration.waitsForConnectivity = true' in IMG)
ck('premium playback return cache exists', 'playbackReturnMemoryCache' in IMG and '28 * 1024 * 1024' in IMG)
ck('premium rolling return cache captures decoded cards', 'playbackReturnMemoryCache.setObject(decoded' in IMG)
ck('premium snapshot excludes oversized popup/backdrop buckets', 'key.maxPixelSize <= 1280' in IMG)
ck('premium VOD entry snapshots visible artwork first', 'snapshotMountedPersistentArtworkForPlaybackReturn(reason: "VOD playback entry")' in IMG)
ck('premium live playback snapshots catalog artwork first', 'snapshotMountedPersistentArtworkForPlaybackReturn(reason: "Live TV playback entry")' in IMG)
ck('premium playback exit is idempotent', 'guard exclusivePlaybackActive else' in section(IMG,'static func endExclusivePlayback','static func suspendForBackground'))
end=section(IMG,'static func endExclusivePlayback','static func suspendForBackground')
ck('premium playback exit no longer clears decoded caches', 'removeAllObjects()' not in end)
ck('premium background cancels active network owners', 'for task in activeNetworkTasks.values { task.cancel() }' in section(IMG,'static func suspendForBackground','static func handleMemoryPressure'))
ck('premium memory pressure clears return cache', 'playbackReturnMemoryCache.removeAllObjects()' in section(IMG,'static func handleMemoryPressure','static func releaseTransientSurfaceResources'))

# Existing v098 / UNITY protections stay intact
ck('one physical LiveTVScreen', len(re.findall(r'\bLiveTVScreen\(\)',APP))==1)
ck('no frozen synthetic donor', 'FrozenLiveTVBackdrop' not in APP)
ck('24 covered corridor retained', 'coveredRenderedChannelLimit: Int = 24' in live)
ck('96 interactive corridor retained', 'interactiveRenderedChannelLimit: Int = 96' in live)
ck('Pulse Glow retained', 'Focused Card Pulse Glow Animation' in APP)
ck('post-navigation recovery retained', 'postNavigationVisualRecoveryActive' in UNITY)
ck('UNITY synthetic-donor rejection retained', 'synthetic donor' in SYSTEM)
ck('connected popup 2048 prewarm retained', 'scheduleConnectedArtworkPrewarm' in APP and 'maxPixelSize: 2048' in APP)
ck('wallpaper phase preservation retained', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('v098 zero-scroll selection repair retained', 'synchronizeLiveTVSelectionWithPublishedLineup(reason:' in live)
ck('v097 cold guide hydration retained', 'scheduleLiveTVColdStartHydrationIfNeeded()' in live)

# Provider/playback/resume donor locks: v099 is artwork/readiness only.
DONOR={
'Sources/NuvioPluginClient.swift':'94a3196403f26e8edad215029b26191e3941d7fb14a5fc5ac60fe29801a90a75',
'Sources/BackupStreamingClient.swift':'251dc138dbd14fc476c76bc6a765f85643df083a5c94196d54fc0148337346cd',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceSystem.swift':'00f507ce35a619732abe0811ff3fd3f7ffe58c431336b23b69011f43079beb76',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
}
for rel,h in DONOR.items(): ck('donor '+rel, sha(rel)==h)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('all Swift sources declared', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
