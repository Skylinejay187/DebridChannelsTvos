from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
SYSTEM = (ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id vBRDC096', app.get('DebridChannelsReleaseID')=='vBRDC096' and top.get('DebridChannelsReleaseID')=='vBRDC096')
ck('marketing 1.0.799', app.get('CFBundleShortVersionString')=='1.0.799' and top.get('CFBundleShortVersionString')=='1.0.799')
ck('build 799', app.get('CFBundleVersion')=='799' and top.get('CFBundleVersion')=='799')
ck('project marketing 1.0.799', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.799')
ck('project build 799', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='799')

root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
root_body=section(root,'var body: some View','// v535: keep the top menu visible')
ck('exactly one physical LiveTVScreen mount in app', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)
ck('frozen donor remains removed', 'FrozenLiveTVBackdrop()' not in APP and 'private struct FrozenLiveTVBackdrop' not in APP)
ck('persistent live root is mounted before dedicated surfaces', root_body.find('LiveTVScreen()') >= 0 and root_body.find('LiveTVScreen()') < root_body.find('if membershipLocked') and root_body.find('LiveTVScreen()') < root_body.find('SettingsScreen(') and root_body.find('LiveTVScreen()') < root_body.find('GlobalFavoritesScreen()'))
ck('persistent live root remains below Sports and catalog', root_body.find('LiveTVScreen()') < root_body.find('SportsHubScreen()') and root_body.find('LiveTVScreen()') < root_body.find('GridOSCatalogOverlay('))
ck('dedicated surfaces explicitly cover retained root', '.zIndex(4100)' in section(root_body,'} else if store.selectedTab == .settings','} else if store.selectedTab == .membership') and '.zIndex(4100)' in section(root_body,'} else if store.selectedTab == .favorites','} else {\n                    if store.selectedTab == .sports'))
ck('live root interaction remains Live-only', 'let liveRootInteractive = store.selectedTab == .live' in root_body)
ck('catalog branch keeps natural transition', all(x in root_body for x in ['.opacity(progress)', '.offset(y: (1 - progress) * 34)', '.scaleEffect(0.996 + (0.004 * progress)']))
ck('all catalog themes still share one overlay root', root.count('GridOSCatalogOverlay(') == 1)
ck('UNITY system still rejects synthetic donors', all(x in SYSTEM for x in ['exact same LiveTVScreen instance','synthetic donor']))

live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
appear=section(live,'.onAppear {','            .onChange(of: store.guideStartupRequestToken)')
selected_tab=section(live,'.onChange(of: store.selectedTab) { tab in','.onChange(of: store.liveTVFocusRestoreToken)')
ck('LiveTV onAppear never rewrites dedicated tab', 'store.selectedTab = .live' not in appear)
ck('Settings Favorites Membership are valid cover owners comment lock', 'Settings/Favorites/Membership are valid cover owners' in appear)
ck('covered root cancels refresh', 'liveRefreshTask?.cancel()' in selected_tab and 'liveForceRefreshTask?.cancel()' in selected_tab)
ck('covered root cancels schedule and artwork prefetch', 'liveTVScheduleBoundaryTask?.cancel()' in selected_tab and 'liveTVArtworkPrefetchTask?.cancel()' in selected_tab)
ck('covered root cancels obsolete artwork prefetches', 'LiveTVBoundedArtworkLoader.cancelObsoletePrefetches(keeping: [])' in selected_tab)
ck('covered root still compacts to 24 cards', 'coveredRenderedChannelLimit: Int = 24' in live and 'renderedChannelLimit = coveredRenderedChannelLimit' in selected_tab)
ck('interactive Live root expands to 96 cards', 'interactiveRenderedChannelLimit: Int = 96' in live and 'renderedChannelLimit = interactiveRenderedChannelLimit' in selected_tab)
ck('hidden decoder lane remains Live-only', 'guard store.selectedTab == .live else { return [] }' in section(live,'private func liveTVArtworkLoadIDs','private func scheduleGuideHintAutoHide'))

loader=section(APP,'private final class LiveTVBoundedArtworkLoader','private struct LiveTVQuickGuideContainedArtworkFrame')
art=section(APP,'private struct LiveTVGridTileArtwork','private struct LiveTVGridTileFooter')
ck('covered tiles suspend without releasing image', 'func suspendPreservingImage()' in loader and 'image = nil' not in section(loader,'func suspendPreservingImage()','func cancel()'))
ck('covered tile path uses suspend preserving image', 'artworkLoader.suspendPreservingImage()' in section(art,'private func synchronizeArtworkRequest','private func programArtBackground'))
ck('tile source identity remains independent of load permission', '@State private var retainedArtworkSource' in art and 'guard loadArtwork else { return nil }' not in section(art,'private var candidateArtworkSource','private var candidateArtworkURL'))
ck('replacement decode preserves previous image', 'preserveCurrentImage: true' in art)
ck('fallback order remains Gracenote channel icon provider', art.find('program?.imageURL') < art.find('channel.iconURL') < art.find('providerChannelPosterURL'))
ck('session guide remains process retained', 'private static var sessionGuidePrograms' in APP and 'if !Self.sessionChannels.isEmpty' in APP)

# Preserve vBRDC092-v095 motion and detail fixes.
card=section(APP,'struct FixedSlotFocusedCatalogCard','struct FixedSlotPreviewCatalogCard')
rail=section(APP,'struct GridOSFixedSlotCatalogRail','private struct SearchMenuIconFramePreferenceKey')
ck('Pulse Glow setting remains', 'Focused Card Pulse Glow Animation' in APP)
ck('Pulse Glow remains slow opacity-only', '.easeInOut(duration: 2.85).repeatForever(autoreverses: true)' in card)
pulse=section(card,'if focused && coordinatedPulseEnabled','            }\n            .allowsHitTesting(false)')
ck('Pulse Glow still has two halos', pulse.count('RoundedRectangle') >= 2 and '.blur(radius: 22)' in pulse and '.blur(radius: 8)' in pulse)
ck('Pulse Glow does not alter card geometry', '.scaleEffect' not in pulse and '.offset' not in pulse and '.frame' not in pulse)
ck('detail visual focus remains pinned through anchor', 'store.selectedDetail ?? store.detailPresentationAnchorItem' in rail)
ck('focus arrival remains blocked during detail handoff', 'store.detailPresentationAnchorItem == nil' in section(card,'private func replaySearchStyleFocusArrival','private func startSearchStyleFocusArrivalSpring'))
ck('row preset frame budget remains', 'frameBudgetSettleDuration(for: catalogRowScrollingAnimationPreset)' in APP)
ck('connected popup 2048 prewarm remains', 'maxPixelSize: 2048' in APP and 'scheduleConnectedArtworkPrewarm' in APP)
ck('dynamic wallpaper phase pause remains', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('post-navigation recovery remains', 'postNavigationVisualRecoveryActive' in UNITY)
ck('Favorites artwork cache isolation remains', '.environment(\\.premiumArtworkCacheDomain, .favorites)' in APP)
ck('Sports artwork cache isolation remains', '.environment(\\.premiumArtworkCacheDomain, .sports)' in APP)

DONOR={
'Sources/NuvioPluginClient.swift':'0495f210b9d2ca0b316f0124e1bb4b584147a303c3cb193f48f5cee4fa7259e5',
'Sources/BackupStreamingClient.swift':'032b7ee7663491e93057d7e3702ba7bc55674a8cb10b9336093e7a0399dd4a49',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
'Sources/RemoteImageFit.swift':'093c1c108270e746e463c6ff72b018af4eb62e19afaeaa894947fe38f3518f0f',
'Sources/CatalogStore.swift':'639979f0bd4b8385dd928e30e82db795bc04635fd557b82f73a60cc3e24dd14f',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'BackendBackupStreamingRuntime/backup_streaming_runtime.py':'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py':'340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/SportsScoresScheduleProvider.swift':'db0b16cf928d363275454e74c7db2dcffdc98ff52f7df58188eb22cb435279af',
}
for rel,expected in DONOR.items(): ck('donor lock '+rel, sha(rel)==expected)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source declared in project', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
