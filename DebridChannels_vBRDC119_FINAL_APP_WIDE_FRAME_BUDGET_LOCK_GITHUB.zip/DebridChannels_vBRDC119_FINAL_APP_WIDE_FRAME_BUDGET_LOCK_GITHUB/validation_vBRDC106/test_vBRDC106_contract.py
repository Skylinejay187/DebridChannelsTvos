from pathlib import Path
import plistlib, sys, re
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
FRAME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
COORD=(ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
CAST_SERVICE=(ROOT/'Sources/CastExplorerService.swift').read_text()
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def section(text,a,b):
    i=text.find(a)
    if i<0:return ''
    j=text.find(b,i+len(a))
    return text[i:] if j<0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f:return plistlib.load(f)
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC106' and toppl.get('DebridChannelsReleaseID')=='vBRDC106')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.809' and toppl.get('CFBundleShortVersionString')=='1.0.809')
ck('build', apppl.get('CFBundleVersion')=='809' and toppl.get('CFBundleVersion')=='809')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.809')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 809')==2)

cast=section(APP,'struct V1111FeaturedCastPosterCard: View','private struct V1106ProductionFact')
prod=section(APP,'private struct V1111ProductionArtworkHeader: View','struct V1104ReviewScoresCluster')
explorer=section(APP,'struct V1134CastExplorerOverlay: View','struct V1134CastFactChip')
credit=section(APP,'private struct V1143CastCreditPoster: View','private struct V1143CastCreditText')

# Root regression: VOD-visible images can publish while full-screen playback remains exclusive.
ck('playback artwork lane exists', 'case playbackArtwork' in FRAME)
ck('playback artwork lane permitted only during playback without nav', 'case .playbackArtwork: return !snapshot.navigationActive' in FRAME)
ck('playback publication opt-in argument', 'allowDuringPlayback: Bool = false' in FRAME)
ck('ordinary playback images still defer', 'return !allowDuringPlayback || snapshot.navigationActive' in FRAME)
ck('coordinator exposes opt-in', 'allowDuringPlayback: Bool = false' in COORD and 'allowDuringPlayback: allowDuringPlayback' in COORD)
ck('RemoteImageFit default remains false', 'var publishDuringPlayback: Bool = false' in IMG)
ck('loader default remains false', 'allowPublicationDuringPlayback: Bool = false' in IMG)
ck('deferred lane maps playback artwork', 'lane = .playbackArtwork' in IMG)
ck('visible playback artwork retries allowed', 'allowPublicationDuringPlayback || (!Self.exclusivePlaybackActive && !VODExclusivePlaybackGate.isActive)' in IMG)
ck('display commit callback exists', 'var onDisplayedURLChange: ((URL?) -> Void)? = nil' in IMG and 'onDisplayedURLChange?(newValue)' in IMG)

# Featured Cast: 7-second visible-only rotation and atomic face/name/select identity.
ck('cast exact seven second cadence', '7_000_000_000' in cast)
ck('cast rotation requires awake', 'guard playbackReady, awake, mode != .off, imageMembers.count > 1 else { return }' in cast)
ck('cast task id includes awake', '"rotate|\\(item.id)|\\(mode.rawValue)|\\(awake)|\\(playbackReady)|\\(imageMembers.count)"' in cast)
ck('cast portrait playback publication compact', cast.count('publishDuringPlayback: true') >= 4)
ck('cast displayed identity state', '@State private var displayedCastMemberID: String? = nil' in cast)
ck('cast waits for real bitmap commit', 'commitDisplayedCastMember(member, requestedURL: imageURL, displayedURL: displayedURL)' in cast)
ck('cast name follows displayed portrait', 'Text(visibleIdentity(for: member).name)' in cast)
ck('cast role follows displayed portrait', 'visibleIdentity(for: member).role' in cast)
ck('cast select follows displayed portrait', 'let member = displayedMember ?? currentMember' in cast)
ck('cast retains prior portrait no blank', cast.count('preservePreviousOnURLChange: true') >= 2)

# Production: visible-only cancellable task, not view-value Timer publisher.
ck('production old autoconnect timer removed', 'Timer.publish(every: 7.0' not in prod and '.onReceive(rotationTimer)' not in prod)
ck('production exact seven second cadence', '7_000_000_000' in prod)
ck('production visible task', '.task(id: rotationTaskID)' in prod and 'await runVisibleRotationTask()' in prod)
ck('production task requires awake', 'guard awake, artworkURLs.count > 1 else { return }' in prod)
ck('production artwork retains frame', 'preservePreviousOnURLChange: true' in prod)
ck('production artwork can publish in playback', 'publishDuringPlayback: true' in prod)

# Hidden overlay must not keep rotations/work alive.
ck('heavy VOD chrome mounts only visible', 'if controlsVisible || activePanel != nil || isScrubbingTimeline || isSeekingInPlayer {' in APP)
ck('cast awake tied to visible chrome', 'castWallAwake: controlsVisible && activePanel == nil && castExplorerMember == nil' in APP)
ck('hidden VOD cancels decorative artwork work', 'PremiumRemoteImageLoader.releaseDecodedArtworkForHiddenVODOverlay()' in section(APP,'.onChange(of: controlsVisible)','        .onChange(of: isPlaying)'))
ck('production task id includes awake', 'vBRDC106-production-rotation|\\(awake)' in prod)

# Cast Explorer: person and credit posters may paint during paused/playing full-screen VOD and use bounded decode sizes.
ck('cast explorer profile playback artwork', 'maxPixelSize: 768, publishDuringPlayback: true' in explorer)
ck('known-for credit posters playback artwork', 'maxPixelSize: 512, publishDuringPlayback: true' in credit)
ck('credit poster remains lazy row', 'LazyHStack' in explorer)
ck('cast explorer only user invoked', 'Person details load only when you open this screen' in explorer)
ck('cast explorer task cancels on close', 'castExplorerTask?.cancel()' in APP and 'castExplorerTask = nil' in APP)
ck('wikidata cannot block filmography', 'loadWikidataFactsBounded' in CAST_SERVICE and '1_800_000_000' in CAST_SERVICE)
ck('wikidata bounded result is optional', 'group.cancelAll()' in CAST_SERVICE and 'return WikidataFacts()' in CAST_SERVICE)

# Scope control: no global opt-in leak.
ck('exact ten VOD playback image opt-ins', APP.count('publishDuringPlayback: true') == 10)
ck('row visual system still present', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())
ck('Live TV preview feature retained', 'liveTVGridFocusPreviewEnabledV1' in APP)
ck('v104 persistent catalog retained', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
