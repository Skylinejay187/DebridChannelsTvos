from pathlib import Path
import re, unittest
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE=(ROOT/'Sources/CatalogStore.swift').read_text()
KS=(ROOT/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PLIST=(ROOT/'Sources/Info.plist').read_text()
PROJECT=(ROOT/'project.yml').read_text()

class VBRDC078ExitContract(unittest.TestCase):
    def test_version(self):
        self.assertIn('vBRDC078', PLIST)
        self.assertIn('1.0.781', PLIST)
        self.assertIn('CURRENT_PROJECT_VERSION: 781', PROJECT)

    def test_ordered_teardown_state_exists(self):
        self.assertIn('@State private var orderedPlayerTeardownCompleted = false', APP)

    def test_normal_vod_disappear_does_not_repeat_teardown(self):
        self.assertIn('} else if !orderedPlayerTeardownCompleted {', APP)
        self.assertIn('stopOwnedPlaybackKitSession(reason: "screen disappeared")', APP)

    def test_dismissal_completes_teardown_before_close(self):
        block=re.search(r'private func requestPlayerDismissal\(\) \{(.*?)\n    \}', APP, re.S).group(1)
        self.assertLess(block.index('teardownPlayer()'), block.index('store.closePlayer'))
        self.assertLess(block.index('orderedPlayerTeardownCompleted = true'), block.index('store.closePlayer'))

    def test_close_task_cleared_before_publishing_nil(self):
        block=re.search(r'private func requestPlayerDismissal\(\) \{(.*?)\n    \}', APP, re.S).group(1)
        self.assertLess(block.index('playerDismissalTask = nil'), block.index('store.closePlayer'))

    def test_post_playback_recovery_has_multiple_focus_checkpoints(self):
        block=re.search(r'private func schedulePostPlaybackExitRecovery\(reason: String\) \{(.*?)\n    \}', APP, re.S).group(1)
        for delay in ('35_000_000','95_000_000','180_000_000','320_000_000'):
            self.assertIn(delay, block)
        self.assertIn('store.recoverCatalogInteractivity', block)

    def test_root_work_resumes_after_focus_checkpoints(self):
        block=re.search(r'private func schedulePostPlaybackExitRecovery\(reason: String\) \{(.*?)\n    \}', APP, re.S).group(1)
        self.assertGreater(block.index('resumeNonAlertRootWorkAfterVOD()'), block.index('for (index, delay) in delays.enumerated()'))
        self.assertGreater(block.index('startCatalogCompletenessWatchdogIfNeeded()'), block.index('for (index, delay) in delays.enumerated()'))

    def test_playback_close_uses_post_exit_recovery(self):
        block=re.search(r'\.onChange\(of: store\.playbackURL\) \{ value in(.*?)\n        \}', APP, re.S).group(1)
        nil_branch=block.split('} else {',1)[0]
        self.assertIn('schedulePostPlaybackExitRecovery(reason: "playback closed")', nil_branch)
        self.assertNotIn('resumeNonAlertRootWorkAfterVOD()', nil_branch)

    def test_new_playback_cancels_pending_exit_recovery(self):
        self.assertIn('postPlaybackExitRecoveryTask?.cancel()', APP)

    def test_close_clears_stale_loading_before_url_nil(self):
        block=re.search(r'func closePlayer\(expectedPresentationID: UUID\? = nil, expectedURL: URL\? = nil\) \{(.*?)\n    \}', STORE, re.S).group(1)
        self.assertLess(block.index('isLoading = false'), block.index('playbackURL = nil'))
        self.assertLess(block.index('topMenuFocusLocked = false'), block.index('playbackURL = nil'))

    def test_v077_resume_autoplay_is_preserved(self):
        self.assertIn('Automatic resume confirmed and playing', APP)
        self.assertIn('currentShouldPlay ?? true', KS)
        self.assertIn('layer.play()', KS)

    def test_v076_playback_priority_is_preserved(self):
        self.assertIn('vBRDC076 Playback Priority', APP)
        self.assertIn('transition(isPlaying ? .identity : .opacity)', APP)

if __name__ == '__main__': unittest.main(verbosity=2)
