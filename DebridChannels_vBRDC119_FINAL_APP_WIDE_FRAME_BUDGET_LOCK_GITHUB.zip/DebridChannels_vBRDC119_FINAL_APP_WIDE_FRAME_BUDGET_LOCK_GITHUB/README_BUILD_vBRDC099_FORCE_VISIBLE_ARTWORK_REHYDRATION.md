# Debrid Channels vBRDC099 — Forced Visible Artwork Rehydration

Release: **vBRDC099**  
Marketing version: **1.0.802**  
Apple build: **802**  
Donor: packaged **vBRDC098** only.

## Physical failures addressed

vBRDC098 fixed the first zero-scroll Gracenote bootstrap, but physical testing exposed a broader return-path problem:

- returning from a Live TV channel could briefly leave Live TV program/Gracenote cards blank or generic again;
- returning from VOD/movie/show playback could leave the persistent Live TV surface blank under catalogs;
- catalog cards themselves could occasionally remount blank until the user moved/scroll-triggered a new image owner.

These were not one provider failure. They were lifecycle/cache ownership problems around full-screen playback and remount.

## Root causes

1. **Playback removes the non-playback SwiftUI tree.** The persistent UNITY root is persistent across app sections, but full-screen playback intentionally replaces that tree. `@StateObject` image owners therefore do not survive playback by themselves.
2. **Live TV had two teardown owners.** Live channel playback released transient artwork in `play(channel:)`, and Root then suspended Live TV again when playback became active. Exact decoded pixels/request identity could be discarded twice.
3. **VOD exit purged generic artwork a second time.** `PremiumRemoteImageLoader.endExclusivePlayback()` could clear caches during the same period in which returning catalog cards were trying to repopulate them.
4. **A single generic image failure could pin a mounted card blank.** The loader short-circuited a same-key request after `failed = true`; scrolling/remounting created a new owner, which is why movement could appear to “fix” the artwork.
5. **Catalog rows could remount before durable rows were republished.** An empty intermediate catalog revision could briefly replace a useful visible snapshot.

## vBRDC099 correction

### Live TV exact-pixel return reservoir

- Added a bounded **32 MB / 36-entry Live TV playback-return cache** for recently visible decoded program/channel images.
- Before full-screen playback, mounted Live TV artwork is snapshotted into that reservoir.
- `play(channel:)` now prepares the snapshot but does **not** perform the destructive release itself. Root remains the single full-screen suspension owner.
- During suspension, mounted Live TV image owners preserve their current image/request identity rather than eagerly clearing it.
- On playback close, retained requests are explicitly resumed and stale per-tile failed URL ladders are reset.
- Memory warnings remain authoritative and can still clear the reservoir.

### Forced, bounded Live TV rehydration

A stronger bootstrap lane now runs at the moments where the visible Live TV surface can legitimately need reconstruction:

- persistent Live TV root mount;
- entering the Live TV tab;
- full-screen playback closing.

The lane starts immediately, reinforces the tile refresh generation at roughly **650 ms** and **2.0 s**, and remains allowed for a bounded **10-second** recovery window. It can load the small mounted artwork corridor even while Home/Movies/Shows/Settings covers the persistent Live TV root, but it does **not** restart hidden provider refresh, EPG boundary scans, or recurring prefetch systems.

The established artwork ladder remains:

**Gracenote/current-program artwork → channel icon → provider poster → generated card**.

### Catalog/VOD rolling return reservoir

- Added a bounded **28 MB / 36-entry** rolling return cache for persistent card-sized decoded artwork.
- Successful card decodes automatically populate it; oversized popup/fullscreen backdrops are intentionally excluded.
- VOD/live playback entry snapshots useful currently mounted catalog artwork before the large caches are released.
- VOD exit is now idempotent and **does not purge freshly returning artwork again**.

### Direct mounted-blank recovery without a SwiftUI invalidation storm

- Added `PremiumArtworkRehydrationCoordinator` as a direct coordinator, **not** an `ObservableObject` observed by every image view.
- It keeps weak references to mounted image loaders and asks only currently blank loaders to rehydrate.
- Healthy images are untouched, so the recovery does not redraw every catalog card at once.
- Generic image networking now waits for connectivity and has at most **two bounded transient retries**.
- Ordinary permanent 4xx responses are remembered so forced recovery does not hammer genuinely invalid URLs.

### Forced catalog readiness

- `CatalogStore.forceVisibleCatalogReadiness(reason:)` synchronously republishes the best durable official catalog cache when safe.
- `GridOSCatalogOverlay` refuses to replace a useful nonempty rendered snapshot with an empty intermediate revision while completeness recovery is pending.
- Catalog appearance/playback return/settled UNITY handoff forces durable row readiness plus a one-shot **180 ms post-mount artwork pass**, catching LazyHStack image owners that did not exist during the immediate recovery call.
- This is bounded recovery, not a new repeating timer.

### Background lifecycle cleanup

The audit also found a mismatch where background suspension could clear decoded caches while allowing active artwork network/in-flight owners to continue. Background suspension now cancels those request owners consistently; foreground recovery restarts only mounted blank artwork.

## UNITY and visual locks retained

- exactly one physical non-playback `LiveTVScreen` root;
- 24-card covered / 96-card interactive Live TV corridors;
- all catalog themes including Artwork Hero variants and Pure Black use the same UNITY lifecycle;
- Pulse Glow remains non-geometric;
- row-motion budgets and post-navigation recovery remain;
- Connected Popup 2048 prewarm remains;
- Dynamic Wallpaper phase-preserving freeze/resume remains;
- Sports/Favorites cache isolation remains;
- playback/resume, In-S, FebBox, TorBox Usenet, MediaFlow, Production metadata, and Source Intelligence provider logic are donor locked in this build.

## Intended existing-file scope

1. `Sources/RemoteImageFit.swift`
2. `Sources/DebridChannelsTVOSApp.swift`
3. `Sources/CatalogStore.swift`
4. `Sources/Info.plist`
5. `TopShelfExtension/Info.plist`
6. `project.yml`

## Validation

- vBRDC099 contract: **77/77 passed**
- Swift syntax parse: **64/64 passed**
- backend pytest: **36 passed, 2 subtests passed**
- plist/project alignment: **8/8 passed**
- donor scope: **6 intended existing-file changes, 0 unexpected**
- app + Top Shelf `plutil -lint`: **OK**
- package SHA-256 manifest: verified before ZIP creation
- GitHub Actions/Xcode remains the authoritative Apple SDK compile.
- Physical Apple TV remains authoritative for actual frame pacing, playback-return timing, and provider/network behavior.
