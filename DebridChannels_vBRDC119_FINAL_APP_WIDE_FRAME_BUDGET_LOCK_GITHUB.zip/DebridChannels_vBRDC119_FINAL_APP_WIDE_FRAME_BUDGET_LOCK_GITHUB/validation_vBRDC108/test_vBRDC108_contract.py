from pathlib import Path
import plistlib, sys, hashlib
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def section(text,a,b):
    i=text.find(a)
    if i<0:return ''
    j=text.find(b,i+len(a))
    return text[i:] if j<0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f:return plistlib.load(f)
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC108' and toppl.get('DebridChannelsReleaseID')=='vBRDC108')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.811' and toppl.get('CFBundleShortVersionString')=='1.0.811')
ck('build', apppl.get('CFBundleVersion')=='811' and toppl.get('CFBundleVersion')=='811')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.811')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 811')==2)

# Live TV real-logo-wins invariant.
footer=section(APP,'private var footerChannelIcon: some View','private func focusedTimelineSummary')
ck('footer no resident text underlay', 'ZStack(alignment: .leading)' not in footer and 'Text(channel.logo)' not in footer)
ck('footer uses loader failure fallback', 'fallbackText: channel.logo' in footer)
ck('RemoteImageFit fallback is opt-in', 'var fallbackText: String? = nil' in IMG)
placeholder=section(IMG,'private func placeholder(showSpinner: Bool)','    }\n}')
ck('fallback only missing or failed', 'resolvedURL == nil || loader.failed' in placeholder)
ck('fallback not used while valid URL loading', 'resolvedURL == nil || loader.failed' in placeholder and 'else if showPlaceholder' in placeholder)

# Media Profile handoff shown in 38430: one transaction, compositor transform, matched teardown.
constants=section(APP,'@State private var stageBackdropVisible','private let sourceIntelligencePageSize')
ck('detail transition exact 0.20s', 'private let detailStageTransitionDuration: Double = 0.20' in constants)
ck('close connector exact 0.20s', 'private let connectorCloseRetractionDuration: Double = 0.20' in constants)
present=section(APP,'private func presentPremiumConnector(for detailID: String)','@ViewBuilder\n    private var popupDimLayer')
ck('panel and connector begin same render turn', 'connectorLineVisible = true\n            stageBackdropVisible = true' in present)
ck('old serialized panel reveal removed', 'panel begins presenting' not in present)
panel=section(APP,'private var popupPanelLayer: some View','@ViewBuilder\n    private var popupPanelBackground')
ck('full panel animated mask removed', '.mask(alignment: .leading)' not in panel)
ck('direct compositor x transform used', '.scaleEffect(x: stageBackdropVisible ? 1.0 : 0.975' in panel)
ck('old spring removed from detail stage', '.spring(response: 0.29, dampingFraction: 0.91)' not in panel)
dismiss=section(APP,'private func dismissDetailSmoothly()','private func presentPremiumConnector')
ck('dismiss uses same timing curve', 'duration: detailStageTransitionDuration' in dismiss)
ck('dismiss waits only matched transition', 'detailStageTransitionDuration + 0.02' in dismiss and '320_000_000' not in dismiss)
ck('close duration retargets in-flight connector', '.onChange(of: retractionDuration)' in APP and 'if !visible { setConnectorVisibility(false, resetOpening: false) }' in APP)
ck('catalog focus handoff still precedes close', dismiss.find('prepareCatalogDetailDismissalFocusHandoff()') < dismiss.find('stageBackdropVisible = false'))

# Prior user-approved behavior remains locked.
ck('v107 focused preview ownership retained', 'if focusedCardPreviewKey == requestedKey,' in APP and 'focusedCardPreviewRequestedKey == requestedKey' in APP)
ck('trailer remains explicit preview stop owner', '.debridTrailerExclusivePlaybackDidBegin' in APP)
ck('v106 cast seven-second task retained', r'rotate|\(item.id)|' in APP and r'|\(mode.rawValue)|\(awake)|\(playbackReady)|\(imageMembers.count)' in APP and '7_000_000_000' in APP)
ck('v106 production visible task retained', 'vBRDC106-production-rotation' in APP and 'await runVisibleRotationTask()' in APP)
ck('v105 Live TV preview retained', 'liveTVGridFocusPreviewEnabledV1' in APP and '3_000_000_000' in APP and '15_000_000_000' in APP)
ck('v104 persistent catalog retained', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)
ck('v103 persistent rail retained', 'persistentRailMotionPhase' in APP and 'commitPersistentHorizontalMove' in APP)
ck('48 motion visual source retained', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
