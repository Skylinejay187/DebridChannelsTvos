from pathlib import Path
import plistlib, hashlib

root = Path(__file__).resolve().parents[1]
donor = Path('/mnt/data/work_v65/DebridChannels_vBRDC065_XMLTV_WATCHDOG_FIX_GITHUB')
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
visual = (root/'Sources/UnityCatalogVisualSystem.swift').read_text()
proj = (root/'project.yml').read_text()

# Release contract.
assert 'MARKETING_VERSION: 1.0.769' in proj
assert 'CURRENT_PROJECT_VERSION: 769' in proj
assert 'Sources/UnityCatalogVisualSystem.swift' in proj
for rel in ['Sources/Info.plist', 'TopShelfExtension/Info.plist']:
    with open(root/rel, 'rb') as f:
        p = plistlib.load(f)
    assert p['CFBundleShortVersionString'] == '1.0.769'
    assert p['CFBundleVersion'] == '769'
    assert p['DebridChannelsReleaseID'] == 'vBRDC066'

# Search-return regression fix: never spin on a VOD-gated no-op task; recover on playback return.
assert 'store.recoverCatalogInteractivity(reason: "Search appeared")' in app
assert 'store.recoverCatalogInteractivity(reason: "Search returned from playback")' in app
assert '.onChange(of: store.playbackURL?.absoluteString)' in app
assert 'guard !VODExclusivePlaybackGate.isActive else {' in app
assert 'if token == unifiedSearchToken { isSearchingUnified = false }' in app
assert 'franchiseItems: currentDetail.franchiseItems.isEmpty ? hydrated.franchiseItems : currentDetail.franchiseItems' in app

# Current compact media-information surface owns franchise presentation; no return to old fullscreen detail required.
assert 'UnityCompactFranchiseRibbon(' in app
assert 'fixed 66pt' in app
assert 'focusedFranchiseIndex' in app
assert 'case .related: focus = .favorite' in app
assert 'if isSeriesItem { focus = .season(selectedSeasonIndex) }' in app

# Unity presentation system: static/cheap visual layers only.
for token in [
    'enum UnityMediaVisualAccent',
    'struct UnityCatalogCardChrome',
    'struct UnityCatalogHeroAura',
    'struct UnityCompactFranchiseRibbon',
    'EXPLORE THE FRANCHISE',
]:
    assert token in visual
assert 'CADisplayLink' not in visual
assert 'Timer' not in visual
assert 'Task {' not in visual
assert 'RemoteImageFit' in visual
assert 'UnityCatalogCardChrome(item: item, focused: focused' in app
assert 'UnityCatalogHeroAura(item: item' in app

# vBRDC065 XMLTV watchdog fix must remain present in the shared app source.
for token in [
    'private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) async',
    'Task.detached(priority: .utility)',
    'LiveTVXMLTVBackgroundParser.parse(',
    'withTaskCancellationHandler',
    'worker.cancel()',
]:
    assert token in app

# Playback/KSP/provider/crash-fix scope stays byte-identical to vBRDC065.
locked = [
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift',
    'Sources/UniversalCodecSupport.swift',
    'Sources/TorBoxUsenetClient.swift',
    'Sources/CatalogStore.swift',
    'Sources/UnitySurfaceSystem.swift',
    'Sources/LocalIntroDetectionEngine.swift',
    'Sources/PlaybackStateManager.swift',
    'Sources/VODExclusivePlaybackGate.swift',
    'Scripts/fetch_patch_kspnuvio_vBRDC064.sh',
    'Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py',
    'BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py',
]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for rel in locked:
    assert sha(root/rel) == sha(donor/rel), rel

print('PASS vBRDC066 contract')
