from pathlib import Path
import plistlib, re, unittest
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
YML=(ROOT/'project.yml').read_text()
class Contract(unittest.TestCase):
    def test_version(self):
        for p in [ROOT/'Sources'/'Info.plist', ROOT/'TopShelfExtension'/'Info.plist']:
            d=plistlib.loads(p.read_bytes())
            self.assertEqual(d['CFBundleShortVersionString'],'1.0.774')
            self.assertEqual(d['CFBundleVersion'],'774')
            self.assertEqual(d['DebridChannelsReleaseID'],'vBRDC071')
        self.assertEqual(YML.count('MARKETING_VERSION: 1.0.774'),2)
        self.assertEqual(YML.count('CURRENT_PROJECT_VERSION: 774'),2)
    def sports_block(self):
        start=APP.index('struct SportsFoundationQuickPanelSurface: View')
        end=APP.index('struct SportsUnityHeroThemeArea: View')
        return APP[start:end]
    def test_sports_reads_shared_unity_theme(self):
        b=self.sports_block()
        self.assertIn('@AppStorage("liveTVGridThemePreset")',b)
        self.assertIn('CatalogArtworkCacheManager.themeFlags(for: liveTVGridThemePreset)',b)
        self.assertIn('sportsUnityThemeBackdrop',b)
        self.assertIn('sportsUnityHeroArea',b)
    def test_root_first_hero_behavior_present(self):
        b=self.sports_block()
        self.assertIn('flags.usesArtwork3Hero || key.contains("pure black")',b)
        self.assertIn('UnityCatalogHeroAura',b)
        self.assertIn('preservePreviousOnURLChange: true',b)
    def test_sports_keeps_shared_catalog_rail(self):
        b=self.sports_block()
        self.assertIn('GridOSFixedSlotCatalogRail(',b)
        rail=APP[APP.index('struct GridOSFixedSlotCatalogRail: View'):APP.index('struct StremioAddonSourceBadge: View')]
        self.assertIn('@AppStorage("catalogRowScrollingAnimationPreset")',rail)
        self.assertIn('UnityCatalogRowMotionStyle.transition',rail)
    def test_direct_tune_preserved(self):
        rail=APP[APP.index('struct GridOSFixedSlotCatalogRail: View'):APP.index('struct StremioAddonSourceBadge: View')]
        self.assertIn('if selectedItem.type.lowercased() == "live"',rail)
        self.assertIn('Sports direct live channel:',rail)
        self.assertIn('store.startPlayback(',rail)
    def test_all_48_motion_names_preserved(self):
        u=(ROOT/'Sources'/'UnityCatalogVisualSystem.swift').read_text()
        start=u.index('static let names = [')
        end=u.index(']\n\n    static func animation',start)
        names=re.findall(r'"([^"]+)"',u[start:end])
        self.assertEqual(len(names),48)
        self.assertIn('Lift Off',names)
        self.assertIn('Instant',names)
if __name__=='__main__': unittest.main(verbosity=2)
