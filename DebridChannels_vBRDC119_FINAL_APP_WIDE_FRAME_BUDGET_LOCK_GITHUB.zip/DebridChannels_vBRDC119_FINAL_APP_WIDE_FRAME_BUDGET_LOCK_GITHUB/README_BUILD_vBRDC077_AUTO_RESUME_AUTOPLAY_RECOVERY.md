# Debrid Channels vBRDC077 — Automatic Resume Autoplay Recovery

Release ID: **vBRDC077**  
Marketing version: **1.0.780**  
Apple build: **780**  
Donor: **packaged vBRDC076 only**

## Corrective scope

Physical Apple TV testing of vBRDC076 confirmed that automatic resume restored the saved movie position but could leave KSPNUVIO paused after its in-place seek, requiring a manual Play press.

vBRDC077 preserves the vBRDC073 clock-confirmed in-place resume architecture and fixes only the play-state handoff:

- `confirmAutomaticResume(...)` now makes automatic resume a complete operation: saved position confirmed **and playback continuing automatically**.
- The player-owned state is restored to `isPlaying = true` after the authoritative decoder clock reaches the saved checkpoint.
- AVPlayer receives an explicit `play()` assertion after confirmed resume.
- KSPNUVIO receives an immediate and one guarded delayed `play()` assertion after its internal pause/seek decoder flush.
- The delayed KS assertion checks `currentShouldPlay`, so a real Siri Remote pause always overrides it.
- No KSPlayer surface recreation was reintroduced.
- Playback resume cache format, source identity behavior, Find Links resume behavior, vBRDC076 Playback Priority changes, vBRDC075 appearance/artwork settings, UNITY, Sports, and backend runtimes are unchanged.

## Required behavior

Opening a partially watched movie or episode must:

1. open the selected source;
2. automatically seek to the durable saved position;
3. confirm the actual player clock reached that position; and
4. **continue playing automatically without requiring the user to press Play.**
