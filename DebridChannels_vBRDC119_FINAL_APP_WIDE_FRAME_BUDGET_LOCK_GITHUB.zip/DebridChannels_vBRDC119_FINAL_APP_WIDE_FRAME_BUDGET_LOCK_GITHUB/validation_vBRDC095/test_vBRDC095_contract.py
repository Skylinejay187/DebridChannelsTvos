from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
SYSTEM = (ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id vBRDC095', app.get('DebridChannelsReleaseID')=='vBRDC095' and top.get('DebridChannelsReleaseID')=='vBRDC095')
ck('marketing 1.0.798', app.get('CFBundleShortVersionString')=='1.0.798' and top.get('CFBundleShortVersionString')=='1.0.798')
ck('build 798', app.get('CFBundleVersion')=='798' and top.get('CFBundleVersion')=='798')
ck('project marketing 1.0.798', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.798')
ck('project build 798', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='798')

# Persistent UNITY root from vBRDC093/v094 remains the architecture.
root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
ck('exactly one physical LiveTVScreen mount in app', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)
ck('frozen donor remains removed', 'private struct FrozenLiveTVBackdrop' not in APP and 'FrozenLiveTVBackdrop()' not in APP)
ck('live root remains beneath catalog and sports overlays', root.find('LiveTVScreen()') < root.find('SportsHubScreen()') and root.find('LiveTVScreen()') < root.find('GridOSCatalogOverlay('))
ck('catalog branch keeps natural root transition', all(x in root for x in ['.opacity(progress)', '.offset(y: (1 - progress) * 34)', '.scaleEffect(0.996 + (0.004 * progress)']))
ck('all catalog themes still share one overlay root', root.count('GridOSCatalogOverlay(') == 1)
ck('UNITY surface system still forbids synthetic donors', all(x in SYSTEM for x in ['exact same LiveTVScreen instance','snapshot','synthetic donor']))

# vBRDC095 live-card continuity: covered surfaces retain exact recent pixels.
loader=section(APP,'private final class LiveTVBoundedArtworkLoader','private struct LiveTVQuickGuideContainedArtworkFrame')
art=section(APP,'private struct LiveTVGridTileArtwork','private struct LiveTVGridTileFooter')
ck('loader supports suspend without image release', 'func suspendPreservingImage()' in loader and 'loadTask?.cancel()' in section(loader,'func suspendPreservingImage()','func cancel()'))
ck('suspend path does not clear retained bitmap', 'image = nil' not in section(loader,'func suspendPreservingImage()','func cancel()') and 'imageURL = nil' not in section(loader,'func suspendPreservingImage()','func cancel()'))
ck('grid retains source identity while covered', '@State private var retainedArtworkSource: ArtworkSource?' in art)
ck('candidate source is independent of load permission', 'private var candidateArtworkSource' in art and 'guard loadArtwork else { return nil }' not in section(art,'private var candidateArtworkSource','private var candidateArtworkURL'))
ck('covered grid suspends rather than loading nil', 'artworkLoader.suspendPreservingImage()' in section(art,'private func synchronizeArtworkRequest','private func programArtBackground'))
ck('grid observes loadArtwork edge explicitly', '.onChange(of: loadArtwork)' in art)
ck('grid preserves current image during replacement decode', 'preserveCurrentImage: true' in art)
ck('loader preserve option exists', 'preserveCurrentImage: Bool = false' in loader)
ck('loader does not clear previous image when preserve requested', 'if !preserveCurrentImage' in loader)
ck('display source prefers actually decoded retained image', 'if let imageURL = artworkLoader.imageURL, artworkLoader.image != nil' in art)
ck('established Gracenote channel icon provider fallback order remains', art.find('program?.imageURL') < art.find('channel.iconURL') < art.find('providerChannelPosterURL'))

# vBRDC095 detail dismissal: no one-frame visual focus loss / whole-row bounce.
rail=section(APP,'struct GridOSFixedSlotCatalogRail','private struct SearchMenuIconFramePreferenceKey')
pin=section(rail,'private var detailKeepsSelectedCardVisuallyFocused','private var coordinatedRailAnimations')
ck('detail visual focus bridges through retained anchor', 'store.selectedDetail ?? store.detailPresentationAnchorItem' in pin)
ck('detail pin remains exact row and index', 'store.quickPanelRestoreRowID == row.id' in pin and 'store.quickPanelRestoreItemIndex == safeIndex' in pin)
ck('detail pin canonical identity fallback remains', 'canonicalCatalogIdentityKey' in pin)
card=section(APP,'struct FixedSlotFocusedCatalogCard','struct FixedSlotPreviewCatalogCard')
ck('focus arrival still blocked while detail anchor exists', 'store.detailPresentationAnchorItem == nil' in section(card,'private func replaySearchStyleFocusArrival','private func startSearchStyleFocusArrivalSpring'))
ck('horizontal item change still hard-resets arrival offset', 'Horizontal row motion already owns the selected-item transition' in card and 'focusArrivalVerticalOffset = 0' in card)

# Pulse is an obvious slow compositor-only glow, never card geometry.
ck('settings still exposes Pulse Glow toggle', 'Focused Card Pulse Glow Animation' in APP)
ck('pulse cycle remains slow 5.7 second full cycle', '.easeInOut(duration: 2.85).repeatForever(autoreverses: true)' in card)
pulse=section(card,'if focused && coordinatedPulseEnabled','            }\n            .allowsHitTesting(false)')
ck('pulse has two halo layers', pulse.count('RoundedRectangle') >= 2)
ck('pulse has broad outer halo', 'lineWidth: 10' in pulse and '.blur(radius: 22)' in pulse)
ck('pulse has inner halo', 'lineWidth: 4' in pulse and '.blur(radius: 8)' in pulse)
ck('pulse changes opacity only', '.opacity(slowGlowBright ?' in pulse and '.scaleEffect' not in pulse and '.offset' not in pulse and '.frame' not in pulse)

# Preserve recent performance and motion fixes.
live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
ck('covered live root keeps compact 24-card corridor', 'coveredRenderedChannelLimit: Int = 24' in live)
ck('interactive live root keeps 96-card corridor', 'interactiveRenderedChannelLimit: Int = 96' in live)
ck('hidden root decoder request lane stays Live-only', 'guard store.selectedTab == .live else { return [] }' in section(live,'private func liveTVArtworkLoadIDs','private func scheduleGuideHintAutoHide'))
ck('row preset frame budget remains', 'frameBudgetSettleDuration(for: catalogRowScrollingAnimationPreset)' in APP)
ck('connected popup 2048 prewarm remains', 'maxPixelSize: 2048' in APP and 'scheduleConnectedArtworkPrewarm' in APP)
ck('dynamic wallpaper phase pause remains', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('coordinator post-navigation recovery remains', 'postNavigationVisualRecoveryActive' in UNITY)
ck('detail dismissal focus prep remains', 'prepareCatalogDetailDismissalFocusHandoff' in APP)
ck('Favorites isolation remains', 'quickPanelRestoreSection != "favoritesCatalog"' in APP)

# Provider/playback/runtime work remains outside this corrective candidate.
DONOR={
'Sources/NuvioPluginClient.swift':'0495f210b9d2ca0b316f0124e1bb4b584147a303c3cb193f48f5cee4fa7259e5',
'Sources/BackupStreamingClient.swift':'032b7ee7663491e93057d7e3702ba7bc55674a8cb10b9336093e7a0399dd4a49',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
'Sources/RemoteImageFit.swift':'093c1c108270e746e463c6ff72b018af4eb62e19afaeaa894947fe38f3518f0f',
'Sources/CatalogStore.swift':'639979f0bd4b8385dd928e30e82db795bc04635fd557b82f73a60cc3e24dd14f',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'BackendBackupStreamingRuntime/backup_streaming_runtime.py':'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py':'340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/SportsScoresScheduleProvider.swift':'db0b16cf928d363275454e74c7db2dcffdc98ff52f7df58188eb22cb435279af',
}
for rel,expected in DONOR.items(): ck('donor lock '+rel, sha(rel)==expected)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source declared in project', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
