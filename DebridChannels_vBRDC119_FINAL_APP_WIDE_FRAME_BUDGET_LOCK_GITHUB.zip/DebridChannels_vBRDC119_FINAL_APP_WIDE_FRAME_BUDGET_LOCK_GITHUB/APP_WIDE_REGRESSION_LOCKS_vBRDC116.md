# vBRDC116 Regression Locks

1. Focused catalog preview: 1.5s dwell, muted, 720p cap, maximum 35 seconds, no loop.
2. Same-title Media Profile remains the same preview ownership identity; completion must not trigger another preview merely from opening/closing that UI.
3. Manual Trailer launch remains full trailer playback and is not subject to the 35-second focused-card cap.
4. Different catalog card/row identity may start its own bounded preview.
5. vBRDC115 MediaFlow LAN Live TV routing remains unchanged.
6. vBRDC109 catalog open/close and vBRDC103 row-scrolling engine remain unchanged.
