# vBRDC079 — Dynamic Wallpaper Evolution

Release: **vBRDC079**  
Marketing version: **1.0.782**  
Apple build: **782**  
Code Name: **UNITY**

Built only from packaged **vBRDC078**.

## Scope

This build changes only the Appearance / Dynamic Live Wallpaper system plus release identifiers. Playback, VOD exit recovery, automatic resume/autoplay, Source Intelligence, Sports, UNITY catalog motion, credential handling, and backend runtimes remain inherited from vBRDC078.

## Curated procedural themes

The old 48-theme list contained many near-duplicate smoke/projector variants. vBRDC079 replaces the visible picker with 25 distinct themes:

- Digital Rain
- Emerald Code
- Cyber Rain
- Falling Stars
- Deep Galaxy
- Warp Space
- Cosmic Dust
- Aurora
- Meteor Shower
- Black Hole
- Constellations
- Neon Grid
- Data Grid
- Electric Storm
- Fire Embers
- Snowfall
- Rain on Glass
- Underwater
- OLED Particles
- Spotlight Smoke
- Cinematic Smoke
- Cinema Projector
- Black Velvet Smoke
- OLED Cinema
- Midnight Smoke

Legacy saved presets are normalized to the nearest curated equivalent instead of becoming invalid.

## Custom Animated Wallpaper URL

Appearance now includes **Custom Animated Wallpaper URL**. When enabled it accepts HTTPS URLs for GIF, animated WebP, MP4, MOV, and M4V.

Safety/performance rules:

- HTTPS only.
- 32 MB maximum downloaded asset size.
- Download once and cache locally.
- Keep only a small bounded cache.
- Invalid/failed assets fall back to the selected built-in theme.
- MP4/MOV/M4V use a muted AVFoundation loop.
- GIF/WebP are downsampled and frame-count bounded according to Visual Performance mode.
- The entire dynamic wallpaper surface remains conditionally unmounted during playback, guides, detail screens, Search, Settings, quick panels, and every non-Live-TV surface.
- The wallpaper cannot compete with KSPlayer because its render surface does not exist while playback owns the screen.

## Locked inherited behavior

vBRDC079 intentionally does not modify:

- VOD playback engine logic.
- vBRDC076 playback-priority protection.
- vBRDC077 automatic resume + automatic play.
- vBRDC078 VOD exit / catalog interactivity recovery.
- Resume-cache format.
- Source Intelligence / TorBox behavior while whitelist approval is pending.
- Sports runtime.
- UNITY catalog motion system.
- Backend runtime trees.
