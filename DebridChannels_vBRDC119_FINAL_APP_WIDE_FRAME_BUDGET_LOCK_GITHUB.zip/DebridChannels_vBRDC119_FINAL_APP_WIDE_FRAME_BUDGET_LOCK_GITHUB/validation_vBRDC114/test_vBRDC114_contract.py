from pathlib import Path
import plistlib, hashlib, sys, re
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
ROUTER=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def section(text,a,b):
    i=text.find(a)
    if i<0:return ''
    j=text.find(b,i+len(a))
    return text[i:] if j<0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f:return plistlib.load(f)
def sha(path): return hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC114' and toppl.get('DebridChannelsReleaseID')=='vBRDC114')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.817' and toppl.get('CFBundleShortVersionString')=='1.0.817')
ck('build', apppl.get('CFBundleVersion')=='817' and toppl.get('CFBundleVersion')=='817')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.817')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 817')==2)

live=section(APP,'final class LiveTVSourceModel: ObservableObject','struct LiveTVScreen: View')
ck('Live TV model found', len(live)>10000)
ck('bootstrap uses MediaFlow forward', 'MediaFlowProxyRouter.forwardRequestIfAllowed(request, kind: .liveTV)' in live)
ck('bootstrap fail-closed if proxy invalid', 'guard let networkRequest = MediaFlowProxyRouter.forwardRequestIfAllowed(request, kind: .liveTV),' in live)
ck('proxied https uses routed request', 'Self.providerSession.data(for: networkRequest)' in live)
ck('proxied/plain http uses routed URL', 'PlainHTTPClient.fetchData(from: networkURL' in live)
ck('upstream accept built before routing', 'request.setValue(accept, forHTTPHeaderField: "Accept")' in live)
ck('upstream UA built before routing', 'request.setValue("DebridChannels-tvOS/560", forHTTPHeaderField: "User-Agent")' in live)
ck('Channels DVR goes through shared fetchText', 'await loadChannelsDVR(base: dvrBase' in live and 'fetchText("\\(base)/devices"' in live)
ck('M3U goes through shared fetchText', 'private func loadM3U' in live and 'await fetchText(url, accept: "audio/x-mpegurl' in live)
ck('Xtream API goes through shared fetchText', 'action=get_live_categories' in live and 'action=get_live_streams' in live)
ck('Xtream XMLTV goes through shared fetchText', '/xmltv.php?username=' in live)
ck('Channels DVR XMLTV goes through shared fetchText', '/devices/ANY/guide/xmltv?duration=' in live)
ck('v110 bootstrap results remain durable', '_ = await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata, maxWait: 2.00)' in live)
ck('no destructive metadata guard in live model', 'guard await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata' not in live)
ck('final playback still uses liveTV stream wrapper', 'MediaFlowProxyRouter.playbackURLIfAllowed(for: originalURL, kind: .liveTV)' in APP)
ck('grid preview still uses liveTV stream wrapper', 'liveTVGridFocusPreviewURL' in APP and 'playbackURLIfAllowed(for: originalURL, kind: .liveTV)' in APP)

ck('forward API accepts route kind', 'kind: MediaFlowProxyRouteKind = .vod' in ROUTER)
ck('forward direct mode returns original request', 'guard shouldProxy(kind: kind, snapshot: config) else { return original }' in ROUTER)
ck('forward validates selected route kind', 'configurationError(kind: kind, snapshot: config)' in ROUTER)
ck('forward uses proxy forward endpoint', 'endpoint: "/proxy/forward"' in ROUTER)
ck('forward preserves method', 'forwarded.httpMethod = original.httpMethod' in ROUTER)
ck('forward preserves body', 'forwarded.httpBody = original.httpBody' in ROUTER)

# Previously accepted visual/runtime boundaries remain present.
ck('v109 single-owner catalog state retained', '@State private var unityCatalogBranchTransitionActive: Bool = false' in APP)
ck('v107 focused preview ownership retained', 'focusedCardPreviewRequestedKey == requestedKey' in APP)
ck('v106 VOD visible rotation retained', 'vBRDC106-production-rotation' in APP and '7_000_000_000' in APP)
ck('v105 Live TV 3s 15s preview retained', '3_000_000_000' in APP and '15_000_000_000' in APP)
ck('v103 persistent row renderer retained', 'persistentRailMotionPhase' in APP and 'commitPersistentHorizontalMove' in APP)
ck('row visual system exists', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
