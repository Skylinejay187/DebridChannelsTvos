from pathlib import Path
import hashlib, plistlib, re, sys, yaml
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
PROJECT=yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id', app.get('DebridChannelsReleaseID')=='vBRDC083' and top.get('DebridChannelsReleaseID')=='vBRDC083')
ck('marketing version', app.get('CFBundleShortVersionString')=='1.0.786' and top.get('CFBundleShortVersionString')=='1.0.786')
ck('build version', app.get('CFBundleVersion')=='786' and top.get('CFBundleVersion')=='786')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.786')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='786')

# Visible procedural library + new Nexus Lines family.
ck('Nexus Lines preset', '"Nexus Lines"' in APP)
ck('Nexus normalization', 'key.contains("nexus")' in APP and 'return "Nexus Lines"' in APP)
ck('Nexus family route', 'case "Nexus Lines": return "nexusLines"' in APP and 'case "nexusLines":' in APP)
ck('Nexus renderer', 'private func drawNexusLines(' in APP)
ck('Nexus axis motion', 'let horizontal = index % 2 == 0' in APP and 'red/green/blue/yellow heads travel horizontally and vertically' in APP)

# Wallpaper visibility correction.
ck('procedural screen blend', '.blendMode(.screen)' in APP)
ck('procedural brightness', '.brightness(0.08)' in APP)
ck('procedural opacity raised', '.opacity(detailLevel == 1 ? 0.86 : (detailLevel == 2 ? 0.91 : 0.95))' in APP)
ck('live wallpaper surface opacity raised', '.opacity(0.94)' in APP and 'Color.black.opacity(0.04)' in APP and 'Color.black.opacity(0.10)' in APP)
ck('digital rain visibility raised', 'let opacity = 0.32 + Double(column % 4) * 0.045' in APP and 'Color.white.opacity(0.72)' in APP)

# Native-resolution custom wallpaper path.
ck('UHD long edge target', 'nativePixelTarget = min(3840, max(1920, screenLongEdge))' in APP)
ck('device native bounds', 'UIScreen.main.nativeBounds' in APP)
ck('single frame streaming', 'Only ONE decoded frame is retained at a time' in APP and 'self.image = frame' in APP)
ck('no UIImageView frame array', 'animationImages = animation.frames' not in APP and 'frameLimit =' not in APP)
ck('decoder generation guard', 'decoderGeneration' in APP and 'self.decoderGeneration == generation' in APP)
ck('custom edge-to-edge', '.frame(maxWidth: .infinity, maxHeight: .infinity)' in APP and 'view.contentMode = .scaleAspectFill' in APP)
ck('4K video aspect fill', 'playerLayer.videoGravity = .resizeAspectFill' in APP)
ck('larger UHD disk cache', '96 * 1024 * 1024' in APP)
ck('https only', 'remoteURL.scheme?.lowercased() == "https"' in APP)
ck('custom formats intact', all(x in APP for x in ['"gif"','"webp"','"mp4"','"mov"','"m4v"']))

# Hard playback/resource isolation must remain.
ck('UNITY wallpaper permit', 'unityAnimations.allows(.dynamicWallpaper)' in APP)
ck('playback hard gate', '&& store.playbackURL == nil' in APP)
ck('detail hard gate', '&& store.selectedDetail == nil' in APP)
ck('search hard gate', '&& !store.searchActive' in APP)
ck('guide hard gate', '&& !showGuide' in APP)
ck('conditional mount', 'if liveWallpaperOwnsRenderBudget' in APP and 'DynamicWallpaperSurface(' in APP)

# Sensitive donor files must remain byte-identical to packaged v082.
BASE_HASHES={'Sources/CatalogStore.swift': '10329bae4d44d46357ede17f9b108d2f7db7c16db9dec0e0af7cfba0ca259a8e', 'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86', 'Sources/UnityAnimationCoordinator.swift': '15320d4424cf64faba13e3a94ff099e939cc561254d05ce267b8300ceed9e305', 'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669', 'Sources/PlaybackResumeCache.swift': '4cdf1bf8d2a78904b4bca221f23388a72ee16b63e2c8be8cd59d1f1fdc95364e', 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift': '9d7c3524792776640d74aaf5f7ba820a8bdb1259d0662a0c97604a257fd08c29', 'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7'}
for rel, expected in BASE_HASHES.items():
    ck('donor lock '+rel, sha(rel)==expected)

# XcodeGen source membership safeguard from v082 remains valid.
entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source compiled', all_swift.issubset(paths))

failed=[n for n,c in checks if not c]
for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
