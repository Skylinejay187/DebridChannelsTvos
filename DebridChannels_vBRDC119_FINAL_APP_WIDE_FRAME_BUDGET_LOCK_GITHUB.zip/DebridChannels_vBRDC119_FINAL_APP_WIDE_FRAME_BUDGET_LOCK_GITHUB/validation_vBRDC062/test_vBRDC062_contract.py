from pathlib import Path
import plistlib
root=Path(__file__).resolve().parents[1]
play=(root/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
universal=(root/'Sources/UniversalCodecSupport.swift').read_text()
foundation=(root/'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()

# Keep the restored vBRDC061 deep VOD ceiling and existing startup reserve targets.
assert 'isVODStylePlayback ? 300 : (!isLiveStream ? 90 : 12)' in play
assert 'isHighMemoryVOD ? 3 : (isVODStylePlayback ? 5' in play
# Instant-open main VOD must be explicit inside the VOD profile.
vod_profile=play.split('if isVODStylePlayback {',1)[1].split('} else if !isLiveStream',1)[0]
assert 'options.isSecondOpen = true' in vod_profile
# Real engine buffer endpoint must be carried through every presentation layer.
assert 'layer.player.playableTime' in play
assert 'onBufferUpdate?(playable, total)' in play
assert 'var onBufferUpdate: ((Double, Double) -> Void)? = nil' in foundation
assert 'var onKSBufferUpdate: ((Double, Double) -> Void)? = nil' in universal
assert 'onKSBufferUpdate: { playable, total in' in app
assert 'bufferedProgress: bufferedPlaybackProgress' in app
assert 'var bufferedProgress: Double? = nil' in app
assert 'buffer ghost' in app.lower()
# VOD-only reconnect hardening; do not retry authorization failures.
assert 'formatOptions["reconnect_on_network_error"] = "1"' in play
assert 'formatOptions["reconnect_on_http_error"] = "408,429,500,502,503,504"' in play
assert 'formatOptions["reconnect_delay_max"] = "2"' in play
assert '401' in play and '403' in play

proj=(root/'project.yml').read_text()
assert 'MARKETING_VERSION: 1.0.765' in proj
assert 'CURRENT_PROJECT_VERSION: 765' in proj
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with open(root/rel,'rb') as f: p=plistlib.load(f)
    assert p['CFBundleShortVersionString']=='1.0.765'
    assert p['CFBundleVersion']=='765'
    assert p['DebridChannelsReleaseID']=='vBRDC062'
print('PASS vBRDC062 contract')
