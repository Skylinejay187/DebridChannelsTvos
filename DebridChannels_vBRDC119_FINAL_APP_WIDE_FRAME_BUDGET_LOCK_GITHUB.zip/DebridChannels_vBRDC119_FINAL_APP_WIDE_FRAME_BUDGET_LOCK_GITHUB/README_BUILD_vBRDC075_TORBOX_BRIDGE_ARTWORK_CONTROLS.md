# Debrid Channels vBRDC075 — TorBox Pro Search Bridge + Artwork/Chrome Controls

Release ID: **vBRDC075**  
Marketing version: **1.0.778**  
Apple build: **778**  
Code name: **UNITY**  
Donor: packaged **vBRDC074** only.

## Why TorBox Usenet was still showing zero

The app-side ID, parser, cancellation and false-zero corrections in vBRDC073/vBRDC074 were not sufficient because TorBox's internal Search API is currently **source-IP-whitelisted**. A TorBox Pro account authorizes the TorBox service, but it does not make an arbitrary Apple TV IP an approved Search API host. TorBox's special Search Usenet NZB references also are not ordinary public NZB downloads; they are meant to be handled by TorBox.

vBRDC075 therefore keeps the existing direct/backend/Newznab compatibility paths but adds an explicit **TorBox Pro Search Bridge** for the restricted discovery step.

## TorBox Pro Search Bridge setup

Use a trusted AIOStreams public instance that can access TorBox Search:

1. Open a trusted AIOStreams public instance in a browser.
2. Create a dedicated configuration for Debrid Channels.
3. Add **TorBox** under Services and enter the TorBox Pro API key there.
4. Add **TorBox Search** and configure its source as **Usenet**. Keeping this bridge configuration dedicated to TorBox Search Usenet avoids mixing torrent/provider results into the orange Usenet lane.
5. Optional but recommended for uncached releases: enable AIOStreams **Cache & Play** so AIOStreams can wait for TorBox to finish the Usenet download and then serve the playback link.
6. Create/save the AIOStreams user/configuration.
7. Copy its unique **Direct Manifest / installation URL ending in `/manifest.json`**.
8. In Debrid Channels open **Settings → Streaming Catalogs → Global Debrid Credentials → TorBox Pro Search Bridge Direct Manifest URL** and paste it.
9. Keep the normal **TorBox API key** in Debrid Channels too. It remains the native TorBox credential for the existing TorBox account/playback paths.

### Privacy/security boundary

The Direct Manifest URL is credential-like: its path identifies an AIOStreams configuration and may carry an encrypted profile secret. Treat it like a password. Debrid Channels stores it as a credential setting and clears it on a true fresh-install credential reset.

Debrid Channels does **not** append or send its separately stored TorBox API key to the bridge request. The AIOStreams configuration owns the TorBox credential you entered on that chosen instance. Only use a host you trust.

## Source Intelligence behavior

- Configured TorBox Pro Search Bridge is attempted first.
- Bridge stream results remain explicitly tagged as **TorBox Usenet** and stay in the orange TorBox Usenet provider lane.
- Bridge direct HTTP(S) playback URLs are playable without pretending they are public NZB links.
- The TorBox Usenet lane remains uncapped by the ordinary 25/50-link Source Intelligence limit.
- Direct native TorBox Search, backend relay, Newznab compatibility, and owned-library matching remain fallback paths.
- When no bridge is configured and the restricted routes cannot provide releases, the app now surfaces the whitelist/bridge requirement instead of silently presenting a healthy-looking zero-result state.

## New Appearance controls

Two persistent controls were added under **Settings → Appearance** and both default to On to preserve the existing visual behavior:

- **Media Information Connector Line** — On keeps the focused-card → Media Information animated line. Off removes the connector and also removes its staging delay so Media Information opens immediately.
- **Top-Left Debrid Channels Logo** — On shows the app chrome wordmark; Off hides only the wordmark and leaves top navigation intact.

Both settings are included in profile backup/restore and stable UI defaults.

## Media Information artwork restoration

The previous donor still exposed a Fanart.tv key field while the actual Fanart.tv fetch path had been hard-disabled. vBRDC075 restores provider use for **detail-only** artwork while keeping catalog/startup work bounded:

- Fanart.tv key is read and used again for detail artwork.
- Existing catalog TMDB/TVDB identities are reused before extra identity lookups.
- Alternate detail candidates are assembled concurrently from direct Fanart.tv, the Debrid Channels backend artwork pool (which can include Fanart/TVDB/TMDB), and alternate TMDB backdrops.
- Provider pools are interleaved and cached per title, then rotated on repeated Media Information opens.
- The currently displayed/default artwork is excluded when alternatives exist, preventing the detail panel from needlessly reusing the focused-card image.
- Requests have bounded timeouts and remain detail-only so the old global catalog/startup performance regression is not reintroduced.

## Preserved vBRDC073/vBRDC074 corrections

- No invalidation race on the retained Source Intelligence `URLSession`.
- Explicit TorBox task cancellation remains.
- Automatic resume stays clock-confirmed and uses an in-place KSPlayer absolute seek.
- Resume cache format is unchanged.
- KSPlayer donor surface is unchanged.
- Multi-debrid/Torrentio per-account behavior is unchanged.
- Sports UNITY, UNITY visual system, catalog motions, and backend runtime trees are unchanged.

## Validation

- vBRDC075 corrective contracts: **24/24 passed**.
- Inherited backend runtime tests: **35/35 passed**.
- Swift syntax parse: **62/62 Swift files passed**.
- Backend runtime directories are byte-for-byte identical to the vBRDC074 donor (excluding test-generated cache files, which are removed before packaging).
- Locked Playback Resume Cache, KSPlayer surface and UnityCatalogVisualSystem donor hashes are preserved.

GitHub Actions / Xcode remains the authoritative full tvOS compile.
