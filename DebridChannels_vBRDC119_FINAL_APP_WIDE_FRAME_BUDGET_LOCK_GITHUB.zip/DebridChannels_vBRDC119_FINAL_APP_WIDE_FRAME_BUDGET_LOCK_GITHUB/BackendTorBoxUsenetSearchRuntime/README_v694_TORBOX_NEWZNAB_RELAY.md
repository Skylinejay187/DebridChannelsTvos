# Backend v694 — TorBox Pro Newznab-first Usenet Relay

`POST /api/torbox/usenet/search`

The Apple app sends the user's TorBox key transiently as `X-TorBox-Token`. The relay does not persist or cache the token and does not include it in responses.

v694 searches `https://search-api.torbox.app/newznab/api` first using media-specific Newznab (`movie` / `tvsearch`) and then generic `search`. XML is normalized to the existing `{ success, data: { nzbs: [...] } }` contract. Legacy Voyager JSON routes remain compatibility-only after Newznab.

Usenet creation, polling and final playback URL resolution remain Apple app -> TorBox Main API and are not proxied by this relay.
