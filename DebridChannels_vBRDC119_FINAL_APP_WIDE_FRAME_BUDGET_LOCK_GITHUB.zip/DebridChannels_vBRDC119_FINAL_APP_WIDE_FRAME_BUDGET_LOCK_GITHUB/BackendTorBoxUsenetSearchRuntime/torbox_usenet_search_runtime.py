"""Debrid Channels backend v694 — TorBox Pro Newznab-first Usenet relay.

Route:
    POST /api/torbox/usenet/search

The user's TorBox API token is accepted only in ``X-TorBox-Token`` for the live
request. It is never persisted, cached, returned, or intentionally logged. The
relay searches TorBox's paid Newznab surface first and normalizes XML results to
the JSON shape already consumed by the Apple app. The older Voyager JSON search
is compatibility-only. Usenet creation/playback remains app -> Main API.
"""

from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

SEARCH_BASE = "https://search-api.torbox.app"
NEWZNAB_API = f"{SEARCH_BASE}/newznab/api"
SCHEMA_VERSION = 2
MAX_RESPONSE_BYTES = 8 * 1024 * 1024


class TorBoxUsenetRelayError(RuntimeError):
    def __init__(self, message: str, status_code: int = 502) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class RelayConfig:
    timeout_seconds: int = 20
    maximum_response_bytes: int = MAX_RESPONSE_BYTES


@dataclass(frozen=True)
class HTTPResult:
    status: int
    body: bytes

    def json(self) -> Any:
        return json.loads(self.body.decode("utf-8", errors="replace"))


HTTPFetcher = Callable[[str, Mapping[str, str], int, int], HTTPResult]


def _default_fetcher(url: str, headers: Mapping[str, str], timeout: int, maximum_bytes: int) -> HTTPResult:
    # nosec B310 - all target URLs are built from the fixed TorBox Search host.
    request = Request(url=url, method="GET", headers=dict(headers))
    try:
        with urlopen(request, timeout=timeout) as response:
            return HTTPResult(status=int(getattr(response, "status", 200)), body=response.read(maximum_bytes + 1))
    except HTTPError as exc:
        return HTTPResult(status=int(exc.code), body=exc.read(maximum_bytes + 1))
    except URLError as exc:
        raise TorBoxUsenetRelayError(f"TorBox Search connection failed: {_safe_message(exc.reason)}") from exc


def _safe_message(value: Any, limit: int = 360) -> str:
    text = str(value or "").replace("\r", " ").replace("\n", " ").strip()
    return text[:limit] or "Unknown error"


def _clean_token(raw: Any) -> str:
    token = str(raw or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token or len(token) > 4096:
        return ""
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in token):
        return ""
    return token


def _clean_text(raw: Any, limit: int) -> str:
    return str(raw or "").replace("\r", " ").replace("\n", " ").strip()[:limit]


def _optional_nonnegative_int(raw: Any) -> Optional[int]:
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value >= 0 else None


def _bool(raw: Any, default: bool = False) -> bool:
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, (int, float)):
        return bool(raw)
    if isinstance(raw, str):
        return raw.strip().lower() in {"1", "true", "yes", "on", "cached", "owned"}
    return default


def _newznab_urls(payload: Mapping[str, Any], token: str) -> Tuple[str, ...]:
    query = _clean_text(payload.get("query"), 300)
    if not query:
        raise TorBoxUsenetRelayError("A search query is required.", status_code=422)

    season = _optional_nonnegative_int(payload.get("season"))
    episode = _optional_nonnegative_int(payload.get("episode"))
    is_episode = (episode or 0) > 0 or season is not None

    base: Dict[str, str] = {
        "apikey": token,
        "q": query,
        "extended": "1",
        "limit": "100",
    }

    media = dict(base)
    media["t"] = "tvsearch" if is_episode else "movie"
    identity_type = _clean_text(payload.get("identityType"), 16).lower()
    identity_id = _clean_text(payload.get("identityID"), 80)
    if identity_type == "imdb" and identity_id:
        media["imdbid"] = identity_id[2:] if identity_id.lower().startswith("tt") else identity_id
    elif identity_type == "tmdb" and identity_id:
        media["tmdbid"] = identity_id
    elif identity_type == "tvdb" and identity_id:
        media["tvdbid"] = identity_id
    if season is not None:
        media["season"] = str(season)
    if episode is not None and episode > 0:
        media["ep"] = str(episode)

    generic = dict(base)
    generic["t"] = "search"
    urls = [f"{NEWZNAB_API}?{urlencode(media)}", f"{NEWZNAB_API}?{urlencode(generic)}"]
    return tuple(dict.fromkeys(urls))


def _legacy_query_items(payload: Mapping[str, Any]) -> Dict[str, str]:
    values = {
        "metadata": "false",
        "check_cache": "true" if _bool(payload.get("checkCache"), True) else "false",
        "check_owned": "true" if _bool(payload.get("checkOwned"), True) else "false",
        "search_user_engines": "true" if _bool(payload.get("searchUserEngines"), False) else "false",
        "cached_only": "true" if _bool(payload.get("cachedOnly"), False) else "false",
    }
    season = _optional_nonnegative_int(payload.get("season"))
    episode = _optional_nonnegative_int(payload.get("episode"))
    if season is not None:
        values["season"] = str(season)
    if episode is not None and episode > 0:
        values["episode"] = str(episode)
    return values


def _legacy_urls(payload: Mapping[str, Any]) -> Tuple[str, ...]:
    params = _legacy_query_items(payload)
    urls: List[str] = []
    identity_type = _clean_text(payload.get("identityType"), 16).lower()
    identity_id = _clean_text(payload.get("identityID"), 80)
    if identity_type in {"imdb", "tmdb", "tvdb"} and identity_id:
        identity = quote(f"{identity_type}:{identity_id}", safe=":")
        urls.append(f"{SEARCH_BASE}/usenet/{identity}?{urlencode(params)}")
    query = _clean_text(payload.get("query"), 300)
    if query:
        canonical = dict(params)
        canonical["query"] = query
        urls.append(f"{SEARCH_BASE}/usenet/search?{urlencode(canonical)}")
    return tuple(urls)


def _local_name(tag: str) -> str:
    if "}" in tag:
        return tag.rsplit("}", 1)[-1].lower()
    if ":" in tag:
        return tag.rsplit(":", 1)[-1].lower()
    return tag.lower()


def _parse_newznab(body: bytes) -> Dict[str, Any]:
    try:
        root = ET.fromstring(body)
    except ET.ParseError as exc:
        prefix = body[:512].decode("utf-8", errors="replace")
        raise TorBoxUsenetRelayError(f"TorBox Newznab returned unreadable XML: {_safe_message(prefix)}") from exc

    if _local_name(root.tag) == "error":
        description = root.attrib.get("description") or root.attrib.get("code") or "Newznab request rejected"
        raise TorBoxUsenetRelayError(f"TorBox Newznab rejected the search: {_safe_message(description)}", status_code=502)

    nzbs: List[Dict[str, Any]] = []
    for item in root.iter():
        if _local_name(item.tag) != "item":
            continue
        title = ""
        link = ""
        guid = ""
        category = ""
        pubdate = ""
        enclosure_url = ""
        enclosure_length = 0
        attrs: Dict[str, str] = {}
        for child in list(item):
            name = _local_name(child.tag)
            text = (child.text or "").strip()
            if name == "title":
                title = text
            elif name == "link":
                link = text
            elif name == "guid":
                guid = text
            elif name == "category":
                category = text
            elif name == "pubdate":
                pubdate = text
            elif name == "enclosure":
                enclosure_url = (child.attrib.get("url") or "").strip()
                try:
                    enclosure_length = int(child.attrib.get("length") or 0)
                except (TypeError, ValueError):
                    enclosure_length = 0
            elif name == "attr":
                attr_name = (child.attrib.get("name") or "").strip().lower()
                if attr_name:
                    attrs[attr_name] = (child.attrib.get("value") or "").strip()

        nzb_url = enclosure_url or link
        if not title or not nzb_url:
            continue
        try:
            size = int(attrs.get("size") or enclosure_length or 0)
        except (TypeError, ValueError):
            size = enclosure_length
        raw_hash = attrs.get("hash") or attrs.get("nzbhash") or attrs.get("usenet_hash") or ""
        if not raw_hash and guid and "://" not in guid and "apikey=" not in guid.lower():
            raw_hash = guid
        tracker = attrs.get("indexer") or attrs.get("source") or category or "TorBox Newznab"
        nzbs.append(
            {
                "hash": raw_hash,
                "raw_title": title,
                "title": title,
                "size": max(0, size),
                "tracker": tracker,
                "nzb": nzb_url,
                "age": attrs.get("age") or pubdate,
                "cached": _bool(attrs.get("cached") or attrs.get("cache"), False),
                "owned": _bool(attrs.get("owned") or attrs.get("is_owned"), False),
            }
        )

    return {"success": True, "schema": SCHEMA_VERSION, "data": {"source": "torbox-newznab", "nzbs": nzbs}}


def _result_count(value: Any) -> int:
    if not isinstance(value, Mapping):
        return 0
    payload = value.get("data", value)
    if isinstance(payload, Mapping):
        for key in ("nzbs", "results", "items", "usenet"):
            if isinstance(payload.get(key), list):
                return len(payload[key])
    return 0


def _extract_json_detail(body: bytes) -> str:
    try:
        value = json.loads(body.decode("utf-8", errors="replace"))
    except Exception:
        return _safe_message(body[:320].decode("utf-8", errors="replace"))
    if isinstance(value, Mapping):
        for key in ("detail", "error", "message"):
            if value.get(key):
                return _safe_message(value.get(key))
    return ""


def relay_torbox_usenet_search(
    payload: Mapping[str, Any],
    token: str,
    config: RelayConfig = RelayConfig(),
    fetcher: HTTPFetcher = _default_fetcher,
) -> Any:
    """Search TorBox Newznab first, legacy Voyager second, without retaining token."""

    clean_token = _clean_token(token)
    if not clean_token:
        raise TorBoxUsenetRelayError("A TorBox API token is required.", status_code=401)

    errors: List[str] = []
    completed_route = False
    newznab_headers = {
        "Authorization": f"Bearer {clean_token}",
        "Accept": "application/rss+xml, application/xml, text/xml",
        "Accept-Encoding": "identity",
        "User-Agent": "DebridChannels-Backend/v694 TorBoxNewznabRelay",
    }

    for url in _newznab_urls(payload, clean_token):
        try:
            result = fetcher(url, newznab_headers, config.timeout_seconds, config.maximum_response_bytes)
            if len(result.body) > config.maximum_response_bytes:
                errors.append("TorBox Newznab response exceeded the relay size limit.")
                continue
            if 200 <= result.status < 300:
                parsed = _parse_newznab(result.body)
                completed_route = True
                if _result_count(parsed) > 0:
                    return parsed
            else:
                errors.append(f"TorBox Newznab HTTP {result.status}: {_extract_json_detail(result.body)}")
        except TorBoxUsenetRelayError as exc:
            errors.append(str(exc))
        except Exception as exc:
            errors.append(f"TorBox Newznab connection failed: {_safe_message(exc)}")

    # Compatibility-only JSON search. It never runs ahead of Newznab and never stops
    # an authenticated Newznab zero from being reported as a real zero.
    legacy_headers = {
        "Authorization": f"Bearer {clean_token}",
        "Accept": "application/json",
        "Accept-Encoding": "identity",
        "User-Agent": "DebridChannels-Backend/v694 TorBoxLegacySearch",
    }
    for url in _legacy_urls(payload):
        try:
            result = fetcher(url, legacy_headers, config.timeout_seconds, config.maximum_response_bytes)
            if len(result.body) > config.maximum_response_bytes:
                errors.append("Legacy TorBox response exceeded the relay size limit.")
                continue
            if 200 <= result.status < 300:
                try:
                    parsed = result.json()
                except Exception:
                    errors.append("Legacy TorBox search returned unreadable JSON.")
                    continue
                completed_route = True
                if _result_count(parsed) > 0:
                    return parsed
            else:
                errors.append(f"Legacy TorBox search HTTP {result.status}: {_extract_json_detail(result.body)}")
        except TorBoxUsenetRelayError as exc:
            errors.append(str(exc))
        except Exception as exc:
            errors.append(f"Legacy TorBox connection failed: {_safe_message(exc)}")

    if completed_route:
        return {"success": True, "schema": SCHEMA_VERSION, "data": {"source": "torbox-newznab", "nzbs": []}}

    detail = "; ".join(errors[-4:]) if errors else "TorBox Pro search did not return a usable response."
    detail = detail.replace(clean_token, "[redacted]")
    raise TorBoxUsenetRelayError(detail, status_code=502)


def create_fastapi_router(config: RelayConfig = RelayConfig()):
    """Create the search-only FastAPI router without making FastAPI a test dependency."""
    try:
        from fastapi import APIRouter, Header, HTTPException
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("FastAPI is required to create the TorBox Usenet relay router") from exc

    router = APIRouter()

    @router.post("/api/torbox/usenet/search")
    async def torbox_usenet_search_endpoint(
        body: Dict[str, Any],
        x_torbox_token: str = Header(default="", alias="X-TorBox-Token"),
    ):
        try:
            return relay_torbox_usenet_search(body, x_torbox_token, config=config)
        except TorBoxUsenetRelayError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc

    return router
