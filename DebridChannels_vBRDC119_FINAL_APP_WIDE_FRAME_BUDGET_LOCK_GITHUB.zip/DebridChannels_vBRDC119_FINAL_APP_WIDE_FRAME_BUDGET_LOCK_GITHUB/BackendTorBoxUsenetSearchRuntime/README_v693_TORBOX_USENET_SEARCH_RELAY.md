# Backend v693 — TorBox Usenet Search Relay

This is an additive Debrid Channels backend runtime for **native TorBox Usenet discovery**. It does not replace Torrentio and does not require Torrentio to be installed.

## Why it exists

TorBox's Main API (`api.torbox.app`) owns Usenet processing: account auth, creating a Usenet download, listing jobs, unpacking/status, and requesting the final download URL. Release discovery is a separate Voyager Search service (`search-api.torbox.app`). When the direct Apple TV path to Voyager hits a DNS, TLS, routing, or transport-specific failure, Debrid Channels uses this fixed backend path as an alternate discovery route.

The Apple app therefore uses this order:

1. Direct Apple TV → TorBox Voyager search.
2. Debrid Channels backend → TorBox Voyager search via this relay.
3. TorBox Main API owned-library match as a final fallback.

Playback is **not proxied through this runtime**. After a result is selected, the app uses the user's TorBox account directly for create/status/request-download operations.

## Mounting

```python
from BackendTorBoxUsenetSearchRuntime.torbox_usenet_search_runtime import (
    RelayConfig,
    create_fastapi_router,
)

app.include_router(create_fastapi_router(RelayConfig(timeout_seconds=18)))
```

Route:

`POST /api/torbox/usenet/search`

The Apple app sends its saved TorBox token in `X-TorBox-Token` only for that request. Keep the route behind the backend's normal TLS, abuse protection, and request-size limits.

## Credential boundary

The runtime never owns a TorBox token. It does not write it to disk, cache it, include it in a URL, return it in JSON, or deliberately log it. Configure reverse-proxy/application request logging so authorization-style headers are excluded as an additional deployment safeguard.

## Deployment requirement

The relay gives Debrid Channels an alternate backend transport path; it does **not** bypass TorBox authorization. The request remains authenticated with the user's TorBox bearer credential and the upstream host is fixed to TorBox Search. When discovery is unavailable or rejected, vBRDC060 still searches matching items already present in the user's TorBox Usenet library through the Main API and surfaces a visible provider status instead of silently hiding Usenet.

## Torrentio independence

Torrentio remains a removable optional Stremio provider. Removing Torrentio changes only `managedTorrentioEnabled`; it never clears the global `torBoxApiKey`. Native TorBox Usenet discovery and playback read the global TorBox credential directly and do not depend on `ManagedAddonBridge`.
