import json
import unittest
from urllib.parse import parse_qs, urlparse

from torbox_usenet_search_runtime import (
    HTTPResult,
    RelayConfig,
    TorBoxUsenetRelayError,
    relay_torbox_usenet_search,
)


class FakeFetcher:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, url, headers, timeout, maximum_bytes):
        self.calls.append((url, dict(headers), timeout, maximum_bytes))
        if not self.responses:
            raise RuntimeError("unexpected fetch")
        return self.responses.pop(0)


def json_response(status, payload):
    return HTTPResult(status=status, body=json.dumps(payload).encode("utf-8"))


def xml_response(items=(), status=200):
    rows = []
    for item in items:
        rows.append(
            f'''<item><title>{item.get("title", "Movie.2026")}</title>'''
            f'''<guid>{item.get("guid", "guid-1")}</guid>'''
            f'''<link>{item.get("url", "https://search-api.torbox.app/newznab/api?t=get&amp;id=1")}</link>'''
            f'''<enclosure url="{item.get("enclosure", "https://search-api.torbox.app/newznab/api?t=get&amp;id=1")}" length="{item.get("size", 12345)}" type="application/x-nzb"/>'''
            f'''<newznab:attr name="size" value="{item.get("size", 12345)}"/>'''
            f'''<newznab:attr name="indexer" value="TorBox"/>'''
            '''</item>'''
        )
    xml = '''<?xml version="1.0"?><rss xmlns:newznab="http://www.newznab.com/DTD/2010/feeds/attributes/"><channel>''' + ''.join(rows) + '</channel></rss>'
    return HTTPResult(status=status, body=xml.encode('utf-8'))


class TorBoxUsenetRelayTests(unittest.TestCase):
    def test_newznab_media_search_uses_paid_endpoint_and_normalizes_xml(self):
        fetcher = FakeFetcher([xml_response([{"title": "Movie.2026.2160p", "guid": "abc", "size": 987654321}])])
        result = relay_torbox_usenet_search(
            {"identityType": "imdb", "identityID": "tt1234567", "query": "Movie 2026"},
            "secret-token",
            fetcher=fetcher,
        )
        self.assertTrue(result["success"])
        self.assertEqual(result["data"]["source"], "torbox-newznab")
        self.assertEqual(result["data"]["nzbs"][0]["hash"], "abc")
        self.assertEqual(result["data"]["nzbs"][0]["size"], 987654321)
        url, headers, timeout, maximum_bytes = fetcher.calls[0]
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        self.assertEqual(parsed.scheme, "https")
        self.assertEqual(parsed.netloc, "search-api.torbox.app")
        self.assertEqual(parsed.path, "/newznab/api")
        self.assertEqual(params["t"], ["movie"])
        self.assertEqual(params["q"], ["Movie 2026"])
        self.assertEqual(params["imdbid"], ["1234567"])
        self.assertEqual(params["apikey"], ["secret-token"])
        self.assertEqual(headers["Authorization"], "Bearer secret-token")
        self.assertEqual(timeout, 20)
        self.assertGreater(maximum_bytes, 0)

    def test_empty_media_newznab_falls_back_to_generic_newznab(self):
        fetcher = FakeFetcher([
            xml_response([]),
            xml_response([{"title": "Show.S01E02", "guid": "xyz"}]),
        ])
        result = relay_torbox_usenet_search(
            {"identityType": "tvdb", "identityID": "123", "query": "Show S01E02", "season": 1, "episode": 2},
            "secret",
            fetcher=fetcher,
        )
        self.assertEqual(len(fetcher.calls), 2)
        first = parse_qs(urlparse(fetcher.calls[0][0]).query)
        second = parse_qs(urlparse(fetcher.calls[1][0]).query)
        self.assertEqual(first["t"], ["tvsearch"])
        self.assertEqual(first["tvdbid"], ["123"])
        self.assertEqual(first["season"], ["1"])
        self.assertEqual(first["ep"], ["2"])
        self.assertEqual(second["t"], ["search"])
        self.assertEqual(result["data"]["nzbs"][0]["hash"], "xyz")

    def test_newznab_zero_can_use_legacy_compatibility_result(self):
        fetcher = FakeFetcher([
            xml_response([]),
            xml_response([]),
            json_response(200, {"success": True, "data": {"nzbs": [{"title": "Legacy", "hash": "legacy"}]}}),
        ])
        result = relay_torbox_usenet_search(
            {"identityType": "imdb", "identityID": "tt123", "query": "Movie"},
            "secret",
            fetcher=fetcher,
        )
        self.assertEqual(result["data"]["nzbs"][0]["hash"], "legacy")
        self.assertIn("/usenet/imdb:tt123?", fetcher.calls[2][0])

    def test_authenticated_zero_returns_clean_zero_not_error(self):
        fetcher = FakeFetcher([
            xml_response([]),
            xml_response([]),
            json_response(200, {"success": True, "data": {"nzbs": []}}),
            json_response(200, {"success": True, "data": {"nzbs": []}}),
        ])
        result = relay_torbox_usenet_search(
            {"identityType": "imdb", "identityID": "tt123", "query": "Nothing"},
            "secret",
            fetcher=fetcher,
        )
        self.assertEqual(result["data"]["nzbs"], [])

    def test_rejected_upstream_never_echoes_token_in_exception(self):
        denied = [json_response(403, {"detail": "request rejected"}) for _ in range(4)]
        fetcher = FakeFetcher(denied)
        with self.assertRaises(TorBoxUsenetRelayError) as context:
            relay_torbox_usenet_search({"identityType": "imdb", "identityID": "tt1", "query": "Movie"}, "super-secret", fetcher=fetcher)
        message = str(context.exception)
        self.assertIn("HTTP 403", message)
        self.assertNotIn("super-secret", message)

    def test_missing_token_is_rejected(self):
        with self.assertRaises(TorBoxUsenetRelayError) as context:
            relay_torbox_usenet_search({"query": "Movie"}, "")
        self.assertEqual(context.exception.status_code, 401)

    def test_oversized_response_is_rejected(self):
        config = RelayConfig(maximum_response_bytes=16)
        fetcher = FakeFetcher([HTTPResult(status=200, body=b"x" * 17) for _ in range(2)])
        with self.assertRaises(TorBoxUsenetRelayError):
            relay_torbox_usenet_search({"query": "Movie"}, "secret", config=config, fetcher=fetcher)


if __name__ == "__main__":
    unittest.main()
