# Debrid Channels vBRDC095 — Live Artwork / Pulse Glow / Detail Handoff Recovery

Release: **vBRDC095**  
Marketing version: **1.0.798**  
Apple build: **798**

Built strictly from packaged vBRDC094.

## Physical-device findings corrected

### 1. Persistent Live TV cards no longer collapse to generic cards beneath Catalog
vBRDC093 restored the correct UNITY architecture: one physical `LiveTVScreen` remains mounted beneath Home/Movies/Shows/Sports. However, vBRDC094 still made each tile's `resolvedArtworkSource` return `nil` whenever `loadArtwork` became false. The resulting `onChange` called `artworkLoader.load(nil)`, and that method deliberately cleared both `image` and `imageURL`. In other words, the persistent root survived, but its exact decoded pixels were thrown away as soon as Catalog covered it.

vBRDC095 separates **request permission** from **presentation ownership**:
- Live-only decoder/network work still suspends while Catalog/Sports owns focus.
- Each mounted tile retains its last valid Gracenote/channel-icon/provider bitmap.
- Covered tiles cancel in-flight work without clearing the retained UIImage.
- Replacement artwork can decode without blanking the current bitmap first.
- Gracenote -> channel icon -> provider poster fallback order remains unchanged.

This preserves the actual recent Live TV card images underneath Catalog while keeping vBRDC090-vBRDC094 background-work isolation.

### 2. Focused Card Pulse is now visibly a slow glow
The vBRDC092 glow was technically present but too close to the normal focus border to be visually obvious on a physical TV. vBRDC095 keeps the same slow **5.7 second full cycle** but uses two opacity-only halo layers:
- broad outer halo: 10pt stroke / 22pt blur
- tighter inner halo: 4pt stroke / 8pt blur

No scale, frame, offset, row geometry, connector geometry, or focus position is animated by Pulse Glow.

### 3. Media Information Back no longer creates a one-frame focus gap
The physical video showed the entire row and focused card moving after Media Information closed. The cause was a one-frame identity gap: `detailKeepsSelectedCardVisuallyFocused` only pinned against `selectedDetail`. `closeDetail()` clears `selectedDetail` before the catalog's exact FocusState/anchor release has completed, allowing the card to become visually unfocused for one frame and focused again on the next. Because focused-card dimensions participate in rail layout, that false->true edge moved the focused card and all trailing posters.

vBRDC095 bridges visual focus using:
`selectedDetail ?? detailPresentationAnchorItem`

The existing detail anchor already survives until exact originating row/index restoration is verified. The row therefore remains in one stable focused geometry throughout the reverse popup handoff, and Search-style focus-arrival remains blocked while that anchor exists.

## Preserved systems
- vBRDC093 one-physical-root UNITY architecture
- natural Catalog entry/reverse transition
- all Artwork Hero / Pure Black / other catalog themes
- 24-card covered / 96-card interactive Live TV virtual corridor
- vBRDC092 row-motion frame budgets
- Connected Popup 2048 artwork prewarm
- Dynamic Wallpaper phase-preserving navigation freeze
- Sports/Favorites artwork cache isolation
- resume/autoplay/playback behavior
- In-S / ShowBox / FebBox provider files unchanged in this corrective build

## Validation
- vBRDC095 contract: **60/60 passed**
- Swift syntax parse: **64/64 files**
- backend pytest: **36 passed + 2 subtests**
- plist/project version alignment: passed
- donor audit: only the intended app Swift + version/config files differ from vBRDC094
- package SHA-256 manifest: generated and verified
- ZIP integrity: verified

GitHub Actions/Xcode remains the authoritative Apple SDK compile. Physical Apple TV testing remains authoritative for compositor/frame pacing.
