# Debrid Channels vBRDC093 — UNITY Persistent Root Transition Recovery

**Release ID:** vBRDC093  
**Marketing version:** 1.0.796  
**Apple build:** 796  
**Donor:** packaged vBRDC092 only

## Purpose

vBRDC093 is a corrective UNITY architecture build based on physical Apple TV evidence supplied after vBRDC092. It does not redesign catalog themes or sacrifice the vBRDC090-vBRDC092 scrolling work. It restores one continuous shared visual surface for Live TV, Home, Movies, TV Shows and Sports while keeping expensive hidden work frozen.

The physical recording showed two defects clearly:

1. opening Home/Movies/Shows rows was effectively an abrupt scene insertion instead of a deliberate UNITY presentation;
2. Back from catalog briefly exposed channel-logo/placeholder tiles before the real Live TV artwork tree returned. The flash is visible around ~3.60s and ~8.15s in the supplied recording, with another transition spike later in the clip.

## Root cause

vBRDC090 replaced the physically persistent Live TV hierarchy underneath catalog/Sports with `FrozenLiveTVBackdrop`. The donor was visually similar, but it was a different SwiftUI tree. On Back the donor disappeared and a new/active `LiveTVScreen` became visible, exposing its intermediate channel-icon/artwork state for one or more frames. This violated the original UNITY invariant: shared surfaces must be different presentations of one continuously mounted root, not visually similar substitute scenes.

A second regression removed an effective outer presentation transaction for catalog branch entry/exit. Individual row motion remained, but the branch itself appeared/disappeared too abruptly, which made Artwork Hero themes, Pure Black and the other catalog themes feel detached from Live TV.

## Fixes

### One persistent physical UNITY root

There is now exactly one `LiveTVScreen()` mount for the shared Live/Home/Movies/Shows/Sports branch. Catalog and Sports are presentation layers over that same physical root. No snapshot, synthetic donor, placeholder grid or second Live TV hierarchy is allowed to stand in for it.

This means channel artwork/logos do not need to be reconstructed during Back. The pixels revealed underneath the outgoing catalog are the same view instance that was there before catalog opened.

### Natural catalog branch presentation

The root owns one catalog presentation scalar for every catalog theme. Theme selection remains internal to `GridOSCatalogOverlay`; Artwork Hero, Pure Black and all other themes use the same outer UNITY handoff.

- Live/Sports -> catalog: ~0.34s ease-in-out branch presentation.
- Catalog -> Live/Sports: ~0.30s reverse presentation.
- Catalog -> catalog: the shell remains mounted and only its content/filter changes.
- The branch combines opacity with a subtle 34pt vertical approach and 0.996 -> 1.0 settle scale. It is not an instant scene swap.
- Input does not move into the catalog until the incoming presentation is essentially landed.

### Back transition ownership

Catalog Back no longer launches a second local `withAnimation` around the heavy tab/root state change. It clears detail state and hands the transition to the root-owned UNITY motion. The outgoing catalog remains visible while focus and surface ownership are prepared behind it, then is removed only after the reverse presentation completes.

Top-menu focus and the global ticker remain suppressed for the full outgoing transition rather than waking as soon as `selectedTab` changes.

### Preserve performance without fake donor surfaces

The performance work is retained by freezing *work*, not replacing *views*.

When Live TV is covered by Home/Movies/Shows/Sports:

- provider refresh remains stopped;
- EPG boundary timers remain stopped;
- Live TV speculative artwork prefetch remains stopped;
- Live TV decoder-corridor work remains stopped;
- the persistent virtualized channel corridor compacts to 24 cards after the incoming branch has fully landed.

Before Back reveals Live TV, the same persistent root expands its virtual corridor to the normal 96-card interactive budget with animations disabled, and Live-only network/EPG/prefetch work is delayed until after the catalog reverse transition has completed.

Sports reuses the same persistent root but does not wake the Live TV network pipeline while Sports owns the screen.

### vBRDC092 motion fixes retained

The following remain donor-locked or contract-locked:

- slow focused-card Pulse Glow is opacity-only, never a scale pulse;
- catalog row transitions retain per-preset frame-budget timing and no second arrival bounce;
- Connected Popup 2048 artwork prewarm and same-title image handoff remain;
- Media Information dismissal focus handoff remains;
- Dynamic Wallpaper phase preservation remains;
- Favorites identity isolation remains;
- resume/autoplay and Production metadata corrections remain;
- provider/In-S/FebBox files are unchanged in this UNITY corrective build.

## Hard UNITY invariants added

1. Shared Live/Home/Movies/Shows/Sports presentation has one physical `LiveTVScreen` identity.
2. Catalog themes may change appearance inside the overlay but may not replace the shared root.
3. No synthetic Live TV donor/snapshot may be mounted for catalog transitions.
4. A catalog branch transition has one root-owned geometric transaction.
5. Hidden Live TV performance is achieved by suspending work and bounding virtualization, never by destroying/replacing visual identity.
6. Ambient systems may not wake underneath the final frames of catalog entry/exit.

## Validation

- vBRDC093 architecture/regression contract: **80/80 passed**.
- Swift syntax parse: **64/64 files passed**.
- Backend suite: **36 passed, 2 subtests passed**.
- App Info.plist: valid, 1.0.796 / 796 / vBRDC093.
- Top Shelf Info.plist: valid, 1.0.796 / 796 / vBRDC093.
- project.yml: valid YAML.
- Donor audit: **5 intended product/config files changed, 0 unexpected, 0 missing**.
- Provider/playback/resume/Production/Source Intelligence and vBRDC092 motion-support files outside the intended scope remain donor-hash locked.

## Physical-test targets

1. Live TV -> Home using Artwork 3 Hero, Artwork 4 Hero, Artwork 5 Floating and Pure Black: the catalog should ease in naturally rather than appear instantly.
2. Hold-scroll catalog rows: vBRDC090-vBRDC092 scrolling performance should remain intact.
3. Home/Movies/Shows -> Back repeatedly: the catalog should reverse out over the same persistent Live TV pixels with no one-frame channel-logo/placeholder flash.
4. Catalog -> catalog tabs: shell/theme presentation should remain continuous rather than tearing down/rebuilding the shared root.
5. Repeat Live -> Sports -> Back and Live -> Favorites/Home cycles to verify that inactive work remains bounded and frame feel does not progressively degrade.
