from pathlib import Path
import plistlib, re, unittest
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
BRIDGE=(ROOT/'Sources'/'DebridCredentialBridge.swift').read_text()
MANAGED=(ROOT/'Sources'/'ManagedAddonBridge.swift').read_text()
CATALOG=(ROOT/'Sources'/'CatalogStore.swift').read_text()
SOURCE=(ROOT/'Sources'/'SourceIntelligenceManager.swift').read_text()
SEC=(ROOT/'Sources'/'ReleaseCandidateSecurityManager.swift').read_text()
YML=(ROOT/'project.yml').read_text()

class Contract(unittest.TestCase):
    def test_version(self):
        for p in [ROOT/'Sources'/'Info.plist', ROOT/'TopShelfExtension'/'Info.plist']:
            d=plistlib.loads(p.read_bytes())
            self.assertEqual(d['CFBundleShortVersionString'],'1.0.775')
            self.assertEqual(d['CFBundleVersion'],'775')
            self.assertEqual(d['DebridChannelsReleaseID'],'vBRDC072')
        self.assertEqual(YML.count('MARKETING_VERSION: 1.0.775'),2)
        self.assertEqual(YML.count('CURRENT_PROJECT_VERSION: 775'),2)

    def test_all_eight_torrentio_debrid_services(self):
        for token in ['realDebrid','torBox','premiumize','allDebrid','debridLink','easyDebrid','offcloud','putio']:
            self.assertRegex(BRIDGE, rf'case {token}\b')
        for key in ['realdebrid','torbox','premiumize','alldebrid','debridlink','easydebrid','offcloud','putio']:
            self.assertIn(f'managedTorrentioEnabled.\\(rawValue).v1', BRIDGE)
            self.assertIn(key, BRIDGE.lower())

    def test_torrentio_is_per_account_not_global_gate(self):
        self.assertNotIn('guard defaults.bool(forKey: "managedTorrentioEnabled")', MANAGED)
        self.assertIn('DebridCredentialBridge.torrentioEnabled(for: service', MANAGED)
        self.assertIn('for service in DebridServiceID.allCases', MANAGED)
        self.assertIn('migrateLegacyGlobalTorrentioSwitch', BRIDGE)
        self.assertIn('defaults.removeObject(forKey: "managedTorrentioEnabled")', BRIDGE)

    def test_settings_expose_all_credentials_and_account_toggles(self):
        for key in ['premiumizeApiKey','allDebridApiKey','debridLinkApiKey','easyDebridApiKey','offcloudApiKey','putioClientID','putioToken']:
            self.assertIn(f'@AppStorage("{key}")', APP)
        for service in ['realdebrid','torbox','premiumize','alldebrid','debridlink','easydebrid','offcloud','putio']:
            self.assertIn(f'@AppStorage("managedTorrentioEnabled.{service}.v1")', APP)
        self.assertIn('managedTorrentioAccountToggle(service: .torBox', APP)
        self.assertIn('Native TorBox Usenet remains independent', APP)

    def test_usenet_bypasses_best_ranked_cap(self):
        start=CATALOG.index('func cappedRankedLinks(_ links: [StreamLink])')
        end=CATALOG.index('func publishBatch', start)
        block=CATALOG[start:end]
        self.assertIn('links.filter(\\.isTorBoxUsenetCandidate)', block)
        self.assertIn('return usenetLinks', block)
        self.assertIn('cappedOrdinary + usenetLinks', block)
        self.assertNotIn('Array(usenetLinks.prefix', block)
        ins=CATALOG[CATALOG.index('let durableVisible = self.streamLinks.filter'):CATALOG.index('self.lastStreamMessage =', CATALOG.index('let durableVisible = self.streamLinks.filter'))]
        self.assertIn('merged.filter(\\.isTorBoxUsenetCandidate)', ins)
        self.assertIn('ordinaryCapped + usenetVisible', ins)

    def test_non_rd_hash_never_falls_through_rd_resolver(self):
        start=CATALOG.index('func resolvePlayableURL(for link: StreamLink)')
        end=CATALOG.index('private func resolveRealDebridInfoHash', start)
        block=CATALOG[start:end]
        self.assertIn('if serviceKey != realDebridKey', block)
        self.assertIn('source did not provide a direct playable link', block)
        self.assertIn('resolveRealDebridInfoHash', block)

    def test_provider_detection_covers_new_services(self):
        for marker in ['easydebrid','offcloud','putio']:
            self.assertIn(marker, SOURCE.lower())
        for label in ['EasyDebrid','Offcloud','Put.io']:
            self.assertIn(label, SOURCE)

    def test_backup_and_fresh_install_cover_new_credentials(self):
        for key in ['premiumizeApiKey','allDebridApiKey','debridLinkApiKey','easyDebridApiKey','offcloudApiKey','putioClientID','putioToken']:
            self.assertGreaterEqual(SEC.count(f'"{key}"'), 2)
            self.assertIn(f'"{key}":', APP)
        for service in ['realdebrid','torbox','premiumize','alldebrid','debridlink','easydebrid','offcloud','putio']:
            key=f'managedTorrentioEnabled.{service}.v1'
            self.assertGreaterEqual(SEC.count(f'"{key}"'),2)
            self.assertIn(f'"{key}":',APP)

    def test_torbox_newznab_remains_native_and_independent(self):
        torbox=(ROOT/'Sources'/'TorBoxUsenetClient.swift').read_text()
        self.assertIn('search-api.torbox.app/newznab/api', torbox)
        self.assertIn('DebridChannels-tvOS/vBRDC072 TorBoxNewznab', torbox)
        self.assertIn('torBoxUsenetAllowed = torBoxUsenetKeyAvailable', CATALOG)
        # Do not couple native Usenet permission to any Torrentio toggle.
        usenet=CATALOG[CATALOG.index('let torBoxUsenetAllowed'):CATALOG.index('let torBoxUsenetTask', CATALOG.index('let torBoxUsenetAllowed'))]
        self.assertNotIn('Torrentio', usenet)

if __name__=='__main__': unittest.main(verbosity=2)
