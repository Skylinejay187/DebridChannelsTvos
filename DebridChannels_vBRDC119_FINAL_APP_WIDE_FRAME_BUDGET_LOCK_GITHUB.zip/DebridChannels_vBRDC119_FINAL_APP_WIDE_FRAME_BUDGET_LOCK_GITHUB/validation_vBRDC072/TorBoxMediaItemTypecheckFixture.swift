import Foundation
struct MediaItem {
    var title: String
    var year: String
    var seasonNumber: Int?
    var episodeNumber: Int?
    var imdbId: String?
    var tmdbId: String?
    var tvdbId: String?
}
