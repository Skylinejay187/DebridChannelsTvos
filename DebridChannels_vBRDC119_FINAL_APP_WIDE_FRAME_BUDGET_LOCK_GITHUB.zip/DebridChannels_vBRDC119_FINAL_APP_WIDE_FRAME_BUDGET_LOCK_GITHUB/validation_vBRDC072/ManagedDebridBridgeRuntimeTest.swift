import Foundation

@main
struct ManagedDebridBridgeRuntimeTest {
    static func main() {
        guard let defaults = UserDefaults(suiteName: "vBRDC072.ManagedDebridBridgeRuntimeTest") else { fatalError("suite") }
        defaults.removePersistentDomain(forName: "vBRDC072.ManagedDebridBridgeRuntimeTest")
        defaults.set("rd-test", forKey: DebridServiceID.realDebrid.primaryCredentialKey)
        defaults.set("tb-test", forKey: DebridServiceID.torBox.primaryCredentialKey)
        defaults.set("pm-test", forKey: DebridServiceID.premiumize.primaryCredentialKey)
        defaults.set("ad-test", forKey: DebridServiceID.allDebrid.primaryCredentialKey)
        defaults.set("dl-test", forKey: DebridServiceID.debridLink.primaryCredentialKey)
        defaults.set("ed-test", forKey: DebridServiceID.easyDebrid.primaryCredentialKey)
        defaults.set("oc-test", forKey: DebridServiceID.offcloud.primaryCredentialKey)
        defaults.set("put-client", forKey: DebridServiceID.putio.primaryCredentialKey)
        defaults.set("put-token", forKey: DebridServiceID.putio.secondaryCredentialKey!)
        for service in DebridServiceID.allCases { defaults.set(true, forKey: service.torrentioEnabledKey) }
        let manifests = ManagedAddonBridge.coreDebridStreamManifests(defaults: defaults)
        precondition(manifests.count == 8, "expected eight manifests, got \(manifests.count)")
        for service in DebridServiceID.allCases {
            guard let manifest = manifests.first(where: { $0.bridgedService == service }) else { fatalError("missing \(service.displayName)") }
            precondition(manifest.manifestURL.contains("\(service.torrentioServiceKey)="), "wrong service key")
            if service == .putio { precondition(manifest.manifestURL.contains("put-client@put-token"), "Put.io pair missing") }
        }
        defaults.set(false, forKey: DebridServiceID.torBox.torrentioEnabledKey)
        let withoutTorBox = ManagedAddonBridge.coreDebridStreamManifests(defaults: defaults)
        precondition(withoutTorBox.count == 7)
        precondition(withoutTorBox.allSatisfy { $0.bridgedService != .torBox })
        precondition(DebridCredentialBridge.effectiveTorBoxAPIKey(defaults: defaults) == "tb-test", "TorBox native credential was incorrectly removed with Torrentio")

        guard let legacy = UserDefaults(suiteName: "vBRDC072.LegacyTorrentioRestoreTest") else { fatalError("legacy suite") }
        legacy.removePersistentDomain(forName: "vBRDC072.LegacyTorrentioRestoreTest")
        legacy.set("legacy-rd", forKey: DebridServiceID.realDebrid.primaryCredentialKey)
        legacy.set("legacy-tb", forKey: DebridServiceID.torBox.primaryCredentialKey)
        legacy.set(true, forKey: "migration.vBRDC072.perDebridTorrentioFlags")
        legacy.set(true, forKey: "managedTorrentioEnabled")
        DebridCredentialBridge.migrateLegacyOverridesIfNeeded(defaults: legacy)
        precondition(legacy.bool(forKey: DebridServiceID.realDebrid.torrentioEnabledKey))
        precondition(legacy.bool(forKey: DebridServiceID.torBox.torrentioEnabledKey))
        precondition(legacy.object(forKey: "managedTorrentioEnabled") == nil)
        print("8-provider manifest generation PASS; per-account TorBox removal leaves native TorBox credential intact")
        print("legacy vBRDC071 global Torrentio restore migration PASS")
    }
}
