# Debrid Channels vBRDC063 — Matched Frame A/V Sync

- Release ID: `vBRDC063`
- Marketing version: `1.0.766`
- Apple build: `766`
- Base: packaged `vBRDC062` only
- Backend: `v693` unchanged
- Code Name: `UNITY`

## Physical-device finding

vBRDC062's instant-start/deep-forward-buffer path itself does not retime audio. Physical testing narrowed the new lip-sync symptom to VOD playback with tvOS **Match Frame Rate** enabled, especially after revealing the VOD overlay.

The matched-VOD path deliberately lets the physical output cadence drive KSPNUVIO's `CADisplayLink`. KSPNUVIO's audio clock remains the authoritative A/V clock. Debrid Channels' v1031 VOD cadence policy also deliberately suppressed decoded-video frame drops, even when video was substantially late, to avoid visible single-frame discontinuities.

That combination meant a short main-run-loop presentation delay while SwiftUI composed the VOD overlay could leave video behind audio, and the no-drop policy could preserve that deficit instead of catching back up.

## Correction

1. Keep tvOS Match Frame Rate enabled and keep the existing display-match architecture.
2. Keep vBRDC062 instant VOD startup, 5s/3s preferred reserve, and 300s maximum forward buffer unchanged.
3. Keep the real `playableTime` buffer ghost on the VOD scrubber.
4. Add a **severe A/V-lag-only** recovery path to `DebridFlixorVODOptions.videoClockSync`:
   - normal small/medium lateness still follows the v1031 no-drop policy;
   - if video remains roughly 180ms+ (or 4.5 frames) behind the audio master for multiple decisions, drop one additional decoded video frame per recovery decision until phase catches up;
   - never seek, flush, recreate the player, reset audio, or alter the cache.
5. Treat the buffer ghost as low-priority telemetry:
   - publish at most every 0.5s unless a larger meaningful advance occurs;
   - require ~1.5s buffer movement for an immediate publication;
   - remove the continuous 0.18s implicit animation from the buffered rail/ghost dot.

## Intentionally unchanged

- TorBox / Real-Debrid playback and credentials
- v693 TorBox Usenet relay
- Torrentio independence
- 300-second VOD forward-buffer ceiling
- instant-open (`isSecondOpen = true`)
- Skip Intro / Up Next
- Live TV and trailer buffering
- Unity navigation/theme behavior
- normal seek behavior and player ownership

## Physical test

Test the same VOD with tvOS Match Frame Rate **ON**. Let playback establish, reveal/hide the VOD overlay repeatedly, leave the overlay visible for 30-60 seconds, and confirm dialogue remains locked to mouths while the translucent buffer ghost continues advancing. Repeat with 23.976/24 fps and 25/30 fps material where available.
