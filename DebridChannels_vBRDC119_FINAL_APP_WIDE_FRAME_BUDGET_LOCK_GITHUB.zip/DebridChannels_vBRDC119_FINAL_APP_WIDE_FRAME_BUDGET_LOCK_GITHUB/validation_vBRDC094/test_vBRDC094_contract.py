from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
SYSTEM = (ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id vBRDC094', app.get('DebridChannelsReleaseID')=='vBRDC094' and top.get('DebridChannelsReleaseID')=='vBRDC094')
ck('marketing 1.0.797', app.get('CFBundleShortVersionString')=='1.0.797' and top.get('CFBundleShortVersionString')=='1.0.797')
ck('build 797', app.get('CFBundleVersion')=='797' and top.get('CFBundleVersion')=='797')
ck('project marketing 1.0.797', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.797')
ck('project build 797', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='797')
ck('prewarm guard re-reads current optional selection through self', 'self.selectedItem?.id == expectedItemID' in APP)
ck('invalid shadowed optional chaining removed', '                  selectedItem?.id == expectedItemID else { return }' not in APP)

# Physical-video root cause: no synthetic Live TV donor may replace the UNITY root.
root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
ck('exactly one physical LiveTVScreen mount in app', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)
ck('frozen donor type removed', 'private struct FrozenLiveTVBackdrop' not in APP)
ck('frozen donor invocation removed', 'FrozenLiveTVBackdrop()' not in APP)
ck('root documents persistent physical live root', 'Live TV is once again the one persistent' in root)
ck('persistent live root is under branch overlays', root.find('LiveTVScreen()') < root.find('SportsHubScreen()') and root.find('LiveTVScreen()') < root.find('GridOSCatalogOverlay('))
ck('live root gets stable z zero', '.zIndex(0)' in section(root,'LiveTVScreen()','if store.selectedTab == .sports'))
ck('catalog overlay retains higher branch z', '.zIndex(4200)' in section(root,'if let catalogPresentationTab','\n                }\n\n            }'))
ck('sports shares same persistent root', '.zIndex(4100)' in section(root,'if store.selectedTab == .sports','if let catalogPresentationTab'))
ck('UNITY system forbids snapshots and synthetic donors', all(x in SYSTEM for x in ['exact same LiveTVScreen instance','snapshot','synthetic donor']))
ck('UNITY system still classifies home movies shows as catalog branch', 'case .home, .movies, .shows:' in SYSTEM and 'return .catalogBranch' in SYSTEM)
ck('UNITY system still classifies sports as shared branch', 'case .sports:' in SYSTEM and 'return .sportsBranch' in SYSTEM)

# Root-owned natural branch motion instead of instant hierarchy swap.
ck('root owns catalog presentation state', all(x in APP for x in ['unityPresentedCatalogTab','unityCatalogBranchProgress','unityCatalogTransitionTask']))
presenter=section(APP,'private func synchronizeUnityCatalogBranchPresentation','private func scheduleUnitySurfaceHandoff')
ck('entry motion is deliberate 340ms', 'duration: 0.34' in presenter and 'unityCatalogBranchProgress = 1' in presenter)
ck('exit motion is deliberate 300ms', 'duration: 0.30' in presenter and 'unityCatalogBranchProgress = 0' in presenter)
ck('outgoing catalog retained through reverse motion', 'if unityPresentedCatalogTab == nil { unityPresentedCatalogTab = oldTab }' in presenter)
ck('outgoing catalog unmount waits after motion', '320_000_000' in presenter and '320_000_000)\n            guard !Task.isCancelled, !UnitySurfaceSystem.catalogBranchActive(for: store.selectedTab) else { return }\n            unityPresentedCatalogTab = nil' in presenter)
ck('catalog to catalog stays one shell', 'if oldWasCatalog' in presenter and 'unityCatalogBranchProgress = 1' in presenter)
overlay=section(root,'if let catalogPresentationTab','\n                }\n\n            }')
ck('overlay fades as one branch', '.opacity(progress)' in overlay)
ck('overlay has subtle natural vertical approach', '.offset(y: (1 - progress) * 34)' in overlay)
ck('overlay has subtle natural settle scale', '.scaleEffect(0.996 + (0.004 * progress)' in overlay)
ck('overlay cannot take input before landing', 'progress < 0.985' in overlay and 'progress >= 0.985' in overlay)
ck('top menu stays out of focus graph during reverse transition', '|| unityPresentedCatalogTab != nil' in root)
ck('global ticker ownership spans outgoing catalog transition', 'catalogTransitionOwnsSurface = unityPresentedCatalogTab != nil' in root)

# Back no longer animates selectedTab/heavy hierarchy separately.
catalog=section(APP,'struct GridOSCatalogOverlay: View','struct CatalogHeroMetadataRibbon')
close=section(catalog,'private func closeOverlay()','\n    }\n}\n')
ck('catalog Back has no second withAnimation transaction', 'withAnimation' not in close)
ck('catalog Back delegates state to root motion', 'store.selectedTab = UnitySurfaceSystem.backDestination' in close)
ck('catalog Back clears detail before tab handoff', close.find('store.selectedDetail = nil') < close.find('store.selectedTab ='))

# Handoff/focus timing follows visible branch motion, not the old 60/110/100ms instant swap.
handoff=section(APP,'private func scheduleUnitySurfaceHandoff','private func scheduleCatalogInteractionRecovery')
ck('catalog Back defers live focus checkpoint', '240_000_000' in handoff)
ck('catalog entry binds focus during presentation', '70_000_000' in handoff)
ck('catalog entry leaves ambient systems frozen through landing', '140_000_000' in handoff)
ck('catalog Back leaves ambient systems frozen through reveal', '85_000_000' in handoff)
ck('surface handoff still owns global animation exclusion', 'unityAnimations.setSurfaceHandoffActive(true)' in handoff and 'unityAnimations.setSurfaceHandoffActive(false)' in handoff)

# Preserve v090 performance without breaking physical view identity.
live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
ck('covered live root has 24-card compact corridor', 'coveredRenderedChannelLimit: Int = 24' in live)
ck('interactive live root retains 96-card corridor', 'interactiveRenderedChannelLimit: Int = 96' in live)
ck('covered compaction waits until branch lands', '390_000_000' in live and 'liveTVCoveredCompactionTask' in live)
ck('live corridor expands before reveal', 'renderedChannelLimit = interactiveRenderedChannelLimit' in live)
ck('covered corridor compacts without animation', 'transaction.animation = nil' in section(live,'.onChange(of: store.selectedTab)','onChange(of: store.liveTVFocusRestoreToken)'))
ck('live visibility resume is delayed beyond catalog reverse', 'liveTVVisibilityResumeTask' in live and '390_000_000' in live)
ck('Sports does not wake Live TV network pipeline', 'if tab == .live {' in live and 'if tab == .live || tab == .sports {' not in live)
refresh=section(live,'private func startLiveTVRefreshIfActive','private func acceptSingleDpadStep')
ck('live refresh guard is Live-only', 'store.selectedTab == .live' in refresh and '|| store.selectedTab == .sports' not in refresh)
boundary=section(live,'private func scheduleLiveTVScheduleBoundaryRefresh','private func scheduleLiveTVArtworkPrefetch')
ck('EPG boundary timer is Live-only', 'store.selectedTab == .live' in boundary and '.sports' not in boundary)
prefetch=section(live,'private func scheduleLiveTVArtworkPrefetch','private func prefetchLiveTVArtworkAroundFocusedChannel')
ck('artwork prefetch is Live-only', 'store.selectedTab == .live' in prefetch and '.sports' not in prefetch)
loadids=section(live,'private func liveTVArtworkLoadIDs','private func scheduleGuideHintAutoHide')
ck('hidden persistent root never wakes decoder corridor', 'guard store.selectedTab == .live else { return [] }' in loadids)
ck('obsolete frozen corridor allocator removed', 'cachedRealAmbientChannelCorridor' not in APP)

# Every catalog theme goes through the same outer UNITY branch motion.
ck('Artwork 3 Hero remains recognized', 'private var useArtwork3Hero' in catalog)
ck('Pure Black remains recognized', 'private var usePureBlackCatalogLogo' in catalog)
ck('Artwork 4 Hero remains recognized', 'private var useArtwork4Hero2' in catalog)
ck('Artwork 5 Floating remains recognized', 'private var useArtwork5Floating' in catalog)
ck('theme logic is inside one GridOSCatalogOverlay', root.count('GridOSCatalogOverlay(') == 1)
ck('Artwork Hero 3 explicitly uses real Live TV root', 'Artwork Hero 3 now uses only the real Live TV screen behind the catalog panel' in catalog)

# vBRDC092 motion/artwork work stays locked.
ck('pulse glow remains glow-only', 'Focused Card Pulse Glow Animation' in APP and 'slowGlowBright' in APP)
ck('row preset frame budget remains', 'frameBudgetSettleDuration(for: catalogRowScrollingAnimationPreset)' in APP)
ck('connected popup 2048 prewarm remains', 'maxPixelSize: 2048' in APP and 'scheduleConnectedArtworkPrewarm' in APP)
ck('detail dismissal handoff remains', 'prepareCatalogDetailDismissalFocusHandoff' in APP)
ck('automatic resume assertion remains', 'ksPlayAssertionSerial &+= 1' in APP)
ck('Favorites identity isolation remains', 'quickPanelRestoreSection != "favoritesCatalog"' in APP)
ck('wallpaper phase navigation pause remains', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('coordinator still has post-navigation recovery', 'postNavigationVisualRecoveryActive' in UNITY)

# Do not mix provider/playback/metadata/provider-runtime changes into this UNITY corrective candidate.
DONOR={
'Sources/NuvioPluginClient.swift':'0495f210b9d2ca0b316f0124e1bb4b584147a303c3cb193f48f5cee4fa7259e5',
'Sources/BackupStreamingClient.swift':'032b7ee7663491e93057d7e3702ba7bc55674a8cb10b9336093e7a0399dd4a49',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
'Sources/RemoteImageFit.swift':'093c1c108270e746e463c6ff72b018af4eb62e19afaeaa894947fe38f3518f0f',
'Sources/CatalogStore.swift':'639979f0bd4b8385dd928e30e82db795bc04635fd557b82f73a60cc3e24dd14f',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'BackendBackupStreamingRuntime/backup_streaming_runtime.py':'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py':'340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/SportsScoresScheduleProvider.swift':'db0b16cf928d363275454e74c7db2dcffdc98ff52f7df58188eb22cb435279af',
}
for rel,expected in DONOR.items(): ck('donor lock '+rel, sha(rel)==expected)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source declared in project', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
