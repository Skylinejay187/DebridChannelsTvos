from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
COORD = (ROOT/'Sources'/'UnityAnimationCoordinator.swift').read_text()
PROJECT = (ROOT/'project.yml').read_text()
APP_PLIST = (ROOT/'Sources'/'Info.plist').read_text()
TOP_PLIST = (ROOT/'TopShelfExtension'/'Info.plist').read_text()

checks=[]
def check(name, cond): checks.append((name, bool(cond)))

check('release id', 'vBRDC080' in APP_PLIST and 'vBRDC080' in TOP_PLIST)
check('marketing', '1.0.783' in PROJECT and '1.0.783' in APP_PLIST and '1.0.783' in TOP_PLIST)
check('build', 'CURRENT_PROJECT_VERSION: 783' in PROJECT and '<string>783</string>' in APP_PLIST and '<string>783</string>' in TOP_PLIST)
check('coordinator included', 'Sources/UnityAnimationCoordinator.swift' in PROJECT)
check('UNITY coordinator singleton', 'static let shared = UnityAnimationCoordinator()' in COORD)
check('named features', all(x in COORD for x in ['catalogPulse','catalogPreview','catalogRowMotion','dynamicWallpaper','detailConnector','sourceIntelligenceMotion','playbackChrome']))
check('search/open split', 'sourceSearchActive' in COORD and 'sourceOpeningActive' in COORD and 'func setSourceIntelligence(searching: Bool, opening: Bool)' in COORD)
check('source opening exclusive', 'if sourceOpeningActive {' in COORD and 'return feature == .overlayChrome || feature == .alertMotion' in COORD)
check('full playback exclusive', 'if context.fullScreenPlaybackActive {' in COORD and 'feature == .playbackChrome || feature == .alertMotion' in COORD)
check('trailer exclusive', 'if trailerExclusiveActive {' in COORD)
# Critical behavior: pulse/preview policy must not check sourceSearchActive.
block = COORD[COORD.index('case .catalogPreview, .catalogPulse:'):COORD.index('case .catalogFocusArrival, .catalogRowMotion:')]
check('search does not suppress pulse preview', 'sourceSearchActive' not in block and 'sourceOpeningActive' not in block)
check('catalog preview asks coordinator', 'unityAnimations.allows(.catalogPreview)' in APP)
check('catalog pulse asks coordinator', 'unityAnimations.allows(.catalogPulse)' in APP)
check('rail motion asks coordinator', 'unityAnimations.allows(.catalogRowMotion)' in APP)
check('wallpaper asks coordinator', 'unityAnimations.allows(.dynamicWallpaper)' in APP)
check('ticker asks coordinator', 'unityAnimations.allows(.tickerMotion)' in APP)
check('source panel motion asks coordinator', 'unityAnimations.allows(.sourceIntelligenceMotion)' in APP)
check('connector asks coordinator', 'guard unityAnimations.allows(.detailConnector)' in APP)
check('source activity derived from actual opening', 'let opening = sourceOpeningProvider != nil || (isFindingLinks && !sourcePanelVisible)' in APP)
check('source search derived from visible panel', 'let searching = isFindingLinks && sourcePanelVisible && !opening' in APP)
check('preview permit change only', '.onChange(of: unityFocusedPreviewAllowed)' in APP)
check('pulse permit change only', '.onChange(of: coordinatedPulseEnabled)' in APP)
check('no coordinator revision restart hooks', '.onChange(of: unityAnimations.revision)' not in APP)
check('root synchronizes global ownership', 'synchronizeUnityAnimationContext(reason:' in APP and 'fullScreenPlaybackActive: store.playbackURL != nil || store.vodExclusivePlaybackActive' in APP)
check('trailer notifications feed UNITY', '.debridTrailerExclusivePlaybackDidBegin' in APP and 'setTrailerExclusiveActive(true)' in APP)
check('guide feeds UNITY', 'synchronizeUnityGuideAnimationActivity' in APP and 'setGuideActive(showGuide)' in APP)
check('opening hides connector atomically', 'transaction.disablesAnimations = true' in APP and 'withTransaction(transaction) { connectorLineVisible = false }' in APP)

failed=[n for n,ok in checks if not ok]
for n,ok in checks: print(('PASS' if ok else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: raise SystemExit('Failed: '+', '.join(failed))
