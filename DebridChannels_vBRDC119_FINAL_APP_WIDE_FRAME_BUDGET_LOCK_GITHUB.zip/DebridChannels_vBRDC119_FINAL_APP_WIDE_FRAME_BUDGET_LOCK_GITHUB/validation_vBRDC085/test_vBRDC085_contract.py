from pathlib import Path
import hashlib
import plistlib
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
UNIVERSAL = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()
FOUNDATION = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []


def ck(name, cond):
    checks.append((name, bool(cond)))


def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]


app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC085', app_plist.get('DebridChannelsReleaseID') == 'vBRDC085' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC085')
ck('marketing version 1.0.788', app_plist.get('CFBundleShortVersionString') == '1.0.788' and top_plist.get('CFBundleShortVersionString') == '1.0.788')
ck('build version 788', app_plist.get('CFBundleVersion') == '788' and top_plist.get('CFBundleVersion') == '788')
ck('project marketing 1.0.788', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.788')
ck('project build 788', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '788')

# Find Links -> selected source automatic resume must produce an explicit KS engine Play pulse.
ck('VOD owns explicit KS play assertion serial', '@State private var ksPlayAssertionSerial = 0' in APP)
ck('automatic resume confirmation window exists', '@State private var automaticResumeConfirmedAt: Date? = nil' in APP)
confirm = section(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
ck('automatic resume confirms requested play state', 'isPlaying = true' in confirm)
ck('automatic resume timestamps confirmation', 'automaticResumeConfirmedAt = Date()' in confirm)
ck('KS automatic resume emits explicit play assertion', 'if forceKSPlayerSurface' in confirm and 'ksPlayAssertionSerial &+= 1' in confirm)
ck('AV automatic resume still directly plays AVPlayer', 'player?.play()' in confirm)
force_resume = section(APP, 'private func forceResumeFromSavedPosition', 'private func saveResumePositionIfNeeded')
ck('manual resume backup emits KS play assertion', 'if forceKSPlayerSurface { ksPlayAssertionSerial &+= 1 }' in force_resume)

# The command must survive every bridge and reach the persistent KS surface without recreation.
ck('UniversalVideoSurface declares KS play assertion', 'var ksPlayAssertionSerial: Int = 0' in UNIVERSAL)
ck('UniversalVideoSurface forwards KS play assertion', 'playAssertionSerial: ksPlayAssertionSerial' in UNIVERSAL)
ck('PlaybackKit host declares play assertion', 'var playAssertionSerial: Int = 0' in FOUNDATION)
ck('PlaybackKit host forwards play assertion', 'playAssertionSerial: playAssertionSerial' in FOUNDATION)
ck('KS surface declares play assertion', 'var playAssertionSerial: Int = 0' in KS)
ck('KS update snapshot tracks play assertion', 'let playAssertionSerial: Int' in KS and 'playAssertionSerial: playAssertionSerial' in KS)
ck('KS coordinator remembers last assertion', 'var lastPlayAssertionSerial: Int = 0' in KS)
play_assert = section(KS, 'if coordinator.lastPlayAssertionSerial != playAssertionSerial', '// v408: KSPlayer can crash')
ck('new KS assertion directly calls layer.play', 'layer.play()' in play_assert)
ck('new KS assertion arms bounded liveness recovery', 'schedulePostSeekAutoplayRecovery(' in play_assert and 'postSeekAutoplayGeneration &+= 1' in play_assert)
ck('KS assertion does not recreate surface', 'resetRenderHostForURLChange' not in play_assert and 'KSPlayerLayer(' not in play_assert)

# Existing user-pause authority and bounded v084 recovery must remain intact.
ck('KS post-seek recovery remains bounded', 'let delays: [TimeInterval] = [0.32, 0.52, 0.82, 1.18]' in KS)
ck('KS recovery exits on advancing decoder clock', 'currentClock >= previousClock + 0.16' in KS)
play_state = section(KS, 'if coordinator.currentShouldPlay != shouldPlay', '// v1056:')
ck('real user Pause invalidates autoplay recovery', 'coordinator.postSeekAutoplayGeneration &+= 1' in play_state and 'layer.pause()' in play_state)
ck('surface teardown invalidates autoplay recovery', 'func playbackKitStopAndReleaseSurface()' in KS and 'postSeekAutoplayGeneration &+= 1' in KS)
ck('automatic resume remains in-place absolute seek', 'ksSeekIsAbsolute = true' in APP and 'ksSeekSerial &+= 1' in APP and 'layer.seek(time: target, autoPlay: resumePlayback)' in KS)

# A transient KSPNUVIO finish(nil) during resume decoder flush must not flip UI state to paused.
ended = section(APP, 'onKSPlaybackEnded:', 'onKSChaptersDiscovered:')
ck('resume flush finish guard requires requested play state', 'if isPlaying,' in ended)
ck('resume flush finish guard is time-bounded', 'Date().timeIntervalSince(confirmedAt) < 8.0' in ended)
ck('resume flush guard distinguishes natural EOF', 'nearNaturalEnd' in ended and 'if !nearNaturalEnd' in ended)
ck('resume flush guard reasserts KS Play', 'ksPlayAssertionSerial &+= 1' in ended)
ck('true completion still sets paused state', 'isPlaying = false' in ended)
ck('true movie completion still clears resume checkpoint', 'PlaybackResumeCacheManager.shared.clear(for: item)' in ended)

# Production information must load independently of Play/Pause, while heavy review/runtime work stays pause-only.
production_loader = section(APP, 'private func loadVODProductionMetadata(', 'private func showVODCastExplorerOnboardingIfNeeded')
ck('Production loader requires first frame but not pause', 'isFirstFrameReady' in production_loader and '!isPlaying' not in production_loader)
ck('Production loader no longer requires controls visible', 'controlsVisible' not in production_loader)
ck('Production loader no longer requires active panel nil', 'activePanel' not in production_loader)
ck('Production loader uses background priority', 'Task(priority: .background)' in production_loader)
first_frame = section(APP, '.onChange(of: isFirstFrameReady)', '.onChange(of: hasStableFirstFramePlayback)')
ck('first frame automatically schedules Production while playing', 'loadVODProductionMetadata(for: overlayItem, delayNanoseconds: 900_000_000)' in first_frame)
ck('first frame heavy hydration remains pause-only', 'if !isPlaying {' in first_frame and 'startPlaybackMetadataHydration()' in first_frame and 'startRuntimeMetadataLookupIfNeeded' in first_frame)
playing_change = section(APP, '.onChange(of: isPlaying)', '.onChange(of: activePanel)')
ck('active playback still cancels review work', 'vodReviewTask?.cancel()' in playing_change)
ck('active playback still cancels runtime work', 'runtimeLookupTask?.cancel()' in playing_change)
ck('active playback does not cancel Production', 'vodProductionMetadataTask?.cancel()' not in playing_change)
controls_change = section(APP, '.onChange(of: controlsVisible)', '.onChange(of: isPlaying)')
ck('visible controls can request Production regardless of pause', 'loadVODProductionMetadata(for: overlayItem, delayNanoseconds: 120_000_000)' in controls_change)
ck('hidden controls do not cancel Production', 'vodProductionMetadataTask?.cancel()' not in controls_change)
active_panel = section(APP, '.onChange(of: activePanel)', '.onChange(of: isLoading)')
ck('opening side panel does not cancel Production', 'vodProductionMetadataTask?.cancel()' not in active_panel)

# Sensitive unrelated systems remain exact packaged-v084 donor bytes.
BASE_HASHES = {
    'Sources/CatalogStore.swift': '10329bae4d44d46357ede17f9b108d2f7db7c16db9dec0e0af7cfba0ca259a8e',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/UnityAnimationCoordinator.swift': '15320d4424cf64faba13e3a94ff099e939cc561254d05ce267b8300ceed9e305',
    'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
}
for rel, expected in BASE_HASHES.items():
    ck('donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
