# Debrid Channels vBRDC081 — UNITY Surface Lifecycle

**Marketing version:** 1.0.784  
**Apple build:** 784  
**Release ID:** vBRDC081  
**Code Name:** UNITY  
**Donor:** packaged vBRDC080 only

## Purpose

vBRDC081 extends UNITY from process-wide animation arbitration into process-wide top-level surface lifecycle arbitration. Physical testing of vBRDC080 reported sluggish interaction after leaving Sports or Favorites. The audit found two concrete resource-handoff violations:

1. Sports created a second `LiveTVSourceModel` and started its own full Live TV/IPTV/XMLTV refresh even though the real Live TV root remained mounted underneath Sports. Late async work could unwind/publish while the returning grid was reclaiming MainActor/focus ownership.
2. Favorites synchronously rebuilt its complete favorite snapshot every time `CatalogStore.rows` changed. Provider row batches could therefore rescan the catalog while Favorites was disappearing and Home was mounting.

Sports exit also performed many redundant `@Published` assignments and multiple immediate focus-token revisions, while top-menu navigation wrapped whole heavy surface swaps in one broad SwiftUI animation transaction.

## vBRDC081 changes

- Adds `UnitySurfaceLifecycleCoordinator.swift` with one generation-based handoff contract for every top-level app tab/surface.
- Root owns the cross-surface transition window. Outgoing work releases first, incoming focus receives a bounded checkpoint, and nonessential catalog/watchdog work resumes after the handoff settles.
- `UnityAnimationCoordinator` now has a short `surfaceHandoffActive` ownership state so outgoing and incoming perpetual animations never composite simultaneously during a surface swap.
- Removed the broad `withAnimation(.easeInOut(duration: 0.26))` transaction around top-menu surface replacement. Local focus visuals remain independently animated.
- Sports now consumes the retained Live TV session and no longer calls a second `liveModel.refreshIfNeeded()` from the Sports surface.
- Sports owns one explicit cancellable surface task and invalidates its Sports/auxiliary-Live-TV generations before exit.
- Sports custom M3U parsing checks cancellation before/after network fetches and periodically during large synchronous parsing.
- `CatalogStore.clearSportsPresentationStateForNavigation` no longer writes every `@Published` property back to its existing default value. It changes only state that is actually active and leaves destination focus revisions to Root's lifecycle coordinator.
- Favorites now coalesces row-driven snapshot rebuilds (120 ms debounce), cancels rebuild work on exit, and gates rebuild publication to an active Favorites surface.
- Favorites releases local focus ownership before switching to Home.
- Settings-return MediaFlow refresh is deferred until the destination focus tree settles.
- Catalog completeness recovery is suppressed during a UNITY surface handoff and rearmed afterward.

## Preserved behavior

The following donor systems are intentionally unchanged:

- KSPlayer / `PlaybackKitKSPlayerSurface.swift`
- `PlaybackResumeCache.swift`
- v077 automatic resume + automatic play behavior
- v076 playback-priority protections
- v078 VOD exit interactivity recovery
- v079 Dynamic Wallpaper Evolution
- v080 Source Intelligence / Pulse / Preview animation compatibility
- `TorBoxUsenetClient.swift` and TorBox Search behavior (still awaiting TorBox backend-IP approval)
- `SourceIntelligenceManager.swift`
- `UnityCatalogVisualSystem.swift`
- all four packaged backend runtime trees

## Expected physical behavior

- Sports → Live TV must return immediately responsive; no delayed second Live TV refresh may continue from Sports.
- Sports → another top-menu destination must not hitch from redundant CatalogStore publication or focus-token churn.
- Favorites → Home must restore responsive focus without catalog rescans competing during the transition.
- Settings → grid and other top-level tab changes use the same bounded UNITY handoff policy.
- Existing Pulse/Preview behavior during Source Intelligence search remains unchanged from vBRDC080.
- Full-screen playback continues to use the stronger playback-specific ownership and recovery paths from vBRDC076-vBRDC078.

## Validation

- vBRDC081 lifecycle contracts: 39/39
- inherited backend runtime tests: 35/35
- Swift syntax parse: 64/64
- app + TopShelf plists: valid
- project.yml: valid YAML
- donor-locked playback/resume/TorBox/Source Intelligence/UNITY visual/backend files: byte-identical
