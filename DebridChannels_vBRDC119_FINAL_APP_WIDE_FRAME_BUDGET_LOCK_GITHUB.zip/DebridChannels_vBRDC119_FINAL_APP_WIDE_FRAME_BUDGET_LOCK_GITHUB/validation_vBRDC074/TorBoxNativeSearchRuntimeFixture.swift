import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct MediaItem {
    var title: String
    var year: String
    var seasonNumber: Int?
    var episodeNumber: Int?
    var imdbId: String?
    var tmdbId: String?
    var tvdbId: String?
}

final class MockURLProtocol: URLProtocol {
    static let lock = NSLock()
    nonisolated(unsafe) static var requests: [URLRequest] = []
    nonisolated(unsafe) static var mode = 1

    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }

    override func startLoading() {
        Self.lock.lock()
        Self.requests.append(request)
        let mode = Self.mode
        Self.lock.unlock()

        guard let url = request.url else { fatalError("missing URL") }
        let path = url.path
        let success: Bool
        if mode == 1 {
            success = path.contains("/usenet/imdb_id:tt0137523")
        } else if mode == 2 {
            success = path.contains("/usenet/themoviedb_id:550")
        } else {
            success = false
        }

        let statusCode: Int
        let body: String
        if mode == 3, path.contains("/v1/api/usenet/mylist") {
            // Main API/library is healthy and empty while release discovery is denied.
            // vBRDC073 incorrectly counted this as discovery success and returned [].
            statusCode = 200
            body = #"{"success":true,"data":[]}"#
        } else if mode == 3 {
            statusCode = 403
            body = #"{"success":false,"error":"BAD_TOKEN","detail":"fixture search denied","data":null}"#
        } else if success {
            statusCode = 200
            body = #"{"success":true,"data":{"nzbs":[{"hash":"abc123","raw_title":"Fight.Club.1999.1080p.BluRay","title":"Fight Club 1999 1080p BluRay","size":1234567890,"tracker":"fixture-indexer","nzb":"https://search-api.torbox.app/newznab/api?t=get&id=fixture","age":"1d","cached":true,"owned":false}]}}"#
        } else {
            statusCode = 200
            body = #"{"success":true,"data":{"nzbs":[]}}"#
        }
        let data = Data(body.utf8)
        let response = HTTPURLResponse(
            url: url,
            statusCode: statusCode,
            httpVersion: "HTTP/1.1",
            headerFields: ["Content-Type": mode == 3 && path.contains("/newznab/") ? "application/xml" : "application/json"]
        )!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }

    override func stopLoading() {}
}

@main
struct RuntimeValidation {
    static func makeSession() -> URLSession {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        return URLSession(configuration: config)
    }

    static func reset(mode: Int) {
        MockURLProtocol.lock.lock()
        MockURLProtocol.requests = []
        MockURLProtocol.mode = mode
        MockURLProtocol.lock.unlock()
    }

    static func snapshot() -> [URLRequest] {
        MockURLProtocol.lock.lock()
        defer { MockURLProtocol.lock.unlock() }
        return MockURLProtocol.requests
    }

    static func main() async throws {
        reset(mode: 1)
        let item1 = MediaItem(
            title: "Fight Club", year: "1999", seasonNumber: nil, episodeNumber: nil,
            imdbId: "tt0137523", tmdbId: "550", tvdbId: nil
        )
        let result1 = try await TorBoxUsenetClient.search(item: item1, apiKey: "fixture-token", session: makeSession())
        guard result1.count == 1, result1[0].hash == "abc123", result1[0].cached else {
            fatalError("current native response was not parsed")
        }
        let req1 = snapshot().first!
        guard req1.url?.path.contains("/usenet/imdb_id:tt0137523") == true else {
            fatalError("current IMDb identity was not primary: \(req1.url?.absoluteString ?? "nil")")
        }
        guard req1.value(forHTTPHeaderField: "Authorization") == "Bearer fixture-token" else {
            fatalError("Bearer auth missing")
        }
        guard req1.value(forHTTPHeaderField: "Content-Type") == "application/json" else {
            fatalError("JSON content type missing")
        }
        let query1 = URLComponents(url: req1.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
        let q1 = Dictionary(uniqueKeysWithValues: query1.map { ($0.name, $0.value ?? "") })
        guard q1["check_cache"] == "true", q1["check_owned"] == "true", q1["metadata"] == "false", q1["cached_only"] == nil else {
            fatalError("native query parameters differ from current TorBox request shape")
        }

        reset(mode: 2)
        let item2 = MediaItem(
            title: "Fight Club", year: "1999", seasonNumber: nil, episodeNumber: nil,
            imdbId: "tt0137523", tmdbId: "550", tvdbId: "81189"
        )
        let result2 = try await TorBoxUsenetClient.search(item: item2, apiKey: "fixture-token", session: makeSession())
        guard result2.count == 1 else { fatalError("multi-identity fallback failed") }
        let paths = snapshot().compactMap { $0.url?.path }
        guard paths.contains(where: { $0.contains("/usenet/imdb_id:tt0137523") }),
              paths.contains(where: { $0.contains("/usenet/imdb:tt0137523") }),
              paths.contains(where: { $0.contains("/usenet/themoviedb_id:550") }) else {
            fatalError("did not retry across current + compatibility identities: \(paths)")
        }

        reset(mode: 3)
        do {
            _ = try await TorBoxUsenetClient.search(item: item1, apiKey: "fixture-token", session: makeSession())
            fatalError("healthy empty library incorrectly masked Search API denial as zero")
        } catch {
            let message = error.localizedDescription.lowercased()
            guard message.contains("fixture search denied") || message.contains("403") else {
                fatalError("discovery failure was not preserved: \(error.localizedDescription)")
            }
        }
        print("TorBox native Search API runtime fixture PASS (current IDs + auth + schema + multi-ID fallback + failure visibility)")
    }
}
