from pathlib import Path
import plistlib, unittest

ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
BRIDGE=(ROOT/'Sources'/'DebridCredentialBridge.swift').read_text()
MANAGED=(ROOT/'Sources'/'ManagedAddonBridge.swift').read_text()
CATALOG=(ROOT/'Sources'/'CatalogStore.swift').read_text()
SOURCE=(ROOT/'Sources'/'SourceIntelligenceManager.swift').read_text()
TORBOX=(ROOT/'Sources'/'TorBoxUsenetClient.swift').read_text()
SEC=(ROOT/'Sources'/'ReleaseCandidateSecurityManager.swift').read_text()
YML=(ROOT/'project.yml').read_text()

class Contract(unittest.TestCase):
    def test_version(self):
        for p in [ROOT/'Sources'/'Info.plist', ROOT/'TopShelfExtension'/'Info.plist']:
            d=plistlib.loads(p.read_bytes())
            self.assertEqual(d['CFBundleShortVersionString'],'1.0.777')
            self.assertEqual(d['CFBundleVersion'],'777')
            self.assertEqual(d['DebridChannelsReleaseID'],'vBRDC074')
        self.assertEqual(YML.count('MARKETING_VERSION: 1.0.777'),2)
        self.assertEqual(YML.count('CURRENT_PROJECT_VERSION: 777'),2)

    def test_shared_source_session_is_never_invalidated(self):
        self.assertNotIn('sourceIntelligenceURLSession.invalidateAndCancel()', CATALOG)
        self.assertIn('private func rotateSourceIntelligenceURLSession()', CATALOG)
        rotate=CATALOG[CATALOG.index('private func rotateSourceIntelligenceURLSession()'):CATALOG.index('private func cancelActiveSourceProviderTasks()')]
        self.assertIn('retiringSession.getAllTasks', rotate)
        self.assertIn('task.cancel()', rotate)
        self.assertNotIn('invalidateAndCancel', rotate)

    def test_torbox_search_task_is_explicitly_owned_and_cancelled(self):
        self.assertIn('activeTorBoxUsenetTask', CATALOG)
        cancel=CATALOG[CATALOG.index('private func cancelActiveSourceProviderTasks()'):CATALOG.index('private func isOnDemandPlaybackItem')]
        self.assertIn('activeTorBoxUsenetTask?.cancel()', cancel)
        self.assertIn('activeTorBoxUsenetTask = nil', cancel)
        creation=CATALOG[CATALOG.index('let torBoxUsenetTask:'):CATALOG.index('// v310: Xtream Codes', CATALOG.index('let torBoxUsenetTask:'))]
        self.assertIn('activeTorBoxUsenetTask = task', creation)

    def test_torbox_cancellation_does_not_fall_through_routes(self):
        self.assertIn('private static func throwIfCancelled', TORBOX)
        self.assertIn('if Task.isCancelled { throw CancellationError() }', TORBOX)
        self.assertGreaterEqual(TORBOX.count('try Task.checkCancellation()'), 6)
        retry=TORBOX[TORBOX.index('private static func searchDataWithTransientRetry'):TORBOX.index('private static func isDNSResolutionError')]
        self.assertIn('try throwIfCancelled(error)', retry)
        self.assertIn('try await Task.sleep', retry)
        self.assertNotIn('try? await Task.sleep', retry)


    def test_current_torbox_native_search_is_primary(self):
        block=TORBOX[TORBOX.index('static func search('):TORBOX.index('private static func searchNewznabDirect')]
        self.assertLess(block.index('searchNativeVoyagerDirect'), block.index('searchViaBackendRelay'))
        self.assertLess(block.index('searchViaBackendRelay'), block.index('searchNewznabDirect'))

    def test_current_torbox_external_ids_and_all_identity_fallbacks(self):
        identities=TORBOX[TORBOX.index('private static func searchIdentities'):TORBOX.index('private static func dataWithTransientRetry')]
        for token in ['imdb_id', 'themoviedb_id', 'thetvdb_id']:
            self.assertIn(token, identities)
        for token in ['("imdb", imdb)', '("tmdb", tmdb)', '("tvdb", tvdb)']:
            self.assertIn(token, identities)
        self.assertIn('var identities:', identities)
        self.assertNotIn('return [("imdb_id"', identities)
        self.assertIn('private static func legacySearchIdentity', identities)

    def test_native_request_matches_current_json_search_shape(self):
        common=TORBOX[TORBOX.index('private static func commonSearchQueryItems'):TORBOX.index('private static func performSearch')]
        for key in ['metadata', 'check_cache', 'check_owned', 'search_user_engines']:
            self.assertIn(f'URLQueryItem(name: "{key}"', common)
        self.assertNotIn('cached_only', common)
        request=TORBOX[TORBOX.index('private static func performSearch'):TORBOX.index('private static func searchDataWithTransientRetry')]
        self.assertIn(r'Bearer \(apiKey)', request)
        self.assertIn('"application/json", forHTTPHeaderField: "Accept"', request)
        self.assertIn('"application/json", forHTTPHeaderField: "Content-Type"', request)
        parser=TORBOX[TORBOX.index('private static func parseSearchResponse'):TORBOX.index('private static func deduplicated')]
        self.assertIn('dictionary["nzbs"]', parser)

    def test_backend_relay_keeps_v694_legacy_identity_contract(self):
        relay=TORBOX[TORBOX.index('private static func searchViaBackendRelay'):TORBOX.index('private static func searchOwnedLibrary')]
        self.assertIn('legacySearchIdentity(for: item)', relay)
        self.assertIn('payload["identityType"]', relay)

    def test_owned_library_cannot_mask_search_api_failure(self):
        block=TORBOX[TORBOX.index('static func search('):TORBOX.index('private static func searchNewznabDirect')]
        owned=block[block.index('let owned = try await searchOwnedLibrary'):block.index('if completedDiscoveryRoute')]
        self.assertNotIn('completedDiscoveryRoute = true', owned)
        self.assertIn('if completedDiscoveryRoute { return [] }', block)

    def test_torbox_failure_message_survives_final_empty_state(self):
        anchor=CATALOG.index('publishBatch(visibleSorted')
        start=CATALOG.index('if visibleSorted.isEmpty {', anchor)
        end=CATALOG.index('return visibleSorted', start)
        block=CATALOG[start:end]
        self.assertIn('sourceProviderStatus(for: "TorBox Usenet")', block)
        self.assertIn('torBoxStatus.state == .failed', block)
        self.assertIn('lastStreamMessage = torBoxStatus.message', block)

    def test_newznab_error_xml_is_not_false_zero(self):
        collector=TORBOX[TORBOX.index('private final class NewznabXMLCollector'):TORBOX.index('private static func parseNewznabResponse')]
        self.assertIn('serviceErrorCode', collector)
        self.assertIn('serviceErrorDescription', collector)
        parser=TORBOX[TORBOX.index('private static func parseNewznabResponse'):TORBOX.index('private static func normalizedNewznabResultURL')]
        self.assertIn('if !collector.serviceErrorCode.isEmpty || !collector.serviceErrorDescription.isEmpty', parser)
        self.assertIn('TorBox Newznab rejected the search', parser)

    def test_newznab_searches_media_and_query_modes_and_merges(self):
        block=TORBOX[TORBOX.index('private static func searchNewznabDirect'):TORBOX.index('private static func newznabSearchURL')]
        self.assertIn('var collected: [TorBoxUsenetSearchResult] = []', block)
        self.assertIn('collected.append(contentsOf: results)', block)
        self.assertIn('return deduplicated(collected)', block)
        self.assertNotIn('if !results.isEmpty { return deduplicated(results) }', block)

    def test_relative_newznab_grab_links_are_normalized(self):
        self.assertIn('normalizedNewznabResultURL(rawNZBURL)', TORBOX)
        normalizer=TORBOX[TORBOX.index('private static func normalizedNewznabResultURL'):TORBOX.index('private static func boolString')]
        self.assertIn('relativeTo: base', normalizer)
        self.assertIn('absoluteURL', normalizer)

    def test_usenet_still_bypasses_best_ranked_cap(self):
        start=CATALOG.index('func cappedRankedLinks(_ links: [StreamLink])')
        end=CATALOG.index('func publishBatch', start)
        block=CATALOG[start:end]
        self.assertIn('links.filter(\\.isTorBoxUsenetCandidate)', block)
        self.assertIn('return usenetLinks', block)
        self.assertIn('cappedOrdinary + usenetLinks', block)
        self.assertNotIn('Array(usenetLinks.prefix', block)

    def test_automatic_resume_is_clock_confirmed(self):
        scheduler=APP[APP.index('private func scheduleAutomaticResumeAfterSurfaceStart'):APP.index('private func forceResumeFromSavedPosition')]
        self.assertIn('reconcileAutomaticResumePlaybackClock', scheduler)
        self.assertIn('confirmAutomaticResume', scheduler)
        self.assertIn('pendingAutomaticResumeSeconds == target', scheduler)
        # The scheduler may request a seek, but it must not declare success itself.
        schedule_only=scheduler[:scheduler.index('private func requestAutomaticResumeSeek')]
        self.assertNotIn('didApplyAutomaticResumeSeek = true', schedule_only)
        self.assertNotIn('pendingAutomaticResumeSeconds = nil', schedule_only)
        callback=APP[APP.index('onPlaybackTimeUpdate: { current, total in'):APP.index('onKSBufferUpdate:', APP.index('onPlaybackTimeUpdate: { current, total in'))]
        self.assertIn('reconcileAutomaticResumePlaybackClock(current: current)', callback)

    def test_automatic_resume_does_not_recreate_ksplayer(self):
        seek=APP[APP.index('private func seekAbsolute('):APP.index('private func startTimelineMetadataRecoveryMonitor', APP.index('private func seekAbsolute('))]
        ks=seek[seek.index('if forceKSPlayerSurface'):seek.index('if forceVLCSurface')]
        self.assertIn('ksSeekIsAbsolute = true', ks)
        self.assertIn('ksSeekSerial &+= 1', ks)
        self.assertNotIn('ksSurfaceToken &+= 1', ks)
        self.assertNotIn('ksStartTimeSeconds = target', ks)

    def test_resume_cache_format_is_preserved(self):
        cache=(ROOT/'Sources'/'PlaybackResumeCache.swift').read_text()
        self.assertIn('playback-resume-v1119.json', cache)
        self.assertIn('minimumResumeSeconds', cache)
        # The VOD view identity remains source/presentation scoped for Find Links/source changes.
        self.assertIn('.id("\\(store.playbackPresentationID.uuidString)::\\(url.absoluteString)")', APP)

    def test_all_eight_torrentio_debrid_services_remain(self):
        for token in ['realDebrid','torBox','premiumize','allDebrid','debridLink','easyDebrid','offcloud','putio']:
            self.assertRegex(BRIDGE, rf'case {token}\b')
        self.assertNotIn('guard defaults.bool(forKey: "managedTorrentioEnabled")', MANAGED)
        self.assertIn('DebridCredentialBridge.torrentioEnabled(for: service', MANAGED)

    def test_non_rd_hash_never_falls_through_rd_resolver(self):
        start=CATALOG.index('func resolvePlayableURL(for link: StreamLink)')
        end=CATALOG.index('private func resolveRealDebridInfoHash', start)
        block=CATALOG[start:end]
        self.assertIn('if serviceKey != realDebridKey', block)
        self.assertIn('source did not provide a direct playable link', block)

    def test_existing_credentials_and_security_boundary_remain(self):
        for key in ['premiumizeApiKey','allDebridApiKey','debridLinkApiKey','easyDebridApiKey','offcloudApiKey','putioClientID','putioToken']:
            self.assertGreaterEqual(SEC.count(f'"{key}"'), 2)
            self.assertIn(f'@AppStorage("{key}")', APP)
        for marker in ['easydebrid','offcloud','putio']:
            self.assertIn(marker, SOURCE.lower())

if __name__=='__main__': unittest.main(verbosity=2)
