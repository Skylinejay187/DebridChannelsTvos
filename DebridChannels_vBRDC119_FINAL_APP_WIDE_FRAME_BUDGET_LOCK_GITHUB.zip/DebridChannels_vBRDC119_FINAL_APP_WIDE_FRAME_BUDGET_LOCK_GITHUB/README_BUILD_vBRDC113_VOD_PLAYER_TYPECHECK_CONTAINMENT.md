# Debrid Channels vBRDC113 — VOD Player Type-Check Containment

Marketing version **1.0.816** / Apple build **816**.

## GitHub Actions failure diagnosed from vBRDC112

The first real Xcode compiler failure in `logs_90075455011.zip` is:

- `Sources/DebridChannelsTVOSApp.swift:21128:25`
- `error: the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

No Bluetooth `MediaPlayer` API error appears before this failure. The vBRDC112 visual-tree extraction reduced the original expression, but the remaining VOD lifecycle/state/input modifier chain was still being inferred as one very large SwiftUI generic type.

## Corrective structure

vBRDC113 keeps runtime behavior and modifier order intact but inserts opaque Swift compile boundaries:

1. `playerVisualTree`
2. `playerLifecycleTree`
3. `playerInputTree`
4. `playerOverlayStateTree`
5. `playerPlaybackStateTree`
6. `playerTimelineStateTree`
7. `playerCommandTree`
8. `body` now delegates only to `playerCommandTree`

This is a compiler-containment change. It does not redesign playback UI or alter the Bluetooth Play/Pause behavior added in vBRDC111.

## Scope

Compared with packaged vBRDC112, only these existing donor files change:

- `Sources/DebridChannelsTVOSApp.swift`
- `Sources/Info.plist`
- `TopShelfExtension/Info.plist`
- `project.yml`

All other donor files remain unchanged; vBRDC113 validation/docs are additive.

## Validation

- vBRDC113 targeted contract: 23/23 PASS
- `Sources` Swift syntax parse: 64/64 PASS
- all package Swift syntax parse: 74/74 PASS
- source diff confirms the VOD modifier order is preserved and only opaque compile boundaries were inserted
- app + Top Shelf version metadata: 1.0.816 / 816 / vBRDC113

The authoritative full tvOS type-check/compile remains GitHub Actions/Xcode.
