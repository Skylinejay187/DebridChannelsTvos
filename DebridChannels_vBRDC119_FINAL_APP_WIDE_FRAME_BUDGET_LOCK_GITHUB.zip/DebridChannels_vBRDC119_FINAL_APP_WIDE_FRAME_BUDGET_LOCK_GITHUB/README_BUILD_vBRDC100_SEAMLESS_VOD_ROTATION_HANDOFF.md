# Debrid Channels vBRDC100 — Seamless VOD Rotation Handoff

Release: **vBRDC100**  
Marketing version: **1.0.803**  
Apple build: **803**  
Donor: packaged **vBRDC099** only.

## Physical failure addressed

Featured Cast and Production & Ratings were using animation durations, but the visible image owner was still being replaced before the next bitmap had finished loading/decoding. On physical Apple TV this could expose the black/transparent backing canvas between rotations, making the transition look like a blank flash rather than a continuous handoff.

## Root causes

1. **Featured Cast changed the image URL immediately without retaining the prior decoded frame.** Both Full Poster and Compact Overlay could therefore show an empty `RemoteImageFit` while the next actor portrait was pending.
2. **Production & Ratings explicitly keyed the artwork view by the rotating URL.** The `.id("v1112-production-artwork-<url>")` modifier destroyed the current `@StateObject` image loader at every 7-second rotation, guaranteeing there was no previous decoded bitmap available to bridge the load.
3. The existing `RemoteImageFit.preservePreviousOnURLChange` path already implements the correct no-blank ownership rule, but these VOD rotation surfaces were not using it.

## vBRDC100 correction

### Featured Cast

- Full Poster cast portraits now opt into `preservePreviousOnURLChange`.
- Compact Overlay cast portraits use the same retained-frame handoff.
- The image loader identity is stable for all cast-member rotations within one media title and resets only when `item.id` changes.
- The approved 7-second rotation cadence, 0.55-second state animation, poster geometry, cast labels, gradients, focus routing, Cast Explorer behavior, and initial poster hold are unchanged.

### Production & Ratings

- Removed the per-artwork-URL `.id(...)` that recreated the image loader on every rotation.
- Rotating artwork now uses `preservePreviousOnURLChange`, so the current decoded banner remains visible until the replacement bitmap is ready.
- The entire Production artwork header is keyed only by `item.id`, preventing stale artwork from bleeding across different media titles while preserving continuity inside the same title.
- The approved 7-second timer, 0.80-second rotation animation, aspect-fit presentation, title logo, company logo/name, facts grid, and panel geometry are unchanged.

## Scope lock

No changes were made to:

- playback/resume/auto-start or KSPlayer;
- source resolution, In-S, FebBox, TorBox/Usenet, MediaFlow, Alternate Audio, or Source Intelligence;
- catalog scrolling/focus/UNITY animation coordination;
- Dynamic Wallpaper, Pulse, Connected Popup artwork, Sports, Favorites, or Live TV;
- `RemoteImageFit.swift` itself — vBRDC100 reuses the existing proven retained-frame API.

## Intended existing-file scope

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/Info.plist`
3. `TopShelfExtension/Info.plist`
4. `project.yml`

All other existing donor files remain byte-for-byte vBRDC099 unless they are new vBRDC100 validation/package documentation.

## Validation

GitHub Actions/Xcode remains the authoritative Apple SDK compile. Physical Apple TV remains authoritative for the perceived transition quality. The local package validation checks Swift syntax parsing, plist/project alignment, exact retained-frame contracts, donor scope, backend regression tests, and package hashes.
