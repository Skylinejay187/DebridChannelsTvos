from pathlib import Path
import hashlib, plistlib, re, sys, yaml
ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
REMOTE = (ROOT/'Sources/RemoteImageFit.swift').read_text()
STORE = (ROOT/'Sources/CatalogStore.swift').read_text()
SPORTS_VM = (ROOT/'Sources/SportsCenterViewModel.swift').read_text()
SCORES = (ROOT/'Sources/SportsScoresScheduleProvider.swift').read_text()
TEAMS = (ROOT/'Sources/SportsTickerFavoriteTeamsManager.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id vBRDC091', app.get('DebridChannelsReleaseID')=='vBRDC091' and top.get('DebridChannelsReleaseID')=='vBRDC091')
ck('marketing 1.0.794', app.get('CFBundleShortVersionString')=='1.0.794' and top.get('CFBundleShortVersionString')=='1.0.794')
ck('build 794', app.get('CFBundleVersion')=='794' and top.get('CFBundleVersion')=='794')
ck('project marketing 1.0.794', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.794')
ck('project build 794', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='794')

# Wallpaper phase preservation: yield frames, never restart identity.
gif=section(APP,'private final class DynamicWallpaperAnimatedUIImageView','private struct DynamicWallpaperAnimatedImageView')
ck('GIF WebP decoder identity excludes paused state', 'let identityChanged = configuredURL != url || configuredPerformanceMode != normalizedMode' in gif)
identity=section(gif,'if identityChanged {','// vBRDC091: a navigation yield')
ck('GIF WebP pause does not cancel decoder', 'paused' not in identity and 'decodeTask?.cancel()' in identity)
ck('GIF WebP decoder sleeps while paused', 'if shouldPause {' in gif and 'Task.sleep(nanoseconds: 45_000_000)' in gif and 'continue' in gif)
ck('GIF WebP frame index survives navigation pause', 'var index = 0' in gif and 'index = (index + 1) % count' in gif)
ck('GIF WebP keeps current frame during pause', 'image = nil' not in section(gif,'// vBRDC091: a navigation yield','guard decodeTask == nil'))
video=section(APP,'private final class DynamicWallpaperLoopPlayerUIView','private struct DynamicWallpaperLoopVideoView')
ck('video wallpaper dedupes pause play commands', 'configuredPaused' in video and 'if configuredPaused != paused' in video)
ck('video wallpaper only plays on ownership change', video.count('queuePlayer?.play()')==1)
smoke=section(APP,'struct DynamicSmokeWallpaper: View','private func renderWallpaper')
ck('procedural wallpaper accumulates paused duration', '@State private var accumulatedPausedDuration' in smoke)
ck('procedural wallpaper records pause start', '@State private var pauseBeganAtReferenceTime' in smoke)
ck('procedural wallpaper phase subtracts paused time', 'let t = (pauseBeganAtReferenceTime ?? rawReferenceTime) - accumulatedPausedDuration' in smoke)
ck('procedural wallpaper remains Timeline paused for frame budget', 'TimelineView(.animation(minimumInterval: 1.0 / fps, paused: paused))' in smoke)

# Surface-specific decoded artwork isolation.
ck('three artwork cache domains', all(x in REMOTE for x in ['case persistent','case sports','case favorites']))
ck('Sports has isolated decoded cache', 'sportsMemoryCache' in REMOTE and '28 * 1024 * 1024' in REMOTE)
ck('Favorites has isolated decoded cache', 'favoritesMemoryCache' in REMOTE)
ck('load key owns cache domain', 'let domain: PremiumArtworkCacheDomain' in REMOTE)
ck('loader accepts cache domain', 'cacheDomain: PremiumArtworkCacheDomain = .persistent' in REMOTE)
ck('transient domains may reuse warm persistent decode', 'if key.domain != .persistent' in REMOTE and 'Self.memoryCache.object' in REMOTE)
ck('transient domains never write into persistent cache by default', 'cache(for: key.domain).setObject' in REMOTE)
ck('transient release cancels domain network work', 'static func releaseTransientSurfaceResources' in REMOTE and 'activeNetworkTasks.keys.filter { $0.domain == domain }' in REMOTE)
ck('transient release drops in-flight subscribers', 'inFlightLoads.keys.filter { $0.domain == domain }' in REMOTE)
ck('transient release clears domain cache', 'cache(for: domain).removeAllObjects()' in REMOTE)
remote_view=section(REMOTE,'struct RemoteImageFit: View','private func placeholder')
ck('RemoteImageFit inherits cache domain', r'@Environment(\.premiumArtworkCacheDomain)' in remote_view)
ck('RemoteImageFit passes cache domain on all load paths', remote_view.count('cacheDomain: cacheDomain') >= 3 and 'cacheDomain: newDomain' in remote_view)
root=section(APP,'var body: some View {','realNewEpisodeAlertLayer')
ck('Sports root owns sports artwork domain', 'SportsHubScreen()' in root and r'.environment(\.premiumArtworkCacheDomain, .sports)' in root)
ck('Favorites root owns favorites artwork domain', 'GlobalFavoritesScreen()' in root and r'.environment(\.premiumArtworkCacheDomain, .favorites)' in root)
ck('Favorites details remain in favorites cache domain', 'store.detailPresentationOrigin == .favorites ? .favorites : .persistent' in root)
handoff=section(APP,'.onChange(of: store.selectedTab)', '.onChange(of: sportsScoreTickerEnabled)')
ck('root releases Sports cache on tab exit', 'oldTab == .sports' in handoff and 'releaseTransientSurfaceResources(domain: .sports' in handoff)
ck('root releases Favorites cache on tab exit', 'oldTab == .favorites' in handoff and 'releaseTransientSurfaceResources(domain: .favorites' in handoff)

# Sports surface: no duplicate LiveTVSourceModel or retained presentation graph.
sports=section(APP,'struct SportsHubScreen: View','private func sportsPlaceholderItem')
ck('SportsHub has no second LiveTVSourceModel StateObject', '@StateObject private var liveModel = LiveTVSourceModel()' not in sports)
ck('Sports classification reads bounded retained channels', 'cachedRealAmbientChannels(limit: 600)' in sports)
ck('Sports exit cancels surface load task', 'sportsSurfaceLoadTask?.cancel()' in sports)
ck('Sports exit invalidates live zone', 'liveZone.suspendForSurfaceExit()' in sports)
ck('Sports exit releases mapped Sports rows', 'sportsCenterVM.releaseForSurfaceExit()' in sports)
ck('Sports exit releases transient artwork', 'releaseTransientSurfaceResources(domain: .sports' in sports)
livezone=section(APP,'@MainActor\nfinal class SportsLiveZoneModel','struct SportsHubScreen: View')
ck('Sports model exit clears score event arrays', all(x in livezone for x in ['liveNow.removeAll','today.removeAll','upcoming.removeAll','sportsOnlyChannels.removeAll','highlights.removeAll']))
ck('Sports model exit clears derived event arrays', all(x in livezone for x in ['commandCenter.removeAll','theaterMode.removeAll','heatMap.removeAll','ppvEvents.removeAll']))
ck('SportsCenter exposes explicit release', 'func releaseForSurfaceExit()' in SPORTS_VM and 'sportsRows.removeAll(keepingCapacity: false)' in SPORTS_VM)
ck('sports scores provider no longer MainActor isolated', '@MainActor\nstruct SportsScoresScheduleProvider' not in SCORES)
ck('sports favorite manager no longer MainActor isolated', '@MainActor\nstruct SportsTickerFavoriteTeamsManager' not in TEAMS)
ck('global sports bootstrap is conditional on ticker', 'if sportsScoreTickerEnabled {' in section(APP,'private func startAppBootstrapIfNeeded','private func recoverEpisodeAlertSchedulerAfterCatalogLoad'))

# Frozen donor: retain only the visible corridor, not an IPTV lineup copy.
model_helpers=section(APP,'static func cachedRealAmbientChannels','@MainActor\n    func loadCachedOrDemo')
ck('ambient channel helper supports bounded limit', 'limit: Int? = nil' in model_helpers)
ck('ambient corridor helper exists', 'static func cachedRealAmbientChannelCorridor' in model_helpers)
ck('corridor default is 12 cards', 'limit: Int = 12' in model_helpers)
frozen=section(APP,'private struct FrozenLiveTVBackdrop','struct LiveTVScreen: View')
ck('frozen donor loads bounded corridor', 'cachedRealAmbientChannelCorridor' in frozen and 'limit: 12' in frozen)
ck('frozen donor no longer copies entire lineup', 'cachedRealAmbientChannels()' not in frozen)
ck('frozen donor still uses real Live TV tile visual', 'LiveTVGridTileContent(' in frozen)
ck('frozen donor remains non-reactive to CatalogStore', '@EnvironmentObject var store: CatalogStore' not in frozen)

# Favorites exit releases local media snapshot and work.
favorites=section(APP,'struct GlobalFavoritesScreen: View','struct FavoriteLiveChannelCard')
ck('Favorites disappearance cancels rebuild task', 'favoritesRebuildTask?.cancel()' in favorites)
ck('Favorites disappearance releases local snapshot', 'cachedFavoriteItems.removeAll(keepingCapacity: false)' in favorites)
ck('Favorites disappearance releases artwork domain', 'releaseTransientSurfaceResources(domain: .favorites' in favorites)
ck('Favorites Back still clears presentation identity', 'clearFavoritesPresentationStateForNavigation' in favorites)

# Catalog watchdog should not keep waking a healthy returned catalog.
ck('CatalogStore exposes completeness recovery predicate', 'var catalogCompletenessNeedsRecovery: Bool' in STORE)
watchdog=section(APP,'private func startCatalogCompletenessWatchdogIfNeeded','private func stopCatalogCompletenessWatchdog')
ck('watchdog only arms if recovery is needed', 'store.catalogCompletenessNeedsRecovery' in watchdog)

# v090 frame-budget architecture remains intact.
ck('CatalogStore status remains non-Published', '@Published var status' not in STORE and 'var status: String = "Loading catalogs…"' in STORE)
ck('only one real LiveTVScreen root mount remains', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)
ck('wallpaper still receives navigation pause gate', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('image publication still defers during remote movement', 'shouldDeferNoncriticalVisualPublication' in REMOTE)
ck('automatic resume play assertion remains', 'ksPlayAssertionSerial &+= 1' in APP)
ck('Favorites identity isolation remains', 'quickPanelRestoreSection != "favoritesCatalog"' in APP)
ck('Connected popup artwork remains catalog-only', 'connectorOrigin == .catalog' in APP)

# Provider/playback work is intentionally not mixed into this performance corrective build.
DONOR={
'Sources/NuvioPluginClient.swift':'0495f210b9d2ca0b316f0124e1bb4b584147a303c3cb193f48f5cee4fa7259e5',
'Sources/BackupStreamingClient.swift':'032b7ee7663491e93057d7e3702ba7bc55674a8cb10b9336093e7a0399dd4a49',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityAnimationCoordinator.swift':'9acc35f8d14985b73a72b0518d14400c04e742944b1d3fd8c1bfcde4503a6fc4',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
'Sources/UnitySurfaceSystem.swift':'848355016d11e481b157e7fff8ddf398b92bfceaae295da0fcf6193dd32d925c',
'BackendBackupStreamingRuntime/backup_streaming_runtime.py':'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py':'340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
}
for rel,expected in DONOR.items(): ck('donor lock '+rel, sha(rel)==expected)
entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source declared in project', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
