# Debrid Channels vBRDC102 — UNITY Frame Runtime

- Release ID: `vBRDC102`
- Marketing version: `1.0.805`
- Apple build: `805`
- Donor: packaged `vBRDC101_BUTTER_SMOOTH_UNITY_HANDOFF`
- Code name: `UNITY`

## Purpose

vBRDC102 is an app-wide interaction-runtime rebuild. It keeps the existing visual themes, Artwork/Hero layouts, Dynamic Wallpaper choices, row-scrolling animation presets, Live TV grid, Gracenote/XMLTV/Xtream data, Sports, Favorites and VOD presentation intact, but replaces their independent timing decisions with one shared frame-priority authority.

The goal is that every interactive surface behaves as one UNITY system: while Siri Remote geometry is moving, focus/scroll owns the frame; while a surface is opening/closing, transition geometry owns the frame; artwork, metadata, Gracenote, catalog publication, prefetch, persistence and ambient animation publish only in the lanes that are safe for that transaction.

## New UNITY Frame Runtime

`Sources/UnityFrameRuntime.swift` introduces process-wide lanes for:

- navigation geometry
- transition geometry
- critical visible artwork
- interactive metadata
- Live TV schedule/EPG publication
- background prefetch
- persistence
- ambient/perpetual motion
- recovery work
- overlay/playback chrome
- alerts

Repeated Siri Remote movement is coalesced into one navigation transaction instead of producing an ObservableObject root invalidation for every repeat event. Duplicate surface-handoff claims are also coalesced.

## App-wide integration

1. **All themes and row animations use the same ownership clock.** Existing row-motion definitions remain byte-identical to vBRDC101. Their look, easing, transforms and theme identities are not redesigned.
2. **Dynamic Wallpaper, catalog pulse/preview and ticker motion are ambient work.** They yield while navigation/transition geometry owns the frame and resume after the transaction tail.
3. **Critical artwork and normal artwork are separated.** Hero/backdrop/focused artwork can complete a safe surface-handoff publication; noncritical prefetch waits. Decoded images no longer use an independent 35 ms polling loop or force-publish after 350 ms.
4. **Catalog row/model publication is frame-aware.** Rendered-row rebuilds, bulk catalog provider swaps, TMDB background shelves, lazy row replacement and Favorites rebuilds wait until interactive geometry releases the frame.
5. **Hero metadata is frame-aware.** Metadata lookup/publication no longer relies on one fixed 850 ms guess that can wake inside a slow row-motion preset.
6. **Live TV/Gracenote is part of UNITY.** Gracenote/XMLTV/Xtream work can fetch/parse independently, but the published guide/channel model swaps only after the shared runtime allows interactive metadata. The main guide is constructed in a local snapshot so a large dictionary is not mutated during scrolling.
7. **Xtream EPG batches are frame-aware.** Visible channel batches, incremental native EPG and deferred final guide publication share the same metadata lane.
8. **Live TV schedule boundaries, artwork prefetch and selection persistence have explicit lanes.** They no longer maintain separate local settle heuristics that can wake during a different surface's motion.
9. **Sports is integrated.** Retained Sports rows pre-bind for entry, while later sports channel classification and multi-rail network publication yield during active navigation.
10. **Favorites, Media Information, Details, Settings/customization and Live guide/control movement register navigation ownership.** Their model updates therefore coordinate with the same runtime rather than behaving as isolated screens.
11. **vBRDC101 Artwork 4 / Hero 2 continuity remains intact.** Stable image ownership, 4K decode caps, retained-frame behavior and preflight focus binding are preserved.
12. **vBRDC100 Cast and Production & Ratings rotation continuity remains intact.** The previous image remains visible until the replacement is ready.

## Intentionally unchanged visually

- Home / Movies / TV Shows / Search / Favorites layouts
- all existing Hero and Artwork themes
- all existing row-scrolling animation presets
- wallpaper and Dynamic Wallpaper selections/effects
- Live TV grid and guide presentation
- Gracenote/XMLTV/Xtream program data semantics
- Sports presentation
- VOD overlay layout
- playback/resume/source-provider behavior
- TorBox/Usenet and Source Intelligence logic

## Validation

- UNITY architecture contract: `117/117`
- Swift syntax parse units: `65/65`
- version/plist/project checks: `8/8`
- unchanged backend suites: `36 passed, 2 subtests passed`
- implementation/metadata donor scope: exact `9` files (including the new frame runtime)

Physical Apple TV testing remains the authoritative measurement for frame pacing and focus feel; this package validation confirms source integrity, coordination contracts and donor preservation.
