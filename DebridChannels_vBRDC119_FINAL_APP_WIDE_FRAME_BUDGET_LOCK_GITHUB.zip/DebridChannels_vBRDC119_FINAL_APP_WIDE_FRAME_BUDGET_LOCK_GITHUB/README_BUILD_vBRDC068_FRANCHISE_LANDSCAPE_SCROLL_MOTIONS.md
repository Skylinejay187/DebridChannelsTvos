# vBRDC068 — Franchise Landscape + Catalog Row Motion Presets

- Release ID: **vBRDC068**
- Marketing version: **1.0.771**
- Apple build: **771**
- Code Name: **UNITY**
- Donor: packaged **vBRDC067** only
- Backend: **v693 unchanged**

## Scope

### 1. Franchise shelf is landscape-first
The vBRDC067 franchise shelf correctly stopped cropping poster art, but portrait posters became visually too small inside the wide shelf. vBRDC068 changes the franchise presentation to a landscape-first design:

- real `landscapeURL`/backdrop artwork fills each wide franchise card;
- portrait `posterURL` is only a fallback and remains aspect-fit;
- collapsed franchise stack also uses landscape thumbnails;
- clearlogo is rendered in its own fixed safe box using aspect-fit and can never become crop-fill artwork;
- title and year live in a dedicated metadata strip below the image, independent of artwork/logo dimensions;
- the existing upward-expanding franchise animation and compact 66-point resting footprint are preserved;
- catalog rows are not pushed down or moved.

### 2. Catalog Row Motion setting
Appearance now contains **Catalog Row Motion**, a global presentation preference for Home/Movies/Shows/shared catalog rails. It changes only the horizontal transition when the selected item changes.

Presets:

1. Classic Spring — existing Debrid Channels motion (default)
2. Smooth Glide
3. Cinematic Drift
4. Elastic
5. Quick Snap
6. Soft Float
7. Depth Shift
8. Carousel Tilt
9. Instant — no horizontal transition

The setting preserves focus ownership, selected-index logic, row geometry, Search-style focused-card arrival/bounce, vertical row navigation, and playback behavior. Left/right transitions respect the direction actually pressed.

The setting is included in Full Profile Backup/Restore and Stable UI Defaults.

## Locked / unchanged

No changes were made to:

- PlaybackKit KSPlayer VOD surface
- vBRDC062 instant-start / 300-second VOD buffer-ahead / buffer ghost
- vBRDC063 matched-frame-rate A/V correction
- vBRDC064 KSPNUVIO IDET crash patch
- vBRDC065 XMLTV watchdog architecture
- vBRDC066 Search-return recovery
- focused-card preview playback behavior (the PREVIEW badge remains removed)
- TorBox Usenet provider/runtime
- Source Intelligence catalog store
- Unity root/navigation ownership
- Skip Intro engine
- playback state/resume ownership
- backend v693

## Validation in this package

- 61 Swift source files parsed with `swiftc -frontend -parse`
- main and Top Shelf plists parsed and agree on 1.0.771 / build 771 / vBRDC068
- `project.yml` parsed successfully
- vBRDC068 contract passed
- locked playback/provider/navigation files SHA-256 match vBRDC067 donor
- ZIP integrity test passed

GitHub Actions/Xcode remains the authoritative Apple-platform compile. Physical Apple TV testing is required for final motion preference/timing judgement.
