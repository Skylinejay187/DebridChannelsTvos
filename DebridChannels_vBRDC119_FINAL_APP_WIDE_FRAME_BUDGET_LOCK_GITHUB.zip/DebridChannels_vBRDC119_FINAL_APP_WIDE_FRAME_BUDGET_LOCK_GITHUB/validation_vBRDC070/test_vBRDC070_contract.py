import plistlib
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def txt(rel):
    return (ROOT / rel).read_text(encoding='utf-8')


class VBRDC070ContractTests(unittest.TestCase):
    def test_release_versions_match(self):
        for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
            with (ROOT / rel).open('rb') as handle:
                info = plistlib.load(handle)
            self.assertEqual(info['CFBundleShortVersionString'], '1.0.773')
            self.assertEqual(info['CFBundleVersion'], '773')
            self.assertEqual(info['DebridChannelsReleaseID'], 'vBRDC070')
        project = txt('project.yml')
        self.assertEqual(project.count('MARKETING_VERSION: 1.0.773'), 2)
        self.assertEqual(project.count('CURRENT_PROJECT_VERSION: 773'), 2)

    def test_fresh_install_boundary_clears_local_credentials(self):
        security = txt('Sources/ReleaseCandidateSecurityManager.swift')
        self.assertIn('credentialInstallBoundaryV1', security)
        self.assertIn('.debridchannels-credential-install-v1', security)
        for needle in (
            'BackupStreamingCredentialStore.purgeForFreshInstall()',
            'MediaFlowCredentialStore.purgeForFreshInstall()',
            'NuvioPluginPreferences.purgeForFreshInstall(defaults: defaults)',
            '"torBoxApiKey"', '"realDebridApiKey"', '"liveXtreamPassword"',
            '"tmdbApiKey"', '"tvdbApiToken"',
        ):
            self.assertIn(needle, security)
        # The installation sentinel must not be part of profile backup data.
        self.assertNotIn('credentialBoundaryDefaultsKey,', security)

    def test_keychain_secrets_only_enter_explicit_backup_vault(self):
        app = txt('Sources/DebridChannelsTVOSApp.swift')
        security = txt('Sources/ReleaseCandidateSecurityManager.swift')
        nuvio = txt('Sources/NuvioPluginClient.swift')
        self.assertIn('"credentialVault": credentialVault', app)
        self.assertIn('sanitizedCredentialVault', app)
        self.assertIn('BackupStreamingCredentialStore.readFebBoxCookie()', app)
        self.assertIn('MediaFlowCredentialStore.readPassword()', app)
        self.assertIn('NuvioPluginPreferences.exportBackupBlob()', app)
        self.assertIn('"febBoxCookie": 16_384', security)
        self.assertIn('"mediaFlowAPIPassword": 32_768', security)
        self.assertIn('"nuvioPluginBackupBlob": 2_000_000', security)
        self.assertIn('NuvioPluginCredentialStore.purgeAll()', nuvio)

    def test_torbox_newznab_is_primary_and_relay_precedes_legacy(self):
        client = txt('Sources/TorBoxUsenetClient.swift')
        direct_pos = client.index('searchNewznabDirect(item: item')
        relay_pos = client.index('searchViaBackendRelay(', direct_pos)
        legacy_pos = client.index('searchLegacyVoyagerDirect(item: item', relay_pos)
        library_pos = client.index('searchOwnedLibrary(item: item', legacy_pos)
        self.assertLess(direct_pos, relay_pos)
        self.assertLess(relay_pos, legacy_pos)
        self.assertLess(legacy_pos, library_pos)
        self.assertIn('https://search-api.torbox.app/newznab/api', client)
        self.assertIn('URLQueryItem(name: "t", value: generic ? "search"', client)
        self.assertIn('URLQueryItem(name: "apikey", value: apiKey)', client)
        self.assertIn('URLQueryItem(name: "imdbid"', client)
        self.assertIn('URLQueryItem(name: "tvdbid"', client)
        self.assertIn('URLQueryItem(name: "season"', client)
        self.assertIn('URLQueryItem(name: "ep"', client)

    def test_torbox_newznab_xml_and_nzb_upload_fallback_present(self):
        client = txt('Sources/TorBoxUsenetClient.swift')
        runtime = txt('BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py')
        for needle in ('NewznabXMLCollector', 'parseNewznabResponse', 'application/x-nzb', 'fetchNZBForUpload', 'createDownloadFromNZBData'):
            self.assertIn(needle, client)
        self.assertIn('NEWZNAB_API = f"{SEARCH_BASE}/newznab/api"', runtime)
        self.assertIn('_parse_newznab', runtime)
        self.assertIn('"source": "torbox-newznab"', runtime)
        self.assertIn('backend v694', runtime)

    def test_catalog_motion_has_48_preset_set(self):
        visual = txt('Sources/UnityCatalogVisualSystem.swift')
        match = re.search(r'static let names = \[(.*?)\n    \]', visual, re.S)
        self.assertIsNotNone(match)
        names = re.findall(r'"([^"]+)"', match.group(1))
        self.assertEqual(len(names), 48)
        for name in (
            'Parallax Sweep', 'Deck Flip', 'Wave Glide', 'Perspective Push', 'Rubber Band', 'Cinema Push',
            'Focus Rush', 'Camera Dolly', 'Portal Zoom', 'Helix Tilt', 'Overshoot Glide', 'Lift Off'
        ):
            self.assertIn(name, names)

    def test_adaptive_vod_memory_fix_remains_present(self):
        playback = txt('Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift')
        # vBRDC069 adaptive memory lane must survive this corrective pass.
        self.assertIn('largeFileVOD', playback)
        self.assertIn('maxBufferDuration', playback)


if __name__ == '__main__':
    unittest.main()
