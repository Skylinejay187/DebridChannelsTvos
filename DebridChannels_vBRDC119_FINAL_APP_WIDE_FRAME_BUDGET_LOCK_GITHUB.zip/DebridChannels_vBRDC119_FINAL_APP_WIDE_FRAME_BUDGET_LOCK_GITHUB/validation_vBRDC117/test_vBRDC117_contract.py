from pathlib import Path
import hashlib
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources' / 'DebridChannelsTVOSApp.swift').read_text()
INFO = (ROOT / 'Sources' / 'Info.plist').read_text()
TOP = (ROOT / 'TopShelfExtension' / 'Info.plist').read_text()
PROJ = (ROOT / 'project.yml').read_text()
DONOR = Path('/mnt/data/DebridChannels_vBRDC116_35_SECOND_CATALOG_PREVIEW_CAP_GITHUB')

checks = {
    'release id': 'vBRDC117' in INFO and 'vBRDC117' in TOP,
    'marketing version': '1.0.820' in INFO and '1.0.820' in TOP and PROJ.count('MARKETING_VERSION: 1.0.820') == 2,
    'apple build': '<string>820</string>' in INFO and '<string>820</string>' in TOP and PROJ.count('CURRENT_PROJECT_VERSION: 820') == 2,
    'MediaPlayer imported': 'import MediaPlayer' in APP,
    'Bluetooth command center retained': 'MPRemoteCommandCenter.shared()' in APP,
    'toggle command retained': 'togglePlayPauseCommand.addTarget' in APP,
    'play command retained': 'playCommand.addTarget' in APP,
    'pause command retained': 'pauseCommand.addTarget' in APP,
    'standard setting defaults on': 'static let enabledKey = "bluetoothVODPlayPauseEnabledV1"' in APP and 'if UserDefaults.standard.object(forKey: enabledKey) == nil { return true }' in APP,
    'VOD audio category playback': 'try session.setCategory(.playback, mode: .moviePlayback, options: [])' in APP,
    'VOD audio session activated': 'try session.setActive(true)' in APP,
    'Now Playing title published': 'info[MPMediaItemPropertyTitle] = title' in APP,
    'Now Playing duration published': 'info[MPMediaItemPropertyPlaybackDuration] = safeDuration' in APP,
    'Now Playing elapsed published': 'info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = safeElapsed' in APP,
    'Now Playing rate published': 'info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0' in APP,
    'Now Playing default rate published': 'info[MPNowPlayingInfoPropertyDefaultPlaybackRate] = 1.0' in APP,
    'Now Playing marked non-live': 'info[MPNowPlayingInfoPropertyIsLiveStream] = false' in APP,
    'claim publishes current VOD metadata': all(x in APP for x in ['title: item.title', 'duration: resolvedDurationSeconds', 'elapsed: authoritativeCurrentSeconds', 'isPlaying: isPlaying']),
    'play pause state refreshes Now Playing': '.onChange(of: isPlaying) { playing in' in APP and 'isPlaying: playing,\n                force: true' in APP,
    'timeline refreshes Now Playing': '.onChange(of: currentSeconds) { _ in' in APP and 'BluetoothVODMediaButtonCoordinator.shared.updateNowPlaying(' in APP,
    'Now Playing updates throttled': 'abs(safeElapsed - lastNowPlayingElapsed) >= 5.0' in APP,
    'release clears Now Playing': 'MPNowPlayingInfoCenter.default().nowPlayingInfo = nil' in APP,
    'release deactivates audio session': 'setActive(false, options: [.notifyOthersOnDeactivation])' in APP,
    'commands are VOD only': 'if !isLivePlayback {' in APP and 'claimVODSession(' in APP,
    'Bluetooth notification remains VOD guarded': 'guard !isLivePlayback,\n              bluetoothVODPlayPauseEnabled,' in APP,
    'SwiftUI play pause fallback retained': '.onPlayPauseCommand {' in APP and 'shouldSuppressSwiftUIPlayPause()' in APP,
    'v113 compile containment retained': 'var body: some View {\n        playerCommandTree\n    }' in APP,
    '35 second catalog preview retained': '35_000_000_000' in APP or '35.0' in APP,
}

# High-value donor locks: these subsystems must not drift in this Bluetooth-only build.
locked_files = [
    'Sources/MediaFlowProxyRouter.swift',
    'Sources/UnityCatalogVisualSystem.swift',
    'Sources/UnityFrameRuntime.swift',
    'Sources/UnityAnimationCoordinator.swift',
    'Sources/CastExplorerService.swift',
    'Sources/CatalogStore.swift',
]
if DONOR.exists():
    for rel in locked_files:
        a = DONOR / rel
        b = ROOT / rel
        checks[f'locked unchanged: {rel}'] = a.exists() and b.exists() and hashlib.sha256(a.read_bytes()).digest() == hashlib.sha256(b.read_bytes()).digest()

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    raise SystemExit('Contract failures: ' + ', '.join(failed))
