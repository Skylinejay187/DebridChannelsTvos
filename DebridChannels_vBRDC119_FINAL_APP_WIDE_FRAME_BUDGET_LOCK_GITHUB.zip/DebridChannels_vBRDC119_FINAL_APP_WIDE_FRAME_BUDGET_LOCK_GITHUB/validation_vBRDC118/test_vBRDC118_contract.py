from pathlib import Path
import hashlib, plistlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
MFP=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
PROJ=(ROOT/'project.yml').read_text()
checks=[]
def check(name, cond):
    checks.append((name, bool(cond)))

def block_between(text, start, end):
    a=text.index(start); b=text.index(end,a); return text[a:b]

# Version/release
with (ROOT/'Sources/Info.plist').open('rb') as f: info=plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top=plistlib.load(f)
check('release id vBRDC118', info.get('DebridChannelsReleaseID')=='vBRDC118' and top.get('DebridChannelsReleaseID')=='vBRDC118')
check('marketing 1.0.821', info.get('CFBundleShortVersionString')=='1.0.821' and top.get('CFBundleShortVersionString')=='1.0.821' and PROJ.count('MARKETING_VERSION: 1.0.821')==2)
check('build 821', info.get('CFBundleVersion')=='821' and top.get('CFBundleVersion')=='821' and PROJ.count('CURRENT_PROJECT_VERSION: 821')==2)

# Peak smooth artwork pipeline
check('heavy-load opt-in defaults false', 'var deferHeavyLoadDuringNavigation: Bool = false' in IMG)
check('dedicated settled-load method exists', 'func loadAfterNavigationSettles(' in IMG)
check('exact cache remains immediate', 'if exactCached {' in IMG)
check('same-turn navigation race yields once', 'await Task.yield()' in IMG)
check('navigation ownership read from frame runtime snapshot', 'UnityFrameRuntime.shared.snapshot.navigationActive' in IMG)
check('heavy cache miss waits criticalArtwork lane', 'waitUntilPermitted(\n                    .criticalArtwork' in IMG)
check('deferred heavy request cancellable', IMG.count('deferredNavigationLoadTask?.cancel()') >= 3)
check('heavy request option routed through RemoteImageFit', 'if deferHeavyLoadDuringNavigation {' in IMG and 'loader.loadAfterNavigationSettles(' in IMG)
check('four 4K decorative surfaces opt in', APP.count('deferHeavyLoadDuringNavigation: true') == 4)
# Ensure each opt-in is a 3840 surface in a small preceding window
positions=[m.start() for m in re.finditer('deferHeavyLoadDuringNavigation: true', APP)]
check('all heavy opt-ins belong to 4K artwork', all('maxPixelSize: 3840' in APP[max(0,p-260):p] for p in positions))

focused=block_between(APP,'struct FixedSlotFocusedCatalogCard: View {','struct MediaInfoPopup: View {')
check('focused card keeps immediate 1280 artwork', 'maxPixelSize: 1280' in focused and 'deferHeavyLoadDuringNavigation: true' not in focused)
hero=block_between(APP,'struct Artwork4HeroLogoLayer: View {','struct FixedSlotFocusedCatalogCard: View {')
check('hero logo remains immediate 1280', 'maxPixelSize: 1280' in hero and 'deferHeavyLoadDuringNavigation: true' not in hero)

# Episode alert visual scope
check('episode alerts use shared 18pt edge inset', 'private let newEpisodeAlertScreenEdgeInset: CGFloat = 18' in APP)
check('root banner uses edge inset', '.padding(newEpisodeAlertBannerSide.horizontalEdgeSet, newEpisodeAlertScreenEdgeInset)' in APP and 'newEpisodeAlertScreenEdgeInset\n    }' in APP)
check('VOD banner uses edge inset', '.padding(episodeAlertSide.verticalEdgeSet, newEpisodeAlertScreenEdgeInset)' in APP and '.padding(episodeAlertSide.horizontalEdgeSet, newEpisodeAlertScreenEdgeInset)' in APP)
banner=block_between(APP,'struct RootNewEpisodeAlertBanner: View {','struct RootNewEpisodeInteractivePopup: View {')
check('episode banner reduced to 530x176', '.frame(width: 530, height: 176' in banner)
check('episode poster reduced to 80x120', '.frame(width: 80, height: 120)' in banner)
check('episode title typography reduced', '.font(.system(size: 23, weight: .black, design: .rounded))' in banner)
poster=block_between(APP,'struct EpisodeAlertPosterImage: View {','struct RootNewEpisodeAlertBanner: View {')
check('episode poster reuses central bounded artwork loader', 'RemoteImageFit(' in poster and 'maxPixelSize: 512' in poster and 'publishDuringPlayback: true' in poster)
check('episode poster no independent AsyncImage loader', 'AsyncImage' not in poster)

# Preserve accepted behavior
check('35-second catalog preview retained', 'CMTime(seconds: 35.0' in APP and 'finishCurrentPreview(reason: "35-second cap")' in APP)
check('catalog preview still finishes instead of looping', 'AVPlayerItemDidPlayToEndTime' in APP and 'finishCurrentPreview(reason: "asset ended")' in APP)
check('Bluetooth Now Playing retained', 'MPNowPlayingInfoCenter.default().nowPlayingInfo' in APP and 'MPRemoteCommandCenter.shared()' in APP)
check('Bluetooth moviePlayback audio session retained', 'setCategory(.playback, mode: .moviePlayback' in APP)
check('MediaFlow LAN bootstrap uses stream/epg', 'let endpoints = epg ? ["/proxy/epg", "/proxy/stream"] : ["/proxy/stream"]' in MFP)
check('MediaFlow live bootstrap helper retained', 'static func liveTVBootstrapRequestsIfAllowed(' in MFP)
check('Live TV app path calls bootstrap helper', 'MediaFlowProxyRouter.liveTVBootstrapRequestsIfAllowed(request, epg: isEPGRequest)' in APP)
check('vBRDC110 durable Live TV commit retained', 'vBRDC110' in APP and 'successful Live TV bootstrap' in APP)

# Immutable architecture hashes against v117 donor known values
expected={
'Sources/UnityCatalogVisualSystem.swift':'e5e4a14c0b61f11f46c2866ed7b0e7f5d14cb46f00269411fc6766defffcd7c3',
'Sources/UnityFrameRuntime.swift':'d360d07514d76876e9b3de412115751fdb8052ec6ae482618d192a4dead0e95d',
'Sources/UnityAnimationCoordinator.swift':'2206eabc3ce477f02de2116b3035b4bae96ee4dca7ef7e2135b1c68cbf820132',
'Sources/CatalogStore.swift':'0d099e7ae5ca84e217610700d98e609944588232b29bb017b79ce2820be06235',
'Sources/MediaFlowProxyRouter.swift':'eaedc162e1b1eff687207b412fb2157cb3168da047b9cf7724d991a9a9bf3c0c',
}
for rel,want in expected.items():
    got=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
    check(f'locked donor unchanged: {Path(rel).name}', got==want)

passed=sum(ok for _,ok in checks)
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
print(f'\n{passed}/{len(checks)} checks passed')
if passed != len(checks): sys.exit(1)
