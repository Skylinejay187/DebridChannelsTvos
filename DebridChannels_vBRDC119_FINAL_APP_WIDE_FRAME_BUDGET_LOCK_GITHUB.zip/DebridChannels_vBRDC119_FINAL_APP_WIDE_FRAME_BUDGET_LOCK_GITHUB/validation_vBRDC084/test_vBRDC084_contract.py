from pathlib import Path
import hashlib, plistlib, sys, yaml
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
RESUME=(ROOT/'Sources/PlaybackResumeCache.swift').read_text()
KS=(ROOT/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJECT=yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id', app.get('DebridChannelsReleaseID')=='vBRDC084' and top.get('DebridChannelsReleaseID')=='vBRDC084')
ck('marketing version', app.get('CFBundleShortVersionString')=='1.0.787' and top.get('CFBundleShortVersionString')=='1.0.787')
ck('build version', app.get('CFBundleVersion')=='787' and top.get('CFBundleVersion')=='787')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.787')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='787')

# Exact resume identity / Search badge isolation.
ck('resume persists year compatibly', 'var year: String?' in RESUME and 'year: item.year.trimmingCharacters' in RESUME)
ck('same-title title-only movie fallback removed', 'movie resume identity must never be title-only' in RESUME)
ck('stable movie IDs skip legacy scan', 'private func shouldAttemptLegacyScan' in RESUME and 'tmdbID(in: item.id) != nil' in RESUME and 'imdbID(in: item.id) != nil' in RESUME)
ck('year blocks legacy scan', 'if !item.year.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return false }' in RESUME)
ck('legacy movie year must match', 'return !itemYear.isEmpty && !entryYear.isEmpty && itemYear == entryYear' in RESUME)
ck('last legacy fallback catalog scoped', 'entry.catalog.caseInsensitiveCompare(item.catalog) == .orderedSame' in RESUME)
ck('Search card still uses exact resume manager', 'PlaybackResumeCacheManager.shared.resumeEntry(for: item)' in APP)

# Search Production information instant/correct hydration.
ck('production session cache exists', 'private final class PopupHeaderDetailsService' in APP)
ck('production cache bounded', 'private let maximumEntries = 80' in APP)
ck('search production prewarm task', 'productionPrefetchTask' in APP and 'prewarmSearchProductionDetails' in APP)
ck('prewarm focused only', 'UNITY performance rule: prewarm only the result that currently owns focus' in APP)
ck('prewarm VOD cancellable', 'productionPrefetchTask = VODExclusiveWorkRegistry.start' in APP)
ck('popup synchronous cached publish', 'if let cached = PopupHeaderDetailsService.shared.cached(for: item)' in APP)
ck('search stable-id hydration retriggers production', 'popupProductionHydrationIdentity' in APP and '.onChange(of: popupProductionHydrationIdentity)' in APP)
ck('production fetch uses exact hydrated IDs', 'PopupHeaderDetailsService.shared.details(for: item, apiKey: key)' in APP)

# Wallpaper quality retained, cadence bounded.
ck('Nexus Lines retained', '"Nexus Lines"' in APP and 'private func drawNexusLines(' in APP)
ck('all UHD custom formats retained', all(x in APP for x in ['"gif"','"webp"','"mp4"','"mov"','"m4v"']))
ck('UHD pixel target retained', 'nativePixelTarget = min(3840, max(1920, screenLongEdge))' in APP)
ck('custom aspect fill retained', 'view.contentMode = .scaleAspectFill' in APP and 'playerLayer.videoGravity = .resizeAspectFill' in APP)
ck('procedural fps budget', 'case "High Performance": return 16.0' in APP and 'case "Balanced": return 12.0' in APP and 'default: return 8.0' in APP)
ck('UHD raster cadence budget', 'case "High Performance": maxFPS = 10' in APP and 'case "Balanced": maxFPS = 8' in APP and 'default: maxFPS = 6' in APP)
ck('UHD decoder background priority', 'Task.detached(priority: .background)' in APP)
ck('wallpaper brightness retained', '.brightness(0.08)' in APP and '.opacity(0.94)' in APP)
ck('wallpaper hard playback isolation', 'unityAnimations.allows(.dynamicWallpaper)' in APP and '&& store.playbackURL == nil' in APP and 'if liveWallpaperOwnsRenderBudget' in APP)

# Automatic resume must seek AND remain playing.
ck('app resume confirmation still requests play', 'private func confirmAutomaticResume' in APP and 'isPlaying = true' in APP and 'Automatic resume confirmed and playing' in APP)
ck('KS post-seek liveness generation', 'postSeekAutoplayGeneration' in KS)
ck('KS bounded delayed recovery', 'let delays: [TimeInterval] = [0.32, 0.52, 0.82, 1.18]' in KS)
ck('KS recovery uses advancing real clock', 'currentClock >= previousClock + 0.16' in KS)
ck('KS recovery reasserts play', 'post-resume play reassertion' in KS and 'layer.play()' in KS)
ck('user Pause cancels resume recovery', 'coordinator.postSeekAutoplayGeneration &+= 1' in KS and 'layer.pause()' in KS)
ck('surface teardown cancels resume recovery', 'postSeekAutoplayGeneration &+= 1' in KS and 'playbackKitStopAndReleaseSurface' in KS)
ck('resume remains in-place seek', 'layer.seek(time: target, autoPlay: resumePlayback)' in KS and 'performBestEffortSeek' in KS)

# Sensitive systems intentionally untouched from packaged v083.
BASE_HASHES={
 'Sources/CatalogStore.swift':'10329bae4d44d46357ede17f9b108d2f7db7c16db9dec0e0af7cfba0ca259a8e',
 'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
 'Sources/UnityAnimationCoordinator.swift':'15320d4424cf64faba13e3a94ff099e939cc561254d05ce267b8300ceed9e305',
 'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
 'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
}
for rel, expected in BASE_HASHES.items(): ck('donor lock '+rel, sha(rel)==expected)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source compiled', all_swift.issubset(paths))

failed=[n for n,c in checks if not c]
for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
