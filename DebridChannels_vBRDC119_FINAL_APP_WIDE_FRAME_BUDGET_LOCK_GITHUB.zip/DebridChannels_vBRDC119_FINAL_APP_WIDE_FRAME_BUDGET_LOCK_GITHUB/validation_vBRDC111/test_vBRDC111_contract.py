from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources' / 'DebridChannelsTVOSApp.swift').read_text()
SEC = (ROOT / 'Sources' / 'ReleaseCandidateSecurityManager.swift').read_text()
PROJECT = (ROOT / 'project.yml').read_text()
PLIST = (ROOT / 'Sources' / 'Info.plist').read_text()
TOP = (ROOT / 'TopShelfExtension' / 'Info.plist').read_text()

checks = {
    'MediaPlayer imported': 'import MediaPlayer' in APP,
    'system command center used': 'MPRemoteCommandCenter.shared()' in APP,
    'toggle command registered': 'togglePlayPauseCommand.addTarget' in APP,
    'play command registered': 'playCommand.addTarget' in APP,
    'pause command registered': 'pauseCommand.addTarget' in APP,
    'Bluetooth VOD setting defaults on': '@AppStorage("bluetoothVODPlayPauseEnabledV1") private var bluetoothVODPlayPauseEnabled: Bool = true' in APP,
    'main Settings exposes toggle': 'Text("Bluetooth Media Controls")' in APP and 'focus: .bluetoothVODPlayPauseToggle' in APP,
    'in-player Playback Settings exposes toggle': 'Bluetooth Media Play/Pause: On' in APP and '.bluetoothVODPlayPauseToggle' in APP,
    'VOD session claims media commands': 'claimVODSession(playbackPresentationID)' in APP,
    'VOD session releases media commands': 'releaseVODSession(playbackPresentationID)' in APP,
    'Bluetooth command scoped away from Live TV': 'guard !isLivePlayback,' in APP and 'debridBluetoothVODMediaCommand' in APP,
    'external play only plays when paused': 'case .play:\n                if !isPlaying { handlePlayerPlayPausePress() }' in APP,
    'external pause only pauses when playing': 'case .pause:\n                if isPlaying { handlePlayerPlayPausePress() }' in APP,
    'duplicate delivery suppression exists': 'shouldSuppressSwiftUIPlayPause()' in APP and 'lastExternalCommandAt' in APP and 'lastSwiftUIPlayPauseAt' in APP,
    'setting included in backup allowlist': '"bluetoothVODPlayPauseEnabledV1"' in SEC,
    'marketing version 1.0.814': 'MARKETING_VERSION: 1.0.814' in PROJECT,
    'build 814': 'CURRENT_PROJECT_VERSION: 814' in PROJECT,
    'app release vBRDC111': '<string>vBRDC111</string>' in PLIST,
    'topshelf release vBRDC111': '<string>vBRDC111</string>' in TOP,
}

for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ' | ' + name)

failed = [name for name, ok in checks.items() if not ok]
print(f'RESULT {len(checks)-len(failed)}/{len(checks)}')
if failed:
    raise SystemExit('Failed: ' + ', '.join(failed))
