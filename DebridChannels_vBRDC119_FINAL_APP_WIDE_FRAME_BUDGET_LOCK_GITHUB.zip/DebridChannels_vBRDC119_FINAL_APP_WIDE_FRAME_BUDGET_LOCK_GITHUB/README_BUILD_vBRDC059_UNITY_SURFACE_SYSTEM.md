# Debrid Channels vBRDC059 — Code Name UNITY / Unified Surface System

- Release ID: **vBRDC059**
- Marketing version: **1.0.762**
- Apple build: **762**
- Code name: **UNITY**
- Backend: **v692 unchanged**
- Fresh base: packaged **vBRDC058 only**

## Product intent

UNITY formalizes the interaction model Debrid Channels has been evolving toward: Live TV is the persistent root canvas and connected browsing modes are branches of that same system rather than unrelated destination screens.

For this build, the connected branch contract covers:

- Live TV — root surface
- Home — catalog branch
- Movies — catalog branch
- Shows — catalog branch
- Sports — sports branch

Search, Favorites, Settings, Membership, and full-screen playback keep their existing dedicated lifecycle/resource rules. They are not broadened into the shared root in this build.

## Physical-device problem addressed

The normal Live TV grid backgrounds already felt unified because Home/Movies/Shows were rendered over the same mounted `LiveTVScreen()`. Pressing Back simply removed the catalog layer and naturally exposed the grid underneath.

Artwork 4 / Hero 2 broke that contract. At the root level it was special-cased to replace `LiveTVScreen()` with `StaticAppBackground()` while the catalog was open. That meant theme selection changed navigation ownership and forced a scene-like handoff back to Live TV.

Artwork-heavy variants could also rely on implicit transition behavior, making the visual handoff less deterministic than the non-artwork themes.

## vBRDC059 correction

### 1. New `UnitySurfaceSystem`

`Sources/UnitySurfaceSystem.swift` now defines the presentation roles and branch rules in one place:

- `liveRoot`
- `catalogBranch`
- `sportsBranch`
- `dedicatedSurface`

It owns the catalog/quick-panel branch checks and the connected Back destination. Theme names are deliberately absent from this system: a theme is presentation only and cannot decide which root surface exists.

### 2. Every catalog theme keeps the same Live TV root

Home/Movies/Shows now always keep the real `LiveTVScreen()` mounted beneath the catalog branch, including:

- Classic Dark
- Channels Glass
- Frosted Guide
- Pure Black
- Midnight Blue
- Neon Edge
- Carbon OLED
- Artwork
- Artwork 2
- Artwork 3 Hero
- Artwork 4 Hero 2
- Artwork 5 Floating

The Artwork 4 / Hero 2 `StaticAppBackground()` root replacement is removed.

### 3. One Unity branch transition

The catalog overlay now has an explicit opacity transition. Artwork remains a transient visual skin over the retained Live TV root, so Back dissolves the branch and reveals the already-mounted grid instead of presenting a hard scene replacement.

The existing 0.22-second Back animation and catalog focus ownership are retained.

### 4. About screen identifies the architecture

The app bundle now includes:

- `DebridChannelsCodeName = UNITY`

About Debrid Channels displays **Code Name UNITY** and describes the single-tree viewing model directly.

## Preserved behavior

This is intentionally scoped to navigation/surface continuity.

Unchanged:

- backend v692
- TorBox/Voyager/DoH behavior from vBRDC058
- playback engine and KSPlayer patch path
- Skip Intro / Up Next playback code
- Live TV playback/Quick Guide behavior
- catalog source/provider logic
- artwork URL resolution and retained-frame high-resolution swap
- Sports branch behavior
- Search location/ownership behavior
- Favorites dedicated details behavior
- settings, membership, and entitlement behavior

## Required physical Apple TV tests

For **each Live TV Grid Background** theme:

1. Start on Live TV and focus a recognizable channel/card.
2. Open Home, move several catalog cards, then press Back.
3. Confirm the catalog dissolves directly to the same Live TV grid without a static-wall flash or scene rebuild feeling.
4. Repeat for Movies and Shows.
5. Confirm Live TV focus/grid state remains stable after the branch collapses.
6. Repeat the Home/Movies/Shows cycle several times to look for delayed focus theft or accumulated hitching.
7. Open Sports and return to Live TV; verify the existing shared-root behavior is unchanged.
8. Open a VOD title and playback to confirm this build did not retain the heavy Live TV tree during full-screen playback.

## Validation authority

GitHub Actions/Xcode remains the authoritative Apple-platform compile. Local release validation for this package checks Swift parsing, version/plist parity, Unity surface contracts, and preservation of vBRDC058 playback/provider files outside the intended changes.
