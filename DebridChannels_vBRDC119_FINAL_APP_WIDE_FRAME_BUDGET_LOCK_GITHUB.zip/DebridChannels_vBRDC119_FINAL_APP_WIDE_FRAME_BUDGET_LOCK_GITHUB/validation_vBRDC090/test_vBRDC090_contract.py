from pathlib import Path
import hashlib
import plistlib
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
REMOTE = (ROOT / 'Sources/RemoteImageFit.swift').read_text()
COORD = (ROOT / 'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []

def ck(name, cond):
    checks.append((name, bool(cond)))

def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)

def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()

def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]

app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC090', app_plist.get('DebridChannelsReleaseID') == 'vBRDC090' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC090')
ck('marketing version 1.0.793', app_plist.get('CFBundleShortVersionString') == '1.0.793' and top_plist.get('CFBundleShortVersionString') == '1.0.793')
ck('build version 793', app_plist.get('CFBundleVersion') == '793' and top_plist.get('CFBundleVersion') == '793')
ck('project marketing 1.0.793', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.793')
ck('project build 793', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '793')

# Global invalidation isolation.
status_decl = section(STORE, '@MainActor\nfinal class CatalogStore', '@Published var addonIdentities')
ck('operational CatalogStore status is not Published', 'var status: String = "Loading catalogs…"' in status_decl and '@Published var status' not in status_decl)
ck('status rationale documents no rendered direct dependency', 'operational/debug status is intentionally NOT @Published' in STORE)

# Frozen inactive surfaces.
frozen = section(APP, 'private struct FrozenLiveTVBackdrop', 'struct LiveTVScreen: View')
root_surface = section(APP, 'if membershipLocked && store.selectedTab != .membership', '// v535: keep the top menu visible')
ck('frozen Live TV donor exists', 'private struct FrozenLiveTVBackdrop: View' in APP)
ck('frozen donor has no CatalogStore environment object', '@EnvironmentObject var store: CatalogStore' not in frozen)
ck('frozen donor uses cached real channels', 'LiveTVSourceModel.cachedRealAmbientChannels()' in frozen)
ck('frozen donor uses last selected channel corridor', '@AppStorage("liveTVLastSelectedChannelID")' in frozen and 'selectedRowStart' in frozen)
ck('frozen donor uses existing Live TV tile content', 'LiveTVGridTileContent(' in frozen)
ck('catalog branches mount frozen donor', 'if catalogOverlayActive' in root_surface and 'FrozenLiveTVBackdrop()' in root_surface)
ck('Sports mounts frozen donor', 'else if store.selectedTab == .sports' in root_surface and root_surface.count('FrozenLiveTVBackdrop()') >= 2)
ck('only one real LiveTVScreen root mount remains', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)

# Motion runtime / navigation burst.
ck('coordinator owns navigation burst state', 'navigationBurstActive' in COORD and 'navigationBurstGeneration' in COORD)
ck('navigation registration extends settle deadline', 'func registerNavigationActivity' in COORD and 'navigationSettleWorkItem?.cancel()' in COORD)
ck('navigation does not bump on each repeat', 'if !navigationBurstActive' in COORD and 'navigationBurstActive = true\n            bump()' in COORD)
ck('navigation frame budget blocks ambient lanes', all(token in COORD for token in ['.dynamicWallpaper', '.catalogPulse', '.catalogPreview', '.tickerMotion']))
ck('navigation retains focus lanes', all(token in COORD for token in ['.catalogFocusArrival', '.catalogRowMotion', '.liveTVMotion', '.guideMotion', '.sportsMotion']))
ck('coordinator exposes noncritical publication defer gate', 'var shouldDeferNoncriticalVisualPublication: Bool' in COORD)
ck('catalog registers navigation activity', 'unityAnimations.registerNavigationActivity(source: "catalog")' in APP)
ck('top menu registers navigation activity', 'unityAnimations.registerNavigationActivity(source: "top-menu")' in APP)
ck('Search registers navigation activity', 'unityAnimations.registerNavigationActivity(source: "search-results")' in APP)
ck('Live TV registers navigation activity', 'registerNavigationActivity(source: "live-tv")' in APP)
ck('Guide registers navigation activity', 'registerNavigationActivity(source: "live-guide")' in APP)

# Focus arrival sequencing.
focus_card = section(APP, 'struct FixedSlotFocusedCatalogCard: View', 'private struct CatalogRowMotionDebugOverlay')
ck('intermediate focus arrival bounce is deferred during burst', 'if unityAnimations.navigationBurstActive' in focus_card and 'DispatchQueue.main.asyncAfter(deadline: .now() + 0.20)' in focus_card)
ck('settled focus preserves Search style spring', 'startSearchStyleFocusArrivalSpring' in focus_card and 'spring(response: 0.34, dampingFraction: 0.62, blendDuration: 0.04)' in focus_card)
ck('catalog Pulse still uses coordinator permit', 'unityAnimations.allows(.catalogPulse)' in focus_card)
ck('catalog preview still uses coordinator permit', 'unityAnimations.allows(.catalogPreview)' in focus_card)

# Wallpaper mount vs motion ownership.
live_wallpaper = section(APP, 'private var wallpaperMotionPausedForNavigation', 'private func acceptSingleDpadStep')
ck('wallpaper motion pauses from coordinator without unmount gate', '!unityAnimations.allows(.dynamicWallpaper)' in live_wallpaper)
ck('wallpaper mount ownership no longer includes dynamicWallpaper permit', 'private var liveWallpaperOwnsRenderBudget' in live_wallpaper and 'dynamicMainGridWallpaperEnabled' in live_wallpaper and '&& unityAnimations.allows(.dynamicWallpaper)' not in live_wallpaper)
ck('wallpaper surface receives pause flag', 'paused: wallpaperMotionPausedForNavigation' in APP)

# Image publication isolation.
ck('Premium image loader owns deferred publication task', 'deferredPublicationTask' in REMOTE)
ck('Premium image decode uses frame-budget defer gate', 'UnityAnimationCoordinator.shared.shouldDeferNoncriticalVisualPublication' in REMOTE)
ck('Premium image stale completion checks current key', 'self.currentKey == key' in REMOTE)
live_loader = section(APP, 'private final class LiveTVBoundedArtworkLoader', 'private struct LiveTVQuickGuideContainedArtworkFrame')
ck('Live TV artwork publication also waits for frame budget', 'shouldDeferNoncriticalVisualPublication' in live_loader)
ck('Live TV stale artwork identity remains guarded', 'requestedCacheKey == key' in live_loader)

# Live TV runtime cleanup.
ck('obsolete wallpaper reconciliation function removed', 'reconcileWallpaperRenderOwnership' not in APP)
live_art_ids = section(APP, 'private func liveTVArtworkLoadIDs', 'private func scheduleGuideHintAutoHide')
ck('Live TV artwork corridor only runs on live or sports owner', 'store.selectedTab == .live || store.selectedTab == .sports' in live_art_ids and 'store.selectedTab == .home' not in live_art_ids)
live_tile = section(APP, 'private func liveTile(channel:', 'private func suppressChannelTap')
ck('Live TV focus owns one scale animation transaction', live_tile.count('.scaleEffect(') == 1 and live_tile.count('.animation(') == 1)
ck('Live TV focused final scale preserves previous composite visual', '1.154025' in live_tile and '1.081575' in live_tile)
ck('dead artwork3 root state removed', 'artwork3CatalogOverlayActive' not in APP)

# Ticker lifecycle and repeat-forever cleanup.
movies_ticker = section(APP, 'struct MoviesShowsReleaseTickerCard: View', 'struct GlobalSportsTickerOverlay')
compact_ticker = section(APP, 'struct CompactSportsAlertShell: View', 'struct SportsScoreTicker')
premium_ticker = section(APP, 'struct PremiumSportsTickerShell: View', 'struct SportsTeamFocusRail')
ck('Movies Shows ticker uses cancellable task loop', '.task(id:' in movies_ticker and 'DispatchQueue.main.asyncAfter' not in movies_ticker)
ck('Movies Shows ticker yields to ticker motion permit', 'unityAnimations.allows(.tickerMotion)' in movies_ticker)
ck('compact Sports ticker uses cancellable task loop', '.task(id:' in compact_ticker and 'DispatchQueue.main.asyncAfter' not in compact_ticker)
ck('compact Sports ticker yields to ticker motion permit', 'unityAnimations.allows(.tickerMotion)' in compact_ticker)
ck('Sports crawl uses pausable TimelineView', 'TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: !unityAnimations.allows(.tickerMotion)))' in premium_ticker)
ck('Sports crawl no longer uses repeatForever', '.repeatForever(' not in premium_ticker)
ck('global ticker visibility no longer unmounts only because navigation motion paused', '&& unityAnimations.allows(.tickerMotion)' not in section(APP, 'private var globalTickerOverlaysAllowed', 'private func synchronizeUnityAnimationContext'))

# Dead HeroLogo pulse removal (all v089 call sites were pulse:false).
hero = section(APP, 'struct HeroLogoText: View', 'struct SportsLiveEvent')
ck('HeroLogo dead repeat-forever pulse removed', '@State private var glow' not in hero and 'repeatForever' not in hero and 'var pulse:' not in hero)

# Prior visual / behavior locks.
ck('Live TV program art fallback still records failed URLs', '@Published private(set) var failedURLs: Set<URL> = []' in live_loader)
live_grid_art = section(APP, 'private struct LiveTVGridTileArtwork: View', 'private struct LiveTVGridTileContent')
program_pos = live_grid_art.find('return .program(url)')
icon_pos = live_grid_art.find('return .channelIcon(url)')
provider_pos = live_grid_art.find('return .provider(url)')
ck('Live TV fallback remains Gracenote then channel icon then provider', -1 not in (program_pos, icon_pos, provider_pos) and program_pos < icon_pos < provider_pos)
ck('Favorites identity isolation remains', 'quickPanelRestoreSection != "favoritesCatalog"' in APP)
ck('Connected popup artwork remains catalog-only', 'connectorOrigin == .catalog' in APP)
ck('automatic resume KS play assertion remains', 'ksPlayAssertionSerial &+= 1' in APP)

# v090 must not mutate v089 provider/playback implementation while doing performance work.
DONOR_HASHES = {
    'Sources/NuvioPluginClient.swift': '0495f210b9d2ca0b316f0124e1bb4b584147a303c3cb193f48f5cee4fa7259e5',
    'Sources/BackupStreamingClient.swift': '032b7ee7663491e93057d7e3702ba7bc55674a8cb10b9336093e7a0399dd4a49',
    'Sources/MediaFlowProxyRouter.swift': '310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift': 'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'BackendBackupStreamingRuntime/backup_streaming_runtime.py': 'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
    'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py': '340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
}
for rel, expected in DONOR_HASHES.items():
    ck('v089 donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is declared in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
if failed:
    print('Failed: ' + ', '.join(failed))
sys.exit(1 if failed else 0)
