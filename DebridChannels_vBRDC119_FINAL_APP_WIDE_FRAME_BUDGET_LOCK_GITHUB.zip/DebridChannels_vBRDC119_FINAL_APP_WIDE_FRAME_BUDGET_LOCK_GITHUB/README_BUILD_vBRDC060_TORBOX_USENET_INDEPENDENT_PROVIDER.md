# Debrid Channels vBRDC060 — UNITY / TorBox Usenet Independent Provider

- Release ID: **vBRDC060**
- Marketing version: **1.0.763**
- Apple build: **763**
- Code Name: **UNITY**
- Built only from packaged **vBRDC059**
- App backend target: **v693** (v692 + additive TorBox Usenet Search relay)

## Goal

This build makes **native TorBox Usenet a real first-class Source Intelligence provider that is independent of Torrentio**.

The global TorBox API key belongs to Debrid Channels, not Torrentio. Torrentio can be added or removed without deleting, disabling, migrating, or changing that key. The same saved TorBox key continues to authenticate native Usenet processing and playback.

## App changes

### 1. Torrentio is truly removable

Streaming Catalogs now exposes an explicit:

- **Add Torrentio Provider (optional)**
- **Remove Torrentio Provider**

Removing Torrentio only changes `managedTorrentioEnabled`. It does not clear `torBoxApiKey` or `realDebridApiKey`. Any currently displayed Torrentio rows/statuses are removed immediately and Source Intelligence returns to **All Providers** if Torrentio had been the selected filter.

### 2. Native TorBox Usenet does not depend on Torrentio

`CatalogStore` starts the TorBox Usenet discovery lane directly from `DebridCredentialBridge.effectiveTorBoxAPIKey`. It does not read `managedTorrentioEnabled`, generated Torrentio manifests, or `ManagedAddonBridge`.

The discovery order is now:

1. Apple TV → TorBox Voyager Search directly.
2. If direct discovery fails, Apple TV → Debrid Channels backend v693 → TorBox Voyager Search.
3. If broad discovery is still unavailable, match already-owned TorBox Usenet jobs through the Main API (`/usenet/mylist`).

The final fallback matters because an owned matching Usenet item can still appear and play even when Voyager Search is unavailable.

### 3. Usenet can no longer silently disappear after a successful connection check

vBRDC059 could report **TorBox API + Usenet connected** while swallowing a Voyager discovery failure and omitting the provider entirely.

vBRDC060 separates those concepts:

- Settings: **API + Usenet processing connected** means the TorBox Main API and Usenet processing/list endpoint are healthy.
- Find Links: release discovery is tested separately.
- If discovery cannot be reached and there is no matching owned-library item, Source Intelligence shows a visible **TorBox Usenet** provider failure instead of pretending the provider does not exist.

### 4. Cached and uncached playback path remains native

Selecting a TorBox Usenet result stays on the TorBox Main API path:

- reuse an owned download when available;
- otherwise submit the result's NZB handoff URL with `createusenetdownload`;
- poll the selected Usenet job until a playable video is ready;
- choose the preferred video file;
- request the final TorBox CDN/download URL through `requestdl`;
- hand that URL to the existing Debrid Channels playback system.

An owned-library result carries the authoritative TorBox Usenet download ID so it does not require Voyager to expose an NZB URL again.

## Backend v693 drop-in

`BackendTorBoxUsenetSearchRuntime/` contains a small search-only relay:

`POST /api/torbox/usenet/search`

The user's TorBox key is sent in the request-scoped `X-TorBox-Token` header, forwarded only to the fixed `https://search-api.torbox.app` host as a Bearer token, and is never deliberately persisted, cached, logged, put in a URL, or returned in JSON.

The relay does **not** proxy playback. It exists only as a stable alternate network path for Voyager discovery when the Apple TV device path hits DNS, TLS, routing, or other transport-specific failures.

### Deployment limitation

The relay does not bypass TorBox authorization and still forwards the user's TorBox bearer credential only to TorBox Search. Current TorBox behavior is API-key-authorized; the relay is an alternate transport path, not an authorization workaround. If a particular Search API route still rejects or fails, vBRDC060 reports that discovery failure clearly and can still surface matching Usenet downloads already owned by the user's TorBox account through the Main API.

## UNITY scope

The vBRDC059 Unity Surface System is preserved. This build does not change Live TV root ownership, catalog branch presentation, playback focus architecture, Skip Intro, KSPlayer behavior, or the Unity Content Fabric backlog.

## Physical Apple TV test matrix

1. Enter a TorBox API key and verify connected services.
   - Expected: **API + Usenet processing connected**.
2. Add Torrentio and confirm Torrentio links can appear.
3. Remove Torrentio Provider.
   - Expected: Torrentio disappears immediately.
   - Expected: TorBox API key remains in the field and Keychain/UserDefaults bridge remains valid.
4. Run Find Links with Torrentio removed.
   - Expected: TorBox Usenet still runs independently.
   - If Voyager/relay access is available: Usenet releases appear with cached/owned state.
   - If Voyager is unavailable: matching owned Usenet library items can still appear; otherwise a visible TorBox Usenet discovery failure is shown.
5. Select a cached/owned Usenet result.
   - Expected: final TorBox URL resolves and playback begins.
6. Select an uncached result.
   - Expected: TorBox creates/processes/unpacks the job and playback begins once the video becomes available.
7. Remove the TorBox API key.
   - Expected: native TorBox Usenet provider is not started and no Usenet placeholder is injected.

## Validation

The package includes `validation_vBRDC060/test_vBRDC060_contract.py`, backend relay unit tests, a current TorBox Search-schema fixture, and owned/uncached Main-API playback fixtures. GitHub Actions/Xcode remains authoritative for the complete tvOS build and physical Apple TV remains authoritative for end-to-end service behavior.
