# vBRDC110 — Live TV Bootstrap Commit Recovery

Marketing version: **1.0.813**  
Apple build: **813**  
Release ID: **vBRDC110**

Built only from packaged **vBRDC109**.

## Root cause

The MediaFlow Proxy router did not regress: `Sources/MediaFlowProxyRouter.swift` is byte-for-byte identical to the known-working vBRDC101 donor and vBRDC109.

The regression was introduced in vBRDC102's frame-budget work. Live TV provider/network work could successfully finish, then hit a bounded `UnityFrameRuntime.waitUntilPermitted(.interactiveMetadata, maxWait: ...)` guard. If the UI stayed busy past the timeout, the code returned and discarded already-fetched channel/Gracenote/XMLTV/Xtream results.

That explains a remote Apple TV showing Movies/Shows correctly while Live TV remained on demo/empty channels despite the provider request itself succeeding.

## Fix

Frame arbitration is now **non-destructive** for Live TV source publication:

- Main Live TV channel + guide bootstrap may defer for up to 2.0 seconds, but a timeout no longer discards the successful result.
- Final channel/guide publication may defer for 1.2 seconds, then commits unless the task is genuinely cancelled, playback owns the surface, or a newer refresh generation superseded it.
- Deferred Xtream native EPG publication uses the same durable-result rule.
- Visible Xtream channel batches may defer briefly but cannot be abandoned solely because the frame lane remained busy.
- Native short-EPG batches are not discarded due to UI timing.

The legitimate safety guards remain: stale generation, task cancellation, and VOD-exclusive playback can still prevent obsolete work from publishing.

## Explicit non-changes / regression locks

- MediaFlow Proxy router: unchanged from vBRDC109 and hash-identical to vBRDC101 known-good donor.
- vBRDC109 single-owner catalog open/close transition retained.
- vBRDC108 real channel logo fallback retained.
- vBRDC107 persistent focused preview ownership retained.
- vBRDC106 visible VOD Cast/Production rotation retained.
- vBRDC105 Live TV 3s dwell / 15s preview retained.
- vBRDC104 persistent catalog shell retained.
- vBRDC103 persistent row scrolling and all existing row-motion visuals retained.
- Playback/resume/provider backend code unchanged.

## Validation

- vBRDC110 targeted regression contract: **24/24**
- Non-validation Swift parse: **67/67**
- Version/project checks: **8/8**
- Backend regression suite: **36 passed + 2 subtests**
- Donor scope: exactly **4 existing files changed**
