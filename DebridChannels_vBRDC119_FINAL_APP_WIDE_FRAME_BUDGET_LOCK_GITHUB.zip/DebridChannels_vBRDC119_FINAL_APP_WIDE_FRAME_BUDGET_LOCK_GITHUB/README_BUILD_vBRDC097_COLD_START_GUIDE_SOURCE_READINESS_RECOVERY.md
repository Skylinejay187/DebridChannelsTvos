# Debrid Channels vBRDC097 — Cold-Start Guide + Source Readiness Recovery

Release: **vBRDC097**  
Marketing version: **1.0.800**  
Apple build: **800**  
Donor: packaged **vBRDC096** only.

## Physical-test failures addressed

### 1. Gracenote/program artwork did not appear on a cold launch until the Live TV grid was scrolled

The failure had three cooperating causes:

1. The persistent UNITY Live TV root could restore a real channel lineup before a current guide was hydrated, but hidden non-Live surfaces intentionally owned zero recurring Live TV network work. A cold launch could therefore sit on a cached lineup without immediately obtaining current guide/Gracenote rows.
2. Already-mounted LazyVGrid artwork owners had no explicit guide-publication generation signal. A guide refresh could update the model without forcing an existing card loader to re-evaluate until scrolling rematerialized the card.
3. Most importantly, `LiveTVBoundedArtworkLoader` treated any failed artwork fetch as a broken URL for the lifetime of that mounted tile. During tvOS cold network bring-up, a transient DNS/TLS/connectivity miss could enter `failedURLs`; scrolling created a new StateObject with an empty failure set, which is why scrolling appeared to "fix" Gracenote.

vBRDC097 fixes all three layers:

- a **single delayed one-shot cold-start guide hydration** is allowed when a real Live TV source is configured and no guide exists yet;
- entering Live TV cancels that hidden bridge immediately, restoring Live TV as the sole interactive network owner;
- successful guide publication increments an **artwork refresh generation** consumed by already-mounted tiles;
- authoritative guide refresh clears stale artwork failures so scrolling is never required to retry them;
- Live TV guide and image sessions use `waitsForConnectivity`;
- artwork has one bounded transient retry before a URL is treated as failed;
- XMLTV/Gracenote provider fetches have one bounded transient retry;
- the established **Gracenote → channel icon → provider fallback → generated card** order remains unchanged;
- covered UNITY surfaces continue preserving the exact last-decoded Live TV pixels without background artwork churn.

This is deliberately **not** a recurring hidden Live TV refresh system. It is a cold-start bridge only for a configured real source with a missing guide.

### 2. First-install Find Links sometimes returned no links until the app was force-quit/reopened

The restart symptom pointed at first-generation networking rather than a specific provider. The first Source Intelligence wave could run while tvOS was still settling connectivity/DNS/TLS and while first-launch provider state was becoming ready. Existing UI-level retries could reuse the same network generation, while force-quitting naturally created fresh URLSession state.

vBRDC097 moves that recovery inside the app:

- Source Intelligence's session now uses `waitsForConnectivity` with bounded host concurrency and slightly more realistic first-connection timeouts;
- if the **first process-wide source search** returns zero links after an actual configured lane was attempted, the app performs exactly **one** internal recovery wave:
  1. retire/cancel work on the first Source Intelligence session;
  2. create a fresh connectivity-aware session;
  3. wait 850 ms for network/provider readiness;
  4. re-read settings and run the complete provider fan-out once more;
- the retry is disabled recursively and can never loop;
- once any source search succeeds, the cold-start recovery path is no longer eligible;
- the TMDB identity lookup used by In-S now uses the same connectivity-aware Source Intelligence session rather than `URLSession.shared`;
- In-S/Nuvio backend requests use `waitsForConnectivity`;
- optional FebBox backend requests use `waitsForConnectivity`.

A legitimate zero-result provider search still ends normally after the bounded recovery. Provider-specific behavior and ranking are not rewritten in this build.

## UNITY / motion / playback locks preserved

vBRDC097 preserves the accepted recent architecture:

- exactly one physical persistent `LiveTVScreen` under every non-playback app surface;
- no synthetic/frozen Live TV donor tree;
- natural Home/Movies/Shows catalog presentation and reverse UNITY transition;
- 24-card covered Live TV corridor / 96-card interactive corridor;
- Pulse Glow remains slow and geometry-free;
- row animation frame-budget and post-navigation recovery remain;
- Media Information focus/detail handoff remains;
- Connected Popup 2048 artwork prewarm remains;
- Dynamic Wallpaper phase-preserving navigation yield remains;
- Sports/Favorites artwork cache isolation remains;
- playback/resume, Source Intelligence ranking, TorBox Usenet, MediaFlow and Production metadata donor files are untouched.

## Intended existing-file scope

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/CatalogStore.swift`
3. `Sources/NuvioPluginClient.swift`
4. `Sources/BackupStreamingClient.swift`
5. `Sources/Info.plist`
6. `TopShelfExtension/Info.plist`
7. `project.yml`

No other donor file is modified.

## Validation

- vBRDC097 contract: **72/72 passed**
- Swift syntax parse: **64/64 passed**
- backend pytest: **36 passed, 2 subtests passed**
- plist/project alignment: **8/8 passed**
- donor scope: **7 intended existing-file changes, 0 unexpected**
- `plutil -lint`: app + Top Shelf **OK**
- GitHub Actions/Xcode remains the authoritative Apple SDK compile.
- Physical Apple TV remains authoritative for cold-start network timing and Gracenote presentation.
