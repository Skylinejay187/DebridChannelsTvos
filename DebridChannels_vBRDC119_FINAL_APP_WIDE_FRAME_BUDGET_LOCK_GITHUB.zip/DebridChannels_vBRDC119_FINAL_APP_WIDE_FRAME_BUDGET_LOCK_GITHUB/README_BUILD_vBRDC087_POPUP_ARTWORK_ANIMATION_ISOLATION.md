# Debrid Channels vBRDC087 — Popup Artwork + Animation Isolation

**Marketing version:** 1.0.790  
**Apple build:** 790  
**Release ID:** vBRDC087  
**Donor:** packaged vBRDC086 only

## Physical-test regressions targeted

1. With **Connected Popup Background Artwork** enabled, a Search-origin Media Information card could show the selected title artwork twice: Search already rendered a full-screen cinematic selected-title backdrop, then the optional connected-popup layer decoded and composited the same title again inside the centered glass card.
2. With **Focused Card Pulse** and **Focused Card Previews** enabled, opening Media Information and then running **Find Links / Source Intelligence** could make the underlying focused-card Pulse visibly stutter/glitch while the link panel inserted and published incremental state.

## Root cause audit

### Duplicate artwork ownership

Media Information has three presentation origins: `catalog`, `search`, and `favorites`.

- Search already owns a full-screen selected-title cinematic backdrop in `popupDimLayer`.
- Favorites keeps its selected Favorite backdrop mounted in `GlobalFavoritesScreen` behind the local popup.
- The optional `connectedMediaPopupArtworkEnabled` layer in `popupPanelBackground` did not check origin, so enabling it added a second selected-title artwork owner to Search and Favorites.

The setting is now explicitly scoped to the surface it was designed for: Home/Movies/Shows catalog Media Information.

### Pulse/Source Intelligence compositor competition

The vBRDC080 UNITY rule intentionally allowed the catalog Pulse to remain active beneath Media Information. Physical testing now shows that the perpetual scale transform can compete with the AVPlayer-backed focused preview while the embedded Source Intelligence panel is inserting/updating. This is especially visible when both Pulse and Focused Card Previews are enabled.

vBRDC087 separates the two behaviors:

- The exact muted focused-card preview may remain mounted under catalog Media Information without being restarted.
- The transform-only Pulse yields immediately when any Media Information detail owns the overlay compositor.
- The Pulse resumes only after Details closes.
- Source opening, trailer, and full playback retain the stronger existing exclusive rules.

## vBRDC087 corrections

### 1. Single artwork owner per Media Information origin

A new `connectedPopupArtworkLayerAllowed` invariant requires both:

- Connected Popup Background Artwork is enabled; and
- `connectorOrigin == .catalog`.

Search and Favorites never render the optional popup artwork layer, eliminating the duplicate decode/composite path while preserving each surface's existing selected-title backdrop and the normal poster/logo inside the information card.

### 2. Same-frame Pulse hard lock

`GridOSFixedSlotCatalogRail.coordinatedPulseAnimation` now requires `store.selectedDetail == nil` in addition to the saved Pulse setting and UNITY permit. This stops the Pulse in the same render frame that Media Information takes ownership, before any root-level coordinator publication can lag behind.

### 3. Process-wide UNITY rule updated

`UnityAnimationCoordinator` now treats `catalogPulse` and `catalogPreview` separately:

- `catalogPreview` can remain mounted during catalog-origin Media Information.
- `catalogPulse` is denied whenever `detailActive == true`.

The existing `updateSlowFocusedPulse` reset uses an animation-disabled transaction, so yielding does not create a new scale animation or geometry bounce.

### 4. Settings wording now documents the contract

Connected Popup Background Artwork explicitly states that Search and Favorites already own a selected-title backdrop and therefore never stack a second popup artwork layer.

## Regression locks retained

- vBRDC086 Favorites presentation identity cannot leak into Home/Movies/Shows.
- vBRDC085 Find Links resume/autoplay still emits an explicit KSPlayer Play assertion after resume seek confirmation.
- vBRDC085 Production metadata remains first-frame gated, background priority, and independent of Play/Pause.
- CatalogStore, PlaybackResumeCache, Production service, Source Intelligence manager, TorBox/Usenet, UNITY surface lifecycle, catalog visual system, Universal codec bridge, and PlaybackKit sources are donor-locked unchanged from packaged vBRDC086.

## Expected physical behavior

- Search → select result → Media Information with Connected Popup Background Artwork **On**: one cinematic selected-title backdrop only; no second full artwork image inside the popup glass.
- Favorites → Media Information with the setting **On**: Favorites keeps its single selected-title backdrop; no second popup artwork layer.
- Home/Movies/Shows → Media Information with the setting **On**: the intended connected-popup artwork remains available.
- With Pulse + Focused Card Previews **On**, open Media Information and press Find Links: the underlying card preview may continue, but its scale Pulse is frozen while Details/Source Intelligence is active, preventing the visible Pulse stutter/compositor fight.
- Close Media Information: Pulse resumes normally on the focused catalog card.

GitHub Actions/Xcode remains the authoritative Apple SDK compile; physical Apple TV testing remains authoritative for focus/compositor timing.
