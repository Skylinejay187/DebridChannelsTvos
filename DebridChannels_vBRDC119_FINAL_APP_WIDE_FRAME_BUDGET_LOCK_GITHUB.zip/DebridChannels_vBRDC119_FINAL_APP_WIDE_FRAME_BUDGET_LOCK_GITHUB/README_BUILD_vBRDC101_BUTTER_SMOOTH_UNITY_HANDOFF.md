# Debrid Channels vBRDC101 — Butter Smooth UNITY Handoff

- Release ID: `vBRDC101`
- Marketing version: `1.0.804`
- Apple build: `804`
- Donor: packaged `vBRDC100_SEAMLESS_VOD_ROTATION_HANDOFF`

## Purpose

This build corrects a system-wide visual smoothness regression around UNITY catalog presentation, with special focus on Artwork 4 / Hero 2. The regression was not caused by one theme animation. Critical artwork publication was being deferred for nearly the entire cross-surface handoff, then vBRDC099's emergency blank-artwork recovery sweep was being released on the same frame the transition settled. URL changes could also remount focused artwork owners despite retained-frame mode.

## Changes

1. **Critical artwork can publish during an ordinary UNITY surface handoff.** Hero backdrops, depth art, focused cards and themed logos bypass only the surface-handoff publication block. They still yield during rapid navigation, post-navigation recovery, source opening, trailers and full-screen playback.
2. **Normal theme navigation no longer runs the emergency vBRDC099 rehydration sweep.** That sweep remains available for real playback-return, scene-resume and catalog-completeness recovery.
3. **Artwork 4 / Hero 2 image ownership is stable across quality upgrades.** Focused artwork and logo `.id` values are keyed to media identity rather than the changing URL, so `preservePreviousOnURLChange` can actually retain the prior decoded frame until the upgraded image is ready.
4. **Catalog entry gets a short invisible preflight and compositor-first easing.** The branch binds its resident rows/image owners **and its large focused-card state** before becoming visible, so Hero 2 no longer promotes the big poster partway through the fade/slide. Ambient work stays isolated slightly beyond both the open and close final frames.
5. **Full-screen catalog artwork is capped at a true 4K decode budget (`3840`).** Oversized 6K/8K source files no longer consume decode/cache/GPU memory for pixels a 4K Apple TV surface cannot display. The depth pass uses the same bucket so it can reuse the decoded image.
6. **vBRDC100 VOD cast and Production & Ratings retained-frame transitions remain intact.**

## Intentionally unchanged

Playback/resume, provider resolution, TorBox/Usenet, Live TV tuning, Source Intelligence, VOD overlay layout, catalog content, dynamic wallpaper choices, and user appearance preferences are not redesigned by this build.
