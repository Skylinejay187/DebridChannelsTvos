# Debrid Channels vBRDC112 — Bluetooth VOD Compile Fix

- Marketing version: 1.0.815
- Apple build: 815
- Donor: packaged vBRDC111 only

## GitHub Actions failure analyzed
The vBRDC111 GitHub Actions log (`logs_90072399833.zip`) contains one blocking compiler error:

`DebridChannelsTVOSApp.swift:20724:25: error: the compiler is unable to type-check this expression in reasonable time`

The Bluetooth MediaPlayer API itself was accepted by Xcode. The failure occurred because the already-large `VODPlayerScreen.body` gained another inline `onReceive` closure and crossed Swift's type-check complexity threshold under the Release build.

## Corrective change
- Preserves the complete vBRDC111 Bluetooth VOD media-control feature.
- Extracts Bluetooth notification decoding/action logic into `handleBluetoothVODMediaCommand(_:)`.
- Splits the heavy VOD render tree into `playerVisualTree`, so Swift type-checks the visual tree separately from the lifecycle/input modifier chain.
- No visual, playback, Live TV, catalog, provider, Gracenote, wallpaper, or row-animation behavior was intentionally changed.

## Bluetooth feature retained
- System Play, Pause, and Toggle Play/Pause commands through `MPRemoteCommandCenter`.
- VOD-only session ownership.
- Main Settings and in-player Playback Settings toggles.
- Default On.
- Dedicated Pause cannot resume; dedicated Play cannot pause.
- Duplicate system/SwiftUI button delivery suppression retained.
- Live TV and non-VOD surfaces do not claim the VOD media-command bridge.

## Local validation
- vBRDC112 targeted contract: 22/22 PASS.
- Production `Sources/*.swift` syntax parse: 64/64 PASS.
- All Swift files in package syntax parse: 74/74 PASS.
- App plist: 1.0.815 / 815 / vBRDC112.
- Top Shelf plist: 1.0.815 / 815 / vBRDC112.

The GitHub Actions Xcode/tvOS build remains the authoritative full compile because the local Linux environment does not contain Apple's tvOS SDK.
