# Debrid Channels vBRDC092 — System Motion Handoff / Glow / Artwork Recovery

**Release ID:** vBRDC092  
**Marketing version:** 1.0.795  
**Apple build:** 795  
**Donor:** packaged vBRDC091 only

## Purpose

vBRDC092 is a focused tvOS motion/presentation corrective build. It keeps the vBRDC090/vBRDC091 frame-budget, wallpaper-phase, Sports/Favorites memory isolation, playback/resume, provider, Source Intelligence and Live TV behavior intact while removing four physical-device presentation defects reported after vBRDC091:

1. focused-card Pulse was no longer visually useful;
2. all catalog row transition presets appeared to make a second jump as the selected card settled;
3. Connected Popup Background Artwork could flash/reload when Media Information opened, especially with Artwork 3 Hero;
4. Back from Media Information could visibly snap to the originating card instead of handing focus back smoothly.

## Root findings

### Row transition settle jump

The selected card was not actually performing only the chosen catalog-row transition. `FixedSlotFocusedCatalogCard` also owned the older Search-style vertical arrival spring. A newly selected card could therefore finish the horizontal row motion and then begin a second `-18 -> 0` vertical spring. Because this was downstream of the shared rail, the artifact was visible with every row-transition preset.

vBRDC092 makes the selected row transition the sole horizontal-navigation transform. The Search-style arrival remains available for genuine non-navigation focus entry only, but it is never queued after a navigation burst or the post-navigation recovery phase.

A second timing issue was also corrected: the global navigation lane previously used one ~180 ms settle window even though catalog presets range from very short snaps to substantially longer springs. Every one of the 48 presets now has an explicit/conservative frame-budget settle window (Classic Spring included), and ambient systems remain frozen for one additional 90 ms recovery beat. This does not slow the selected transition; it prevents wallpaper, glow, preview, ticker and deferred image publication from waking on the transition's final frame.

### Focused-card Pulse -> Pulse Glow

The old breathing scale pulse is removed from the focused catalog card. The saved setting key is retained for compatibility, but its presentation is now a slow opacity-only accent glow around the existing focused-card silhouette. It uses no scale, width, height, offset or geometry mutation, so it cannot move connector measurements or fight row layout. The glow automatically yields during navigation, Details, source opening, playback and the existing UNITY exclusivity windows.

### Connected Popup Artwork flash

The popup contained an intentional delayed artwork-readiness gate that guaranteed an artwork-free first frame. In addition, the popup requested a different decode bucket than the focused card, and changing hydrated artwork URLs could recreate the image loader.

vBRDC092 removes the delayed gate, keeps the popup loader stable for a title, preserves the previous decoded frame across same-title URL upgrades, and adds decode-bucket reuse: a warm 1280 focused-card bitmap can be displayed immediately as the provisional popup frame while the 2048 popup decode finishes.

The exact 2048 popup bucket is also prewarmed only after the focused row has settled. That warmup is cancellable: the moment another Siri Remote navigation burst begins, any still-speculative 2048 network/decode job is cancelled unless a real visible loader has already subscribed. This prevents anti-flash preloading from becoming a new scrolling-performance regression.

### Media Information open/back handoff

`CatalogStore.openDetail` previously cleared `selectedDetail` for one run-loop before mounting the requested detail. That briefly reopened the underlying catalog focus graph and could produce a focus/artwork flash. Detail identity now publishes atomically.

Back previously removed Media Information synchronously. vBRDC092 first stages the exact originating catalog row/index FocusState behind the still-visible popup, reverses the existing connected-popup presentation, then removes the detail after that reverse transition. The final close does not send a second focus token when the handoff was already prepared. The originating card therefore exists at its resting focus state before it is revealed.

## Performance invariants retained

- one real reactive `LiveTVScreen` root;
- frozen/bounded Live TV donor behind catalog/Sports surfaces;
- wallpaper phase-preserving navigation yield;
- Sports/Favorites isolated transient artwork caches and exit cleanup;
- noncritical decoded image publication deferred during navigation;
- `CatalogStore.status` remains non-`@Published`;
- existing vBRDC085 resume/autoplay and Production corrections remain donor-locked;
- Favorites identity and Connected Popup single-owner rules remain intact.

## Provider scope

The In-S/ShowBox/FebBox runtime files are intentionally donor-locked to vBRDC091/vBRDC089 behavior in this UI/motion build. The local Nuvio-compatible provider-runtime redesign remains an isolated subsequent stage so provider changes cannot invalidate physical performance diagnosis of this candidate.

## Validation

The package contains `validation_vBRDC092/` with the release contract, Swift syntax parse log, backend suite log, plist/project validation, donor diff audit, package SHA-256 manifest/verification and ZIP integrity report.
