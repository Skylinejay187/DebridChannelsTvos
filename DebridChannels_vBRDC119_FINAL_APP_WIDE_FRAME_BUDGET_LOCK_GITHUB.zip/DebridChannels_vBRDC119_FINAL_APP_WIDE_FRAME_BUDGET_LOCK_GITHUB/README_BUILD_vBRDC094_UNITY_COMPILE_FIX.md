# Debrid Channels vBRDC094 — UNITY Compile Fix

- Release ID: `vBRDC094`
- Marketing version: `1.0.797`
- Apple build: `797`
- Donor: packaged `vBRDC093_UNITY_PERSISTENT_ROOT_TRANSITION_RECOVERY_GITHUB`

## Why this build exists

The GitHub Actions/Xcode build for vBRDC093 stopped on one Swift compiler error in `Sources/DebridChannelsTVOSApp.swift` at the delayed Connected Popup Artwork prewarm guard:

`cannot use optional chaining on non-optional value of type 'MediaItem'`

The outer `guard let selectedItem` creates a non-optional local named `selectedItem`. The delayed task then wrote `selectedItem?.id`, which optional-chained that non-optional captured local.

## Correction

The guard now uses:

`self.selectedItem?.id == expectedItemID`

This is not only the compile correction. It also restores the intended stale-selection safety: after the delay the task re-reads the rail's **current optional selection** instead of comparing the captured old item to itself.

## Scope lock

No UNITY motion behavior, catalog transition timing, Live TV persistent-root architecture, Pulse Glow, Connected Popup artwork strategy, wallpaper phase system, playback, provider, resume, metadata, Sports, Favorites, or Usenet behavior was redesigned in this build.

Only four pre-existing product/configuration files differ from packaged vBRDC093:

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/Info.plist`
3. `TopShelfExtension/Info.plist`
4. `project.yml`

All other additions are validation/audit documentation for vBRDC094.

## Validation

- vBRDC094 regression/architecture contract: 82/82 passed
- Swift syntax parse: 64/64 passed
- Focused Swift compile-shape typecheck for the corrected guard: passed
- Backend pytest: 36 passed, 2 subtests passed
- App and Top Shelf plist lint: passed
- App/Top Shelf/project version alignment: passed
- Donor scope audit: 4 intended existing-file changes, 0 unexpected

GitHub Actions/Xcode remains the authoritative Apple SDK compile.
