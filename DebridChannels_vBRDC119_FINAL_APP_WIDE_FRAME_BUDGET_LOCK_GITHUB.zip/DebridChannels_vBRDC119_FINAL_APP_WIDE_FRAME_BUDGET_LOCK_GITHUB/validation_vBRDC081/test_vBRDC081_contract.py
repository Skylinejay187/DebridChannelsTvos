from pathlib import Path
import plistlib, re, sys
root=Path(__file__).resolve().parents[1]
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
store=(root/'Sources/CatalogStore.swift').read_text()
anim=(root/'Sources/UnityAnimationCoordinator.swift').read_text()
life=(root/'Sources/UnitySurfaceLifecycleCoordinator.swift').read_text()
surface=(root/'Sources/UnitySurfaceSystem.swift').read_text()
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))

def plist(rel):
    with open(root/rel,'rb') as f:return plistlib.load(f)
a=plist('Sources/Info.plist'); t=plist('TopShelfExtension/Info.plist')
ck('release id', a.get('DebridChannelsReleaseID')=='vBRDC081' and t.get('DebridChannelsReleaseID')=='vBRDC081')
ck('marketing', a.get('CFBundleShortVersionString')=='1.0.784' and t.get('CFBundleShortVersionString')=='1.0.784')
ck('build', a.get('CFBundleVersion')=='784' and t.get('CFBundleVersion')=='784')
ck('lifecycle coordinator included', 'final class UnitySurfaceLifecycleCoordinator' in life)
ck('lifecycle singleton', 'static let shared = UnitySurfaceLifecycleCoordinator()' in life)
for case in ['home','movies','shows','sports','favorites','liveTV','membership','settings','search','detail','playback']:
    ck('lifecycle surface '+case, f'case {case}' in life)
ck('generation ownership', 'beginTabHandoff' in life and 'finishTabHandoff' in life and 'generation' in life)
ck('root owns lifecycle handoff', 'scheduleUnitySurfaceHandoff(from: oldTab, to: tab' in app)
ck('bounded focus checkpoints', '60_000_000' in app and '110_000_000' in app and '100_000_000' in app)
ck('watchdog suspended in handoff', 'stopCatalogCompletenessWatchdog()' in app and 'unityLifecycle.permitsNonessentialBackgroundWork' in app)
ck('animation handoff permit', 'setSurfaceHandoffActive' in anim and 'if surfaceHandoffActive' in anim)
ck('handoff blocks perpetual animation', 'return feature == .overlayChrome || feature == .alertMotion' in anim)
ck('surface system documents lifecycle', 'UnitySurfaceLifecycleCoordinator' in surface)
# isolate SportsHub body for specific checks
ss=app.index('struct SportsHubScreen: View'); se=app.index('struct SportsFoundationQuickPanelSurface: View', ss); sports=app[ss:se]
ck('sports explicit owned task', 'sportsSurfaceLoadTask' in sports and 'startSportsSurfaceWork()' in sports)
ck('sports explicit exit invalidation', 'stopSportsSurfaceWork(reason:' in sports and '.onDisappear' in sports)
ck('sports no duplicate full live refresh', 'await liveModel.refreshIfNeeded()' not in sports)
ck('sports consumes retained live session', 'liveModel.loadCachedOrDemo()' in sports)
ck('sports model generation invalidated', 'func suspendForSurfaceExit()' in app)
ck('sports custom source cancellation', 'guard !Task.isCancelled else { break }' in app and 'lineIndex.isMultiple(of: 256), Task.isCancelled' in app)
ck('sports close avoids extra focus token', 'clearSportsPresentationState + Root UNITY handoff' in sports)
ck('sports store avoids redundant published sets', 'hasStreamPresentationState' in store and 'if selectedDetail != nil { selectedDetail = nil }' in store)
ck('sports store unity lifecycle log', '[UNITY Lifecycle][Sports]' in store)
# Favorites slice
fs=app.index('struct GlobalFavoritesScreen: View'); fe=app.index('struct FavoriteLiveChannelCard: View', fs); fav=app[fs:fe]
ck('favorites active gate', 'favoritesSurfaceActive' in fav)
ck('favorites coalesced rebuild', 'scheduleFavoritesCacheRebuild' in fav and '120_000_000' in fav)
ck('favorites cancel rebuild on exit', 'favoritesRebuildTask?.cancel()' in fav and '.onDisappear' in fav)
ck('favorites coordinated close', '.onExitCommand { closeFavoritesSurface() }' in fav)
ck('favorites releases local focus first', 'focusedRow = nil' in fav and 'removeFocused = false' in fav)
# broad surface transaction removed from top-menu path
menu=app[app.index('struct TopMenuBar'):app.index('struct GlobalSearchScreen')]
ck('no broad top-menu surface animation transaction', 'withAnimation(.easeInOut(duration: 0.26))' not in menu)
# prior v080 rule must remain
ck('source search still does not suppress pulse preview', 'case .catalogPreview, .catalogPulse:' in anim and '&& !sourceSearchActive' not in anim[anim.index('case .catalogPreview, .catalogPulse:'):anim.index('case .catalogFocusArrival')])
failed=[n for n,c in checks if not c]
for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
