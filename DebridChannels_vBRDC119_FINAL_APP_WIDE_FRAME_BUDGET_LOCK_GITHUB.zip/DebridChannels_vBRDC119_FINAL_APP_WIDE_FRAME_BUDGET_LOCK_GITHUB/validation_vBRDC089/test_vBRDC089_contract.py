from pathlib import Path
import hashlib
import plistlib
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
NUVIO = (ROOT / 'Sources/NuvioPluginClient.swift').read_text()
FEBCLIENT = (ROOT / 'Sources/BackupStreamingClient.swift').read_text()
FEBRUNTIME = (ROOT / 'BackendBackupStreamingRuntime/backup_streaming_runtime.py').read_text()
FEBTEST = (ROOT / 'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py').read_text()
MEDIAFLOW = (ROOT / 'Sources/MediaFlowProxyRouter.swift').read_text()
UNIVERSAL = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()
FOUNDATION = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
REMOTE = (ROOT / 'Sources/RemoteImageFit.swift').read_text()
COORD = (ROOT / 'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []


def ck(name, cond):
    checks.append((name, bool(cond)))


def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]


app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC089', app_plist.get('DebridChannelsReleaseID') == 'vBRDC089' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC089')
ck('marketing version 1.0.792', app_plist.get('CFBundleShortVersionString') == '1.0.792' and top_plist.get('CFBundleShortVersionString') == '1.0.792')
ck('build version 792', app_plist.get('CFBundleVersion') == '792' and top_plist.get('CFBundleVersion') == '792')
ck('project marketing 1.0.792', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.792')
ck('project build 792', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '792')

# Core request-context model and Stremio parity.
ck('StreamLink owns request header context', 'var requestHeaders: [StreamRequestHeader] = []' in STORE)
ck('StreamLink request headers are hashable', 'struct StreamRequestHeader: Hashable' in STORE)
ck('request header array converts to playback dictionary', 'var playbackHTTPHeaderDictionary: [String: String]' in STORE)
ck('Stremio behavior hints decode proxy headers', 'var proxyHeaders: StremioProxyHeaders?' in STORE)
ck('Stremio proxy headers decode request map', 'struct StremioProxyHeaders: Decodable' in STORE and 'var request: [String: String]?' in STORE)
ck('main Stremio discovery preserves proxy request headers', 'requestHeaders: (stream.behaviorHints?.proxyHeaders?.request ?? [:])' in section(STORE, 'func findStreams(', 'func findStreamsForcePopulated'))
ck('Up Next Stremio discovery preserves proxy request headers', 'requestHeaders: (stream.behaviorHints?.proxyHeaders?.request ?? [:])' in section(STORE, 'func prepareUpNextEpisodeSources', 'func phase15PreparedSwitchSources'))

# In-S/Nuvio provider compatibility.
ck('In-S decodes top-level headers aliases', 'let headers: [String: String]?' in NUVIO and 'let httpHeaders: [String: String]?' in NUVIO and 'let requestHeaders: [String: String]?' in NUVIO)
ck('In-S decodes behaviorHints proxy request headers', 'let proxyHeaders: NuvioResolvedProxyHeaders?' in NUVIO and 'let request: [String: String]?' in NUVIO)
ck('In-S decodes behaviorHints videoSize', 'let videoSize: NuvioSettingValue?' in section(NUVIO, 'private struct NuvioResolvedBehaviorHints', 'private struct NuvioResolvedStream'))
ck('In-S decodes filename and size aliases', all(x in NUVIO for x in ['let fileSize: NuvioSettingValue?', 'let sizeBytes: NuvioSettingValue?', 'let filename: String?']))
ck('In-S merges provider request header forms', 'normalizedPlaybackHeaders(' in NUVIO and 'stream.behaviorHints?.proxyHeaders?.request' in NUVIO and 'stream.httpHeaders' in NUVIO and 'stream.requestHeaders' in NUVIO)
ck('In-S blocks request framing header injection', 'content-length' in NUVIO and 'transfer-encoding' in NUVIO and 'content-range' in NUVIO)
ck('In-S provider headers are stored on StreamLink', 'requestHeaders: resolvedHeaders.map { StreamRequestHeader' in NUVIO)
ck('In-S quality can recover from provider metadata text', 'normalizedQuality(stream.quality, fallbackText: metadataHaystack)' in NUVIO)
ck('In-S size prioritizes real provider byte metadata', '[stream.behaviorHints?.videoSize, stream.videoSize, stream.fileSize, stream.sizeBytes, stream.size]' in NUVIO)
ck('In-S size parser handles human units', 'tb|tib|gb|gib|mb|mib|kb|kib' in NUVIO)
ck('Shoebox ShowBox FebBox provider identities are recognized', all(token in NUVIO for token in ['providerContext.contains("febbox")', 'providerContext.contains("shoebox")', 'providerContext.contains("showbox")']))
ck('Shoebox FebBox uses local ui cookie only at playback edge', 'BackupStreamingCredentialStore.readFebBoxCookie()' in NUVIO and 'resolvedHeaders["Cookie"] = "ui=\\(localCookie); oss_group=USA7"' in NUVIO)
ck('Shoebox FebBox fallback supplies referer and origin', 'resolvedHeaders["Referer"] = "https://www.febbox.com/"' in NUVIO and 'resolvedHeaders["Origin"] = "https://www.febbox.com"' in NUVIO)
ck('plugin bridge HTTP session itself does not use cookie storage', 'configuration.httpCookieStorage = nil' in NUVIO)

# Native FebBox source resolution + metadata/privacy.
ck('FebBox response model decodes safe playback headers', 'let headers: [String: String]?' in FEBCLIENT and 'let referer: String?' in FEBCLIENT and 'let region: String?' in FEBCLIENT)
ck('FebBox backend Cookie is blocked from overriding local credential', '"cookie"' in section(FEBCLIENT, 'private static func sanitizedPlaybackHeaders', 'private static func endpointURL'))
ck('FebBox client reconstructs local ui plus oss_group cookie', 'playbackHeaders["Cookie"] = "ui=\\(cleanCookie); oss_group=\\(region)"' in FEBCLIENT)
ck('FebBox client stores final request headers on StreamLink', 'requestHeaders: playbackHeaders.map { StreamRequestHeader' in FEBCLIENT)
ck('FebBox runtime has metadata size normalizer', 'def _size_from_metadata(' in FEBRUNTIME)
ck('FebBox runtime accepts binary and decimal size labels', 'TB|TiB|GB|GiB|MB|MiB|KB|KiB' in FEBRUNTIME)
ck('FebBox file parser reads explicit size attributes', all(x in FEBRUNTIME for x in ['data-size', 'data-filesize', 'data-file-size', 'data-bytes']))
ck('FebBox file parser retains detail text for size fallback', 'record["details"]' in FEBRUNTIME)
ck('FebBox player source prefers source byte metadata', all(x in FEBRUNTIME for x in ['source.get("videoSize")', 'source.get("filesize")', 'source.get("file_size")', 'source.get("length")', 'source.get("bytes")']))
ck('FebBox runtime returns referer and region', '"referer": referer' in FEBRUNTIME and '"region": region' in FEBRUNTIME)
ck('FebBox safe playback headers deliberately exclude cookie', 'The private ui cookie is deliberately excluded' in FEBRUNTIME and '"Cookie"' not in section(FEBRUNTIME, 'def _febbox_safe_playback_headers', 'def _codecs_from_text'))
ck('FebBox test covers metadata size when filename lacks size', 'test_febbox_file_metadata_size_attribute_wins_when_filename_has_no_size' in FEBTEST)
ck('FebBox test protects secret cookie from response', 'secret-cookie' in FEBTEST and "self.assertNotIn('Cookie', result['streams'][0]['headers'])" in FEBTEST)

# Playback session ownership, alternate failover, and engine propagation.
ck('playback session publishes selected request headers', '@Published private(set) var playbackHTTPHeaders: [String: String] = [:]' in STORE)
ck('playback session stores fallback header maps by URL', 'private var playbackFallbackHTTPHeaders: [String: [String: String]] = [:]' in STORE)
ck('startPlayback accepts selected and fallback headers', 'headers: [String: String] = [:], fallbackHeaders: [String: [String: String]] = [:]' in STORE)
ck('selected source headers become active playback headers', 'playbackHTTPHeaders = !headers.isEmpty ? headers' in STORE)
ck('automatic source failover switches request context too', 'playbackHTTPHeaders = playbackFallbackHTTPHeaders[nextCandidate.url.absoluteString] ?? [:]' in STORE)
ck('restoring original source restores its request context', 'playbackHTTPHeaders = playbackFallbackHTTPHeaders[originalPlaybackURL.absoluteString] ?? [:]' in STORE)
ck('player close clears provider request context', 'playbackHTTPHeaders = [:]' in section(STORE, 'func closePlayer', 'func openDetail'))
ck('Phase15 selected source passes headers', 'headers: selected.requestHeaders.playbackHTTPHeaderDictionary' in section(STORE, 'func playPhase15SelectedDirectStream', 'func playFirstDirectStream'))
ck('auto Play selected source passes headers', 'headers: direct.requestHeaders.playbackHTTPHeaderDictionary' in section(STORE, 'func playFirstDirectStream', 'private func quickPlaybackPreflight'))
ck('Up Next selected source passes headers', 'headers: rememberedLink?.requestHeaders.playbackHTTPHeaderDictionary ?? [:]' in APP)
ck('Media Information selected source passes headers', 'headers: link.requestHeaders.playbackHTTPHeaderDictionary' in APP)
ck('preflight preserves selected provider context for MediaFlow future use', 'quickPlaybackPreflight(url: url, headers: selected.requestHeaders.playbackHTTPHeaderDictionary)' in STORE and 'upstreamHeaders: headers' in section(STORE, 'private func quickPlaybackPreflight', 'func startPlayback'))

ck('Universal player surface carries provider headers', 'var httpHeaders: [String: String] = [:]' in UNIVERSAL and 'httpHeaders: httpHeaders' in UNIVERSAL)
ck('PlaybackKit host carries provider headers', 'var httpHeaders: [String: String] = [:]' in FOUNDATION and 'httpHeaders: httpHeaders' in FOUNDATION)
ck('KS surface carries provider headers', 'var httpHeaders: [String: String] = [:]' in KS)
ck('KS AVURLAsset receives merged provider headers', 'AVURLAssetHTTPHeaderFieldsKey' in KS and 'mergedPlaybackHeaders(defaultUserAgent:' in KS)
ck('KS FFmpeg path receives provider user agent', '"user_agent": effectiveUserAgent' in KS)
ck('KS network appendHeader receives merged provider headers', 'options.appendHeader(playbackHeaders)' in KS)
ck('display-match probe receives provider headers', 'applyForFullScreenVOD(url: url, hint: routeHint, httpHeaders: sanitizedPlaybackHTTPHeaders)' in KS)
ck('manual AVPlayer path merges provider headers', 'vBRDC089: AVPlayer is a manual compatibility path' in APP and 'playerRequestHeaders(for: mediaFlowRouteKind, upstreamHeaders: store.playbackHTTPHeaders)' in APP)

# MediaFlow must forward provider context to the destination rather than lose it at the proxy boundary.
ck('MediaFlow playback wrapper accepts upstream headers', 'upstreamHeaders: [String: String] = [:]' in MEDIAFLOW)
ck('MediaFlow playback encodes provider headers as h parameters', 'headers: upstreamHeaders' in section(MEDIAFLOW, 'static func playbackURLIfAllowed(', '/// Provider headers belong to the destination host'))
ck('MediaFlow direct player header policy avoids duplicating destination secrets onto proxy', 'static func playerRequestHeaders(' in MEDIAFLOW and 'return shouldProxy(kind: kind, snapshot: config) ? [:] : upstreamHeaders' in MEDIAFLOW)
ck('VOD surface wraps source with active provider headers', 'upstreamHeaders: isLivePlayback ? [:] : store.playbackHTTPHeaders' in section(APP, 'private func mediaFlowPlaybackURL', 'private var enginePlaybackHTTPHeaders'))
ck('VOD engine suppresses direct destination headers when MediaFlow owns hop', 'httpHeaders: enginePlaybackHTTPHeaders' in APP)
ck('external-player MediaFlow wrapper also carries selected source headers', 'upstreamHeaders: link.requestHeaders.playbackHTTPHeaderDictionary' in APP)

# Live TV grid artwork ownership/fallback.
live_loader = section(APP, 'private final class LiveTVBoundedArtworkLoader', 'private struct LiveTVQuickGuideContainedArtworkFrame')
live_grid_art = section(APP, 'private struct LiveTVGridTileArtwork: View', 'private struct LiveTVGridTileContent')
ck('Live TV artwork loader publishes failed URL ownership', '@Published private(set) var failedURLs: Set<URL> = []' in live_loader and 'self.failedURLs.insert(url)' in live_loader)
ck('Live TV failed Gracenote URL is skipped instead of pinning black card', '!artworkLoader.failedURLs.contains(url)' in live_grid_art)
program_pos = live_grid_art.find('return .program(url)')
icon_pos = live_grid_art.find('return .channelIcon(url)')
provider_pos = live_grid_art.find('return .provider(url)')
ck('Live TV grid fallback ladder is Gracenote then channel icon then provider poster', -1 not in (program_pos, icon_pos, provider_pos) and program_pos < icon_pos < provider_pos)

# Prior regression locks remain present with no visual redesign.
rail = section(APP, 'struct GridOSFixedSlotCatalogRail: View', 'struct FixedSlotFocusedCatalogCard: View')
preview_items = section(rail, 'private var previewItems:', 'private func isCatalogFavorite')
ck('vBRDC088 visible-slice allocation lock remains', 'Array(row.items[firstPreviewIndex..<endIndex])' in preview_items and 'Array(row.items.dropFirst' not in preview_items)
ck('vBRDC088 stable connector frame lock remains', 'vBRDC088: report the fixed catalog slot' in rail)
ck('vBRDC088 bounded search artwork decode remains', 'maxPixelSize: 1024' in section(APP, 'struct SearchResultCard: View', 'struct SearchLiveChannelCard: View'))
ck('vBRDC087 connected popup artwork remains catalog-only', 'connectorOrigin == .catalog' in section(APP, 'private var connectedPopupArtworkLayerAllowed', '// v1051: Keep the optional artwork layer'))
ck('vBRDC087 catalog pulse still yields to Media Information', 'store.selectedDetail == nil' in section(rail, 'private var coordinatedPulseAnimation', 'private var cardIsVisuallyFocused'))
ck('vBRDC086 Favorites identity owner remains isolated', 'quickPanelRestoreSection != "favoritesCatalog"' in section(APP, 'private var catalogMayUseDetailPresentationAnchor', 'private var rowFocusedBackdropItem'))
confirm = section(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
ck('vBRDC085 automatic resume still asserts KS Play', 'ksPlayAssertionSerial &+= 1' in confirm)
production_loader = section(APP, 'private func loadVODProductionMetadata(', 'private func showVODCastExplorerOnboardingIfNeeded')
ck('vBRDC085 Production remains background and pause-independent', 'Task(priority: .background)' in production_loader and '!isPlaying' not in production_loader)

# Untargeted sensitive files remain exact packaged-vBRDC088 bytes.
DONOR_HASHES = {
    'Sources/RemoteImageFit.swift': '135b41565cade3f9fe1ab36536ccf75f0d79dbbe3056107851a6bcd6d2e79933',
    'Sources/UnityAnimationCoordinator.swift': '48261d539c09555bfe54bfb1bacaebc7319fe0c45574b10d64ce811f44875994',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83cfe?'.replace('cfe?','f673e218d76b25a83cfe') if False else '3eb69ee18cf587646229b8f673e218d76b25a83cfe?'
}
# Keep these hashes explicit without cleverness; the third assignment above is replaced below.
DONOR_HASHES = {
    'Sources/RemoteImageFit.swift': '135b41565cade3f9fe1ab36536ccf75f0d79dbbe3056107851a6bcd6d2e79933',
    'Sources/UnityAnimationCoordinator.swift': '48261d539c09555bfe54bfb1bacaebc7319fe0c45574b10d64ce811f44875994',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
    'Sources/UnityCatalogVisualSystem.swift': 'cc954cb07319a98dd288eadea8a4976514d9bccad5b78134bc939d18613799c4',
}
for rel, expected in DONOR_HASHES.items():
    ck('v088 donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is declared in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
if failed:
    print('Failed: ' + ', '.join(failed))
sys.exit(1 if failed else 0)
