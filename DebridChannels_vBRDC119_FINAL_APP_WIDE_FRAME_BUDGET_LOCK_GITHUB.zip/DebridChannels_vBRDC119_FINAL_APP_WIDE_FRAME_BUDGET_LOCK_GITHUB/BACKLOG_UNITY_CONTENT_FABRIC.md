# Backlog — Unity Content Fabric

## Goal

Evolve UNITY beyond a shared navigation root into a content model where users move through **context**, **time**, and **relationships** instead of repeatedly entering traditional app pages.

This should be treated as a Debrid Channels product architecture, not as a claim that overlay navigation or graph data structures themselves are new inventions. The opportunity is the combination and TV-first interaction model.

## Core idea: the focused item becomes the navigation center

Today a user chooses a section first (Live TV, Movies, Shows, Sports) and then chooses content. Unity Content Fabric can invert that relationship: the content already in focus becomes the center and related experiences appear as lightweight branches around it.

Examples:

- Focus a live basketball game → reveal team schedule, standings, related live channels, highlights, documentaries, and upcoming games without leaving the canvas.
- Focus a live TV program → reveal available episodes, related movies/shows, cast, next airing, and user-connected on-demand sources as branches.
- Focus a movie → reveal cast branches, franchise chronology, soundtrack/trailer branch, similar live programming, and continue-watching context.
- Focus a show → move directly between current live airing, next episode, prior episode progress, season rail, and related content.

## Proposed interaction grammar

- **Left / Right = time or sequence** — earlier/later, previous/next episode, prior/next game, continue position.
- **Up / Down = context branch** — related, live, on-demand, sports, cast, collection, recommendations.
- **Select = deepen the current node** — details, playback, source selection, expanded branch.
- **Back = collapse one depth** — never jump to an unrelated root unless the current node is already at root depth.

The user should feel that they are moving through one living content space rather than opening and closing pages.

## Major future systems

### 1. Unity Context Graph

Normalize relationships between channels, programs, movies, series, episodes, sports events, teams, people, providers, and playback history. UI branches can then be generated from relationships rather than hard-coded section boundaries.

### 2. Unified Time Ribbon

A single horizontal time axis can combine:

- currently live
- airing next
- upcoming sports
- newly released episodes
- continue-watching positions
- scheduled favorites/alerts

This creates a TV interface organized around **what matters now and next**, not just content type.

### 3. Live-to-VOD handoff

When the focused live program has an on-demand equivalent, Unity can expose “Start from beginning,” episode history, related seasons, or another user-connected source without forcing a separate search/page flow.

### 4. Persistent spatial memory

Every branch should remember its exact focus, rail, time position, and parent node. Collapsing and reopening a branch should return to the same place, reinforcing the feeling that all surfaces coexist in one structure.

### 5. Adaptive branch composition

The lower/side branch can change based on what is focused rather than on a fixed tab:

- sports event → score/schedule/team branches
- movie → related/cast/franchise branches
- series → episodes/seasons/airing branches
- live channel → guide/next/related branches

### 6. Unity Session Graph

A lightweight session model could remember how the viewer arrived at a title — live channel → actor → movie → related show — so Back walks the actual content path rather than a generic screen stack.

## Guardrails

- Playback remains a resource-isolated terminal surface unless future hardware testing proves a retained background is safe.
- Theme selection never changes navigation ownership.
- No branch may create a second competing focus tree.
- Content/provider availability remains truthful; relationships must not imply that Debrid Channels hosts content.
- The system should degrade gracefully when metadata is missing.

## Suggested phased path

1. **Unity Surface System** — current vBRDC059 foundation.
2. **Unity Session Graph** — replace ad-hoc Back destinations with explicit parent/depth state.
3. **Context Branch API** — one model for producing related branches for any focused content node.
4. **Unified Time Ribbon** — Live/Next/Continue/Upcoming in one temporal lane.
5. **Adaptive Content Fabric** — section boundaries become optional lenses rather than primary destinations.
