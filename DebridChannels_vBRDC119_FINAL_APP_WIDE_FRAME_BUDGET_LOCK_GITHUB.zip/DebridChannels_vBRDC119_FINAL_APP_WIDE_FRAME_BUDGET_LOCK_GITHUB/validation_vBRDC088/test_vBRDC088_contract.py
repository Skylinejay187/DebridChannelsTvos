from pathlib import Path
import hashlib
import plistlib
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
REMOTE = (ROOT / 'Sources/RemoteImageFit.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
COORD = (ROOT / 'Sources/UnityAnimationCoordinator.swift').read_text()
UNIVERSAL = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()
FOUNDATION = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []


def ck(name, cond):
    checks.append((name, bool(cond)))


def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]


app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC088', app_plist.get('DebridChannelsReleaseID') == 'vBRDC088' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC088')
ck('marketing version 1.0.791', app_plist.get('CFBundleShortVersionString') == '1.0.791' and top_plist.get('CFBundleShortVersionString') == '1.0.791')
ck('build version 791', app_plist.get('CFBundleVersion') == '791' and top_plist.get('CFBundleVersion') == '791')
ck('project marketing 1.0.791', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.791')
ck('project build 791', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '791')

# vBRDC088 catalog-frame-budget locks.
rail = section(APP, 'struct GridOSFixedSlotCatalogRail: View', 'struct FixedSlotFocusedCatalogCard: View')
preview_items = section(rail, 'private var previewItems:', 'private func isCatalogFavorite')
ck('catalog rail does not copy complete remaining tail', 'Array(row.items.dropFirst' not in preview_items)
ck('catalog rail computes remaining count before slice', 'remainingCount = max(0, row.items.count - firstPreviewIndex)' in preview_items)
ck('catalog rail copies only viewport-sized slice', 'Array(row.items[firstPreviewIndex..<endIndex])' in preview_items)
ck('catalog fixed slot reports stable frame outside animated card', 'vBRDC088: report the fixed catalog slot' in rail and 'FocusedCatalogCardFramePreferenceKey.self' in rail)
ck('stable slot reporter preserves resting y offset', '.offset(y: -6)' in rail)

fixed_card = section(APP, 'struct FixedSlotFocusedCatalogCard: View', 'struct FixedSlotPreviewCatalogCard: View')
ck('animated focused card no longer publishes global frame preference', 'FocusedCatalogCardFramePreferenceKey.self' not in fixed_card)
ck('focused catalog artwork uses bounded display decode', 'maxPixelSize: 1280' in fixed_card)
preview_card = section(APP, 'struct FixedSlotPreviewCatalogCard: View', 'struct MovieInfoComicBubbleShape')
ck('trailing catalog artwork uses bounded display decode', 'maxPixelSize: 640' in preview_card)
search_card = section(APP, 'struct SearchResultCard: View', 'struct SearchLiveChannelCard: View')
ck('Search result cards use bounded display decode', 'maxPixelSize: 1024' in search_card)
card_logo = section(APP, 'struct CardThemedLogo: View', 'struct PopupArtworkLogoOnly: View')
ck('high-churn focused card logo uses bounded display decode', 'maxPixelSize: 768' in card_logo)
root_pref = section(APP, '.onPreferenceChange(FocusedCatalogCardFramePreferenceKey.self)', '.onAppear {')
ck('root catalog frame state write is deduplicated', 'frame != focusedCatalogCardFrame' in root_pref)
ck('root search frame state write is deduplicated', 'frame != searchMenuIconFrame' in root_pref)

# vBRDC088 generic image loader keeps visual source policy but bounds high-churn decode memory.
ck('generic image loader imports ImageIO', 'import ImageIO' in REMOTE)
ck('decode cache key contains URL and pixel bucket', 'private struct LoadKey: Hashable' in REMOTE and 'maxPixelSize: Int' in REMOTE and '|decode=' in REMOTE)
ck('decode cache is keyed by URL plus bucket string', 'NSCache<NSString, UIImage>' in REMOTE)
ck('downsample uses ImageIO thumbnail max pixel size', 'kCGImageSourceThumbnailMaxPixelSize: maxPixelSize' in REMOTE)
ck('downsample applies source transform', 'kCGImageSourceCreateThumbnailWithTransform: true' in REMOTE)
ck('full-screen/default loader retains original decode fallback', 'if maxPixelSize > 0' in REMOTE and 'UIGraphicsImageRenderer(size: source.size' in REMOTE)
ck('RemoteImageFit default remains original-resolution decode', 'var maxPixelSize: Int? = nil' in REMOTE)
ck('RemoteImageFit forwards decode budget on appear', 'loader.load(resolvedURL, maxPixelSize: maxPixelSize)' in REMOTE)
ck('RemoteImageFit forwards decode budget on URL changes', 'maxPixelSize: maxPixelSize' in section(REMOTE, '.onChange(of: resolvedURL)', '.onDisappear'))
ck('preserve-previous artwork behavior remains present', 'preservePreviousOnURLChange' in REMOTE and '.transition(preservePreviousOnURLChange ? .identity : .opacity)' in REMOTE)

# vBRDC088 Live TV focus path: no hidden provider work and no O(n) focus scans.
live_model = section(APP, 'final class LiveTVSourceModel: ObservableObject', 'struct LiveTVScreen: View')
ck('Live TV channel browse index rebuilds only when channel array changes', 'didSet { rebuildChannelBrowseIndex() }' in live_model)
ck('Live TV browse index stores exact category groups', 'channelBrowseIndex: [String: [LiveTVChannel]]' in live_model)
ck('Live TV browse index stores HD projection', 'indexedHDChannels' in live_model)
ck('Live TV browse index stores channel identity/order for Favorites', 'indexedChannelByID' in live_model and 'indexedChannelPositionByID' in live_model)
ck('Live TV browse index is initialized for demo/cached starting data', 'init()' in live_model and 'rebuildChannelBrowseIndex()' in live_model)

live_screen = section(APP, 'struct LiveTVScreen: View', 'private struct GuideEmptyProgramCell: View')
categories = section(live_screen, 'private var categories:', 'private var myFavoriteChannelIDs')
visible = section(live_screen, 'private var visibleChannels:', 'private var renderedChannels:')
ck('Live TV category list reads provider-time index instead of mapping every channel per focus', 'liveModel.browseCategoryNames()' in categories and 'liveModel.channels.map' not in categories)
ck('Live TV HD/category filters read provider-time indexes', 'liveModel.browseHDChannels()' in visible and 'browseChannels(inExactCategory:' in visible)
ck('Live TV My Favorites uses indexed channel lookup instead of full-lineup filter', 'browseFavoriteChannels(ids: myFavoriteChannelIDs)' in visible and 'liveModel.channels.filter' not in visible)
selection_change = section(live_screen, '.onChange(of: selectedChannelID)', '.onChange(of: renderedWindowStart)')
ck('Live TV focus persists through debounce helper', 'scheduleLiveTVSelectionPersistence(value)' in selection_change)
ck('Live TV focus no longer writes AppStorage synchronously', 'liveTVLastSelectedChannelID = value' not in selection_change)
ck('Live TV focus no longer rescans all EPG boundaries', 'scheduleLiveTVScheduleBoundaryRefresh' not in selection_change)
window_change = section(live_screen, '.onChange(of: renderedWindowStart)', '.onChange(of: guideFocus)')
ck('EPG boundary scan moves to virtual-window change', 'render window changed' in window_change and 'scheduleLiveTVScheduleBoundaryRefresh' in window_change)

persist = section(live_screen, 'private func scheduleLiveTVSelectionPersistence', 'private func startLiveTVRefreshIfActive')
ck('Live TV selection persistence is coalesced', '450_000_000' in persist and 'liveTVSelectionPersistenceTask?.cancel()' in persist)
ck('settled channel is checked before persistence', 'selectedChannelID == channelID' in persist)
refresh = section(live_screen, 'private func startLiveTVRefreshIfActive', 'private func reconcileWallpaperRenderOwnership')
ck('Live TV refresh is gated to visible Live/Sports tabs', 'store.selectedTab == .live || store.selectedTab == .sports' in refresh)
ck('Live TV refresh remains VOD-exclusive gated', '!VODExclusivePlaybackGate.isActive' in refresh)

on_appear = section(live_screen, '.onAppear {\n                synchronizeUnityGuideAnimationActivity', '.onChange(of: store.guideStartupRequestToken)')
ck('Live TV mount loads cached visual donor state', 'liveModel.loadCachedOrDemo()' in on_appear)
ck('Live TV mount delegates expensive refresh to active-surface gate', 'startLiveTVRefreshIfActive(reason: "grid appear")' in on_appear)
ck('Live TV mount no longer directly starts refreshIfNeeded', 'await liveModel.refreshIfNeeded()' not in on_appear)

tab_change = section(live_screen, '.onChange(of: store.selectedTab)', '.onChange(of: store.liveTVFocusRestoreToken)')
ck('leaving Live/Sports cancels hidden Live TV refresh', 'liveRefreshTask?.cancel()' in tab_change and 'liveRefreshTask = nil' in tab_change)
ck('leaving Live/Sports cancels hidden artwork prefetch', 'liveTVArtworkPrefetchTask?.cancel()' in tab_change and 'LiveTVBoundedArtworkLoader.cancelObsoletePrefetches' in tab_change)
ck('returning to Live/Sports restarts active refresh', 'startLiveTVRefreshIfActive(reason: "Live TV became visible")' in tab_change)

prefetch = section(live_screen, 'private func scheduleLiveTVArtworkPrefetch', 'private func prefetchLiveTVArtworkAroundFocusedChannel')
ck('Live TV artwork prefetch only runs on Live/Sports', '(store.selectedTab == .live || store.selectedTab == .sports)' in prefetch)
ck('Live TV hidden Home/Movies/Shows prefetch permission removed', 'store.selectedTab == .home' not in prefetch and 'store.selectedTab == .movies' not in prefetch and 'store.selectedTab == .shows' not in prefetch)
tile_focus = section(live_screen, '.onChange(of: tileFocus)', 'private func performLiveTVRestoreScroll')
ck('tile focus has one canonical virtual-window update path', 'keepFocusedChannelInVirtualWindow()' not in tile_focus and 'selectedChannelID = value' in tile_focus)
play = section(APP, 'private func play(channel: LiveTVChannel)', 'private func saveLiveTVFocusSnapshot')
ck('actual Live TV playback flushes selected channel immediately', 'liveTVLastSelectedChannelID != channel.id' in play and 'liveTVLastSelectedChannelID = channel.id' in play)

# vBRDC087 single artwork-owner + animation isolation remains intact.
art_gate = section(APP, 'private var connectedPopupArtworkLayerAllowed', '// v1051: Keep the optional artwork layer')
ck('connected popup artwork remains catalog-only', 'connectorOrigin == .catalog' in art_gate)
pulse_gate = section(rail, 'private var coordinatedPulseAnimation', 'private var cardIsVisuallyFocused')
ck('catalog pulse still yields whenever Media Information is open', 'store.selectedDetail == nil' in pulse_gate)
coord_pulse = section(COORD, 'case .catalogPulse:', 'case .catalogFocusArrival')
coord_preview = section(COORD, 'case .catalogPreview:', 'case .catalogPulse:')
ck('UNITY pulse still yields to detailActive', '!context.detailActive' in coord_pulse)
ck('UNITY preview remains independent from detail pulse lock', '!context.detailActive' not in coord_preview)

# vBRDC086 Favorites identity lock remains intact.
hero_gate = section(APP, 'private var catalogMayUseDetailPresentationAnchor', 'private var rowFocusedBackdropItem')
ck('catalog hero still rejects favorites origin', 'store.detailPresentationOrigin != .favorites' in hero_gate)
ck('catalog hero still rejects favorites restore owner', 'store.quickPanelRestoreSection != "favoritesCatalog"' in hero_gate)
close_favorites = section(APP, 'private func closeFavoritesSurface()', 'private func scheduleFavoritesCacheRebuild')
ck('Favorites exit still scrubs identity before Home', close_favorites.find('clearFavoritesPresentationStateForNavigation') < close_favorites.find('store.selectedTab = .home'))

# vBRDC085 resume/autoplay + Production decoupling remains intact.
ck('VOD explicit KS play assertion serial preserved', '@State private var ksPlayAssertionSerial = 0' in APP)
confirm = section(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
ck('automatic resume still emits KS Play assertion', 'ksPlayAssertionSerial &+= 1' in confirm)
ck('UniversalVideoSurface still forwards play assertion', 'playAssertionSerial: ksPlayAssertionSerial' in UNIVERSAL)
ck('PlaybackKit host still forwards play assertion', 'playAssertionSerial: playAssertionSerial' in FOUNDATION)
play_assert = section(KS, 'if coordinator.lastPlayAssertionSerial != playAssertionSerial', '// v408: KSPlayer can crash')
ck('KS surface still calls layer.play for assertion', 'layer.play()' in play_assert)
production_loader = section(APP, 'private func loadVODProductionMetadata(', 'private func showVODCastExplorerOnboardingIfNeeded')
ck('Production remains first-frame gated', 'isFirstFrameReady' in production_loader)
ck('Production remains independent from pause', '!isPlaying' not in production_loader)
ck('Production remains background priority', 'Task(priority: .background)' in production_loader)

# Sensitive systems not targeted in vBRDC088 remain exact packaged-v087 bytes.
BASE_HASHES = {
    'Sources/UnityAnimationCoordinator.swift': '48261d539c09555bfe54bfb1bacaebc7319fe0c45574b10d64ce811f44875994',
    'Sources/CatalogStore.swift': '07d1bd218cdf3315298496ff7dd57d11ef15a102a943989f2312cef3c22ac5df',
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
    'Sources/UnityCatalogVisualSystem.swift': 'cc954cb07319a98dd288eadea8a4976514d9bccad5b78134bc939d18613799c4',
    'Sources/UniversalCodecSupport.swift': 'b315a3fb05c7115f94c70234827b15af8be2e502efaa8398d9413a20dee191d7',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift': 'cd22fb911d06af7b4b4d103c8007b14c168ef80e21451253d514c0f1b5f2cdaf',
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift': '9fabac610a23f7d96ecd8dc4eca7e680986bb3bc8734cbc75fa1cb4655b483db',
}
for rel, expected in BASE_HASHES.items():
    ck('v087 donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
