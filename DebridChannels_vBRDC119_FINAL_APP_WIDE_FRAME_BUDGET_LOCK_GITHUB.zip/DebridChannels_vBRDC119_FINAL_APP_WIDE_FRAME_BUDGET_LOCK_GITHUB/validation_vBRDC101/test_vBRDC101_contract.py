from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG = (ROOT/'Sources/RemoteImageFit.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release vBRDC101', app.get('DebridChannelsReleaseID')=='vBRDC101' and top.get('DebridChannelsReleaseID')=='vBRDC101')
ck('marketing 1.0.804', app.get('CFBundleShortVersionString')=='1.0.804' and top.get('CFBundleShortVersionString')=='1.0.804')
ck('build 804', app.get('CFBundleVersion')=='804' and top.get('CFBundleVersion')=='804')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.804')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='804')

# vBRDC101 compositor/publication lane.
ck('critical publication API exists', 'func shouldDeferVisualPublication(allowDuringSurfaceHandoff: Bool = false)' in UNITY)
ck('critical publication bypasses only surface handoff', '(!allowDuringSurfaceHandoff && surfaceHandoffActive)' in UNITY)
ck('critical publication still yields for navigation', 'navigationBurstActive' in section(UNITY,'func shouldDeferVisualPublication','var shouldDeferNoncriticalVisualPublication'))
ck('critical publication still yields for post-nav recovery', 'postNavigationVisualRecoveryActive' in section(UNITY,'func shouldDeferVisualPublication','var shouldDeferNoncriticalVisualPublication'))
ck('critical publication still yields for source opening', 'sourceOpeningActive' in section(UNITY,'func shouldDeferVisualPublication','var shouldDeferNoncriticalVisualPublication'))
ck('critical publication still yields for trailer', 'trailerExclusiveActive' in section(UNITY,'func shouldDeferVisualPublication','var shouldDeferNoncriticalVisualPublication'))
ck('critical publication still yields for playback', 'context.fullScreenPlaybackActive' in section(UNITY,'func shouldDeferVisualPublication','var shouldDeferNoncriticalVisualPublication'))
ck('legacy noncritical policy preserved', 'shouldDeferVisualPublication()' in section(UNITY,'var shouldDeferNoncriticalVisualPublication','func setSourceIntelligence'))

ck('image loader stores surface handoff publication permit', 'private var allowPublicationDuringSurfaceHandoff: Bool = false' in IMG)
ck('image loader load accepts surface handoff publication permit', 'allowPublicationDuringSurfaceHandoff: Bool = false' in section(IMG,'func load(','func suspendPreservingImage'))
ck('RemoteImageFit exposes critical publication option', 'var publishDuringSurfaceHandoff: Bool = false' in IMG)
ck('RemoteImageFit forwards critical publication option', 'allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff' in IMG)
ck('deferred publish consults critical policy', 'shouldDeferVisualPublication(' in section(IMG,'private func publishDecodedImage','private static func normalizedURL'))

# Normal UNITY navigation must not run the emergency rehydration storm.
handoff=section(APP,'private func scheduleUnitySurfaceHandoff','private func scheduleCatalogInteractionRecovery')
ck('normal UNITY handoff does not force blank rehydration', 'PremiumArtworkRehydrationCoordinator.shared.force' not in handoff)
ck('normal UNITY handoff does not force catalog readiness', 'forceVisibleCatalogReadiness' not in handoff)
ck('normal UNITY handoff still restarts completeness watchdog', 'startCatalogCompletenessWatchdogIfNeeded()' in handoff)
ck('catalog overlay has lightweight presentation prep', 'private func prepareCatalogOverlayForPresentation(reason: String)' in APP)
prep=section(APP,'private func prepareCatalogOverlayForPresentation','private func forceVisibleCatalogReadiness')
ck('healthy overlay presentation only rebuilds resident rows', 'rebuildRenderedRows(reason: reason)' in prep)
ck('emergency readiness only on empty/incomplete catalog', 'store.rows.isEmpty || store.catalogCompletenessNeedsRecovery' in prep)
onappear=section(APP,'.onAppear {',' .onChange(of: store.rowsRevision)')
# Use whole APP check because RootView has multiple onAppear blocks.
ck('catalog overlay appear uses lightweight prep', 'prepareCatalogOverlayForPresentation(reason: "catalog overlay appear")' in APP)
ck('old handoff-settled rehydration reason removed', 'UNITY catalog handoff settled' not in APP)
ck('old healthy content-focus artwork force removed', 'content focus artwork' not in APP)

# Catalog branch motion should bind before first visible frame and settle independently.
transition=section(APP,'private func synchronizeUnityCatalogBranchPresentation','private func scheduleUnitySurfaceHandoff')
ck('catalog entry has hidden preflight yield', 'await Task.yield()' in transition and '24_000_000' in transition)
ck('catalog entry uses compositor-first curve', '.timingCurve(0.22, 1.0, 0.36, 1.0, duration: 0.38)' in transition)
ck('catalog exit uses smooth reverse curve', '.timingCurve(0.40, 0.0, 0.20, 1.0, duration: 0.34)' in transition)
ck('catalog entry transition owns bounded settle', '400_000_000' in transition)
ck('catalog exit transition owns bounded settle', '360_000_000' in transition)
ck('catalog focus binds inside invisible preflight', 'enteringCatalogFromLiveRoot ? 18_000_000' in handoff and '24_000_000' in transition)
ck('catalog entry keeps ambient isolated after final motion', 'enteringCatalogFromLiveRoot ? 190_000_000' in handoff and 'enteringCatalogFromLiveRoot ? 220_000_000' in handoff)
ck('catalog exit keeps ambient isolated after unmount', 'leavingCatalogForLiveRoot ? 100_000_000' in handoff)

# Artwork 4 / Hero 2 retained ownership and 4K decode budget.
main_art=section(APP,'private func mainArtworkBackground','private func artworkThemeTint')
depth=section(APP,'private func artworkDepthLayers','private var artworkHeroLogo')
hero=section(APP,'private func artworkHeroLogo','struct Artwork4HeroLogoLayer: View')
hero_logo=section(APP,'struct Artwork4HeroLogoLayer: View','private struct CatalogHeroMetadataRibbon')
focused=section(APP,'struct FixedSlotFocusedCatalogCard: View','struct FixedSlotPreviewCatalogCard: View')
preview=section(APP,'struct FixedSlotPreviewCatalogCard: View','struct HomeGridThemeOverlay: View')
card_logo=section(APP,'struct CardThemedLogo: View','struct FocusedCardPreviewSurface: View')

ck('main backdrop is true 4K decode capped', 'maxPixelSize: 3840' in main_art)
ck('main backdrop retains prior frame', 'preservePreviousOnURLChange: true' in main_art)
ck('main backdrop publishes during UNITY handoff', 'publishDuringSurfaceHandoff: true' in main_art)
ck('main backdrop identity is media-stable', r'.id("catalog-main-\(itemID)")' in main_art)
ck('depth art shares 4K decode bucket', 'maxPixelSize: 3840' in depth)
ck('depth art retains prior frame', 'preservePreviousOnURLChange: true' in depth)
ck('depth art publishes during UNITY handoff', 'publishDuringSurfaceHandoff: true' in depth)
ck('hero logo owner no longer keyed by URL', r'.id("artwork-hero-logo-\(store.detailPresentationRevision)-\(item.id)")' in hero and r'.id("artwork-hero-logo-\(store.detailPresentationRevision)-\(item.id)-\(focusedThemedLogoURL ?? "title")")' not in APP)
ck('hero content owner no longer keyed by URL', r'.id("catalog-hero-content-\(store.detailPresentationRevision)-\(item.id)")' in hero and r'.id("catalog-hero-content-\(store.detailPresentationRevision)-\(item.id)-\(focusedThemedLogoURL ?? "title")")' not in APP)
ck('Artwork4 logo retains prior URL frame', 'preservePreviousOnURLChange: true' in hero_logo)
ck('Artwork4 logo critical handoff publication', 'publishDuringSurfaceHandoff: true' in hero_logo)
ck('Artwork4 logo decode bounded', 'maxPixelSize: 1280' in hero_logo)
ck('focused big card retains previous image', 'preservePreviousOnURLChange: true' in focused)
ck('focused big card critical handoff publication', 'publishDuringSurfaceHandoff: true' in focused)
ck('focused big card owner is URL-stable', r'.id("focused-card-art-\(rowID)-\(item.id)")' in focused and r'.id("focused-card-art-\(rowID)-\(item.id)-' not in focused)
ck('focused logo owner is URL-stable', r'.id("focused-card-logo-\(rowID)-\(item.id)")' in focused and r'.id("focused-card-logo-\(rowID)-\(item.id)-' not in focused)
ck('preview cards retain previous image', 'preservePreviousOnURLChange: true' in preview)
ck('near preview cards may publish during handoff', 'publishDuringSurfaceHandoff: depth < 3' in preview)
ck('preview image owner is URL-stable', r'.id("preview-card-art-\(rowID)-\(item.id)")' in preview)
ck('card themed logo retains frame', 'preservePreviousOnURLChange: true' in card_logo)
ck('card themed logo critical handoff publication', 'publishDuringSurfaceHandoff: true' in card_logo)

# vBRDC100 seamless VOD rotations remain locked.
cast=section(APP,'struct V1111FeaturedCastPosterCard: View','private struct V1106ProductionFact')
prod_panel=section(APP,'struct V1108ProductionRatingsPanel: View','private struct V1111ProductionArtworkHeader')
prod_header=section(APP,'private struct V1111ProductionArtworkHeader: View','struct V1104ReviewScoresCluster')
ck('v100 compact cast retained-frame fix preserved', 'preservePreviousOnURLChange: true' in section(cast,'private var compactBannerSurface','private func fullPosterCast'))
ck('v100 full cast retained-frame fix preserved', 'preservePreviousOnURLChange: true' in section(cast,'private func fullPosterCast','private var accessibilityText'))
ck('v100 compact cast stable identity preserved', r'.id("vBRDC100-featured-cast-compact-\(item.id)")' in cast)
ck('v100 full cast stable identity preserved', r'.id("vBRDC100-featured-cast-full-\(item.id)")' in cast)
ck('v100 cast 7-second cadence preserved', 'Task.sleep(nanoseconds: 7_000_000_000)' in cast)
ck('v100 production retained-frame fix preserved', 'preservePreviousOnURLChange: true' in prod_header)
ck('v100 production per-URL destruction remains removed', r'v1112-production-artwork-\(currentArtworkURL)' not in prod_header)
ck('v100 production stable title identity preserved', r'.id("vBRDC100-production-header-\(item.id)")' in prod_panel)
ck('v100 production 7-second cadence preserved', 'Timer.publish(every: 7.0' in prod_header)

# Emergency recovery itself remains available for genuine failures/playback returns.
ck('playback close rehydration retained', 'PremiumArtworkRehydrationCoordinator.shared.force(reason: "full-screen playback closed")' in APP)
ck('scene resume rehydration retained', 'PremiumArtworkRehydrationCoordinator.shared.force(reason: "scene became active")' in APP)
recovery=section(APP,'private func forceVisibleCatalogReadiness','private func scheduleRenderedRowsRebuild')
ck('real readiness still forces mounted blank rehydrate', 'PremiumArtworkRehydrationCoordinator.shared.force(reason: reason)' in recovery)
ck('real readiness keeps bounded post-mount pass', '180_000_000' in recovery and 'post-mount image pass' in recovery)

# Provider/playback/resume and core UNITY donor locks remain byte-identical to packaged vBRDC100.
DONOR={
'Sources/NuvioPluginClient.swift':'94a3196403f26e8edad215029b26191e3941d7fb14a5fc5ac60fe29801a90a75',
'Sources/BackupStreamingClient.swift':'251dc138dbd14fc476c76bc6a765f85643df083a5c94196d54fc0148337346cd',
'Sources/UnitySurfaceSystem.swift':'00f507ce35a619732abe0811ff3fd3f7ffe58c431336b23b69011f43079beb76',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
}
for rel,h in DONOR.items(): ck('donor '+rel, sha(rel)==h)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('all Swift sources declared', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
