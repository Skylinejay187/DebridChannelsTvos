from pathlib import Path
import plistlib, re, sys
ROOT = Path(__file__).resolve().parents[1]
src=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
ck('release id app', b'vBRDC113' in (ROOT/'Sources/Info.plist').read_bytes())
ck('release id topshelf', b'vBRDC113' in (ROOT/'TopShelfExtension/Info.plist').read_bytes())
ck('marketing app', b'1.0.816' in (ROOT/'Sources/Info.plist').read_bytes())
ck('build app', b'<string>816</string>' in (ROOT/'Sources/Info.plist').read_bytes())
ck('project marketing', 'MARKETING_VERSION: 1.0.816' in (ROOT/'project.yml').read_text())
ck('project build', 'CURRENT_PROJECT_VERSION: 816' in (ROOT/'project.yml').read_text())
for name in ['playerVisualTree','playerLifecycleTree','playerInputTree','playerOverlayStateTree','playerPlaybackStateTree','playerTimelineStateTree','playerCommandTree']:
    ck('stage '+name, name in src)
ck('body delegates only', re.search(r'var body: some View \{\s*playerCommandTree\s*\}', src) is not None)
ck('bluetooth coordinator retained', 'BluetoothVODMediaButtonCoordinator.shared.claimVODSession' in src)
ck('bluetooth release retained', 'BluetoothVODMediaButtonCoordinator.shared.releaseVODSession' in src)
ck('bluetooth receive retained', '.debridBluetoothVODMediaCommand' in src)
ck('swiftui duplicate guard retained', 'shouldSuppressSwiftUIPlayPause()' in src)
ck('visual root still focus section', 'private var playerVisualTree: some View' in src and '.focusSection()' in src)
ck('exit command retained', '.onExitCommand {' in src)
ck('scene phase retained', '.onChange(of: scenePhase)' in src)
ck('controls visibility retained', '.onChange(of: controlsVisible)' in src)
ck('first frame retained', '.onChange(of: isFirstFrameReady)' in src)
failed=[n for n,v in checks if not v]
print(f'{len(checks)-len(failed)}/{len(checks)} PASS')
for n,v in checks: print(('PASS ' if v else 'FAIL ')+n)
sys.exit(1 if failed else 0)
