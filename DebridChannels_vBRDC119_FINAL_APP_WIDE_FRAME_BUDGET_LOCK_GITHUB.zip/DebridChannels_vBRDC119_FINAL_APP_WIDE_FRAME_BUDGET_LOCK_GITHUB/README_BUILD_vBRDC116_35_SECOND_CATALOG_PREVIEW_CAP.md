# vBRDC116 — 35-Second Catalog Preview Cap

Release: vBRDC116
Marketing version: 1.0.819
Apple build: 819
Donor: packaged vBRDC115

## Scope
Focused catalog-card previews only.

- Keeps the existing 1.5-second settled-focus dwell.
- Keeps previews muted and capped to 1280x720.
- Caps active focused-card preview playback at 35 seconds.
- If a trailer asset ends before 35 seconds, the preview ends naturally.
- Removes the vBRDC107 in-place trailer loop.
- Fades back to the card artwork after completion.
- Remembers completion for the current catalog identity so same-title Media Profile UI publications do not immediately restart the preview.
- Moving to another catalog identity clears that completion ownership and permits the next card's preview.
- Manually launched Trailer playback remains unrestricted and separate.

## Non-scope
No changes to MediaFlow Proxy routing, Live TV/Gracenote, catalog row scrolling/open-close transitions, VOD playback, Bluetooth media controls, Dynamic Wallpaper, providers, resume, or backend runtimes.
