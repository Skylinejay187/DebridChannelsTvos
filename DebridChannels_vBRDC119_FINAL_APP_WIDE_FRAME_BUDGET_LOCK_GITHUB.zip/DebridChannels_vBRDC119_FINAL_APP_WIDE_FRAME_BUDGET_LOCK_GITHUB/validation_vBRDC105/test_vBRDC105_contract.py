from pathlib import Path
import plistlib, sys
import re
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def section(text, a, b):
    i=text.find(a)
    if i < 0: return ''
    j=text.find(b, i+len(a))
    return text[i:] if j < 0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f: return plistlib.load(f)
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC105' and toppl.get('DebridChannelsReleaseID')=='vBRDC105')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.808' and toppl.get('CFBundleShortVersionString')=='1.0.808')
ck('build', apppl.get('CFBundleVersion')=='808' and toppl.get('CFBundleVersion')=='808')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.808')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 808')==2)

root_playback=section(APP,'.onChange(of: store.playbackURL) { value in','        .onChange(of: scenePhase)')
recovery=section(APP,'private func schedulePostPlaybackExitRecovery(reason: String)','private func synchronizeUnityCatalogBranchPresentation')
live=section(APP,'struct LiveTVScreen: View','private struct LiveTVGridTileContent: View')
restore_schedule=section(APP,'private func scheduleLiveTVFocusRestore(reason: String)','private func restoreLiveTVFocusFallback()')
restore_scroll=section(APP,'private func performLiveTVRestoreScroll(proxy: ScrollViewProxy, targetID: Int)','private func scheduleLiveTVScheduleBoundaryRefresh')
preview=section(APP,'// vBRDC105: one-shot Live TV grid focus preview','private func scheduleLivePreviewWarmup')
play=section(APP,'private func play(channel: LiveTVChannel)','static let sampleChannels')
tile=section(APP,'private struct LiveTVGridFocusPreviewSurface: View','private struct LiveTVGridTileArtwork: View')
settings=section(APP,'private var liveTVSourcesSection: some View','private func liveTextField')

# Live TV fast-return path
ck('live return detected by focus snapshot', 'let returningToLiveTV = store.liveTVFocusSnapshot != nil' in root_playback)
ck('catalog premium rehydration skipped on live return', 'if !returningToLiveTV {' in root_playback and 'PremiumArtworkRehydrationCoordinator.shared.force' in root_playback)
ck('dedicated fast return branch', 'if returningToLiveTV {' in recovery and 'Live TV already has a precise store-owned channel/category/window' in recovery)
ck('one root focus nudge', recovery.count('store.liveTVFocusRestoreToken &+= 1')==2) # one fast lane + one legacy VOD checkpoint body
ck('fast lane does not call catalog recovery', 'recoverCatalogInteractivity' not in section(recovery,'if returningToLiveTV {','// vBRDC078: VOD dismissal'))
ck('fast lane no premium rehydration', 'PremiumArtworkRehydrationCoordinator' not in section(recovery,'if returningToLiveTV {','// vBRDC078: VOD dismissal'))
ck('post-return network delayed', '220_000_000' in recovery and 'returned from Live TV playback' in recovery)
ck('playback-return mount gates artwork bootstrap', 'if !restoringFromPlayback {' in live and 'beginForcedLiveTVArtworkBootstrap(reason: "Live TV root mounted")' in live)
ck('playback-return mount gates guide refresh', 'if !restoringFromPlayback { scheduleLiveTVScheduleBoundaryRefresh(reason: "grid appear") }' in live)
ck('playback-return mount gates live refresh', 'if restoringFromPlayback {' in live and 'startLiveTVRefreshIfActive(reason: "grid appear")' in live)
ck('late focus token cannot jump first channel', 'guard store.liveTVFocusSnapshot != nil else {' in restore_schedule and 'if tileFocus == nil, guideFocus == nil' in restore_schedule)
ck('restore uses animation-free structure transaction', 'structureTransaction.animation = nil' in restore_schedule)
ck('restore old 18 poll removed', '0..<18' not in restore_schedule)
ck('restore old 5 focus retries removed', '1...5' not in restore_schedule)
ck('restore bounded to four short waits', '0..<4' in restore_schedule and '32_000_000' in restore_schedule)
ck('restore two-pass scroll', restore_scroll.count('proxy.scrollTo(targetID, anchor: .center)')==2)
ck('restore fourteen-scroll loop removed', '0..<14' not in restore_scroll)
ck('focus first then bootstrap', restore_schedule.find('store.liveTVFocusSnapshot = nil') < restore_schedule.find('beginForcedLiveTVArtworkBootstrap(reason: "post-playback focus restored")'))
ck('guide preview suppressed during focus return', 'previewPlaybackSuppressed = restoringFromPlayback' in live and 'if !previewPlaybackSuppressed { scheduleLivePreviewWarmup' in live)

# Grid focus preview strict session contract
ck('preview setting AppStorage live screen', '@AppStorage("liveTVGridFocusPreviewEnabledV1") private var liveTVGridFocusPreviewEnabled: Bool = true' in live)
ck('preview arm task state', '@State private var gridFocusPreviewArmTask: Task<Void, Never>? = nil' in live)
ck('preview stop task state', '@State private var gridFocusPreviewStopTask: Task<Void, Never>? = nil' in live)
ck('exact 3 second dwell', '3_000_000_000' in preview)
ck('exact 15 second wall ceiling', '15_000_000_000' in preview)
ck('no preview retry loop', re.search(r'\bfor\s+\w+\s+in\b|\bwhile\s+', preview) is None)
ck('decoder suppression check', 'AuxiliaryVideoPlaybackCoordinator.shared.isAuxiliaryPlaybackSuppressed()' in preview)
ck('preview only live tab', 'store.selectedTab == .live' in preview)
ck('preview only grid not guide', '!showGuide' in preview)
ck('preview blocked by tools', '!quickWindowVisible' in preview)
ck('preview blocked by channel action', 'channelActionChannelID == nil' in preview)
ck('preview requires exact focused channel', 'tileFocus == channelID' in preview)
ck('focus change cancels preview', 'cancelLiveTVGridFocusPreview()' in section(live,'.onChange(of: tileFocus)','private func performLiveTVRestoreScroll'))
ck('focus change arms preview', 'scheduleLiveTVGridFocusPreview(for: value)' in section(live,'.onChange(of: tileFocus)','private func performLiveTVRestoreScroll'))
ck('leaving live cancels preview', 'if tab != .live { cancelLiveTVGridFocusPreview() }' in live)
ck('playback cancels preview', 'cancelLiveTVGridFocusPreview()' in play)
ck('preview is muted', 'muteAudio: true' in tile)
ck('preview uses isolated auxiliary marker', '.marksAuxiliaryVideoActivity(true)' in tile)
ck('preview rendered only focused tile', 'if let previewURL, isFocused {' in tile)
ck('preview playback URL uses live MediaFlow route', 'MediaFlowProxyRouter.playbackURLIfAllowed(for: originalURL, kind: .liveTV)' in preview)
ck('dynamic wallpaper pauses during preview', '&& gridFocusPreviewChannelID == nil' in live)
ck('full playback waits only for auxiliary handoff', 'await waitForAuxiliaryVideoHandoffIfNeeded(reason: "Live TV grid/guide preview → full playback")' in play)
ck('full playback validates saved target', 'store.liveTVFocusSnapshot?.playedChannelID == channel.id' in play)

# Settings / backup / restore / reset
ck('settings toggle present', 'Live TV Focus Preview' in settings and '$liveTVGridFocusPreviewEnabled' in settings)
ck('settings explains 3 and 15 seconds', 'exactly 3 seconds' in settings and '15-second channel preview' in settings)
ck('settings says no retry hunting', 'there is no retry or background preview hunting' in settings)
ck('settings focus enum', 'liveGridFocusPreviewToggle' in APP)
ck('backup includes preview setting', '"liveTVGridFocusPreviewEnabledV1": liveTVGridFocusPreviewEnabled' in APP)
ck('restore includes preview setting', 'settings["liveTVGridFocusPreviewEnabledV1"] as? Bool' in APP)
ck('stable reset enables preview', 'liveTVGridFocusPreviewEnabled = true' in APP)

# Preserve v103/v104 movement fixes
livegrid=section(APP,'private func liveGrid(size: CGSize)','private func performLiveTVRestoreScroll')
ck('normal live grid still no per-focus proxy scroll', 'proxy.scrollTo(value, anchor: .center)' not in livegrid)
ck('persistent catalog v104 remains', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)
ck('row scrolling visual system untouched by this build', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
