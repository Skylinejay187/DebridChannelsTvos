from pathlib import Path
import hashlib, plistlib, re, sys, yaml
ROOT = Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
CAT=(ROOT/'Sources/CatalogStore.swift').read_text()
NUV=(ROOT/'Sources/NuvioPluginClient.swift').read_text()
FEB=(ROOT/'Sources/BackupStreamingClient.swift').read_text()
UNITY=(ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
SYSTEM=(ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
PROJECT=yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(n,c): checks.append((n,bool(c)))
def pl(rel):
    with open(ROOT/rel,'rb') as f:return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release vBRDC098', app.get('DebridChannelsReleaseID')=='vBRDC098' and top.get('DebridChannelsReleaseID')=='vBRDC098')
ck('marketing 1.0.801', app.get('CFBundleShortVersionString')=='1.0.801' and top.get('CFBundleShortVersionString')=='1.0.801')
ck('build 801', app.get('CFBundleVersion')=='801' and top.get('CFBundleVersion')=='801')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.801')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='801')

root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
art_ids=section(live,'private func liveTVArtworkLoadIDs(in mountedChannels: [LiveTVChannel]) -> Set<Int>','private func scheduleGuideHintAutoHide')
sync=section(live,'private func synchronizeLiveTVSelectionWithPublishedLineup','private func scheduleLiveTVSelectionPersistence')
appear=section(live,'.onAppear {','.onChange(of: store.guideStartupRequestToken)')
selected=section(live,'.onChange(of: store.selectedTab) { tab in','.onChange(of: store.liveTVFocusRestoreToken)')
cold=section(live,'private func scheduleLiveTVColdStartHydrationIfNeeded','private func startLiveTVRefreshIfActive')
active=section(live,'private func startLiveTVRefreshIfActive','private var liveWallpaperOwnsRenderBudget')
art=section(APP,'private struct LiveTVGridTileArtwork','private struct LiveTVGridTileFooter')
loader=section(APP,'private final class LiveTVBoundedArtworkLoader','private struct LiveTVQuickGuideContainedArtworkFrame')

# Core zero-scroll fix
ck('zero-scroll selection helper exists', 'synchronizeLiveTVSelectionWithPublishedLineup(reason:' in live)
ck('onAppear repairs provider selection immediately after load', 'liveModel.loadCachedOrDemo()' in appear and appear.find('liveModel.loadCachedOrDemo()') < appear.find('synchronizeLiveTVSelectionWithPublishedLineup(reason: "grid appear lineup")'))
ck('entering Live repairs provider selection before work', 'synchronizeLiveTVSelectionWithPublishedLineup(reason: "Live tab selected")' in selected)
ck('active refresh repairs lineup anchor', 'synchronizeLiveTVSelectionWithPublishedLineup(reason: "active refresh publication")' in active)
ck('cold hydration repairs lineup anchor', 'synchronizeLiveTVSelectionWithPublishedLineup(reason: "cold-start guide hydration complete")' in cold)
ck('helper recognizes demo-id mismatch', 'demo ID 6003' in sync and 'stable hashed/provider IDs' in sync)
ck('helper restores All for invalid/empty category', 'selectedCategory = "All"' in sync)
ck('helper prefers persisted/snapshot identity', all(x in sync for x in ['liveTVLastSelectedChannelID','playedChannelID','focusedChannelID']))
ck('helper repairs selected channel', 'selectedChannelID = target.id' in sync)
ck('helper repairs virtual window', 'resetVirtualChannelWindow(to: target.id)' in sync)
ck('helper restores focus without animation', 'transaction.animation = nil' in sync and 'tileFocus = target.id' in sync)
ck('artwork corridor never requires a focus hit', '}.first ?? 0' in art_ids)
ck('old empty-on-invalid-focus guard removed', 'guard let focusedIndex' not in art_ids)
ck('artwork corridor checks focus selection persisted IDs', all(x in art_ids for x in ['tileFocus','guideFocus','selectedChannelID','liveTVLastSelectedChannelID']))
ck('artwork bootstrap begins at first mounted row', 'finally bootstrap from' in art_ids and 'first mounted row' in art_ids)
ck('artwork corridor still Live-only', 'guard store.selectedTab == .live else { return [] }' in art_ids)
ck('bounded corridor remains +/-3 rows', 'focusedRow - 3' in art_ids and 'focusedRow + 3' in art_ids)

# v097 cold-start protections remain
ck('artwork refresh token retained', '@State private var liveTVArtworkRefreshToken' in live)
ck('mounted tile reacts to refresh token', '.onChange(of: refreshToken)' in art and 'resetFailedURLsForAuthoritativeRefresh()' in art)
ck('image networking waits for connectivity', 'configuration.waitsForConnectivity = true' in loader)
ck('artwork transient retry retained', '650_000_000' in loader)
ck('cold guide hydration retained', '@State private var liveTVColdStartHydrationTask' in live and 'scheduleLiveTVColdStartHydrationIfNeeded()' in appear)
ck('active refresh wakes mounted cards', 'liveTVArtworkRefreshToken &+= 1' in active)
ck('fallback ladder unchanged', art.find('program?.imageURL') < art.find('channel.iconURL') < art.find('providerChannelPosterURL'))
ck('covered bitmap preservation unchanged', 'artworkLoader.suspendPreservingImage()' in art and 'preserveCurrentImage: true' in art)

# UNITY/performance locks
ck('one physical LiveTVScreen', len(re.findall(r'\bLiveTVScreen\(\)',APP))==1)
ck('no frozen synthetic donor', 'FrozenLiveTVBackdrop' not in APP)
ck('24 covered corridor retained', 'coveredRenderedChannelLimit: Int = 24' in live)
ck('96 interactive corridor retained', 'interactiveRenderedChannelLimit: Int = 96' in live)
ck('Pulse Glow setting retained', 'Focused Card Pulse Glow Animation' in APP)
ck('post-navigation recovery retained', 'postNavigationVisualRecoveryActive' in UNITY)
ck('UNITY synthetic-donor rejection retained', 'synthetic donor' in SYSTEM)
ck('connected popup prewarm retained', 'scheduleConnectedArtworkPrewarm' in APP and 'maxPixelSize: 2048' in APP)
ck('wallpaper phase preservation retained', 'paused: wallpaperMotionPausedForNavigation' in APP)

# v097 source readiness unchanged byte-for-byte
DONOR={
'Sources/CatalogStore.swift':'3e907cec8ef189592dbec20273f1daa6e799a692be31a727d7532177b621e6c4',
'Sources/NuvioPluginClient.swift':'94a3196403f26e8edad215029b26191e3941d7fb14a5fc5ac60fe29801a90a75',
'Sources/BackupStreamingClient.swift':'251dc138dbd14fc476c76bc6a765f85643df083a5c94196d54fc0148337346cd',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/RemoteImageFit.swift':'093c1c108270e746e463c6ff72b018af4eb62e19afaeaa894947fe38f3518f0f',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
}
for rel,h in DONOR.items(): ck('donor '+rel, sha(rel)==h)

# Source manifest coverage
entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('all Swift sources declared', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
