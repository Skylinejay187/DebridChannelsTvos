# Debrid Channels vBRDC061 — UNITY / Restore Main VOD Deep Buffer

- Release ID: **vBRDC061**
- Marketing version: **1.0.764**
- Apple build: **764**
- Code Name: **UNITY**
- Built only from packaged **vBRDC060**
- Backend target: **v693 unchanged**

## Why this build exists

Physical Apple TV testing of vBRDC060 reported that normal movie/episode playback was not building the forward buffer expected from earlier Debrid Channels playback builds.

A source audit confirms **vBRDC058, vBRDC059, and vBRDC060 all carry the exact same PlaybackKit file**. vBRDC060 did not introduce a new buffering change. The currently inherited VOD profile came from **vBRDC049**, where the main KSPlayer VOD maximum packet-buffer ceiling was reduced from **300 seconds (5 minutes)** to **30 seconds** for memory/graphics-stability reasons.

## vBRDC061 correction

Restore only the old main-VOD maximum buffer ceiling:

- Ordinary KSPlayer VOD preferred startup/forward threshold: **5 seconds** — unchanged.
- High-memory VOD (4K/UHD/remux/TrueHD/DTS-HD) preferred threshold: **3 seconds** — unchanged.
- Main VOD maximum packet-buffer/cache-ahead ceiling: **30 seconds → 300 seconds**.
- Trailer buffer profile: unchanged.
- Live TV buffer profile: unchanged.
- Native AVPlayer profile: unchanged (VOD currently requests 180 seconds for non-HLS / 60 seconds for HLS and waits to minimize stalling).

This restores the pre-vBRDC049 deep-buffer ceiling without rolling back the vBRDC049 KSPNUVIO CircularBuffer leak fix, decoder-thread protections, HDR safety, Skip Intro work, Unity navigation, or the vBRDC060 TorBox Usenet/Torrentio separation.

## Important physical-test note

A 300-second packet-buffer ceiling can use substantially more memory on very high-bitrate remuxes than the 30-second cap. vBRDC061 deliberately restores it because the requested behavior is the older deep buffering profile. Apple TV physical testing should verify both:

1. the progress/buffer state again grows substantially ahead during normal VOD playback; and
2. long 4K/remux playback does not reintroduce memory-pressure or graphics instability.

GitHub Actions/Xcode remains authoritative for the complete tvOS compile.
