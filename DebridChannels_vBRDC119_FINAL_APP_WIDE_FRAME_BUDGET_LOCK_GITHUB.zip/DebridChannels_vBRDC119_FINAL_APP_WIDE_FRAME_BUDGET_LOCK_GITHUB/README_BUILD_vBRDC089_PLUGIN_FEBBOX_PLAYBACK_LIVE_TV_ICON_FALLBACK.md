# Debrid Channels vBRDC089 — In-S / FebBox Playback Parity + Live TV Icon Fallback

**Marketing version:** 1.0.792  
**Apple build:** 792  
**Release ID:** vBRDC089  
**Donor:** packaged vBRDC088 only

## Why this build exists

Physical testing showed two independent problems:

1. **In-S/Nuvio plugin and FebBox/Shoebox links could resolve and display in Source Intelligence but fail when selected for playback**, even though the same provider result plays in Nuvio.
2. **Live TV grid cards could remain black/placeholder when Gracenote/program artwork was absent or failed**, instead of falling back to the channel's own icon/logo.

vBRDC089 fixes both without changing the established visual design.

## In-S / Nuvio plugin playback correction

The root playback mismatch was request-context loss. Provider results can carry request headers required by the final media host, including `Referer`, `Origin`, `Cookie`, `Authorization`, or a provider-specific `User-Agent`. The previous bridge could resolve the URL but discard that context before KSPlayer/AVFoundation/FFmpeg opened the media request.

vBRDC089 adds a session-scoped request-header contract to `StreamLink` and preserves it through:

- In-S/Nuvio plugin resolution
- regular Stremio add-on `behaviorHints.proxyHeaders.request`
- Source Intelligence manual selection
- automatic Play selection
- Phase 15 source selection
- Up Next source preparation
- adaptive/automatic source failover
- MediaFlow wrapping
- KSPlayer AVURLAsset and FFmpeg paths
- the manual AVPlayer compatibility path
- display-match media inspection

Fallback URLs retain their own header maps, so switching providers cannot accidentally reuse the previous provider's cookie/referer context.

### In-S response compatibility

The plugin decoder now accepts the common provider forms used in Nuvio-style runtimes:

- `headers`
- `httpHeaders`
- `requestHeaders`
- `behaviorHints.proxyHeaders.request`
- `behaviorHints.videoSize`
- `videoSize`
- `fileSize`
- `sizeBytes`
- `size`
- `filename`

Unsafe framing headers (`Host`, `Content-Length`, transfer/content range headers, etc.) are filtered before playback.

## FebBox / Shoebox correction

FebBox-backed sources need the same authenticated request context at playback time that was used during source resolution.

vBRDC089 therefore:

- keeps the private FebBox `ui` cookie local to the Apple TV credential store;
- never returns that secret cookie from the backend response;
- reconstructs the final `Cookie: ui=...; oss_group=...` header only at the playback edge;
- preserves safe `Referer`, `Origin`, `User-Agent`, and other provider request hints;
- carries those headers through KSPlayer, AVPlayer, MediaFlow, and source failover.

For In-S results identified as FebBox/Shoebox/ShowBox-backed, the same local FebBox credential is applied to the final media request when the provider did not already supply a Cookie header.

## Source metadata correction

Stream cards now prefer actual provider metadata over filename guessing.

In-S size resolution checks real byte/size fields first and understands raw byte counts plus human-readable KB/MB/GB/TB values. Quality can also be recovered from provider title/filename/description metadata when the explicit quality field is missing.

Native FebBox parsing now reads explicit file metadata attributes (`data-size`, `data-filesize`, `data-file-size`, `data-bytes`) and player-source size fields before falling back to filename parsing.

## Live TV grid Gracenote -> channel icon fallback

The Live TV artwork ladder is now explicitly locked:

1. real current-program/Gracenote artwork;
2. the channel's own icon/logo;
3. optional provider now-playing artwork only when a usable channel icon is unavailable;
4. generated channel poster as the final fallback.

A second bug was also fixed: a valid-looking Gracenote URL that returned 404/invalid image data could leave a card stuck on a black loading state forever. `LiveTVBoundedArtworkLoader` now remembers genuine fetch/decode failures for the mounted card and immediately advances to the next artwork candidate. Cancellation and full-screen playback suspension are not treated as failures.

This directly covers channels such as the reported KTLA card: no Gracenote artwork must no longer mean a black card when the channel icon exists.

## Privacy / credential boundary

- Plugin bridge URLSession uses no shared HTTP cookie storage.
- FebBox backend responses deliberately exclude the private `ui` Cookie.
- Backend-supplied Cookie headers cannot override the Apple TV's locally owned FebBox credential.
- MediaFlow receives destination headers through its upstream `h_*` parameters; destination cookies are not redundantly sent to the MediaFlow host itself.

## Prior regression locks retained

The vBRDC088 app-wide scrolling/frame-budget fixes remain intact, including bounded card decode sizes and stable connector geometry.

The following previously fixed behavior is also retained:

- vBRDC087 Connected Popup single-artwork ownership and Pulse/Media Information isolation
- vBRDC086 Favorites identity handoff cleanup
- vBRDC085 Find Links automatic resume/play assertion and Production metadata decoupling
- existing Source Intelligence, TorBox/Usenet, UNITY lifecycle, and resume-cache behavior outside this targeted scope

## Validation

- vBRDC089 contract: **85/85 passed**
- Swift syntax parse: **64/64 passed**
- Backend regression suites: **36 tests passed + 2 subtests passed**
- App + TopShelf plists: **valid**
- Version alignment: **vBRDC089 / 1.0.792 / 792**
- Donor source/config/backend scope audit: **13/13 intended files, 0 unexpected**
- Final ZIP integrity + packaged SHA-256 manifest verification: **passed**

GitHub Actions/Xcode remains the authoritative Apple SDK compile. Physical Apple TV testing remains authoritative for protected-provider playback, CDN request behavior, and Live TV artwork rendering.
