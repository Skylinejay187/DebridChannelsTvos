# Debrid Channels vBRDC083 — Dynamic Wallpaper Visibility / Native 4K / Nexus Lines

**Release ID:** vBRDC083  
**Marketing version:** 1.0.786  
**Apple build:** 786  
**Donor:** packaged vBRDC082 only

## Scope
This build is intentionally isolated to the Dynamic Live Wallpaper / Appearance implementation plus version identifiers. It does not change PlaybackKit, resume persistence, Source Intelligence, TorBox Usenet, UNITY animation coordination, UNITY surface lifecycle coordination, CatalogStore, or backend runtimes.

## Visibility
- Raises the Live TV dynamic wallpaper presentation opacity from 0.74 to 0.94.
- Reduces the dark readability veil from 0.10/0.24 to 0.04/0.10.
- Procedural Canvas output uses a screen blend, modest brightness/saturation lift, and an 0.86–0.95 internal opacity envelope.
- Digital Rain glyphs and heads receive their own visibility increase so code remains readable from normal Apple TV viewing distance.

## Nexus Lines
Adds **Nexus Lines** as a built-in procedural UNITY theme. It uses independent red/green/blue/yellow luminous heads and fading trails moving along horizontal and vertical lanes. The effect is generated natively in Canvas; no third-party wallpaper image/video asset is bundled.

## Custom animated wallpaper / native 4K
- GIF/WebP no longer decode into a 720/960px frame array.
- The renderer targets the Apple TV output long edge, up to 3840 pixels on Apple TV 4K.
- GIF/WebP are streamed one decoded frame at a time instead of retaining the animation in memory.
- Compatibility/Balanced/High Performance cap animated image presentation at 12/18/24 fps respectively while keeping native output resolution.
- MP4/MOV/M4V remain AVFoundation/AVPlayerLayer hardware playback with aspect-fill.
- Custom assets are edge-to-edge aspect-fill.
- HTTPS-only remote assets remain locally cached; the on-disk cap increases from 32 MB to 96 MB to accommodate UHD animated assets.

## Resource isolation
The existing hard wallpaper ownership gate remains unchanged: dynamic wallpaper is conditionally unmounted for playback, detail screens, Search, guides and covered surfaces, and it still requires a UNITY `.dynamicWallpaper` animation permit. Playback has priority.

## Validation
See `FINAL_VALIDATION_vBRDC083.txt` and `validation_vBRDC083/`.
