# Debrid Channels vBRDC103 — Persistent UNITY Scroll Engine

- Release ID: `vBRDC103`
- Marketing version: `1.0.806`
- Apple build: `806`
- Donor: packaged `vBRDC102_UNITY_FRAME_RUNTIME`

## Why this build exists

Physical Apple TV testing showed vBRDC102 felt essentially unchanged. The vBRDC102 frame runtime coordinated permissions around the existing renderer, but the expensive physical SwiftUI behavior underneath it was still present. vBRDC103 changes that renderer path directly rather than adding another timing wrapper.

## Persistent catalog rail

Home, Movies, TV Shows, Favorites and Sports now use one persistent fixed-slot rail tree. Horizontal navigation no longer destroys/recreates the focused card and all trailing preview cards by media ID. Preview cards are stable depth slots, and the focused slot changes its `MediaItem` input in place.

The existing 48 row-motion presets are retained. Their original animation timings and transition definitions remain present unchanged; the persistent rail uses the exact existing insertion transform values as compositor-only arrival transforms instead of SwiftUI insertion/removal identity churn.

The old selected-index implicit animation is removed so a D-pad change does not animate every descendant state mutation in the rail.

## Stable artwork ownership

The following visible artwork owners no longer use changing media IDs/URLs as SwiftUI identity:

- catalog main backdrop
- catalog depth artwork
- Artwork/Hero logo content
- focused catalog card artwork/logo
- preview card artwork
- Favorites full-screen backdrop
- Sports full-screen theme backdrop

`RemoteImageFit` therefore keeps the previous decoded frame until the replacement is ready instead of losing its StateObject during focus changes.

## Global invalidation isolation

vBRDC102 accidentally made large surfaces observe the global animation coordinator. Every navigation begin/settle could therefore invalidate RootView and hidden/persistent surfaces.

vBRDC103 removes that subscription from:

- RootView
- Top Menu
- Global Search
- the full catalog overlay
- the catalog rail shell
- the retained Live TV/Gracenote grid

Only small leaf views that actually need live animation permission still observe it, such as focused-card pulse/preview, Dynamic Wallpaper, detail motion and tickers.

Dynamic Wallpaper is isolated in its own tiny UNITY-observing wrapper so it can still pause during Live TV navigation without forcing the Live TV grid to recompute.

## Native tvOS scrolling ownership

The app no longer overlays a second programmatic scroll animation on top of native focus scrolling in these interactive paths:

- Live TV grid focus navigation
- Live TV full Guide/Gracenote timeline focus navigation
- VOD playback control chip navigation
- VOD player option panel navigation

Explicit one-time/off-screen restore scrolls are retained where needed, including Live TV playback-return restoration and initial player-panel positioning.

## Vertical row navigation

The catalog row shell no longer remounts when moving Up/Down. The previous 0/55/150 ms repeated row-focus assertions are replaced by one render-turn focus bind because the focusable rail now survives row changes.

## Sports and Favorites

Sports uses the same persistent rail, stable backdrop owner, and navigation ownership as the main catalog. Favorites uses the same persistent rail and a retained-frame 4K-capped backdrop owner.

## Preserved systems

This build does not remove or redesign the existing:

- Artwork/Hero themes
- 48 catalog row-motion presets
- static wallpaper system
- Dynamic Wallpaper presets/custom wallpaper path
- Live TV grid layout/categories
- Gracenote/XMLTV/Xtream guide data
- Sports visual branch
- Search layout
- VOD overlay visual design
- playback/provider/Usenet/source-intelligence logic
- vBRDC100 seamless Cast + Production & Ratings rotations
- vBRDC101 Artwork 4 / Hero 2 retained-artwork and handoff corrections
- vBRDC102 provider/model publication frame gates

## Validation

Static/package validation can prove source structure and regression locks, but physical Apple TV testing remains authoritative for actual frame pacing. vBRDC103 intentionally makes materially different physical renderer changes from vBRDC102; it does not claim literal zero dropped frames under all tvOS/network/memory conditions.
