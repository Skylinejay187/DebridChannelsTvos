# Debrid Channels vBRDC073 — TorBox Usenet Crash + Resume Recovery

- Release ID: **vBRDC073**
- Marketing version: **1.0.776**
- Apple build: **776**
- Code Name: **UNITY**
- Donor: packaged **vBRDC072** only
- Donor ZIP SHA-256: `d3db688484fe2d4ad7075a9a6ca6a9101df3883e60f19263a6bbff158b873570`
- Backend: **v694 unchanged**

## Physical vBRDC072 crash fixed at the session-ownership boundary

Three supplied vBRDC072 Apple TV IPS reports share the same SIGABRT/Objective-C exception inside `__NSURLSessionLocal taskForClassInfo` while native TorBox Usenet is creating a URLSession task. The third report reaches the same exception through the TorBox Voyager DoH fallback.

vBRDC073 no longer calls `invalidateAndCancel()` on the shared Source Intelligence URLSession while a retained async search can still reference it. Search/lifecycle cancellation now rotates new work to a fresh ephemeral session, cancels outstanding tasks on the retiring session without invalidating that session object, and explicitly owns/cancels the native TorBox Usenet Task.

TorBox network retry/fallback code now preserves `CancellationError`, checks cancellation before creating each request, and cannot turn a cancelled route into another retry/DoH/library request.

## TorBox Usenet zero-link correction

vBRDC072 could interpret a valid Newznab `<error/>` XML response as a successful search with zero rows because XMLParser correctly returned `true`. vBRDC073 captures Newznab service-error attributes and surfaces them as a real discovery failure instead of a false zero.

Discovery also now:

- searches both Newznab media/ID mode and plain `q=` query mode;
- merges and deduplicates both result sets;
- converts relative Newznab `t=get`/grab URLs into absolute TorBox Search URLs;
- keeps the vBRDC072 rule that native TorBox Usenet rows bypass the ordinary Best-Ranked 25/50 cap;
- keeps Newznab direct -> backend v694 relay -> legacy compatibility -> owned Main API library fallback;
- keeps NZB-link handoff -> authenticated in-memory NZB upload fallback -> TorBox Main API download -> final playable CDN URL.

No Torrentio state is consulted by native TorBox Usenet. The effective TorBox credential remains the only account credential gate.

## Automatic VOD resume repaired

The durable resume cache was still present in vBRDC072, but startup could lose the actual resume seek. vBRDC072 waited a fixed delay, recreated the KSPlayer surface with `startPlayTime`, then immediately cleared the pending resume target and declared success without verifying the decoder clock. If the reload/start-time command raced surface creation, playback remained at 0:00 even though the app believed resume had completed.

vBRDC073 changes only the resume-application path:

- the existing `playback-resume-v1119.json` storage format and per-title/source alias behavior are preserved;
- a real KSPlayer decoder-clock callback proves the surface is mounted before the automatic absolute seek is issued;
- automatic resume uses the existing in-place KSPlayer seek serial and does **not** recreate KSPlayer or increment the surface reload token;
- the saved target stays pending and protected from a temporary 0:00 checkpoint until the authoritative player clock lands within keyframe tolerance of the target;
- failed/ignored startup seeks can be retried in-place up to a bounded limit;
- AVPlayer marks automatic resume complete only after its seek completion callback;
- the manual Resume backup remains available if a particular source refuses seek commands.

The VOD screen remains keyed by playback presentation ID + source URL, so normal Play and Find Links/source changes receive a fresh resume attempt while reusing the same durable title/episode checkpoint.

## Explicitly preserved from vBRDC072

- all 8 account-scoped debrid/Torrentio credential boundaries;
- native TorBox Usenet independent of Torrentio;
- all valid native TorBox Usenet rows remain uncapped;
- Sports UNITY hero/theme integration;
- all 48 catalog row scrolling motion presets;
- vBRDC069 adaptive large-file VOD memory buffer;
- `PlaybackKitKSPlayerSurface.swift` unchanged;
- `PlaybackResumeCache.swift` unchanged;
- `UnityCatalogVisualSystem.swift` unchanged;
- Sports runtime source unchanged;
- backend v694 runtime unchanged;
- Live TV/Sports direct tune, FebBox, MediaFlow, In-S and existing provider behavior.

## Validation

- 62/62 Swift source files syntax-parse with Swift 6.2.1;
- `TorBoxUsenetClient.swift` isolated Swift type-check passes;
- executable Newznab parser fixture confirms valid `<error/>` XML is not a false zero and relative grab links normalize;
- 14/14 vBRDC073 source contracts pass;
- 8-provider managed Torrentio/debrid runtime test passes, including TorBox native credential independence;
- 35/35 inherited backend runtime tests pass (7 TorBox relay + 8 Alternate Audio discovery + 15 Alternate Audio bridge + 5 backup streaming);
- shared Source Intelligence session has zero `invalidateAndCancel()` call sites;
- `PlaybackKitKSPlayerSurface.swift`, `PlaybackResumeCache.swift`, `UnityCatalogVisualSystem.swift`, and `SportsCenterViewModel.swift` are byte-identical to packaged vBRDC072;
- both plists + both XcodeGen target blocks report 1.0.776 / 776 / vBRDC073.

GitHub Actions/Xcode remains authoritative for the Apple SDK compile/link. Physical Apple TV testing is still required to verify real-account TorBox search/download behavior and decoder-clock resume behavior on-device.
