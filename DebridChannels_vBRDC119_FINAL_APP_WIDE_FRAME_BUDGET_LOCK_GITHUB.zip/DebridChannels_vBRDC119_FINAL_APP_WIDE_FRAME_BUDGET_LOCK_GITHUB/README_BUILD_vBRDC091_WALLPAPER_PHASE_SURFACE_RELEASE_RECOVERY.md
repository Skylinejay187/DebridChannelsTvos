# Debrid Channels vBRDC091 — Wallpaper Phase + Surface Release Recovery

**Marketing version:** 1.0.794  
**Apple build:** 794  
**Donor:** packaged vBRDC090 only

## Why this corrective build exists

Physical Apple TV testing showed two remaining problems after vBRDC090's frame-budget isolation:

1. Dynamic Live Wallpaper could visibly jump/glitch during Siri Remote movement even though navigation itself was smoother.
2. Visiting Sports or Favorites and then returning to Home/Movies/Shows could leave the destination feeling heavier/slower than it did before entering those surfaces.

The vBRDC091 audit found both were real lifecycle/resource ownership issues rather than a reason to remove the existing visuals.

## Wallpaper phase preservation

vBRDC090 correctly made wallpaper yield frame budget while the Siri Remote was actively navigating, but some wallpaper implementations interpreted that yield as a restart:

- GIF/WebP decoder work was cancelled on every navigation pause and restarted from frame zero.
- Procedural Canvas wallpaper used absolute TimelineView time, so resuming after a pause jumped forward by the entire yielded interval.
- Loop-video wallpaper could receive redundant AVPlayer play/pause commands from unrelated SwiftUI updates.

vBRDC091 changes the contract to **freeze presentation, preserve phase**:

- GIF/WebP keeps its decoder and exact frame index alive while navigation owns the compositor. It sleeps without publishing frames and resumes from the same sequence position.
- Procedural wallpaper subtracts accumulated paused time from its animation clock. The visual phase therefore continues from where it froze rather than jumping.
- MP4/MOV/M4V wallpaper deduplicates AVPlayer pause/play commands and changes player state only when ownership actually changes.
- The wallpaper still yields frame budget during remote navigation; this does not revert vBRDC090's scrolling protection.

## Sports return-performance root cause and fix

vBRDC090 removed the hidden reactive Live TV screen under Sports, but `SportsHubScreen` still created **another full `LiveTVSourceModel`** of its own. On entry it called `loadCachedOrDemo()`, which could materialize a second channel array, browse indexes and guide state simply so Sports could classify Live TV channels.

vBRDC091 removes that duplicate model entirely. Sports now reads a bounded retained process snapshot (maximum 600 channels) and the retained guide-program lookup directly. On exit it explicitly releases:

- its score/event model payloads,
- mapped Sports MediaItem rows,
- pending surface load task,
- decoded Sports artwork cache and in-flight Sports image requests.

Public Sports score/team network helpers also no longer inherit MainActor isolation; only final Sports view-model publication remains on MainActor.

The optional global Sports score model is now loaded at app bootstrap only when the Sports ticker is actually enabled. With the ticker Off (the default), there is no hidden global Sports schedule/network payload.

## Favorites return-performance root cause and fix

Sports/Favorites previously shared the same 96 MB decoded-artwork cache as Home/Movies/Shows. A short visit to a dedicated surface could therefore fill that cache with its posters/backgrounds and evict the warm catalog images. Returning Home then required fresh image decode/upload work during scrolling, which can feel like the destination permanently lost performance.

vBRDC091 introduces cache ownership domains:

- `persistent` — Home/Movies/Shows/normal retained artwork (existing 96 MB ceiling)
- `sports` — short-lived 28 MB decoded cache
- `favorites` — short-lived 28 MB decoded cache

Sports/Favorites can reuse an already-warm persistent image, but their new decodes cannot evict persistent catalog artwork. Their domains are cancelled and cleared on surface exit. Favorites-owned Media Information is kept in the Favorites domain too, including full-resolution popup artwork.

Favorites also drops its cached favorite MediaItem snapshot and coalesced rebuild task when the surface disappears.

## Frozen Live TV donor memory correction

The vBRDC090 frozen Live TV donor visually rendered only a small corridor, but it still retained a copied array of the entire real IPTV lineup. vBRDC091 adds a bounded corridor helper and retains only the **12 channels actually needed by the frozen donor** around the last selected channel.

This preserves the exact donor appearance while avoiding a hidden full-lineup copy on Home/Movies/Shows/Sports.

## Healthy catalogs no longer arm needless recovery work

The catalog-completeness watchdog now arms only when `CatalogStore` reports that official catalog rows actually need recovery. Returning from Sports/Favorites no longer schedules a delayed MainActor completeness pass when the loaded catalog is already complete.

## No visual redesign

This build intentionally changes no card geometry, typography, row layout, wallpaper presets, Pulse amplitude, Preview appearance, Media Information layout, Live TV tile design, Sports design, Favorites design or Quick Guide presentation.

The visible rule is simply:

> **Remote navigation gets frame priority, wallpaper preserves visual phase, and short-lived surfaces release the resources they own when they leave.**

## Provider compatibility scope

The vBRDC089 In-S / ShowBox / FebBox implementation remains donor-locked in this build. vBRDC091 does **not** claim to solve the provider failure. The local Nuvio-compatible provider runtime and native FebBox resolver work moves to the next provider-focused candidate so it can be tested independently from this frame/memory correction.

## Validation

- vBRDC091 architecture/regression contract: **79/79 passed**
- Swift syntax parse: **64/64 files passed**
- Backend pytest suite: **36 passed + 2 subtests passed**
- App and Top Shelf plists: valid
- `project.yml`: valid YAML
- vBRDC090 provider/playback/UNITY coordinator donor locks: passed
- Donor diff audit: only intended product/config files changed
- Final package hash and ZIP integrity checks included with the package
