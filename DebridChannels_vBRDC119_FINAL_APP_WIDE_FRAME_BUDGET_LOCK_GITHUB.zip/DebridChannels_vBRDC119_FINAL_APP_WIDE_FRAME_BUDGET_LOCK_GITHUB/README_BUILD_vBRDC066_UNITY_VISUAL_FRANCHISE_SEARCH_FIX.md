# vBRDC066 — UNITY Visual Overhaul + Search Return + Compact Franchise Ribbon

- Release ID: **vBRDC066**
- Marketing version: **1.0.769**
- Apple build: **769**
- Code Name: **UNITY**
- Built only from packaged **vBRDC065** source lineage
- Backend target: **v693 unchanged**

## Scope

vBRDC066 is deliberately a UI/search regression build. It does **not** alter KSPlayer playback, VOD cache-ahead, matched-frame-rate A/V work, the vBRDC064 IDET crash patch, TorBox provider code, or the vBRDC065 XMLTV watchdog worker.

### 1. Search cannot remain stuck after returning from a searched VOD title

`GlobalSearchScreen` remains mounted underneath Search-origin Media Information and playback. A return from VOD therefore does not always trigger a fresh `onAppear`. vBRDC066 explicitly watches the actual playback URL transition back to `nil`, reconciles the existing VOD-exclusive gate, clears stale search progress state, and restarts the existing query after one render turn.

The unified-search scheduler now also refuses to enter `isSearchingUnified=true` when the VOD-exclusive gate would reject the task, and its owned operation clears the spinner in `defer` on cancellation/early return.

Search detail hydration now preserves `airDateString`, `episodeDateStrings`, and—critically—`franchiseItems` so later resolver identity hydration cannot erase an already-hydrated collection from the visible media profile.

### 2. Franchise returns to the CURRENT compact Media Information surface

The obsolete full-screen Details screen is **not** restored.

When real `franchiseItems` metadata exists, the current connected 860x858 Media Information panel gains a compact **EXPLORE THE FRANCHISE** ribbon. Its resting footprint is fixed at 66 pt. When focus enters it, a five-title glass shelf expands **upward as an overlay**. It never pushes or reflows the catalog rail underneath.

The existing `.related(index)` focus ownership and selection path are retained. Series can also route through the same ribbon if future/current metadata supplies franchise items; after the ribbon, Down returns to the season/episode path.

### 3. UNITY catalog visual overhaul

A new presentation-only `UnityCatalogVisualSystem.swift` adds one coherent visual language without changing layout/focus ownership:

- **Unity card chrome:** layered glass/specular frame, restrained title-specific accent rail, softer inner edge, and focus depth.
- **Title Aura:** deterministic per-title accent selected from a restrained premium palette. It is stable across launches and does not rely on Swift's randomized hash seed.
- **Hero Aura:** two static radial gradients tie the hero artwork to its focused card with no extra artwork decode, timer, CADisplayLink, or shader loop.
- **Search visual parity:** Search results now use the same Unity card chrome instead of a separate orange-only focus treatment.
- **Catalog fan cards:** trailing poster previews receive the same lightweight chrome at reduced intensity.
- **Provider marks:** row/provider headers gain a slim illuminated accent rail while preserving their existing text/logo ownership and geometry.
- **Compact Media Information:** the same title aura is mixed into the existing transparent glass panel so card → hero → media information reads as one visual system.

The existing Search-style focused-card bounce, fixed rail geometry, optional slow pulse, focused-card previews, themes, artwork handoff, and Unity persistent Live TV root are preserved.

## Locked playback/crash scope

The following remain byte-identical to vBRDC065:

- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/PlaybackKit/PlaybackKitFoundation.swift`
- `Sources/UniversalCodecSupport.swift`
- `Sources/TorBoxUsenetClient.swift`
- `Sources/CatalogStore.swift`
- `Sources/UnitySurfaceSystem.swift`
- `Sources/LocalIntroDetectionEngine.swift`
- `Sources/PlaybackStateManager.swift`
- `Sources/VODExclusivePlaybackGate.swift`
- `Scripts/fetch_patch_kspnuvio_vBRDC064.sh`
- `Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py`
- backend TorBox Usenet relay runtime

Because `DebridChannelsTVOSApp.swift` contains both UI and the vBRDC065 Live TV parser integration, the vBRDC065 XMLTV background/cancellation anchors are contract-tested rather than hash-locked.

## Validation in this environment

- 61 Swift source files parsed with `swiftc -frontend -parse`.
- App + Top Shelf plists validate.
- vBRDC066 contract test passes.
- Locked playback/KSP/provider source hashes match vBRDC065.
- Project YAML parses and includes `UnityCatalogVisualSystem.swift` in the tvOS target.
- Final ZIP integrity is checked after packaging.

A full Apple-platform/Xcode compile is still authoritative in GitHub Actions, followed by physical Apple TV testing.

## Physical test priorities

1. Search for a movie → open it → play it → Back to Media Information/Search. Search results must immediately remain focusable and must never sit indefinitely on “Searching movies and shows…”.
2. Open a TMDB-confirmed collection title. The current compact Media Information panel should show the franchise ribbon. Down into the ribbon, Left/Right through titles, Select opens that franchise title, Back returns normally.
3. Confirm franchise shelf expands upward and catalog cards beneath the media-information panel do not move.
4. Browse Home/Movies/Shows quickly. The fixed focused landscape slot, fan cards, provider marks, and hero should use the new Unity chrome/aura without changing row geometry or the established Search-style bounce.
5. Re-test VOD cache/ghost, Match Frame Rate, and long Live TV/XMLTV sessions to confirm the locked playback/crash fixes remain unchanged.
