"""Debrid Channels Phase 2 backend Alternate Audio discovery runtime.

This module is intentionally discovery-only. It probes the selected source and every
resolved Source Intelligence candidate with ffprobe, identifies real English audio
streams, verifies movie/episode ownership, compares timing/edition/chapter metadata,
and returns one of the five public match classifications. It never creates a bridge,
changes playback, or rewrites media.

The production backend should expose ``POST /api/alternate-audio/discover`` and pass
the decoded JSON body to :func:`discover_alternate_audio`.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import subprocess
from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
from urllib.parse import urlparse

SCHEMA_VERSION = 1
MAX_CANDIDATES = 50
MAX_PROBE_BYTES = 8 * 1024 * 1024
DEFAULT_PROBE_TIMEOUT = 35
DEFAULT_FINGERPRINT_TIMEOUT = 25

COMMENTARY_TOKENS = (
    "commentary", "director commentary", "cast commentary", "producer commentary",
    "audio commentary", "comment", "kommentar",
)
DESCRIPTIVE_TOKENS = (
    "audio description", "descriptive audio", "described video", "visual impaired",
    "visually impaired", "ad track", "description",
)
EDITION_TOKENS = (
    "extended", "director's cut", "directors cut", "theatrical", "unrated",
    "remastered", "imax", "criterion", "special edition", "final cut", "redux",
)
LANGUAGE_ALIASES = {
    "en": "eng", "eng": "eng", "english": "eng", "en-us": "eng", "en-gb": "eng",
    "und": "und", "": "und",
}


class DiscoveryError(RuntimeError):
    pass


@dataclass(frozen=True)
class ProbeConfig:
    ffprobe_binary: str = "ffprobe"
    ffmpeg_binary: str = "ffmpeg"
    probe_timeout_seconds: int = DEFAULT_PROBE_TIMEOUT
    fingerprint_timeout_seconds: int = DEFAULT_FINGERPRINT_TIMEOUT
    maximum_candidates: int = MAX_CANDIDATES
    fingerprint_candidate_limit: int = 6


@dataclass(frozen=True)
class AudioTrack:
    stream_index: int
    codec: str
    language: str
    title: str
    is_default: bool
    is_forced: bool
    is_commentary: bool
    is_descriptive: bool

    def as_dict(self) -> Dict[str, Any]:
        return {
            "streamIndex": self.stream_index,
            "codec": self.codec,
            "language": self.language,
            "title": self.title,
            "isDefault": self.is_default,
            "isForced": self.is_forced,
            "isCommentary": self.is_commentary,
            "isDescriptive": self.is_descriptive,
        }


@dataclass(frozen=True)
class MediaProbe:
    duration_seconds: Optional[float]
    start_time_seconds: Optional[float]
    frame_rate: Optional[float]
    video_codec: str
    width: Optional[int]
    height: Optional[int]
    chapter_count: int
    edition: str
    release_metadata: str
    audio_tracks: Tuple[AudioTrack, ...]


def _safe_http_url(raw: str) -> bool:
    try:
        parsed = urlparse(raw)
    except Exception:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def _float(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _int(value: Any) -> Optional[int]:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _ratio(value: Any) -> Optional[float]:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw or raw in {"0/0", "N/A"}:
        return None
    if "/" in raw:
        left, right = raw.split("/", 1)
        numerator, denominator = _float(left), _float(right)
        if numerator is None or denominator in {None, 0}:
            return None
        return numerator / denominator
    return _float(raw)


def _normalize_language(value: Any) -> str:
    raw = str(value or "").strip().lower().replace("_", "-")
    return LANGUAGE_ALIASES.get(raw, raw[:3] if raw else "und")


def _haystack(*values: Any) -> str:
    return " ".join(str(v or "") for v in values).lower()


def _contains_any(text: str, tokens: Iterable[str]) -> bool:
    return any(token in text for token in tokens)


def _edition_from_text(*values: Any) -> str:
    text = _haystack(*values)
    found = [token.title() for token in EDITION_TOKENS if token in text]
    return ", ".join(dict.fromkeys(found))


def _release_metadata(filename: str) -> str:
    text = filename.strip()
    tokens = re.findall(
        r"(?i)\b(?:2160p|1080p|720p|480p|web[- .]?dl|webrip|bluray|blu[- .]?ray|remux|hdtv|hdr10\+?|dolby[ .]?vision|dv|hevc|x265|x264|av1|atmos|truehd|eac3|ddp|dts(?:-hd)?|aac)\b",
        text,
    )
    return " ".join(dict.fromkeys(token.upper() for token in tokens))


def _run_json(command: Sequence[str], timeout: int) -> Mapping[str, Any]:
    completed = subprocess.run(
        list(command),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
    )
    if completed.returncode != 0:
        message = completed.stderr.decode("utf-8", errors="replace")[-800:]
        raise DiscoveryError(message or f"probe exited {completed.returncode}")
    if len(completed.stdout) > MAX_PROBE_BYTES:
        raise DiscoveryError("ffprobe response exceeded safe limit")
    try:
        payload = json.loads(completed.stdout.decode("utf-8", errors="strict"))
    except Exception as exc:
        raise DiscoveryError("ffprobe returned invalid JSON") from exc
    if not isinstance(payload, Mapping):
        raise DiscoveryError("ffprobe returned a non-object payload")
    return payload


def probe_media(url: str, filename: str, config: ProbeConfig = ProbeConfig()) -> MediaProbe:
    if not _safe_http_url(url):
        raise DiscoveryError("only resolved HTTP(S) media URLs are accepted")
    payload = _run_json(
        [
            config.ffprobe_binary,
            "-v", "error",
            "-show_entries",
            "format=duration,start_time:format_tags=title,comment,edition,encoder:"
            "stream=index,codec_type,codec_name,width,height,avg_frame_rate,r_frame_rate,start_time,duration:"
            "stream_tags=language,title,handler_name:stream_disposition:chapter=id,start_time,end_time",
            "-of", "json",
            url,
        ],
        timeout=config.probe_timeout_seconds,
    )
    format_obj = payload.get("format") if isinstance(payload.get("format"), Mapping) else {}
    streams = payload.get("streams") if isinstance(payload.get("streams"), list) else []
    chapters = payload.get("chapters") if isinstance(payload.get("chapters"), list) else []

    duration = _float(format_obj.get("duration"))
    start_time = _float(format_obj.get("start_time"))
    video_codec = ""
    width: Optional[int] = None
    height: Optional[int] = None
    frame_rate: Optional[float] = None
    audio_tracks: List[AudioTrack] = []

    for stream in streams:
        if not isinstance(stream, Mapping):
            continue
        codec_type = str(stream.get("codec_type") or "").lower()
        tags = stream.get("tags") if isinstance(stream.get("tags"), Mapping) else {}
        disposition = stream.get("disposition") if isinstance(stream.get("disposition"), Mapping) else {}
        if codec_type == "video" and not video_codec:
            video_codec = str(stream.get("codec_name") or "")
            width = _int(stream.get("width"))
            height = _int(stream.get("height"))
            frame_rate = _ratio(stream.get("avg_frame_rate")) or _ratio(stream.get("r_frame_rate"))
            if start_time is None:
                start_time = _float(stream.get("start_time"))
        elif codec_type == "audio":
            title = str(tags.get("title") or tags.get("handler_name") or "").strip()
            language = _normalize_language(tags.get("language"))
            track_text = _haystack(title, language)
            commentary = bool(disposition.get("comment")) or _contains_any(track_text, COMMENTARY_TOKENS)
            descriptive = bool(disposition.get("visual_impaired")) or _contains_any(track_text, DESCRIPTIVE_TOKENS)
            audio_tracks.append(
                AudioTrack(
                    stream_index=_int(stream.get("index")) or 0,
                    codec=str(stream.get("codec_name") or "unknown"),
                    language=language,
                    title=title,
                    is_default=bool(disposition.get("default")),
                    is_forced=bool(disposition.get("forced")),
                    is_commentary=commentary,
                    is_descriptive=descriptive,
                )
            )

    format_tags = format_obj.get("tags") if isinstance(format_obj.get("tags"), Mapping) else {}
    edition = _edition_from_text(filename, format_tags.get("title"), format_tags.get("edition"), format_tags.get("comment"))
    return MediaProbe(
        duration_seconds=duration,
        start_time_seconds=start_time,
        frame_rate=frame_rate,
        video_codec=video_codec,
        width=width,
        height=height,
        chapter_count=len(chapters),
        edition=edition,
        release_metadata=_release_metadata(filename),
        audio_tracks=tuple(audio_tracks),
    )


def _normalized_title(value: Any) -> str:
    text = re.sub(r"[^a-z0-9]+", " ", str(value or "").lower())
    stop = {"the", "a", "an"}
    return " ".join(token for token in text.split() if token not in stop)


def _episode_tokens(value: str) -> Optional[Tuple[int, int]]:
    patterns = (
        r"(?i)\bS(\d{1,3})[ ._-]*E(\d{1,3})\b",
        r"(?i)\b(\d{1,3})x(\d{1,3})\b",
    )
    for pattern in patterns:
        match = re.search(pattern, value)
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


def verify_identity(identity: Mapping[str, Any], filename: str) -> Tuple[bool, str, int]:
    title = str(identity.get("title") or "").strip()
    year = str(identity.get("year") or "").strip()
    season = _int(identity.get("seasonNumber") or identity.get("season_number"))
    episode = _int(identity.get("episodeNumber") or identity.get("episode_number"))
    media_type = str(identity.get("mediaType") or identity.get("media_type") or "").lower()
    normalized_filename = _normalized_title(filename)
    normalized_title = _normalized_title(title)
    score = 0

    if normalized_title and normalized_title in normalized_filename:
        score += 55
    else:
        title_tokens = set(normalized_title.split())
        file_tokens = set(normalized_filename.split())
        overlap = len(title_tokens & file_tokens) / max(1, len(title_tokens))
        if overlap >= 0.75:
            score += 40
        elif overlap >= 0.5:
            score += 20
        else:
            return False, "title identity mismatch", score

    if media_type in {"series", "show", "tv", "episode"} or season is not None or episode is not None:
        parsed = _episode_tokens(filename)
        if season is None or episode is None:
            return False, "episode identity is incomplete", score
        if parsed is None:
            return False, "candidate filename does not identify the exact episode", score
        if parsed != (season, episode):
            return False, f"candidate is S{parsed[0]:02d}E{parsed[1]:02d}, expected S{season:02d}E{episode:02d}", score
        score += 35
    elif year:
        years = re.findall(r"\b(?:19|20)\d{2}\b", filename)
        if years and year not in years:
            return False, f"release year mismatch ({'/'.join(years)} vs {year})", score
        if year in years:
            score += 15

    return True, "identity verified", score


def select_audio_track(
    probe: MediaProbe,
    preferred_languages: Sequence[str],
    include_commentary: bool,
    include_descriptive: bool,
) -> Optional[AudioTrack]:
    preferred = {_normalize_language(value) for value in preferred_languages}
    eligible = [
        track for track in probe.audio_tracks
        if track.language in preferred
        and (include_commentary or not track.is_commentary)
        and (include_descriptive or not track.is_descriptive)
    ]
    if not eligible:
        return None
    return sorted(
        eligible,
        key=lambda track: (
            track.is_commentary,
            track.is_descriptive,
            not track.is_default,
            track.stream_index,
        ),
    )[0]


def _duration_delta(a: Optional[float], b: Optional[float]) -> Optional[float]:
    if a is None or b is None:
        return None
    return abs(a - b)


def _fps_delta(a: Optional[float], b: Optional[float]) -> Optional[float]:
    if a is None or b is None:
        return None
    return abs(a - b)


def _release_family(metadata: str) -> str:
    text = metadata.upper()
    if "BLURAY" in text or "REMUX" in text:
        return "disc"
    if "WEB" in text:
        return "web"
    if "HDTV" in text or "MPEG-TS" in text:
        return "broadcast"
    return "unknown"


def _hamming_similarity(left: bytes, right: bytes) -> float:
    if not left or len(left) != len(right):
        return 0.0
    differences = sum((a ^ b).bit_count() for a, b in zip(left, right))
    return 1.0 - differences / (len(left) * 8)


def _frame_signature(url: str, seconds: float, config: ProbeConfig) -> bytes:
    if not _safe_http_url(url):
        raise DiscoveryError("invalid fingerprint URL")
    completed = subprocess.run(
        [
            config.ffmpeg_binary,
            "-v", "error",
            "-ss", f"{max(0.0, seconds):.3f}",
            "-i", url,
            "-map", "0:v:0",
            "-frames:v", "1",
            "-vf", "scale=17:16:flags=bilinear,format=gray",
            "-f", "rawvideo",
            "pipe:1",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=config.fingerprint_timeout_seconds,
        check=False,
    )
    if completed.returncode != 0 or len(completed.stdout) < 17 * 16:
        raise DiscoveryError("sampled video fingerprint unavailable")
    raw = completed.stdout[: 17 * 16]
    bits = bytearray()
    current = 0
    count = 0
    for row in range(16):
        offset = row * 17
        for column in range(16):
            current = (current << 1) | int(raw[offset + column] > raw[offset + column + 1])
            count += 1
            if count == 8:
                bits.append(current)
                current = 0
                count = 0
    return bytes(bits)


def sampled_video_fingerprint(url: str, duration: Optional[float], config: ProbeConfig) -> Tuple[bytes, ...]:
    if duration is None or duration < 30:
        return tuple()
    points = (duration * 0.12, duration * 0.50, duration * 0.88)
    return tuple(_frame_signature(url, point, config) for point in points)


def fingerprint_similarity(left: Sequence[bytes], right: Sequence[bytes]) -> Optional[float]:
    if not left or len(left) != len(right):
        return None
    return sum(_hamming_similarity(a, b) for a, b in zip(left, right)) / len(left)


def classify_candidate(
    baseline: MediaProbe,
    candidate: MediaProbe,
    identity_score: int,
    fingerprint_score: Optional[float],
) -> Tuple[str, str, Optional[str]]:
    duration_delta = _duration_delta(baseline.duration_seconds, candidate.duration_seconds)
    fps_delta = _fps_delta(baseline.frame_rate, candidate.frame_rate)
    start_delta = _duration_delta(baseline.start_time_seconds, candidate.start_time_seconds)
    edition_mismatch = bool(baseline.edition and candidate.edition and baseline.edition != candidate.edition)
    chapter_delta = abs(baseline.chapter_count - candidate.chapter_count)
    baseline_release_family = _release_family(baseline.release_metadata)
    candidate_release_family = _release_family(candidate.release_metadata)
    release_family_mismatch = (
        baseline_release_family != "unknown"
        and candidate_release_family != "unknown"
        and baseline_release_family != candidate_release_family
    )

    if duration_delta is None:
        return "Possible Match", "Identity and English track verified; duration metadata is incomplete.", None
    if duration_delta > 45:
        return "Incompatible", "Candidate duration differs by more than 45 seconds.", "duration mismatch"
    if edition_mismatch and duration_delta > 8:
        return "Incompatible", "Edition metadata and duration indicate a different cut.", "edition mismatch"
    if fingerprint_score is not None and fingerprint_score < 0.58:
        return "Incompatible", "Sampled video fingerprint indicates different content.", "video fingerprint mismatch"

    exact_duration = duration_delta <= max(1.0, (baseline.duration_seconds or 0) * 0.0015)
    close_fps = fps_delta is None or fps_delta <= 0.02
    close_chapters = chapter_delta <= 1 or baseline.chapter_count == 0 or candidate.chapter_count == 0
    fingerprint_exact = fingerprint_score is None or fingerprint_score >= 0.82
    exact_start = start_delta is None or start_delta <= 0.5
    release_signal_ok = not release_family_mismatch or (fingerprint_score is not None and fingerprint_score >= 0.88)
    if exact_duration and exact_start and close_fps and close_chapters and not edition_mismatch and fingerprint_exact and release_signal_ok:
        return "Exact Match", "Identity, duration, start time, frame rate, edition, chapters, release metadata, and sampled content agree.", None

    if duration_delta <= 2.0 and close_fps:
        release_note = " Release source differs, but timing remains compatible." if release_family_mismatch else ""
        if start_delta is not None and start_delta <= 15:
            return "Offset Match", "The same cut is detected with a correctable start offset." + release_note, None
        return "Offset Match", "Duration and frame rate agree; a short manual offset may be required." + release_note, None

    relative = duration_delta / max(1.0, baseline.duration_seconds or candidate.duration_seconds or 1.0)
    if relative <= 0.006 and (fps_delta is None or fps_delta <= 0.15) and not edition_mismatch:
        return "Drift Correctable", "Identity matches and the small duration/frame-rate difference is correctable.", None

    if duration_delta <= 20 and identity_score >= 55:
        return "Possible Match", "Identity is strong, but cut/timing metadata requires user verification.", None
    return "Incompatible", "Timing or edition metadata does not match the selected source.", "timing compatibility failed"


def _result_base(candidate: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "url": str(candidate.get("url") or ""),
        "provider": str(candidate.get("provider") or "Source Intelligence"),
        "filename": str(candidate.get("filename") or "Alternate source"),
        "quality": str(candidate.get("quality") or ""),
        "size": str(candidate.get("size") or ""),
    }


def discover_alternate_audio(payload: Mapping[str, Any], config: ProbeConfig = ProbeConfig()) -> Dict[str, Any]:
    identity = payload.get("identity") if isinstance(payload.get("identity"), Mapping) else {}
    current = payload.get("currentSource") or payload.get("current_source")
    candidates = payload.get("candidates")
    if not isinstance(current, Mapping):
        raise DiscoveryError("currentSource is required")
    if not isinstance(candidates, list):
        raise DiscoveryError("candidates must be an array")
    current_url = str(current.get("url") or "")
    current_filename = str(current.get("filename") or identity.get("title") or "Current source")
    if not _safe_http_url(current_url):
        raise DiscoveryError("currentSource must be a resolved HTTP(S) URL")

    preferred_languages = payload.get("preferredLanguages") or payload.get("preferred_languages") or ["eng", "en"]
    if not isinstance(preferred_languages, list):
        preferred_languages = ["eng", "en"]
    include_commentary = bool(payload.get("includeCommentary") or payload.get("include_commentary"))
    include_descriptive = bool(payload.get("includeDescriptiveAudio") or payload.get("include_descriptive_audio"))
    enable_fingerprint = bool(payload.get("enableSampledVideoFingerprint") or payload.get("enable_sampled_video_fingerprint"))

    baseline = probe_media(current_url, current_filename, config)
    baseline_fingerprint: Tuple[bytes, ...] = tuple()
    if enable_fingerprint:
        try:
            baseline_fingerprint = sampled_video_fingerprint(current_url, baseline.duration_seconds, config)
        except Exception:
            baseline_fingerprint = tuple()

    results: List[Dict[str, Any]] = []
    fingerprinted = 0
    for raw_candidate in candidates[: config.maximum_candidates]:
        if not isinstance(raw_candidate, Mapping):
            continue
        result = _result_base(raw_candidate)
        url = result["url"]
        filename = result["filename"]
        identity_ok, identity_reason, identity_score = verify_identity(identity, filename)
        if not identity_ok:
            result.update({
                "classification": "Incompatible",
                "confidence": identity_reason,
                "selectedAudioTrack": None,
                "rejectionReason": identity_reason,
                "releaseMetadata": _release_metadata(filename),
            })
            results.append(result)
            continue
        try:
            candidate_probe = probe_media(url, filename, config)
        except Exception as exc:
            result.update({
                "classification": "Incompatible",
                "confidence": "Backend ffprobe could not inspect this candidate.",
                "selectedAudioTrack": None,
                "rejectionReason": str(exc)[:240],
                "releaseMetadata": _release_metadata(filename),
            })
            results.append(result)
            continue

        track = select_audio_track(
            candidate_probe,
            [str(value) for value in preferred_languages],
            include_commentary,
            include_descriptive,
        )
        if track is None:
            rejected = [
                audio for audio in candidate_probe.audio_tracks
                if audio.language == "eng" and (audio.is_commentary or audio.is_descriptive)
            ]
            reason = "Only commentary/descriptive English tracks were found." if rejected else "No real English audio stream was found."
            result.update({
                "classification": "Incompatible",
                "confidence": reason,
                "selectedAudioTrack": None,
                "durationSeconds": candidate_probe.duration_seconds,
                "startTimeSeconds": candidate_probe.start_time_seconds,
                "frameRate": candidate_probe.frame_rate,
                "edition": candidate_probe.edition,
                "chapterCount": candidate_probe.chapter_count,
                "rejectionReason": reason,
                "releaseMetadata": candidate_probe.release_metadata,
            })
            results.append(result)
            continue

        similarity: Optional[float] = None
        fingerprint_status = "Not sampled"
        preliminary_duration = _duration_delta(baseline.duration_seconds, candidate_probe.duration_seconds)
        should_fingerprint = (
            enable_fingerprint
            and baseline_fingerprint
            and fingerprinted < config.fingerprint_candidate_limit
            and (preliminary_duration is None or preliminary_duration <= 25)
        )
        if should_fingerprint:
            try:
                candidate_fingerprint = sampled_video_fingerprint(url, candidate_probe.duration_seconds, config)
                similarity = fingerprint_similarity(baseline_fingerprint, candidate_fingerprint)
                fingerprint_status = "Sampled video fingerprint compared" if similarity is not None else "Fingerprint unavailable"
                fingerprinted += 1
            except Exception:
                fingerprint_status = "Fingerprint unavailable"

        classification, confidence, rejection = classify_candidate(
            baseline,
            candidate_probe,
            identity_score,
            similarity,
        )
        result.update({
            "classification": classification,
            "confidence": confidence,
            "selectedAudioTrack": track.as_dict(),
            "durationSeconds": candidate_probe.duration_seconds,
            "startTimeSeconds": candidate_probe.start_time_seconds,
            "frameRate": candidate_probe.frame_rate,
            "edition": candidate_probe.edition,
            "chapterCount": candidate_probe.chapter_count,
            "fingerprintSimilarity": similarity,
            "fingerprintStatus": fingerprint_status,
            "rejectionReason": rejection,
            "releaseMetadata": candidate_probe.release_metadata,
        })
        results.append(result)

    order = {
        "Exact Match": 0,
        "Offset Match": 1,
        "Drift Correctable": 2,
        "Possible Match": 3,
        "Incompatible": 4,
    }
    results.sort(key=lambda item: (order.get(str(item.get("classification")), 9), str(item.get("provider")), str(item.get("filename"))))
    compatible_count = sum(1 for item in results if item.get("classification") != "Incompatible")
    return {
        "schemaVersion": SCHEMA_VERSION,
        "status": "complete",
        "scannedCount": len(results),
        "compatibleCount": compatible_count,
        "baseline": {
            "durationSeconds": baseline.duration_seconds,
            "startTimeSeconds": baseline.start_time_seconds,
            "frameRate": baseline.frame_rate,
            "edition": baseline.edition,
            "chapterCount": baseline.chapter_count,
            "videoCodec": baseline.video_codec,
        },
        "results": results,
    }


def register_fastapi_route(app: Any, config: ProbeConfig = ProbeConfig()) -> None:
    """Register the Phase 2 endpoint on an existing FastAPI application.

    FastAPI is imported lazily so this helper remains testable without backend web
    dependencies. Production authentication/session ownership should wrap this route;
    the stricter signed-URL and abuse controls are scheduled for Phase 10.
    """
    try:
        from fastapi import HTTPException, Request
    except Exception as exc:  # pragma: no cover - only used by backend integration
        raise RuntimeError("FastAPI is required to register the endpoint") from exc

    @app.post("/api/alternate-audio/discover")
    async def alternate_audio_discover(request: Request) -> Dict[str, Any]:
        try:
            body = await request.json()
            if not isinstance(body, Mapping):
                raise DiscoveryError("request body must be an object")
            return discover_alternate_audio(body, config)
        except DiscoveryError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc
        except subprocess.TimeoutExpired as exc:
            raise HTTPException(status_code=504, detail="media probe timed out") from exc
