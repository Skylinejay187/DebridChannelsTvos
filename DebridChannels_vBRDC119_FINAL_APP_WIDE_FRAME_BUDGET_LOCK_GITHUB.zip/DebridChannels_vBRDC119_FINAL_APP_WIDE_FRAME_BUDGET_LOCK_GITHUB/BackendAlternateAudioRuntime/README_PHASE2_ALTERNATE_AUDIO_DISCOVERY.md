# Phase 2 Alternate Audio discovery backend handoff

Add `alternate_audio_discovery_runtime.py` to the existing Debrid Channels backend and register it on the production FastAPI app:

```python
from alternate_audio_discovery_runtime import register_fastapi_route
register_fastapi_route(app)
```

Runtime requirements:

- `ffprobe` and `ffmpeg` available on `PATH`.
- Existing backend authentication should protect `POST /api/alternate-audio/discover`.
- The request contains only URLs already resolved by Debrid Channels Source Intelligence.
- This phase is discovery-only. It never remuxes, creates HLS, or changes playback.

The response includes actual audio stream language, title, codec and dispositions; exact movie/episode identity checks; duration/start-time/frame-rate/edition/chapter comparisons; optional sampled video fingerprint similarity; and one of:

- Exact Match
- Offset Match
- Drift Correctable
- Possible Match
- Incompatible

Commentary and descriptive audio are excluded unless the request explicitly enables them.
