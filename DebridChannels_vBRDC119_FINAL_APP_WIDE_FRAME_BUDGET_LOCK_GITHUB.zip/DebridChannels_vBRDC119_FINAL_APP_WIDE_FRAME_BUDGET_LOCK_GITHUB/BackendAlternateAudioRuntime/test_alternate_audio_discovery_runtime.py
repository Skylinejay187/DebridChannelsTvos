import unittest
from unittest.mock import patch

from alternate_audio_discovery_runtime import (
    AudioTrack,
    MediaProbe,
    classify_candidate,
    discover_alternate_audio,
    select_audio_track,
    verify_identity,
)


def probe(duration=3600.0, start=0.0, fps=23.976, edition="", chapters=12):
    return MediaProbe(
        duration_seconds=duration,
        start_time_seconds=start,
        frame_rate=fps,
        video_codec="hevc",
        width=3840,
        height=2160,
        chapter_count=chapters,
        edition=edition,
        release_metadata="2160P BLURAY REMUX",
        audio_tracks=(),
    )


class Phase2DiscoveryTests(unittest.TestCase):
    def test_exact_episode_identity(self):
        ok, _, score = verify_identity(
            {"title": "Example Show", "mediaType": "series", "seasonNumber": 2, "episodeNumber": 7},
            "Example.Show.S02E07.1080p.WEB-DL.mkv",
        )
        self.assertTrue(ok)
        self.assertGreaterEqual(score, 90)

    def test_wrong_episode_is_rejected(self):
        ok, reason, _ = verify_identity(
            {"title": "Example Show", "mediaType": "series", "seasonNumber": 2, "episodeNumber": 7},
            "Example.Show.S02E08.1080p.WEB-DL.mkv",
        )
        self.assertFalse(ok)
        self.assertIn("expected S02E07", reason)

    def test_commentary_is_excluded(self):
        tracks = (
            AudioTrack(1, "eac3", "eng", "Director Commentary", True, False, True, False),
            AudioTrack(2, "aac", "eng", "English", False, False, False, False),
        )
        candidate = MediaProbe(3600, 0, 24, "h264", 1920, 1080, 10, "", "", tracks)
        selected = select_audio_track(candidate, ["English", "eng"], False, False)
        self.assertEqual(selected.stream_index, 2)

    def test_exact_match(self):
        classification, _, rejection = classify_candidate(probe(), probe(duration=3600.2), 100, 0.91)
        self.assertEqual(classification, "Exact Match")
        self.assertIsNone(rejection)

    def test_offset_match(self):
        classification, _, _ = classify_candidate(probe(), probe(duration=3601.5, start=4.0), 100, 0.88)
        self.assertEqual(classification, "Offset Match")

    def test_drift_correctable(self):
        classification, _, _ = classify_candidate(probe(), probe(duration=3615.0, fps=24.0), 100, 0.80)
        self.assertEqual(classification, "Drift Correctable")


    def test_full_discovery_response_shape(self):
        english = AudioTrack(2, "eac3", "eng", "English", True, False, False, False)
        baseline = probe()
        candidate = MediaProbe(3600.1, 0.0, 23.976, "hevc", 3840, 2160, 12, "", "2160P BLURAY REMUX", (english,))
        payload = {
            "identity": {"title": "Example Movie", "mediaType": "movie", "year": "2024"},
            "currentSource": {"url": "https://media.example/current", "filename": "Example.Movie.2024.mkv"},
            "candidates": [{
                "url": "https://media.example/candidate",
                "provider": "Test Provider",
                "filename": "Example.Movie.2024.2160p.BluRay.Remux.mkv",
                "quality": "4K",
                "size": "60 GB",
            }],
            "preferredLanguages": ["English", "eng"],
            "enableSampledVideoFingerprint": False,
        }
        with patch("alternate_audio_discovery_runtime.probe_media", side_effect=[baseline, candidate]):
            response = discover_alternate_audio(payload)
        self.assertEqual(response["schemaVersion"], 1)
        self.assertEqual(response["compatibleCount"], 1)
        self.assertEqual(response["results"][0]["classification"], "Exact Match")
        self.assertEqual(response["results"][0]["selectedAudioTrack"]["streamIndex"], 2)

    def test_different_cut_is_incompatible(self):
        classification, _, rejection = classify_candidate(
            probe(edition="Theatrical"),
            probe(duration=3700.0, edition="Extended"),
            100,
            0.90,
        )
        self.assertEqual(classification, "Incompatible")
        self.assertIsNotNone(rejection)


if __name__ == "__main__":
    unittest.main()
