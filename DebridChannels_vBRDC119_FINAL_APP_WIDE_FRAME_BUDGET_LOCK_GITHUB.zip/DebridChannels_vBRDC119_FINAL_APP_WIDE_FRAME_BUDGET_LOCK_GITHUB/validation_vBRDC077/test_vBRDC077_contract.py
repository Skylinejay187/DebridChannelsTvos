from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJ = (ROOT / 'project.yml').read_text()
INFO = (ROOT / 'Sources/Info.plist').read_text()
TOP = (ROOT / 'TopShelfExtension/Info.plist').read_text()


def block(text, signature, next_signature):
    start = text.index(signature)
    end = text.index(next_signature, start)
    return text[start:end]

confirm = block(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
seek = block(APP, 'private func seekAbsolute', 'private func startTimelineMetadataRecoveryMonitor')
ks_seek = block(KS, 'private func performBestEffortSeek', 'private func applyAudioMuteState')

checks = {
    'confirmed resume restores play state': 'isPlaying = true' in confirm,
    'confirmed resume restores autohide': 'scheduleAutoHide()' in confirm,
    'AVPlayer confirmed resume asserts play': 'player?.play()' in confirm,
    'confirmed resume no longer means seek-only': 'confirmed and playing' in confirm,
    'KS automatic resume remains in-place': 'ksSurfaceToken &+= 1' not in seek and 'ksSeekSerial &+= 1' in seek,
    'KS seek requests autoplay': 'autoPlay: resumePlayback' in ks_seek,
    'KS seek immediately reasserts play': 'if resumePlayback { layer.play() }' in ks_seek or 'guard resumePlayback else { return }' in ks_seek,
    'KS post-flush play assertion exists': 'asyncAfter(deadline: .now() + 0.18)' in ks_seek,
    'manual pause wins over delayed assertion': 'coordinator.currentShouldPlay ?? true' in ks_seek,
    'release ID bumped': '<string>vBRDC077</string>' in INFO and '<string>vBRDC077</string>' in TOP,
    'marketing version bumped': '1.0.780' in INFO and '1.0.780' in TOP and 'MARKETING_VERSION: 1.0.780' in PROJ,
    'numeric build bumped': '<string>780</string>' in INFO and '<string>780</string>' in TOP and 'CURRENT_PROJECT_VERSION: 780' in PROJ,
    'v076 playback-priority buffer gate retained': 'vBRDC076 Playback Priority: playableTime is telemetry' in APP,
    'v073 clock-confirmed resume retained': 'reconcileAutomaticResumePlaybackClock(current: current)' in APP,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{sum(checks.values())}/{len(checks)} vBRDC077 contracts passed')
if failed:
    raise SystemExit('Failed: ' + ', '.join(failed))
