# Debrid Channels vBRDC084 — UNITY Performance / Identity / Resume Recovery

Version: **1.0.787**  
Apple build: **787**  
Release ID: **vBRDC084**

Built only from packaged **vBRDC083**.

## Physical regressions addressed

1. Search results with the same movie title could all display the same RESUME/progress state. The legacy movie fallback used title-only matching. vBRDC084 persists movie year, makes stable IDs/year authoritative, skips expensive legacy scans for modern movie identities, and scopes last-resort legacy matching conservatively.
2. Search-origin Media Information could show partial/late Production information. Search keeps the visible detail ID stable while hydration adds TMDB/IMDb/TVDB identities, so the old loader did not retry. vBRDC084 adds a bounded identity-exact session cache, prewarms only the currently focused Search result, publishes cached Production details synchronously, and retries when external identity improves.
3. vBRDC083's visible/4K wallpaper work could consume too much UI frame budget. vBRDC084 keeps all themes, Nexus Lines, 3840px custom GIF/WebP output, aspect-fill, custom video and 96MB disk cache, but caps perpetual procedural redraw cadence to 8/12/16 fps and 4K raster animation decode cadence to 6/8/10 fps. Resolution/visibility are unchanged; custom raster decoding runs at background priority. Wallpaper still unmounts for playback and covered surfaces.
4. Automatic resume could reach the correct saved position and remain paused. The vBRDC077 single delayed Play assertion was not sufficient for sources whose decoder flush finishes later. vBRDC084 adds a bounded post-seek liveness recovery inside the existing KSPlayer surface: it establishes a post-seek clock baseline, reasserts Play only while playback is still requested, and stops as soon as the real player clock advances. User Pause and teardown invalidate the recovery generation immediately.

## Preserved

- vBRDC083 Dynamic Wallpaper visibility / 4K custom wallpaper / Nexus Lines
- vBRDC081 UNITY surface lifecycle handoff
- vBRDC080 UNITY animation compatibility
- vBRDC078 VOD exit interactivity recovery
- vBRDC076 playback-priority protections
- Source Intelligence / TorBox donor code / Sports / catalog systems

TorBox Usenet is not claimed fixed in this build; the backend Search API whitelist/authorization remains a separate pending integration item.

## Validation

- vBRDC084 contract: 43/43
- Same-title resume cache semantic compile/run: passed
- Backend inherited tests: 35/35
- Swift syntax parse: 64/64 app + Top Shelf files
- plist/project YAML validation: passed
- XcodeGen source membership: all Sources Swift files included

GitHub Actions/Xcode remains the authoritative Apple semantic compile.
