# Debrid Channels vBRDC106 — VOD Overlay Visible Rotation + Cast Explorer Recovery

- Release ID: `vBRDC106`
- Marketing version: `1.0.809`
- Apple build: `809`
- Donor: packaged `vBRDC105`

## Physical-test regression addressed

During full-screen VOD playback, Featured Cast and Production & Ratings could appear stuck on one bitmap even though their 7-second indexes were advancing. Closing/reopening the overlay or pausing could make the next image suddenly appear. Cast names could advance ahead of the retained portrait, and Cast Explorer Known For / Movies / TV Shows posters could fail to paint reliably.

## Root cause

`vBRDC102` made full-screen playback an exclusive UNITY state. `RemoteImageFit` decoded and cached VOD overlay artwork, but the shared publication gate treated those visible overlay images like ordinary background artwork. The decoded replacement therefore entered cache but was not permitted to publish while playback remained active. Reopening the overlay then found the cached bitmap synchronously, creating the false impression that pause/reopen restarted rotation.

## Fix

1. Added a dedicated opt-in `playbackArtwork` UNITY lane. Only visible VOD UI explicitly using `publishDuringPlayback: true` can paint during full-screen VOD. Default behavior remains blocked for catalog, wallpaper, Dynamic Wallpaper, Sports, Favorites, Live TV and background prefetch.
2. Featured Cast compact/full portraits, title poster/logo, Production artwork/title/company logos, Cast Explorer profile art and credit posters use the playback-artwork lane.
3. Featured Cast now commits actor identity only when the requested portrait bitmap actually reaches the screen. The retained old portrait remains visible with its matching old name/role and Select target until the replacement is ready; face/name/action cannot drift apart.
4. Production rotation no longer uses a `Timer.publish(...).autoconnect()` stored in a SwiftUI view. It uses a cancellable 7-second `.task` tied to the mounted visible header.
5. Hidden VOD chrome still unmounts. Featured Cast and Production rotation therefore cancel while the overlay is hidden; there is no background 7-second cycling.
6. Cast Explorer profile/credit poster decodes are display-bounded (768 / 512 px) instead of decoding TMDB originals at full source size.
7. Optional Wikidata enrichment gets a bounded 1.8-second window and can no longer hold TMDB Known For / Movies / TV Shows rows behind slow open-data requests.

## Preserved behavior

- Featured Cast: exact 7-second rotation cadence.
- Production artwork: exact 7-second rotation cadence and 0.80-second animation.
- vBRDC100 retained-frame no-blank handoff remains.
- vBRDC103 persistent row scrolling remains.
- vBRDC104 persistent catalog surface remains.
- vBRDC105 Live TV fast-return and 3s/15s focused-channel preview remain.
- `UnityCatalogVisualSystem.swift` is byte-identical to vBRDC105.

## Validation

- VOD regression contract: 45/45
- Production Swift parse: 65/65
- Version/project metadata: 8/8
- Backend regression: 36 tests + 2 subtests passed
- Existing donor-file scope: exactly 8 intended files changed
- No donor files missing
- No unexpected donor files added
- `UnityCatalogVisualSystem.swift`: byte-identical to donor

Physical Apple TV validation remains authoritative for real playback/compositor behavior.
