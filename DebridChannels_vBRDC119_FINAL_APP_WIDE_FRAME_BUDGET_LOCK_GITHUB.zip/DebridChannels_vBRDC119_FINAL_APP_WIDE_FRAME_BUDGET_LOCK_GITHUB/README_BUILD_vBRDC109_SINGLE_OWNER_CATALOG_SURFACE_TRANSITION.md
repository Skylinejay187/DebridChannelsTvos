# Debrid Channels vBRDC109 — Single-Owner Catalog Surface Transition

- Release ID: **vBRDC109**
- Marketing version: **1.0.812**
- Apple build: **812**
- Donor: **vBRDC108 App-Wide Regression Lock + Media Handoff**
- Backend/provider runtimes: unchanged from donor

## Physical-test finding from `38435.mp4`

The user correctly separated this regression from horizontal/vertical row scrolling. The persistent row engine and its 48 motion presets are working; the remaining jank is specifically the **Live TV/persistent-root ↔ Home/Movies/Shows catalog surface open/close**.

Dense 60 fps inspection of the supplied recording shows two independent geometry changes during one visible transition:

1. The whole catalog surface moves on `unityCatalogBranchProgress` (`opacity + 18pt vertical translation`).
2. The focused catalog card separately changes focus geometry (`82% unfocused size -> 390x220 focused size`, `-6pt resting offset`, sideways effect, plus the Search-style focus-arrival spring).

On close there was a third timing conflict: the outgoing catalog uses a 0.20 s visible close, but Live TV focus restoration was scheduled at **0.120 s**, while the catalog was still visibly composited. That allows tvOS to release the catalog `FocusState` and shrink/reposition the focused card before catalog opacity reaches zero.

This is why shortening transition duration alone did not solve the physical behavior.

## vBRDC109 architecture correction

The cross-surface transition now has **one geometry owner**.

### Opening

- The persistent catalog shell remains mounted as before.
- A dedicated `unityCatalogBranchTransitionActive` state begins before any visible motion.
- The active catalog row receives a visual-focus pin while catalog opacity is still zero.
- The selected card is committed immediately to its final focused geometry with animations disabled.
- The card's independent Search-style focus arrival and 0.36 s focus-geometry spring are disabled for this boundary.
- Invisible preflight is **0.034 s** (two 60 Hz render turns), allowing FocusState/layout to settle before the first visible pixel.
- Only then does the existing catalog surface compositor animate for **0.22 s**.

### Closing

- The focused card remains visually pinned at its exact focused geometry through the complete visible close.
- Only the catalog surface compositor performs the **0.20 s** reverse transition.
- The catalog branch reaches zero opacity / completes its branch settle at **0.205 s**.
- Live TV focus restoration is delayed until **0.220 s**, after the outgoing catalog is invisible.
- The visual-focus pin is then released with animations disabled while the catalog shell remains hidden/persistent.

## What is intentionally unchanged

- All 48 catalog row scrolling animation definitions (`UnityCatalogVisualSystem.swift`) are byte-identical to vBRDC108.
- vBRDC103 persistent row renderer and retained focused artwork behavior.
- vBRDC104 persistent catalog shell.
- vBRDC105 Live TV fast return + 3 s dwell / 15 s preview.
- vBRDC106 VOD Cast / Production visible-only 7-second rotation and Cast Explorer playback-artwork lane.
- vBRDC107 focused preview media-identity ownership.
- vBRDC108 Live TV real-logo-wins fallback and Media Profile 0.20 s handoff.
- `RemoteImageFit.swift`, `CatalogStore.swift`, `CastExplorerService.swift`, and `UnityAnimationCoordinator.swift` are byte-identical to the donor.
- Providers, playback/resume, Source Intelligence, TorBox/Usenet, Gracenote schedule data, Dynamic Wallpaper themes, and VOD overlay visuals are unchanged.

## Validation

- vBRDC109 catalog-boundary/invariant contract: **37/37**
- Production Swift parse: **65/65**
- Version/project metadata: **8/8**
- Backend regression suite: **36 tests + 2 subtests passed**
- Existing donor-file scope: **exactly 5 files changed**
  - `Sources/DebridChannelsTVOSApp.swift`
  - `Sources/UnityFrameRuntime.swift`
  - `Sources/Info.plist`
  - `TopShelfExtension/Info.plist`
  - `project.yml`
- `UnityCatalogVisualSystem.swift`: byte-identical to donor
- ZIP integrity: passed

Physical Apple TV testing remains authoritative for frame pacing. This build specifically targets the two-shift opening/closing sequence visible in `38435.mp4`; it does not alter the row-scrolling behavior that the user already confirmed is working.
