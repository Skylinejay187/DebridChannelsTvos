# Debrid Channels vBRDC117 — Standard VOD Bluetooth / Now Playing Recovery

Release: **vBRDC117**  
Marketing version: **1.0.820**  
Apple build: **820**

## Scope

vBRDC117 is built only from packaged vBRDC116. It corrects the VOD Bluetooth/headset Play/Pause path without changing catalog scrolling, the 35-second catalog preview cap, Live TV/Gracenote/MediaFlow routing, Dynamic Wallpaper, VOD visuals, source intelligence, debrid/Usenet, or backend behavior.

## Root cause

vBRDC111 registered Play, Pause, and Toggle Play/Pause handlers on `MPRemoteCommandCenter`, but the custom VOD/KS playback surface did not publish `MPNowPlayingInfoCenter` metadata or explicitly activate a movie-playback `AVAudioSession`. A custom tvOS player can therefore have valid command handlers in source while still not becoming the system's active Now Playing media app, so Bluetooth/headset transport events may never be routed to those handlers.

## Correction

- VOD claims a playback-only audio session using `.playback` + `.moviePlayback`.
- The active VOD publishes title, duration, playhead, playback rate, and non-live state to `MPNowPlayingInfoCenter`.
- Play/Pause state changes immediately refresh Now Playing state.
- Timeline progress refreshes Now Playing at a bounded 5-second cadence.
- Existing `MPRemoteCommandCenter` handlers for Play, Pause, and Toggle Play/Pause remain the single external accessory command bridge.
- Existing SwiftUI `onPlayPauseCommand` remains as the Siri Remote/tvOS fallback, with the previous duplicate-event guard preserved.
- VOD release clears Now Playing info and deactivates the owned playback audio session.
- Commands remain VOD-only and do not claim Live TV, catalog previews, trailers, or navigation.
- The existing Bluetooth Media Play/Pause setting remains default-On as the opt-out control.

## Compile containment

vBRDC113's split VOD modifier graph remains intact. vBRDC117 adds no new SwiftUI modifier layers; the Now Playing updates are inserted into existing lifecycle/state callbacks to avoid reintroducing the type-check failures seen in vBRDC111/vBRDC112.

## Validation

- 34/34 vBRDC117 feature/regression contracts passed.
- 65/65 production Swift files parsed.
- 74/74 total Swift files parsed.
- 8/8 version/project checks passed.
- 36 backend regression tests passed.
- Exactly four existing donor files changed from vBRDC116: main Swift source plus normal version metadata.

GitHub Actions/Xcode remains the authoritative full tvOS compile and a physical Apple TV + Bluetooth headset test remains authoritative for hardware transport delivery.
