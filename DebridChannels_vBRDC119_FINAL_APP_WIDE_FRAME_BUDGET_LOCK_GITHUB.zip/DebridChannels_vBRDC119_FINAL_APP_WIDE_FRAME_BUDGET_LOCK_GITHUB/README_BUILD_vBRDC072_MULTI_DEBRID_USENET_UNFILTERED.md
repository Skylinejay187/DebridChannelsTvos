# Debrid Channels vBRDC072 — Multi-Debrid + Unfiltered Native Usenet

- Release ID: **vBRDC072**
- Marketing version: **1.0.775**
- Apple build: **775**
- Code Name: **UNITY**
- Donor: packaged **vBRDC071** only
- Backend: **v694 unchanged**

## Native TorBox Usenet no longer uses the ordinary Best-Ranked cap

Native TorBox Usenet is now a separate Source Intelligence publication lane. Every valid, deduplicated Usenet discovery row returned by the TorBox Newznab/native-owned discovery path is retained. The global 25/50 Best-Ranked setting continues to cap ordinary torrent/debrid/In-S results only.

This rule is applied at every publication boundary, including late In-S incremental updates, so a late provider cannot accidentally re-cap or remove already-visible Usenet rows.

The Usenet lane remains independent of Torrentio. A valid TorBox API key is the only credential gate for native TorBox Usenet.

## Torrentio is account-scoped

vBRDC071 and older had one global `managedTorrentioEnabled` flag. vBRDC072 replaces that with one independent flag per debrid account:

- Real-Debrid
- TorBox
- Premiumize
- AllDebrid
- Debrid-Link
- EasyDebrid
- Offcloud
- Put.io

A user can therefore keep `Torrentio • Real-Debrid` while removing `Torrentio • TorBox`, or the reverse. Removing a Torrentio attachment never deletes the debrid credential. Removing Torrentio from TorBox also never disables native TorBox Usenet.

Legacy upgrades and legacy profile restores migrate the old global Torrentio switch into per-account flags only for credentials that are actually configured, without overwriting a later explicit per-account choice.

## Eight debrid services in Global Debrid Credentials

Global Debrid Credentials now accepts all eight debrid services exposed by Torrentio's current configuration surface. Put.io uses its Client ID + OAuth token pair. Managed Torrentio creates one isolated manifest per enabled account, so credentials are never combined across debrid services.

Connection Status validates direct account/API reachability where a safe account/read endpoint exists and validates each enabled Torrentio manifest independently.

## Resolver isolation

An explicitly labeled Premiumize/AllDebrid/TorBox/Debrid-Link/EasyDebrid/Offcloud/Put.io hash can no longer fall through the Real-Debrid magnet resolver. Managed debrid addons are expected to return a direct playable URL for their own service. This prevents accidental Real-Debrid usage when another provider supplied the row.

## Credential boundary and backup

Fresh-install cleanup and the explicit protected profile backup allowlist now include the new debrid credentials and all per-account Torrentio switches. No new production credential defaults are hardcoded.

## Preserved from vBRDC071

- Sports UNITY hero/theme integration
- all 48 catalog scrolling motion presets
- vBRDC069 adaptive large-file VOD memory buffer
- TorBox Newznab-first discovery + backend v694 relay + owned-library fallback
- NZB URL handoff with NZB upload fallback
- FebBox / MediaFlow / In-S fresh-install credential boundary
- Live TV/Sports direct tune

## Validation

- 62/62 Swift files syntax-parse
- debrid credential bridge + managed Torrentio + health client isolated type-check
- TorBoxUsenetClient isolated type-check
- 9/9 vBRDC072 contract tests
- 8-provider managed-manifest runtime test
- legacy global-Torrentio restore migration runtime test
- 35 inherited backend runtime tests
- production hardcoded debrid credential scan: 0 findings
- adaptive playback file byte-identical to vBRDC071
- 48-motion definition file byte-identical to vBRDC071
- Sports UNITY block byte-identical to vBRDC071
- both plist targets + both XcodeGen target blocks: 1.0.775 / 775 / vBRDC072

GitHub Actions/Xcode remains authoritative for the Apple SDK compile/link. Physical Apple TV testing remains required for provider behavior against real user accounts.
