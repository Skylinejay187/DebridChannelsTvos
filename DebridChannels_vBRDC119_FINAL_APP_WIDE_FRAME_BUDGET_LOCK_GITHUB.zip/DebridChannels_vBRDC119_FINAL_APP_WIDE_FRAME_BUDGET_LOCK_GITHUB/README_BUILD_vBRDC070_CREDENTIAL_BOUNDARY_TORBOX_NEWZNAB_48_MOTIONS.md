# Debrid Channels vBRDC070 — Credential Boundary + TorBox Pro Newznab + 48 Catalog Motions

- Release ID: **vBRDC070**
- Marketing version: **1.0.773**
- Apple build: **773**
- Code Name: **UNITY**
- Donor: corrected packaged **vBRDC069** only
- Backend: **v694 TorBox Pro Newznab relay** over the existing backend runtime

## 1. Fresh-install credential boundary

Apple Keychain data can outlive an app container. Earlier Debrid Channels builds therefore allowed FebBox, MediaFlow and In-S password fields to reappear after deleting and reinstalling the app.

vBRDC070 adds an installation sentinel in Application Support that is excluded from device backup. On the first vBRDC070 upgrade from an existing installation, the sentinel is established without signing the user out. On a true reinstall after the boundary exists (or a genuinely clean first install), stale user credentials/configuration are removed before normal catalog/provider startup reads them.

Fresh-install cleanup includes:

- FebBox `ui` cookie Keychain item
- MediaFlow API password Keychain item
- all In-S password-style Keychain items and repository configuration
- TorBox / Real-Debrid API keys and retired Torrentio override keys
- artwork-provider API keys/tokens
- Xtream password/source credentials and user-entered Live TV source configuration
- backup bookkeeping/restore code from the previous installation

The stable production device identity is not a provider credential and remains separate because membership/device entitlement uses it.

### Explicit backup is the only credential migration route

Keychain-only secrets are not added to ordinary UserDefaults. When the user explicitly creates a Debrid Channels profile backup, the app builds a tightly allowlisted `credentialVault` containing only:

- FebBox cookie
- MediaFlow API password
- In-S repository/password backup envelope

Those values are restored only from that explicit backup. Repository definitions strictly define which In-S password keys may be restored.

## 2. TorBox Pro Usenet — Newznab-first discovery

The old Debrid Channels implementation relied primarily on TorBox Voyager JSON search routes. TorBox's paid Newznab-compatible endpoint is now the authoritative app discovery path:

- base: `https://search-api.torbox.app/newznab`
- API path: `/api`
- movie search: `t=movie`
- TV search: `t=tvsearch` with season/episode
- generic full-text fallback: `t=search`
- API key supplied only for the live authenticated request

Discovery order is now:

1. TorBox Newznab directly from Apple TV
2. Debrid Channels backend v694 Newznab relay as an independent network path
3. legacy Voyager JSON search only as compatibility fallback
4. matching owned `/usenet/mylist` jobs

A genuine zero from one route no longer suppresses the next route.

### XML normalization

The app and backend now parse Newznab RSS/XML results, including title, download/enclosure URL, size, indexer/source, age/date, and available cache/owned metadata. The backend normalizes XML into the existing `data.nzbs` JSON contract so Source Intelligence does not need a second result model.

### NZB handoff fallback

TorBox Main API supports both an accessible NZB link and an uploaded NZB file at `/v1/api/usenet/createusenetdownload`. vBRDC070 tries the Newznab handoff link first. If TorBox rejects that link (for example, redirect/accessibility differences), Debrid Channels fetches the authenticated NZB in memory and uploads it as `application/x-nzb`. The NZB is never written to disk.

## 3. Catalog row scrolling motion library — 48 presets

The motion picker is expanded from 24 to **48** choices. Only the selected preset executes; adding choices does not create additional background animation engines.

The original choices remain, plus:

- Focus Rush
- Velvet Slide
- Horizon Glide
- Magnetic Pull
- Spring Roll
- Feather Sweep
- Turbo Flick
- Camera Dolly
- Lens Pull
- Stage Slide
- Portal Zoom
- Sidewinder
- Pendulum
- Helix Tilt
- Prism Drift
- Cascade
- Hover Shift
- Satellite
- Backdrop Push
- Recoil
- Whisper Snap
- Overshoot Glide
- Gravity Drop
- Lift Off

All presets remain presentation-only. They do not mutate selected index, own focus, change catalog geometry, move rows vertically, or touch playback.

## Preserved from vBRDC069

The adaptive VOD memory-pressure fix remains unchanged: large/high-memory VOD files use the bounded 30-second KSPNUVIO lane, medium known files use 120 seconds, small files can retain the 300-second deep reserve, and unknown-size sources use the fail-safe 90-second maximum.

## Validation targets

- both app plists: `1.0.773 / 773 / vBRDC070`
- both XcodeGen target version blocks: `1.0.773 / 773`
- all Swift source files syntax-parse
- TorBoxUsenetClient standalone Foundation type-check with MediaItem fixture
- backend v694 Python compile + Newznab relay unit tests
- vBRDC070 contract tests
- fresh-install credential/keychain static audit
- donor diff limited to intended credential, backup, TorBox, motion, version and documentation files
- ZIP integrity test

GitHub Actions/Xcode remains authoritative for the Apple SDK compile/link. Physical Apple TV testing is required for provider network behavior, fresh uninstall/reinstall behavior, and focus/motion feel.
