# Debrid Channels vBRDC071 — Sports UNITY Hero Theme Integration

- Release ID: **vBRDC071**
- Marketing version: **1.0.774**
- Apple build: **774**
- Code Name: **UNITY**
- Donor: packaged **vBRDC070** only
- Backend: **v694 unchanged**

## Sports is now a complete UNITY visual branch

vBRDC070 already kept Sports inside the UNITY navigation tree and reused the shared fixed-slot catalog rail. The remaining seam was visual: Sports used a hard-coded Sports glass hero and did not resolve the same `liveTVGridThemePreset` / `CatalogArtworkCacheManager.ThemeFlags` used by Home, Movies and Shows.

vBRDC071 removes that visual split. Sports now reads the exact same theme preference and theme flags as the catalog branches. No second Sports-theme preference is introduced.

### Shared theme behavior

Sports now responds immediately to:

- Classic Dark
- Channels Glass
- Frosted Guide
- Pure Black
- Midnight Blue
- Neon Edge
- Carbon OLED
- Artwork
- Artwork 2
- Artwork 3 Hero
- Artwork 4 Hero 2
- Artwork 5 Floating

For normal/non-artwork themes, Sports preserves its existing compact live widget over the real Live TV root. For artwork/hero themes, Sports uses the same catalog artwork-theme flags for backdrop opacity, saturation, contrast, hero depth intent, transparent/floating presentation, and Pure Black/Artwork 3 root-first behavior.

### Persistent Live TV root preserved

Artwork 3 Hero and Pure Black do not construct a duplicate channel grid or fake background. The actual `LiveTVScreen` remains mounted underneath the Sports branch and Sports adds only protective gradients / hero presentation over it, matching the UNITY contract used by Home/Movies/Shows.

Artwork, Artwork 2, Artwork 4 Hero 2 and Artwork 5 Floating can use the currently focused Sports event/channel artwork as a retained-frame backdrop while the real Live TV surface stays mounted underneath.

### Sports hero presentation

The Sports hero now has a UNITY-aware presentation for hero themes:

- selected event/channel identity follows the focused fixed-slot card
- theme name and active Sports row are reflected in the hero
- live/source status remains visible
- Artwork 4 / Artwork 5 use the floating glass treatment
- Artwork 3 / Pure Black keep the clean root-first hero presentation
- focused Sports artwork uses the same retained-frame image path to avoid a black flash during rapid card movement

## Shared catalog row motion preserved

Sports already uses `GridOSFixedSlotCatalogRail`, so all **48 catalog scrolling motion presets** from vBRDC070 continue to work on Sports rows automatically. vBRDC071 does not add a duplicate Sports animation engine or a separate setting.

## Playback behavior preserved

Sports direct-tune behavior is unchanged. A Sports `MediaItem` with `type == "live"` still bypasses VOD Media Information / Source Intelligence and starts its stream directly on Select or Play/Pause.

## Preserved from vBRDC070

- fresh-install credential boundary / explicit backup credential vault
- TorBox Pro Newznab-first Usenet discovery and NZB upload fallback
- 48 catalog scrolling motion presets
- vBRDC069 adaptive large-file VOD memory buffer
- backend v694 unchanged

## Validation targets

- both app plists: `1.0.774 / 774 / vBRDC071`
- both XcodeGen target version blocks: `1.0.774 / 774`
- every Swift source file syntax-parses
- Sports resolves `liveTVGridThemePreset` through `CatalogArtworkCacheManager.themeFlags`
- Sports hero/background follows the focused Sports `MediaItem` without changing focus ownership
- shared `GridOSFixedSlotCatalogRail` remains the Sports card rail
- Sports live direct-tune path remains present and unchanged
- backend v694 test suites remain green
- donor diff limited to Sports UNITY integration, version metadata, validation and this build note
- ZIP integrity test

GitHub Actions/Xcode remains authoritative for the Apple SDK compile/link. Physical Apple TV testing is required for hero-theme feel and focus behavior.
