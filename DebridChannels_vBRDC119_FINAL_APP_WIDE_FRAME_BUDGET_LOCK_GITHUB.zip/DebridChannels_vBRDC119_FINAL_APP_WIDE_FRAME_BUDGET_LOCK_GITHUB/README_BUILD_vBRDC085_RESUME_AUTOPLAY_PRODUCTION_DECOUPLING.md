# Debrid Channels vBRDC085 — Resume Autoplay + Production Decoupling

**Marketing version:** 1.0.788  
**Apple build:** 788  
**Release ID:** vBRDC085  
**Donor:** packaged vBRDC084 only

## Physical-test regressions targeted

### 1. Find Links resume landed at the saved time but remained paused

The Play chip and Find Links ultimately enter the same VOD player, but the KSPlayer resume path had a state/engine mismatch after an in-place resume seek. `isPlaying` could already be `true` when the saved clock position was confirmed, so assigning `true` again did not guarantee a SwiftUI update and therefore did not guarantee a fresh `KSPlayerLayer.play()` command. Some KSPNUVIO sources could also emit a transient `finish(nil)` while the decoder was flushing the resume seek, which could flip the VOD screen back to paused even though the resume clock had landed correctly.

vBRDC085 adds an **explicit KS play-assertion serial** that travels from `VODPlayerScreen` through `UniversalVideoSurface` and `PlaybackKitKSPlayerHost` into the persistent `KSPlayerVideoSurface`. When automatic resume is confirmed, the serial changes and the existing KS layer receives a direct Play assertion plus the already-bounded post-seek liveness recovery. No surface recreation is used.

A short, eight-second confirmed-resume guard also ignores a transient `finish(nil)` when playback is still requested and the authoritative clock is not genuinely near natural EOF. Real completion still follows the normal end-of-playback path.

**User Pause remains authoritative:** changing the requested play state to paused still increments the recovery generation and calls `layer.pause()`, invalidating any delayed autoplay recovery immediately.

### 2. Production information only finished loading after Play/Pause

This coupling was real. vBRDC076 intentionally moved decorative VOD metadata work, including Production, into the pause-time enrichment window for playback-performance protection. That made the Production panel visibly depend on pressing Play/Pause.

vBRDC085 separates Production from the heavier decorative work:

- Production metadata starts as one bounded **background-priority** session fetch after the first stable VOD frame.
- It no longer requires controls to be visible.
- It no longer requires the side panel to be closed.
- It is not cancelled simply because playback is active or the controls auto-hide.
- Opening controls can request the same Production snapshot without requiring the movie to be paused.

Review-score lookup, runtime lookup, and the heavier playback metadata hydration remain pause-time work, preserving the playback-priority protections introduced in vBRDC076.

## Intentionally unchanged

- Resume identity/cache format and exact same-title protections from vBRDC084.
- Catalog source/link selection behavior.
- Source Intelligence providers.
- TorBox / Usenet implementation.
- UNITY coordinators and surface lifecycle system.
- Dynamic wallpaper / Nexus Lines implementation.
- Production metadata service implementation itself; only the VOD scheduling/lifecycle policy changed.
- Existing KSPlayer surface ownership and in-place seek architecture.

## Validation completed in package

- 53/53 vBRDC085 regression-contract checks passed.
- All app/Top Shelf Swift files passed `swiftc -parse`.
- App and Top Shelf plist versions plus `project.yml` version/build alignment passed.
- Inherited backend regression suites passed: 35 tests + 2 subtests.
- Sensitive unrelated source files are SHA-256 locked to the packaged vBRDC084 donor.
- Final package manifest and ZIP integrity are verified before delivery.

Physical Apple TV testing remains authoritative for the KSPlayer decoder timing regression this build targets.
