# Debrid Channels vBRDC062 — UNITY / Instant VOD + Background Buffer Ghost

- Release ID: **vBRDC062**
- Marketing version: **1.0.765**
- Apple build: **765**
- Code Name: **UNITY**
- Built only from packaged **vBRDC061**
- Backend: **v693 unchanged**

## Goal

Keep VOD startup immediate while the player continues building a deep forward reserve in the background, and make that reserve visible on the existing VOD scrubber.

## Instant first-frame, deep background reserve

Main VOD restores KSPNUVIO's instant-open behavior (`isSecondOpen = true`). The player is allowed to begin as soon as decodable media is available instead of waiting for the preferred reserve to fill first.

This does **not** reduce the existing buffer targets:

- Ordinary VOD preferred forward reserve remains **5 seconds**.
- High-memory 4K/UHD/remux/TrueHD/DTS-HD VOD preferred reserve remains **3 seconds**.
- Main VOD maximum forward-buffer window remains **300 seconds / 5 minutes** from vBRDC061.

The important change is that startup latency and background buffer depth are now independent: playback can begin immediately while the reader keeps filling ahead.

## Real buffer ghost on the VOD scrubber

The scrubber now receives KSPNUVIO's actual `MediaPlayerProtocol.playableTime` endpoint. KSMEPlayer derives this from the current playback clock plus the engine's real loaded time, so the UI does not estimate or animate fake progress.

- Bright blue = played/current progress.
- Translucent blue = media currently playable from the forward buffer.
- Small translucent ghost dot = current buffer head as it advances.
- White scrubber dot = playback/seek position, unchanged.

A source-generation ownership check prevents callbacks from an outgoing player from extending the new source's buffer ghost. The ghost resets to the current playhead whenever a new KS surface generation is created.

## Debrid/CDN interruption resilience

Main VOD now adds FFmpeg reconnect handling for transient network/CDN failures while already-buffered media continues to render:

- TCP/TLS/network reconnect enabled.
- Retry HTTP **408, 429, 500, 502, 503, 504**.
- Authorization failures such as **401/403 are not retried**.
- Reconnect delay ceiling for VOD is **2 seconds**.

Live TV and trailer format-option profiles remain unchanged.

## What this is not

This release does **not** pretend that the current time-based KSPNUVIO packet buffer is a 100 MB / 300 MB / 500 MB / 1 GB cache. A true byte-budgeted or unlimited/full-title cache remains future work for the premium KSPlayer cache layer, where memory/disk ownership can be enforced correctly.

## Physical Apple TV test

1. Start several normal VOD titles and confirm first frame is not delayed while waiting for a deep reserve.
2. Open the VOD controls and confirm the translucent buffer rail/dot grows ahead of the white playback thumb while the movie continues.
3. Test a title through a debrid/CDN path with intermittent throughput and confirm buffered video continues while the source reconnects.
4. Seek to a new position/source and confirm the ghost resets instead of retaining the outgoing source's buffered endpoint.
5. Verify Live TV and trailer startup/buffering are unchanged.

GitHub Actions/Xcode remains the authoritative Apple-platform compile; physical Apple TV playback remains required before declaring this candidate stable.
