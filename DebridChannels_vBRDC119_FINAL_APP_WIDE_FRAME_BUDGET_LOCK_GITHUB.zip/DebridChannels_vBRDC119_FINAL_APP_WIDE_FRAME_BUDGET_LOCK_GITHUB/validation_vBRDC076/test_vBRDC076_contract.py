from pathlib import Path
import plistlib, unittest, hashlib

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
KS = (ROOT/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
FOUND = (ROOT/'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
CAT = (ROOT/'Sources/CatalogStore.swift').read_text()

class Contract(unittest.TestCase):
    def test_01_version(self):
        with open(ROOT/'Sources/Info.plist','rb') as f: d=plistlib.load(f)
        self.assertEqual(d['CFBundleShortVersionString'],'1.0.779')
        self.assertEqual(str(d['CFBundleVersion']),'779')
        self.assertEqual(d['DebridChannelsReleaseID'],'vBRDC076')

    def test_02_buffer_publication_has_hard_one_second_gate(self):
        self.assertIn('private let minimumBufferPublicationInterval: CFTimeInterval = 1.00', KS)
        self.assertIn('guard force || (intervalElapsed && meaningfulAdvance) else { return }', KS)
        self.assertNotIn('guard force || meaningfulAdvance || now - lastBufferPublicationHostTime', KS)

    def test_03_hidden_overlay_receives_no_buffer_state_invalidations(self):
        self.assertIn('guard controlsVisible || activePanel != nil || isScrubbingTimeline || isSeekingInPlayer else { return }', APP)
        self.assertIn('playableTime is telemetry for the visible', APP)

    def test_04_overlay_snapshot_bridge_is_one_hz(self):
        self.assertIn('Date().timeIntervalSince(lastPublicationDate) >= 1.00', FOUND)
        self.assertNotIn('Date().timeIntervalSince(lastPublicationDate) >= 0.20', FOUND)

    def test_05_playing_overlay_does_not_launch_review_production_work(self):
        self.assertIn('visible && activePanel == nil && isFirstFrameReady && !isPlaying', APP)
        self.assertIn('controlsVisible && isFirstFrameReady && !isPlaying', APP)
        self.assertIn('controlsVisible && activePanel == nil && !isPlaying', APP)

    def test_06_active_playback_cancels_decorative_work(self):
        block = APP.split('.onChange(of: isPlaying) { playing in',1)[1].split('.onChange(of: activePanel)',1)[0]
        for needle in ['vodReviewTask?.cancel()', 'vodProductionMetadataTask?.cancel()', 'runtimeLookupTask?.cancel()', 'playbackMetadataTask?.cancel()']:
            self.assertIn(needle, block)
        self.assertIn('Paused playback is the safe enrichment window.', block)

    def test_07_first_frame_remote_enrichment_is_pause_only(self):
        self.assertIn('if !isPlaying {\n                        startPlaybackMetadataHydration()', APP)
        self.assertIn('startRuntimeMetadataLookupIfNeeded(delayNanoseconds: 1_100_000_000)', APP)

    def test_08_playing_overlay_show_is_atomic(self):
        self.assertIn('if isPlaying {\n            controlsVisible = true', APP)
        self.assertIn('.transition(isPlaying ? .identity : .opacity)', APP)

    def test_09_up_next_network_work_is_deferred(self):
        stable = APP.split('.onChange(of: hasStableFirstFramePlayback)',1)[1].split('.onChange(of: ksSurfaceToken)',1)[0]
        self.assertNotIn('startUpNextPreparationIfNeeded()', stable)
        self.assertIn('(upNextNaturalEndPending || remaining <= 360)', APP)

    def test_10_automatic_resume_confirmation_survives(self):
        for needle in ['reconcileAutomaticResumePlaybackClock(current: current)', 'Automatic resume confirmed at', 'pendingAutomaticResumeSeconds']:
            self.assertIn(needle, APP)

    def test_11_v075_appearance_controls_survive(self):
        for needle in ['mediaInfoConnectorLineEnabled', 'topLeftDebridChannelsLogoEnabled']:
            self.assertIn(needle, APP)

    def test_12_fanart_provider_stays_enabled(self):
        self.assertIn('fetchFanartArtwork', CAT)
        self.assertNotIn('Fanart.tv remote fetch disabled for v711 stability', CAT)

    def test_13_torbox_donor_path_survives_while_whitelist_pending(self):
        tor = (ROOT/'Sources/TorBoxUsenetClient.swift').read_text()
        self.assertIn('search-api.torbox.app', tor)
        self.assertIn('TorBox Pro Search Bridge', (ROOT/'README_BUILD_vBRDC075_TORBOX_BRIDGE_ARTWORK_CONTROLS.md').read_text())

    def test_14_resume_cache_format_file_is_unchanged_from_v075_donor(self):
        donor = Path('/mnt/data/v075src/DebridChannels_vBRDC075_TORBOX_BRIDGE_ARTWORK_CONTROLS_GITHUB/Sources/PlaybackResumeCache.swift')
        current = ROOT/'Sources/PlaybackResumeCache.swift'
        if donor.exists():
            self.assertEqual(hashlib.sha256(donor.read_bytes()).hexdigest(), hashlib.sha256(current.read_bytes()).hexdigest())

if __name__ == '__main__':
    unittest.main(verbosity=2)
