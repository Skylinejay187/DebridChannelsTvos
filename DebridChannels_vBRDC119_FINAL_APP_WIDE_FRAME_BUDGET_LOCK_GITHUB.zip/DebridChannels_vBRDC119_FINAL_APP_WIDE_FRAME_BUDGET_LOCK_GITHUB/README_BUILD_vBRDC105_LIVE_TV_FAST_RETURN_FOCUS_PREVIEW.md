# Debrid Channels vBRDC105 — Live TV Fast Return + Focus Preview

- Release ID: `vBRDC105`
- Marketing version: `1.0.808`
- Apple build: `808`
- Donor: packaged `vBRDC104 — Persistent Catalog Surface Handoff`

## Purpose

vBRDC105 is a tightly scoped Live TV build. It addresses the physical Apple TV report that the Live TV grid can appear stuck/sluggish after exiting full-screen Live TV playback, and it adds an optional focused-channel preview without creating a continuously probing/background preview system.

## 1. Live TV playback return — single-pass focus-first recovery

The previous return route stacked several independent recovery mechanisms: the root playback-close recovery could issue multiple checkpoints, while the Live TV grid performed repeated materialization/readiness/focus attempts. Heavy artwork/guide work could also resume before the saved Live TV focus target had regained ownership.

vBRDC105 gives Live TV a dedicated fast-return lane:

- Detects a Live TV return from the saved `LiveTVFocusSnapshot`.
- Skips catalog-wide premium artwork rehydration on the critical return frame.
- Restores the saved category/channel/window before nonessential Live TV refresh work is resumed.
- Uses a bounded two-pass, nonanimated grid recenter rather than the old repeated scroll loop.
- Uses one focus bind plus at most one short corrective bind instead of a multi-attempt focus storm.
- Keeps the exact saved snapshot alive if its provider channel is not yet materialized; provider completion may perform the one later retry instead of tight polling.
- Defers Gracenote/artwork/Live TV refresh work until the focus target has been restored.
- Suppresses the existing Guide preview while the playback-return focus handoff is in progress.
- Late restore tokens cannot jump the grid back to the first channel after the saved snapshot has already been consumed.

This is intended to make playback → grid return immediately interactive while retaining the current Gracenote schedule, artwork, category, and channel-position behavior.

## 2. Live TV Focus Preview

A new setting named **Live TV Focus Preview** is available in the Live TV settings section. It is enabled by default and can be turned Off.

The runtime contract is intentionally strict:

1. A Live TV grid card must remain the exact focused card for **3.0 seconds**.
2. At the 3-second boundary, the app checks that the grid still owns the surface and that the auxiliary decoder lane is available.
3. If allowed, that one focused channel starts a **muted** in-card preview.
4. The preview has a hard **15.0-second wall-clock ceiling** and then stops.
5. It does not repeat while focus remains on the same card. A new focus movement creates a new dwell session.
6. If the preview cannot start at the 3-second boundary, it is skipped. There is **no retry loop, neighbor probing, continuous hunting, or background channel scanning**.

The preview is cancelled immediately when:

- focus moves to another channel;
- the user leaves the Live TV tab;
- full-screen playback begins;
- the full Guide is opened;
- Live TV Tools/quick window opens;
- a channel action overlay opens;
- the preview setting is switched Off;
- the Live TV screen disappears.

The preview uses the existing Live TV MediaFlow routing policy and KSPlayer video surface when available. Audio is always muted. It is registered as auxiliary video activity so existing decoder/resource ownership rules remain authoritative.

## 3. Full-screen playback remains authoritative

Clicking a channel always wins over a preview. Any active grid/guide preview is cancelled first. The app waits for an auxiliary decoder handoff only when an auxiliary preview was actually active/recent; with no preview owner, normal Live TV playback follows the existing immediate launch path.

## 4. Dynamic Wallpaper/resource isolation

While the 15-second grid preview is actually playing, Dynamic Wallpaper temporarily yields and resumes after the preview ends. This prevents two continuous visual/video lanes from competing for the Apple TV GPU/decoder budget while preserving the user's wallpaper and Dynamic Wallpaper configuration.

## Preserved behavior

This build does not alter the vBRDC103 persistent row renderer or its 48 row animation definitions, and it retains vBRDC104's persistent catalog surface handoff. Providers, VOD playback/resume, Sports, Favorites, TorBox/Usenet, Source Intelligence, and backend runtimes are unchanged by this build.

## Validation

- vBRDC105 contract: **56/56**
- Swift syntax parse: **65/65**
- version/project checks: **8/8**
- unchanged backend tests: **36 passed + 2 subtests**
- changed existing donor files: **4**, exact expected set
- `UnityCatalogVisualSystem.swift`: byte-identical to vBRDC104

Physical Apple TV testing remains authoritative for perceived frame pacing and real stream-preview compatibility.
