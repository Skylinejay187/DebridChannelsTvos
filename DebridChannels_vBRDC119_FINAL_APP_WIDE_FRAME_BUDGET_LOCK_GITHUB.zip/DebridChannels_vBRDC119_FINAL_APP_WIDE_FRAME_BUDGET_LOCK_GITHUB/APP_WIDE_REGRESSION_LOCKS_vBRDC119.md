# Debrid Channels vBRDC119 — App-Wide Regression Locks

These rules define accepted behavior for vBRDC119 and future additive builds.

## Performance invariants

1. **Navigation owns the frame.** Expensive supporting work may defer while focus/transition geometry is moving.
2. **Frame waiting is event-driven.** Do not reintroduce independent short-interval polling loops per deferred caller.
3. **Authoritative results are durable.** An already-fetched provider/catalog/guide/decode result may wait to publish, but must not be discarded solely because a courtesy frame timeout expired. Cancellation/supersession remains valid.
4. **Speculative work may be skipped.** Hidden prefetch, prewarm, and equivalent retryable work may use bounded courtesy waits/cancellation.
5. **Do not republish identical large model snapshots.** Catalog row arrays and Live TV channel/guide snapshots must equality-guard equivalent assignments.
6. **Live TV programme identity must remain stable** for equivalent programme/schedule data.
7. **Live TV focus/channel lookup remains indexed** rather than full-array scanning in high-frequency paths.
8. **Heavy M3U/Xtream/XMLTV parsing remains off the MainActor**; UI publication returns to the model only after transformation is complete.
9. **XMLTV does not duplicate complete programme collections under aliases.** Keep canonical storage + alias lookup.
10. **Large guide cache encoding/writes stay off the MainActor and coalesced.**
11. **Paused animated wallpaper does not poll.** Keep event-driven pause/resume with exact frame retention.
12. **High-frequency episode metadata/scanning must reuse parser objects** instead of constructing formatter/regex stacks per row.
13. **High-frequency VOD state callbacks must avoid equivalent state writes.**
14. **Do not lower artwork quality, remove effects, or remove/shorten animations to meet a performance target.**

## Catalog / Search / Media Profile locks

- Keep the vBRDC103 persistent fixed-slot catalog renderer and existing row motions.
- Keep the approved retained-artwork handoff; do not introduce blank/black artwork between focused cards.
- Keep the Search-style focused card presentation.
- Keep vBRDC109 single-owner catalog surface open/close behavior.
- Keep the vBRDC088 fixed-slot source-card geometry measurement; do not measure the bouncing/pulsing transformed card every frame.
- Same-title Media Profile/button/cast movement does not stop the focused catalog preview solely because focus moved inside that item's UI.
- Moving to another catalog item/row replaces ownership as designed.
- Focused catalog preview: 1.5-second dwell, maximum 35 seconds, then stop/fade to artwork; no infinite loop.
- Explicit Trailer launch may play the full trailer and owns playback normally.

## VOD locks

- Resume behavior, manual Find Links resume, source switching, playback, scrubber, subtitles/audio, KSPlayer behavior remain unchanged unless explicitly scoped.
- Bluetooth/media accessory Play, Pause and Toggle remain standard VOD behavior through AVAudioSession + Now Playing + MPRemoteCommandCenter.
- VOD Cast and Production rotation remains visible-only and uses the accepted 7-second cadence.
- vBRDC119 Cast manual browsing:
  - LEFT/RIGHT while Cast is focused browses image-backed cast members;
  - browsing wraps;
  - manual selection resets the existing 7-second hold rather than adding a second timer;
  - temporary chevrons remain inside the portrait and fade;
  - Select opens Cast Explorer for the displayed member.
- Cast portrait/name/Select identity remains atomic.
- Episode Alert passive banner remains 530x176 and 18 points from the selected screen edge.

## Live TV locks

- Keep Live TV channel grid, Quick Guide, schedule/current-next behavior and focus semantics.
- Keep focus preview's accepted dwell/preview/one-shot behavior.
- Successful lineup/Gracenote/XMLTV/Xtream results cannot be dropped because the UI remained busy.
- Keep vBRDC115 MediaFlow LAN/away-from-home behavior; `MediaFlowProxyRouter.swift` is intentionally unchanged in vBRDC119.
- Keep provider sources and Gracenote/XMLTV mapping behavior.
- Real channel/provider artwork supersedes generic text; generic fallback appears only when real artwork is unavailable/failed.

## Dynamic Wallpaper / appearance locks

- Keep every existing Dynamic Wallpaper theme and current visual quality.
- Wallpaper may pause expensive decoder work according to existing lifecycle rules, but must retain the exact visual frame and resume without resetting appearance.
- Keep existing main-grid background, Connected popup artwork, pulse, top-menu themes and appearance settings.

## Provider / backend locks

- Do not remove or conflate Real-Debrid, TorBox, Usenet, Xtream, M3U, Channels DVR, HDHomeRun, Gracenote/XMLTV, plugins, Sports, or existing provider credentials/routing.
- Do not let performance scheduling destroy successful provider data.
- Keep current backend/runtime tests passing.

## Files intentionally hash-locked from vBRDC118

- `Sources/UnityCatalogVisualSystem.swift`
- `Sources/UnityAnimationCoordinator.swift`
- `Sources/MediaFlowProxyRouter.swift`
- `Sources/CastExplorerService.swift`
- `Sources/SportsCenterViewModel.swift`
- `Sources/PlaybackKit/PlaybackKitFoundation.swift`

The vBRDC119 contract verifies these donor hashes.
