# vBRDC108 App-Wide Regression Locks

This build is intentionally narrow in implementation scope while broad in regression coverage. The rule is that a local correction may not silently change an accepted ownership contract elsewhere in the app.

## Locked accepted behavior

- Catalog rows remain the vBRDC103 persistent-slot scroll engine. Existing row-motion presets and `UnityCatalogVisualSystem.swift` are unchanged.
- Catalog focused preview remains vBRDC107 media-identity owned: same-title Media Profile/control movement does not stop it; an actual Trailer launch or media ownership change does.
- VOD Featured Cast and Production & Ratings retain vBRDC106 visible-only 7-second rotation and playback-safe artwork publication. Hidden VOD chrome must not continue decorative rotation work.
- Live TV retains vBRDC105 fast post-playback focus return and strict 3-second dwell / 15-second one-shot muted grid preview contract.
- vBRDC104 persistent catalog shell remains mounted; this build does not alter Live TV ↔ catalog branch geometry.
- Dynamic Wallpaper, Sports, Favorites, Gracenote/provider data paths, playback/resume, Source Intelligence, debrid/Usenet providers and backend runtimes are not modified by this build.

## New invariant: channel logo exclusivity

A decoded provider/Gracenote channel logo is the sole logo presentation. Generic `channel.logo` text is not kept underneath a real image. Text is used only when no valid logo URL exists or the real image loader definitively fails.

## New invariant: Media Profile handoff math

The catalog-card ↔ Media Profile transition is one 0.20-second compositor transaction. Connector and panel start together. The full 860×858 panel is not animated through a changing mask. Close uses a matched 0.20-second panel/connector teardown and the popup is released only after that transition completes. The catalog focus handoff is prepared before close begins.

## Validation rule

`validation_vBRDC108/test_vBRDC108_contract.py` checks these new invariants plus the accepted vBRDC103–vBRDC107 ownership contracts. `AUDIT_vBRDC108_CHANGED_FILES.txt` records donor scope and hashes for critical unchanged systems.
