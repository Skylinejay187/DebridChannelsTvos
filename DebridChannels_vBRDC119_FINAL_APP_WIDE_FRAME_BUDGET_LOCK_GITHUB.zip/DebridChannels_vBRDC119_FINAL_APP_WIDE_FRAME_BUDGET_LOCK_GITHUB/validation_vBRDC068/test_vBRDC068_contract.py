from pathlib import Path
import plistlib, hashlib

root = Path(__file__).resolve().parents[1]
donor = Path('/mnt/data/_v67src/DebridChannels_vBRDC067_UNITY_CARD_CLEANUP_FRANCHISE_FIT_GITHUB')
app = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
visual = (root/'Sources/UnityCatalogVisualSystem.swift').read_text()
security = (root/'Sources/ReleaseCandidateSecurityManager.swift').read_text()
stable = (root/'Sources/StableFeatureGateManager.swift').read_text()
proj = (root/'project.yml').read_text()

# Release contract.
assert 'MARKETING_VERSION: 1.0.771' in proj
assert 'CURRENT_PROJECT_VERSION: 771' in proj
for rel in ['Sources/Info.plist', 'TopShelfExtension/Info.plist']:
    with open(root/rel, 'rb') as f:
        p = plistlib.load(f)
    assert p['CFBundleShortVersionString'] == '1.0.771'
    assert p['CFBundleVersion'] == '771'
    assert p['DebridChannelsReleaseID'] == 'vBRDC068'

# Franchise is landscape-first and logo/name/year are independently protected.
assert 'if let landscape = franchiseItem.landscapeURL' in visual
assert 'RemoteImageFit(url: landscape, mode: .fill' in visual
assert 'private var hasLandscape: Bool' in visual
assert 'RemoteImageFit(url: item.landscapeURL, mode: .fill' in visual
assert 'RemoteImageFit(url: item.posterURL, mode: .fit' in visual
assert 'private var hasLogo: Bool' in visual
assert 'RemoteImageFit(url: item.logoURL, mode: .fit' in visual
assert '.frame(width: 96, height: 30' in visual
assert 'Text(item.title)' in visual
assert 'Text(item.year)' in visual
assert '.frame(width: 150, height: 84)' in visual
assert '.frame(width: 150, height: 36)' in visual
assert '.frame(width: 808, height: 66, alignment: .bottomLeading)' in visual

# Catalog row motion is a user-selectable presentation setting, current behavior is default.
assert 'enum UnityCatalogRowMotionStyle' in visual
for name in [
    'Classic Spring', 'Smooth Glide', 'Cinematic Drift', 'Elastic', 'Quick Snap',
    'Soft Float', 'Depth Shift', 'Carousel Tilt', 'Instant'
]:
    assert name in visual
assert 'static let defaultName = "Classic Spring"' in visual
assert 'struct CatalogRowMotionPicker: View' in visual
assert '@AppStorage("catalogRowScrollingAnimationPreset")' in app
assert 'Catalog Row Motion:' in app
assert 'CatalogRowMotionPicker(selectedStyle:' in app
assert 'UnityCatalogRowMotionStyle.transition(for:' in app
assert 'lastHorizontalMoveDirection = -1' in app
assert 'lastHorizontalMoveDirection = 1' in app
assert 'UnityCatalogRowMotionStyle.animation(for:' in app
assert 'catalogRowScrollingAnimationPreset' in security
assert 'StableUIDefault(key: "catalogRowScrollingAnimationPreset", value: "Classic Spring")' in stable

# v67 cleanup and preview-label removal remain.
card = visual.split('struct UnityCatalogCardChrome: View {', 1)[1].split('struct UnityCatalogHeroAura: View {', 1)[0]
assert 'Capsule()' not in card
assert 'Circle()' not in card
assert 'PREVIEW 🍿' not in app
assert 'FocusedCardPreviewSurface(' in app

# v66 Search/franchise fixes and v65 XMLTV watchdog fix remain.
for token in [
    'store.recoverCatalogInteractivity(reason: "Search appeared")',
    'store.recoverCatalogInteractivity(reason: "Search returned from playback")',
    'franchiseItems: currentDetail.franchiseItems.isEmpty ? hydrated.franchiseItems : currentDetail.franchiseItems',
    'private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) async',
    'Task.detached(priority: .utility)',
    'LiveTVXMLTVBackgroundParser.parse(',
]:
    assert token in app

# Playback/KSP/provider/navigation/state stay byte-identical to v67.
locked = [
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift',
    'Sources/UniversalCodecSupport.swift',
    'Sources/TorBoxUsenetClient.swift',
    'Sources/CatalogStore.swift',
    'Sources/UnitySurfaceSystem.swift',
    'Sources/LocalIntroDetectionEngine.swift',
    'Sources/PlaybackStateManager.swift',
    'Sources/VODExclusivePlaybackGate.swift',
    'Scripts/fetch_patch_kspnuvio_vBRDC064.sh',
    'Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py',
    'BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py',
]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for rel in locked:
    assert sha(root/rel) == sha(donor/rel), rel

print('PASS vBRDC068 contract')
