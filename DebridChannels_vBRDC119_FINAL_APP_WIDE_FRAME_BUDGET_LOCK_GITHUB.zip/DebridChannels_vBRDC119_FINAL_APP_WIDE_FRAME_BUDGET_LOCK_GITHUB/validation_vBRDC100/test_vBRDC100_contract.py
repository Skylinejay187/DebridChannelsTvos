from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG = (ROOT/'Sources/RemoteImageFit.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release vBRDC100', app.get('DebridChannelsReleaseID')=='vBRDC100' and top.get('DebridChannelsReleaseID')=='vBRDC100')
ck('marketing 1.0.803', app.get('CFBundleShortVersionString')=='1.0.803' and top.get('CFBundleShortVersionString')=='1.0.803')
ck('build 803', app.get('CFBundleVersion')=='803' and top.get('CFBundleVersion')=='803')
ck('project marketing', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.803')
ck('project build', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='803')

cast=section(APP,'struct V1111FeaturedCastPosterCard: View','private struct V1106ProductionFact')
prod_panel=section(APP,'struct V1108ProductionRatingsPanel: View','private struct V1111ProductionArtworkHeader')
prod_header=section(APP,'private struct V1111ProductionArtworkHeader: View','struct V1104ReviewScoresCluster')

ck('compact cast retains previous decoded portrait', 'RemoteImageFit(url: imageURL, mode: .fill, showPlaceholder: false, preservePreviousOnURLChange: true)' in section(cast,'private var compactBannerSurface','private func fullPosterCast'))
ck('full cast retains previous decoded portrait', 'RemoteImageFit(url: imageURL, mode: .fill, showPlaceholder: false, preservePreviousOnURLChange: true)' in section(cast,'private func fullPosterCast','private var accessibilityText'))
ck('compact cast loader identity is title-stable', r'.id("vBRDC100-featured-cast-compact-\(item.id)")' in cast)
ck('full cast loader identity is title-stable', r'.id("vBRDC100-featured-cast-full-\(item.id)")' in cast)
ck('cast rotation cadence unchanged', 'Task.sleep(nanoseconds: 7_000_000_000)' in cast)
ck('cast state animation unchanged', 'withAnimation(.easeInOut(duration: 0.55))' in cast)
ck('cast initial poster reveal unchanged', 'Task.sleep(nanoseconds: 4_000_000_000)' in cast and 'duration: 0.70' in cast)

ck('production header retains previous decoded artwork', 'RemoteImageFit(url: currentArtworkURL, mode: .fit, showPlaceholder: false, preservePreviousOnURLChange: true)' in prod_header)
ck('production per-url loader destruction removed', r'v1112-production-artwork-\(currentArtworkURL)' not in prod_header)
ck('production artwork transition no longer inserts blank owner', '.transition(.opacity)' not in section(prod_header,'if let currentArtworkURL','LinearGradient('))
ck('production header identity resets only by title', r'.id("vBRDC100-production-header-\(item.id)")' in prod_panel)
ck('production rotation cadence unchanged', 'Timer.publish(every: 7.0' in prod_header)
ck('production rotation animation unchanged', 'withAnimation(.easeInOut(duration: 0.80))' in prod_header)
ck('production aspect-fit unchanged', 'mode: .fit' in prod_header and 'frame(height: bannerHeight)' in prod_header)

ck('existing retained-frame API unchanged and available', 'var preservePreviousOnURLChange: Bool = false' in IMG and 'preserveCurrentImage: preservePreviousOnURLChange' in IMG)
# vBRDC100 intentionally does not alter the systemic image loader itself.
ck('RemoteImageFit donor locked', sha('Sources/RemoteImageFit.swift')=='eeb490063ac2d92e6eb613510354620c4f4281cc508c14859f54c026c75ad9f2')

# Critical provider/playback/UNITY donor locks copied from packaged vBRDC099.
DONOR={
'Sources/NuvioPluginClient.swift':'94a3196403f26e8edad215029b26191e3941d7fb14a5fc5ac60fe29801a90a75',
'Sources/BackupStreamingClient.swift':'251dc138dbd14fc476c76bc6a765f85643df083a5c94196d54fc0148337346cd',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceSystem.swift':'00f507ce35a619732abe0811ff3fd3f7ffe58c431336b23b69011f43079beb76',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
}
for rel,h in DONOR.items(): ck('donor '+rel, sha(rel)==h)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('all Swift sources declared', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
