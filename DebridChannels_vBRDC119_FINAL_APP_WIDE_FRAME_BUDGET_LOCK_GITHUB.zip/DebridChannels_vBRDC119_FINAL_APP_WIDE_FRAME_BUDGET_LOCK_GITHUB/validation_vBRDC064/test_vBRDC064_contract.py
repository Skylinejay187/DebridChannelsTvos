from pathlib import Path
import plistlib
root=Path(__file__).resolve().parents[1]
app=plistlib.loads((root/'Sources/Info.plist').read_bytes())
ext=plistlib.loads((root/'TopShelfExtension/Info.plist').read_bytes())
proj=(root/'project.yml').read_text()
fetch=(root/'Scripts/fetch_patch_kspnuvio_vBRDC064.sh').read_text()
patch=(root/'Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py').read_text()
assert app['CFBundleShortVersionString']=='1.0.767'
assert app['CFBundleVersion']=='767'
assert app['DebridChannelsReleaseID']=='vBRDC064'
assert app['DebridChannelsCodeName']=='UNITY'
assert ext['CFBundleShortVersionString']=='1.0.767'
assert ext['CFBundleVersion']=='767'
assert ext['DebridChannelsReleaseID']=='vBRDC064'
assert 'MARKETING_VERSION: 1.0.767' in proj
assert 'CURRENT_PROJECT_VERSION: 767' in proj
assert 'preGenCommand: bash Scripts/fetch_patch_kspnuvio_vBRDC064.sh' in proj
assert 'patch_kspnuvio_idet_overflow_vBRDC064.py' in fetch
assert '69a73e5e22184c6db254eb2919f81768afb57a81' in fetch
assert 'property_new = "    // vBRDC064: signed, bounded counters' in patch
assert '1_000_000' in patch
surface=(root/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
assert 'isVODStylePlayback ? 300' in surface
assert 'options.isSecondOpen = true' in surface
assert 'reconnect_on_network_error' in surface
print('PASS: vBRDC064 release + KSP crash-fix contract')
