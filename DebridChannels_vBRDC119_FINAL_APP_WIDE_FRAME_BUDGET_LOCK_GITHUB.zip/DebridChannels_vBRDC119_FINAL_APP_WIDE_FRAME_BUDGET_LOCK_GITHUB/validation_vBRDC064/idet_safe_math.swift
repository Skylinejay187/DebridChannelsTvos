import Foundation
enum T: CaseIterable { case tff, bff, progressive, undetermined }
var counts: [T:Int] = [:]
for i in 0..<250_000 {
    let type = T.allCases[i % T.allCases.count]
    let current = counts[type] ?? 0
    counts[type] = min(current + 1, 1_000_000)
    let tff = counts[.tff] ?? 0
    let bff = counts[.bff] ?? 0
    let progressive = counts[.progressive] ?? 0
    let undetermined = counts[.undetermined] ?? 0
    _ = progressive - tff - bff > 100
    _ = bff - progressive > 100
    _ = tff - progressive > 100
    _ = undetermined - progressive - tff - bff > 100
}
let progressive = 0
let tff = 1
let bff = 0
precondition(progressive - tff - bff == -1)
print("PASS: signed idet arithmetic survives negative vote leads")
