    // vBRDC064: signed, bounded counters prevent Swift unsigned-underflow traps in idet voting.
    private var idetTypeMap = [VideoInterlacingType: Int]()
func fixture() {
                            // Upstream stores these counters as UInt and subtracts competing votes.
                            // A perfectly ordinary sequence such as tff=1/progressive=0 therefore executes
                            // 0 - 1 and traps in Swift. Keep the detector semantics, but use signed counters
                            // and a practical saturation ceiling so every comparison remains arithmetic-safe.
                            let current = idetTypeMap[type] ?? 0
                            idetTypeMap[type] = min(current + 1, 1_000_000)
                            let tff = idetTypeMap[.tff] ?? 0
                            let bff = idetTypeMap[.bff] ?? 0
                            let progressive = idetTypeMap[.progressive] ?? 0
                            let undetermined = idetTypeMap[.undetermined] ?? 0
                            if progressive - tff - bff > 100 {
                                videoInterlacingType = .progressive
                                autoDeInterlace = false
                            } else if bff - progressive > 100 {
                                videoInterlacingType = .bff
                                autoDeInterlace = false
                            } else if tff - progressive > 100 {
                                videoInterlacingType = .tff
                                autoDeInterlace = false
                            } else if undetermined - progressive - tff - bff > 100 {
                                videoInterlacingType = .undetermined
                                autoDeInterlace = false
                            }
}
