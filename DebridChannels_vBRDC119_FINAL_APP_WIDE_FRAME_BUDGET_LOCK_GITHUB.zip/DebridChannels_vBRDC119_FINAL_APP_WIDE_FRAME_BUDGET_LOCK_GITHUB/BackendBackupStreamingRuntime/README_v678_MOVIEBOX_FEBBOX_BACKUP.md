# Backend v678 — MovieBox / FebBox Backup Streaming

This runtime adds **backup-only** direct HTTP source infrastructure for Debrid Channels.
It is not a replacement for Stremio addons, Real-Debrid, TorBox, Torrentio, Comet, or
MediaFusion. The Apple app invokes it only when the normal Find Links provider scan has
finished with no usable source and the user has enabled Backup Streaming.

## Routes to mount

- `POST /api/backup-streaming/resolve` → pass decoded JSON to `resolve_backup_streams`.
- `POST /api/backup-streaming/febbox/verify` → pass decoded JSON to `verify_febbox_cookie`.

Both helpers return JSON-serializable dictionaries. For the existing FastAPI backend the runtime also exposes:

```python
from backup_streaming_runtime import register_fastapi_routes
register_fastapi_routes(app)
```

Keep the backend's existing authentication/rate-limit middleware around these routes and configure request-body logging to exclude them because the request may contain a user's transient FebBox cookie.

## Credential boundary

There is **no backend FebBox cookie configuration**. Every user enters their own FebBox
`ui` cookie in the Apple app. The app stores it in Keychain and includes only that token
in the single resolve/verify request that needs it. The runtime never persists, caches,
or logs the cookie, and its public responses never echo it.

`MOVIEBOX_PRIMARY_KEY` is different: it is infrastructure required for the MovieBox API
request signature and belongs on the backend, never in the Apple binary.

Optional environment values:

- `MOVIEBOX_PRIMARY_KEY` — Base64 MovieBox protocol key used only server-side.
- `FEBBOX_REGION` — default `USA7`.
- `BACKUP_STREAMING_TIMEOUT_SECONDS` — default `20`.
- `BACKUP_STREAMING_MAX_STREAMS` — default `12` per provider.

## Playback / MediaFlow

The resolver returns final direct media URLs. The Apple app puts them into the existing
Source Intelligence model. When global MediaFlow is enabled, the existing fail-closed
MediaFlow playback wrapper handles these URLs exactly like other VOD sources.

The resolver request itself is intentionally sent directly to the Debrid Channels HTTPS
backend because it can contain the user's FebBox credential; it is not forwarded through
a separately configured MediaFlow instance.

## Attribution

The provider protocol research and portions of the matching/resolution approach were
adapted from `tapframe/NuvioStreamsAddon`, MIT licensed. Preserve `NUVIO_MIT_NOTICE.txt`
with deployments that incorporate this runtime.
