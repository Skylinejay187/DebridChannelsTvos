"""Debrid Channels v688 additive FebBox runtime.

The custom MovieBox implementation was removed in v688. FebBox remains an independent
optional provider. The user-owned ``ui`` cookie is received only for the individual
verification/resolver request and MUST NOT be persisted, cached, logged, or exposed in
diagnostics.

Expected backend routes:
    POST /api/backup-streaming/febbox/verify
    POST /api/backup-streaming/febbox/resolve
"""

from __future__ import annotations

import html as html_module
import json
import os
import re
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional
from urllib.parse import urlencode
from urllib.request import Request, urlopen

SCHEMA_VERSION = 1
SHOWBOX_BASE = "https://www.showbox.media"
FEBBOX_BASE = "https://www.febbox.com"
DEFAULT_USER_AGENT = "Mozilla/5.0 (AppleTV; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15"


class BackupStreamingError(RuntimeError):
    pass


@dataclass(frozen=True)
class BackupStreamingRuntimeConfig:
    febbox_region: str = "USA7"
    timeout_seconds: int = 20
    maximum_streams_per_provider: int = 50

    @classmethod
    def from_environment(cls) -> "BackupStreamingRuntimeConfig":
        return cls(
            febbox_region=(os.environ.get("FEBBOX_REGION") or "USA7").strip() or "USA7",
            timeout_seconds=max(5, int(os.environ.get("BACKUP_STREAMING_TIMEOUT_SECONDS") or 20)),
            maximum_streams_per_provider=max(1, min(50, int(os.environ.get("BACKUP_STREAMING_MAX_STREAMS") or 50))),
        )


@dataclass(frozen=True)
class HTTPResult:
    status: int
    headers: Mapping[str, str]
    body: bytes

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.text)


HTTPFetcher = Callable[[str, str, Mapping[str, str], Optional[bytes], int], HTTPResult]


def _default_fetcher(method: str, url: str, headers: Mapping[str, str], body: Optional[bytes], timeout: int) -> HTTPResult:
    request = Request(url=url, data=body, method=method.upper(), headers=dict(headers))
    with urlopen(request, timeout=timeout) as response:  # nosec - URL targets are fixed provider hosts
        normalized_headers = {str(k).lower(): str(v) for k, v in response.headers.items()}
        set_cookies = response.headers.get_all("Set-Cookie") or []
        if set_cookies:
            normalized_headers["set-cookie"] = ", ".join(str(v) for v in set_cookies)
        return HTTPResult(
            status=int(getattr(response, "status", 200)),
            headers=normalized_headers,
            body=response.read(4 * 1024 * 1024),
        )


def _clean_cookie(raw: Any) -> str:
    value = str(raw or "").strip()
    if value.lower().startswith("ui="):
        value = value[3:]
    value = value.split(";", 1)[0].strip()
    # Reject control characters/newlines so the transient token cannot become a header injection vector.
    if not value or any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in value):
        return ""
    return value[:8192]


def _cookie_header(cookie: str, region: str) -> str:
    clean = _clean_cookie(cookie)
    return f"ui={clean}; oss_group={region}" if clean else f"oss_group={region}"


def _safe_text(value: Any, limit: int = 512) -> str:
    return str(value or "").strip()[:limit]


def _normal_media_type(value: Any) -> str:
    lower = _safe_text(value).lower()
    return "tv" if lower in {"tv", "series", "show", "episode"} or "series" in lower or "show" in lower else "movie"


def _normalize_title(value: Any) -> str:
    text = html_module.unescape(_safe_text(value, 400)).lower()
    text = re.sub(r"\(\d{4}\)", " ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"^(?:the|a|an)\s+", "", text)
    return text


def _title_score(target: str, candidate: str, target_year: str = "", candidate_year: str = "", media_type: str = "", href: str = "") -> float:
    a = _normalize_title(target)
    b = _normalize_title(candidate)
    if not a or not b:
        return -100.0
    aw, bw = set(a.split()), set(b.split())
    overlap = len(aw & bw) / max(len(aw | bw), 1)
    exact = 1.0 if a == b else 0.0
    containment = min(len(a), len(b)) / max(len(a), len(b)) if a in b or b in a else 0.0
    score = exact * 100.0 + overlap * 50.0 + containment * 24.0
    if target_year and candidate_year:
        score += 18.0 if target_year == candidate_year else -12.0
    if media_type and href:
        expected = "/tv/" if media_type == "tv" else "/movie/"
        score += 14.0 if expected in href else -18.0
    return score


def _extract_year(text: str) -> str:
    match = re.search(r"\b(19\d{2}|20\d{2}|21\d{2})\b", text or "")
    return match.group(1) if match else ""


def _quality_from_text(*values: Any) -> str:
    text = " ".join(_safe_text(v) for v in values).lower()
    if any(token in text for token in ("2160", "4k", "uhd")):
        return "2160p"
    if "1440" in text:
        return "1440p"
    if "1080" in text:
        return "1080p"
    if "720" in text or re.search(r"\bhd\b", text):
        return "720p"
    if "576" in text:
        return "576p"
    if "480" in text or re.search(r"\bsd\b", text):
        return "480p"
    if "360" in text:
        return "360p"
    return "Auto"


def _size_from_text(*values: Any) -> str:
    text = " ".join(_safe_text(v) for v in values)
    matches = re.findall(r"(?i)(\d+(?:[.,]\d+)?)\s*(TB|TiB|GB|GiB|MB|MiB|KB|KiB)", text)
    if not matches:
        return "Unknown size"
    number, unit = matches[-1]
    number = number.replace(",", ".")
    normalized_unit = unit.upper().replace("TIB", "TB").replace("GIB", "GB").replace("MIB", "MB").replace("KIB", "KB")
    return f"{number} {normalized_unit}"


def _size_from_metadata(*values: Any) -> str:
    """Normalize provider byte counts and human-readable size labels without guessing."""
    for value in values:
        if value is None:
            continue
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            bytes_value = float(value)
        else:
            text = _safe_text(value, 256)
            parsed = _size_from_text(text)
            if parsed != "Unknown size":
                return parsed
            try:
                bytes_value = float(text) if text and re.fullmatch(r"\d+(?:\.\d+)?", text) else 0.0
            except Exception:
                bytes_value = 0.0
        if bytes_value <= 0:
            continue
        if bytes_value >= 1099511627776:
            return f"{bytes_value / 1099511627776:.2f} TB"
        if bytes_value >= 1073741824:
            return f"{bytes_value / 1073741824:.2f} GB"
        if bytes_value >= 1048576:
            return f"{bytes_value / 1048576:.0f} MB"
        if bytes_value >= 1024:
            return f"{bytes_value / 1024:.0f} KB"
        return f"{bytes_value:.0f} B"
    return "Unknown size"


def _febbox_safe_playback_headers(share_url: str) -> Dict[str, str]:
    """Headers safe to echo to the client. The private ui cookie is deliberately excluded."""
    return {
        "User-Agent": DEFAULT_USER_AGENT,
        "Accept": "*/*",
        "Referer": share_url,
        "Origin": FEBBOX_BASE,
    }


def _codecs_from_text(*values: Any) -> List[str]:
    text = " ".join(_safe_text(v) for v in values).lower()
    pairs = [
        ("Dolby Vision", ("dolby vision", "dovi", ".dv.")),
        ("HDR10+", ("hdr10+", "hdr10plus")),
        ("HDR", (" hdr", ".hdr")),
        ("AV1", ("av1",)),
        ("H.265", ("h265", "x265", "hevc")),
        ("H.264", ("h264", "x264", "avc")),
        ("Atmos", ("atmos",)),
        ("TrueHD", ("truehd", "true-hd")),
        ("DTS-HD", ("dts-hd", "dtshd")),
        ("DTS", (" dts", ".dts")),
        ("EAC3", ("eac3", "e-ac-3", "dd+", "ddp")),
        ("AC3", ("ac3",)),
        ("AAC", ("aac",)),
        ("Opus", ("opus",)),
    ]
    result: List[str] = []
    for label, tokens in pairs:
        if any(token in text for token in tokens) and label not in result:
            result.append(label)
    return result


class _ShowBoxSearchParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.results: List[Dict[str, str]] = []
        self._poster_depth = 0

    def handle_starttag(self, tag: str, attrs: Sequence[Tuple[str, Optional[str]]]) -> None:
        values = {k: (v or "") for k, v in attrs}
        classes = set(values.get("class", "").split())
        if tag == "div" and "film-poster" in classes:
            self._poster_depth += 1
        elif self._poster_depth and tag == "div":
            self._poster_depth += 1
        if self._poster_depth and tag == "a":
            href = values.get("href", "")
            title = values.get("title", "")
            if href and title and ("/movie/" in href or "/tv/" in href):
                self.results.append({"href": href, "title": title})

    def handle_endtag(self, tag: str) -> None:
        if tag == "div" and self._poster_depth:
            self._poster_depth -= 1


class _FebBoxFilesParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.records: List[Dict[str, Any]] = []
        self._stack: List[Optional[Dict[str, Any]]] = []
        self._capture_name = False

    def handle_starttag(self, tag: str, attrs: Sequence[Tuple[str, Optional[str]]]) -> None:
        values = {k: (v or "") for k, v in attrs}
        if tag == "div":
            classes = set(values.get("class", "").split())
            if "file" in classes and values.get("data-id", "").isdigit():
                raw_size = next((values.get(key, "") for key in ("data-size", "data-filesize", "data-file-size", "data-bytes") if values.get(key, "")), "")
                record = {
                    "id": values["data-id"],
                    "isFolder": "open_dir" in classes,
                    "name": "",
                    "size": _size_from_metadata(raw_size),
                    "details": "",
                }
                self.records.append(record)
                self._stack.append(record)
            else:
                self._stack.append(None)
        elif tag == "p" and self._active_record() is not None:
            classes = set(values.get("class", "").split())
            if "file_name" in classes:
                self._capture_name = True

    def handle_endtag(self, tag: str) -> None:
        if tag == "p":
            self._capture_name = False
        if tag == "div" and self._stack:
            self._stack.pop()

    def handle_data(self, data: str) -> None:
        record = self._active_record()
        if record is None:
            return
        clean = " ".join(str(data or "").split())
        if clean:
            details = (record.get("details", "") + " " + clean).strip()
            record["details"] = details[:2000]
        if self._capture_name:
            record["name"] = (record.get("name", "") + data).strip()[:500]

    def _active_record(self) -> Optional[Dict[str, Any]]:
        for value in reversed(self._stack):
            if value is not None:
                return value
        return None


def _parse_showbox_results(html: str) -> List[Dict[str, str]]:
    parser = _ShowBoxSearchParser()
    parser.feed(html)
    if parser.results:
        return parser.results
    # Fallback for minor markup changes.
    results: List[Dict[str, str]] = []
    for match in re.finditer(r"<a\b[^>]*href=['\"]([^'\"]*(?:/movie/|/tv/)[^'\"]*)['\"][^>]*title=['\"]([^'\"]+)['\"]", html, re.I):
        results.append({"href": html_module.unescape(match.group(1)), "title": html_module.unescape(match.group(2))})
    return results


def _parse_febbox_records(html: str) -> List[Dict[str, Any]]:
    parser = _FebBoxFilesParser()
    parser.feed(html)
    return parser.records


def _extract_share_key(url: str, html: str = "") -> str:
    match = re.search(r"/share/([A-Za-z0-9-]+)", url)
    if match:
        return match.group(1)
    match = re.search(r'(?:var\s+share_key\s*=|share_key\s*:|shareid=)["\']?([A-Za-z0-9-]+)', html)
    return match.group(1) if match else ""


def _extract_direct_sources(player_html: str) -> List[Mapping[str, Any]]:
    match = re.search(r"var\s+sources\s*=\s*(\[.*?\])\s*;", player_html, re.I | re.S)
    if not match:
        stripped = player_html.strip()
        if stripped.startswith("http"):
            return [{"label": "Direct", "file": stripped}]
        return []
    try:
        decoded = json.loads(match.group(1))
    except Exception:
        return []
    return decoded if isinstance(decoded, list) else []


def _episode_number(name: str) -> Optional[int]:
    lower = name.lower()
    patterns = [
        r"s\d{1,2}[ ._-]*e(\d{1,3})\b",
        r"episode[ ._-]*(\d{1,3})\b",
        r"\be[ ._-]?(\d{1,3})\b",
        r"\bep[ ._-]?(\d{1,3})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, lower, re.I)
        if match:
            return int(match.group(1))
    return None


def _season_number(name: str) -> Optional[int]:
    lower = name.lower()
    for pattern in (r"season[ ._-]*(\d{1,2})\b", r"\bs(\d{1,2})\b"):
        match = re.search(pattern, lower, re.I)
        if match:
            return int(match.group(1))
    numbers = re.findall(r"\b\d{1,2}\b", lower)
    return int(numbers[0]) if len(numbers) == 1 else None


def _http_json(fetcher: HTTPFetcher, method: str, url: str, headers: Mapping[str, str], body: Optional[bytes], timeout: int) -> Any:
    result = fetcher(method, url, headers, body, timeout)
    if result.status < 200 or result.status >= 300:
        raise BackupStreamingError(f"provider returned HTTP {result.status}")
    return result.json()


def verify_febbox_cookie(payload: Mapping[str, Any], config: Optional[BackupStreamingRuntimeConfig] = None, fetcher: HTTPFetcher = _default_fetcher) -> Dict[str, Any]:
    config = config or BackupStreamingRuntimeConfig.from_environment()
    cookie = _clean_cookie(payload.get("febboxCookie"))
    if not cookie:
        return {"schemaVersion": SCHEMA_VERSION, "valid": False, "status": "FebBox cookie is missing."}
    try:
        response = _http_json(
            fetcher,
            "GET",
            FEBBOX_BASE + "/console/user_cards",
            {
                "Cookie": f"ui={cookie}",
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "User-Agent": DEFAULT_USER_AGENT,
            },
            None,
            config.timeout_seconds,
        )
        flow = (((response or {}).get("data") or {}).get("flow") or {}) if isinstance(response, dict) else {}
        limit_mb = float(flow.get("traffic_limit_mb") or 0)
        used_mb = float(flow.get("traffic_usage_mb") or 0)
        if limit_mb <= 0 and not flow:
            return {"schemaVersion": SCHEMA_VERSION, "valid": False, "status": "FebBox did not accept this cookie."}
        remaining = max(0.0, limit_mb - used_mb)
        return {
            "schemaVersion": SCHEMA_VERSION,
            "valid": True,
            "status": "FebBox cookie verified",
            "remainingMB": remaining,
            "trafficLimitMB": limit_mb,
            "trafficUsedMB": used_mb,
        }
    except Exception:
        # Never include exception content: upstream messages can contain request headers.
        return {"schemaVersion": SCHEMA_VERSION, "valid": False, "status": "FebBox verification failed."}


def _showbox_best_detail_url(fetcher: HTTPFetcher, title: str, year: str, media_type: str, timeout: int) -> Optional[str]:
    search_url = SHOWBOX_BASE + "/search?" + urlencode({"keyword": title})
    result = fetcher("GET", search_url, {"User-Agent": DEFAULT_USER_AGENT, "Accept": "text/html"}, None, timeout)
    if result.status < 200 or result.status >= 300:
        return None
    candidates = _parse_showbox_results(result.text)
    if not candidates:
        return None
    best = max(candidates, key=lambda item: _title_score(title, item.get("title", ""), year, _extract_year(item.get("href", "")), media_type, item.get("href", "")))
    if _title_score(title, best.get("title", ""), year, _extract_year(best.get("href", "")), media_type, best.get("href", "")) < 20:
        return None
    href = best.get("href", "")
    return href if href.startswith("http") else SHOWBOX_BASE + (href if href.startswith("/") else "/" + href)


def _showbox_to_febbox_share(fetcher: HTTPFetcher, showbox_url: str, media_type: str, timeout: int) -> Optional[str]:
    detail = fetcher("GET", showbox_url, {"User-Agent": DEFAULT_USER_AGENT, "Accept": "text/html"}, None, timeout)
    if detail.status < 200 or detail.status >= 300:
        return None
    html = detail.text
    direct = re.search(r"https?://(?:www\.)?febbox\.com/share/[A-Za-z0-9-]+", html, re.I)
    if direct:
        return direct.group(0)

    content_id = ""
    content_type = "2" if media_type == "tv" else "1"
    detail_match = re.search(r"/(movie|tv)/detail/(\d+)", showbox_url + "\n" + html, re.I)
    if detail_match:
        content_id = detail_match.group(2)
        content_type = "1" if detail_match.group(1).lower() == "movie" else "2"
    if not content_id:
        return None
    share_url = SHOWBOX_BASE + "/index/share_link?" + urlencode({"id": content_id, "type": content_type})
    share = fetcher(
        "GET",
        share_url,
        {"User-Agent": DEFAULT_USER_AGENT, "Accept": "application/json", "X-Requested-With": "XMLHttpRequest", "Referer": showbox_url},
        None,
        timeout,
    )
    if share.status < 200 or share.status >= 300:
        return None
    try:
        payload = share.json()
    except Exception:
        return None
    if isinstance(payload, dict) and payload.get("code") == 1:
        link = ((payload.get("data") or {}).get("link") or "") if isinstance(payload.get("data"), dict) else ""
        if isinstance(link, str) and "febbox.com/share/" in link:
            return link
    return None


def _febbox_player_sources(fetcher: HTTPFetcher, fid: str, share_key: str, cookie: str, region: str, timeout: int, filename: str, file_size: str = "Unknown size") -> List[Dict[str, Any]]:
    body = urlencode({"fid": fid, "share_key": share_key}).encode("utf-8")
    result = fetcher(
        "POST",
        FEBBOX_BASE + "/file/player",
        {
            "Cookie": _cookie_header(cookie, region),
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": DEFAULT_USER_AGENT,
            "Referer": FEBBOX_BASE + "/share/" + share_key,
        },
        body,
        timeout,
    )
    if result.status < 200 or result.status >= 300:
        return []
    streams: List[Dict[str, Any]] = []
    for source in _extract_direct_sources(result.text):
        raw_url = _safe_text(source.get("file") or source.get("url"), 8192)
        if not raw_url.startswith(("http://", "https://")):
            continue
        label = _safe_text(source.get("label") or source.get("name") or "Auto", 80)
        label_quality = _quality_from_text(label)
        source_size = _size_from_metadata(
            source.get("videoSize"), source.get("video_size"), source.get("filesize"),
            source.get("file_size"), source.get("size"), source.get("length"), source.get("bytes"),
            file_size, filename, label,
        )
        referer = FEBBOX_BASE + "/share/" + share_key
        streams.append({
            "provider": "FebBox",
            "title": filename or "FebBox stream",
            "url": raw_url,
            "quality": label_quality if label_quality != "Auto" else _quality_from_text(filename),
            "size": source_size,
            "codecs": _codecs_from_text(filename, label),
            "language": "",
            "headers": _febbox_safe_playback_headers(referer),
            "referer": referer,
            "region": region,
        })
    return streams


def _resolve_febbox(payload: Mapping[str, Any], config: BackupStreamingRuntimeConfig, fetcher: HTTPFetcher) -> List[Dict[str, Any]]:
    cookie = _clean_cookie(payload.get("febboxCookie"))
    if not cookie:
        return []
    title = _safe_text(payload.get("title"), 300)
    year = _safe_text(payload.get("year"), 8)
    media_type = _normal_media_type(payload.get("mediaType"))
    season = int(payload.get("season")) if str(payload.get("season") or "").isdigit() else None
    episode = int(payload.get("episode")) if str(payload.get("episode") or "").isdigit() else None
    if not title:
        return []

    showbox_url = _showbox_best_detail_url(fetcher, title, year, media_type, config.timeout_seconds)
    if not showbox_url:
        return []
    share_url = _showbox_to_febbox_share(fetcher, showbox_url, media_type, config.timeout_seconds)
    if not share_url:
        return []
    share_key = _extract_share_key(share_url)
    if not share_key:
        return []

    share = fetcher(
        "GET",
        share_url,
        {"Cookie": _cookie_header(cookie, config.febbox_region), "User-Agent": DEFAULT_USER_AGENT, "Accept": "text/html"},
        None,
        config.timeout_seconds,
    )
    if share.status < 200 or share.status >= 300:
        return []
    direct = _extract_direct_sources(share.text)
    if direct:
        result: List[Dict[str, Any]] = []
        for source in direct:
            url = _safe_text(source.get("file") or source.get("url"), 8192)
            if url.startswith(("http://", "https://")):
                label = _safe_text(source.get("label") or "Auto", 80)
                result.append({
                    "provider": "FebBox",
                    "title": title,
                    "url": url,
                    "quality": _quality_from_text(label),
                    "size": _size_from_metadata(source.get("videoSize"), source.get("filesize"), source.get("file_size"), source.get("size"), source.get("length"), source.get("bytes"), label),
                    "codecs": _codecs_from_text(label),
                    "language": "",
                    "headers": _febbox_safe_playback_headers(share_url),
                    "referer": share_url,
                    "region": config.febbox_region,
                })
        return result[: config.maximum_streams_per_provider]

    records = _parse_febbox_records(share.text)
    if media_type == "tv":
        if season is None or episode is None:
            return []
        folders = [record for record in records if record.get("isFolder")]
        selected_folder: Optional[Dict[str, Any]] = None
        exact = [record for record in folders if _season_number(_safe_text(record.get("name"))) == season]
        if exact:
            selected_folder = exact[0]
        elif len(folders) == 1:
            selected_folder = folders[0]
        if selected_folder is None:
            return []
        folder_url = FEBBOX_BASE + "/file/file_share_list?" + urlencode({"share_key": share_key, "parent_id": selected_folder["id"], "is_html": "1", "pwd": ""})
        folder_result = fetcher(
            "GET",
            folder_url,
            {
                "Cookie": _cookie_header(cookie, config.febbox_region),
                "Referer": share_url,
                "X-Requested-With": "XMLHttpRequest",
                "User-Agent": DEFAULT_USER_AGENT,
            },
            None,
            config.timeout_seconds,
        )
        if folder_result.status < 200 or folder_result.status >= 300:
            return []
        folder_html = folder_result.text
        try:
            maybe_json = folder_result.json()
            if isinstance(maybe_json, dict) and isinstance(maybe_json.get("html"), str):
                folder_html = maybe_json["html"]
        except Exception:
            pass
        episode_files = [record for record in _parse_febbox_records(folder_html) if not record.get("isFolder")]
        exact_eps = [record for record in episode_files if _episode_number(_safe_text(record.get("name"))) == episode]
        if not exact_eps and 0 < episode <= len(episode_files):
            # Last-resort ordinal fallback only within the already selected season folder.
            exact_eps = [episode_files[episode - 1]]
        files = exact_eps[:3]
    else:
        files = [record for record in records if not record.get("isFolder")][:6]

    resolved: List[Dict[str, Any]] = []
    for record in files:
        filename = _safe_text(record.get("name"), 500) or title
        record_size = _size_from_metadata(record.get("size"), record.get("details"), filename)
        resolved.extend(_febbox_player_sources(fetcher, str(record["id"]), share_key, cookie, config.febbox_region, config.timeout_seconds, filename, record_size))
        if len(resolved) >= config.maximum_streams_per_provider:
            break
    return resolved[: config.maximum_streams_per_provider]




def _deduplicate_streams(streams: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    result: List[Dict[str, Any]] = []
    for source in streams:
        url = _safe_text(source.get("url"), 8192)
        if not url or url in seen:
            continue
        seen.add(url)
        result.append(dict(source))
    quality_rank = {"2160p": 0, "1440p": 1, "1080p": 2, "720p": 3, "576p": 4, "480p": 5, "360p": 6, "Auto": 9}
    result.sort(key=lambda value: (quality_rank.get(_safe_text(value.get("quality")), 8), _safe_text(value.get("provider")), _safe_text(value.get("title"))))
    return result


def resolve_febbox_streams(payload: Mapping[str, Any], config: Optional[BackupStreamingRuntimeConfig] = None, fetcher: HTTPFetcher = _default_fetcher) -> Dict[str, Any]:
    """Resolve only the user's personal FebBox source.

    The ui cookie is request-scoped and is never persisted, logged, cached, or echoed.
    """
    config = config or BackupStreamingRuntimeConfig.from_environment()
    cookie = _clean_cookie(payload.get("febboxCookie"))
    if not cookie:
        return {
            "schemaVersion": SCHEMA_VERSION,
            "status": "no_links",
            "message": "FebBox requires a verified personal ui cookie.",
            "streams": [],
            "providers": {"febbox": 0},
        }
    try:
        febbox = _resolve_febbox(payload, config, fetcher)
    except Exception:
        febbox = []
    streams = _deduplicate_streams(febbox)
    return {
        "schemaVersion": SCHEMA_VERSION,
        "status": "ready" if streams else "no_links",
        "message": "FebBox streams ready." if streams else "No FebBox streams were available for this title.",
        "streams": streams,
        "providers": {"febbox": len(streams)},
        "febbox": {"userCredentialRequired": True, "requestScopedCredential": True},
    }
