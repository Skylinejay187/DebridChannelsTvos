# vBRDC115 — MediaFlow LAN Live TV Route

Marketing version **1.0.818**, Apple build **818**. Built only from packaged vBRDC114.

## Why vBRDC114 still failed away from home
vBRDC114 correctly noticed that Live TV bootstrap had to pass through MediaFlow, but it selected MediaFlow's `/proxy/forward` endpoint. Current MediaFlow implements `/proxy/forward` with SSRF protection that rejects loopback and RFC-1918 private IP targets. A home Channels DVR/HDHomeRun source commonly lives at `192.168.x.x`, `10.x.x.x`, or `172.16-31.x.x`, so the proxy could return HTTP 403 before Debrid Channels ever received channels or guide data.

This also created a compatibility risk for MediaFlow servers older than the release that introduced `/proxy/forward`.

## Corrected route
When MediaFlow Proxy is enabled:
- Channels DVR JSON/API GETs -> `/proxy/stream`
- HDHomeRun discovery/lineup GETs -> `/proxy/stream`
- M3U playlist GETs -> `/proxy/stream`
- Xtream `player_api.php` / playlist GETs -> `/proxy/stream`
- XMLTV / Gracenote -> `/proxy/epg` first, then `/proxy/stream` compatibility fallback
- Final Live TV playback / grid preview -> existing `.liveTV` HLS or generic stream wrapper (unchanged)

When MediaFlow Proxy is disabled, the original direct provider behavior is unchanged.

MediaFlow remains fail-closed while enabled: a failed MediaFlow route does not silently leak the request through the away-from-home Apple TV's direct network.

## Regression preservation
No catalog scrolling/open-close, VOD overlay, Bluetooth media command, focused preview, Dynamic Wallpaper, Sports, provider credentials, playback/resume, TorBox, Usenet, or source-intelligence logic was intentionally changed.

## Validation
- vBRDC115 targeted route/regression contract: 36/36 PASS
- Production Swift syntax parse: 65/65 PASS
- Backend regression: 36 tests PASS
- Version/project metadata: 8/8 PASS
- Existing donor file scope: exactly 5 changed files
