# vBRDC119 Final App-Wide Performance Audit

## Scope and standard

The audit used vBRDC118 as the sole donor and treated 16.67 ms as the 60 Hz frame budget. Optimizations were accepted only when the source could be made more efficient without intentionally reducing visual quality, artwork resolution, animation count, animation design, feature coverage, or provider/playback behavior.

Impact rankings below are architectural estimates from static/runtime-path analysis, not Instruments measurements on physical Apple TV hardware. Device recordings and Instruments remain authoritative for the final frame-time profile.

## Ranked findings that were still present after vBRDC118

### P0 / Cross-cutting — per-caller frame-gate polling

**Finding:** The process-wide UNITY frame policy was logically shared, but each caller waiting for permission ran its own `Task.sleep` polling loop. A burst of focus work could create many independent wakeups from artwork, catalog, Live TV, persistence, and recovery paths.

**Why it matters:** The wakeup itself is invisible, but a large number of short-lived MainActor/task-scheduler wakeups competes with focus/layout/compositor work exactly when the user is holding the D-pad.

**Correction:** `UnityFrameRevisionWaiterHub` provides a thread-safe shared revision signal using continuations. Waiting tasks wake when ownership actually changes rather than on a fixed polling cadence.

### P0 / Correctness + performance — destructive courtesy timeouts for authoritative results

**Finding:** Some completed network/decode/provider results still used a bounded courtesy wait and could return without publishing if navigation stayed active too long.

**Why it matters:** Besides losing data, dropped authoritative results cause later retries/re-fetches/re-parses, which add avoidable work and can create inconsistent UI readiness.

**Correction:** Added `waitUntilPermittedDurably`. Already-fetched authoritative results wait event-driven until publication is permitted, unless their owning task is truly cancelled/superseded. Speculative work keeps bounded cancellation semantics.

### P0 / SwiftUI invalidation — identical catalog and Live TV publication

**Finding:** `@Published` sends before assignment, so assigning an identical Array/Dictionary can still invalidate observers. Catalog projected rows and Live TV snapshots had paths that republished equivalent values.

**Why it matters:** Large Home/Live TV view trees may reevaluate even though nothing visible changed.

**Correction:** Equality guards were added before publication. Guide batches merge into one next snapshot and publish once.

### P1 / Live TV identity churn — random programme IDs

**Finding:** Equivalent programme data could acquire fresh identities when reparsed/refreshed.

**Why it matters:** SwiftUI can treat unchanged guide cells as removed/inserted content, increasing diffing/layout/artwork churn.

**Correction:** `LiveProgram` uses stable deterministic identity hashing based on programme/schedule identity.

### P1 / Live TV focus path — repeated linear channel scans

**Finding:** Frequently requested channel/focus position data was derived by scanning channel arrays.

**Why it matters:** Individually inexpensive operations become meaningful when repeated by focus, guide, preview, and metadata code during rapid navigation.

**Correction:** Channel-by-ID and position indexes are rebuilt with channel publication and used for O(1) lookups.

### P1 / XMLTV — repeated regex/date construction and alias duplication

**Finding:** XMLTV processing repeatedly constructed parsing helpers and could duplicate programme arrays under multiple aliases for lookup convenience.

**Why it matters:** Large EPG documents amplify regex compilation, date-format parsing, allocation, dictionary copying, and memory pressure.

**Correction:** A per-parse context owns compiled patterns/formatters. Programmes are stored once under real XMLTV channel IDs; a reverse alias map resolves UI identities without duplicating programme collections. XMLTV processing is performed as utility work away from the MainActor.

### P1 / M3U and Xtream parsing on UI-critical isolation

**Finding:** M3U attribute parsing and Xtream EPG/date conversion could perform substantial provider transformation while the Live TV observable model was MainActor-isolated.

**Why it matters:** Provider parsing can coincide with focus movement and delay visible frame work.

**Correction:** M3U emits Sendable drafts from a detached utility parse. Xtream short EPG conversion is nonisolated/detached and publishes only final results on the UI model.

### P1 / Live TV persistence — large JSON encode/write on UI path

**Finding:** Large channel/guide snapshots could create JSON and perform atomic file writes synchronously with model work.

**Why it matters:** Tens of thousands of EPG rows can generate significant CPU and filesystem latency.

**Correction:** Encoding/writes use a utility serial queue and coalesce pending snapshots so persistence cannot build an obsolete write backlog.

### P1 / Dynamic Wallpaper — paused polling

**Finding:** Streaming animated wallpaper periodically woke while paused to check whether it could continue.

**Why it matters:** Background wakeups do not change pixels while paused but still consume scheduler/CPU time during foreground navigation/playback transitions.

**Correction:** `DynamicWallpaperPauseGate` is event-driven. The decoder waits without advancing and resumes from the exact retained frame when signaled.

### P1 / Episode metadata — formatter and regex construction

**Finding:** Episode-card metadata and the episode-alert scanner repeatedly constructed multiple DateFormatter/ISO formatter/regex objects across large episode collections.

**Why it matters:** DateFormatter setup is relatively expensive and the scanner may evaluate hundreds or thousands of rows.

**Correction:** Reusable thread-safe parser pools preserve all existing input formats, local-day semantics, and display formatting.

### P2 / VOD observable churn — repeated equivalent playback state

**Finding:** Duration and play/pause callbacks could write values that were effectively unchanged.

**Why it matters:** Playback clocks are high-frequency producers. A redundant write can invalidate overlay state unrelated to the visible timeline change.

**Correction:** Equality/threshold guards prevent equivalent state publication while preserving the same user-facing timing data.

## Investigation that did *not* justify another change

### Focused catalog card root geometry

The root still observes `FocusedCatalogCardFramePreferenceKey`, which initially looked like a potential root-wide invalidation source. Inspection confirmed vBRDC088 already moved the measurement outside the animated card to an invisible fixed resting slot. It therefore does not intentionally track the card's bounce/pulse transform every frame. The frame is also equality guarded at RootView.

Because Media Profile's connector depends on the accurate source-card frame and the previous regression history is sensitive, vBRDC119 leaves this working fixed-slot design unchanged.

### Persistent catalog renderer

The fixed-slot rail and existing row-motion system already avoid recreating a traditional scroll collection on every focus move. It remains unchanged.

### PlaybackKit timing foundation

The existing playback foundation already contains hidden-playback/timing coalescing behavior. Replacing it in this performance pass would increase regression risk without a concrete bottleneck proven by the audit, so it remains byte-identical.

### Live TV artwork flattening

Existing retained/flattened artwork paths already avoid several historical image-flash/decode regressions. They were preserved.

## Requested vBRDC119 feature — manual VOD Cast browsing

This is the only intentional interaction addition in the release. It reuses the existing Cast focus owner and rotation task:

- focused Cast + LEFT/RIGHT changes the current image-backed member;
- selection wraps;
- the existing 7-second visible-only rotation clock restarts from the chosen member;
- no second rotation timer is created;
- in-portrait arrows appear briefly as a discoverability hint, then fade;
- Select continues to open Cast Explorer for the displayed member.

## Expected performance character

vBRDC119 should reduce invisible CPU/task/MainActor work during sustained navigation and reduce SwiftUI invalidation when provider/guide values have not actually changed. It should also reduce Live TV bootstrap/EPG memory and parsing pressure and long-session persistence churn.

These are source-level performance improvements; the release does not claim a measured 60 FPS result without physical Apple TV Instruments/device testing.
