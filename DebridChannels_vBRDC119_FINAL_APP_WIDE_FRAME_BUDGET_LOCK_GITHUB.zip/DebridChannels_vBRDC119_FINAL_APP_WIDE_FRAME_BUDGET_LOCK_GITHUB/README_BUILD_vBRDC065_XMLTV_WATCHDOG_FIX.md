# Debrid Channels vBRDC065 — Live TV XMLTV Watchdog Fix

- Release ID: `vBRDC065`
- Marketing version: `1.0.768`
- Apple build: `768`
- Code Name: `UNITY`
- Built only from packaged `vBRDC064`
- Backend: `v693` unchanged
- Pinned KSPNUVIO commit and vBRDC064 IDET crash patch: unchanged

## Physical crash evidence

The supplied tvOS crash report is a different failure from the vBRDC064 KSPNUVIO IDET arithmetic trap.

- Exception: `EXC_CRASH / SIGKILL`
- Termination namespace: `FRONTBOARD`
- Watchdog: `0x8BADF00D`
- Reason: foreground app failed to terminate gracefully within 5 seconds
- Faulting queue: `com.apple.main-thread`
- Main-thread stack: `LiveTVSourceModel.parseXMLTV` -> `xmltvLookupKeys` -> `normalizeGuideKey` -> `String.replacingOccurrences`

The app had been running for roughly four hours. At termination, Live TV XMLTV refresh was synchronously normalizing a large guide on `LiveTVSourceModel`'s `@MainActor`, preventing FrontBoard from getting a responsive process exit.

## vBRDC065 correction

The program-heavy XMLTV parser is no longer allowed to own the tvOS main thread:

1. `LiveTVSourceModel` snapshots only each channel's already-resolved result key and XMLTV lookup keys on MainActor.
2. Regex enumeration, programme extraction, date parsing, alias normalization, sorting, and guide-window filtering execute in a detached `.utility` task.
3. Parent-task cancellation is explicitly forwarded to that worker.
4. The worker checks cancellation during channel and programme enumeration and while resolving channel rows.
5. Repeated XMLTV channel IDs/aliases use a local normalization cache so the same `replacingOccurrences` work is not repeated for every programme row.
6. The completed value-only guide dictionary is published back by the existing MainActor refresh flow in one step.

Guide matching semantics remain the same: channel ID/display-name aliases, normalized IDs, stale cutoff, 12-hour guide window, and maximum row count are preserved.

## Locked scope

The following are byte-identical to packaged vBRDC064:

- KSPlayer VOD playback surface and the vBRDC062 cache/ghost work
- vBRDC063 matched-frame A/V correction
- vBRDC064 KSPNUVIO IDET overflow patch and vendor fetch script
- VOD exclusive work registry
- TorBox Usenet client/backend runtime
- CatalogStore / Unity surface system
- Skip Intro detector
- PlaybackStateManager

No VOD cache size, startup threshold, reconnect behavior, audio/subtitle behavior, Live TV playback decoder behavior, TorBox provider behavior, or backend behavior changed in this candidate.

## Validation

- All 61 app/extension Swift files parse with `swiftc -frontend -parse`.
- The isolated background XMLTV parser type-checks under Swift on this runner.
- A sample XMLTV document is parsed successfully by the new worker implementation.
- Main app and Top Shelf plist versions match `1.0.768 (768)` / `vBRDC065`.
- Locked playback/provider/KSP files are SHA-256 identical to vBRDC064.
- ZIP integrity is checked after packaging.

A full tvOS/Xcode compile in GitHub Actions and physical Apple TV testing remain authoritative.
