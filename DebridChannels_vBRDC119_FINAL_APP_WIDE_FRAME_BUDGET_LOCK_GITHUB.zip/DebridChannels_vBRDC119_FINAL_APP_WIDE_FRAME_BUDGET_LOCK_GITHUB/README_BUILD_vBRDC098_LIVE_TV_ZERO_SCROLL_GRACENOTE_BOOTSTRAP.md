# Debrid Channels vBRDC098 — Live TV Zero-Scroll Gracenote Bootstrap

Release: **vBRDC098**  
Marketing version: **1.0.801**  
Apple build: **801**  
Donor: packaged **vBRDC097** only.

## Physical-test failure addressed

On a cold launch/relaunch, Live TV could show the real provider lineup but leave program/Gracenote artwork empty until the user moved through the grid. vBRDC097 correctly added connectivity retries and an authoritative artwork refresh generation, but one UI-state gate still prevented those already-mounted cards from ever starting their first artwork request.

### Root cause

`LiveTVScreen` intentionally initializes with demo channel ID `6003` so it has a safe placeholder before a real provider lineup exists. Real IPTV/HDHomeRun/Xtream channels use provider/stable hashed IDs. After `loadCachedOrDemo()` published the real lineup, `selectedChannelID` / `tileFocus` could still point at demo ID 6003.

`liveTVArtworkLoadIDs(in:)` then tried to locate that ID in the mounted real-provider corridor. When the ID was absent it returned an **empty Set**, so every visible tile received `loadArtwork = false`. The guide and Gracenote URLs could already be present in the model, but no mounted card was permitted to request them. The first D-pad movement supplied a real channel ID, the artwork corridor became non-empty, and the images suddenly appeared — exactly matching the physical symptom.

## vBRDC098 correction

- Artwork bootstrap no longer depends on the tvOS Focus Engine having produced its first valid provider ID.
- `liveTVArtworkLoadIDs(in:)` now tries current tile focus, guide focus, selected channel, and the persisted Live TV channel ID; if none exists in the mounted corridor it anchors to **the first mounted row instead of returning no artwork owners**.
- Immediately after `loadCachedOrDemo()`, Live TV canonicalizes the selected channel against the published provider lineup.
- Entering Live TV repeats the canonicalization before decoder/prefetch work is enabled, covering the case where the persistent root originally mounted underneath Home/Settings.
- Cold-start guide hydration and active guide refresh canonicalize the selection again after provider publication, protecting lineup replacement/reorder cases.
- Invalid category/selection state falls back to a valid visible channel without animation, resets the virtual window, and restores a valid tile focus only when Live TV actually owns focus.
- Existing vBRDC097 connectivity-aware sessions, refresh tokens, bounded image retry, persistent exact-pixel UNITY root, Gracenote → channel icon fallback, and 24/96-card performance corridors remain unchanged.

The intended invariant is now:

> **If Live TV is visible and at least one channel is mounted, the visible artwork corridor is non-empty even before the user touches the remote.**

## Intended existing-file scope

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/Info.plist`
3. `TopShelfExtension/Info.plist`
4. `project.yml`

No provider, playback, resume, Source Intelligence, In-S, FebBox, TorBox Usenet, wallpaper, motion coordinator, Sports, or Favorites source is changed by this build.

## Validation

- vBRDC098 contract: **52/52 passed**
- Swift syntax parse: **64/64 passed**
- backend pytest: **36 passed, 2 subtests passed**
- plist/project alignment: **8/8 passed**
- donor scope: **4 intended existing-file changes, 0 unexpected**
- app + Top Shelf `plutil -lint`: **OK**
- GitHub Actions/Xcode remains the authoritative Apple SDK compile.
- Physical Apple TV remains authoritative for actual Gracenote network/image timing.
