# Debrid Channels vBRDC080 — UNITY Animation Coordinator

Release: **vBRDC080**  
Marketing version: **1.0.783**  
Apple build: **783**  
Donor: packaged **vBRDC079** only

## Purpose

vBRDC080 turns animation ownership into an app-wide UNITY contract. Cross-surface,
continuous, auxiliary-video, and playback-adjacent animations no longer decide their
lifecycle independently.

## Central coordinator

`Sources/UnityAnimationCoordinator.swift` owns named feature permits for:

- Dynamic wallpaper
- Catalog focus arrival
- Focused-card Pulse
- Focused-card preview video
- Catalog row motion
- Media Information transition
- Media Information connector
- Source Intelligence motion
- Live TV / Guide motion
- Sports motion
- Global ticker motion
- Overlay chrome
- Playback chrome
- Episode-alert motion

The coordinator distinguishes global ownership states from Source Intelligence phases:

- Scene inactive
- Global Search
- Settings
- Detail / Media Information
- Source Intelligence searching
- Source opening / decoder handoff
- Full trailer exclusivity
- Full-screen playback
- Live TV guide

## Critical Source Intelligence rule

**Searching for links is not exclusive.**

Opening the Source Intelligence panel and receiving incremental result batches does not
stop or restart the already-running focused-card preview or Pulse. Those features keep
the same mounted instance/phase because their permit remains `true` throughout search.

**Opening a real source is exclusive.**

Once a selected link begins opening/resolving, UNITY removes the catalog preview/Pulse,
row motion, wallpaper, connector and other nonessential animation lanes before decoder
handoff. Full trailer and full-screen playback use the same exclusive ownership rule.

## Anti-restart design

Views do not react to the coordinator's raw revision counter. The focused preview and Pulse
observe only their computed permit. Therefore unrelated state changes and Source Intelligence
batch updates cannot reset/restart their animation phase.

## Playback safety

No PlaybackKit/KSPlayer source was changed. vBRDC076 playback-priority protections,
vBRDC077 automatic resume + automatic Play, and vBRDC078 VOD-exit interactivity recovery
remain intact. vBRDC079 dynamic wallpaper remains intact, now with UNITY budget permission.

## TorBox

TorBox/Search behavior is unchanged while backend Search API whitelist approval is pending.

## Validation

- vBRDC080 animation contracts: 27/27
- inherited backend tests: 35/35
- Swift syntax parse: 63/63
- plists/YAML: passed
- locked playback/resume/catalog/Source Intelligence/TorBox files: byte-identical to vBRDC079
- all four backend runtime source trees: byte-identical to vBRDC079
