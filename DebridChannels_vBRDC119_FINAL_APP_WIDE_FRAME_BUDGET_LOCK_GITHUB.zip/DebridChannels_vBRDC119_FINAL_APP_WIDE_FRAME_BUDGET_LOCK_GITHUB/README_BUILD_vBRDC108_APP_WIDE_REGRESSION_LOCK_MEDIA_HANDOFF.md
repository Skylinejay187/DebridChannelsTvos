# Debrid Channels vBRDC108 — App-Wide Regression Lock + Media Handoff

- Release ID: `vBRDC108`
- Marketing version: `1.0.811`
- Apple build: `811`
- Donor: packaged `vBRDC107`

## Why this build exists

Physical Apple TV video `38430.mp4` showed that the remaining visible open/close glitch was not the Live TV ↔ catalog branch that earlier builds had targeted. It was the focused catalog card ↔ Media Profile presentation path. That path still serialized a connector draw before the panel reveal, animated the complete 860×858 glass/artwork panel through a changing mask, and on close could begin a 1.18-second connector retraction while releasing the popup about 0.32 seconds later.

The supplied Live TV screenshot also showed a second concrete regression: a generated text channel logo was permanently resident underneath the real downloaded logo. Transparent logos such as History therefore exposed both at once.

## Corrections

### Media Profile open/close

- Connector and Media Profile panel now start on the same render turn.
- The transition is one 0.20-second compositor transaction.
- The full-panel animated mask was removed; the panel keeps the same content/layout and uses only a small direct x-scale/offset/opacity transform.
- Close uses the same 0.20-second timing contract.
- Back/close retargets any decorative connector retraction already in progress to the 0.20-second close window before the popup is released.
- Catalog focus handoff remains prepared before close begins, preserving the selected-card identity and the vBRDC103/vBRDC107 retained preview behavior.
- The normal seven-second connector hold and decorative slow auto-retraction remain when the user is not closing the popup.

### Live TV logo fallback

- Real provider/Gracenote logo and generated `channel.logo` text are now mutually exclusive.
- The text fallback is no longer permanently rendered underneath a real image.
- While a valid image URL is loading the fallback remains absent.
- Generic text appears only when no usable logo URL exists or the loader definitively fails.

## Regression discipline

This build deliberately changes only five existing donor files: the main app source, shared image view, two version plists, and `project.yml`. `UnityCatalogVisualSystem.swift`, `UnityFrameRuntime.swift`, `UnityAnimationCoordinator.swift`, `CastExplorerService.swift`, and `CatalogStore.swift` are byte-identical to vBRDC107.

The vBRDC108 contract also locks the accepted behaviors from vBRDC103–vBRDC107: persistent row scrolling, media-identity focused preview ownership, VOD visible-only Cast/Production cycling, Live TV 3-second/15-second preview, and the persistent catalog shell.

## Validation

- vBRDC108 regression contract: 28/28
- Production Swift parse: 65/65
- Version/project metadata: 8/8
- Backend regression suite: 36/36 tests passed (the alternate-audio bridge suite still exercises its two classification subtests)
- Existing donor scope: exactly 5 files changed
- Critical subsystem hash audit: clean

Physical Apple TV testing remains authoritative for perceived frame pacing and the exact visual handoff.
