# Debrid Channels vBRDC119 — Final App-Wide Frame Budget Lock

Release: **vBRDC119**  
Marketing version: **1.0.822**  
Apple build: **822**

## Donor / source-of-truth rule

This release was built only from the attached packaged donor:

`DebridChannels_vBRDC118_PEAK_SMOOTH_FRAME_PIPELINE_GITHUB.zip`

No older repository state, reconstructed source, or alternate ZIP was used as the implementation donor.

## Purpose

vBRDC119 is an app-wide behavior-preserving performance engineering pass. It does not intentionally remove, shorten, simplify, or lower the quality of existing animations, artwork, layouts, providers, playback behavior, Dynamic Wallpaper, Live TV, VOD, Sports, Favorites, Search, MediaFlow, or catalog features.

The performance goal is to reduce work competing with the 16.67 ms 60 Hz frame budget, especially during focus/navigation and cross-surface motion.

## Highest-impact corrections

### 1. Shared frame gate is now event-driven

The old UNITY courtesy gate used a private sleep/poll loop for every caller. During a D-pad burst, many deferred artwork, provider, guide, persistence, and recovery tasks could independently wake and ask the MainActor whether the frame lane was free.

vBRDC119 adds one shared revision-waiter hub. Waiting tasks now sleep until frame ownership actually changes, cancellation occurs, or a speculative timeout expires. The old `poll` argument remains only for source compatibility and is not used for sleep polling.

### 2. Authoritative results are durable

Already-fetched provider/catalog/guide/image results must not disappear merely because the UI remains busy longer than a courtesy timeout. vBRDC119 adds `waitUntilPermittedDurably` and moves authoritative publication paths to it. Speculative/pre-fetch work may still time out or cancel; authoritative results wait until their lane opens unless genuinely cancelled or superseded.

### 3. Redundant SwiftUI publications are suppressed

Catalog retained rows and Live TV channel/guide snapshots now compare the complete next value before assigning to `@Published` state. Identical results no longer trigger an unnecessary observable-object invalidation.

Live TV guide batches also merge atomically instead of repeatedly publishing one key at a time.

### 4. Stable Live TV identities and O(1) focus lookup

`LiveProgram` no longer receives a fresh random identity for equivalent schedule data. Its identity is deterministic from stable program/schedule information, preventing unchanged guide cells from looking new to SwiftUI.

The Live TV source model now maintains channel-by-ID and position indexes so focus/selection paths do not repeatedly scan the full channel array.

### 5. Live TV parsing moved away from focus frames

M3U parsing now performs its string/attribute work in a detached utility worker and emits Sendable drafts back to the MainActor.

Xtream short-EPG parsing/date work is performed off the MainActor before publication.

XMLTV parsing uses a per-document parse context with reusable regexes and formatters, stores each programme once under its real XMLTV channel ID, and uses a reverse alias index rather than duplicating programme arrays under multiple lookup aliases.

### 6. Live TV cache writes are coalesced off the MainActor

Large channel/guide JSON encoding and atomic file writes now use a utility persistence queue. If several snapshots arrive before a write drains, only the latest pending snapshot is retained, avoiding an I/O backlog while preserving the latest authoritative state.

### 7. Dynamic Wallpaper paused-state polling removed

Animated GIF/WebP wallpaper previously woke repeatedly while paused just to check whether it could continue. It now waits on an event-driven pause gate while retaining the exact current frame, preserving the visual behavior without periodic wakeups.

### 8. Episode metadata/scanner parser pooling

High-frequency episode-card metadata and the new-episode scanner no longer construct stacks of date formatters/regexes for every row. Thread-safe reusable parser pools preserve all accepted date formats and display semantics.

### 9. VOD state publication guards

Repeated AVPlayer duration/play-state values are equality/threshold guarded before state publication, reducing unnecessary VOD view invalidation while preserving the same displayed values and controls.

## vBRDC119 requested VOD Cast addition

While the VOD Cast surface is focused:

- LEFT selects the previous image-backed cast member.
- RIGHT selects the next image-backed cast member.
- Navigation wraps naturally at either end.
- Manual movement resets the existing visible-only 7-second Cast rotation hold from the selected member; it does not add another timer.
- Subtle left/right chevrons appear inside the cast portrait as a temporary discoverability hint and fade after about 2.2 seconds.
- Select still opens Cast Explorer for the currently displayed cast member.
- Accessibility now advertises LEFT/RIGHT browsing.

The Cast design, portrait quality, Cast Explorer, and automatic rotation behavior are otherwise unchanged.

## Important systems deliberately left unchanged

The audit found several systems that already have the desired architecture and were therefore not rewritten:

- `UnityCatalogVisualSystem.swift` — persistent fixed-slot catalog geometry and the existing row motions.
- `UnityAnimationCoordinator.swift` — existing animation ownership coordination.
- `MediaFlowProxyRouter.swift` — vBRDC115 LAN/away-from-home route behavior.
- `CastExplorerService.swift` — Cast Explorer service behavior.
- `SportsCenterViewModel.swift` — Sports model behavior.
- `PlaybackKitFoundation.swift` — existing playback foundation/hidden-clock behavior.
- vBRDC088 fixed-slot focused-card frame measurement — it already measures a non-animated resting slot rather than the bouncing/pulsing card subtree, so no root-geometry rewrite was justified.

## Locked accepted behavior retained

- All existing catalog row animations and focus style.
- vBRDC109 single-owner catalog open/close transition.
- vBRDC116 35-second focused catalog preview cap; no loop.
- Full manually launched Trailer behavior.
- vBRDC117 Bluetooth/Now Playing VOD media controls.
- vBRDC115 MediaFlow LAN Live TV bootstrap route.
- Live TV focus preview behavior.
- Gracenote/XMLTV/provider support.
- VOD Cast/Production visible-only rotation behavior.
- Dynamic Wallpaper themes/quality.
- Episode Alert 530x176 banner and 18-point screen-edge placement.
- Artwork retention/no-black-frame behavior.
- Resume, Find Links, provider/debrid/Usenet, Sports, Favorites, Search, Quick Guide, and playback behavior.

## Validation

See `FINAL_VALIDATION_vBRDC119.txt` for the final package results. GitHub Actions/Xcode remains the authoritative full tvOS Release compile; this environment performs source parsing and regression/runtime validation but does not claim an Apple-device/Xcode build.
