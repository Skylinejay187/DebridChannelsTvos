from pathlib import Path
import plistlib, sys, hashlib
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
RUNTIME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def section(text,a,b):
    i=text.find(a)
    if i<0:return ''
    j=text.find(b,i+len(a))
    return text[i:] if j<0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f:return plistlib.load(f)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC110' and toppl.get('DebridChannelsReleaseID')=='vBRDC110')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.813' and toppl.get('CFBundleShortVersionString')=='1.0.813')
ck('build', apppl.get('CFBundleVersion')=='813' and toppl.get('CFBundleVersion')=='813')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.813')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 813')==2)

live=section(APP,'final class LiveTVSourceModel: ObservableObject','struct LiveTVScreen: View')
ck('Live TV source model found', len(live)>1000)
ck('main bootstrap 2s wait is non-destructive', '_ = await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata, maxWait: 2.00)' in live)
ck('final publish 1.2s wait is non-destructive', '_ = await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata, maxWait: 1.20)' in live)
ck('deferred EPG wait is non-destructive', '_ = await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata, maxWait: 1.50)' in live)
ck('no destructive frame guards in Live TV source model', 'guard await UnityFrameRuntime.shared.waitUntilPermitted(.interactiveMetadata' not in live)
ck('generation guard retained after courtesy wait', 'guard generation == refreshGeneration, !Task.isCancelled, !VODExclusivePlaybackGate.isActive else { return }' in live)
ck('successful channel publish retained', 'channels = finalized.sorted' in live and 'guidePrograms = finalizedGuidePrograms' in live)
ck('Xtream batches publish after courtesy wait', 'never abort an already-fetched Xtream lineup batch' in live and 'channels = staged.sorted' in live)
ck('native EPG batches publish after courtesy wait', 'a completed native EPG batch is durable' in live)

# MediaFlow Proxy code is intentionally not rewritten for this regression.
router=ROOT/'Sources/MediaFlowProxyRouter.swift'
ck('MediaFlow Proxy router present', router.exists())
# Stable hash from vBRDC101/vBRDC109 donor comparison.
ck('MediaFlow Proxy router remains known-good donor', sha(router)=='310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4')

# Accepted vBRDC109 and earlier invariants remain.
root=section(APP,'struct RootView: View','struct TopMenuBar')
ck('v109 single-owner transition retained', '@State private var unityCatalogBranchTransitionActive: Bool = false' in root and 'surfaceHandoffActive: unityCatalogBranchTransitionActive' in root)
ck('v109 hidden preflight retained', 'preflight: 0.034' in RUNTIME and 'focusBind: 0.220' in RUNTIME)
ck('v108 real logo fallback retained', 'fallbackText: channel.logo' in APP)
ck('v107 focused preview ownership retained', 'focusedCardPreviewRequestedKey == requestedKey' in APP)
ck('v106 VOD rotation retained', 'vBRDC106-production-rotation' in APP and '7_000_000_000' in APP)
ck('v105 Live TV preview retained', 'liveTVGridFocusPreviewEnabledV1' in APP and '3_000_000_000' in APP and '15_000_000_000' in APP)
ck('v104 persistent catalog shell retained', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)
ck('v103 persistent rail retained', 'persistentRailMotionPhase' in APP and 'commitPersistentHorizontalMove' in APP)
ck('48 row-motion visual source retained', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
