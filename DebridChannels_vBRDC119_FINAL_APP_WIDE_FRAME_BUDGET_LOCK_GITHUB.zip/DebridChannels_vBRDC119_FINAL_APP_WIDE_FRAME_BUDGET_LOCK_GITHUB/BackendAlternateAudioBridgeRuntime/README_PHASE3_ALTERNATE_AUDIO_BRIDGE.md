# Phase 3 Alternate Audio Bridge runtime

Register `alternate_audio_bridge_runtime.create_fastapi_router()` on the existing authenticated Debrid Channels FastAPI application.

```python
from BackendAlternateAudioBridgeRuntime.alternate_audio_bridge_runtime import (
    BridgeConfig,
    create_fastapi_router,
)

app.include_router(create_fastapi_router(BridgeConfig(
    root_directory="/var/cache/debridchannels/alternate-audio",
    public_base_url="https://your-backend.example/api/alternate-audio/bridge",
)))
```

The backend host requires `ffprobe` and `ffmpeg` on `PATH`, and the Phase 2 discovery module must remain installed beside this runtime.

## Endpoint

`POST /api/alternate-audio/bridge`

The request contains the exact movie/episode identity, the currently selected video source, one compatible Phase 2 English-audio candidate, its real stream index, classification, and saved offset. The runtime re-probes both sources before creating a session.

The response returns one short-lived HLS URL plus the untouched original source URL. Phase 3 does not hand the HLS URL to KSPlayer; Phase 4 owns that session-safe switch.

## Media policy

- Video is always `-c:v copy`.
- Exact AAC/AC3/EAC3 audio can be stream-copied.
- Offset or drift correction re-encodes audio only.
- TrueHD, DTS, and other HLS-incompatible audio are converted to AAC while video remains untouched.
- Output is temporary fMP4 HLS (`master.m3u8`, `media.m3u8`, `init.mp4`, `.m4s` segments).
- Every session has a unique UUID and expires after 30 minutes by default.

Phase 9 will expand lifecycle/concurrency/recovery controls. Phase 10 will add signed URLs, token redaction, host allowlists, replay protection, and rate limits. The production app must keep the endpoint behind its existing authentication and resolved-link ownership checks until those phases are complete.
