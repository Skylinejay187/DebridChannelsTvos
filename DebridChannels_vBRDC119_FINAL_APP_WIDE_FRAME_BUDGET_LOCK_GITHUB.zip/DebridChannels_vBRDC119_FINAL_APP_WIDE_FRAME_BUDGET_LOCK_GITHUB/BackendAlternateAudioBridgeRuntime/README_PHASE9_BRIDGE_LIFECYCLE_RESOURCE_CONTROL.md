# Phase 9 — Alternate Audio Bridge Lifecycle and Resource Control

This runtime patch advances the deployed **backend v669** Alternate Audio bridge runtime to the Phase 9 lifecycle contract. Package/deploy it as the next backend candidate (**v670**) together with the existing discovery runtime and existing authenticated backend integration.

## Added in Phase 9

- Every bridge keeps its unique bridge UUID and playback-presentation ownership.
- A deterministic SHA-256 job fingerprint deduplicates identical in-flight work.
- Completed HLS work can be reused only when the exact media/source/stream/offset/classification and playback presentation match.
- Startup and request-time reconciliation removes expired, abandoned, and oversized sessions and marks complete HLS sessions recoverable after a backend restart.
- Presentation-wide cancellation removes all bridge work for a closed/replaced playback session.
- Global and per-presentation concurrency limits reject excess jobs rather than starting duplicate ffmpeg processes.
- Root/session storage budgets evict oldest completed reusable work first and reject new work when the budget cannot be reclaimed safely.
- ffmpeg thread count is bounded; POSIX launches apply best-effort address-space, CPU-time, and file-descriptor limits.
- HLS asset access updates last-access time and enforces the per-session storage ceiling.
- Video remains `-c:v copy` in every bridge plan. Only audio is re-encoded when timing/HLS compatibility requires it.

## Default resource policy

Environment variables may override these defaults:

- `DEBRID_CHANNELS_ALT_AUDIO_MAX_CONCURRENT=3`
- `DEBRID_CHANNELS_ALT_AUDIO_MAX_PER_PRESENTATION=2`
- `DEBRID_CHANNELS_ALT_AUDIO_MAX_ROOT_BYTES=206158430208` (192 GiB)
- `DEBRID_CHANNELS_ALT_AUDIO_MAX_SESSION_BYTES=103079215104` (96 GiB)
- `DEBRID_CHANNELS_ALT_AUDIO_ABANDONED_SECONDS=180`
- `DEBRID_CHANNELS_ALT_AUDIO_FFMPEG_THREADS=2`
- `DEBRID_CHANNELS_ALT_AUDIO_MAX_ADDRESS_SPACE=2147483648` (2 GiB)
- `DEBRID_CHANNELS_ALT_AUDIO_MAX_CPU_SECONDS=21600`

Do not use `docker compose down -v`. This phase does not require deleting persistent volumes.

## API compatibility

The bridge response schema is v2 and adds `jobFingerprint`, `reusedExisting`, `reuseKind`, and `resourcePolicy`. Existing Phase 3/4 fields remain. The `/api/alternate-audio/cancel` route accepts playback-presentation, request, or bridge UUID ownership.

## Phase boundary

Phase 10 still owns signed URLs, provider-token protection, host/private-network validation, replay protection, and rate limiting. Phase 11 still owns codec/performance compatibility.
