from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

from alternate_audio_bridge_runtime import (
    BridgeConfig,
    BridgeError,
    build_bridge_plan,
    cleanup_expired_sessions,
    prepare_alternate_audio_bridge,
    read_bridge_asset,
    reconcile_bridge_sessions,
    bridge_status,
    cancel_bridge_sessions,
)
from alternate_audio_discovery_runtime import AudioTrack, MediaProbe


def probe(codec: str = "aac", duration: float = 3600.0, video: str = "hevc") -> MediaProbe:
    return MediaProbe(
        duration_seconds=duration,
        start_time_seconds=0.0,
        frame_rate=23.976,
        video_codec=video,
        width=3840,
        height=2160,
        chapter_count=12,
        edition="",
        release_metadata="2160P WEB-DL",
        audio_tracks=(
            AudioTrack(2, codec, "eng", "English", True, False, False, False),
        ),
    )


class FakeProcess:
    def __init__(self):
        self.process = subprocess.Popen(["sleep", "60"], start_new_session=True)
        self.pid = self.process.pid

    def stop(self):
        try:
            self.process.terminate()
            self.process.wait(timeout=1)
        except Exception:
            try:
                self.process.kill()
            except Exception:
                pass


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.fake_processes = []
        self.config = BridgeConfig(
            root_directory=str(self.root),
            public_base_url="https://backend.example/api/alternate-audio/bridge",
            ffmpeg_binary="ffmpeg",
            ffprobe_binary="ffprobe",
            ttl_seconds=600,
        )

    def tearDown(self):
        for process in self.fake_processes:
            process.stop()
        self.temp.cleanup()

    def fake_process(self):
        process = FakeProcess()
        self.fake_processes.append(process)
        return process

    def payload(self, classification="Exact Match", offset=0):
        return {
            "schemaVersion": 2,
            "identity": {
                "mediaID": "tt1234567:1:2",
                "imdbID": "tt1234567",
                "mediaType": "series",
                "title": "Example Show",
                "year": "2026",
                "seasonNumber": 1,
                "episodeNumber": 2,
            },
            "currentSource": {
                "url": "https://video.example/show.s01e02.2160p.mkv",
                "filename": "Example.Show.S01E02.2160p.mkv",
            },
            "alternateAudioSource": {
                "url": "https://audio.example/show.s01e02.1080p.mkv",
                "filename": "Example.Show.S01E02.1080p.mkv",
                "classification": classification,
                "selectedAudioTrack": {"streamIndex": 2},
            },
            "offsetMS": offset,
            "requestUUID": "11111111-1111-1111-1111-111111111111",
            "playbackPresentationID": "22222222-2222-2222-2222-222222222222",
        }

    def test_exact_aac_stream_copies_video_and_audio(self):
        plan = build_bridge_plan(
            video_url="https://video.example/a.mkv",
            audio_url="https://audio.example/b.mkv",
            stream_index=2,
            audio_codec="aac",
            classification="Exact Match",
            offset_ms=0,
            session_directory=self.root / "one",
            config=self.config,
        )
        command = list(plan.command)
        self.assertEqual(plan.video_mode, "stream-copy")
        self.assertEqual(plan.audio_mode, "stream-copy")
        self.assertIn("copy", command)
        self.assertNotIn("-filter_complex", command)

    def test_offset_forces_audio_only_reencode(self):
        plan = build_bridge_plan(
            video_url="https://video.example/a.mkv",
            audio_url="https://audio.example/b.mkv",
            stream_index=2,
            audio_codec="aac",
            classification="Offset Match",
            offset_ms=250,
            session_directory=self.root / "two",
            config=self.config,
        )
        command = list(plan.command)
        self.assertEqual(plan.video_mode, "stream-copy")
        self.assertEqual(plan.audio_mode, "AAC re-encode")
        self.assertIn("-filter_complex", command)
        self.assertTrue(any("adelay=250" in value for value in command))
        self.assertEqual(command[command.index("-c:v") + 1], "copy")

    def test_drift_uses_async_resample_without_video_encode(self):
        plan = build_bridge_plan(
            video_url="https://video.example/a.mkv",
            audio_url="https://audio.example/b.mkv",
            stream_index=2,
            audio_codec="eac3",
            classification="Drift Correctable",
            offset_ms=0,
            session_directory=self.root / "three",
            config=self.config,
        )
        self.assertEqual(plan.video_mode, "stream-copy")
        self.assertEqual(plan.audio_mode, "AAC re-encode")
        self.assertTrue(any("aresample=async=1" in value for value in plan.command))

    def test_hls_incompatible_audio_codec_reencodes_audio_only(self):
        plan = build_bridge_plan(
            video_url="https://video.example/a.mkv",
            audio_url="https://audio.example/b.mkv",
            stream_index=2,
            audio_codec="truehd",
            classification="Exact Match",
            offset_ms=0,
            session_directory=self.root / "four",
            config=self.config,
        )
        self.assertEqual(plan.video_mode, "stream-copy")
        self.assertEqual(plan.audio_mode, "AAC re-encode")
        self.assertIn("not HLS", plan.audio_reason)

    def test_possible_and_incompatible_are_rejected(self):
        for classification in ("Possible Match", "Incompatible"):
            with self.subTest(classification=classification):
                with self.assertRaises(BridgeError):
                    prepare_alternate_audio_bridge(
                        self.payload(classification=classification),
                        self.config,
                        probe_fn=lambda *_: probe(),
                        identity_fn=lambda *_: (True, "ok", 100),
                        launcher=lambda *_: self.fake_process(),
                    )

    def test_series_requires_exact_episode_identity(self):
        payload = self.payload()
        del payload["identity"]["episodeNumber"]
        with self.assertRaisesRegex(BridgeError, "seasonNumber and episodeNumber"):
            prepare_alternate_audio_bridge(
                payload,
                self.config,
                probe_fn=lambda *_: probe(),
                identity_fn=lambda *_: (True, "ok", 100),
                launcher=lambda *_: self.fake_process(),
            )

    def test_bridge_creates_short_lived_hls_session_and_keeps_original(self):
        commands = []

        def launch(command, directory):
            commands.append(list(command))
            (directory / "media.m3u8").write_text("#EXTM3U\n", encoding="utf-8")
            (directory / "init.mp4").write_bytes(b"init")
            return self.fake_process()

        response = prepare_alternate_audio_bridge(
            self.payload(),
            self.config,
            probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "exact episode", 100),
            launcher=launch,
            now=1_000.0,
        )
        self.assertTrue(response["hlsURL"].endswith("/master.m3u8"))
        self.assertTrue(response["originalSourceAvailable"])
        self.assertEqual(response["originalSourceURL"], self.payload()["currentSource"]["url"])
        self.assertEqual(response["videoMode"], "stream-copy")
        self.assertTrue(response["phase4HandoffRequired"])
        session = self.root / response["bridgeUUID"]
        self.assertTrue((session / "master.m3u8").exists())
        metadata = json.loads((session / "session.json").read_text(encoding="utf-8"))
        self.assertGreater(int(metadata["ffmpegPID"]), 1)
        self.assertEqual(commands[0][commands[0].index("-c:v") + 1], "copy")

    def test_asset_reader_blocks_path_traversal(self):
        response = prepare_alternate_audio_bridge(
            self.payload(),
            self.config,
            probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100),
            launcher=lambda *_: self.fake_process(),
        )
        with self.assertRaises(BridgeError):
            read_bridge_asset(response["bridgeUUID"], "../session.json", self.config)
        asset = read_bridge_asset(response["bridgeUUID"], "master.m3u8", self.config)
        self.assertEqual(asset.content_type, "application/vnd.apple.mpegurl")

    def test_expired_sessions_are_removed(self):
        directory = self.root / "00000000-0000-0000-0000-000000000000"
        directory.mkdir()
        (directory / "session.json").write_text(json.dumps({"expiresAtEpoch": 10}), encoding="utf-8")
        self.assertEqual(cleanup_expired_sessions(self.config, now=20), 1)
        self.assertFalse(directory.exists())

    def test_duplicate_inflight_request_reuses_same_bridge(self):
        launches = []
        def launch(command, directory, *_):
            launches.append(directory.name)
            (directory / "media.m3u8").write_text("#EXTM3U\n", encoding="utf-8")
            return self.fake_process()
        first = prepare_alternate_audio_bridge(
            self.payload(), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=launch, now=1000.0
        )
        second = prepare_alternate_audio_bridge(
            self.payload(), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=launch, now=1001.0
        )
        self.assertEqual(first["bridgeUUID"], second["bridgeUUID"])
        self.assertTrue(second["reusedExisting"])
        self.assertEqual(second["reuseKind"], "in-flight")
        self.assertEqual(len(launches), 1)

    def test_completed_bridge_survives_restart_reconcile_and_reuses(self):
        def launch(command, directory, *_):
            (directory / "media.m3u8").write_text("#EXTM3U\n#EXT-X-ENDLIST\n", encoding="utf-8")
            (directory / "init.mp4").write_bytes(b"init")
            return self.fake_process()
        first = prepare_alternate_audio_bridge(
            self.payload(), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=launch, now=1000.0
        )
        metadata_path = self.root / first["bridgeUUID"] / "session.json"
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        metadata["ffmpegPID"] = None
        metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
        stats = reconcile_bridge_sessions(self.config, now=1001.0)
        self.assertEqual(stats["abandoned"], 0)
        second = prepare_alternate_audio_bridge(
            self.payload(), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=lambda *_: self.fail("should reuse"), now=1002.0
        )
        self.assertEqual(first["bridgeUUID"], second["bridgeUUID"])
        self.assertEqual(second["reuseKind"], "completed")

    def test_abandoned_job_is_removed_after_grace(self):
        directory = self.root / "33333333-3333-3333-3333-333333333333"
        directory.mkdir()
        (directory / "session.json").write_text(json.dumps({
            "bridgeUUID": directory.name,
            "createdAtEpoch": 1000,
            "lastAccessEpoch": 1000,
            "expiresAtEpoch": 5000,
            "ffmpegPID": None,
        }), encoding="utf-8")
        stats = reconcile_bridge_sessions(self.config, now=1300.0)
        self.assertEqual(stats["abandoned"], 1)
        self.assertFalse(directory.exists())

    def test_concurrency_limit_rejects_new_distinct_job(self):
        limited = BridgeConfig(
            root_directory=str(self.root), public_base_url=self.config.public_base_url,
            ffmpeg_binary="ffmpeg", ffprobe_binary="ffprobe", ttl_seconds=600,
            maximum_concurrent_sessions=1, maximum_sessions_per_presentation=2
        )
        prepare_alternate_audio_bridge(
            self.payload(), limited, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=lambda *_: self.fake_process(), now=1000.0
        )
        other = self.payload(offset=250)
        with self.assertRaisesRegex(BridgeError, "concurrency limit"):
            prepare_alternate_audio_bridge(
                other, limited, probe_fn=lambda *_: probe(),
                identity_fn=lambda *_: (True, "ok", 100), launcher=lambda *_: self.fake_process(), now=1001.0
            )

    def test_status_reports_phase9_fingerprint_and_size(self):
        def launch(command, directory, *_):
            (directory / "media.m3u8").write_text("#EXTM3U\n#EXT-X-ENDLIST\n", encoding="utf-8")
            return self.fake_process()
        response = prepare_alternate_audio_bridge(
            self.payload(), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=launch
        )
        status = bridge_status(response["bridgeUUID"], self.config)
        self.assertTrue(status["jobFingerprint"])
        self.assertTrue(status["completed"])
        self.assertGreaterEqual(status["sessionBytes"], 1)

    def test_presentation_cancellation_removes_all_owned_jobs(self):
        first = prepare_alternate_audio_bridge(
            self.payload(offset=0), self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=lambda *_: self.fake_process(), now=1000.0
        )
        second_payload = self.payload(offset=250)
        second = prepare_alternate_audio_bridge(
            second_payload, self.config, probe_fn=lambda *_: probe(),
            identity_fn=lambda *_: (True, "ok", 100), launcher=lambda *_: self.fake_process(), now=1001.0
        )
        result = cancel_bridge_sessions(
            playback_presentation_id=self.payload()["playbackPresentationID"],
            reason="playback closed", config=self.config
        )
        self.assertEqual(result["cancelledCount"], 2)
        self.assertFalse((self.root / first["bridgeUUID"]).exists())
        self.assertFalse((self.root / second["bridgeUUID"]).exists())


if __name__ == "__main__":
    unittest.main()
