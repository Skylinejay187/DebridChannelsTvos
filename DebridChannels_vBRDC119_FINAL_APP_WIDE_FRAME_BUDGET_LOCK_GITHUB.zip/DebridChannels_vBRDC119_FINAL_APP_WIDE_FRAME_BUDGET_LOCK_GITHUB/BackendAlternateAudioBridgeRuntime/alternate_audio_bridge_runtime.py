"""Debrid Channels Phase 3 Alternate Audio bridge runtime.

The bridge keeps video from the user's selected high-quality source and takes one
verified English audio stream from a compatible Phase 2 discovery candidate. Video
is always stream-copied. Audio is stream-copied when HLS/timing compatibility allows,
and is encoded to AAC only when offset correction, drift correction, or HLS codec
compatibility requires it.

Production endpoint:
    POST /api/alternate-audio/bridge

The returned HLS URL is intentionally *not* handed to KSPlayer in Phase 3. The tvOS
client may prepare and inspect a short-lived bridge session, while Phase 4 owns the
session-safe player handoff.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import shutil
import subprocess
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Iterator, Mapping, Optional, Sequence, Tuple
from urllib.parse import urlparse

try:
    from alternate_audio_discovery_runtime import (
        AudioTrack,
        MediaProbe,
        ProbeConfig,
        probe_media,
        verify_identity,
    )
except ImportError:  # package-style backend integration
    from BackendAlternateAudioRuntime.alternate_audio_discovery_runtime import (
        AudioTrack,
        MediaProbe,
        ProbeConfig,
        probe_media,
        verify_identity,
    )

SCHEMA_VERSION = 2
SUPPORTED_CLASSIFICATIONS = {"Exact Match", "Offset Match", "Drift Correctable"}
HLS_AUDIO_COPY_CODECS = {"aac", "ac3", "eac3"}
SAFE_ASSET_PATTERN = re.compile(r"^(?:master\.m3u8|media\.m3u8|init\.mp4|segment_\d{6}\.m4s)$")


class BridgeError(RuntimeError):
    """A client-safe bridge preparation failure."""


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class BridgeConfig:
    root_directory: str = os.environ.get(
        "DEBRID_CHANNELS_ALT_AUDIO_ROOT", "/tmp/debridchannels-alternate-audio"
    )
    public_base_url: str = os.environ.get(
        "DEBRID_CHANNELS_ALT_AUDIO_PUBLIC_BASE", "/api/alternate-audio/bridge"
    )
    ffmpeg_binary: str = os.environ.get("FFMPEG_BINARY", "ffmpeg")
    ffprobe_binary: str = os.environ.get("FFPROBE_BINARY", "ffprobe")
    ttl_seconds: int = 30 * 60
    segment_seconds: int = 4
    maximum_offset_ms: int = 120_000
    maximum_asset_bytes: int = 64 * 1024 * 1024
    # Phase 9 lifecycle/resource controls. Defaults are deliberately conservative:
    # video is stream-copied, so CPU is dominated by probe/audio work rather than encode.
    maximum_concurrent_sessions: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_CONCURRENT", 3)
    maximum_sessions_per_presentation: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_PER_PRESENTATION", 2)
    maximum_root_bytes: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_ROOT_BYTES", 192 * 1024 * 1024 * 1024)
    maximum_session_bytes: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_SESSION_BYTES", 96 * 1024 * 1024 * 1024)
    abandoned_seconds: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_ABANDONED_SECONDS", 180)
    maximum_ffmpeg_threads: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_FFMPEG_THREADS", 2)
    maximum_address_space_bytes: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_ADDRESS_SPACE", 2 * 1024 * 1024 * 1024)
    maximum_cpu_seconds: int = _env_int("DEBRID_CHANNELS_ALT_AUDIO_MAX_CPU_SECONDS", 6 * 60 * 60)


@dataclass(frozen=True)
class BridgePlan:
    command: Tuple[str, ...]
    video_mode: str
    audio_mode: str
    audio_reason: str
    selected_stream_index: int
    selected_audio_codec: str


@dataclass(frozen=True)
class BridgeAsset:
    data: bytes
    content_type: str
    cache_control: str


def _safe_http_url(raw: str) -> bool:
    try:
        parsed = urlparse(raw)
    except Exception:
        return False
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def _required_string(mapping: Mapping[str, Any], key: str, limit: int = 4096) -> str:
    value = str(mapping.get(key) or "").strip()
    if not value:
        raise BridgeError(f"{key} is required")
    return value[:limit]


def _identity(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    value = payload.get("identity")
    if not isinstance(value, Mapping):
        raise BridgeError("identity is required")
    media_id = str(value.get("mediaID") or value.get("media_id") or "").strip()
    title = str(value.get("title") or "").strip()
    media_type = str(value.get("mediaType") or value.get("media_type") or "").strip().lower()
    if not media_id or not title or media_type not in {"movie", "series", "show", "episode", "tv"}:
        raise BridgeError("identity must include mediaID, title, and movie/series mediaType")
    if media_type != "movie":
        season = value.get("seasonNumber", value.get("season_number"))
        episode = value.get("episodeNumber", value.get("episode_number"))
        if season is None or episode is None:
            raise BridgeError("television bridge sessions require exact seasonNumber and episodeNumber")
        try:
            if int(season) < 0 or int(episode) < 0:
                raise ValueError
        except (TypeError, ValueError):
            raise BridgeError("seasonNumber and episodeNumber must be non-negative integers")
    return value


def _source(payload: Mapping[str, Any], *keys: str) -> Mapping[str, Any]:
    for key in keys:
        value = payload.get(key)
        if isinstance(value, Mapping):
            return value
    raise BridgeError(f"{keys[0]} is required")


def _selected_stream_index(source: Mapping[str, Any]) -> int:
    track = source.get("selectedAudioTrack") or source.get("selected_audio_track")
    if isinstance(track, Mapping):
        value = track.get("streamIndex", track.get("stream_index"))
    else:
        value = source.get("audioTrackIndex", source.get("audio_track_index"))
    try:
        index = int(value)
    except (TypeError, ValueError):
        raise BridgeError("alternateAudioSource.selectedAudioTrack.streamIndex is required")
    if index < 0:
        raise BridgeError("selected audio stream index must be non-negative")
    return index


def _classification(source: Mapping[str, Any]) -> str:
    value = str(source.get("classification") or source.get("matchClassification") or "").strip()
    if value not in SUPPORTED_CLASSIFICATIONS:
        raise BridgeError("only Exact Match, Offset Match, or Drift Correctable candidates can create a bridge")
    return value


def _offset_ms(payload: Mapping[str, Any], config: BridgeConfig) -> int:
    raw = payload.get("offsetMS", payload.get("offset_ms", 0))
    try:
        value = int(raw)
    except (TypeError, ValueError):
        raise BridgeError("offsetMS must be an integer")
    if abs(value) > config.maximum_offset_ms:
        raise BridgeError(f"offsetMS exceeds the {config.maximum_offset_ms}ms safety limit")
    return value


def _find_track(probe: MediaProbe, stream_index: int) -> AudioTrack:
    for track in probe.audio_tracks:
        if track.stream_index == stream_index:
            if track.language != "eng":
                raise BridgeError("the selected stream is not tagged as English")
            if track.is_commentary or track.is_descriptive:
                raise BridgeError("commentary or descriptive audio requires an explicit future opt-in")
            return track
    raise BridgeError("the selected English audio stream no longer exists on the candidate source")


def _filter_chain(stream_index: int, offset_ms: int, drift: bool) -> Optional[str]:
    filters = []
    if offset_ms > 0:
        filters.append(f"adelay={offset_ms}:all=1")
    elif offset_ms < 0:
        filters.extend([
            f"atrim=start={abs(offset_ms) / 1000.0:.3f}",
            "asetpts=PTS-STARTPTS",
        ])
    if drift:
        filters.append("aresample=async=1:min_hard_comp=0.100:first_pts=0")
    if not filters:
        return None
    return f"[1:{stream_index}]" + ",".join(filters) + "[aout]"


def build_bridge_plan(
    *,
    video_url: str,
    audio_url: str,
    stream_index: int,
    audio_codec: str,
    classification: str,
    offset_ms: int,
    session_directory: Path,
    config: BridgeConfig,
) -> BridgePlan:
    """Build the deterministic ffmpeg plan without launching it."""
    if not _safe_http_url(video_url) or not _safe_http_url(audio_url):
        raise BridgeError("bridge inputs must be resolved HTTP(S) media URLs")
    if video_url == audio_url:
        raise BridgeError("alternate audio must come from a different resolved source")
    if classification not in SUPPORTED_CLASSIFICATIONS:
        raise BridgeError("candidate classification is not bridge-compatible")

    normalized_codec = audio_codec.lower().strip()
    drift = classification == "Drift Correctable"
    requires_filter = offset_ms != 0 or drift
    codec_requires_encode = normalized_codec not in HLS_AUDIO_COPY_CODECS
    copy_audio = not requires_filter and not codec_requires_encode

    if requires_filter:
        reason = "offset correction" if offset_ms != 0 and not drift else (
            "drift correction" if offset_ms == 0 else "offset and drift correction"
        )
    elif codec_requires_encode:
        reason = f"{normalized_codec or 'unknown'} is not HLS fMP4 audio-copy compatible"
    else:
        reason = "compatible English audio stream copied"

    media_playlist = session_directory / "media.m3u8"
    segment_pattern = session_directory / "segment_%06d.m4s"
    command = [
        config.ffmpeg_binary,
        "-nostdin", "-hide_banner", "-loglevel", "warning", "-y",
        "-threads", str(max(1, config.maximum_ffmpeg_threads)),
        "-thread_queue_size", "2048", "-i", video_url,
        "-thread_queue_size", "2048", "-i", audio_url,
        "-map", "0:v:0",
    ]

    filter_chain = _filter_chain(stream_index, offset_ms, drift)
    if filter_chain:
        command += ["-filter_complex", filter_chain, "-map", "[aout]"]
    else:
        command += ["-map", f"1:{stream_index}"]

    command += [
        "-map_metadata", "0", "-map_chapters", "0",
        "-c:v", "copy",
    ]
    if copy_audio:
        command += ["-c:a", "copy"]
    else:
        command += ["-c:a", "aac", "-b:a", "384k"]

    command += [
        "-sn", "-dn", "-shortest",
        "-avoid_negative_ts", "make_zero",
        "-max_interleave_delta", "0",
        "-f", "hls",
        "-hls_time", str(max(2, config.segment_seconds)),
        "-hls_list_size", "0",
        "-hls_segment_type", "fmp4",
        "-hls_fmp4_init_filename", "init.mp4",
        "-hls_segment_filename", str(segment_pattern),
        "-hls_flags", "independent_segments+temp_file",
        str(media_playlist),
    ]

    return BridgePlan(
        command=tuple(command),
        video_mode="stream-copy",
        audio_mode="stream-copy" if copy_audio else "AAC re-encode",
        audio_reason=reason,
        selected_stream_index=stream_index,
        selected_audio_codec=normalized_codec or "unknown",
    )


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(path)


def _process_exists(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _terminate_process_group(pid: int, grace_seconds: float = 0.75) -> bool:
    if pid <= 1:
        return False
    signalled = False
    try:
        os.killpg(pid, signal.SIGTERM)
        signalled = True
    except OSError:
        try:
            os.kill(pid, signal.SIGTERM)
            signalled = True
        except OSError:
            return False
    deadline = time.time() + max(0.05, grace_seconds)
    while time.time() < deadline:
        if not _process_exists(pid):
            return signalled
        time.sleep(0.05)
    try:
        os.killpg(pid, signal.SIGKILL)
    except OSError:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    return signalled


def cancel_bridge_directory(directory: Path, reason: str = "cancelled") -> bool:
    metadata_path = directory / "session.json"
    metadata: Dict[str, Any] = {}
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except Exception:
        metadata = {}
    try:
        pid = int(metadata.get("ffmpegPID") or 0)
    except (TypeError, ValueError):
        pid = 0
    if pid > 1:
        _terminate_process_group(pid)
    metadata["status"] = "cancelled"
    metadata["cancelReason"] = str(reason)[:240]
    metadata["cancelledAtEpoch"] = time.time()
    try:
        _write_json(metadata_path, metadata)
    except Exception:
        pass
    shutil.rmtree(directory, ignore_errors=True)
    return True


def _launch_ffmpeg(command: Sequence[str], session_directory: Path, config: Optional[BridgeConfig] = None) -> subprocess.Popen[bytes]:
    stderr_handle = (session_directory / "ffmpeg.stderr.log").open("ab", buffering=0)
    policy = config or BridgeConfig()

    def apply_limits() -> None:
        # The production backend runs on Linux. Keep this best-effort so a platform
        # without `resource` still starts rather than turning lifecycle protection
        # into an availability failure.
        try:
            import resource
            if policy.maximum_address_space_bytes > 0:
                resource.setrlimit(resource.RLIMIT_AS, (policy.maximum_address_space_bytes, policy.maximum_address_space_bytes))
            if policy.maximum_cpu_seconds > 0:
                resource.setrlimit(resource.RLIMIT_CPU, (policy.maximum_cpu_seconds, policy.maximum_cpu_seconds))
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
        except Exception:
            pass

    try:
        process = subprocess.Popen(
            list(command),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=stderr_handle,
            cwd=str(session_directory),
            start_new_session=True,
            preexec_fn=apply_limits if os.name == "posix" else None,
        )
        stderr_handle.close()
        return process
    except Exception:
        stderr_handle.close()
        raise


def cleanup_expired_sessions(config: BridgeConfig = BridgeConfig(), now: Optional[float] = None) -> int:
    root = Path(config.root_directory)
    if not root.exists():
        return 0
    current = time.time() if now is None else now
    removed = 0
    for child in root.iterdir():
        if not child.is_dir():
            continue
        metadata_path = child / "session.json"
        try:
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            expires_at = float(metadata.get("expiresAtEpoch") or 0)
        except Exception:
            expires_at = child.stat().st_mtime + config.ttl_seconds
        if expires_at <= current:
            cancel_bridge_directory(child, "bridge session expired")
            removed += 1
    return removed


def _directory_bytes(directory: Path) -> int:
    total = 0
    try:
        for path in directory.rglob("*"):
            if path.is_file():
                try:
                    total += path.stat().st_size
                except OSError:
                    pass
    except OSError:
        pass
    return total


def _playlist_complete(directory: Path) -> bool:
    playlist = directory / "media.m3u8"
    if not playlist.exists():
        return False
    try:
        return "#EXT-X-ENDLIST" in playlist.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False


def _load_metadata(directory: Path) -> Dict[str, Any]:
    try:
        return json.loads((directory / "session.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def _touch_metadata(directory: Path, metadata: Dict[str, Any], now: Optional[float] = None) -> None:
    metadata["lastAccessEpoch"] = time.time() if now is None else now
    try:
        _write_json(directory / "session.json", metadata)
    except Exception:
        pass


def _session_runtime_state(directory: Path, metadata: Mapping[str, Any]) -> str:
    if _playlist_complete(directory):
        return "complete"
    try:
        pid = int(metadata.get("ffmpegPID") or 0)
    except (TypeError, ValueError):
        pid = 0
    if (directory / "media.m3u8").exists() and (pid <= 1 or _process_exists(pid)):
        return "ready"
    if pid > 1 and _process_exists(pid):
        return "preparing"
    return "abandoned"


@contextmanager
def _lifecycle_lock(config: BridgeConfig) -> Iterator[None]:
    root = Path(config.root_directory)
    root.mkdir(parents=True, exist_ok=True)
    lock_path = root / ".phase9.lock"
    handle = lock_path.open("a+")
    try:
        try:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        except Exception:
            pass
        yield
    finally:
        try:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        except Exception:
            pass
        handle.close()


def _job_fingerprint(
    identity: Mapping[str, Any],
    video_url: str,
    audio_url: str,
    stream_index: int,
    classification: str,
    offset_ms: int,
    playback_presentation_id: str,
) -> str:
    stable = {
        "mediaID": identity.get("mediaID", identity.get("media_id")),
        "mediaType": identity.get("mediaType", identity.get("media_type")),
        "seasonNumber": identity.get("seasonNumber", identity.get("season_number")),
        "episodeNumber": identity.get("episodeNumber", identity.get("episode_number")),
        "videoURL": video_url,
        "audioURL": audio_url,
        "streamIndex": stream_index,
        "classification": classification,
        "offsetMS": offset_ms,
        "playbackPresentationID": playback_presentation_id,
    }
    encoded = json.dumps(stable, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def reconcile_bridge_sessions(config: BridgeConfig = BridgeConfig(), now: Optional[float] = None) -> Dict[str, int]:
    """Recover reusable sessions and purge expired, abandoned, or oversized work."""
    root = Path(config.root_directory)
    if not root.exists():
        return {"expired": 0, "abandoned": 0, "oversized": 0, "evicted": 0}
    current = time.time() if now is None else now
    stats = {"expired": 0, "abandoned": 0, "oversized": 0, "evicted": 0}
    reusable = []
    for child in list(root.iterdir()):
        if not child.is_dir():
            continue
        metadata = _load_metadata(child)
        try:
            expires_at = float(metadata.get("expiresAtEpoch") or 0)
        except (TypeError, ValueError):
            expires_at = 0
        if expires_at and expires_at <= current:
            cancel_bridge_directory(child, "bridge session expired")
            stats["expired"] += 1
            continue
        size = _directory_bytes(child)
        if config.maximum_session_bytes > 0 and size > config.maximum_session_bytes:
            cancel_bridge_directory(child, "bridge session exceeded storage limit")
            stats["oversized"] += 1
            continue
        state = _session_runtime_state(child, metadata)
        last_activity = float(metadata.get("lastAccessEpoch") or metadata.get("createdAtEpoch") or child.stat().st_mtime)
        if state == "abandoned" and current - last_activity >= max(30, config.abandoned_seconds):
            cancel_bridge_directory(child, "abandoned bridge job recovered after backend restart")
            stats["abandoned"] += 1
            continue
        if state == "complete":
            if metadata.get("status") != "complete":
                metadata["status"] = "complete"
                metadata["recoveredAfterRestart"] = True
                _write_json(child / "session.json", metadata)
            reusable.append((last_activity, child, size))

    root_bytes = sum(_directory_bytes(child) for child in root.iterdir() if child.is_dir())
    limit = max(0, config.maximum_root_bytes)
    if limit and root_bytes > limit:
        for _, child, size in sorted(reusable, key=lambda row: row[0]):
            cancel_bridge_directory(child, "completed bridge evicted for storage budget")
            root_bytes -= size
            stats["evicted"] += 1
            if root_bytes <= limit:
                break
    return stats


def _active_session_rows(config: BridgeConfig, now: Optional[float] = None):
    root = Path(config.root_directory)
    current = time.time() if now is None else now
    rows = []
    if not root.exists():
        return rows
    for child in root.iterdir():
        if not child.is_dir():
            continue
        metadata = _load_metadata(child)
        try:
            if float(metadata.get("expiresAtEpoch") or 0) <= current:
                continue
        except (TypeError, ValueError):
            continue
        state = _session_runtime_state(child, metadata)
        if state in {"preparing", "ready", "complete"}:
            rows.append((child, metadata, state))
    return rows


def _response_from_session(directory: Path, metadata: Dict[str, Any], config: BridgeConfig, *, reused: bool, reuse_kind: Optional[str]) -> Dict[str, Any]:
    state = _session_runtime_state(directory, metadata)
    metadata["status"] = state
    _touch_metadata(directory, metadata)
    public_base = config.public_base_url.rstrip("/")
    bridge_uuid = str(metadata.get("bridgeUUID") or directory.name)
    expires_epoch = float(metadata.get("expiresAtEpoch") or 0)
    return {
        "schemaVersion": SCHEMA_VERSION,
        "status": "ready" if state in {"ready", "complete"} else state,
        "bridgeUUID": bridge_uuid,
        "hlsURL": f"{public_base}/{bridge_uuid}/master.m3u8",
        "expiresAt": datetime.fromtimestamp(expires_epoch, tz=timezone.utc).isoformat() if expires_epoch else None,
        "expiresAtEpoch": expires_epoch,
        "originalSourceURL": metadata.get("originalSourceURL"),
        "originalSourceAvailable": True,
        "classification": metadata.get("classification"),
        "offsetMS": int(metadata.get("offsetMS") or 0),
        "videoMode": metadata.get("videoMode"),
        "audioMode": metadata.get("audioMode"),
        "audioReason": metadata.get("audioReason"),
        "selectedStreamIndex": int(metadata.get("selectedStreamIndex") or 0),
        "selectedAudioCodec": metadata.get("selectedAudioCodec") or "unknown",
        "phase4HandoffRequired": True,
        "jobFingerprint": metadata.get("jobFingerprint"),
        "reusedExisting": reused,
        "reuseKind": reuse_kind,
        "resourcePolicy": {
            "maximumConcurrentSessions": config.maximum_concurrent_sessions,
            "maximumSessionsPerPresentation": config.maximum_sessions_per_presentation,
            "maximumRootBytes": config.maximum_root_bytes,
            "maximumSessionBytes": config.maximum_session_bytes,
        },
    }


def prepare_alternate_audio_bridge(
    payload: Mapping[str, Any],
    config: BridgeConfig = BridgeConfig(),
    *,
    probe_fn: Callable[[str, str, ProbeConfig], MediaProbe] = probe_media,
    identity_fn: Callable[[Mapping[str, Any], str], Tuple[bool, str, int]] = verify_identity,
    launcher: Callable[[Sequence[str], Path], Any] = _launch_ffmpeg,
    now: Optional[float] = None,
) -> Dict[str, Any]:
    """Validate, plan, and launch one short-lived bridge session."""
    cleanup_expired_sessions(config, now=now)
    identity = _identity(payload)
    current = _source(payload, "currentSource", "current_source")
    alternate = _source(payload, "alternateAudioSource", "alternate_audio_source")
    video_url = _required_string(current, "url")
    audio_url = _required_string(alternate, "url")
    if not _safe_http_url(video_url) or not _safe_http_url(audio_url):
        raise BridgeError("only backend-resolved HTTP(S) source URLs are accepted")

    classification = _classification(alternate)
    stream_index = _selected_stream_index(alternate)
    offset_ms = _offset_ms(payload, config)
    playback_presentation_id = str(payload.get("playbackPresentationID") or payload.get("playback_presentation_id") or "").strip()
    if not playback_presentation_id:
        raise BridgeError("playbackPresentationID is required for Phase 9 bridge ownership")
    fingerprint = _job_fingerprint(identity, video_url, audio_url, stream_index, classification, offset_ms, playback_presentation_id)
    current_filename = str(current.get("filename") or identity.get("title") or "Current source")[:512]
    alternate_filename = str(alternate.get("filename") or "Alternate source")[:512]

    identity_ok, identity_reason, _ = identity_fn(identity, alternate_filename)
    if not identity_ok:
        raise BridgeError(f"alternate source ownership failed: {identity_reason}")

    # Deduplicate before ffprobe/ffmpeg. Completed work survives backend restarts; an
    # identical in-flight request returns the same bridge UUID instead of spawning work.
    with _lifecycle_lock(config):
        reconcile_bridge_sessions(config, now=now)
        rows = _active_session_rows(config, now=now)
        for directory, metadata, state in rows:
            if metadata.get("jobFingerprint") == fingerprint and metadata.get("playbackPresentationID") == playback_presentation_id:
                kind = "completed" if state == "complete" else "in-flight"
                return _response_from_session(directory, metadata, config, reused=True, reuse_kind=kind)
        per_owner = [row for row in rows if row[1].get("playbackPresentationID") == playback_presentation_id]
        if len(rows) >= max(1, config.maximum_concurrent_sessions):
            raise BridgeError("Alternate Audio bridge concurrency limit reached; retry after an active bridge is released")
        if len(per_owner) >= max(1, config.maximum_sessions_per_presentation):
            raise BridgeError("This playback already owns the maximum number of bridge sessions")
        if config.maximum_root_bytes > 0:
            root = Path(config.root_directory)
            if sum(_directory_bytes(child) for child in root.iterdir() if child.is_dir()) >= config.maximum_root_bytes:
                raise BridgeError("Alternate Audio bridge storage budget is full")

        probe_config = ProbeConfig(
            ffprobe_binary=config.ffprobe_binary,
            ffmpeg_binary=config.ffmpeg_binary,
        )
        current_probe = probe_fn(video_url, current_filename, probe_config)
        alternate_probe = probe_fn(audio_url, alternate_filename, probe_config)
        if not current_probe.video_codec:
            raise BridgeError("the selected high-quality source has no usable video stream")
        track = _find_track(alternate_probe, stream_index)

        if current_probe.duration_seconds and alternate_probe.duration_seconds:
            duration_delta = abs(current_probe.duration_seconds - alternate_probe.duration_seconds)
            if duration_delta > 45:
                raise BridgeError("candidate duration changed and is no longer bridge-compatible")

        bridge_uuid = str(uuid.uuid4())
        root = Path(config.root_directory)
        root.mkdir(parents=True, exist_ok=True)
        session_directory = root / bridge_uuid
        session_directory.mkdir(mode=0o700)
        created_epoch = time.time() if now is None else now
        expires_epoch = created_epoch + max(60, config.ttl_seconds)

        try:
            plan = build_bridge_plan(
                video_url=video_url,
                audio_url=audio_url,
                stream_index=stream_index,
                audio_codec=track.codec,
                classification=classification,
                offset_ms=offset_ms,
                session_directory=session_directory,
                config=config,
            )
            # The master playlist exists immediately. KSPlayer handoff remains Phase 4,
            # but the URL is stable while ffmpeg fills media.m3u8 and fMP4 segments.
            (session_directory / "master.m3u8").write_text(
                "#EXTM3U\n#EXT-X-VERSION:7\n"
                "#EXT-X-STREAM-INF:BANDWIDTH=16000000\nmedia.m3u8\n",
                encoding="utf-8",
            )
            metadata = {
                "schemaVersion": SCHEMA_VERSION,
                "bridgeUUID": bridge_uuid,
                "status": "preparing",
                "createdAtEpoch": created_epoch,
                "expiresAtEpoch": expires_epoch,
                "mediaID": str(identity.get("mediaID") or identity.get("media_id") or ""),
                "mediaType": str(identity.get("mediaType") or identity.get("media_type") or ""),
                "seasonNumber": identity.get("seasonNumber", identity.get("season_number")),
                "episodeNumber": identity.get("episodeNumber", identity.get("episode_number")),
                "classification": classification,
                "offsetMS": offset_ms,
                "videoMode": plan.video_mode,
                "audioMode": plan.audio_mode,
                "audioReason": plan.audio_reason,
                "selectedStreamIndex": stream_index,
                "selectedAudioCodec": track.codec,
                "originalSourceURL": video_url,
                "alternateAudioSourceURL": audio_url,
                "playbackPresentationID": str(payload.get("playbackPresentationID") or payload.get("playback_presentation_id") or ""),
                "requestUUID": str(payload.get("requestUUID") or payload.get("request_uuid") or ""),
                "jobFingerprint": fingerprint,
                "lastAccessEpoch": created_epoch,
                "recoveredAfterRestart": False,
            }
            _write_json(session_directory / "session.json", metadata)
            try:
                process = launcher(plan.command, session_directory, config)
            except TypeError:
                process = launcher(plan.command, session_directory)
            pid = getattr(process, "pid", None)
            metadata["ffmpegPID"] = int(pid) if isinstance(pid, int) else None
            _write_json(session_directory / "session.json", metadata)
        except Exception:
            shutil.rmtree(session_directory, ignore_errors=True)
            raise

        metadata = _load_metadata(session_directory)
        return _response_from_session(session_directory, metadata, config, reused=False, reuse_kind=None)



def cancel_bridge_sessions(
    *,
    playback_presentation_id: Optional[str] = None,
    request_uuid: Optional[str] = None,
    bridge_uuid: Optional[str] = None,
    reason: str = "cancelled",
    config: BridgeConfig = BridgeConfig(),
) -> Dict[str, Any]:
    """Cancel exact bridge work or every job owned by one playback presentation."""
    owner = str(playback_presentation_id or "").strip()
    request = str(request_uuid or "").strip()
    bridge = str(bridge_uuid or "").strip()
    if not owner and not request and not bridge:
        raise BridgeError("a playback presentation, request UUID, or bridge UUID is required")
    root = Path(config.root_directory)
    cancelled = []
    if root.exists():
        for directory in list(root.iterdir()):
            if not directory.is_dir():
                continue
            metadata = _load_metadata(directory)
            matches = (
                (bridge and directory.name == bridge)
                or (owner and str(metadata.get("playbackPresentationID") or "") == owner)
                or (request and str(metadata.get("requestUUID") or "") == request)
            )
            if not matches:
                continue
            cancel_bridge_directory(directory, reason)
            cancelled.append(directory.name)
    return {
        "schemaVersion": SCHEMA_VERSION,
        "cancelled": bool(cancelled),
        "cancelledCount": len(cancelled),
        "bridgeUUIDs": cancelled,
    }


def bridge_status(bridge_uuid: str, config: BridgeConfig = BridgeConfig()) -> Dict[str, Any]:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", bridge_uuid):
        raise BridgeError("invalid bridge UUID")
    reconcile_bridge_sessions(config)
    directory = Path(config.root_directory) / bridge_uuid
    metadata_path = directory / "session.json"
    if not metadata_path.exists():
        raise BridgeError("bridge session not found")
    metadata = _load_metadata(directory)
    now = time.time()
    if float(metadata.get("expiresAtEpoch") or 0) <= now:
        cancel_bridge_directory(directory, "bridge session expired")
        raise BridgeError("bridge session expired")
    state = _session_runtime_state(directory, metadata)
    if state == "abandoned":
        cancel_bridge_directory(directory, "abandoned bridge job")
        raise BridgeError("bridge session was abandoned")
    metadata["status"] = state
    _touch_metadata(directory, metadata, now)
    return {
        "schemaVersion": SCHEMA_VERSION,
        "bridgeUUID": bridge_uuid,
        "status": "ready" if state in {"ready", "complete"} else state,
        "completed": state == "complete",
        "expiresAtEpoch": metadata.get("expiresAtEpoch"),
        "videoMode": metadata.get("videoMode"),
        "audioMode": metadata.get("audioMode"),
        "audioReason": metadata.get("audioReason"),
        "selectedStreamIndex": metadata.get("selectedStreamIndex"),
        "jobFingerprint": metadata.get("jobFingerprint"),
        "recoveredAfterRestart": bool(metadata.get("recoveredAfterRestart")),
        "sessionBytes": _directory_bytes(directory),
    }


def read_bridge_asset(
    bridge_uuid: str,
    asset_name: str,
    config: BridgeConfig = BridgeConfig(),
) -> BridgeAsset:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", bridge_uuid):
        raise BridgeError("invalid bridge UUID")
    if not SAFE_ASSET_PATTERN.fullmatch(asset_name):
        raise BridgeError("invalid bridge asset")
    directory = Path(config.root_directory) / bridge_uuid
    metadata_path = directory / "session.json"
    if not metadata_path.exists():
        raise BridgeError("bridge session not found")
    metadata = _load_metadata(directory)
    if float(metadata.get("expiresAtEpoch") or 0) <= time.time():
        cancel_bridge_directory(directory, "bridge session expired")
        raise BridgeError("bridge session expired")
    session_bytes = _directory_bytes(directory)
    if config.maximum_session_bytes > 0 and session_bytes > config.maximum_session_bytes:
        cancel_bridge_directory(directory, "bridge session exceeded storage limit")
        raise BridgeError("bridge session exceeded the storage limit")
    _touch_metadata(directory, metadata)
    path = directory / asset_name
    if not path.exists() or not path.is_file():
        raise BridgeError("bridge asset is still preparing")
    size = path.stat().st_size
    if size > config.maximum_asset_bytes:
        raise BridgeError("bridge asset exceeds the safe response limit")
    if asset_name.endswith(".m3u8"):
        content_type = "application/vnd.apple.mpegurl"
        cache_control = "no-store"
    elif asset_name.endswith(".mp4") or asset_name.endswith(".m4s"):
        content_type = "video/mp4"
        cache_control = "private, max-age=60"
    else:
        content_type = "application/octet-stream"
        cache_control = "no-store"
    return BridgeAsset(path.read_bytes(), content_type, cache_control)


def create_fastapi_router(config: BridgeConfig = BridgeConfig()):
    """Optional registration helper; importing this module does not require FastAPI."""
    try:
        from fastapi import APIRouter, HTTPException
        from fastapi.responses import Response
    except ImportError as exc:  # pragma: no cover - deployment integration guard
        raise RuntimeError("FastAPI is required to create the bridge router") from exc

    router = APIRouter()
    # Phase 9 restart recovery: reconcile stale/completed work when the backend
    # registers this router, before the first client request arrives.
    reconcile_bridge_sessions(config)

    @router.post("/api/alternate-audio/bridge")
    async def create_bridge_endpoint(body: Dict[str, Any]):
        try:
            return prepare_alternate_audio_bridge(body, config)
        except BridgeError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @router.post("/api/alternate-audio/cancel")
    async def cancel_bridge_endpoint(body: Dict[str, Any]):
        try:
            return cancel_bridge_sessions(
                playback_presentation_id=body.get("playbackPresentationID") or body.get("playback_presentation_id"),
                request_uuid=body.get("requestUUID") or body.get("request_uuid"),
                bridge_uuid=body.get("bridgeUUID") or body.get("bridge_uuid"),
                reason=str(body.get("reason") or "cancelled")[:240],
                config=config,
            )
        except BridgeError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from exc

    @router.get("/api/alternate-audio/bridge/{bridge_uuid}/status")
    async def bridge_status_endpoint(bridge_uuid: str):
        try:
            return bridge_status(bridge_uuid, config)
        except BridgeError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @router.get("/api/alternate-audio/bridge/{bridge_uuid}/{asset_name}")
    async def bridge_asset_endpoint(bridge_uuid: str, asset_name: str):
        try:
            asset = read_bridge_asset(bridge_uuid, asset_name, config)
            return Response(
                content=asset.data,
                media_type=asset.content_type,
                headers={"Cache-Control": asset.cache_control},
            )
        except BridgeError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    return router
