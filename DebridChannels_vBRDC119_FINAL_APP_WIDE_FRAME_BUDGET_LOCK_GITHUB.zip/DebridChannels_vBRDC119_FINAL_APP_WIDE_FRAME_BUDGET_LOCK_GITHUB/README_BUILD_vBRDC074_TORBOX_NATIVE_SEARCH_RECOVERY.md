# Debrid Channels vBRDC074 — TorBox Native Search Recovery

- Release ID: **vBRDC074**
- Marketing version: **1.0.777**
- Apple build: **777**
- Code Name: **UNITY**
- Donor: packaged **vBRDC073** only
- Donor ZIP SHA-256: `f7aad6a01d85f33538f72796a9433e6f5caa978caed9e1a6cc02938ddd7afb3c`
- Backend: **v694 unchanged**

## Physical vBRDC073 finding

On-device testing showed the TorBox Usenet provider pill working normally while every tested movie and episode published **0 Usenet candidates before ranking**. Debrido/Torrentio continued to return links. This proves the remaining fault is inside TorBox release discovery rather than Source Intelligence filtering, ranking, or provider selection.

## vBRDC074 correction

vBRDC074 makes TorBox's authenticated native JSON Search API the primary discovery path:

- primary base remains `https://search-api.torbox.app`;
- Usenet ID search uses `/usenet/<id-type>:<id>` with Bearer authentication;
- request shape matches current TorBox clients: `metadata=false`, `check_cache=true`, `check_owned=true`, `search_user_engines=<bool>`;
- JSON requests explicitly send `Accept: application/json` and `Content-Type: application/json`;
- `cached_only=false` is no longer forced; omission means normal cached + uncached discovery;
- current external-ID spellings are tried first while historical aliases remain compatibility retries;
- every identity available on the MediaItem is attempted instead of stopping after the first catalog identity.

Identity retries include:

- IMDb: `imdb_id`, then `imdb`;
- TMDB: `themoviedb_id`, `tmdb_id`, then `tmdb`;
- TVDB: `thetvdb_id`, `tvdb_id`, then `tvdb`.

The Debrid Channels v694 relay deliberately keeps its historical short-ID wire contract so the currently deployed backend remains compatible. Newznab remains a fallback after native Search API + relay rather than the primary path.

## False-zero masking removed

vBRDC073 had a second zero-result masking bug: after Search API/Newznab failures, a healthy but empty TorBox Main API `/usenet/mylist` request marked the entire discovery operation as successfully completed. That converted authentication, paid-plan, endpoint, or upstream failures into a misleading plain `0 links` result.

vBRDC074 no longer treats Main API library access as release-discovery success. If all actual discovery routes fail and the owned library is empty, the real TorBox discovery error is preserved. When TorBox Usenet is the selected provider, the final empty-state message also preserves that real failure instead of overwriting it with the generic “Try All Providers” text.

This is important because TorBox Search API non-metadata searches require authenticated paid-account access. A real account/plan/API failure can now be distinguished from a legitimate title with zero NZBs during physical testing.

## Preserved from vBRDC073

The vBRDC073 crash and resume fixes are untouched:

- shared Source Intelligence sessions are never invalidated while retained async work can reference them;
- TorBox Usenet task ownership/cancellation remains explicit;
- Newznab `<error/>` responses cannot become false-zero XML results;
- automatic VOD resume remains player-clock confirmed and uses the in-place KSPlayer absolute seek;
- `PlaybackResumeCache.swift` storage format is unchanged;
- TorBox Usenet rows still bypass the ordinary Best-Ranked 25/50 cap;
- all 8 account-scoped debrid/Torrentio credential boundaries remain intact;
- Sports UNITY, 48 catalog motions, and vBRDC069 adaptive large-file VOD buffering remain intact;
- backend v694 remains unchanged.

## Validation

- executable mocked TorBox Search API runtime fixture passes current ID path, Bearer auth, JSON schema parsing, multi-ID fallback, and discovery-failure visibility;
- 20/20 vBRDC074 source contracts pass;
- 35/35 inherited backend runtime tests pass;
- 62/62 app + TopShelf Swift files syntax-parse with Swift 6.2.1;
- `TorBoxUsenetClient.swift` isolated type-check passes;
- DebridChannelsTVOSApp, KSPlayer surface, resume cache, UNITY visual system, Sports runtime, credential bridge, managed-addon bridge, and Source Intelligence manager are byte-identical to packaged vBRDC073;
- all packaged backend runtime directories are byte-identical to packaged vBRDC073;
- both plists + both XcodeGen target blocks report 1.0.777 / 777 / vBRDC074.

GitHub Actions/Xcode remains authoritative for Apple SDK compile/link. Physical Apple TV testing is required for the live authenticated TorBox Search API.
