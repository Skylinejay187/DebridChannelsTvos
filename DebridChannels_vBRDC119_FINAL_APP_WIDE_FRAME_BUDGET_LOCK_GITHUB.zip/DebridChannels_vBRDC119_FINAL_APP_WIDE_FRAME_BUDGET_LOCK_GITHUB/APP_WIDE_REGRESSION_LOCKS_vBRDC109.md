# vBRDC109 App-Wide Regression Locks

A change is not considered acceptable merely because it compiles. The following previously accepted behaviors are explicit invariants for this build line.

1. Catalog horizontal/vertical row motion remains the vBRDC103 persistent renderer with the existing 48 visual presets unchanged.
2. Catalog surface open/close has one visible geometry owner. Focused card focus-size/arrival animations may not run during that cross-surface transition.
3. On catalog open, focused geometry is established while the catalog is invisible before compositor motion begins.
4. On catalog close, Live TV may not reclaim focus until after catalog opacity is zero.
5. Focused catalog preview remains media-identity owned (vBRDC107); Media Profile/control focus does not stop it, while actual Trailer/full playback and a different catalog card do.
6. VOD Featured Cast and Production & Ratings rotate only while the VOD chrome is visible and keep the exact 7-second cadence (vBRDC106).
7. Live TV grid focus preview remains exactly one 3-second dwell -> maximum 15-second preview with no polling/retry storm (vBRDC105).
8. Live TV provider/Gracenote artwork logo wins exclusively; generic text is failure/missing-logo fallback only (vBRDC108).
9. Media Profile open/close remains the vBRDC108 matched 0.20-second compositor handoff.
10. Dynamic Wallpaper, wallpaper themes, Gracenote schedule publication, playback/resume, provider/Usenet, and Source Intelligence ownership boundaries are not modified by vBRDC109.
