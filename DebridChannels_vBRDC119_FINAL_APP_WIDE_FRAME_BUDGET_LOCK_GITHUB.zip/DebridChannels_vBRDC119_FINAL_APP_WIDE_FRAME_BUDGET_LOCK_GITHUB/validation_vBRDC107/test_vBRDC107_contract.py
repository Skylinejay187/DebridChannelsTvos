
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / "Sources" / "DebridChannelsTVOSApp.swift").read_text()
PROJECT = (ROOT / "project.yml").read_text()
INFO = (ROOT / "Sources" / "Info.plist").read_text()
TOP = (ROOT / "TopShelfExtension" / "Info.plist").read_text()

def test_release_metadata():
    assert "MARKETING_VERSION: 1.0.810" in PROJECT
    assert "CURRENT_PROJECT_VERSION: 810" in PROJECT
    assert "<string>1.0.810</string>" in INFO
    assert "<string>810</string>" in INFO
    assert "<string>vBRDC107</string>" in INFO
    assert "<string>1.0.810</string>" in TOP
    assert "<string>810</string>" in TOP
    assert "<string>vBRDC107</string>" in TOP

def test_media_identity_request_owner_exists():
    assert "@State private var focusedCardPreviewRequestedKey: String? = nil" in APP
    assert "focusedCardPreviewRequestedKey = requestedKey" in APP
    assert "requestedKey == focusedCardPreviewRequestedKey" in APP

def test_active_preview_is_not_gated_by_unity_ambient_motion():
    assert "if focused, let previewURL, let previewKey {" in APP
    assert "if focused, coordinatedPreviewEnabled, let previewURL, let previewKey {" not in APP
    assert ".onChange(of: coordinatedPreviewEnabled)" not in APP
    assert "private var coordinatedPreviewEnabled" not in APP

def test_same_identity_active_preview_is_preserved():
    marker = "if focusedCardPreviewKey == requestedKey,"
    assert marker in APP
    block = APP[APP.index(marker): APP.index("// The same card may still be inside", APP.index(marker))]
    assert "unityAnimations.allows(.catalogPreview)" not in block
    assert "focusedCardPreviewTask?.cancel()" in block
    assert "focusedCardPreviewURL != nil" in block

def test_same_identity_pending_request_is_preserved():
    marker = "if focusedCardPreviewRequestedKey == requestedKey,"
    assert marker in APP
    block = APP[APP.index(marker): APP.index("stopFocusedCardPreview()", APP.index(marker))]
    assert "focusedCardPreviewTask != nil" in block
    assert "return" in block

def test_preview_start_resolve_not_cancelled_by_same_title_ui_motion():
    start = APP.index("private func scheduleFocusedCardPreview(reason: String)")
    end = APP.index("private func finishFocusedCardPreview", start)
    block = APP[start:end]
    assert "unityAnimations.allows(.catalogPreview)" not in block
    assert "requestedKey == focusedCardPreviewIdentityKey" in block
    assert "focusedCardPreviewPresentationAllowed(for: item)" in block

def test_trailer_still_has_explicit_stop_owner():
    assert ".debridTrailerExclusivePlaybackDidBegin" in APP
    anchor = APP.index("struct GridOSCatalogOverlay: View")
    idx = APP.index(".onReceive(NotificationCenter.default.publisher(for: .debridTrailerExclusivePlaybackDidBegin))", anchor)
    block = APP[idx: idx + 300]
    assert "stopFocusedCardPreview()" in block

def test_required_full_playback_teardown_remains():
    anchor = APP.index("struct GridOSCatalogOverlay: View")
    idx = APP.index(".onChange(of: store.vodExclusivePlaybackActive)", anchor)
    assert "stopFocusedCardPreview()" in APP[idx:idx+500]
    idx = APP.index(".onChange(of: store.playbackURL)", anchor)
    assert "stopFocusedCardPreview()" in APP[idx:idx+500]

def test_existing_preview_characteristics_and_new_identity_lifetime():
    assert "Task.sleep(nanoseconds: 1_500_000_000)" in APP
    assert "CMTime(seconds: 40" not in APP
    assert "self?.loopCurrentItem()" in APP
    assert "currentPlayer.seek(to: .zero" in APP
    assert "previewPlayer.isMuted = true" in APP
    assert "CGSize(width: 1280, height: 720)" in APP
