# APP-WIDE REGRESSION LOCKS — vBRDC118

These are behavioral contracts for future builds. A performance change must not silently remove or rewrite them.

## Frame ownership

- D-pad/focus geometry owns active navigation frames.
- Heavy decorative 4K cache-miss **network/decode starts** must not compete with active navigation geometry.
- Exact cached heavy artwork may remain immediate.
- Heavy deferral is opt-in; small cards/logos stay responsive and immediate.
- No existing catalog row-motion preset, spring, pulse, glow, hero theme, Dynamic Wallpaper theme, or visual amplitude is reduced by vBRDC118.
- The 4K backdrop decode target remains 3840 for the four opted-in decorative surfaces.

## Catalog

- vBRDC103 persistent fixed-slot catalog scrolling engine stays intact.
- The previously approved retained previous-card artwork handoff stays intact rather than flashing black/blank.
- vBRDC109 single-owner catalog surface open/close geometry stays intact.
- Focused card artwork remains 1280 px and is not delayed by the vBRDC118 heavy-backdrop gate.
- Hero logo remains 1280 px and immediate.
- vBRDC116 focused preview: 1.5s dwell -> up to 35s muted preview -> stop/fade to artwork -> no loop.
- Same-title Media Profile ownership does not terminate a focused preview; actual Trailer launch or different media ownership does.

## Episode Alerts

- Passive banner is 530×176 with an 80×120 poster.
- Root and VOD passive banners use the same 18 pt selected-edge inset.
- Episode alert poster uses bounded central artwork loading (512 px) and is permitted while its VOD alert is visibly on screen.
- Interactive Episode Alert popup remains unchanged.

## VOD / Bluetooth

- vBRDC117 custom VOD player continues to claim tvOS Now Playing ownership while a movie/show session is active.
- `AVAudioSession` playback/moviePlayback, `MPNowPlayingInfoCenter`, and Play/Pause/Toggle `MPRemoteCommandCenter` handlers remain intact.
- VOD closes release Now Playing ownership.
- vBRDC106 Cast/Production rotation remains visible-only with the accepted 7-second cadence.

## Live TV / MediaFlow

- vBRDC115 MediaFlow-enabled home-LAN Live TV bootstrap remains `/proxy/stream`, with XMLTV/Gracenote preferring `/proxy/epg` and falling back to `/proxy/stream`.
- Do not switch home-LAN Live TV bootstrap back to `/proxy/forward`; MediaFlow deliberately rejects private RFC-1918 targets there.
- vBRDC110 successful channels/guide results cannot be discarded by a UI-frame timeout.
- vBRDC105 focus preview stays 3s dwell -> 15s muted preview -> stop, one-shot/no hunting.
- vBRDC108 provider/Gracenote logo and generic text fallback remain mutually exclusive.

## Locked donor files in vBRDC118

The following are byte-identical to vBRDC117:

- `Sources/UnityCatalogVisualSystem.swift`
- `Sources/UnityFrameRuntime.swift`
- `Sources/UnityAnimationCoordinator.swift`
- `Sources/CatalogStore.swift`
- `Sources/MediaFlowProxyRouter.swift`
