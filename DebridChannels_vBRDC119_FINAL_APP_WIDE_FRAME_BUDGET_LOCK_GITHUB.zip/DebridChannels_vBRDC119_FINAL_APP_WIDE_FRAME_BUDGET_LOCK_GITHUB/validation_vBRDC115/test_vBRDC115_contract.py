from pathlib import Path
import plistlib, re
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
ROUTER=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
with open(ROOT/'Sources/Info.plist','rb') as f: AP=plistlib.load(f)
with open(ROOT/'TopShelfExtension/Info.plist','rb') as f: TP=plistlib.load(f)
checks=[]
def ck(name, ok):
    checks.append((name,bool(ok)))
    if not ok: print('FAIL',name)

# release metadata
ck('app release', AP.get('DebridChannelsReleaseID')=='vBRDC115')
ck('top release', TP.get('DebridChannelsReleaseID')=='vBRDC115')
ck('app marketing', AP.get('CFBundleShortVersionString')=='1.0.818')
ck('top marketing', TP.get('CFBundleShortVersionString')=='1.0.818')
ck('app build', str(AP.get('CFBundleVersion'))=='818')
ck('top build', str(TP.get('CFBundleVersion'))=='818')
ck('project marketing', PROJECT.count('MARKETING_VERSION: 1.0.818')==2)
ck('project build', PROJECT.count('CURRENT_PROJECT_VERSION: 818')==2)

# MediaFlow routing architecture
ck('bootstrap helper exists', 'liveTVBootstrapRequestsIfAllowed' in ROUTER)
ck('bootstrap uses stream relay', '"/proxy/stream"' in ROUTER)
ck('bootstrap uses epg relay', '"/proxy/epg"' in ROUTER)
ck('epg compatibility fallback ordering', 'epg ? ["/proxy/epg", "/proxy/stream"] : ["/proxy/stream"]' in ROUTER)
ck('direct mode preserved', 'guard shouldProxy(kind: .liveTV, snapshot: config) else { return [original] }' in ROUTER)
ck('mediaflow invalid config fails closed', 'configurationError(kind: .liveTV, snapshot: config) == nil' in ROUTER)
ck('already wrapped preserved', 'isAlreadyWrappedByConfiguredProxy(destination, baseURL: baseURL)' in ROUTER)
ck('bootstrap GET HEAD only', 'method == "GET" || method == "HEAD"' in ROUTER)
ck('upstream headers encoded', 'headers: original.allHTTPHeaderFields ?? [:]' in ROUTER)
ck('proxy epg recognized wrapped', 'path.contains("/proxy/epg")' in ROUTER)
ck('proxy forward recognized wrapped', 'path.contains("/proxy/forward")' in ROUTER)

# fetchText wiring
ck('fetchText uses new helper', 'liveTVBootstrapRequestsIfAllowed(request, epg: isEPGRequest)' in APP)
ck('fetchText no v114 forward-only call', 'forwardRequestIfAllowed(request, kind: .liveTV)' not in APP)
ck('epg detection by xml accept', 'lowerAccept.contains("xml")' in APP)
ck('epg detection by xmltv url', 'lowerURLString.contains("xmltv")' in APP)
ck('epg detection guide xmltv', 'lowerURLString.contains("/guide/xmltv")' in APP)
ck('route fallback loop', 'for networkRequest in networkRequests' in APP)
ck('4xx advances fallback route', 'if plain.statusCode < 500 { shouldTryNextRoute = true; break }' in APP)
ck('https 4xx advances fallback route', 'if http.statusCode < 500 { shouldTryNextRoute = true; break }' in APP)
ck('transient retry preserved', 'for attempt in 0..<2' in APP)
ck('retry delay preserved', '550_000_000' in APP)

# final playback is still dedicated liveTV wrapper; do not store proxy URL in model
ck('final live playback wrapper preserved', 'playbackURLIfAllowed(for: originalURL, kind: .liveTV)' in APP)
ck('grid preview live wrapper preserved', 'playbackURLIfAllowed(for: originalStreamURL, kind: .liveTV)' in APP)

# previous critical invariants still present
ck('durable live tv publish rule present', 'waitUntilPermitted' in APP and 'Live TV' in APP)
ck('bluetooth vod control setting preserved', 'bluetoothVODPlayPauseToggle' in APP)
ck('focused preview setting preserved', 'focusedCardPreviews' in APP)
ck('live grid focus preview preserved', 'liveGridFocusPreviewToggle' in APP)
ck('dynamic wallpaper preserved', 'dynamicWallpaperToggle' in APP)

passed=sum(ok for _,ok in checks)
print(f'{passed}/{len(checks)} PASS')
raise SystemExit(0 if passed==len(checks) else 1)
