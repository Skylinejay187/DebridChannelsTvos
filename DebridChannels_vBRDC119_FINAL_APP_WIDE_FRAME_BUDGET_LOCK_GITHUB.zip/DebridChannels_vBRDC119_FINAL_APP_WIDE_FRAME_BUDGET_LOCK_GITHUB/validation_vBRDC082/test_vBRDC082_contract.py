from pathlib import Path
import plistlib, sys, yaml
root=Path(__file__).resolve().parents[1]
project=yaml.safe_load((root/'project.yml').read_text())
entries=project['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(root/rel,'rb') as f: return plistlib.load(f)
app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
coord=root/'Sources/UnitySurfaceLifecycleCoordinator.swift'
ck('release id', app.get('DebridChannelsReleaseID')=='vBRDC082' and top.get('DebridChannelsReleaseID')=='vBRDC082')
ck('marketing version', app.get('CFBundleShortVersionString')=='1.0.785' and top.get('CFBundleShortVersionString')=='1.0.785')
ck('build version', app.get('CFBundleVersion')=='785' and top.get('CFBundleVersion')=='785')
ck('coordinator source exists', coord.is_file())
ck('coordinator declares expected type', 'final class UnitySurfaceLifecycleCoordinator' in coord.read_text())
ck('coordinator explicitly compiled by app target', 'Sources/UnitySurfaceLifecycleCoordinator.swift' in paths)
all_swift={str(p.relative_to(root)) for p in (root/'Sources').rglob('*.swift')}
ck('every app Swift source is in XcodeGen target', all_swift.issubset(paths))
ck('no app target Swift path is missing', all((root/p).exists() for p in paths if str(p).endswith('.swift')))
ck('project marketing version', project['settings']['base']['MARKETING_VERSION']=='1.0.785')
ck('project build version', str(project['settings']['base']['CURRENT_PROJECT_VERSION'])=='785')
ck('topshelf project marketing', project['targets']['DebridChannelsTopShelf']['settings']['base']['MARKETING_VERSION']=='1.0.785')
ck('topshelf project build', str(project['targets']['DebridChannelsTopShelf']['settings']['base']['CURRENT_PROJECT_VERSION'])=='785')
failed=[n for n,c in checks if not c]
for n,c in checks: print(('PASS' if c else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
