# vBRDC118 — PEAK SMOOTH FRAME PIPELINE

**Marketing version:** 1.0.821  
**Apple build:** 821  
**Built only from:** packaged vBRDC117

## Purpose

This build is an app-wide frame-budget optimization pass that preserves the current visual design and animation system. It does **not** remove catalog motions, pulse, Dynamic Wallpaper, hero themes, glow, Live TV, VOD overlays, or any accepted transition behavior.

The main remaining performance issue was not the number of animations by itself. Full-screen 4K artwork could begin network + ImageIO decode work for each fly-by focus item while the Siri Remote focus spring was still moving. vBRDC090/v102 already prevented many decoded results from *publishing* on navigation frames, but the expensive request/decode work could still start and consume CPU, memory bandwidth, URLSession scheduling, and texture/decode resources during the motion.

## Peak-smooth frame pipeline

`RemoteImageFit` now has an opt-in heavyweight path: `deferHeavyLoadDuringNavigation`.

For large decorative 4K surfaces only:

1. An exact decoded cache hit remains immediate.
2. A cache miss yields one MainActor turn so focus ownership can register even when the URL change and D-pad event land in the same render turn.
3. If navigation owns the frame, the 4K network/decode job waits on `UnityFrameRuntime`'s `.criticalArtwork` lane.
4. Repeated focus moves cancel/replace the pending request, so fly-by cards do not each start a 4K job.
5. Once focus geometry settles, only the final requested backdrop begins its normal existing load/decode path.
6. The existing shared in-flight image-key deduplication remains in place after a load begins.

The opt-in is applied to exactly four high-cost decorative surfaces:

- Main catalog 4K backdrop
- Catalog hero/depth 4K backdrop
- Sports UNITY 4K backdrop
- Global Favorites 4K backdrop

The focused catalog card (1280 px) and hero logo (1280 px) remain immediate. No animation duration, scale, spring, blur, theme, crop, or 4K decode target was reduced.

## Episode Alert polish

The passive Episode Alert banner is now substantially smaller and sits directly against the selected screen edge with only an 18 pt overscan/clipping safety inset.

- Banner: 650×224 -> **530×176**
- Poster: 104×156 -> **80×120**
- Typography/spacings/shadows scaled down proportionally
- Root UI and VOD playback use the same 18 pt edge contract
- The banner poster now uses the app's bounded `RemoteImageFit` cache/decode pipeline at 512 px instead of a separate `AsyncImage` loader
- The interactive Episode Alert popup is intentionally unchanged

## Regression locks retained

- vBRDC117 standard VOD Bluetooth/Now Playing controls
- vBRDC116 35-second focused catalog preview cap; no preview loop
- vBRDC115 MediaFlow LAN Live TV `/proxy/stream` + `/proxy/epg` routing
- vBRDC110 durable Live TV/Gracenote publication
- vBRDC109 single-owner catalog surface open/close transition
- vBRDC108 exclusive real-logo/fallback behavior
- vBRDC106 visible-only VOD Cast/Production rotation
- vBRDC105 Live TV 3s dwell / 15s muted preview
- vBRDC103 persistent catalog scrolling engine and all row visual motions

## Source scope

Exactly five existing vBRDC117 donor files changed:

1. `Sources/RemoteImageFit.swift`
2. `Sources/DebridChannelsTVOSApp.swift`
3. `Sources/Info.plist`
4. `TopShelfExtension/Info.plist`
5. `project.yml`

Core animation/runtime/provider files including `UnityCatalogVisualSystem.swift`, `UnityFrameRuntime.swift`, `UnityAnimationCoordinator.swift`, `CatalogStore.swift`, and `MediaFlowProxyRouter.swift` remain byte-identical to vBRDC117.

## Validation

- vBRDC118 contract: 36/36
- Swift parse: 64/64 production source files
- Swift parse: 74/74 total Swift files/fixtures
- Backend regression: 36/36 tests
- Version metadata: 1.0.821 / 821 / vBRDC118
- Package ZIP integrity: performed after packaging

GitHub Actions/Xcode remains the authoritative tvOS Release compile and physical Apple TV remains the authoritative frame-pacing test.
