# Debrid Channels vBRDC096 — Live Artwork Cross-Surface Persistence

Release: vBRDC096  
Marketing version: 1.0.799  
Apple build: 799  
Donor: packaged vBRDC095

## Physical issue reproduced from 38397.mp4
After Live TV displayed real Gracenote/current-program artwork, entering Settings destroyed the shared LiveTVScreen branch. Returning directly to Home/Movies/Shows mounted a new LiveTVScreen underneath the catalog while Live-TV artwork requests were intentionally suspended, so generic channel cards appeared until Live TV was re-entered and artwork reloaded.

## Fix
- The single physical `LiveTVScreen` is now mounted for every non-playback app surface, not only Live/Home/Movies/Shows/Sports.
- Settings, Favorites and Membership cover the same retained Live TV root instead of replacing it.
- The root remains non-interactive outside Live TV.
- Outside Live TV, refresh, force-refresh, EPG boundary work and artwork prefetch remain cancelled.
- Covered Live TV remains compacted to 24 cards; interactive Live TV still expands to 96 cards.
- Tile-owned decoded Gracenote/channel artwork remains mounted and `suspendPreservingImage()` still stops request work without clearing the visible bitmap.
- LiveTVScreen `onAppear` no longer changes `selectedTab`; Settings/Favorites/Membership are valid owners above the persistent root.

## Regression locks retained
- Gracenote → channel icon → provider poster fallback.
- Single UNITY catalog transition shell for all themes.
- Slow opacity-only Pulse Glow.
- Media Information focus-anchor handoff.
- Row-motion frame budgets.
- Connected Popup 2048 artwork prewarm.
- Dynamic Wallpaper phase preservation.
- Sports/Favorites decoded-artwork cache isolation.
- Provider/playback/resume/source-intelligence donor files unchanged.

GitHub Actions/Xcode remains the authoritative Apple SDK compile. Physical Apple TV remains authoritative for compositor/frame pacing.
