from pathlib import Path
import plistlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
VIS=(ROOT/'Sources/UnityCatalogVisualSystem.swift').read_text()
FRAME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
UNITY=(ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(n,c): checks.append((n,bool(c)))
def section(t,a,b):
    i=t.find(a)
    if i<0:return ''
    j=t.find(b,i+len(a))
    return t[i:] if j<0 else t[i:j]
def pl(p):
    with open(ROOT/p,'rb') as f:return plistlib.load(f)
apppl=pl('Sources/Info.plist'); toppl=pl('TopShelfExtension/Info.plist')
ck('release id',apppl.get('DebridChannelsReleaseID')=='vBRDC104' and toppl.get('DebridChannelsReleaseID')=='vBRDC104')
ck('marketing',apppl.get('CFBundleShortVersionString')=='1.0.807' and toppl.get('CFBundleShortVersionString')=='1.0.807')
ck('build',apppl.get('CFBundleVersion')=='807' and toppl.get('CFBundleVersion')=='807')
ck('project versions',PROJECT.count('MARKETING_VERSION: 1.0.807')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 807')==2)

# Physical catalog renderer: persistent structural slots, not media-identity remounts.
rail=section(APP,'struct GridOSFixedSlotCatalogRail: View','struct StremioAddonSourceBadge: View')
focused=section(APP,'struct FixedSlotFocusedCatalogCard: View','struct FixedSlotPreviewCatalogCard: View')
preview=section(APP,'struct FixedSlotPreviewCatalogCard: View','struct MovieInfoComicBubbleShape: Shape')
cat=section(APP,'struct GridOSCatalogOverlay: View','private func isFavoriteMovieOrShow')
ck('persistent motion phase', '@State private var persistentRailMotionPhase: CGFloat = 1' in rail)
ck('persistent motion generation', '@State private var persistentRailMotionGeneration: UInt64 = 0' in rail)
ck('fixed preview slots', 'private var previewSlotCount: Int' in rail and 'private func previewItem(at depth: Int)' in rail)
ck('no preview array materialization', 'private var previewItems: [MediaItem]' not in rail and 'Array(row.items[firstPreviewIndex..<endIndex])' not in rail)
ck('slot keyed previews', 'ForEach(0..<previewSlotCount, id: \\.self)' in rail)
ck('focused card no media identity remount', '.id(selectedItem.id)' not in rail)
ck('row animation no child transition churn', 'UnityCatalogRowMotionStyle.transition(' not in rail)
ck('no selectedIndex implicit subtree animation', 'value: selectedIndex' not in rail)
ck('persistent motion modifier installed', 'UnityCatalogPersistentRailMotionModifier(' in rail)
ck('single horizontal commit path', rail.count('commitPersistentHorizontalMove(')>=3)
ck('focused artwork owner stable', 'focused-card-art-' not in focused and 'preservePreviousOnURLChange: true' in focused)
ck('focused logo owner stable', 'focused-card-logo-' not in focused)
ck('preview artwork owner stable', 'preview-card-art-' not in preview and 'preservePreviousOnURLChange: true' in preview)
ck('catalog row pager id removed', 'row-pager-' not in cat)
ck('catalog parent move handler removed', 'handleQuickPanelMove(direction)' not in section(APP,'private func catalogOverlayContent','private var catalogArtworkBaseLayer'))
ck('row focus triple delay removed', 'let delays: [UInt64] = [0, 55_000_000, 150_000_000]' not in cat)
ck('row entry one yield', 'await Task.yield()' in section(cat,'private func scheduleFirstCardRowEntryFocus','private func scheduleQuickPanelFocusRestore'))

# Existing 48 visual choices are retained; helper reuses exact style insertion transforms.
ck('48 motion preset names retained', len(re.findall(r'^\s*"[^"]+",?$', section(VIS,'static let names = [',']'), re.M))==48)
ck('persistent visual transform type', 'struct UnityCatalogPersistentMotionTransform' in VIS)
ck('persistent compositor modifier', 'struct UnityCatalogPersistentRailMotionModifier: ViewModifier' in VIS)
helper=section(VIS,'static func persistentArrivalTransform','static func transition')
ck('46 named insertion transforms mapped', helper.count('return UnityCatalogPersistentMotionTransform(')>=47)
ck('instant remains identity', 'case "instant":\n            return .identity' in helper)
ck('old transition API retained', 'static func transition(for name: String, direction: Int) -> AnyTransition' in VIS)
ck('old animation API retained', 'static func animation(for name: String) -> Animation?' in VIS)

# Hero/theme artwork keeps one decoded owner across focus changes.
main=section(APP,'private func mainArtworkBackground','private var mainArtworkSideGradient')
depth=section(APP,'private func artworkDepthLayers','private func catalogHeroRuntimeLabel')
hero=section(APP,'private func artworkHeroLogo','private func catalogQuickPanel')
ck('main art stable owner', 'catalog-main-' not in main and 'preservePreviousOnURLChange: true' in main and 'maxPixelSize: 3840' in main)
ck('depth art stable owner', 'artwork-depth-' not in depth and 'preservePreviousOnURLChange: true' in depth)
ck('hero logo stable owner', 'artwork-hero-logo-' not in hero)
ck('hero content tree stable', 'catalog-hero-content-' not in hero)

# v102 over-invalidation removed: only leaf views observe the animation coordinator.
rootsec=section(APP,'struct RootView: View','struct EpisodeAlertPosterImage: View')
top=section(APP,'struct TopMenuBar: View','struct GlobalSearchScreen: View')
search=section(APP,'struct GlobalSearchScreen: View','// MARK: - v220 Grid Overlay Catalog Shelves')
live=section(APP,'struct LiveTVScreen: View','struct SportsHubScreen: View')
ck('Root no coordinator subscription', '@ObservedObject private var unityAnimations' not in rootsec and 'private let unityAnimations = UnityAnimationCoordinator.shared' in rootsec)
ck('Top Menu no coordinator subscription', '@ObservedObject private var unityAnimations' not in top and 'private let unityAnimations = UnityAnimationCoordinator.shared' in top)
ck('Search no coordinator subscription', '@ObservedObject private var unityAnimations' not in search and 'private let unityAnimations = UnityAnimationCoordinator.shared' in search)
ck('Catalog overlay no coordinator subscription', '@ObservedObject private var unityAnimations' not in cat and 'private let unityAnimations = UnityAnimationCoordinator.shared' in cat)
ck('Catalog rail no coordinator subscription', '@ObservedObject private var unityAnimations' not in rail and 'private let unityAnimations = UnityAnimationCoordinator.shared' in rail)
ck('Live grid no coordinator subscription', '@ObservedObject private var unityAnimations' not in live and 'private let unityAnimations = UnityAnimationCoordinator.shared' in live)
ck('wallpaper observer isolated leaf', 'private struct LiveTVUnityDynamicWallpaperSurface: View' in APP and '@ObservedObject private var unityAnimations = UnityAnimationCoordinator.shared' in section(APP,'private struct LiveTVUnityDynamicWallpaperSurface','struct LiveTVScreen: View'))
ck('wallpaper still pauses for navigation', 'paused: !unityAnimations.allows(.dynamicWallpaper)' in section(APP,'private struct LiveTVUnityDynamicWallpaperSurface','struct LiveTVScreen: View'))
ck('preview no overlay-wide permit onChange', 'unityFocusedPreviewAllowed' not in cat)

# Live TV / Gracenote physical movement: native focus is sole interactive scroller.
livegrid=section(APP,'private func liveGrid(size: CGSize)','private func performLiveTVRestoreScroll')
restore=section(APP,'private func performLiveTVRestoreScroll','private func scheduleLiveTVScheduleBoundaryRefresh')
guide=section(APP,'private func guideView(size: CGSize)','private func googleGuideHero')
ck('Live tile focus no proxy scroll', 'withAnimation(.easeOut(duration: 0.10))' not in livegrid and 'proxy.scrollTo(value, anchor: .center)' not in livegrid)
ck('Live explicit playback restore preserved', restore.count('proxy.scrollTo(targetID, anchor: .center)')>=2)
ck('guide no focus proxy animation', 'ScrollViewReader' not in guide and 'proxy.scrollTo(value, anchor: .center)' not in guide)
ck('Gracenote publication gate retained', 'waitUntilPermitted(.liveSchedule' in APP and 'waitUntilPermitted(.interactiveMetadata' in APP)

# Favorites and Sports use same persistent artwork/rail contract.
favs=section(APP,'struct GlobalFavoritesScreen: View','struct MoviesShowsReleaseTickerCard: View')
sports=section(APP,'struct SportsFoundationQuickPanelSurface: View','struct StringBackedSportsEvent')
ck('Favorites backdrop retains frame', 'preservePreviousOnURLChange: true' in favs and '.id(artworkURL)' not in favs)
ck('Favorites uses persistent rail', 'GridOSFixedSlotCatalogRail(' in favs)
ck('Sports row remount removed', 'sports-foundation-row-' not in sports)
ck('Sports backdrop remount removed', 'sports-unity-backdrop-' not in sports and 'preservePreviousOnURLChange: true' in sports)
ck('Sports uses persistent rail', 'GridOSFixedSlotCatalogRail(' in sports)
ck('Sports navigation ownership', 'source: "sports"' in sports and 'settleAfter: 0.22' in sports)

# Playback chrome: keep explicit restore scrolls, remove every-focus competing scrolls.
vodchips=section(APP,'private var vodControlChipScroller','private var vodControlDrawerHandle')
panel=section(APP,'struct DebridPlayerPanel<Content: View>: View','struct PanelOptionChip: View')
ck('VOD chip initial restore retained', 'proxy.scrollTo(target, anchor: .center)' in vodchips)
ck('VOD chip focus-change scroll removed', '.onChange(of: focusedControl)' not in vodchips)
ck('player panel initial restore retained', '.onAppear' in panel and 'proxy.scrollTo(focusedOption, anchor: .center)' in panel)
ck('player panel focus-change scroll removed', '.onChange(of: focusedOption)' not in panel)

# Shared runtime and provider gating from v102 remain present.
for lane in ['navigationGeometry','transitionGeometry','criticalArtwork','interactiveMetadata','liveSchedule','backgroundPrefetch','persistence','ambientMotion','recovery']:
    ck('runtime lane '+lane, f'case {lane}' in FRAME)
ck('animation facade still uses runtime', 'private let frameRuntime = UnityFrameRuntime.shared' in UNITY)
ck('catalog model publication gating retained', 'waitUntilPermitted(.interactiveMetadata' in APP)
ck('background prefetch gating retained', 'waitUntilPermitted(.backgroundPrefetch' in APP)
ck('persistence gating retained', 'waitUntilPermitted(.persistence' in APP)

# Previous continuity fixes retained.
cast=section(APP,'struct V1111FeaturedCastPosterCard: View','private struct V1106ProductionFact')
prod=section(APP,'private struct V1111ProductionArtworkHeader: View','struct V1104ReviewScoresCluster')
ck('cast retained frames', cast.count('preservePreviousOnURLChange: true')>=2)
ck('cast cadence retained', 'Task.sleep(nanoseconds: 7_000_000_000)' in cast)
ck('production retained frame', 'preservePreviousOnURLChange: true' in prod)
ck('production cadence retained', 'Timer.publish(every: 7.0' in prod)


# vBRDC104 persistent catalog-surface handoff: the surface shell itself no longer mounts/unmounts per Live TV round-trip.
rootbranch=section(APP,'if membershipLocked && store.selectedTab != .membership','// v535: keep the top menu visible/reachable on Sports')
focusrestore=section(APP,'private func scheduleQuickPanelFocusRestore','@discardableResult\n    private func restoreQuickPanelFocusIfPossible')
ck('persistent catalog tab state', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)
ck('persistent catalog render identity', 'private var unityCatalogRenderTab: AppTab' in APP)
ck('catalog overlay no conditional mount', 'if let catalogPresentationTab {' not in rootbranch and 'GridOSCatalogOverlay(filter: catalogRenderTab' in rootbranch)
ck('catalog overlay remains compositor hidden', 'let catalogSurfacePresented = catalogPresentationTab != nil' in rootbranch and '.opacity(progress)' in rootbranch)
ck('full-surface scale removed', '.scaleEffect(0.996 + (0.004 * progress)' not in rootbranch)
ck('catalog handoff travel reduced', '.offset(y: (1 - progress) * 18)' in rootbranch)
ck('hidden shell cancels preview work', 'Hidden persistent catalog pixels are retained, but decoder/network work is not.' in cat and 'stopFocusedCardPreview()' in cat)
ck('ordinary focus restore single bind', 'let needsRecoveryRetries' in focusrestore and 'needsRecoveryRetries ? [0, 80_000_000, 220_000_000] : [0]' in focusrestore)
ck('entry transition compositor duration', 'visibleDuration: 0.22' in FRAME and 'branchSettle: 0.23' in FRAME)
ck('exit transition compositor duration', 'visibleDuration: 0.20' in FRAME and 'branchSettle: 0.21' in FRAME)

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
