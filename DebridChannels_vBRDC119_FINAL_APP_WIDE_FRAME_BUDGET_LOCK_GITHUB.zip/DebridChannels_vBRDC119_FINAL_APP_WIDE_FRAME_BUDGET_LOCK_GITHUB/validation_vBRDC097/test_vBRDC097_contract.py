from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
CATALOG = (ROOT/'Sources/CatalogStore.swift').read_text()
NUVIO = (ROOT/'Sources/NuvioPluginClient.swift').read_text()
FEBBOX = (ROOT/'Sources/BackupStreamingClient.swift').read_text()
SYSTEM = (ROOT/'Sources/UnitySurfaceSystem.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
PROJECT = yaml.safe_load((ROOT/'project.yml').read_text())
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release id vBRDC097', app.get('DebridChannelsReleaseID')=='vBRDC097' and top.get('DebridChannelsReleaseID')=='vBRDC097')
ck('marketing 1.0.800', app.get('CFBundleShortVersionString')=='1.0.800' and top.get('CFBundleShortVersionString')=='1.0.800')
ck('build 800', app.get('CFBundleVersion')=='800' and top.get('CFBundleVersion')=='800')
ck('project marketing 1.0.800', PROJECT['settings']['base']['MARKETING_VERSION']=='1.0.800')
ck('project build 800', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION'])=='800')

# vBRDC093-v096 persistent UNITY architecture must not regress.
root=section(APP,'struct RootView: View','struct NewEpisodeAlertBannerView')
root_body=section(root,'var body: some View','// v535: keep the top menu visible')
ck('exactly one physical LiveTVScreen mount', len(re.findall(r'\bLiveTVScreen\(\)', APP)) == 1)
ck('synthetic FrozenLiveTVBackdrop remains removed', 'FrozenLiveTVBackdrop()' not in APP and 'private struct FrozenLiveTVBackdrop' not in APP)
ck('persistent live root precedes Settings Favorites Sports catalog', all(root_body.find('LiveTVScreen()') < root_body.find(marker) for marker in ['SettingsScreen(', 'GlobalFavoritesScreen()', 'SportsHubScreen()', 'GridOSCatalogOverlay(']))
ck('live root interaction remains Live-only', 'let liveRootInteractive = store.selectedTab == .live' in root_body)
ck('catalog natural UNITY transition remains', all(x in root_body for x in ['.opacity(progress)', '.offset(y: (1 - progress) * 34)', '.scaleEffect(0.996 + (0.004 * progress)']))
ck('all catalog themes share one overlay root', root.count('GridOSCatalogOverlay(') == 1)
ck('UNITY system rejects synthetic donor roots', all(x in SYSTEM for x in ['exact same LiveTVScreen instance','synthetic donor']))

live_model=section(APP,'final class LiveTVSourceModel: ObservableObject','struct LiveTVScreen: View')
live=section(APP,'struct LiveTVScreen: View','struct LiveTVSelectHoldMonitor')
loader=section(APP,'private final class LiveTVBoundedArtworkLoader','private struct LiveTVQuickGuideContainedArtworkFrame')
art=section(APP,'private struct LiveTVGridTileArtwork','private struct LiveTVGridTileFooter')
appear=section(live,'.onAppear {','            .onChange(of: store.guideStartupRequestToken)')
selected_tab=section(live,'.onChange(of: store.selectedTab) { tab in','.onChange(of: store.liveTVFocusRestoreToken)')

# New Gracenote cold-start readiness contract.
ck('cold-start hydration state exists', '@State private var liveTVColdStartHydrationTask' in live)
ck('artwork refresh generation state exists', '@State private var liveTVArtworkRefreshToken' in live)
ck('Live onAppear schedules one-shot guide hydration', 'scheduleLiveTVColdStartHydrationIfNeeded()' in appear)
ck('cold-start guide hydration requires configured real source', 'var needsColdStartGuideHydration: Bool' in live_model and 'demo-only installs never perform hidden network work' in live_model)
cold=section(live,'private func scheduleLiveTVColdStartHydrationIfNeeded()','private func startLiveTVRefreshIfActive')
ck('cold hydration is delayed one-shot not recurring', '900_000_000' in cold and 'await liveModel.refreshIfNeeded()' in cold and 'liveTVColdStartHydrationTask == nil' in cold)
ck('cold hydration only runs while Live is covered', 'store.selectedTab != .live' in cold)
ck('entering Live cancels hidden cold hydration', 'liveTVColdStartHydrationTask?.cancel()' in selected_tab)
active_refresh=section(live,'private func startLiveTVRefreshIfActive','private var liveWallpaperOwnsRenderBudget')
ck('active guide refresh wakes mounted artwork cards', 'liveTVArtworkRefreshToken &+= 1' in active_refresh)
ck('active guide refresh immediately prefetches artwork', 'scheduleLiveTVArtworkPrefetch(immediate: true)' in active_refresh)
ck('artwork token reaches each tile', 'artworkRefreshToken: liveTVArtworkRefreshToken' in live and 'let artworkRefreshToken: Int' in APP and 'refreshToken: artworkRefreshToken' in APP)
ck('mounted tile reacts to authoritative refresh token', '.onChange(of: refreshToken)' in art and 'resetFailedURLsForAuthoritativeRefresh()' in art and 'synchronizeArtworkRequest()' in section(art,'.onChange(of: refreshToken)','        .onChange(of: artworkLoader.imageURL)'))
ck('artwork failure reset exists so scrolling is not required', 'func resetFailedURLsForAuthoritativeRefresh()' in loader and 'failedURLs.removeAll()' in section(loader,'func resetFailedURLsForAuthoritativeRefresh()','func suspendPreservingImage()'))
ck('Live artwork networking waits for connectivity', 'configuration.waitsForConnectivity = true' in section(loader,'private static let imageSession','private static var prefetchTasks'))
ck('Live artwork gets bounded transient retry', '650_000_000' in loader and 'a cold tvOS launch' in loader)
ck('Live guide provider networking waits for connectivity', 'private static let providerSession' in live_model and 'configuration.waitsForConnectivity = true' in section(live_model,'private static let providerSession','private let guideCacheManager'))
fetchtext=section(APP,'    private func fetchText(_ urlString: String, accept: String = "*/*", maxBytes: Int = 4 * 1024 * 1024, timeout: TimeInterval = 45) async -> String? {','    private func attr(_ meta: String, _ key: String) -> String {')
ck('Live guide fetch no longer uses URLSession.shared', 'URLSession.shared.data(for:' not in fetchtext and 'Self.providerSession.data(for: request)' in fetchtext)
ck('Live guide fetch has bounded transient retry', 'for attempt in 0..<2' in fetchtext and '550_000_000' in fetchtext)
ck('covered cards still preserve exact bitmap', 'artworkLoader.suspendPreservingImage()' in art and 'preserveCurrentImage: true' in art)
ck('fallback order still Gracenote channel icon provider', art.find('program?.imageURL') < art.find('channel.iconURL') < art.find('providerChannelPosterURL'))
ck('covered root still compacts to 24', 'coveredRenderedChannelLimit: Int = 24' in live and 'renderedChannelLimit = coveredRenderedChannelLimit' in selected_tab)
ck('interactive Live root still expands to 96', 'interactiveRenderedChannelLimit: Int = 96' in live and 'renderedChannelLimit = interactiveRenderedChannelLimit' in selected_tab)

# Find Links first-install connection readiness contract.
ck('source intelligence session waits for connectivity', 'configuration.waitsForConnectivity = true' in section(CATALOG,'private static func makeSourceIntelligenceURLSession','private func rotateSourceIntelligenceURLSession'))
ck('source intelligence session has controlled host concurrency', 'configuration.httpMaximumConnectionsPerHost = 6' in section(CATALOG,'private static func makeSourceIntelligenceURLSession','private func rotateSourceIntelligenceURLSession'))
ck('startup source recovery state exists', 'sourceSearchHasSucceededThisSession' in CATALOG and 'sourceStartupRecoveryUsed' in CATALOG)
findstreams=section(CATALOG,'func findStreams(for item: MediaItem, providerFilter: String? = nil, allowStartupConnectionRecovery: Bool = true)','private func')
ck('findStreams startup retry is explicitly bounded', 'allowStartupConnectionRecovery: Bool = true' in CATALOG and 'allowStartupConnectionRecovery: false' in findstreams)
ck('startup retry requires actual configured/attempted lane', 'let hadConfiguredSourceLane = attempts > 0' in findstreams and 'hadConfiguredSourceLane,' in findstreams)
ck('startup retry rotates URLSession before retrying', 'rotateSourceIntelligenceURLSession()' in findstreams and '850_000_000' in findstreams)
ck('startup retry stops after first successful process search', 'sourceSearchHasSucceededThisSession = true' in findstreams and '!sourceSearchHasSucceededThisSession' in findstreams)
ck('TMDB IMDb identity lookup uses source readiness session', 'sourceIntelligenceURLSession.data(for: request)' in section(CATALOG,'private func tmdbTargetForCredits','private func tmdbTargetByTitleYear'))
ck('TMDB title identity lookup uses source readiness session', 'sourceIntelligenceURLSession.data(for: request)' in section(CATALOG,'private func tmdbTargetByTitleYear','// v1154: Sports uses'))
ck('In-S POST session waits for connectivity', 'configuration.waitsForConnectivity = true' in NUVIO)
ck('In-S POST session limits host fanout', 'configuration.httpMaximumConnectionsPerHost = 4' in NUVIO)
ck('FebBox backend bridge waits for connectivity', 'configuration.waitsForConnectivity = true' in FEBBOX)
ck('FebBox backend bridge limits host fanout', 'configuration.httpMaximumConnectionsPerHost = 4' in FEBBOX)

# Preserve recent motion/UNITY behavior the user already approved.
card=section(APP,'struct FixedSlotFocusedCatalogCard','struct FixedSlotPreviewCatalogCard')
rail=section(APP,'struct GridOSFixedSlotCatalogRail','private struct SearchMenuIconFramePreferenceKey')
ck('Pulse Glow setting remains', 'Focused Card Pulse Glow Animation' in APP)
ck('Pulse Glow remains slow', '.easeInOut(duration: 2.85).repeatForever(autoreverses: true)' in card)
pulse=section(card,'if focused && coordinatedPulseEnabled','            }\n            .allowsHitTesting(false)')
ck('Pulse Glow remains geometry-free', '.scaleEffect' not in pulse and '.offset' not in pulse and '.frame' not in pulse)
ck('detail anchor remains pinned through Back handoff', 'store.selectedDetail ?? store.detailPresentationAnchorItem' in rail)
ck('focus arrival remains blocked during detail handoff', 'store.detailPresentationAnchorItem == nil' in section(card,'private func replaySearchStyleFocusArrival','private func startSearchStyleFocusArrivalSpring'))
ck('row preset frame budget remains', 'frameBudgetSettleDuration(for: catalogRowScrollingAnimationPreset)' in APP)
ck('connected popup 2048 prewarm remains', 'maxPixelSize: 2048' in APP and 'scheduleConnectedArtworkPrewarm' in APP)
ck('dynamic wallpaper phase preservation remains', 'paused: wallpaperMotionPausedForNavigation' in APP)
ck('post-navigation visual recovery remains', 'postNavigationVisualRecoveryActive' in UNITY)
ck('Favorites cache isolation remains', '.environment(\\.premiumArtworkCacheDomain, .favorites)' in APP)
ck('Sports cache isolation remains', '.environment(\\.premiumArtworkCacheDomain, .sports)' in APP)

# Donor locks: these subsystems must remain byte-identical to vBRDC096.
DONOR={
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
'Sources/UnityAnimationCoordinator.swift':'1421465139b242144f6961dbf19630e2c2371f2a386c3dec267a2e08d23d04b9',
'Sources/UnitySurfaceLifecycleCoordinator.swift':'091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
'Sources/RemoteImageFit.swift':'093c1c108270e746e463c6ff72b018af4eb62e19afaeaa894947fe38f3518f0f',
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/SportsScoresScheduleProvider.swift':'db0b16cf928d363275454e74c7db2dcffdc98ff52f7df58188eb22cb435279af',
'BackendBackupStreamingRuntime/backup_streaming_runtime.py':'f3199068ae891b0f1310b61aefbc3989d73a0da20ae302288c1b5de39459d21f',
'BackendBackupStreamingRuntime/test_backup_streaming_runtime.py':'340977e669f5bfc2b95c7f609131541d28e4dc0c4dd2cabb3382a1220545bf6c',
}
for rel,expected in DONOR.items(): ck('donor lock '+rel, sha(rel)==expected)

entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('every app Swift source declared in project', all_swift.issubset(paths))

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
