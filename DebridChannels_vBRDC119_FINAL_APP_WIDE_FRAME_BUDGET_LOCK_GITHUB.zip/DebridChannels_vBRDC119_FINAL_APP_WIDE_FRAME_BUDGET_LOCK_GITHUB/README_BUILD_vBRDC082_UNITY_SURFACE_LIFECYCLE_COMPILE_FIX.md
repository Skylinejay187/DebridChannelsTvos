# Debrid Channels vBRDC082 — UNITY Surface Lifecycle Compile Fix

**Marketing version:** 1.0.785  
**Apple build:** 785  
**Release ID:** vBRDC082  
**Code Name:** UNITY  
**Donor:** packaged vBRDC081 only

## Root cause

GitHub Actions was authoritative and failed vBRDC081 with:

`Sources/DebridChannelsTVOSApp.swift:677:34: error: cannot find 'UnitySurfaceLifecycleCoordinator' in scope`

The coordinator implementation itself was present at `Sources/UnitySurfaceLifecycleCoordinator.swift`, but vBRDC081's explicit XcodeGen `sources:` list omitted that file. Because the project uses an explicit source list, XcodeGen did not add the coordinator to the DebridChannelsTVOS target even though the Swift file existed in the ZIP.

## vBRDC082 correction

- Adds `Sources/UnitySurfaceLifecycleCoordinator.swift` to the `DebridChannelsTVOS` target in `project.yml` immediately after `UnityAnimationCoordinator.swift`.
- Bumps app and Top Shelf to vBRDC082 / 1.0.785 / build 785.
- Adds a compile-packaging regression contract that verifies:
  - the coordinator file exists;
  - the expected coordinator type is declared;
  - the coordinator path is explicitly present in the XcodeGen app target;
  - every Swift file under `Sources/` is represented in the explicit app target source list;
  - no listed Swift source path is missing.

## Scope lock

This is a compile-only corrective package. No vBRDC081 runtime behavior is changed. `UnitySurfaceLifecycleCoordinator.swift`, `DebridChannelsTVOSApp.swift`, `CatalogStore.swift`, `UnityAnimationCoordinator.swift`, PlaybackKit/KSPlayer, resume handling, Source Intelligence, TorBox code, Dynamic Wallpaper, and backend runtime code remain byte-identical to packaged vBRDC081.

## Expected result

XcodeGen now includes `UnitySurfaceLifecycleCoordinator.swift` in the generated project, so `DebridChannelsTVOSApp.swift` can resolve `UnitySurfaceLifecycleCoordinator.shared` during the real Xcode semantic compile.
