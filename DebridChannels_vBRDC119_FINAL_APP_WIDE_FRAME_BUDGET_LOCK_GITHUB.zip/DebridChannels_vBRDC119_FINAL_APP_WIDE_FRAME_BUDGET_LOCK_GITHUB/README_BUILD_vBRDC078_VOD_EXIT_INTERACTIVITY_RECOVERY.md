# Debrid Channels vBRDC078 — VOD Exit Interactivity Recovery

Release ID: **vBRDC078**  
Marketing version: **1.0.781**  
Apple build: **781**  
Donor: **packaged vBRDC077 only**

## Physical-test regression

After leaving VOD playback, the catalog/main-grid hierarchy could become visible but stop responding to Siri Remote movement until the process was force-closed and relaunched.

## Root cause corrected

The existing v992 ordered-dismissal design tore the player/session down before `playbackURL=nil`, but `VODPlayerScreen.onDisappear` then ran `teardownPlayer()` a second time after the catalog had already begun remounting. That repeated a synchronous resume-cache flush and player/session cleanup during the catalog/focus handoff. At the same time Root immediately resumed optional entitlement/catalog/alert work and attempted focus recovery in the same remount window.

vBRDC078 makes the ownership order explicit:

1. VOD saves the durable resume position and tears down the player/session exactly once while VOD still owns the hierarchy.
2. The dismissal task is cleared before `playbackURL=nil` is published, preventing the disappearing VOD view from cancelling its own close task.
3. The catalog remount starts from neutral loading/focus state.
4. Catalog interactivity/focus is reasserted at multiple bounded checkpoints after remount.
5. Optional MediaFlow refresh, entitlement/catalog bootstrap, episode-alert work, and completeness watchdog resume only after those focus checkpoints.
6. A new playback or scene suspension cancels any outstanding post-playback recovery task.

## Preserved behavior

- vBRDC077 automatic resume **and automatic playback continuation** remain intact.
- vBRDC076 Playback Priority / overlay telemetry throttling remains intact.
- vBRDC075 appearance controls and restored alternate artwork remain intact.
- Resume-cache data format is unchanged.
- KSPlayer seek architecture is unchanged.
- TorBox/backend runtimes are unchanged.
- UNITY and Sports behavior are unchanged.

## Required physical test

Start a movie from Home/Movies/Shows, allow playback to stabilize, press Back until VOD closes, then immediately navigate the returning catalog in all four directions. Repeat several times, including after opening/closing the VOD overlay. The catalog must remain responsive without force-closing the app.
