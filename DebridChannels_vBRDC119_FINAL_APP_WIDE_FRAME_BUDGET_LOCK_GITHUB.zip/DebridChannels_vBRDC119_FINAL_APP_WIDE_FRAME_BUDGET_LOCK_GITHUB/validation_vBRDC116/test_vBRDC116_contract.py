from pathlib import Path
root = Path(__file__).resolve().parents[1]
app = (root / 'Sources/DebridChannelsTVOSApp.swift').read_text()
proj = (root / 'project.yml').read_text()
info = (root / 'Sources/Info.plist').read_text()
top = (root / 'TopShelfExtension/Info.plist').read_text()
checks = [
    ('release id app', 'vBRDC116' in info),
    ('release id top shelf', 'vBRDC116' in top),
    ('marketing version app', '1.0.819' in info),
    ('apple build app', '<string>819</string>' in info),
    ('project marketing version', proj.count('MARKETING_VERSION: 1.0.819') == 2),
    ('project apple build', proj.count('CURRENT_PROJECT_VERSION: 819') == 2),
    ('35 second AVPlayer boundary', 'CMTime(seconds: 35.0, preferredTimescale: 600)' in app),
    ('boundary completion', 'finishCurrentPreview(reason: "35-second cap")' in app),
    ('short asset completion', 'finishCurrentPreview(reason: "asset ended")' in app),
    ('loop removed', 'loopCurrentItem()' not in app),
    ('same identity completion lock', 'focusedCardPreviewCompletedKey' in app),
    ('completion tears down surface', 'focusedCardPreviewCompletedKey = key\n        stopFocusedCardPreview()' in app),
    ('focused preview still muted', 'previewPlayer.isMuted = true' in app),
    ('focused preview 720p cap retained', 'CGSize(width: 1280, height: 720)' in app),
    ('1.5 second focus dwell retained', 'Task.sleep(nanoseconds: 1_500_000_000)' in app),
    ('same title media profile ownership retained', 'store.catalogItemsShareCanonicalIdentity(detail, rowItem)' in app),
    ('manual trailer still explicit ownership stop', '.debridTrailerExclusivePlaybackDidBegin' in app),
]
failed = []
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ' ' + name)
    if not ok: failed.append(name)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
raise SystemExit(1 if failed else 0)
