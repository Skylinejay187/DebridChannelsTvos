from pathlib import Path
import plistlib, re, hashlib, sys
root=Path(__file__).resolve().parents[1]
app=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()
proj=(root/'project.yml').read_text()
assert 'MARKETING_VERSION: 1.0.768' in proj
assert 'CURRENT_PROJECT_VERSION: 768' in proj
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with open(root/rel,'rb') as f: p=plistlib.load(f)
    assert p['CFBundleShortVersionString']=='1.0.768'
    assert p['CFBundleVersion']=='768'
    assert p['DebridChannelsReleaseID']=='vBRDC065'
assert 'private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) async' in app
assert 'Task.detached(priority: .utility)' in app
assert 'LiveTVXMLTVBackgroundParser.parse(' in app
assert 'withTaskCancellationHandler' in app
assert 'worker.cancel()' in app
assert 'lookupCache' in app
assert 'programRegex.enumerateMatches' in app
assert 'Task.isCancelled || parsedCount >= 1_500_000' in app
assert 'let hdhrGuide = await parseXMLTV' in app
assert 'let parsedGuide = await parseXMLTV' in app
# No old synchronous signature may remain.
assert 'private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) ->' not in app
# Playback/KSP/provider scope is intentionally locked to v64.
v64=Path('/tmp/v64/DebridChannels_vBRDC064_KSP_IDET_CRASH_FIX_GITHUB')
locked=[
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift',
'Sources/PlaybackKit/PlaybackKitFoundation.swift',
'Sources/UniversalCodecSupport.swift',
'Sources/TorBoxUsenetClient.swift',
'Sources/CatalogStore.swift',
'Sources/UnitySurfaceSystem.swift',
'Sources/LocalIntroDetectionEngine.swift',
'Sources/PlaybackStateManager.swift',
'Sources/VODExclusivePlaybackGate.swift',
'Scripts/fetch_patch_kspnuvio_vBRDC064.sh',
'Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py',
'BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py',
]
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for rel in locked:
    assert sha(root/rel)==sha(v64/rel), rel
print('PASS vBRDC065 contract')
