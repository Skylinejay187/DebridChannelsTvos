from pathlib import Path
import hashlib, plistlib, re, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
CAT = (ROOT/'Sources/CatalogStore.swift').read_text()
IMG = (ROOT/'Sources/RemoteImageFit.swift').read_text()
FRAME = (ROOT/'Sources/UnityFrameRuntime.swift').read_text()
UNITY = (ROOT/'Sources/UnityAnimationCoordinator.swift').read_text()
LIFE = (ROOT/'Sources/UnitySurfaceLifecycleCoordinator.swift').read_text()
PROJECT_TEXT = (ROOT/'project.yml').read_text()
PROJECT = yaml.safe_load(PROJECT_TEXT)
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def pl(rel):
    with open(ROOT/rel,'rb') as f: return plistlib.load(f)
def sha(rel): return hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
def section(text,start,end):
    a=text.find(start)
    if a<0:return ''
    b=text.find(end,a+len(start))
    return text[a:] if b<0 else text[a:b]

app=pl('Sources/Info.plist'); top=pl('TopShelfExtension/Info.plist')
ck('release vBRDC102', app.get('DebridChannelsReleaseID')=='vBRDC102' and top.get('DebridChannelsReleaseID')=='vBRDC102')
ck('marketing 1.0.805', app.get('CFBundleShortVersionString')=='1.0.805' and top.get('CFBundleShortVersionString')=='1.0.805')
ck('build 805', app.get('CFBundleVersion')=='805' and top.get('CFBundleVersion')=='805')
ck('project marketing 1.0.805 twice', PROJECT_TEXT.count('MARKETING_VERSION: 1.0.805')==2)
ck('project build 805 twice', PROJECT_TEXT.count('CURRENT_PROJECT_VERSION: 805')==2)

# One shared frame runtime exists and owns every category of competing work.
for lane in ['navigationGeometry','transitionGeometry','criticalArtwork','interactiveMetadata','liveSchedule','backgroundPrefetch','persistence','ambientMotion','recovery','overlayChrome','playbackChrome','alerts']:
    ck('frame lane '+lane, f'case {lane}' in FRAME)
ck('frame snapshot owns navigation state', 'var navigationActive: Bool = false' in FRAME and 'var postNavigationRecoveryActive: Bool = false' in FRAME)
ck('frame snapshot owns surface transition', 'var surfaceTransitionActive: Bool = false' in FRAME)
ck('frame snapshot owns playback/source/trailer', all(x in FRAME for x in ['var sourceOpeningActive: Bool = false','var trailerActive: Bool = false','var playbackActive: Bool = false']))
ck('repeat remote burst is coalesced', 'if !wasNavigationActive || wasRecovering { publishRevision() }' in FRAME)
ck('duplicate surface claims do not republish', 'if snapshot.surfaceTransitionActive == active' in FRAME and 'if active { snapshot.transitionSource = normalized }' in FRAME)
ck('surface transition allows critical art', 'case .navigationGeometry, .transitionGeometry, .criticalArtwork, .overlayChrome, .alerts:' in FRAME)
ck('surface transition blocks ambient/prefetch', 'case .interactiveMetadata, .liveSchedule, .backgroundPrefetch, .persistence, .ambientMotion, .recovery, .playbackChrome:' in FRAME)
ck('active navigation blocks critical and ambient', 'case .criticalArtwork, .interactiveMetadata, .liveSchedule, .backgroundPrefetch, .persistence, .ambientMotion, .recovery, .playbackChrome:' in FRAME)
ck('post-navigation keeps prefetch ambient recovery blocked', 'case .backgroundPrefetch, .ambientMotion, .recovery:' in FRAME)
ck('runtime exposes cancellable permission wait', 'func waitUntilPermitted(_ lane: Lane' in FRAME and 'Task.isCancelled' in section(FRAME,'func waitUntilPermitted','func resetTransientOwnership'))
ck('runtime centralizes catalog handoff profile', 'func catalogTransitionProfile' in FRAME and 'visibleDuration: 0.38' in FRAME and 'visibleDuration: 0.34' in FRAME)

# Existing feature facade now delegates to frame runtime instead of owning another clock.
ck('animation facade uses frame runtime', 'private let frameRuntime = UnityFrameRuntime.shared' in UNITY)
ck('navigation registration delegates', 'frameRuntime.registerNavigationActivity(source: source, settleAfter: settleAfter)' in UNITY)
ck('image publication policy delegates', 'frameRuntime.shouldDeferVisualPublication(critical: allowDuringSurfaceHandoff)' in UNITY)
ck('dynamic wallpaper uses ambient lane', 'case .dynamicWallpaper, .catalogPulse, .catalogPreview, .tickerMotion:' in UNITY and 'return .ambientMotion' in UNITY)
ck('row/live/sports motion use navigation lane', 'case .catalogFocusArrival, .catalogRowMotion, .liveTVMotion, .guideMotion, .sportsMotion:' in UNITY and 'return .navigationGeometry' in UNITY)
ck('detail/source motion use transition lane', 'case .detailTransition, .detailConnector, .sourceIntelligenceMotion:' in UNITY and 'return .transitionGeometry' in UNITY)
ck('exclusive playback synchronized into runtime', 'playbackActive: fullScreenPlaybackActive' in UNITY)
ck('surface handoff facade delegates', 'frameRuntime.setSurfaceTransitionActive(active, source: "surface-handoff")' in UNITY)

# Lifecycle/background work shares same authority.
ck('lifecycle owns frame runtime', 'private let frameRuntime = UnityFrameRuntime.shared' in LIFE)
ck('lifecycle background permission comes from runtime', 'var permitsNonessentialBackgroundWork: Bool { frameRuntime.permits(.backgroundPrefetch) }' in LIFE)
ck('lifecycle starts runtime transition', 'frameRuntime.setSurfaceTransitionActive(true, source: reason)' in LIFE)
ck('lifecycle finishes runtime transition', LIFE.count('frameRuntime.setSurfaceTransitionActive(false, source: reason)')>=2)

# Remote image decoding no longer has an independent 35ms / forced 350ms publish clock.
pub=section(IMG,'private func publishDecodedImage','private static func normalizedURL')
ck('image publication joins runtime lane', 'UnityFrameRuntime.shared.waitUntilPermitted(lane, maxWait: 2.50)' in pub)
ck('critical image maps to criticalArtwork', '? .criticalArtwork' in pub)
ck('noncritical image maps to backgroundPrefetch', ': .backgroundPrefetch' in pub)
ck('old image polling loop removed', 'for _ in 0..<10' not in pub and '35_000_000' not in pub)
ck('obsolete decoded owner still drops', 'self.currentKey == key' in pub)

# Catalog/root transition, row rebuild and hero metadata are on one clock.
transition=section(APP,'private func synchronizeUnityCatalogBranchPresentation','private func scheduleUnitySurfaceHandoff')
handoff=section(APP,'private func scheduleUnitySurfaceHandoff','private func scheduleCatalogInteractionRecovery')
rowsrebuild=section(APP,'private func scheduleRenderedRowsRebuild','private func rebuildRenderedRows')
heroMeta=section(APP,'private func scheduleFocusedHeroMetadata','private func cancelFocusedHeroMetadata')
ck('catalog transition requests shared profile', 'catalogTransitionProfile(' in transition)
ck('catalog entry keeps original visual curve', '.timingCurve(0.22, 1.0, 0.36, 1.0, duration: frameProfile.visibleDuration)' in transition)
ck('catalog exit keeps original visual curve', '.timingCurve(0.40, 0.0, 0.20, 1.0, duration: frameProfile.visibleDuration)' in transition)
ck('focus checkpoints use shared profile', all(x in handoff for x in ['frameProfile.focusBind','frameProfile.focusSettle','frameProfile.ambientTail']))
ck('normal handoff does not run emergency artwork storm', 'PremiumArtworkRehydrationCoordinator.shared.force' not in handoff)
ck('rendered rows wait interactive metadata', 'waitUntilPermitted(.interactiveMetadata' in rowsrebuild)
ck('rendered rows no old half-second ownership timer', '0.50 - elapsed' not in rowsrebuild and 'elapsed >= 0.48' not in rowsrebuild)
ck('hero metadata waits same lane before request', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.60)' in heroMeta)
ck('hero metadata waits same lane before publish', 'waitUntilPermitted(.interactiveMetadata, maxWait: 0.80)' in heroMeta)
ck('connected artwork prewarm waits background lane', 'waitUntilPermitted(.backgroundPrefetch, maxWait: 1.40)' in APP)

# Live TV / Gracenote / XMLTV / Xtream publications are frame-aware.
liveRefresh=section(APP,'func refreshFromConfiguredSources','private struct XtreamAccount')
ck('Live provider publication waits runtime', 'waitUntilPermitted(.interactiveMetadata, maxWait: 2.00)' in liveRefresh)
ck('Live final publish waits runtime again', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.20)' in liveRefresh)
ck('Gracenote guide built into local snapshot', 'var finalizedGuidePrograms = previousGuidePrograms' in liveRefresh)
ck('published guide swaps only after final gate', liveRefresh.find('guidePrograms = finalizedGuidePrograms') > liveRefresh.find('waitUntilPermitted(.interactiveMetadata, maxWait: 1.20)'))
ck('authoritative HDHR merges into local guide', 'let current = finalizedGuidePrograms[key] ?? []' in liveRefresh)
ck('Xtream visible batches wait runtime', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.20)' in section(APP,'private func commitXtreamChannelsInVisibleBatches','private func loadXtreamShortGuidePrograms'))
ck('Xtream incremental EPG waits runtime', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.20)' in section(APP,'private func loadXtreamShortGuidePrograms','private func xtreamGuideStorageKeys'))
ck('Xtream deferred final guide waits runtime', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.50)' in section(APP,'private func loadDeferredXtreamShortGuide','private func commitXtreamChannelsInVisibleBatches'))
ck('Live boundary schedule uses liveSchedule lane', 'waitUntilPermitted(.liveSchedule, maxWait: 1.20)' in APP)
ck('Live artwork prefetch uses background lane', 'waitUntilPermitted(.backgroundPrefetch, maxWait: 1.25)' in APP)
ck('Live selection persistence uses persistence lane', 'waitUntilPermitted(.persistence, maxWait: 1.20)' in APP)
ck('cold start Gracenote hydration uses background lane', 'waitUntilPermitted(.backgroundPrefetch, maxWait: 1.80)' in APP)
ck('active Live refresh waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.25)' in APP)

# Sports, Favorites, detail/settings and Live controls participate in same interaction ownership.
sportsModel=section(APP,'final class SportsLiveZoneModel','struct SportsHubScreen')
sportsHub=section(APP,'struct SportsHubScreen','private struct SportsFoundationQuickPanelSurface')
ck('Sports multi-rail publication waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 2.00)' in sportsModel)
ck('Sports retained rows prebind before visible interaction', 'if sportsCenterVM.sportsRows.isEmpty' in sportsHub and 'rebuildSportsRowsNow()' in sportsHub)
ck('Sports later row rebuild waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.60)' in sportsHub)
ck('Sports row refresh task cancels on exit', 'sportsRowsRefreshTask?.cancel()' in sportsHub)
ck('Sports cards register navigation ownership', APP.count('registerNavigationActivity(source: "sports", settleAfter: 0.22)')>=2)
ck('Favorites register navigation ownership', 'registerNavigationActivity(source: "favorites", settleAfter: 0.22)' in APP)
ck('Favorites model rebuild waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.30)' in APP)
ck('Media info registers navigation', 'registerNavigationActivity(source: "media-info", settleAfter: 0.20)' in APP)
ck('Details registers navigation', 'registerNavigationActivity(source: "detail", settleAfter: 0.20)' in APP)
ck('Settings registers navigation', 'registerNavigationActivity(source: "settings", settleAfter: 0.18)' in APP)
ck('Catalog customization registers navigation', 'registerNavigationActivity(source: "settings-catalog-customization", settleAfter: 0.18)' in APP)
ck('Live guide/controls register navigation', 'registerNavigationActivity(source: showGuide ? "live-guide" : "live-tv-controls"' in APP)

# CatalogStore bulk and incremental providers cannot invalidate persistent roots during navigation.
ck('bulk catalog publication waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 3.00)' in CAT)
ck('TMDB background catalog publication waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 2.00)' in CAT)
ck('lazy catalog row replacement waits metadata lane', 'waitUntilPermitted(.interactiveMetadata, maxWait: 1.80)' in CAT)

# Existing visual identity / design remains locked.
DONOR={
'Sources/UnityCatalogVisualSystem.swift':'f95eeb731db2e3e558d0dc387c4201ffb2f261245af45c13250c879143efe6d8',
'Sources/UnitySurfaceSystem.swift':'00f507ce35a619732abe0811ff3fd3f7ffe58c431336b23b69011f43079beb76',
'Sources/NuvioPluginClient.swift':'94a3196403f26e8edad215029b26191e3941d7fb14a5fc5ac60fe29801a90a75',
'Sources/BackupStreamingClient.swift':'251dc138dbd14fc476c76bc6a765f85643df083a5c94196d54fc0148337346cd',
'Sources/MediaFlowProxyRouter.swift':'310c001fd1e3cd4728470c46e9057a4d7212f6099276816b0477e754a1971ca4',
'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift':'a6c03d579214fe0b3602092d2db377c6b41f501d9ae8885c82c22927caabfa3d',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
'Sources/PlaybackResumeCache.swift':'3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
'Sources/VODProductionMetadata.swift':'7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
'Sources/TorBoxUsenetClient.swift':'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
'Sources/SourceIntelligenceManager.swift':'7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
}
for rel,h in DONOR.items(): ck('donor visual/core lock '+rel, sha(rel)==h)
ck('all row motion visual definitions byte-identical to v101', sha('Sources/UnityCatalogVisualSystem.swift')==DONOR['Sources/UnityCatalogVisualSystem.swift'])

# vBRDC101 Artwork 4 / Hero 2 continuity remains intact.
main_art=section(APP,'private func mainArtworkBackground','private func artworkThemeTint')
depth=section(APP,'private func artworkDepthLayers','private var artworkHeroLogo')
hero=section(APP,'private func artworkHeroLogo','struct Artwork4HeroLogoLayer: View')
hero_logo=section(APP,'struct Artwork4HeroLogoLayer: View','private struct CatalogHeroMetadataRibbon')
focused=section(APP,'struct FixedSlotFocusedCatalogCard: View','struct FixedSlotPreviewCatalogCard: View')
preview=section(APP,'struct FixedSlotPreviewCatalogCard: View','struct HomeGridThemeOverlay: View')
ck('main backdrop remains true 4K capped', 'maxPixelSize: 3840' in main_art)
ck('main backdrop retains frame', 'preservePreviousOnURLChange: true' in main_art)
ck('main backdrop remains critical handoff art', 'publishDuringSurfaceHandoff: true' in main_art)
ck('depth art remains 4K capped', 'maxPixelSize: 3840' in depth)
ck('Artwork4 logo retains frame', 'preservePreviousOnURLChange: true' in hero_logo)
ck('Artwork4 logo remains critical handoff art', 'publishDuringSurfaceHandoff: true' in hero_logo)
ck('focused big card retains frame', 'preservePreviousOnURLChange: true' in focused)
ck('focused big card owner remains URL-stable', r'.id("focused-card-art-\(rowID)-\(item.id)")' in focused)
ck('preview cards retain frame', 'preservePreviousOnURLChange: true' in preview)

# vBRDC100 cast + Production & Ratings smooth rotation remains intact.
cast=section(APP,'struct V1111FeaturedCastPosterCard: View','private struct V1106ProductionFact')
prod_panel=section(APP,'struct V1108ProductionRatingsPanel: View','private struct V1111ProductionArtworkHeader')
prod_header=section(APP,'private struct V1111ProductionArtworkHeader: View','struct V1104ReviewScoresCluster')
ck('compact cast retained frame', 'preservePreviousOnURLChange: true' in section(cast,'private var compactBannerSurface','private func fullPosterCast'))
ck('full cast retained frame', 'preservePreviousOnURLChange: true' in section(cast,'private func fullPosterCast','private var accessibilityText'))
ck('cast stable identity', r'.id("vBRDC100-featured-cast-full-\(item.id)")' in cast)
ck('cast 7 second cadence unchanged', 'Task.sleep(nanoseconds: 7_000_000_000)' in cast)
ck('production retained frame', 'preservePreviousOnURLChange: true' in prod_header)
ck('production stable identity', r'.id("vBRDC100-production-header-\(item.id)")' in prod_panel)
ck('production 7 second cadence unchanged', 'Timer.publish(every: 7.0' in prod_header)

# Genuine recovery paths remain; normal movement does not invoke them.
ck('playback close rehydration retained', 'PremiumArtworkRehydrationCoordinator.shared.force(reason: "full-screen playback closed")' in APP)
ck('scene resume rehydration retained', 'PremiumArtworkRehydrationCoordinator.shared.force(reason: "scene became active")' in APP)
ck('normal UNITY handoff contains no force rehydration', 'PremiumArtworkRehydrationCoordinator.shared.force' not in handoff)

# Project file must compile every Swift source, including new runtime.
entries=PROJECT['targets']['DebridChannelsTVOS']['sources']
paths={e['path'] if isinstance(e,dict) else e for e in entries}
all_swift={str(p.relative_to(ROOT)) for p in (ROOT/'Sources').rglob('*.swift')}
ck('UnityFrameRuntime declared in project', 'Sources/UnityFrameRuntime.swift' in paths)
ck('all Swift sources declared', all_swift.issubset(paths))
ck('expected Swift source count 64 app + topshelf = 65 parse units', len(all_swift)+1==65)

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'),n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
