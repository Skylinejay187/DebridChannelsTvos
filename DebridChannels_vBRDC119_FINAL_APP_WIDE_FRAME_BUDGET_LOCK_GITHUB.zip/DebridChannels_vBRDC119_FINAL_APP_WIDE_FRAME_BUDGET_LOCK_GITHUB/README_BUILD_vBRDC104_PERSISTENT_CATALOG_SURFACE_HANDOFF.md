# Debrid Channels vBRDC104 — Persistent Catalog Surface Handoff

**Marketing version:** 1.0.807  
**Apple build:** 807  
**Donor:** packaged vBRDC103 Persistent UNITY Scroll Engine

## Physical-device finding from 38422.mp4
vBRDC103 fixed the physical row renderer, but the entire `GridOSCatalogOverlay` still mounted and unmounted for each Live TV ↔ Home/Movies/Shows round trip. The catalog open path therefore stacked surface animation with `onAppear`, row projection, Hero/metadata setup, and a 0/80/220 ms focus recovery. The close path reversed the same heavy surface and then released it.

## vBRDC104 changes
- Keeps one `GridOSCatalogOverlay` physically mounted across Live TV ↔ catalog handoffs.
- Retains decoded/layout/row state while the catalog is hidden.
- Stops focused preview and Hero metadata work while the hidden catalog is not active.
- Normal catalog entry uses one render-turn focus bind; bounded 0/80/220 ms retries remain only for real detail/playback/scene recovery.
- Removes the full-surface scale transform from catalog open/close.
- Reduces catalog vertical handoff travel from 34 pt to 18 pt.
- Open compositor duration: 0.22 s; close compositor duration: 0.20 s.
- Home/Movies/Shows filter changes re-project the resident row snapshot without remounting the surface.
- All vBRDC103 persistent row/card renderer behavior and all 48 existing row-motion visual definitions remain intact.
- vBRDC100 Cast/Production retained-image handoffs and vBRDC101/vBRDC102 artwork/runtime protections remain intact.

## Validation
- vBRDC104 source/continuity contract: 82/82 PASS
- Production Swift parse: 65/65 PASS (one pre-existing PlaybackKit indentation warning)
- Plist/project version checks: 8/8 PASS
- Backend donor tests: 36 passed, 2 subtests passed
- Existing donor implementation/version scope: exactly 5 changed files, 0 unexpected
- `UnityCatalogVisualSystem.swift`: byte-identical to vBRDC103

Physical Apple TV testing remains authoritative for frame pacing.
