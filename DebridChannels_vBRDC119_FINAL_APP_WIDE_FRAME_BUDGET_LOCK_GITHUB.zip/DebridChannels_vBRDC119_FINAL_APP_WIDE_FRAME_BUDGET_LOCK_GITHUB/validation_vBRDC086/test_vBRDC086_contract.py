from pathlib import Path
import hashlib
import plistlib
import re
import sys
import yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
UNIVERSAL = (ROOT / 'Sources/UniversalCodecSupport.swift').read_text()
FOUNDATION = (ROOT / 'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
KS = (ROOT / 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
PROJECT = yaml.safe_load((ROOT / 'project.yml').read_text())
checks = []


def ck(name, cond):
    checks.append((name, bool(cond)))


def pl(rel):
    with open(ROOT / rel, 'rb') as f:
        return plistlib.load(f)


def sha(rel):
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def section(text, start_marker, end_marker):
    start = text.find(start_marker)
    if start < 0:
        return ''
    end = text.find(end_marker, start + len(start_marker))
    return text[start:] if end < 0 else text[start:end]


app_plist = pl('Sources/Info.plist')
top_plist = pl('TopShelfExtension/Info.plist')
ck('release id vBRDC086', app_plist.get('DebridChannelsReleaseID') == 'vBRDC086' and top_plist.get('DebridChannelsReleaseID') == 'vBRDC086')
ck('marketing version 1.0.789', app_plist.get('CFBundleShortVersionString') == '1.0.789' and top_plist.get('CFBundleShortVersionString') == '1.0.789')
ck('build version 789', app_plist.get('CFBundleVersion') == '789' and top_plist.get('CFBundleVersion') == '789')
ck('project marketing 1.0.789', PROJECT['settings']['base']['MARKETING_VERSION'] == '1.0.789')
ck('project build 789', str(PROJECT['settings']['base']['CURRENT_PROJECT_VERSION']) == '789')

# Favorites must have an explicit identity owner distinct from the shared catalog.
rail_open = section(APP, 'private func openSelected()', 'private func removeSelectedSportsChannel')
ck('Favorites rail is explicitly detected', 'let isFavoritesRail = row.id == "catalog-favorites-quick-panel"' in rail_open)
ck('Favorites restore section is not streamingCatalog', 'store.quickPanelRestoreSection = isFavoritesRail ? "favoritesCatalog" : "streamingCatalog"' in rail_open)
ck('Favorites details use favorites presentation origin', 'let presentationOrigin: DetailPresentationOrigin? = isFavoritesRail ? .favorites : nil' in rail_open)
ck('shared catalogs still retain streamingCatalog owner', '"streamingCatalog"' in rail_open)

# Shared catalog rendering has a same-frame UI fail-safe against Favorites identity leakage.
hero_gate = section(APP, 'private var catalogMayUseDetailPresentationAnchor', 'private var rowFocusedBackdropItem')
ck('catalog hero gate rejects favorites origin', 'store.detailPresentationOrigin != .favorites' in hero_gate)
ck('catalog hero gate rejects favorites restore section', 'store.quickPanelRestoreSection != "favoritesCatalog"' in hero_gate)
ck('catalog hero gate rejects favorites row id', 'store.quickPanelRestoreRowID != "catalog-favorites-quick-panel"' in hero_gate)
focused_item = section(APP, 'private var focusedBackdropItem', 'private var focusedBackdropRowID')
ck('focused hero ignores favorites selected detail', 'store.detailPresentationOrigin != .favorites' in focused_item)
ck('focused hero requires gated anchor', 'catalogMayUseDetailPresentationAnchor' in focused_item)
focused_url = section(APP, 'private var focusedBackdropURL', 'private var focusedBackdropStableIdentity')
ck('backdrop URL requires gated anchor', 'catalogMayUseDetailPresentationAnchor' in focused_url)

# closeDetail may pin a hero only for true shared catalog origin, never Favorites.
close_detail = section(STORE, 'func closeDetail()', 'func releaseDetailPresentationAnchorAfterCatalogRestore')
ck('closeDetail captures closing origin', 'let closingOrigin = detailPresentationOrigin' in close_detail)
ck('hero retention requires catalog origin', 'guard closingOrigin == .catalog' in close_detail)
ck('hero retention rejects Favorites row', 'quickPanelRestoreRowID != "catalog-favorites-quick-panel"' in close_detail)
ck('Favorites close clears restore identity', 'if closingOrigin == .favorites || quickPanelRestoreRowID == "catalog-favorites-quick-panel"' in close_detail and 'clearFavoritesRestoreIdentity()' in close_detail)
ck('nonmatching detail clears anchor', 'detailPresentationAnchorItem = nil' in close_detail)
ck('catalog close behavior still emits content focus token', 'contentFocusToken += 1' in close_detail)

# Dedicated Favorites navigation owns a synchronous state scrub.
fav_cleanup = section(STORE, 'func clearFavoritesPresentationStateForNavigation', 'func closeDetail()')
ck('Favorites cleanup detects origin', 'detailPresentationOrigin == .favorites' in fav_cleanup)
ck('Favorites cleanup detects restore row', 'quickPanelRestoreRowID == "catalog-favorites-quick-panel"' in fav_cleanup)
ck('Favorites cleanup detects focused-card token', 'quickPanelRestoreFocusedCardID?.hasPrefix("catalog-favorites-quick-panel#")' in fav_cleanup)
ck('Favorites cleanup invalidates detail async generation', 'detailOpenGeneration &+= 1' in fav_cleanup)
ck('Favorites cleanup cancels detail credits', 'detailCreditsTask?.cancel()' in fav_cleanup)
ck('Favorites cleanup cancels premium artwork', 'detailPremiumArtworkTask?.cancel()' in fav_cleanup)
ck('Favorites cleanup clears selected detail', 'selectedDetail = nil' in fav_cleanup)
ck('Favorites cleanup clears hero anchor', 'detailPresentationAnchorItem = nil' in fav_cleanup)
ck('Favorites cleanup clears detail stack', 'detailBackStack.removeAll()' in fav_cleanup)
ck('Favorites cleanup clears Source Intelligence when present', 'clearStreamLinkState()' in fav_cleanup)
ck('Favorites cleanup clears restore tokens', 'clearFavoritesRestoreIdentity()' in fav_cleanup)
ck('Favorites cleanup restores catalog origin', 'detailPresentationOrigin = .catalog' in fav_cleanup)
ck('Favorites cleanup releases top-menu lock', 'topMenuFocusLocked = false' in fav_cleanup)

# Both local Back/Exit and root tab handoff enforce the invariant.
root_tab = section(APP, '.onChange(of: store.selectedTab)', '.onChange(of: store.searchActive)')
ck('root tab handoff scrubs outgoing Favorites', 'if oldTab == .favorites, tab != .favorites, store.playbackURL == nil' in root_tab)
ck('root handoff calls Favorites cleanup', 'store.clearFavoritesPresentationStateForNavigation' in root_tab)
close_favorites = section(APP, 'private func closeFavoritesSurface()', 'private func scheduleFavoritesCacheRebuild')
ck('Favorites local exit clears identity before Home', close_favorites.find('clearFavoritesPresentationStateForNavigation') < close_favorites.find('store.selectedTab = .home'))

# The explicit Favorites reset helper must clear every restore token, including numeric slots.
reset = section(STORE, 'private func clearFavoritesRestoreIdentity()', 'func clearFavoritesPresentationStateForNavigation')
for token in [
    'quickPanelRestoreItemID', 'quickPanelRestoreCanonicalKey', 'quickPanelRestoreIdentityItem',
    'quickPanelRestoreRowID', 'quickPanelRestoreRowIndex', 'quickPanelRestoreItemIndex',
    'quickPanelRestoreSection', 'quickPanelRestoreFocusedCardID'
]:
    ck('Favorites reset clears ' + token, token in reset)

# vBRDC085 Find Links resume/autoplay lock remains in place.
ck('VOD explicit KS play assertion serial preserved', '@State private var ksPlayAssertionSerial = 0' in APP)
confirm = section(APP, 'private func confirmAutomaticResume', 'private func forceResumeFromSavedPosition')
ck('automatic resume still emits KS Play assertion', 'ksPlayAssertionSerial &+= 1' in confirm)
ck('UniversalVideoSurface still forwards play assertion', 'playAssertionSerial: ksPlayAssertionSerial' in UNIVERSAL)
ck('PlaybackKit host still forwards play assertion', 'playAssertionSerial: playAssertionSerial' in FOUNDATION)
play_assert = section(KS, 'if coordinator.lastPlayAssertionSerial != playAssertionSerial', '// v408: KSPlayer can crash')
ck('KS surface still calls layer.play for assertion', 'layer.play()' in play_assert)
ck('KS resume liveness recovery remains bounded', 'let delays: [TimeInterval] = [0.32, 0.52, 0.82, 1.18]' in KS)

# vBRDC085 Production decoupling remains intact.
production_loader = section(APP, 'private func loadVODProductionMetadata(', 'private func showVODCastExplorerOnboardingIfNeeded')
ck('Production remains first-frame gated', 'isFirstFrameReady' in production_loader)
ck('Production remains independent from pause', '!isPlaying' not in production_loader)
ck('Production remains background priority', 'Task(priority: .background)' in production_loader)

# Unrelated sensitive systems remain exact packaged-v085 bytes.
BASE_HASHES = {
    'Sources/PlaybackResumeCache.swift': '3eb69ee18cf587646229b8f673e218d76b25a83a953482f5d0ad1377e3ad9bba',
    'Sources/VODProductionMetadata.swift': '7a4971c0f779962e739a136e3f754f5d7318a1fdff51452577c1320f92c2cdaa',
    'Sources/SourceIntelligenceManager.swift': '7f6a38285f4cf5717ddee21ec2da981e64c6c02bbc9bbeef00087645b8215669',
    'Sources/TorBoxUsenetClient.swift': 'c3817fcbd953016cd521bd9c37a9ccd5aeb2a696b40576ba5d505e480d1cc2d7',
    'Sources/UnityAnimationCoordinator.swift': '15320d4424cf64faba13e3a94ff099e939cc561254d05ce267b8300ceed9e305',
    'Sources/UnitySurfaceLifecycleCoordinator.swift': '091ae175dd499c42b5eb9419808ee44f0655a8c16967532a5c708756d6113a86',
    'Sources/UniversalCodecSupport.swift': 'b315a3fb05c7115f94c70234827b15af8be2e502efaa8398d9413a20dee191d7',
    'Sources/PlaybackKit/PlaybackKitFoundation.swift': 'cd22fb911d06af7b4b4d103c8007b14c168ef80e21451253d514c0f1b5f2cdaf',
    'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift': '9fabac610a23f7d96ecd8dc4eca7e680986bb3bc8734cbc75fa1cb4655b483db',
}
for rel, expected in BASE_HASHES.items():
    ck('v085 donor lock ' + rel, sha(rel) == expected)

entries = PROJECT['targets']['DebridChannelsTVOS']['sources']
paths = {e['path'] if isinstance(e, dict) else e for e in entries}
all_swift = {str(p.relative_to(ROOT)) for p in (ROOT / 'Sources').rglob('*.swift')}
ck('every app Swift source is in project', all_swift.issubset(paths))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(('PASS' if ok else 'FAIL'), name)
print(f'\n{len(checks) - len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
