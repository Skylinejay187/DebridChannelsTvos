from pathlib import Path
import plistlib

ROOT = Path(__file__).resolve().parents[1]


def txt(rel):
    return (ROOT / rel).read_text(errors='replace')


def ok(name, cond):
    if not cond:
        raise AssertionError(name)
    print('PASS', name)


proj = txt('project.yml')
app_swift = txt('Sources/DebridChannelsTVOSApp.swift')
catalog = txt('Sources/CatalogStore.swift')
usenet = txt('Sources/TorBoxUsenetClient.swift')
managed = txt('Sources/ManagedAddonBridge.swift')
creds = txt('Sources/DebridCredentialBridge.swift')
health = txt('Sources/ConnectedServicesHealthClient.swift')
unity = txt('Sources/UnitySurfaceSystem.swift')
relay = txt('BackendTorBoxUsenetSearchRuntime/torbox_usenet_search_runtime.py')
app = plistlib.load(open(ROOT / 'Sources/Info.plist', 'rb'))
top = plistlib.load(open(ROOT / 'TopShelfExtension/Info.plist', 'rb'))

# Release identity
ok('release id', app.get('DebridChannelsReleaseID') == 'vBRDC060')
ok('code name UNITY preserved', app.get('DebridChannelsCodeName') == 'UNITY')
ok('marketing version', app.get('CFBundleShortVersionString') == '1.0.763')
ok('build number', app.get('CFBundleVersion') == '763')
ok('topshelf parity', top.get('DebridChannelsReleaseID') == 'vBRDC060' and top.get('CFBundleShortVersionString') == '1.0.763' and top.get('CFBundleVersion') == '763')
ok('project version parity', proj.count('MARKETING_VERSION: 1.0.763') >= 2 and proj.count('CURRENT_PROJECT_VERSION: 763') >= 2)

# Torrentio is optional and must never own the global key.
ok('Torrentio still explicit opt-in', 'guard defaults.bool(forKey: "managedTorrentioEnabled") else { return [] }' in managed)
ok('Torrentio uses global credential bridge', 'DebridCredentialBridge.credential(for: service, defaults: defaults)' in managed)
ok('global TorBox key remains authoritative', 'key = "torBoxApiKey"' in creds and 'effectiveTorBoxAPIKey' in creds)
ok('explicit add Torrentio UI', 'Add Torrentio Provider (optional)' in app_swift)
ok('explicit remove Torrentio UI', 'Remove Torrentio Provider' in app_swift)
remove_block = app_swift.split('title: managedTorrentioEnabled ? "Remove Torrentio Provider"', 1)[1].split('// vBRDC055', 1)[0]
ok('removing Torrentio does not clear TorBox key', 'torBoxApiKey =' not in remove_block and 'removeObject(forKey: "torBoxApiKey")' not in remove_block)
ok('remove message promises independent Usenet', 'Global API keys were kept; TorBox Usenet remains independent' in remove_block)

# Native TorBox Usenet lane is independent from Torrentio.
usenet_gate = catalog.split('// vBRDC060: TorBox Usenet is credential-gated', 1)[1].split('// v310:', 1)[0]
ok('Usenet keyed directly by effective TorBox credential', 'let torBoxUsenetAPIKey = effectiveTorBoxAPIKey()' in catalog)
ok('Usenet gate does not read managed Torrentio state', 'managedTorrentioEnabled' not in usenet_gate and 'ManagedAddonBridge' not in usenet_gate)
ok('Usenet filter is provider-specific', 'providerCanonical(activeProviderFilter).contains("torboxusenet")' in usenet_gate)
ok('no key means no Usenet task', 'torBoxUsenetTask = nil' in usenet_gate)

# Discovery and owned-library fallback.
ok('direct Voyager discovery preserved', 'searchVoyagerDirect' in usenet and 'https://search-api.torbox.app' in usenet)
ok('backend relay fallback present', '/api/torbox/usenet/search' in usenet and 'X-TorBox-Token' in usenet)
ok('relay requires HTTPS', 'url.scheme?.lowercased() == "https"' in usenet)
ok('Main API owned library fallback present', 'searchOwnedLibrary' in usenet and '/mylist?limit=1000' in usenet)
ok('owned download ID modeled', 'var ownedDownloadID: Int? = nil' in usenet and 'torBoxUsenetDownloadID' in catalog)
ok('owned library rows survive empty hash/NZB', 'identity = "id:\\(downloadID)"' in catalog)
ok('owned download resolves directly', 'if let ownedID = result.ownedDownloadID, ownedID > 0' in usenet)
ok('create Usenet download path retained', '/createusenetdownload' in usenet)
ok('request final download path retained', '/requestdl' in usenet)
ok('cached and uncached search requested', 'URLQueryItem(name: "cached_only", value: "false")' in usenet)
ok('native search runs before user-engine enrichment', 'for includeUserEngines in [false, true]' in usenet)
ok('user engine flag is dynamic', 'URLQueryItem(name: "search_user_engines", value: includeUserEngines ? "true" : "false")' in usenet)
ok('relay defaults to native TorBox search', '"searchUserEngines": false' in usenet)

# A failed search is visible rather than silently swallowed.
ok('visible Usenet discovery failure', 'Usenet connected • discovery unavailable' in catalog)
ok('Settings separates processing from discovery', 'API + Usenet processing connected' in health and 'Find Links tests release discovery separately' in health)
ok('Torrentio disabled health preserves credentials', 'Provider removed / disabled' in health and 'TorBox Usenet remains independent of Torrentio.' in health)

# Relay credential/host boundary.
ok('relay fixed to TorBox Search host', 'SEARCH_BASE = "https://search-api.torbox.app"' in relay)
ok('relay accepts request-scoped header', 'alias="X-TorBox-Token"' in relay)
ok('relay defaults to native TorBox engines', '_bool(payload.get("searchUserEngines"), False)' in relay)
ok('relay forwards Bearer token', '"Authorization": f"Bearer {clean_token}"' in relay)
ok('relay does not put token in URL', 'token=' not in relay and 'api_key=' not in relay)
ok('relay has defensive token redaction', 'detail.replace(clean_token, "[redacted]")' in relay)
ok('relay is search-only', '/createusenetdownload' not in relay and '/requestdl' not in relay)

# Unity architecture remains intact.
ok('Unity source included', 'Sources/UnitySurfaceSystem.swift' in proj)
ok('Unity codename constant', 'static let displayCodeName = "UNITY"' in unity)
ok('Live root role preserved', 'case liveRoot' in unity)
ok('catalog branch role preserved', 'case catalogBranch' in unity)
ok('Artwork4 root special case remains removed', 'artwork4CatalogOverlayActive' not in app_swift)
ok('LiveTV root remains mounted for catalog branch', 'Every Home/Movies/Shows branch keeps the exact same Live TV root mounted' in app_swift)

print('ALL vBRDC060 TORBOX USENET INDEPENDENT PROVIDER CONTRACTS PASS')
