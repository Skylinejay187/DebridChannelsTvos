import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct MediaItem {
    var title: String
    var year: String
    var seasonNumber: Int?
    var episodeNumber: Int?
    var imdbId: String?
    var tmdbId: String?
    var tvdbId: String?
}

final class MockURLProtocol: URLProtocol {
    static var requests: [URLRequest] = []
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.requests.append(request)
        let url = request.url!
        let payload: [String: Any]
        if url.host == "search-api.torbox.app" {
            payload = [
                "success": true,
                "data": [
                    "nzbs": [[
                        "hash": "abcdef0123456789",
                        "raw_title": "Obsession.2026.1080p.WEB-DL.DDP5.1.mkv",
                        "title": "Obsession",
                        "size": 4_294_967_296,
                        "tracker": "TorBox Search",
                        "nzb": "http://100.126.180.44:4010/getnzb/example",
                        "age": "2d",
                        "type": "usenet",
                        "cached": false,
                        "owned": false
                    ]]
                ]
            ]
        } else {
            payload = ["success": true, "data": []]
        }
        let data = try! JSONSerialization.data(withJSONObject: payload)
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main
struct Runner {
    static func main() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [MockURLProtocol.self]
        let session = URLSession(configuration: config)
        let item = MediaItem(title: "Obsession", year: "2026", seasonNumber: nil, episodeNumber: nil, imdbId: "tt1234567", tmdbId: nil, tvdbId: nil)
        let results = try await TorBoxUsenetClient.search(item: item, apiKey: "test-key", backendBaseURL: nil, session: session)
        guard results.count == 1 else { fatalError("expected 1 result, got \\(results.count)") }
        let r = results[0]
        guard r.rawTitle.contains("Obsession.2026"), r.nzbURL.contains("getnzb"), r.sizeBytes == 4_294_967_296, r.cached == false else {
            fatalError("search result did not map current TorBox NZB schema")
        }
        guard let request = MockURLProtocol.requests.first,
              request.value(forHTTPHeaderField: "Authorization") == "Bearer test-key",
              let query = request.url?.query,
              query.contains("check_cache=true"),
              query.contains("check_owned=true"),
              query.contains("search_user_engines=false"),
              query.contains("cached_only=false") else {
            fatalError("native TorBox search request contract mismatch")
        }
        print("PASS current TorBox Search NZB schema maps to a Source Intelligence candidate")
        print("PASS first search uses native TorBox search_user_engines=false, cached_only=false")
    }
}
