import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

struct MediaItem {
    var title: String
    var year: String
    var seasonNumber: Int?
    var episodeNumber: Int?
    var imdbId: String?
    var tmdbId: String?
    var tvdbId: String?
}

final class PlaybackMockURLProtocol: URLProtocol {
    static var requests: [URLRequest] = []
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        Self.requests.append(request)
        let url = request.url!
        let payload: [String: Any]
        if url.path.hasSuffix("/createusenetdownload") {
            payload = ["success": true, "data": ["usenetdownload_id": 88]]
        } else if url.path.hasSuffix("/mylist") {
            let id = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems?.first(where: {$0.name == "id"})?.value.flatMap(Int.init) ?? 77
            payload = ["success": true, "data": [
                "id": id,
                "hash": "abc",
                "name": "Obsession.2026.1080p.WEB-DL.mkv",
                "cached": true,
                "download_finished": true,
                "download_present": true,
                "download_state": "completed",
                "files": [["id": 3, "name": "Obsession.2026.1080p.WEB-DL.mkv", "size": 4_000_000_000, "mimetype": "video/x-matroska"]]
            ]]
        } else if url.path.hasSuffix("/requestdl") {
            payload = ["success": true, "data": "https://cdn.example.test/obsession.mkv"]
        } else {
            payload = ["success": false, "detail": "unexpected fixture URL"]
        }
        let data = try! JSONSerialization.data(withJSONObject: payload)
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
        client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
        client?.urlProtocol(self, didLoad: data)
        client?.urlProtocolDidFinishLoading(self)
    }
    override func stopLoading() {}
}

@main
struct Runner {
    static func main() async throws {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [PlaybackMockURLProtocol.self]
        let session = URLSession(configuration: config)

        let owned = TorBoxUsenetSearchResult(hash: "abc", rawTitle: "Owned", normalizedTitle: "Owned", sizeBytes: 1, tracker: "", nzbURL: "", age: "", cached: true, owned: true, ownedDownloadID: 77)
        let ownedURL = try await TorBoxUsenetClient.resolve(owned, apiKey: "test-key", session: session)
        guard ownedURL.absoluteString == "https://cdn.example.test/obsession.mkv" else { fatalError("owned playback did not resolve") }
        guard !PlaybackMockURLProtocol.requests.contains(where: {$0.url?.path.hasSuffix("/createusenetdownload") == true}) else { fatalError("owned result created duplicate job") }
        print("PASS owned Usenet library result resolves directly to final TorBox CDN URL")

        PlaybackMockURLProtocol.requests = []
        let uncached = TorBoxUsenetSearchResult(hash: "def", rawTitle: "Uncached", normalizedTitle: "Uncached", sizeBytes: 1, tracker: "", nzbURL: "http://100.126.180.44:4010/getnzb/example", age: "", cached: false, owned: false, ownedDownloadID: nil)
        let uncachedURL = try await TorBoxUsenetClient.resolve(uncached, apiKey: "test-key", session: session)
        guard uncachedURL.absoluteString == "https://cdn.example.test/obsession.mkv" else { fatalError("uncached playback did not resolve") }
        guard let create = PlaybackMockURLProtocol.requests.first(where: {$0.url?.path.hasSuffix("/createusenetdownload") == true}),
              create.httpMethod == "POST",
              create.value(forHTTPHeaderField: "Authorization") == "Bearer test-key",
              let body = create.httpBody,
              String(data: body, encoding: .utf8)?.contains("http://100.126.180.44:4010/getnzb/example") == true else {
            fatalError("uncached NZB was not submitted to TorBox Main API")
        }
        guard PlaybackMockURLProtocol.requests.contains(where: {$0.url?.path.hasSuffix("/requestdl") == true}) else { fatalError("final requestdl was not called") }
        print("PASS uncached NZB handoff creates a TorBox Usenet job and resolves final CDN URL")
    }
}
