# Debrid Channels vBRDC107 — Persistent Focused Preview Ownership

- Release ID: `vBRDC107`
- Marketing version: `1.0.810`
- Apple build: `810`
- Donor: packaged `vBRDC106`

## Physical-test regression addressed

On Home / Movies / Shows catalog rows, the focused-card preview could visibly pause, disappear, or restart when the user moved focus inside the connected Media Profile (Play / Trailer / Find Links / Cast) or simply opened the selected item, even though the selected movie/show had not changed.

## Root cause

The focused preview was still classified as generic UNITY `ambientMotion`. Any navigation burst or surface transition temporarily denied that lane. `FixedSlotFocusedCatalogCard` used that permission directly in its render condition and also forced `inlinePreviewIsPlaying = false` when permission changed, so ordinary UI motion inside the same title could hide/dismantle the AVPlayer-backed preview.

The pending preview request also had no independent media-identity owner. Re-entering the scheduling path during Media Profile presentation could reset the same card's settle/resolve task.

## Fix

1. Active focused-card preview ownership is now keyed to the exact catalog media identity, not to current UI animation permission.
2. Once a preview is active for the selected movie/show, opening Media Profile and moving among its controls no longer hides, pauses, or dismantles it.
3. Added a separate `focusedCardPreviewRequestedKey` so the same card's pending 1.5-second settle/resolve task survives Media Profile opening and focus movement instead of restarting.
4. The focused preview surface is no longer conditionally removed when UNITY temporarily yields ambient animation during navigation/surface transitions.
5. Row/card identity change still cancels the previous preview immediately and starts the normal settle/resolve path for the new card.
6. Actually launching Trailer still tears the preview down through the existing exclusive-trailer notification/decoder handoff.
7. Full-screen VOD/Live playback, leaving the catalog branch, Search, scene deactivation, memory warning, or disabling the setting still perform required lifecycle teardown.

## Preserved behavior

- Focused-card preview remains muted, 720p-capped, and uses the existing 1.5-second settled-card delay.
- The old arbitrary 40-second stop is removed. If the preview asset ends while the same card still owns focus/detail identity, it loops in-place without resolving another URL/player.
- vBRDC103 persistent row scrolling and all 48 row-motion visuals remain unchanged.
- vBRDC104 persistent catalog surface remains.
- vBRDC105 Live TV fast return + Live TV focus preview remains.
- vBRDC106 VOD Cast / Production & Ratings / Cast Explorer fixes remain.
- No provider, playback resolver, resume, Usenet, Gracenote, Dynamic Wallpaper, Live TV grid, or Sports behavior is changed by this build.

Physical Apple TV validation remains authoritative for real preview continuity and frame pacing.
