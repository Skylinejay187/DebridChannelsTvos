# vBRDC118 Performance Audit — Current Apple TV Peak-Smooth Pass

## What was already solved before vBRDC118

The current source already contains several important optimizations from earlier UNITY builds, so vBRDC118 deliberately did not duplicate or rewrite them:

- vBRDC088 removed the old O(n) row allocation/focus path and moved focused-card geometry reporting to a stable fixed slot.
- vBRDC090 stopped hidden Live TV and noncritical artwork publication from fighting catalog navigation.
- vBRDC102 centralized interactive frame ownership in `UnityFrameRuntime`.
- vBRDC103 moved catalog scrolling onto persistent fixed slots.
- v1085 reduced the hero effect from multiple extra full-screen artwork copies to one restrained depth pass.
- Dynamic Wallpaper already uses bounded low-frequency cadence and yields/freezes during navigation where required.

## Remaining high-value bottleneck found

The app was protecting **publication** of decoded artwork during navigation, but large decorative images could still start their URLSession request and ImageIO 4K decode while the D-pad animation was moving.

That hidden work is expensive even when the pixels do not publish immediately:

- network completion scheduling
- compressed image memory
- ImageIO decompression
- decoded bitmap allocation
- memory bandwidth/cache pressure
- later texture upload/compositor work

This explains how an app can have the same visible number of animations as another tvOS app but still feel less fluid: the competitor may be doing far less invisible work inside the same 16.67 ms frame budget.

## vBRDC118 correction

Heavy decorative 4K `RemoteImageFit` owners now delay a cache-miss request/decode **start** until navigation geometry settles. Exact cache hits remain immediate. Repeated focus changes replace the pending request so only the final focus owner pays the heavy cost.

Applied to:

1. Catalog main 4K backdrop
2. Catalog depth 4K backdrop
3. Sports UNITY 4K backdrop
4. Favorites 4K backdrop

The normal 1280 focused card and 1280 hero logo remain immediate so the visual focus response is unchanged.

## What vBRDC118 intentionally does not do

- No animation is removed.
- No spring/timing curve is shortened.
- No 4K backdrop decode target is reduced.
- No blur/glow/theme is removed.
- No Dynamic Wallpaper theme is downgraded.
- No root `CatalogStore` observation rewrite is attempted in this build; that would be a much larger regression surface.

## Next measurement step

If physical Apple TV still shows measurable hitches after this pass, the next optimization should be guided by an Instruments capture (Animation Hitches + Time Profiler + Core Animation) from the exact interaction that drops frames. That will let the next build target the remaining real main-thread/compositor offender instead of reducing visual quality speculatively.
