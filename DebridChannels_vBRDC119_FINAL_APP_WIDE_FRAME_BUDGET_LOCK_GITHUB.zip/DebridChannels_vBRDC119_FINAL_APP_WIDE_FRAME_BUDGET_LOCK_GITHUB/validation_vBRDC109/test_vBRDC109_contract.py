from pathlib import Path
import plistlib, sys, hashlib, re
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
RUNTIME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
PROJECT=(ROOT/'project.yml').read_text()
checks=[]
def ck(name, cond): checks.append((name, bool(cond)))
def section(text,a,b):
    i=text.find(a)
    if i<0:return ''
    j=text.find(b,i+len(a))
    return text[i:] if j<0 else text[i:j]
def plist(path):
    with open(ROOT/path,'rb') as f:return plistlib.load(f)
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
apppl=plist('Sources/Info.plist'); toppl=plist('TopShelfExtension/Info.plist')
ck('release id', apppl.get('DebridChannelsReleaseID')=='vBRDC109' and toppl.get('DebridChannelsReleaseID')=='vBRDC109')
ck('marketing', apppl.get('CFBundleShortVersionString')=='1.0.812' and toppl.get('CFBundleShortVersionString')=='1.0.812')
ck('build', apppl.get('CFBundleVersion')=='812' and toppl.get('CFBundleVersion')=='812')
ck('project versions', PROJECT.count('MARKETING_VERSION: 1.0.812')==2 and PROJECT.count('CURRENT_PROJECT_VERSION: 812')==2)

# vBRDC109: actual catalog surface boundary shown in 38435.mp4.
root=section(APP,'struct RootView: View','struct TopMenuBar')
ck('root owns explicit catalog transition flag', '@State private var unityCatalogBranchTransitionActive: Bool = false' in root)
ck('persistent catalog receives transition ownership', 'surfaceHandoffActive: unityCatalogBranchTransitionActive' in root)
ck('visible surface has one root translation', '.offset(y: (1 - progress) * 18)' in root)
ck('open marks transition before progress animation', root.find('unityCatalogBranchTransitionActive = true\n            unityCatalogBranchProgress = 0') >= 0)
ck('close pins transition before reverse animation', 'pin catalog focus geometry for the complete visible close' in root and 'unityCatalogBranchTransitionActive = true' in root)
ck('transition flag clears only after branch settle', 'unityCatalogBranchTransitionActive = false\n                unityCatalogTransitionTask = nil' in root)

overlay=section(APP,'struct GridOSCatalogOverlay: View','private func dcParsedSeasonEpisode')
ck('overlay accepts surface handoff state', 'let surfaceHandoffActive: Bool' in overlay)
ck('overlay has persistent visual focus pin', '@State private var surfaceHandoffVisualFocusPinned: Bool = false' in overlay)
ck('surface handoff begins visual pin', '.onChange(of: surfaceHandoffActive)' in overlay and 'beginCatalogSurfaceVisualFocusPin()' in overlay)
ck('visual pin binds active row without animation', 'transaction.disablesAnimations = true' in section(overlay,'private func beginCatalogSurfaceVisualFocusPin()','private func finishCatalogSurfaceVisualFocusPin()') and 'focusedRow = min(max(activeRowIndex, 0), rows.count - 1)' in section(overlay,'private func beginCatalogSurfaceVisualFocusPin()','private func finishCatalogSurfaceVisualFocusPin()'))
ck('visual pin releases one render turn later', 'await Task.yield()' in section(overlay,'private func finishCatalogSurfaceVisualFocusPin()','private func moveQuickPanelRow'))
ck('rail receives visual focus pin', 'surfaceVisualFocusPinned: surfaceHandoffVisualFocusPinned || surfaceHandoffActive' in overlay)

rail=section(APP,'struct GridOSFixedSlotCatalogRail: View','struct FixedSlotPreviewCatalogCard')
ck('rail owns surface visual pin input', 'var surfaceVisualFocusPinned: Bool = false' in rail)
ck('surface pin forces final focused geometry', 'private var cardIsVisuallyFocused: Bool' in rail and 'surfaceVisualFocusPinned' in section(rail,'private var cardIsVisuallyFocused','private var previewSlotCount'))
ck('focus arrival separated from row motion', 'private var coordinatedFocusArrivalAnimation: Bool' in rail and 'animateFocusArrival: coordinatedFocusArrivalAnimation' in rail)
ck('focus arrival forbidden during surface handoff', '!unityAnimations.surfaceHandoffActive' in section(rail,'private var coordinatedFocusArrivalAnimation','private var coordinatedPulseAnimation'))
ck('focused-card geometry spring disabled during surface handoff', 'animateFocusGeometry: !surfaceVisualFocusPinned' in rail and '.animation(animateFocusGeometry ? .spring(response: 0.36, dampingFraction: 0.86) : nil, value: focused)' in APP)
ck('48 row motion owner remains separate', 'private var coordinatedRailAnimations: Bool' in rail and 'UnityCatalogRowMotionStyle.animation' in rail)

profile=section(RUNTIME,'func catalogTransitionProfile','/// A repeat-heavy Siri Remote burst')
# Exact timing invariants: hidden preflight >= 2 frames at 60 Hz; close focus after fade.
ck('open hidden preflight is two 60Hz frames', 'preflight: 0.034' in profile)
ck('open visible duration retained 0.22', 'visibleDuration: 0.22' in profile)
ck('open focus bind occurs before visible animation', 'focusBind: 0.0' in profile)
ck('close visible duration retained 0.20', 'visibleDuration: 0.20' in profile)
ck('close Live TV focus waits until catalog invisible', 'focusBind: 0.220' in profile)
ck('close branch pixels finish before focus handoff', 'branchSettle: 0.205' in profile and profile.find('branchSettle: 0.205') < profile.find('focusBind: 0.220'))

# vBRDC108 real-logo and Media Profile fixes remain.
footer=section(APP,'private var footerChannelIcon: some View','private func focusedTimelineSummary')
ck('real Live TV logo still wins over text', 'fallbackText: channel.logo' in footer and 'Text(channel.logo)' not in footer)
constants=section(APP,'@State private var stageBackdropVisible','private let sourceIntelligencePageSize')
ck('Media Profile 0.20s handoff retained', 'private let detailStageTransitionDuration: Double = 0.20' in constants)

# vBRDC107-vBRDC103 prior accepted invariants.
ck('v107 focused preview ownership retained', 'if focusedCardPreviewKey == requestedKey,' in APP and 'focusedCardPreviewRequestedKey == requestedKey' in APP)
ck('trailer remains explicit focused-preview stop owner', '.debridTrailerExclusivePlaybackDidBegin' in APP)
ck('v106 cast seven-second rotation retained', '7_000_000_000' in APP and 'vBRDC106-production-rotation' in APP)
ck('v105 Live TV 3s/15s preview retained', 'liveTVGridFocusPreviewEnabledV1' in APP and '3_000_000_000' in APP and '15_000_000_000' in APP)
ck('v104 persistent catalog shell retained', '@State private var unityPersistentCatalogTab: AppTab = .home' in APP)
ck('v103 persistent rail retained', 'persistentRailMotionPhase' in APP and 'commitPersistentHorizontalMove' in APP)
ck('48-motion visual source exists', (ROOT/'Sources/UnityCatalogVisualSystem.swift').exists())

failed=[n for n,o in checks if not o]
for n,o in checks: print(('PASS' if o else 'FAIL'), n)
print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed')
if failed: print('Failed: '+', '.join(failed))
sys.exit(1 if failed else 0)
