# Debrid Channels vBRDC076 — Playback Priority Recovery

Release ID: **vBRDC076**  
Marketing version: **1.0.779**  
Apple build: **779**

Built only from packaged **vBRDC075**.

## Physical-device symptom addressed

During main VOD playback, audio could continue while video presentation visibly froze/stalled. The problem could be exposed while the VOD overlay/cache-ahead UI was visible.

## Corrective scope

- Buffer/cache-ahead telemetry is now hard-throttled to one publication per second and meaningful buffer jumps may no longer bypass that gate.
- Hidden VOD controls receive **zero** `bufferedPlaybackSeconds` SwiftUI state mutations.
- Visible playback snapshots are capped at 1 Hz.
- Opening the VOD overlay while video is actively playing no longer launches review/production/runtime metadata network work.
- Decorative metadata work is cancelled whenever active playback resumes and is allowed to enrich while paused.
- VOD controls show/hide without a whole-overlay opacity transition while video is playing; paused playback retains the polished transition.
- Up Next metadata/network preparation is removed from first-frame startup and begins only inside the final six minutes (or at natural EOF). Existing final source-preparation timing remains bounded near episode end.
- Automatic resume/cache format, Source Intelligence providers, Fanart restoration, Appearance controls, Sports/UNITY and backend runtimes are retained.

## TorBox note

TorBox Usenet discovery remains dependent on TorBox Search API authorization/IP whitelisting. This playback release does not claim to resolve the pending external whitelist requirement.

## Validation

- vBRDC076 corrective contracts.
- All 62 Swift app/TopShelf files syntax parsed.
- Inherited backend suites: 35/35 passed.
- ZIP integrity and SHA-256 generated after packaging.
