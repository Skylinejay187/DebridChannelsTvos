# Debrid Channels vBRDC086 — Favorites Identity Handoff Lock

**Marketing version:** 1.0.789  
**Apple build:** 789  
**Release ID:** vBRDC086  
**Donor:** packaged vBRDC085 only

## Physical-test regression targeted

After returning from Favorites to Home/Movies/Shows, the catalog hero could continue showing the title/artwork identity of the previously selected Favorite until a new catalog card received a manual focus move. The same stale identity could survive a Favorites-origin playback/detail round trip.

### Root cause

Favorites intentionally reuses `GridOSFixedSlotCatalogRail`, but the rail was marking every opened card with `quickPanelRestoreSection = "streamingCatalog"`. `CatalogStore.closeDetail()` used that marker to decide whether a detail hero anchor should stay pinned while catalog focus restored. Because a Favorites card looked like a normal streaming-catalog card to that retention check, its `detailPresentationAnchorItem` and restore tokens could survive beyond the Favorites surface.

When Home/Movies/Shows mounted, `GridOSCatalogOverlay.focusedBackdropItem` preferred the still-pinned detail anchor over the newly focused catalog row. Moving/clicking another card finally replaced the visible identity, which is why the old Favorite title disappeared only after user interaction.

## vBRDC086 corrections

### 1. Favorites receives a dedicated restore owner

The shared rail now assigns:

- `favoritesCatalog` for `catalog-favorites-quick-panel`
- `streamingCatalog` only for the shared Home/Movies/Shows catalog surface

Favorites detail presentation continues to use `DetailPresentationOrigin.favorites`.

### 2. Hero-anchor retention is catalog-only

`CatalogStore.closeDetail()` now retains a detail hero anchor only when all of the following are true:

- the closing detail origin is `.catalog`
- the restore owner is `streamingCatalog`
- the restore row is not `catalog-favorites-quick-panel`
- the restored item canonically matches the closing item

A Favorites-origin detail therefore releases its anchor and all Favorites restore tokens immediately when Details closes.

### 3. Dedicated Favorites navigation scrub

A centralized `clearFavoritesPresentationStateForNavigation(reason:)` invalidates Favorites-owned transient presentation state when leaving Favorites. It clears/cancels:

- detail async generation
- selected detail
- detail hero anchor and premium backdrop
- detail back stack
- active Source Intelligence state when present
- all quick-panel restore identity fields
- top-menu/focus locks owned by the departing Favorites presentation

The scrub is enforced both by the Favorites local Exit path and by the Root tab handoff, covering Back, top-menu navigation, and post-playback surface exits.

### 4. Same-frame catalog rendering fail-safe

`GridOSCatalogOverlay` now refuses to consume a detail anchor when any Favorites ownership marker is present. This is intentionally redundant with the store cleanup so a same-frame tab transition cannot briefly paint stale Favorite title/artwork before lifecycle callbacks settle.

## Regression locks retained from vBRDC085

- Find Links automatic resume still sends an explicit KSPlayer Play assertion after the saved seek is confirmed.
- The bounded post-seek liveness recovery remains unchanged.
- Real user Pause remains authoritative.
- Production metadata remains independent from Play/Pause and begins after first frame at background priority.
- Resume cache format, Source Intelligence, TorBox/Usenet, UNITY coordinators, and Production metadata service are unchanged.

## Validation completed

- 64/64 vBRDC086 targeted contract checks passed.
- 64 Swift files passed `swiftc -parse` with 0 failures.
- App/Top Shelf plist and `project.yml` align at vBRDC086 / 1.0.789 / 789.
- Backend regression suites passed: 35 tests + 2 subtests.
- vBRDC085 playback/resume/Production bridge files and other sensitive unrelated systems are SHA-256 locked unchanged.
- Package hashes and ZIP integrity are verified before delivery.

GitHub Actions/Xcode remains the authoritative Apple SDK compile; physical Apple TV testing remains authoritative for focus-engine timing.
