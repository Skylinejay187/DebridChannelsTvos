# App-Wide Regression Locks — vBRDC117

vBRDC117 changes only the standard VOD Bluetooth/headset media-control eligibility layer.

Locked behavior:

- vBRDC116: focused catalog preview remains 1.5-second dwell + maximum 35-second muted preview, no loop.
- vBRDC115: MediaFlow LAN Live TV routing remains unchanged.
- vBRDC113: VOD SwiftUI type-check containment remains intact.
- vBRDC109: single-owner catalog open/close transition remains unchanged.
- vBRDC103: persistent catalog row scrolling engine and accepted row motions remain unchanged.
- vBRDC106: VOD Cast/Production visible-only cycling remains unchanged.
- vBRDC105: Live TV focus preview behavior remains unchanged.
- Dynamic Wallpaper, Sports, Favorites, Gracenote/provider data model, playback resume, debrid/Usenet, Source Intelligence, and backend runtimes are unchanged.

New locked VOD media-control contract:

1. A movie/show VOD session explicitly activates a playback/movie audio session.
2. A movie/show VOD session publishes valid Now Playing metadata while active.
3. `MPRemoteCommandCenter` owns Bluetooth/accessory Play, Pause, and Toggle Play/Pause commands only while a VOD session is active and the setting is enabled.
4. The VOD Now Playing record follows play/pause and bounded timeline progress.
5. VOD teardown clears its Now Playing record and releases its owned audio-session activity.
6. Live TV and non-VOD surfaces never claim this VOD media-command ownership.
7. Siri Remote / SwiftUI Play-Pause remains supported and duplicate delivery is suppressed.
