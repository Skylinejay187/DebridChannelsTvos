# Debrid Channels vBRDC088 — App-Wide Scroll Frame Budget Recovery

**Marketing version:** 1.0.791  
**Apple build:** 791  
**Release ID:** vBRDC088  
**Donor:** packaged vBRDC087 only

## Why this build exists

Physical testing reported that scrolling/navigation felt sluggish across the app even with **Dynamic Wallpaper disabled** and regardless of the visual Performance Mode. The audit confirmed that wallpaper was not the main baseline bottleneck. Several unrelated focus/render/data paths were consuming the frame budget during normal D-pad navigation.

vBRDC088 is deliberately a **no-redesign performance build**. It changes scheduling, allocation, decode size, and ownership boundaries while preserving the current visual system.

## Main root causes corrected

### 1. O(n) catalog-row allocation on every horizontal focus move

The fixed catalog rail first copied the **entire remaining row** into a new Array and only afterward calculated that the viewport needed a small number of trailing poster cards.

vBRDC088 calculates the required card count first and copies only that visible slice. Card ordering, number of rendered cards, shrinking-poster geometry, transitions, and navigation behavior stay the same.

### 2. Animated focused-card geometry was invalidating RootView

The Media Information connector measured `proxy.frame(in: .global)` from inside the focused card. That same subtree performs the Search-style focus bounce and optional repeat-forever Pulse scale.

The frame preference now comes from a stable invisible fixed-slot reporter outside the animation subtree, preserving the existing resting `-6` position. Root also ignores identical frame publications. Pulse/bounce remain visually unchanged, but they no longer have a path to repeatedly rewrite root geometry state.

### 3. Small cards were decoding original-resolution artwork

TMDB artwork continues to request the established `/original/` source URL. The problem was the **decoded bitmap**, not the selected artwork: small catalog/Search cells could decompress multi-megapixel originals and upload those full textures while focus was moving.

`RemoteImageFit` now supports a URL+decode-budget cache key. Only high-churn card surfaces opt into display-bounded ImageIO decoding, with caps far above their visible dimensions. Full-screen/default callers retain the exact original-resolution decode path.

- Search card: 1024 px
- focused catalog card: 1280 px
- trailing portrait card: 640 px
- focused card logo: 768 px

This preserves source selection, crop/fit, interpolation, transitions, and full-screen quality while reducing decode memory/texture pressure during scrolling.

### 4. Hidden Live TV work could run behind catalog surfaces

The Live TV root intentionally remains mounted behind Home/Movies/Shows for the UNITY visual system. vBRDC087 still started `refreshIfNeeded()` on that mount and allowed Live TV speculative artwork prefetch on Home/Movies/Shows.

vBRDC088 keeps cached/demo Live TV visual state mounted, but expensive provider/guide refresh and speculative artwork prefetch run only when **Live TV or Sports actually owns the active surface**. Leaving those tabs cancels hidden refresh/prefetch/boundary work without deleting the cached visual donor.

### 5. Live TV focus performed persistence and EPG work per tile

- `liveTVLastSelectedChannelID` was written through AppStorage on every selected-channel change. It is now coalesced for 450 ms and flushed immediately when playback actually starts.
- EPG boundary scheduling no longer rescans the rendered channel window for each tile. It is tied to virtual-window/guide/boundary changes instead.
- The duplicate virtual-window update in `tileFocus` was removed.

### 6. Live TV rebuilt provider channel projections during focus rendering

Category names, HD filtering, and exact category filtering were derived from the complete provider lineup during SwiftUI body evaluation. With large IPTV lineups, a simple focus move could therefore rescan thousands of channels.

`LiveTVSourceModel` now builds category/HD/channel-identity indexes only when the provider publishes a new channel array. Focus passes read the stable indexes. My Favorites uses indexed identity/order lookup instead of a full-lineup filter.

## Visual/behavior lock

No dimensions, spacing, fonts, colors, theme effects, Pulse timing/amplitude, focused-card preview presentation, row animation, dynamic wallpaper, Search layout, Favorites layout, Media Information layout, Live TV card design, or Quick Guide design were changed.

The vBRDC087 artwork-owner/Pulse isolation locks remain intact, along with vBRDC086 Favorites identity handoff and vBRDC085 Find Links resume/autoplay + Production metadata decoupling.

## Validation

- vBRDC088 regression/performance contract: **80/80 passed**
- Swift syntax parse: **64/64 passed**
- Backend regression suites: **35 tests passed + 2 subtests passed**
- Version alignment: **vBRDC088 / 1.0.791 / 791**
- Sensitive playback/resume/Production/Source Intelligence/TorBox/Usenet/UNITY coordinator sources not targeted here are SHA-256 donor-locked to packaged vBRDC087.

See `PERFORMANCE_AUDIT_vBRDC088.txt` for the detailed frame-budget audit and physical test matrix.

GitHub Actions/Xcode remains the authoritative Apple SDK compile. Physical Apple TV testing remains authoritative for frame pacing and focus-engine timing.
