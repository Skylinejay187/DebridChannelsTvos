# vBRDC063 Matched Frame A/V Sync — Compile Fix

- Release ID: **vBRDC063**
- Marketing version: **1.0.766**
- Apple build: **766**
- Backend: **v693 unchanged**

## Correction
The first vBRDC063 package updated the main app and Xcode target metadata to 1.0.766 (766), but `TopShelfExtension/Info.plist` was accidentally left at vBRDC062 / 1.0.765 (765). The V1041 production configuration validation correctly rejected the build before linking.

This package changes only the Top Shelf extension release/version metadata to match the main app:
- `CFBundleShortVersionString`: 1.0.765 -> 1.0.766
- `CFBundleVersion`: 765 -> 766
- `DebridChannelsReleaseID`: vBRDC062 -> vBRDC063

No Swift source, KSPNUVIO source, matched-frame A/V-sync logic, VOD buffer/cache behavior, scrubber ghost behavior, Unity navigation, TorBox Usenet work, or backend code was changed by this compile correction.
