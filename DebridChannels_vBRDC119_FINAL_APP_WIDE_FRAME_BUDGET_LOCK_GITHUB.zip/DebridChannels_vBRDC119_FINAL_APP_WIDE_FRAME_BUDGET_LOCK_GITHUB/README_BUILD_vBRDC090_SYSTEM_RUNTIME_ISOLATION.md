# Debrid Channels vBRDC090 — SYSTEM RUNTIME ISOLATION

**Marketing version:** 1.0.793  
**Apple build:** 793  
**Donor:** packaged vBRDC089 only

## Purpose

vBRDC090 is a system-wide frame-budget correction. It does **not** redesign the UI or remove user-facing visual features. The goal is to stop hidden surfaces, background publications, image completion, repeat-forever decoration, and focus motion from competing for the same Siri Remote frame.

## Root cause audit

The previous app could remain sluggish even with Dynamic Wallpaper disabled because the main cost was not one wallpaper renderer:

- Home / Movies / TV Shows kept a complete reactive `LiveTVScreen` mounted underneath their translucent catalog shelves. `.disabled(true)` stopped input, but it did not stop SwiftUI invalidation, EPG/model observation, focus-tree maintenance, artwork state, or the 96-card Live TV hierarchy from recomputing.
- Sports did the same thing underneath its SportsHub lane.
- `CatalogStore.status` was `@Published` even though rendered views do not directly display it. It changes throughout catalog/provider/source/playback operations, so harmless diagnostic text could invalidate every `CatalogStore` observer.
- focused-card arrival, row motion, Pulse, preview, wallpaper, ticker, and image completion could all publish or animate in the same navigation burst.
- global ticker rotation used recursively scheduled `DispatchQueue.main.asyncAfter` chains; item changes could start another chain instead of cancelling the old one.
- the SportsCenter crawl used an uncancellable `repeatForever` transaction.
- Live TV program-art decode completion could publish during the exact frame the Focus Engine was resolving another tile.

## vBRDC090 runtime changes

### 1. Frozen inactive Live TV visual donor

Home / Movies / TV Shows / Sports now render `FrozenLiveTVBackdrop` behind their overlays instead of a second active `LiveTVScreen`.

The donor:

- uses cached real Live TV channel data;
- opens around the last-selected channel row so the visible grid identity remains familiar;
- uses the existing Live TV tile artwork/style implementation;
- has no `CatalogStore` subscription;
- owns no focus state;
- owns no provider refresh;
- owns no EPG scheduler;
- owns no Live TV prefetch corridor;
- owns no preview player;
- owns no Live TV persistence writes.

The real `LiveTVScreen` now mounts only when Live TV itself owns the surface.

### 2. System navigation Motion Runtime

`UnityAnimationCoordinator` now has an app-wide navigation-burst lane.

A D-pad burst is one focus transaction. Repeated remote events only extend the settle deadline and do not publish another coordinator revision on every repeat.

During the burst, navigation-critical lanes stay enabled while decorative/media-adjacent lanes yield:

- allowed: catalog row/focus arrival, Live TV focus, Guide focus, Sports focus, overlay chrome, alerts;
- yielded: focused-card Pulse, focused-card preview, dynamic wallpaper motion, detail/source transition motion, global ticker motion.

### 3. Wallpaper remains mounted; only motion pauses

Dynamic Live Wallpaper is no longer repeatedly dismantled/recreated just because another lane temporarily owns frame budget. On Live TV, the wallpaper surface remains mounted and freezes its Timeline/GIF/video motion during a navigation burst, then resumes after focus settles.

### 4. Focus arrival no longer fights held scrolling

The Search-style focused-card arrival bounce remains visually intact, but intermediate cards do not each launch their own bounce while the user is still holding LEFT/RIGHT. Only the final settled focused card replays the existing bounce.

### 5. Noncritical image publication waits for focus settle

`PremiumRemoteImageLoader` still fetches and decodes off the critical path and immediately caches the result, but it can defer the SwiftUI `@Published` image mutation during active navigation/source handoff/playback ownership. Stale completions are dropped by URL/key identity.

The existing Live TV bounded artwork loader follows the same rule for decoded program/channel artwork.

### 6. Remove global invalidation from operational status

`CatalogStore.status` is now ordinary state instead of `@Published` state. It remains fully available to resolver/error logic, but changing an operational status sentence can no longer invalidate every catalog/Live TV/settings observer.

### 7. Ticker runtime cleanup

- Movies/Shows release ticker rotation uses a cancellable SwiftUI task instead of self-recursing `asyncAfter` chains.
- compact Sports ticker uses the same cancellation model.
- SportsCenter continuous crawl uses a paused `TimelineView` instead of an uncancellable `repeatForever` offset transaction.
- ticker surfaces remain visually mounted when appropriate; only their motion yields to a higher-priority navigation lane.

### 8. Dead/duplicate runtime cleanup

- removed unused `artwork3CatalogOverlayActive` state;
- removed empty `reconcileWallpaperRenderOwnership` path/calls;
- consolidated duplicate Live TV guide visibility observer work;
- removed a redundant inner Live TV tile scale animation while preserving the exact previous final focused scale at the single outer transform;
- removed unused HeroLogo repeat-forever pulse machinery (every active call site already passed `pulse: false`);
- Live TV artwork corridor no longer contains obsolete Home/Movies/Shows ownership branches.

## Visual locks

No intentional changes to:

- catalog card dimensions or spacing;
- Search-style focused-card resting geometry;
- Pulse amplitude/speed once navigation is settled;
- focused-card preview appearance;
- Dynamic Wallpaper themes;
- Live TV card design, guide design, artwork fallback, or Frosted Edges/full-card option;
- Sports visual design;
- Media Information layout;
- VOD overlay design;
- playback engines/resume behavior;
- In-S / FebBox implementation from vBRDC089 (vBRDC091 is the separate provider-runtime correction).

## Expected physical result

The important test is not only “wallpaper off vs on.” Rapid scrolling across Home, Movies, TV Shows, Search, Favorites, Sports, and Live TV should have a much more consistent baseline because hidden Live TV and background publications no longer compete with focus ownership.

This build is designed to scale with faster future Apple TV hardware, but it does not depend on future hardware to hide current architectural waste.
