# vBRDC067 — UNITY Card Cleanup + Franchise Artwork Fit

- Release ID: **vBRDC067**
- Marketing version: **1.0.770**
- Apple build: **770**
- Code Name: **UNITY**
- Built only from packaged **vBRDC066**
- Backend target: **v693 unchanged**

## Scope

vBRDC067 is a physical-UI correction over vBRDC066. It does not redesign navigation or alter playback/cache behavior.

### 1. Remove meaningless catalog-card status ornaments

The small top-left dash, focused-card top-right dot, and lower accent rail introduced with the vBRDC066 Unity card chrome were decorative only. They did not represent playback, cache state, progress, provider state, or any actionable status and could therefore be misread as indicators.

vBRDC067 removes those ornaments from focused and trailing cards while retaining the new rounded glass/chrome edge, title-specific accent, subtle specular treatment, focus depth, Search-style bounce, and existing card geometry.

### 2. Franchise shelf now preserves complete artwork and title identity

The franchise animation/ribbon remains. Its presentation is corrected so collection titles do not look cropped:

- collapsed stack thumbnails use **aspect fit** rather than crop-to-fill;
- expanded franchise cards use complete poster/landscape artwork with aspect fit;
- every expanded card has a dedicated title strip and year when available, so the title remains readable even when a provider logo/artwork asset is unusual;
- the focused shelf is slightly taller and rises farther upward, preserving the compact 66pt resting footprint and avoiding catalog-row reflow.

The current compact Media Information surface remains; the retired full-screen information screen is not restored.

### 3. Focused-card preview is visual-only

The **PREVIEW 🍿** badge/status capsule is removed while the focused-card preview video is playing. Preview resolution, mute behavior, one-shot lifecycle, artwork fallback, focus ownership, and teardown behavior are unchanged.

## Preserved vBRDC066 fixes/features

- Search return from VOD no longer sticks in an indefinite search state.
- Search hydration preserves franchise metadata.
- Compact upward-expanding franchise ribbon remains.
- Unity hero/title aura and catalog glass treatment remain.
- vBRDC065 XMLTV watchdog correction remains.
- vBRDC064 KSPNUVIO IDET crash fix remains.
- vBRDC063 matched-frame A/V correction remains.
- vBRDC062 instant VOD + buffer ghost remains.
- vBRDC061 300-second forward buffer maximum remains.
- Backend v693 remains unchanged.

## Validation in this environment

- All Swift source files are parsed with `swiftc -frontend -parse`.
- App + Top Shelf plists are validated and version-matched.
- vBRDC067 UI regression contract checks the card ornament removal, franchise aspect-fit/title strip, Preview badge removal, and preservation of Search/XMLTV fixes.
- Playback/KSP/provider files are hash-locked against packaged vBRDC066.
- Final ZIP integrity is checked after packaging.

GitHub Actions/Xcode remains the authoritative Apple-platform compile, followed by physical Apple TV testing.
