# Debrid Channels vBRDC064 — KSPNUVIO IDET Crash Fix

- Release ID: `vBRDC064`
- Marketing version: `1.0.767`
- Apple build: `767`
- Code Name: `UNITY`
- Base: packaged corrected `vBRDC063`
- Backend: `v693` unchanged

## Physical crash root cause

The supplied tvOS `.ips` crash from vBRDC063 reports `EXC_BREAKPOINT / SIGTRAP` on the `KSPlayer_vide` thread. The faulting symbol is `KSOptions.filter(log:)`, called from FFmpeg logging during `FFmpegDecode.decodeFrame`.

Pinned KSPNUVIO stores auto-deinterlace (`idet`) vote counters in `UInt` and performs expressions such as `progressive - tff - bff`. A normal vote ordering can therefore attempt unsigned subtraction below zero and Swift traps the process.

## vBRDC064 correction

`Scripts/patch_kspnuvio_idet_overflow_vBRDC064.py` is applied to the exact audited pinned KSPNUVIO source during the existing XcodeGen pre-generation vendor step.

- Changes the private `idetTypeMap` counter value from `UInt` to `Int`.
- Saturates each detector vote at 1,000,000 before the existing lead calculations. This keeps all existing detector thresholds/semantics while making the arithmetic bounded and signed.
- Leaves automatic deinterlacing enabled.
- Does not change decoder selection, audio clocks, frame-rate matching, VOD buffer duration, instant-start behavior, the buffer ghost, Live TV, trailers, Source Intelligence, TorBox, or backend behavior.

The KSPNUVIO fetch pipeline remains pinned to commit `69a73e5e22184c6db254eb2919f81768afb57a81`; vBRDC064 only layers this deterministic source patch on top of the existing v995/vBRDC043/vBRDC049 patches.
