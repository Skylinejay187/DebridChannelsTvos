Debrid Channels tvOS v51 TRUE SPLIT DETERMINISTIC

This package intentionally builds only source_zip/DebridChannelsTVOS_Source_v51_DETERMINISTIC_SPLIT.zip so stale older source zips in the repository cannot be selected by mistake.

Run GitHub Actions workflow:
00 Build tvOS IPA From Source ZIP v51 ONLY

After build, extract the artifact ZIP and upload only DebridChannelsTVOS_v51_UPLOAD_THIS_IPA.ipa to your signer.
