# Debrid Channels tvOS Build Repo

Upload `DebridChannelsTVOS_Source_BuildReady_v3.zip` to this repo root and run the workflow:

`00 Build tvOS IPA From Source ZIP`

The workflow installs XcodeGen, generates the Xcode project from `project.yml`, builds unsigned for tvOS, and uploads an unsigned IPA artifact.
