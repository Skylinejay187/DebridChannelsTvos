# Debrid Channels tvOS

Upload this repo package contents to GitHub with `source_zip/DebridChannelsTVOS_Source.zip` and run **00 Build tvOS IPA From Source ZIP**.

The workflow extracts the source zip, generates the Xcode project with XcodeGen, builds the tvOS app unsigned, then uploads an unsigned IPA artifact.
