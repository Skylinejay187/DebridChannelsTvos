Debrid Channels tvOS v80 V73 Real App Wiring

Upload this repo ZIP to GitHub. It preserves the approved v73 home/detail layout and adds:
- brand-new isolated Apple-style VOD overlay with no Debrid logo
- selectable detail buttons, stream links, and More Like This
- back-stack detail navigation
- ambient-only home background by default; preview video can become background
- slow continuous right poster float
- universal tvOS device workflow
