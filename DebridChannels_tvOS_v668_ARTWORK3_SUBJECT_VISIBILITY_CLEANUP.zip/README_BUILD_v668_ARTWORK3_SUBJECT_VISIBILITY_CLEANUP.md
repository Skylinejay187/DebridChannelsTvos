# Debrid Channels tvOS v668 - Artwork 3 Subject Visibility Cleanup

Build name: DebridChannels_tvOS_v668_ARTWORK3_SUBJECT_VISIBILITY_CLEANUP

Base: v667 Artwork 3 Detail Visibility and Artwork 4 Hero Fullscreen.

Scope:
- Artwork 3 Hero catalog overlay only.

Changed:
- Removed the Artwork 3 Hero catalog overlay ghost layer.
- Removed the catalog overlay path that selected a logo/landscape/poster for the oversized ghost layer.
- Artwork 3 now enhances the focused artwork background itself instead of rendering a second oversized logo/title/artwork layer.

Preserved:
- Artwork 3 transparent catalog panel.
- Artwork 3 subject visibility tuning from v667:
  - higher artwork opacity
  - increased saturation
  - increased contrast
  - existing cinematic dark masks
- Artwork 4 Hero 2 behavior from v667 was not modified.
- Favorites keeps its existing hero ghost behavior.
- Backend, trailers, Live TV playback, VOD playback, guide, details popup, search, alerts, Sports, Source Intelligence, and catalog loading logic were not modified.
