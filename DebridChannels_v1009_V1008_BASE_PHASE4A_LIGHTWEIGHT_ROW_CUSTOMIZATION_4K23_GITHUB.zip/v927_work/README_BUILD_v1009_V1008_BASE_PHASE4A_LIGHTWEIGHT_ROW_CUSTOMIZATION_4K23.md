# Debrid Channels v1009 — Phase 4A

Base: v1008.

## Lightweight in-app All-in-One row customization

Added under:

`Settings → Streaming Catalogs → Customize All-in-One Rows`

Per-device controls are intentionally limited to:

- Show or hide an individual built-in row.
- Move a focused row up or down with left/right.
- Reset all row visibility and ordering to the official server defaults.
- Keep the master All-in-One Catalogs On/Off toggle.

The editor is a text-only list. It does not render posters, start previews, refetch catalogs, or rebuild the visible catalog screen while the editor is open. The resulting visibility/order is applied to the already loaded built-in rows and persisted in UserDefaults.

The hidden built-in endpoint remains:

`https://catalog.skylinejay187.it.com/manifest.json`

Personal catalog URLs remain separate and are used when All-in-One Catalogs is off.

## Playback adjustment

- 4K decoded-frame queue changed from 25 to 23.
- 1080p remains 24.
- Lower resolutions remain 16.
- No cadence, clock, decoder mode, subtitle, overlay, trailer, Live TV, or Source Intelligence setting was changed.

## Performance ticker defaults

- Sports Score Ticker defaults to Off.
- Movies & Shows Release Ticker now also defaults to Off.
- A one-time v1009 migration turns both tickers off for existing installs, while preserving the ability to enable either toggle afterward.
- When the sports ticker is off, its global sports schedule/highlight network load is skipped during app bootstrap.
- No Sports Hub screen, Live TV, catalog, or playback feature was removed.

## Deferred phases

- Phase 4B: unified fast Search using the local built-in catalog database, Cinemeta, and TMDB with deduplication.
- Phase 4C: optional muted focused-card previews, off by default, one short preview per stable focus.

## Version

- Marketing version: 1.0.537
- Build: 537
