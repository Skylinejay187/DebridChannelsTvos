
import Foundation
import SQLite3

// v301: Lightweight native SQLite cache for extreme Live TV scale.
// This is intentionally dependency-free so GitHub Actions/XcodeGen does not need
// another package. The UI can page from this cache instead of holding 50,000+
// channels and full XMLTV rows in one Swift Array.
final class LiveTVSQLiteCache {
    static let shared = LiveTVSQLiteCache()
    private var db: OpaquePointer?
    private let queue = DispatchQueue(label: "DebridChannels.LiveTVSQLiteCache", qos: .userInitiated)

    private init() { open() }
    deinit { if db != nil { sqlite3_close(db) } }

    private func open() {
        guard db == nil else { return }
        let folder = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        let fileURL = folder.appendingPathComponent("debridchannels_live_tv.sqlite")
        guard sqlite3_open(fileURL.path, &db) == SQLITE_OK else { return }
        sqlite3_exec(db, "PRAGMA journal_mode=WAL;", nil, nil, nil)
        sqlite3_exec(db, "PRAGMA synchronous=NORMAL;", nil, nil, nil)
        sqlite3_exec(db, """
        CREATE TABLE IF NOT EXISTS channels(
            id INTEGER PRIMARY KEY,
            number TEXT,
            name TEXT,
            logo TEXT,
            category TEXT,
            stream_url TEXT,
            icon_url TEXT,
            tvg_id TEXT,
            source TEXT,
            now_title TEXT,
            next_title TEXT,
            description TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_channels_category ON channels(category);
        CREATE INDEX IF NOT EXISTS idx_channels_number ON channels(number);
        CREATE INDEX IF NOT EXISTS idx_channels_source ON channels(source);
        CREATE TABLE IF NOT EXISTS epg(
            channel_key TEXT,
            title TEXT,
            start_ts REAL,
            end_ts REAL,
            description TEXT,
            image_url TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_epg_channel_time ON epg(channel_key, start_ts, end_ts);
        """, nil, nil, nil)
    }

    func replaceChannels(_ channels: [LiveTVChannel]) {
        queue.async { [weak self] in
            guard let self, let db = self.db else { return }
            sqlite3_exec(db, "BEGIN IMMEDIATE TRANSACTION; DELETE FROM channels;", nil, nil, nil)
            let sql = "INSERT OR REPLACE INTO channels(id,number,name,logo,category,stream_url,icon_url,tvg_id,source,now_title,next_title,description) VALUES(?,?,?,?,?,?,?,?,?,?,?,?);"
            var stmt: OpaquePointer?
            if sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK {
                for ch in channels {
                    sqlite3_bind_int64(stmt, 1, sqlite3_int64(ch.id))
                    bind(stmt, 2, ch.number); bind(stmt, 3, ch.name); bind(stmt, 4, ch.logo); bind(stmt, 5, ch.category)
                    bind(stmt, 6, ch.streamURL); bind(stmt, 7, ch.iconURL); bind(stmt, 8, ch.tvgID); bind(stmt, 9, ch.source)
                    bind(stmt, 10, ch.now); bind(stmt, 11, ch.next); bind(stmt, 12, ch.description)
                    sqlite3_step(stmt); sqlite3_reset(stmt)
                }
            }
            sqlite3_finalize(stmt)
            sqlite3_exec(db, "COMMIT;", nil, nil, nil)
        }
    }

    func fetchChannels(category: String, limit: Int, offset: Int) -> [LiveTVChannel] {
        queue.sync {
            guard let db else { return [] }
            let all = category == "All"
            let sql = all
                ? "SELECT id,logo,number,name,category,now_title,next_title,description,stream_url,icon_url,tvg_id,source FROM channels ORDER BY CAST(number AS REAL), name LIMIT ? OFFSET ?;"
                : "SELECT id,logo,number,name,category,now_title,next_title,description,stream_url,icon_url,tvg_id,source FROM channels WHERE category=? ORDER BY CAST(number AS REAL), name LIMIT ? OFFSET ?;"
            var stmt: OpaquePointer?
            var out: [LiveTVChannel] = []
            guard sqlite3_prepare_v2(db, sql, -1, &stmt, nil) == SQLITE_OK else { return [] }
            if all { sqlite3_bind_int(stmt, 1, Int32(limit)); sqlite3_bind_int(stmt, 2, Int32(offset)) }
            else { bind(stmt, 1, category); sqlite3_bind_int(stmt, 2, Int32(limit)); sqlite3_bind_int(stmt, 3, Int32(offset)) }
            while sqlite3_step(stmt) == SQLITE_ROW {
                out.append(LiveTVChannel(
                    id: Int(sqlite3_column_int64(stmt, 0)), logo: text(stmt, 1), number: text(stmt, 2), name: text(stmt, 3), category: text(stmt, 4),
                    now: text(stmt, 5), next: text(stmt, 6), description: text(stmt, 7), accent: LiveTVSourceModel.accent(for: text(stmt, 4)),
                    streamURL: text(stmt, 8), iconURL: text(stmt, 9), tvgID: text(stmt, 10), source: text(stmt, 11)))
            }
            sqlite3_finalize(stmt)
            return out
        }
    }
}

private func bind(_ stmt: OpaquePointer?, _ index: Int32, _ value: String) {
    sqlite3_bind_text(stmt, index, (value as NSString).utf8String, -1, unsafeBitCast(-1, to: sqlite3_destructor_type.self))
}
private func text(_ stmt: OpaquePointer?, _ index: Int32) -> String {
    guard let c = sqlite3_column_text(stmt, index) else { return "" }
    return String(cString: c)
}
