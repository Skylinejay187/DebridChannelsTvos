Stage 25: root entitlement transition to Settings-owned Find Signal for unconfigured users. Swift syntax only; tvOS compile pending. No domain integration.
