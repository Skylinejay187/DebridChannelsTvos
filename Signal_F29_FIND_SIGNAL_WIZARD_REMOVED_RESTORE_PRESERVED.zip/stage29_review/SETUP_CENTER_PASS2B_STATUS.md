# Signal Setup Center — Pass 2B
Base: Pass 2A source checkpoint.
Added provider-specific guided selection/instruction panel for Channels DVR, M3U/XMLTV, HDHomeRun, Xtream, Real-Debrid, TorBox, Torrentio, other Debrid providers and custom Stremio addons. Configuration uses the existing Settings editors; it does not claim new provider connectivity.
Added dedicated dark Smart Restore sheet with restore code entry, truthful active operation status, explicit replacement confirmation and safe pre-operation cancellation. Restore execution remains existing backend logic, not transactional. Once a restore starts, Close is disabled to avoid implying that dismissal cancels work.
No fake percentage, no automatic clearing, no changes to AetherEngine, scrolling, Classic View, or playlists.
Validation: Swift frontend parse succeeded. Full tvOS compile and real device testing pending. Further guided in-sheet credential forms, actual granular per-stage progress, and connection dashboard remain for Pass 3/Phase 5.
