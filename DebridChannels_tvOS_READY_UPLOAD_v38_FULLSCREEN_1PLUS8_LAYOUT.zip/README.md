# Debrid Channels tvOS v38

Ready-to-upload ZIP. Uses v14-compatible Signulous-safe packaging.

Build artifact IPA: DebridChannelsTVOS_v38_UPLOAD_THIS_IPA.ipa
