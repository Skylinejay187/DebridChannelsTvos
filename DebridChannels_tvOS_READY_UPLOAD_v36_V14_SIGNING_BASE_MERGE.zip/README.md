# Debrid Channels tvOS v36

This build intentionally restores the v14 source ZIP layout and v14 IPA packaging approach because that package signed successfully.

Upload the ZIP contents to GitHub, run `00 Build tvOS IPA From Source ZIP`, extract the artifact ZIP, then upload only `DebridChannelsTVOS_v36_UPLOAD_THIS_IPA.ipa` to Signulous.
