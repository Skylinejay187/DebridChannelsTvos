# Debrid Channels tvOS Build Repo

This repo contains the GitHub Actions workflow and embedded source zip. Run **00 Build tvOS IPA From Source ZIP** to generate an unsigned tvOS IPA artifact.

Current build: v7 careful project.yml verified package.
