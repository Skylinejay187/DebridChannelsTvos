# Debrid Channels vBRDC160 — Local Alternate Audio

- Release ID: `vBRDC160`
- Marketing version: `1.0.863`
- Apple build: `863`
- Exact donor/base: packaged `vBRDC159`

## Scope

This release replaces the active **Prepare & Use Audio Bridge** playback action with an on-device Alternate Audio path.

The currently playing VOD video URL remains the primary KSPlayer source. A selected compatible alternate copy is opened independently by KSPNUVIO's FFmpeg-based `KSMEPlayer` with video decode disabled. The discovered ffprobe audio stream is selected before decoder/audio-output creation, then the secondary audio clock follows the primary movie clock.

## Behavior

- `Use This Audio` starts the selected alternate audio locally on Apple TV.
- Original video URL/render surface is not replaced by a backend-generated HLS bridge.
- Alternate source provider headers are retained and forwarded.
- If MediaFlow is enabled for normal VOD routing, its existing routing policy remains available; no server-side Alternate Audio remux is required.
- Original audio stays audible while the secondary source opens and aligns.
- Secondary output remains silent during preparation; the primary is muted first, then aligned secondary audio becomes audible.
- Pause / Play follow the primary player.
- Main VOD seeks force a local secondary-audio resync.
- `-250 ms`, `+250 ms`, and Reset update the secondary clock directly and never rebuild a bridge.
- Drift greater than the bounded tolerance is corrected by seeking the secondary audio only.
- `Restore Original Audio` detaches the secondary decoder and restores original audio without recreating or seeking the primary video.
- If local audio fails or does not become ready within the bounded startup window, the original audio is restored.

## KSPNUVIO isolation

The secondary source uses `KSMEPlayer` directly rather than a second `KSPlayerLayer`. This avoids creating a second Now Playing / remote-command owner and keeps Bluetooth / Siri Remote transport ownership with the primary movie.

The selected ffprobe stream index is passed into a dedicated `KSOptions.wantedAudio` override so the correct audio decoder is chosen before KSMEPlayer prepares its audio output.

## Regression locks

- Live TV implementation remains byte-identical to vBRDC158/vBRDC159.
- No Live TV, HDHomeRun, MediaFlow Live TV, Gracenote/XMLTV, grid, Guide, page, channel-number, Search, Favorites, or VOD-logo behavior was intentionally changed by this release.
- Server-side Alternate Audio bridge functions remain only as legacy/diagnostic compatibility code; the active VOD action does not call bridge preparation or switch playback to a bridge HLS URL.

## Validation

- Targeted Alternate Audio contract: 53/53 passed.
- Production Swift parse: 65/65 files, 0 failures.
- Backend runtime suite: 36 tests passed + 2 subtests.
- App/TopShelf plist and project version values validated.
- Final ZIP integrity checked after packaging.

GitHub Actions / Xcode compile on the Apple toolchain remains authoritative for the tvOS build.
