from pathlib import Path
import plistlib, re, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+': '+name)

app=plistlib.load(open(root/'Sources/Info.plist','rb'))
top=plistlib.load(open(root/'TopShelfExtension/Info.plist','rb'))
proj=(root/'project.yml').read_text()
store=(root/'Sources/CatalogStore.swift').read_text()
play=(root/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
appsrc=(root/'Sources/DebridChannelsTVOSApp.swift').read_text()

for name,d in [('app',app),('topshelf',top)]:
    ck(name+' version', d.get('CFBundleShortVersionString')=='1.0.871')
    ck(name+' build', d.get('CFBundleVersion')=='871')
    ck(name+' release id', d.get('DebridChannelsReleaseID')=='vBRDC168')
ck('project marketing version', 'MARKETING_VERSION: 1.0.871' in proj)
ck('project build version', 'CURRENT_PROJECT_VERSION: 871' in proj)

ck('physical memory aware', 'ProcessInfo.processInfo.physicalMemory' in play)
ck('three memory tiers', all(x in play for x in ['case compact','case standard','case high']))
ck('explicit bitrate parser', 'explicitBitrateMbps' in play and 'mbps' in play and 'kbps' in play)
ck('size plus quality bitrate estimate', 'sourceSizeGB * 8_192.0' in play and 'qualityBitrateFloor' in play)
ck('runtime duration bitrate refinement', 'knownDurationSeconds' in play and 'duration-refined adaptive cache' in play)
ck('byte budget conversion', 'packetBudgetMiB * 8.388608 / safeBitrate' in play)
ck('4k is bitrate floor not fixed max', 'if is4K { return 18 }' in play)
ck('uncached source compensation', 'cache-health=uncached' in store and 'uncachedBudgetMiB' in play)
ck('low seeder threshold', '$0 <= 25' in play and 'lowSeederBudgetMiB' in play)
ck('seeder parser in source intelligence', 'sourceIntelligenceSeederCount' in store and '👤' in store and 'seeders?' in store)
ck('transport hint hidden from visible label', 'playbackAdaptiveCacheHint' in store and 'store.playbackAdaptiveCacheHint' in appsrc)
ck('adaptive hint includes raw addon transport metadata', 'source-meta=' in store)
ck('automatic failover refreshes cache hint', 'playbackAdaptiveCacheHint = matchedLink.sourceIntelligenceAdaptiveCacheHint' in store)
ck('manual VOD selected links forward adaptive hint', appsrc.count('adaptiveCacheHint: link.sourceIntelligenceAdaptiveCacheHint') >= 6)
ck('Up Next forwards adaptive hint', 'adaptiveCacheHint: rememberedLink?.sourceIntelligenceAdaptiveCacheHint ?? ""' in appsrc)
ck('memory warning emergency clamp', 'UIApplication.didReceiveMemoryWarningNotification' in play and 'min(options.maxBufferDuration, 30)' in play)
ck('live/trailer planner exclusion', 'let adaptiveVODCacheProfile = isVODStylePlayback' in play)
ck('CBS live max remains 12', 'options.maxBufferDuration = isLikelyCBSLiveTimingRisk' in play and '? 12' in play)
ck('KSME primary preserved', 'KSOptions.firstPlayerType = KSMEPlayer.self' in play)
ck('KSAV VOD fallback preserved', 'KSOptions.secondPlayerType = isVODStylePlayback ? KSAVPlayer.self : KSMEPlayer.self' in play)

if not all(v for _,v in checks):
    sys.exit(1)
