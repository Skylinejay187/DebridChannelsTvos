import Foundation

/// Release-candidate migration, profile-backup compatibility, and diagnostic redaction.
///
/// Profile backup is an explicit user action protected by a reusable restore code.
/// It must preserve the operational configuration needed on a replacement Apple TV,
/// including user-entered Live TV sources and provider credentials. Internal catalog
/// endpoints, entitlement state, owner state, diagnostics, and release-only values are
/// still excluded.
enum ReleaseCandidateSecurityManager {
    static let migrationVersion = 1

    private static let migrationKey = "releaseCandidateSecurityMigrationVersion"
    private static let publicBackendURL = "https://api.skylinejay187.it.com"
    private static let cinematetaManifestURL = "https://v3-cinemeta.strem.io/manifest.json"

    private static let officialCatalogMarkers = [
        "catalog.skylinejay187.it.com",
        "192.168.100.55:8484",
        "catalog.debridchannels"
    ]

    private static let sensitiveNames: Set<String> = [
        "api_key", "apikey", "api-key", "key", "token", "access_token",
        "auth", "authorization", "password", "pass", "username", "user",
        "realdebrid", "real_debrid", "torbox", "premiumize", "alldebrid"
    ]

    /// Runs before CatalogStore reads persisted manifests. It is idempotent and
    /// preserves every user preference that is not an obsolete internal endpoint.
    @discardableResult
    static func performUpgradeMigration(defaults: UserDefaults = .standard) -> [String] {
        let storedVersion = defaults.integer(forKey: migrationKey)
        guard storedVersion < migrationVersion else { return [] }

        var changes: [String] = []

        let savedManifests = defaults.stringArray(forKey: "stremioManifestURLs") ?? []
        let cleanedManifests = sanitizedSavedManifestURLs(savedManifests)
        if cleanedManifests != savedManifests {
            defaults.set(cleanedManifests, forKey: "stremioManifestURLs")
            changes.append("saved catalog list repaired")
        }

        if let primary = defaults.string(forKey: "stremioManifestURL"), isOfficialCatalogURL(primary) {
            defaults.set(cinematetaManifestURL, forKey: "stremioManifestURL")
            changes.append("legacy official catalog entry removed")
        }

        if let backend = defaults.string(forKey: "backendBaseURL")?.trimmingCharacters(in: .whitespacesAndNewlines),
           backend.isEmpty || backend.lowercased().contains("192.168.100.55:8181") {
            defaults.set(publicBackendURL, forKey: "backendBaseURL")
            changes.append("legacy backend migrated to public HTTPS")
        }

        defaults.set(migrationVersion, forKey: migrationKey)
        defaults.set(Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "unknown", forKey: "lastValidatedReleaseBuild")
        return changes
    }

    static func sanitizedSavedManifestURLs(_ urls: [String]) -> [String] {
        var output: [String] = []
        var seen = Set<String>()
        for raw in urls {
            let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, !isOfficialCatalogURL(clean), let url = URL(string: clean),
                  let scheme = url.scheme?.lowercased(), scheme == "https" || scheme == "http" else { continue }
            let key = clean.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            guard seen.insert(key).inserted else { continue }
            output.append(clean)
        }
        if !output.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
            output.append(cinematetaManifestURL)
        }
        return output
    }

    /// User-saved add-on manifests are part of a full profile backup, including
    /// configured URLs that carry the user's own provider token. The hidden official
    /// catalog endpoint is never exported.
    static func cloudBackupManifestURLs(_ urls: [String]) -> [String] {
        sanitizedSavedManifestURLs(urls)
    }

    /// Kept for decoding Phase 8/9 call sites and old tests. Full profile backup now
    /// intentionally preserves credential-bearing user manifests.
    static func cloudBackupSafeManifestURLs(_ urls: [String]) -> [String] {
        cloudBackupManifestURLs(urls)
    }

    static func sanitizedRestoredSettings(_ raw: [String: Any]) -> [String: Any] {
        // Explicit application-configuration allowlist. This includes credentials by
        // design because a restore code is expected to rebuild a replacement Apple TV.
        // Entitlement, owner, diagnostics, migration, and backup bookkeeping keys are
        // deliberately absent.
        let allowedKeys: Set<String> = [
            // Catalogs and add-ons
            "stremioManifestURL", "stremioManifestURLs",
            "allInOneCatalogsEnabled",
            "builtInCatalogHiddenRowIDs.v1009", "builtInCatalogCustomRowOrder.v1009",

            // Live TV source configuration and organization
            "liveChannelsDvrBaseURL", "liveHDHomeRunManualURL", "liveHDHomeRunManualGuideURL",
            "liveM3UURL", "liveXMLTVURL",
            "liveXtreamServer", "liveXtreamUsername", "liveXtreamPassword", "liveXtreamAccounts",
            "liveXtreamLoginStatus", "sportsXtreamImportMode",
            "sportsAssignedGroups", "sportsFavoriteTeams", "sportsCustomSourcesJSON",
            "myFavoriteChannelIds", "sportsManualChannelIds",
            "sportsExcludedChannelIds", "sportsExcludedChannelNames",
            "sportsScoreTickerEnabled", "sportsTickerPosition", "moviesShowsReleaseTickerEnabled",

            // Source Intelligence, debrid/add-on providers, and artwork metadata providers
            "backendBaseURL", "tmdbApiKey", "omdbApiKey", "fanartTvApiKey", "tvdbApiToken",
            "torrentioRealDebridApiKey", "torrentioTorBoxApiKey", "torBoxApiKey", "realDebridApiKey",
            "builtInAddonQualityFilter", "builtInAddonCachedOnly", "builtInAddonExcludeCam",
            "sourceIntelligenceMaximumLinks",

            // Playback and presentation preferences
            "externalMoviesInfuseDefault", "externalMoviesVLCDefault", "externalMoviesSenPlayerDefault",
            "externalShowsInfuseDefault", "externalShowsVLCDefault", "externalShowsSenPlayerDefault",
            "liveTVUseAVPlayerDefault", "liveTVMatchDisplayEnabled",
            "liveTVGridProgramProgressEnabled", "liveTVCardArtworkStyle", "liveQuickGuideTipShown",
            "gridLockedMode", "trailerEngineMode",
            "vodInternalPlayerEngine", "vodControlsDockStyle",
            "vodControlShelfMode", "vodControlShelfAutoHideSeconds", "vodControlShelfLastExpanded",
            "focusedCardPreviewsEnabled",
            "popupFontPreset", "topMenuThemePreset", "topMenuAccentColor", "topMenuFontPreset",
            "topBarMediaInfoLayout", "mediaInfoTopBarTransparency",
            "showMediaInfoPortraitPoster", "connectedMediaPopupArtworkEnabled", "advisoryDisplayEnabled",
            "homeGridThemePreset", "liveTVGridThemePreset",

            // Library/follow state and alert preferences
            "favoriteMediaIds", "followedShowIds",
            "followAlertsEnabled", "followNewEpisodesEnabled",
            "followSportsAlertsEnabled", "followPPVAlertsEnabled", "followVerifiedOnly",
            "newEpisodeAlertScanFrequencyMinutes", "newEpisodeAlertStyle",
            "newEpisodeAlertBannerSide", "newEpisodeAlertTheme",
            "newEpisodeAlertBannerDurationSeconds"
        ]

        var sanitized: [String: Any] = [:]
        for (key, value) in raw where allowedKeys.contains(key) {
            if key == "stremioManifestURLs", let urls = value as? [String] {
                sanitized[key] = cloudBackupManifestURLs(urls)
            } else if key == "stremioManifestURL", let url = value as? String {
                sanitized[key] = cloudBackupManifestURLs([url]).first ?? cinematetaManifestURL
            } else if isSupportedBackupValue(value) {
                sanitized[key] = value
            }
        }
        return sanitized
    }

    private static func isSupportedBackupValue(_ value: Any) -> Bool {
        if value is String || value is Bool || value is Int || value is Double || value is NSNumber {
            return true
        }
        if let strings = value as? [String] {
            return strings.allSatisfy { !$0.contains("\u{0000}") }
        }
        return false
    }

    static func redactedURLDescription(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "Not available" }
        if isOfficialCatalogURL(raw) { return "official-catalog" }
        guard var components = URLComponents(string: raw) else { return redactedText(raw) }
        components.user = nil
        components.password = nil
        if let items = components.queryItems, !items.isEmpty {
            components.queryItems = items.map { item in
                sensitiveNames.contains(item.name.lowercased())
                    ? URLQueryItem(name: item.name, value: "REDACTED")
                    : item
            }
        }
        var output = components.string ?? raw
        output = redactSensitivePathValues(output)
        return redactedText(output)
    }

    static func redactedText(_ text: String?) -> String {
        guard var result = text, !result.isEmpty else { return "None" }
        result = result.replacingOccurrences(of: "https://catalog.skylinejay187.it.com/manifest.json", with: "official-catalog", options: .caseInsensitive)
        result = result.replacingOccurrences(of: "catalog.skylinejay187.it.com", with: "official-catalog", options: .caseInsensitive)
        result = result.replacingOccurrences(of: "192.168.100.55:8484", with: "official-catalog", options: .caseInsensitive)
        result = result.replacingOccurrences(of: "192.168.100.55:8181", with: "public-backend", options: .caseInsensitive)
        return redactSensitivePathValues(result)
    }

    static func releaseIdentity() -> String {
        let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "unknown"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "unknown"
        return "\(version) (\(build))"
    }

    private static func isOfficialCatalogURL(_ value: String) -> Bool {
        let lower = value.lowercased()
        return officialCatalogMarkers.contains { lower.contains($0) }
            || lower.contains("api.skylinejay187.it.com") && lower.contains("manifest")
    }

    private static func isSafePublicManifestURL(_ value: String) -> Bool {
        guard !isOfficialCatalogURL(value), let components = URLComponents(string: value),
              components.scheme?.lowercased() == "https", components.host != nil,
              components.user == nil, components.password == nil else { return false }

        if components.queryItems?.contains(where: { sensitiveNames.contains($0.name.lowercased()) }) == true {
            return false
        }
        let lower = value.lowercased()
        let credentialMarkers = sensitiveNames.map { "\($0)=" } + ["/configure/", "authorization=", "bearer="]
        return !credentialMarkers.contains { lower.contains($0) }
    }

    private static func redactSensitivePathValues(_ input: String) -> String {
        var result = input
        for name in sensitiveNames {
            let escaped = NSRegularExpression.escapedPattern(for: name)
            let pattern = "(?i)(\(escaped)=)[^&/\\s]+"
            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }
            let range = NSRange(result.startIndex..<result.endIndex, in: result)
            result = regex.stringByReplacingMatches(in: result, range: range, withTemplate: "$1REDACTED")
        }
        return result
    }
}
