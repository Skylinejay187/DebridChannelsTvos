from pathlib import Path
import plistlib

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'Sources' / 'DebridChannelsTVOSApp.swift').read_text()
YML = (ROOT / 'project.yml').read_text()

for rel in ['Sources/Info.plist', 'TopShelfExtension/Info.plist']:
    with open(ROOT / rel, 'rb') as f:
        p = plistlib.load(f)
    assert p['CFBundleShortVersionString'] == '1.0.928', rel
    assert str(p['CFBundleVersion']) == '928', rel
    assert p.get('DebridChannelsReleaseID') == 'vBRDC225', rel

assert YML.count('MARKETING_VERSION: 1.0.928') == 2
assert YML.count('CURRENT_PROJECT_VERSION: 928') == 2

assert 'private enum LiveTVBrowseMode: String, CaseIterable, Hashable' in SRC
assert 'case grid = "Grid"' in SRC
assert 'case list = "List"' in SRC
assert 'case epg = "EPG"' in SRC
assert 'case .grid: return .list' in SRC
assert 'case .list: return .epg' in SRC
assert 'case .epg: return .grid' in SRC
assert 'else if liveTVBrowseMode == .list {' in SRC
assert 'private func liveList(size: CGSize) -> some View' in SRC
assert 'let mountedChannels = renderedChannels' in SRC
assert 'private func liveListRow(channel: LiveTVChannel' in SRC
assert 'private var liveTVBrowseModeChip: some View' in SRC
assert 'private func cycleLiveTVBrowseMode()' in SRC
assert 'liveTVBrowseMode = .epg\n            openFullLiveTVGuide(from: selectedChannelID)' in SRC
assert 'liveTVBrowseMode = snapshot.origin == "list" ? .list : .grid' in SRC
assert '? "list"' in SRC and 'saveLiveTVFocusSnapshot(channel: channel, origin: origin)' in SRC
assert 'if liveTVBrowseMode == .list {\n            routeLiveListSpecialMove' in SRC
assert '@StateObject private var liveModel = LiveTVSourceModel()' in SRC

print('PASS vBRDC225 unified Live TV Grid/List/EPG contract')
