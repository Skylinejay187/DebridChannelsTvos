# vBRDC245 — Aether PackageFrameworks Embed Fix

Release: **vBRDC245**  
Version: **1.0.948 (948)**

vBRDC244 compiled and linked successfully, then failed only in generated Copy Files phases. XcodeGen treated SwiftPM binary products as top-level build products. The actual Aether dynamic frameworks are under SwiftPM `PackageFrameworks`; Dovi is linked as `-ldovi`, not a nested `Dovi.framework`.

This build removes the invalid generated copy phases, keeps the dynamic bridge, copies the nine actual `AetherLib*.framework` bundles from `$BUILT_PRODUCTS_DIR/PackageFrameworks`, and audits their complete `@rpath/Aether*.framework` closure with `otool -L`. Playback logic is unchanged.
