# Debrid Channels vBRDC223 — Shared Artwork Cache Phase 5

Version: 1.0.926 (926)
Release: vBRDC223

## Changes
- Catalog Health is now a lightweight shared-backend artwork cache/status panel.
- Shows shared server artwork file count, cache size, backend availability, preload progress, failed count, predictive queue/activity, and active server transfers.
- Refresh Backend Cache Status performs a small backend status request only.
- Refresh Catalog Metadata retains the existing catalog repair path, then refreshes shared-cache status.
- Retry Failed Artwork requests the backend retry queue; bulk artwork downloading remains server-owned.
- Removed heavy per-row/failed-page controls from the visible Catalog Health screen so the Apple TV no longer acts as the bulk artwork maintenance surface.
- Existing universal PremiumArtworkURL shared-backend routing remains intact.

Backend companion: v696 Shared Artwork Cache Phase 5.
