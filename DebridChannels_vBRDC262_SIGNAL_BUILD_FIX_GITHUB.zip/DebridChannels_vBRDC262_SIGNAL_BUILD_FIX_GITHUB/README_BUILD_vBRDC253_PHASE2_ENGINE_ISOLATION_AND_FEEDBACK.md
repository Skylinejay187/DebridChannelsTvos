# Debrid Channels vBRDC253 — Phase 2 Engine Isolation + Launch Feedback

Release: **vBRDC253**  
Version: **1.0.956 (956)**  
Baseline: **vBRDC252 / 1.0.955 (955)**

## Scope

This candidate advances the Aether/KSPlayer roadmap without attacking the deferred Live TV/Source Intelligence hitching pass yet.

### Phase 2 engine controls
- AetherEngine remains the primary internal playback engine.
- KSPlayer remains the explicit fallback/alternative.
- Normal VOD Player Engine UI exposes AetherEngine <-> KSPlayer only.
- AVPlayer remains internal compatibility machinery and is no longer a normal selectable engine in the VOD engine panel/settings.
- Adds a persistent Live TV engine preference (`liveTVInternalPlayerEngineV1`) with AetherEngine and KSPlayer choices.
- Live TV playback reads the persistent preference; legacy AVPlayer/VLC channel overrides are retired back to the supported Aether/KS path.
- The Live TV preference is included in Debrid Channels backup/restore.

### Manual engine-switch cleanup
- Manual Aether <-> KSPlayer switches cancel/clear engine-local startup/resume/seek state before the new surface takes ownership.
- Durable `PlaybackResumeCacheManager` state is intentionally not erased. Movies/episodes can still resume after leaving content, app restart, or force-close.
- The new engine re-seeds resume from persistent per-title state rather than inheriting stale engine-local commands.

### KSPlayer source-launch reassurance
- When Source Intelligence hands a manually selected stream to KSPlayer, the player loading gate immediately shows **Opening Stream…**.
- No artificial delay was added. The message disappears naturally on player readiness/first frame.
- Nuvio-style prepared-source/zero-delay handoff remains intact.

## Deferred Phase 5 performance/hitching pass
The user-reported hitching remains explicitly deferred until after the functional playback phases unless it escalates into freezes or broken navigation. The Phase 5 performance pass must include all of the following as one correlated investigation:

- Live TV Guide/Grid scrolling stutter/hitches.
- Source Intelligence occasionally appearing stuck while addon resolution/refresh is in progress, then recovering by itself.
- Correlation between Source Intelligence state and the selected playback engine (AetherEngine vs KSPlayer).
- Fast-link loading / cached-link restoration / addon refresh publication cadence.
- Main-thread state publication, animation/frame-budget pressure, player-runtime wakeups, and source-resolution callbacks.
- Verify that Aether/FFmpeg runtime work is not competing with browsing/Source Intelligence when playback is not active.

The supplied screenshots show the transient states **“Restored 50 cached links. Refreshing addons…”** and **“Resolving addons… Showing 50 of 50 max”**, supporting the decision to profile Source Intelligence resolution/publication together with the UI hitch rather than treat them as unrelated symptoms.

## Regression locks
All v252 navigation, artwork, Live TV Grid/List/EPG, direct-tune, resume, source failover, dynamic wallpaper, Favorites/Search, Quick Guide, Bluetooth/Now Playing priorities, and native SwiftPM Aether packaging contracts remain locked.
