from pathlib import Path
import hashlib, plistlib, re, yaml

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
PROJECT_TEXT = (ROOT / 'project.yml').read_text()
PROJECT = yaml.safe_load(PROJECT_TEXT)


def between(start: str, end: str) -> str:
    a = APP.index(start)
    b = APP.index(end, a)
    return APP[a:b]


def test_release_identity():
    assert PROJECT_TEXT.count('MARKETING_VERSION: 1.0.911') == 2
    assert PROJECT_TEXT.count('CURRENT_PROJECT_VERSION: 911') == 2
    for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
        with (ROOT / rel).open('rb') as fh:
            p = plistlib.load(fh)
        assert p['CFBundleShortVersionString'] == '1.0.911'
        assert str(p['CFBundleVersion']) == '911'
        assert p['DebridChannelsReleaseID'] == 'vBRDC208'


def test_episode_alert_scheduler_survives_vod_and_livetv():
    suspend = between('private func suspendNonAlertRootWorkForVOD()', 'private func resumeNonAlertRootWorkAfterVOD()')
    assert 'stopNewEpisodeHeartbeat' not in suspend
    activate = between('private func activateNewEpisodeAlertScheduler', 'private func shouldRunImmediateEpisodeAlertCatchUp')
    restart = between('private func restartNewEpisodeHeartbeat', 'private func stopNewEpisodeHeartbeat')
    assert 'vodExclusivePlaybackActive' not in activate
    assert 'vodExclusivePlaybackActive' not in restart
    scan = between('private func runRealEpisodeAlertScan', 'private func enqueueNewEpisodeAlerts')
    assert 'deferred while VOD playback owns frame budget' not in scan
    assert 'allowExistingScannerDuringPlayback' in scan
    assert 'episodeAlertFullScreenPlaybackActive' in scan
    lifecycle = between('private var rootPlaybackLifecycleTree', 'private var rootSurfaceObservationTree')
    assert '"VOD full-screen playback mounted"' in lifecycle
    assert '"Live TV full-screen playback mounted"' in lifecycle


def test_episode_alert_banner_remains_inside_fullscreen_player():
    assert 'RootNewEpisodeAlertBanner(' in APP
    player = between('private var playerVisualTree', 'private var playerLifecycleTree')
    assert 'RootNewEpisodeAlertBanner(' in player
    assert 'if let episodeAlert' in player


def test_now_playing_has_handoff_keys_for_mediaremote_home_assistant():
    manager = between('private final class DebridNowPlayingManager', 'final class BluetoothVODMediaButtonCoordinator')
    for marker in (
        'MPNowPlayingInfoPropertyMediaType',
        'MPNowPlayingInfoMediaType.video.rawValue',
        'MPNowPlayingInfoPropertyAssetURL',
        'MPNowPlayingInfoPropertyPlaybackRate',
        'MPNowPlayingInfoPropertyDefaultPlaybackRate',
        'MPNowPlayingInfoPropertyElapsedPlaybackTime',
        'MPNowPlayingInfoPropertyServiceIdentifier',
        'AVAudioSession.sharedInstance()',
        'setCategory(.playback, mode: .moviePlayback',
        'setActive(true)',
    ):
        assert marker in manager
    assert 'lastPublishedInfo' in manager
    assert 'reassertCurrentSession' in manager
    assert 'let publish: () -> Void' in manager


def test_now_playing_is_registered_and_reasserted_app_wide():
    lifecycle = between('private var rootPlaybackLifecycleTree', 'private var rootSurfaceObservationTree')
    assert 'BluetoothVODMediaButtonCoordinator.shared.installIfNeeded()' in lifecycle
    scene = between('private var rootSurfaceObservationTree', 'private var rootStateObservationTree')
    assert 'DebridNowPlayingManager.shared.reassertCurrentSession(reason: "root scene became active")' in scene
    vod = between('private func publishVODSystemNowPlayingMetadata()', 'private func publishLiveTVSystemNowPlaying')
    assert 'assetURL: activePlaybackURL' in vod
    live = between('private func publishLiveTVSystemNowPlaying', 'var body: some View')
    assert live.count('assetURL: activePlaybackURL') >= 2


def test_atvloadly_has_parser_visible_loose_icon_alias():
    approved = ROOT / 'Resources/DebridChannelsHomeIcon.png'
    alias = ROOT / 'Resources/AppIcon-1280x768.png'
    assert approved.exists() and alias.exists()
    assert approved.read_bytes() == alias.read_bytes()
    # Mirrors ATVLoadly's current loose AppIcon filename family: AppIcon...<W>x<H>.png.
    pattern = re.compile(r'^Payload\/.*\.app\/AppIcon-?_?\w*(\d+(\.\d+)?)x(\d+(\.\d+)?)(@\dx)?(~ipad)?\.png$')
    assert pattern.match('Payload/DebridChannelsTVOS.app/AppIcon-1280x768.png')
    with (ROOT / 'Sources/Info.plist').open('rb') as fh:
        p = plistlib.load(fh)
    assert p['CFBundleIconFile'] == 'AppIcon-1280x768.png'
    assert p['CFBundleIconFiles'][0] == 'AppIcon-1280x768.png'
    assert p['CFBundleIconName'] == 'AppIcon'  # canonical layered tvOS icon remains primary
    resources = PROJECT['targets']['DebridChannelsTVOS']['resources']
    assert any(isinstance(x, dict) and x.get('path') == 'Resources/AppIcon-1280x768.png' for x in resources)
    assert 'ATVLOADLY_ICON_DST="$APP_DIR/AppIcon-1280x768.png"' in PROJECT_TEXT
    assert 'cp -f "$ATVLOADLY_ICON_SRC" "$ATVLOADLY_ICON_DST"' in PROJECT_TEXT


def test_up_next_eof_hardening_is_preserved():
    upnext = between('private func prepareUpNextSourcesIfNeeded', 'private func nextEpisode')
    assert 'bufferedHeadroom >= 24' in upnext
    assert 'bufferedHeadroom >= 12' in upnext
    assert 'case ...1: delay = 2' in upnext
    assert 'case 2: delay = 4' in upnext
    assert 'default: delay = 8' in upnext
    watchdog = between('private func startUpNextWatchdogIfNeeded()', 'private func handleNaturalEpisodeEnd')
    assert 'remaining <= 0.10' in watchdog
    eof = APP[APP.index('private func handleNaturalEpisodeEnd'):APP.index('private func startUpNextCountdown', APP.index('private func handleNaturalEpisodeEnd'))]
    assert 'naturalEpisodeTransitionActive' in eof
    assert 'deferProgressRefresh: true' in eof
    assert 'flushDeferredProgressRefreshAfterPlaybackStabilizes' in APP


def test_project_source_contract_and_assets():
    app_sources = PROJECT['targets']['DebridChannelsTVOS']['sources']
    swift_entries = [x for x in app_sources if isinstance(x, dict) and str(x.get('path','')).endswith('.swift')]
    # Explicit source list has exactly the expected app Swift files; Top Shelf is separate.
    assert len(swift_entries) == 67
    top_sources = PROJECT['targets']['DebridChannelsTopShelf']['sources']
    assert len([x for x in top_sources if isinstance(x, dict) and str(x.get('path','')).endswith('.swift')]) == 1


def test_release_network_identity():
    trakt = (ROOT / 'Sources/TraktSyncManager.swift').read_text()
    catalogs = (ROOT / 'Sources/TraktCatalogService.swift').read_text()
    assert '1.0.911' in trakt
    assert 'vBRDC208' in catalogs
