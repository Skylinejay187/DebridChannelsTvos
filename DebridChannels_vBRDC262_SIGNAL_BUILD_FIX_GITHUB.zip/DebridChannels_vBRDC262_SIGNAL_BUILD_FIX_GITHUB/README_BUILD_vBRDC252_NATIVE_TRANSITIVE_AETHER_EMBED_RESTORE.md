# Debrid Channels vBRDC252 — Native Transitive Aether Embed Restore

Release: **vBRDC252**  
Version: **1.0.955 (955)**

## Build failure fixed

vBRDC251 compiled the app, Aether bridge, AetherEngine, KSPlayer, and the namespaced FFmpeg graph, but its final runtime audit failed because `link: false` on the app's `AetherPlaybackBridge` package dependency caused Xcode to copy only `AetherPlaybackBridge.framework` into the app while omitting its transitive `AetherLib*.framework` runtime dependencies. The first missing dependency reported was `AetherLibavcodec.framework`.

## Fix

- Restores the proven Xcode/SwiftPM native dependency form: `AetherPlaybackBridge` with `embed: true` and normal linking.
- Does **not** reintroduce manual DerivedData framework injection/copying.
- Keeps vBRDC251's on-demand Aether engine/player object creation path and Live TV focus-routing fixes.
- Keeps the POSIX runtime closure audit, but removes the invalid requirement that the app executable contain no Aether load command.
- The audit still verifies that the bridge and every `@rpath/Aether*.framework` dependency it references exists in the final signed app bundle.

## Why this is the safe packaging path

vBRDC250 proved this native SwiftPM/Xcode embedding architecture installs through both ATVLoadly and Signulous. vBRDC251's `link: false` optimization broke SwiftPM's transitive runtime embed closure. vBRDC252 restores the proven packaging graph instead of returning to the manual framework injection used in earlier failed builds.

## Preserved runtime work

- Aether primary / KSPlayer fallback
- vBRDC251 Live TV first-row/top-control focus routing work
- Aether host/player objects are still created only when Aether playback is requested
- Existing Nuvio-style prepared-source handoff and playback contracts
- Native Signulous/ATVLoadly-compatible framework signing/layout
