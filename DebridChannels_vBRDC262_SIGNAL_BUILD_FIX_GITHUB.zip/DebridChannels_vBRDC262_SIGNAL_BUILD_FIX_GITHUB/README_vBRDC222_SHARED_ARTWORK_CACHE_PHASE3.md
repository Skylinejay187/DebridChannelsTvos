# Debrid Channels vBRDC222 — Shared Artwork Cache Phase 3

Builds on vBRDC221. The central PremiumArtworkURL path remains the universal client artwork route, so public poster, backdrop, logo, cast, season, episode, Live TV and enrichment image requests continue through the shared backend cache. Phase 3 backend discovery now recognizes and preloads these classes rather than only relying on poster-centric catalog fields.

Version: 1.0.925 (925)
Release: vBRDC222
