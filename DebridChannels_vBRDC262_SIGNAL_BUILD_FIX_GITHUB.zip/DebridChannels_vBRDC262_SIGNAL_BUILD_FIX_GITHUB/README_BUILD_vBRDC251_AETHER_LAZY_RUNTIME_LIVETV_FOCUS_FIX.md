# vBRDC251 — Aether Lazy Runtime + Live TV Focus Fix

Release: **vBRDC251**  
Version: **1.0.954 (954)**

## Why this build exists

vBRDC250 proved that the Aether/KSPlayer coexistence package now installs through both ATVLoadly and Signulous, but browsing became unacceptably sluggish and fast UP navigation in the Live TV grid could jump from the second channel row directly to the Grid/List/EPG mode chip.

The source diff against the last pre-Aether build showed that the browsing UI itself had not otherwise been rewritten by the Aether phase. The remaining app-wide cost was the app executable's eager dynamic linkage to `AetherPlaybackBridge`, which made dyld load the Aether framework graph (including namespaced FFmpeg frameworks) at process launch even when the user was only browsing.

## Runtime isolation change

- `AetherPlaybackBridge` remains a normal signed/embedded SwiftPM dynamic product.
- The app dependency now uses `link: false` + `embed: true`.
- `DebridChannelsTVOS` no longer imports `AetherPlaybackBridge` and has no direct Swift symbol reference to it.
- The app opens the embedded bridge with `dlopen` only when an Aether playback surface is actually requested.
- A C ABI factory (`DebridAetherCreateHostView`) creates the Aether host view after the framework has been loaded.
- Commands cross the bridge through Objective-C/KVC selectors and playback telemetry returns through scoped `NotificationCenter` events.
- Aether playback time/buffer notifications are throttled before crossing back into the app UI lane to avoid unnecessary main-thread invalidations.
- KSPlayer fallback, resume, source identity and first-frame/failure handoff contracts remain in place.

The post-build audit now fails if the final app executable contains an eager `AetherPlaybackBridge` or `AetherLib*` load command, while still requiring the signed bridge and its Aether runtime closure to exist in `Frameworks/`.

## Live TV focus correction

Live TV edge math now uses the exact channel ID of the card whose `onMoveCommand` received the remote event. It no longer derives the row from a potentially one-frame-old `@FocusState` / selected-channel snapshot.

This fixes the fast-UP sequence so it is deterministic:

`third row -> second row -> first row -> Grid/List/EPG chip -> top menu`

The root/bubbled `onMoveCommand` is no longer allowed to run channel-edge math without an explicit card owner, preventing a stale focus value from skipping the first row.

## Catalog / Live TV data loading

No provider URL, catalog manifest, Gracenote, M3U, Xtream, HDHomeRun or Docker/backend contract was changed in this build. The existing catalog persistence/retry lane already retries failed catalog loads at bounded intervals, and Live TV retains its guide/lineup recovery loop. The transient empty state reported immediately before this build subsequently recovered when the backend containers updated, so this build avoids rewriting those proven recovery paths while removing the new Aether browsing overhead.

## Local validation

- Source package cloned from vBRDC250 only; no rollback.
- App / Top Shelf version tuple synchronized to 1.0.954 (954), release ID vBRDC251.
- Swift syntax parse performed for all app Swift sources and the bridge source.
- YAML and plist parsing performed.
- AetherPlaybackKit package manifest dump performed.
- `/bin/sh` syntax check performed for the runtime embed audit.
- No app source imports `AetherPlaybackBridge`, `AetherEngine`, or `AetherLib*`.
- Live TV tile routing contract scan performed.
- ZIP integrity and clean-extraction checks performed before delivery.

A full tvOS/Xcode compile still has to run in GitHub Actions; local Linux validation cannot substitute for Xcode's Apple SDK linker/signing stages.
