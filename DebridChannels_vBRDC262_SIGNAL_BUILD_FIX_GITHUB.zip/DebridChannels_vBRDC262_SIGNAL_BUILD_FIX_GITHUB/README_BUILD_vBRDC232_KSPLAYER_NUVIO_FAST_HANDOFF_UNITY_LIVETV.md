# Debrid Channels vBRDC232 — KSPlayer + Nuvio-style Fast Handoff + Unified Live TV

Version: 1.0.935 (935)
Release ID: vBRDC232

## Why this build exists
vBRDC229-vBRDC231 proved that MPVKit can play some VOD sources well, but the physical Apple TV test exposed regressions in stream compatibility, Live TV, preview playback, seek/clock behavior, Siri Remote integration, and focus/navigation. MPVKit and KSPNUVIO also bring independent FFmpeg dependency graphs whose modules collide when linked in the same application target.

vBRDC232 therefore returns playback to the last proven KSPlayer baseline (vBRDC228) and ports the useful Nuvio-style startup architecture without changing the decoder stack.

## Playback
- KSPlayer/KSPNUVIO is again the production VOD, Live TV and Live TV preview engine.
- The normal VOD scrubber/clock and Debrid Channels remote/seek overlay remain authoritative; no MPV OSD owns Siri Remote seeks.
- Live TV compatibility and preview behavior return to the proven vBRDC228 player path.
- Source Intelligence now prebuilds a ReadyPlaybackSource while links are visible: primary URL, fallback order, per-source headers, subtitle URLs and adaptive-cache hint.
- Selecting a resolved source reuses that prepared object instead of rescanning streamLinks on the first-frame path.
- Playback URL is published as soon as the launch-critical source contract is complete; termination-journal work is deferred to the next main-queue turn.
- One root cinematic artwork cover survives Media Information -> player replacement and is released only after the active player reports a genuine first frame.
- Startup benchmark checkpoints cover ready-source hit/miss, fallback/header readiness, URL publication, player bootstrap and first frame.
- Existing deferred metadata/enrichment behavior is preserved so Cast, Production & Ratings, Trakt enrichment, Up Next preparation and similar nonessential work do not become prerequisites for frame #1.

## Live TV unity
- Grid, List and EPG are modes of one persistent Live TV browse shell.
- One shared broadcast header and one Grid/List/EPG mode chip remain mounted while the content lane changes.
- EPG no longer enters through the old separately padded/popup-like outer presentation.
- Grid remains the fixed paged Gracenote card view.
- List remains the same Gracenote card design, scrolling vertically as one continuous channel page.
- The List scroll viewport no longer clips the focused first-row card; extra top breathing room is reserved for the focus scale.
- UP from the first Grid/List row explicitly reaches the mode chip.
- UP from the mode chip explicitly requests the persistent top menu, so both Current and Spread Out layouts have the same focus route.
- DOWN from the mode chip returns to the currently selected channel.
- The removed third-row "press down to Guide" path stays removed; EPG is entered only through the unified mode chip.

## MPVKit coexistence decision
This build intentionally does not ship MPVKit. KSPNUVIO and MPVKit currently depend on separate FFmpeg module/binary graphs; linking both into one tvOS application target causes duplicate libav module/symbol ownership. A real dual-engine build would require rebuilding/namespacing one native FFmpeg stack (or replacing one engine's native dependency), not simply adding both Swift packages. vBRDC232 chooses the stable production path instead of shipping an unsafe linker/runtime experiment.

## Validation
- All production Swift files individually pass `swiftc -parse` in this environment.
- Project contract confirms KSPNUVIO/KSPlayer present and MPVKit absent.
- Unified Live TV shell, List clipping fix, top-menu focus route, ready-source cache, early URL publication, continuous cover and benchmark contracts pass.
- App and Top Shelf versions are 1.0.935 / 935; app release ID is vBRDC232.
- Merge-marker scan passes.
- No full Xcode/tvOS link or physical-device playback test is possible in this Linux environment. GitHub Actions/Xcode and the physical Apple TV remain authoritative.
