# Debrid Channels vBRDC224 — Shared Artwork Cache Phase 6

Version: 1.0.927 (927)
Release: vBRDC224

## Changes
- Final client-side cache hardening for the shared artwork origin.
- Premium artwork byte downloads now respect the backend's immutable HTTP cache headers instead of forcing `reloadIgnoringLocalCacheData`.
- Added a dedicated URLCache for premium artwork (64 MB memory / 1 GB disk) so repeat artwork can survive process/app relaunches without even requiring a backend round trip when still valid.
- Existing decoded-image cache buckets remain unchanged, so small card decodes cannot poison focused/hero/full-resolution artwork.
- Existing in-flight decode coalescing, navigation-aware publication deferral, and prefetch limits remain intact.
- Backend shared cache remains the cross-user source of truth: one user's miss warms the server for all users; the device cache is an additional local speed layer.

Backend companion: v697 Shared Artwork Cache Phase 6.
