# vBRDC256 — Phase 5 Render / Compatibility / Performance Hardening

Version: 1.0.959 (959)
Release: vBRDC256
Baseline: vBRDC255 Phase 4 Session / Presentation Isolation.

This candidate is the Phase 5 hardening pass. AetherEngine remains the primary engine for VOD and Live TV; KSPlayer remains the compatibility fallback. Live TV always starts on Aether when Aether is selected so the same playback path remains suitable for the later Aether-native rolling timeshift implementation.

Phase 5 changes:
- Adds an app-side Aether codec/container compatibility policy based on the existing codec classifier. Difficult Dolby Vision P7, 12-bit, VC-1, legacy, AVI and WebM sources use a shorter bounded startup recovery window.
- Adds an Aether first-frame compatibility watchdog. If the selected Aether surface never reaches a first frame inside the bounded grace period, the exact same source is handed to KSPlayer instead of leaving the UI apparently frozen. VOD resume position is preserved during this automatic fallback. Live TV never pre-routes away from Aether; fallback happens only after an actual Aether startup stall.
- Coalesces Aether time and buffer notifications before they reach the app MainActor. Decoder/frame-rate callbacks no longer cause unnecessary UI/session invalidations at frame cadence.
- Coalesces Source Intelligence publication so identical ranked 25/50-link arrays are not repeatedly assigned to @Published state as providers finish. This reduces Source Intelligence panel re-render pressure and the hitching that can overlap playback or Live TV navigation.
- Preserves the Phase 4 opaque-black Aether presentation boundary, no-halo behavior and SDR SwiftUI/UIKit artwork isolation.
- Preserves Aether -> KSPlayer runtime failure fallback, manual engine-switch transient-state clearing, persistent resume, automatic source failover, Next Episode/EOF ownership, Bluetooth/Now Playing ownership and Live TV Grid/List/EPG UX.
- No VOD cache or Live TV timeshift buffer is added in this phase. Those remain post-Phase-5 features.
- GitHub Actions build-speed optimization remains deferred until all playback phases and requested feature work are complete.

Performance note:
The reported Live TV Guide scrolling stutter and occasional Source Intelligence “stuck then recovers” behavior are explicitly part of this Phase 5 pass. This candidate attacks two shared MainActor churn sources (Aether telemetry and redundant Source Intelligence array publications) without changing the accepted Live TV layout/focus contracts.

Validation:
- App and Top Shelf versions synchronized to 1.0.959 / 959 / vBRDC256.
- Production and vendored AetherPlaybackBridge sources are exact mirrors.
- Changed Swift sources pass swiftc parser validation.
- App and Top Shelf plists pass plutil lint.
- GitHub Actions/Xcode remains the authoritative compile/link/archive test.
