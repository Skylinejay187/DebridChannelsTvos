# Debrid Channels vBRDC220 — Debrid Now Showing Direct Push

Release identity: **vBRDC220 / 1.0.923 / 923**

This build preserves the vBRDC219 MediaRemote/Bluetooth/Now Playing reclaim lifecycle and adds a real Home-Assistant-free sender for the self-hosted Debrid Now Showing Docker.

## What changed

- Added `DebridNowShowingDirectPushManager.swift`.
- VOD claim, metadata enrichment, play/pause/elapsed updates, Live TV publication and release/idle edges now POST to the configured Debrid Now Showing server.
- Exact TMDB/IMDb identity already known by Debrid Channels is carried through the existing Now Playing external identifier when available.
- Added **Settings → VOD Player → Debrid Now Showing Display** with:
  - server URL (for example `http://192.168.100.55:8088`),
  - direct-push token,
  - non-mutating connection/token test.
- Direct push uses both standard `Authorization: Bearer` and the compatibility `X-Debrid-Now-Showing-Token` header.
- Server URL and token are included in protected profile backup/restore so a replacement install can reuse the same pairing.
- Fresh-install credential boundary clears an orphaned direct-push token when no protected restore was performed.

## Runtime behavior

If no Debrid Now Showing server URL is configured, the new sender is inert. Existing playback, Now Playing, Bluetooth, Trakt, Live TV, artwork and source-search logic continue unchanged.

When configured, direct push is fire-and-forget on a small ephemeral URLSession and never blocks player startup or decoder timing.
