# vBRDC249 — Aether Native Embed Audit POSIX Fix

- Release: vBRDC249
- Version: 1.0.952 (952)
- Base: vBRDC248
- Fixes the only vBRDC248 GitHub build failure: the runtime audit used Bash process substitution while Xcode executes build-phase scripts through `/bin/sh`.
- Rewrites the audit using a portable temporary-file loop.
- Preserves SwiftPM-native embedding of `AetherPlaybackBridge.framework` and the namespaced Aether FFmpeg frameworks.
- No manual framework injection/copying was reintroduced.

The vBRDC248 build log proved Xcode copied `AetherPlaybackBridge.framework` into the final app Frameworks directory and also showed the namespaced Aether runtime frameworks in the app. vBRDC249 keeps that successful packaging path and fixes the audit script syntax that stopped the build afterward.
