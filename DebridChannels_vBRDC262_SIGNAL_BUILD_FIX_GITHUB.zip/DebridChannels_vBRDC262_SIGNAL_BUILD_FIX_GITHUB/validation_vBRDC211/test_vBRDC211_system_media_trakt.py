from pathlib import Path
import plistlib
import re

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
STORE = (ROOT / 'Sources/CatalogStore.swift').read_text()
TRAKT = (ROOT / 'Sources/TraktSyncManager.swift').read_text()
TRAKT_CATALOG = (ROOT / 'Sources/TraktCatalogService.swift').read_text()
PROJECT = (ROOT / 'project.yml').read_text()
HERO = (ROOT / 'Sources/CatalogHeroMetadataCache.swift').read_text()


def test_release_identity_v211():
    assert PROJECT.count('MARKETING_VERSION: 1.0.914') == 2
    assert PROJECT.count('CURRENT_PROJECT_VERSION: 914') == 2
    for rel in ('Sources/Info.plist', 'TopShelfExtension/Info.plist'):
        with (ROOT / rel).open('rb') as f:
            p = plistlib.load(f)
        assert p['CFBundleShortVersionString'] == '1.0.914'
        assert str(p['CFBundleVersion']) == '914'
        assert p['DebridChannelsReleaseID'] == 'vBRDC211'
    assert 'private static let appVersion = "1.0.914"' in TRAKT
    assert 'DebridChannels-tvOS/vBRDC211 TraktCatalog' in TRAKT_CATALOG


def test_real_mpnowplayingsession_anchor_is_packaged():
    anchor = ROOT / 'Resources/DebridSystemMediaAnchor.m4a'
    assert anchor.exists() and anchor.stat().st_size > 0
    assert 'Resources/DebridSystemMediaAnchor.m4a' in PROJECT
    assert 'Bundle.main.url(forResource: "DebridSystemMediaAnchor", withExtension: "m4a")' in APP
    assert 'let player = AVQueuePlayer(items: [])' in APP
    assert 'player.isMuted = true' in APP
    assert 'player.volume = 0' in APP
    assert 'let looper = AVPlayerLooper(player: player, templateItem: templateItem)' in APP
    assert 'let session = MPNowPlayingSession(players: [player])' in APP
    assert 'session.automaticallyPublishesNowPlayingInfo = false' in APP


def test_session_scoped_now_playing_is_authoritative():
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in APP
    assert 'session.remoteCommandCenter' in APP
    assert 'session.becomeActiveIfPossible' in APP
    assert 'session.isActive' in APP
    # The default center is retained only as cleanup/fallback, not as the normal publisher.
    publish_block = APP[APP.index('private func publishSnapshotOnMain'):APP.index('private func synchronizeAnchorPlaybackOnMain')]
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in publish_block
    assert 'else {' in publish_block and 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in publish_block


def test_anchor_follows_real_play_pause_without_replacing_renderer():
    sync = APP[APP.index('private func synchronizeAnchorPlaybackOnMain'):APP.index('private func requestSystemSessionActivationOnMain')]
    assert 'if isPlaying' in sync
    assert 'player.play()' in sync
    assert 'player.pause()' in sync
    # Existing renderer paths remain present.
    assert 'KSPlayer' in APP
    assert 'VLC' in APP


def test_remote_commands_are_registered_on_session_and_shared_centers():
    install = APP[APP.index('func installIfNeeded()', APP.index('final class BluetoothVODMediaButtonCoordinator')):]
    install = install[:install.index('func claimVODSession')]
    assert 'DebridNowPlayingManager.shared.remoteCommandCenters()' in install
    for marker in ('togglePlayPauseCommand.addTarget', 'playCommand.addTarget', 'pauseCommand.addTarget'):
        assert marker in install
    centers = APP[APP.index('private func preparedCommandCentersOnMain'):APP.index('func remoteCommandCenters')]
    assert 'session.remoteCommandCenter' in centers
    assert 'MPRemoteCommandCenter.shared()' in centers


def test_remote_commands_enabled_before_audio_activation():
    vod = APP[APP.index('func claimVODSession(', APP.index('final class BluetoothVODMediaButtonCoordinator')):]
    vod = vod[:vod.index('func claimLiveControlSession')]
    assert vod.index('syncAvailability()') < vod.index('activateVODAudioSession()')
    live = APP[APP.index('func claimLiveControlSession'):APP.index('func releaseVODSession')]
    assert live.index('syncAvailability()') < live.index('activateVODAudioSession()')


def test_dual_command_center_delivery_cannot_double_toggle():
    receive = APP[APP.index('private func receive(_ command: BluetoothVODMediaCommand)'):APP.index('private func activateVODAudioSession')]
    assert 'duplicateExternalRoute' in receive
    assert 'let duplicateExternalRoute = (now - lastExternalCommandAt) < 0.18' in receive
    assert '(now - lastExternalCommandAt) < 0.18' in receive
    assert 'guard !duplicateOfSwiftUI, !duplicateExternalRoute else { return .success }' in receive
    receive_idx = APP.index('.onReceive(NotificationCenter.default.publisher(for: .debridBluetoothVODMediaCommand))')
    playpause_idx = APP.rfind('.onPlayPauseCommand {', 0, receive_idx)
    assert playpause_idx >= 0
    playpause = APP[playpause_idx:receive_idx]
    assert 'BluetoothVODMediaButtonCoordinator.shared.shouldSuppressSwiftUIPlayPause()' in playpause
    suppression_line = next(line for line in playpause.splitlines() if 'shouldSuppressSwiftUIPlayPause()' in line)
    assert '!isLivePlayback &&' not in suppression_line


def test_bluetooth_command_bypasses_ui_440ms_debounce():
    block = APP[APP.index('private func handleBluetoothVODMediaCommand'):APP.index('@ViewBuilder', APP.index('private func handleBluetoothVODMediaCommand'))]
    assert 'playerAction {' not in block
    assert 'togglePlay()' in block
    assert 'case .play:' in block and 'case .pause:' in block


def test_now_playing_diagnostics_are_visible():
    for marker in (
        'System Now Playing: \\(systemNowPlayingStatus)',
        'Last Session Claim: \\(systemNowPlayingLastClaim) • Last Media Button: \\(systemMediaRemoteLastEvent)',
        'systemSessionStatusDefaultsKey',
        'systemSessionLastClaimDefaultsKey',
        'systemMediaRemoteLastEventDefaultsKey',
    ):
        assert marker in APP
    assert 'UserDefaults.standard.set(result, forKey: Self.systemSessionLastClaimDefaultsKey)' in APP
    assert 'UserDefaults.standard.set("\\(command.rawValue.capitalized) received"' in APP


def test_vod_and_live_publish_rich_metadata():
    assert 'publishVODSystemNowPlayingMetadata()' in APP
    assert 'publishLiveTVSystemNowPlaying(claim: true)' in APP
    for marker in (
        'MPNowPlayingInfoPropertyMediaType',
        'MPNowPlayingInfoMediaType.video.rawValue',
        'MPNowPlayingInfoPropertyPlaybackRate',
        'MPNowPlayingInfoPropertyElapsedPlaybackTime',
        'MPNowPlayingInfoPropertyServiceIdentifier',
        'MPNowPlayingInfoPropertyExternalContentIdentifier',
        'MPNowPlayingInfoPropertyIsLiveStream',
    ):
        assert marker in APP


def test_live_claim_precedes_decoder_mount():
    start = STORE[STORE.index('func startPlayback(item: MediaItem'):]
    start = start[:start.index('/// Phase 0 entry point')]
    assert 'claimLiveControlSession' in start
    assert start.index('claimLiveControlSession') < start.index('playbackURL = url')


def test_live_pause_updates_system_rate():
    assert 'func updateLivePlaybackState' in APP
    change = APP[APP.index('.onChange(of: isPlaying)'):]
    assert 'updateLivePlaybackState(playbackPresentationID, isPlaying: playing)' in change[:5000]


def test_manual_trakt_resync_restores_keychain_first_and_confirms():
    block = TRAKT[TRAKT.index('func manualResyncFromSettings'):TRAKT.index('var connectedAccountName')]
    assert block.index('restorePersistedConnectionIfNeeded()') < block.index('refreshPlaybackProgress(force: true)')
    assert '✓ Trakt resync complete •' in block
    assert 'Continue Playing' in block
    settings = APP[APP.index('SettingsButton(title: "Sync Resume Now"'):]
    settings = settings[:settings.index('if TraktSyncManager.shared.isConnected')]
    assert 'let resynced = await TraktSyncManager.shared.manualResyncFromSettings()' in settings
    assert 'store.status = traktStatusText' in settings


def test_verified_account_no_longer_hides_manual_sync_confirmation():
    status = APP[APP.index('HStack(spacing: 7)', APP.index('private var traktSyncSettingsSection')):APP.index('private func beginTraktDeviceLinkFromSettings')]
    assert 'traktStatusText.isEmpty ? (TraktSyncManager.shared.accountIdentityVerified ? "Verified ✓"' in status
    assert 'if traktStatusText.contains("Trakt resync complete")' in status
    assert 'checkmark.circle.fill' in status


def test_restore_code_runs_one_automatic_trakt_resync():
    restore = APP[APP.index('private func runBackendProfileRestore()'):APP.index('private func runBackendProfileClear()')]
    assert restore.count('manualResyncFromSettings()') == 1
    assert 'restorePersistedConnectionIfNeeded()' in restore
    assert restore.index('restorePersistedConnectionIfNeeded()') < restore.index('manualResyncFromSettings()')
    assert 'playbackAlreadySynchronized: true' in restore
    assert 'resynced once automatically' in restore
    assert 'refreshPlaybackDerivedCatalogRows(scheduleAccountRefresh: false)' in restore


def test_catalog_refresh_can_skip_duplicate_playback_request():
    sig = 'func refreshTraktCatalogRowsIfNeeded(force: Bool = false, userInitiated: Bool = false, playbackAlreadySynchronized: Bool = false)'
    assert sig in STORE
    block = STORE[STORE.index(sig):STORE.index('func removeTraktCatalogRows', STORE.index(sig)) if False else len(STORE)]
    assert 'skipPlaybackRefresh: playbackAlreadySynchronized' in block
    service = TRAKT_CATALOG[TRAKT_CATALOG.index('func fetchCatalogRows('):TRAKT_CATALOG.index('let endpoints: [Endpoint]')]
    assert 'skipPlaybackRefresh: Bool = false' in service
    assert 'if !skipPlaybackRefresh' in service


def test_cold_resume_artwork_hardening_preserved():
    assert 'func hydrateResumeArtworkOnColdLaunchIfNeeded' in STORE
    for marker in ('posterURL: String?', 'landscapeURL: String?', 'logoURL: String?'):
        assert marker in HERO
    block = STORE[STORE.index('func hydrateResumeArtworkOnColdLaunchIfNeeded'):STORE.index('func refreshPlaybackDerivedCatalogRows(')]
    assert 'entries.prefix(12)' in block
    assert 'batchSize = 3' in block
    assert 'CatalogHeroMetadataCache.shared.metadata' in block


def test_episode_alert_and_up_next_regression_locks_preserved():
    assert 'allowExistingScannerDuringPlayback = episodeAlertFullScreenPlaybackActive' in APP
    assert 'newEpisodeAlertPresentationScope == .mainAndVOD' in APP
    for marker in ('naturalEpisodeTransitionActive', 'upNextPostEOFTask', 'schedulePostEOFUpNextWork()'):
        assert marker in APP


def test_atvloadly_icon_and_catalog_type_boundary_preserved():
    assert 'Resources/AppIcon-1280x768.png' in PROJECT
    assert (ROOT / 'Resources/AppIcon-1280x768.png').exists()
    assert 'vBRDC199: a fuller but type-corrupted v198 snapshot must never beat a' in STORE
    assert 'vBRDC199: for the official All-in-One source the manifest catalog' in STORE


def test_no_obsolete_synchronize_or_completion_amplifiers():
    assert '.synchronize()' not in APP
    save = APP[APP.index('private func saveResumePositionIfNeeded'):APP.index('private func defaultExternalTargetForCurrentItem')]
    assert 'markCompleted' not in save
    assert '>= 0.95' not in save
