# Debrid Channels vBRDC211 — MPNowPlayingSession / Bluetooth / Trakt Restore Hard Fix

Release: vBRDC211  
Marketing version: 1.0.914  
Build: 914  
Donor/source of truth: the uploaded vBRDC210 packaged source only.

## Why this pass is materially different from vBRDC210

vBRDC210 still published Now Playing through the process-wide `MPNowPlayingInfoCenter.default()` and listened only to `MPRemoteCommandCenter.shared()`. That can publish dictionaries without giving tvOS a real AVPlayer-owned playback session to associate with MediaRemote.

vBRDC211 changes the runtime ownership model itself:

- Adds a 1-second bundled silent AAC resource (`Resources/DebridSystemMediaAnchor.m4a`).
- Creates one retained, muted `AVQueuePlayer` + `AVPlayerLooper` solely as a tvOS system-media ownership anchor.
- Creates `MPNowPlayingSession(players:)` around that anchor.
- Sets `automaticallyPublishesNowPlayingInfo = false` so Debrid Channels remains authoritative for movie/show/Live TV metadata and timing.
- Publishes Now Playing through the session-scoped `nowPlayingInfoCenter`.
- Calls `becomeActiveIfPossible()` while real full-screen playback owns the session.
- Registers Play, Pause, and Toggle handlers on the session-scoped `remoteCommandCenter` and also on the shared compatibility center.
- Keeps KSPlayer/VLC/Live TV as the real playback engines. The anchor is muted and never renders or transcodes the actual stream.
- Mirrors real play/pause state into the anchor so MediaRemote ownership remains synchronized with the true player.
- Reasserts the same session after app activation, route changes, interruptions, and media-service reset notifications.
- De-duplicates a physical media-button event if tvOS surfaces it through both command centers, and de-duplicates the SwiftUI `onPlayPauseCommand` path for both VOD and Live TV.
- Bluetooth/system media commands continue to bypass the generic 440 ms UI-action debounce.

## Visible physical-device diagnostics

Under **Settings → VOD Internal Player**:

- `System Now Playing: Active / Requesting / Rejected / Idle / Unavailable`
- `Last Session Claim: ...`
- `Last Media Button: Toggle/Play/Pause received`

These are deliberately visible so a physical Apple TV test can distinguish “tvOS accepted the session” from “metadata code executed” and can prove whether a Bluetooth transport command reached the app.

## Trakt manual resync confirmation

- `Sync Resume Now` still restores the persisted Trakt Keychain session before the network refresh.
- A successful manual resync now stores and displays an explicit confirmation such as:
  - `✓ Trakt resync complete • 4 Continue Playing items refreshed`
- The old verified-account label no longer hides the resync result behind `Verified ✓`.
- A dedicated green confirmation row is shown after a successful manual resync.
- The refreshed cloud snapshot is immediately projected into Resume / Continue Playing and artwork hydration.

## Restore-code → automatic Trakt resync

After a successful backend profile restore:

1. Apply the restored profile.
2. Recover the existing Trakt OAuth session from Keychain when available.
3. Run exactly one authoritative `manualResyncFromSettings()` playback-progress transaction.
4. Re-project Continue Playing immediately.
5. Refresh Trakt catalog shelves while explicitly skipping a second playback-progress request.
6. Show the Trakt result in both Settings state and the restore result text.

Restore codes still do **not** copy OAuth refresh tokens. On a different Apple TV or an install where the Trakt Keychain item is no longer present, the restore result explicitly tells the user to reconnect Trakt once rather than pretending cloud resume was restored.

## Preserved regression locks

- vBRDC210 cold Resume artwork/themed-logo recovery remains intact.
- vBRDC209 natural-EOF / Up Next decoder isolation remains intact.
- Episode Alert scanning/presentation during VOD and Live TV remains intact.
- Main Movies / TV Shows type boundaries remain intact.
- Force Guide bounded self-healing remains intact.
- ATVLoadly raw icon compatibility alias and canonical layered icon assets are unchanged.
- No `UserDefaults.synchronize()` calls were reintroduced.
- Normal Resume checkpoints do not reintroduce >=95% completion amplification.

## Local validation

- vBRDC211 regression contracts: 20/20 passed.
- Swift syntax parse: 68/68 files, 0 failures.
- App and Top Shelf plists lint clean.
- Silent system-media anchor: AAC, 48 kHz stereo, 1.000 second, 1303 bytes.
- Asset catalog and both approved raw icon files are byte-identical to the uploaded vBRDC210 donor.
- No merge-conflict markers in source/project files.

GitHub Actions / Xcode with the tvOS SDK remains the authoritative SDK type-check and device build. Physical Apple TV testing is still required to verify actual MediaRemote ownership on the target tvOS/hardware/accessory combination.
