# vBRDC220 regression locks

- vBRDC219 MPNowPlayingSession fresh-claim/release lifecycle remains intact.
- Shared MPRemoteCommandCenter remains the hardware-proven Bluetooth route.
- KSPlayer/VLC remain the real VOD renderers; the silent AVPlayer remains MediaRemote ownership only.
- No source-search, catalog, UI motion, Live TV guide, Trakt resume, artwork, alternate-audio or failover behavior was intentionally changed.
- Direct push is optional and disabled by absence of a server URL.
- Direct-push transport is asynchronous and cannot delay first-frame playback.
- Profile backup/restore preserves the Debrid Now Showing URL/token pair.
