# Debrid Channels vBRDC233 — KSPlayer Nuvio-Style Zero-Delay Handoff + Live TV Unity Polish

Version: 1.0.936 (936)
Release ID: vBRDC233

## Baseline
Built from the user-provided vBRDC228 KSPlayer baseline, preserving the proven KSPNUVIO/FFmpeg playback stack. MPVKit is not linked in this build.

## VOD startup / Nuvio-style handoff
- Removes the intentional 550 ms `Opening Stream` delay that still sat between selecting an already-resolved direct link and publishing the player route.
- Source Intelligence prebuilds a `ReadyPlaybackSource` while links are visible: primary URL, fallback order, per-source HTTP headers, subtitle URLs, adaptive-cache hint, and parsed source-track summary.
- Direct link taps reuse the prepared source contract instead of rebuilding fallback/header/subtitle plans at click time.
- Per-title source persistence / last-link persistence is deferred until after the player route is published so UserDefaults/disk work cannot hold up frame #1.
- `playbackURL` remains published as soon as the launch-critical contract is ready; termination-journal work remains deferred.
- The root cinematic launch cover remains mounted across details/source UI -> VOD replacement and releases only from the active playback first-frame signal.
- Startup benchmark markers remain active for ready-source hit/miss, fallback/header readiness, URL publication, player bootstrap, and first frame.
- Cast, Production & Ratings, Trakt enrichment, alternate-audio discovery, Up Next/Now Playing enrichment and other nonessential work remain outside the first-frame critical window.

## Live TV unity / navigation
- Retains the vBRDC230 one-tree Live TV shell: Grid, List and EPG share one persistent broadcast header, one Grid/List/EPG mode chip, one category/channel state and one root geometry.
- EPG remains an in-place content mode, not the old separately padded Guide presentation.
- UP from the first Grid or List row explicitly enters the mode chip; UP from that chip requests the persistent top menu; DOWN returns to the selected channel.
- The removed third-row Down-to-Guide gesture stays removed. EPG is entered only from the unified mode chip.
- Current and Spread Out layouts use the same focus route.

## List layout
- List remains the same four-column Gracenote card design, scrolling vertically as one continuous channel page.
- List now sizes its card rows from the actual viewport so exactly three complete rows fill the visible area toward the bottom of the screen instead of exposing a compressed/fourth row.
- The first focused row gets a dedicated top focus-scale/overscan cushion and uses a small positive scroll anchor so the enlarged focused card is not cut off at the top.
- Grid sizing/paging is unchanged.

## Engine decision
KSPNUVIO/KSPlayer remains the production VOD, Live TV and preview engine. This intentionally avoids the MPVKit + KSPNUVIO duplicate FFmpeg module collision and restores the proven playback clock, Siri Remote seek overlay, Live TV compatibility and preview behavior.

## Validation
- All production Swift sources individually parsed with `swiftc -parse` in this Linux environment.
- App + Top Shelf versions are aligned at 1.0.936 / 936; release ID is vBRDC233.
- Project keeps KSPNUVIO and does not link MPVKit.
- Contract scans verify zero 550 ms handoff delay, ready-source summary/fallback cache, three-row List sizing, unified Live TV shell and explicit top-menu focus route.
- Merge-marker and ZIP-integrity checks pass.
- No full Xcode/tvOS link or physical-device playback test is possible here; GitHub Actions/Xcode and the physical Apple TV remain authoritative.
