from pathlib import Path
r=Path(__file__).resolve().parents[1]
app=(r/'Sources/DebridChannelsTVOSApp.swift').read_text()
cat=(r/'Sources/CatalogStore.swift').read_text()
proj=(r/'project.yml').read_text()
trakt=(r/'Sources/TraktSyncManager.swift').read_text()
traktcat=(r/'Sources/TraktCatalogService.swift').read_text()
info=(r/'Sources/Info.plist').read_text()
top=(r/'TopShelfExtension/Info.plist').read_text()


def block(start, end):
    return app[app.index(start):app.index(end, app.index(start))]


def test_release_identity():
    assert 'MARKETING_VERSION: 1.0.920' in proj
    assert 'CURRENT_PROJECT_VERSION: 920' in proj
    for text in (info, top):
        assert '<string>1.0.920</string>' in text
        assert '<string>920</string>' in text
        assert '<string>vBRDC217</string>' in text
    assert 'private static let appVersion = "1.0.920"' in trakt
    assert 'DebridChannels-tvOS/vBRDC217 TraktCatalog' in traktcat
    assert 'DebridChannels-tvOS/920 UniversalInstantSourceFanout' in cat


def test_background_audio_capability_preserved():
    assert '<key>UIBackgroundModes</key>' in info
    assert '<string>audio</string>' in info


def test_now_playing_publication_is_main_thread_and_session_first():
    pub=block('private func publishSnapshotOnMain', 'private func ensureHeartbeatOnMain')
    assert 'assert(Thread.isMainThread)' in pub
    assert 'session.nowPlayingInfoCenter.nowPlayingInfo = info' in pub
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = info' in pub
    assert pub.index('session.nowPlayingInfoCenter.nowPlayingInfo = info') < pub.index('MPNowPlayingInfoCenter.default().nowPlayingInfo = info')


def test_activation_republishes_metadata_after_session_becomes_active():
    req=block('private func requestSystemSessionActivationOnMain', 'func reassertCurrentSession')
    assert 'session.becomeActiveIfPossible' in req
    assert 'self.publishSnapshotOnMain(snapshot)' in req
    assert 'self.ensureHeartbeatOnMain()' in req
    assert 'activateDefaultCenterFallbackOnMain' in req


def test_rejected_session_has_default_center_fallback_without_losing_shared_remote():
    fb=block('private func activateDefaultCenterFallbackOnMain', 'private func requestSystemSessionActivationOnMain')
    assert 'defaultCenterFallbackActive = true' in fb
    assert 'retainSharedCommandCenterOnlyForDefaultNowPlayingFallback()' in fb
    assert 'nowPlayingSession = nil' in fb
    assert 'MPNowPlayingInfoCenter.default().nowPlayingInfo = snapshot' in fb
    remote=block('func retainSharedCommandCenterOnlyForDefaultNowPlayingFallback', '/// vBRDC117')
    assert 'MPRemoteCommandCenter.shared()' in remote
    assert 'removeTarget(registration.toggleTarget)' in remote


def test_concrete_movie_tv_media_type_replaces_any_video():
    enum_block=block('private enum DebridNowPlayingContentKind', 'private enum DebridNowPlayingArtworkURL')
    assert 'case movie' in enum_block and 'case tvShow' in enum_block and 'case liveTV' in enum_block
    assert 'case .movie: return .movie' in enum_block
    assert 'case .tvShow, .liveTV: return .tvShow' in enum_block
    mutate=block('private func mutate(', '/// Bridges system media-button events')
    assert 'contentKind.mediaItemType.rawValue' in mutate
    assert 'MPMediaType.anyVideo.rawValue' not in mutate


def test_artwork_is_real_mpmediaitemartwork_and_bounded():
    artwork=block('private func loadArtwork', 'private func synchronizeAnchorPlaybackOnMain')
    assert 'MPMediaItemArtwork(boundsSize: image.size)' in artwork
    assert 'MPMediaItemPropertyArtwork' in artwork
    assert 'CGImageSourceCreateThumbnailAtIndex' in app
    assert 'maxPixelSize: Int = 1280' in app
    assert 'timeoutIntervalForRequest = 8' in app
    assert '/t/p/w780/' in app


def test_artwork_waits_for_first_real_frame():
    vod=block('private func publishVODSystemNowPlayingMetadata()', 'private func publishLiveTVSystemNowPlaying')
    assert 'isFirstFrameReady ? DebridNowPlayingArtworkURL.url' in vod
    live=block('private func publishLiveTVSystemNowPlaying(claim: Bool)', 'var body: some View')
    assert 'let artworkURL = isFirstFrameReady' in live
    assert 'program?.imageURL ?? channel?.iconURL' in live


def test_periodic_mediaremote_heartbeat_exists():
    hb=block('private func ensureHeartbeatOnMain', 'private func stopHeartbeatOnMain')
    assert 'withTimeInterval: 10.0' in hb
    assert 'publishSnapshotOnMain(snapshot)' in hb
    assert 'requestSystemSessionActivationOnMain(reason: "10-second MediaRemote heartbeat")' in hb


def test_vod_decoder_clock_still_updates_now_playing_every_five_seconds():
    update=block('func updateNowPlaying(', '/// Restore tvOS media ownership')
    assert 'abs(safeElapsed - lastNowPlayingElapsed) >= 5.0' in update
    assert 'DebridNowPlayingManager.shared.updateVODTiming' in update


def test_live_pause_rate_is_not_overwritten_to_playing():
    live=block('private func publishLiveSession(', 'func releaseSession')
    assert 'let isPlaying = ownerSessionID == sessionID ? ownerIsPlaying : true' in live
    assert 'MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0' in live
    assert 'MPNowPlayingInfoPropertyIsLiveStream] = true' in live


def test_v216_playback_parity_main_catalog_vertical_scroll_preserved():
    assert 'MainCatalogVerticalRowArrivalModifier' not in app
    nav=block('private func moveQuickPanelRow(_ delta: Int)', 'private func scheduleFirstCardRowEntryFocus')
    assert 'transaction.disablesAnimations = true' in nav
    assert 'activeRowIndex = next' in nav
    assert 'focusedRow = next' in nav
    assert 'withAnimation(' not in nav
    rail=block('private func catalogRail(', '@ViewBuilder\n    private func nextRowTitle')
    assert '.transition(.identity)' in rail
    assert '.animation(nil, value: activeRowIndex)' in rail


def test_v214_bluetooth_anchor_and_universal_source_fanout_preserved():
    anchor=block('private func synchronizeAnchorPlaybackOnMain', 'private func activateDefaultCenterFallbackOnMain')
    assert 'player.pause()' not in anchor
    assert 'if hasOwner, player.timeControlStatus != .playing { player.play() }' in anchor
    assert 'var centers: [MPRemoteCommandCenter] = [MPRemoteCommandCenter.shared()]' in app
    assert 'let maximumConcurrentProviders = max(1, sourceManifests.count)' in cat
    assert 'while let optionalResult = await group.next()' in cat


def test_v211_trakt_restore_resync_preserved():
    assert 'manualResyncFromSettings() async -> Bool' in trakt
    assert 'restorePersistedConnectionIfNeeded()' in trakt
    assert '✓ Trakt resync complete' in trakt


def test_v212_source_catalog_fast_paths_preserved():
    assert 'configuration.httpMaximumConnectionsPerHost = 16' in cat
    assert 'sourceLinkMemoryCacheTTL: TimeInterval = 240' in cat
    assert 'sourceManifestMemoryCacheTTL: TimeInterval = 900' in cat
    assert 'forceOfficialRefresh: Bool = false, forceCompleteRows: Bool = false' in cat
    assert '[1, 3, 8, 20, 45, 90, 180]' in cat


def test_no_merge_conflict_markers():
    for rel in ('Sources/DebridChannelsTVOSApp.swift','Sources/CatalogStore.swift','Sources/TraktSyncManager.swift','Sources/TraktCatalogService.swift','project.yml'):
        text=(r/rel).read_text()
        assert '\n<<<<<<< ' not in text
        assert '\n=======' not in text
        assert '\n>>>>>>> ' not in text
