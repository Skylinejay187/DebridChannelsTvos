# APP-WIDE REGRESSION LOCKS — vBRDC215

1. Build only from packaged vBRDC214 donor; no older-source reconstruction.
2. Main catalog Up/Down must retain a single persistent rail. Do not reintroduce an outgoing+incoming vertical pager or row crossfade.
3. Main catalog vertical motion must remain compositor-only after the atomic destination-row rebind; focus/index semantics remain unchanged.
4. Playback-browse catalog vertical behavior remains untouched.
5. vBRDC214 universal Stremio addon fan-out remains universal for every configured stream addon; do not restore the 12-addon application queue.
6. vBRDC214 Bluetooth/Now Playing route remains: shared MPRemoteCommandCenter first, MPNowPlayingSession mirrored, default+session metadata publication, muted ownership anchor kept playing for the real media session.
7. vBRDC211 Trakt restore/manual resync and vBRDC212 Source Intelligence/catalog force-load contracts remain preserved.
8. No UI layout/theme redesign, no provider ranking changes, no player-engine changes, no catalog type/filter changes in this build.
