# vBRDC258 build fix 2 — AetherEngine 6.80 / Xcode 16.4 compatibility

GitHub Actions failure from run logs_93909614127.zip was inside vendored AetherEngine 6.80.0, not Debrid Channels app code.

Root causes under Xcode 16.4 / Swift 6.1:
- Swift 6 strict concurrency rejected several AVFoundation async results (`AVMediaSelectionGroup`, `[AVAssetTrack]`) as non-Sendable.
- Aether 6.80 references SDK APIs introduced after Xcode 16.4: `UITraitCollection.hdrHeadroomUsageLimit`, `AVSampleBufferDisplayLayer.preferredDynamicRange`, and `VTRegisterSupplementalVideoDecoderIfAvailable`.

Fix:
- Keep AetherEngine at 6.80.0 and AetherFFmpegBuild at 3.2.0.
- Compile the Aether package in Swift 5 language mode on the current CI toolchain to avoid strict-Sendable import errors.
- Add an Xcode 16.4 compatibility patch that compiles out only the newer SDK diagnostic/render-hint APIs. The 6.80 live/IPTV contracts remain intact: `liveSourceReset`, `nativeRemoteHLS`, `liveJoinProfile`, first-frame readiness and DVR foundations.
- No Debrid Channels app architecture, KSPlayer FFmpegKit graph, native framework embedding, or version identifiers were changed.

Version remains vBRDC258 / 1.0.961 / build 961 because the prior v258 did not successfully build.
