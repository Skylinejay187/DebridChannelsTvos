# Debrid Channels vBRDC234 — KSPlayer Nuvio-Style Zero-Delay Handoff Build Fix

Version: 1.0.937 (937)
Release ID: vBRDC234
Base: vBRDC233

## Fix
- Restores Xcode target membership for `Sources/PlaybackKit/PlaybackLaunchBenchmark.swift` in `project.yml`.
- Fixes the GitHub Actions compiler failure: `cannot find PlaybackLaunchBenchmark in scope`.
- No AetherEngine changes.
- No rollback or behavior change to the vBRDC233 Nuvio-style zero-delay prepared-source handoff.
- No rollback or behavior change to Live TV unity/focus polish.

## Scope
Only build membership/version metadata changed. Playback benchmark implementation and all vBRDC233 functional source remain intact.
