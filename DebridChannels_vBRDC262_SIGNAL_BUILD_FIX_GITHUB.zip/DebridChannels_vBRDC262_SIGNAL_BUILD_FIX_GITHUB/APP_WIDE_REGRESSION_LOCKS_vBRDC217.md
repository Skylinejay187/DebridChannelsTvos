# vBRDC217 regression locks

1. Do not regress the vBRDC216 fixed-slot instant main catalog vertical row swap. No compositor glide, row offset, fade, two-row pager, or delayed visual transition may be reintroduced.
2. Do not pause the muted MediaRemote anchor while a real playback session exists; vBRDC214 fixed repeated Bluetooth Play/Pause by keeping that anchor alive through real-player pause.
3. Keep `MPRemoteCommandCenter.shared()` registered as the primary Bluetooth/accessory route.
4. When `MPNowPlayingSession` is active, publish its session-scoped Now Playing center first and mirror the same complete snapshot to the default center.
5. Re-publish metadata after session activation succeeds. Do not return to a publish-before-activation-only lifecycle.
6. If the synthetic session cannot become active or is rejected, retain the shared Bluetooth command center and use the default Now Playing center fallback rather than leaving a rejected session alive.
7. Never overwrite concrete movie/TV `MPMediaItemPropertyMediaType` with `.anyVideo`.
8. Keep VOD decoder Now Playing timing updates bounded at the existing ~5-second delta; do not create a new SwiftUI high-frequency playback clock.
9. Keep the MediaRemote heartbeat process-level and low frequency (10 seconds), not a view invalidation timer.
10. Keep Now Playing artwork isolated from the main catalog artwork cache and start remote artwork only after first frame.
11. Preserve universal simultaneous Stremio addon fan-out from vBRDC214 and all vBRDC212 Source Intelligence/cache/catalog fast paths.
12. Preserve vBRDC211 Trakt automatic restore resync and explicit manual confirmation.
13. Do not change KSPlayer/VLC playback ownership or the approved app icon/resources in this build line.
