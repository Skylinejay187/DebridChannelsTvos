# Debrid Channels vBRDC218 — Main Catalog Playback-Focus Parity

Release: **vBRDC218**  
Marketing version: **1.0.921**  
Build: **921**

## Why v216/v217 still looked wrong

The two user videos exposed that the remaining defect was **not another vertical-scroll animation**. v216 already used the same one-row, animation-disabled data rebind as the VOD/Live-TV playback catalog.

The main screen has one additional piece that playback browsing does not: the permanently mounted top-navigation focus graph. During an Up/Down row rebind tvOS could release the catalog `FocusState` for a render turn. `FixedSlotFocusedCatalogCard` then changed from its focused **390×220, -6pt** presentation to its **82% unfocused** geometry and later regained focus. On television this looks exactly like the whole catalog row drops/jumps even though the row container itself never moved.

The first video shows that geometry loss; the second playback video is the reference behavior.

## vBRDC218 fix

- Keeps the destination row replacement as one animation-disabled fixed-slot transaction.
- Removes the obsolete per-row `store.topMenuFocusLocked = true` publication from the main vertical navigation hot path. The persistent UNITY shell already disables top-menu interaction while catalog rows own focus, so this write only forced an unnecessary app-wide environment-object publication.
- Main-screen vertical navigation now pins the existing focused-card **visual geometry** across the row rebind.
- The pin is part of the same transaction as `activeRowIndex` and `focusedRow`; there is no intermediate frame with an unfocused/shrunken card.
- A bounded main-actor focus handoff reasserts the destination row for a few render turns, then releases the visual pin with animations disabled.
- Rapid Up/Down cancels the previous release task and advances the generation owner, so an old handoff cannot release focus over a newer row.
- The v214 160ms decorative-work delay remains non-visual. Preview/trailer/hero metadata resume only after navigation settles.
- No vertical offset, fade, crossfade, spring, second row tree, or compositor glide was added.
- Playback-browse catalog behavior is not replaced or redesigned; it remains the visual reference.

## Regression preservation

vBRDC218 preserves the v217 Now Playing/Home Assistant heartbeat work, v216 fixed-position catalog row rebind, v214 Bluetooth headphone ownership and universal Stremio source fan-out, v212 Source Intelligence/catalog fast paths, and v211 Trakt restore/resync behavior.

## Validation boundary

Linux Swift parser and contract validation can verify syntax and source invariants but cannot perform a full tvOS SDK/Xcode compile or reproduce the Apple TV focus engine. GitHub Actions/Xcode remains authoritative for compile/link; the physical Apple TV remains authoritative for the final focus/scroll feel.
