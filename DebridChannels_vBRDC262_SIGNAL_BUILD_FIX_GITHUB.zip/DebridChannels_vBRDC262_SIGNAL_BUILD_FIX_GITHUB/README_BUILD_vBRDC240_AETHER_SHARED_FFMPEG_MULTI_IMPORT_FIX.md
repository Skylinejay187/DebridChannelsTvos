# Debrid Channels vBRDC240 — Aether Shared FFmpeg Multi-Import Fix

Version: **1.0.943 (943)**  
Release ID: **vBRDC240**

## Build failure fixed
vBRDC239 correctly moved AetherEngine and KSPNUVIO onto one shared FFmpegBuild package, but its KSP fetch-time safety check expected one stale `import FFmpegKit`. The pinned KSPNUVIO revision actually contains five stale umbrella imports, so XcodeGen stopped before project generation.

vBRDC240 patches the exact five known KSP source files reported by the pinned revision:
- `MEPlayer/MEPlayerItem.swift`
- `MEPlayer/VideoToolboxDecode.swift`
- `MEPlayer/FFmpegAssetTrack.swift`
- `MEPlayer/AVFFmpegExtension.swift`
- `MEPlayer/AVFoundationExtension.swift`

The fetch script now requires that exact set, removes all five imports, then scans all KSPlayer Swift sources and fails if any `import FFmpegKit` remains.

## Preserved
- AetherEngine primary, pinned to 5.5.1 for Xcode 16 compatibility.
- KSPlayer/KSPNUVIO fallback.
- Shared FFmpegBuild 2.0.0 dependency graph.
- tvOS/iOS/macOS package platform alignment.
- Nuvio-style zero-delay prepared-source handoff.
- Resume/progress, Now Playing/Bluetooth ownership, source failover, previews, VOD overlay and Live TV unity tree.
- Live TV upward-focus correction: focus may enter the persistent top bar at Home without changing the selected Live TV category.

Full tvOS/Xcode compilation remains authoritative in GitHub Actions.
