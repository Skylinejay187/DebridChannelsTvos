# Debrid Channels vBRDC239 — Aether Shared FFmpeg Import Cleanup

Release: vBRDC239
Version: 1.0.942 (942)

Build fix only, forward from vBRDC238.

GitHub Actions vBRDC238 reached KSPlayer compilation, proving the Aether 5.5.1 pin, shared FFmpegBuild graph, and platform alignment were accepted. Compilation then failed because the pinned KSPNUVIO source still contained a legacy `import FFmpegKit` in `AVFFmpegExtension.swift` even though the package now consumes FFmpegBuild's individual Libav* products.

vBRDC239 updates the KSPNUVIO fetch/patch step to remove exactly one stale `import FFmpegKit` after checkout. It fails fast if the expected upstream shape changes.

Preserved: Aether primary, KSPlayer fallback, Aether exact 5.5.1 pin, FFmpegBuild 2.0.0 shared provider, tvOS 16 package alignment, Debrid Channels tvOS 17 deployment, Live TV focus correction, zero-delay handoff, resume/progress, Now Playing/Bluetooth ownership, previews, failover, and current VOD/Live TV UI architecture.
