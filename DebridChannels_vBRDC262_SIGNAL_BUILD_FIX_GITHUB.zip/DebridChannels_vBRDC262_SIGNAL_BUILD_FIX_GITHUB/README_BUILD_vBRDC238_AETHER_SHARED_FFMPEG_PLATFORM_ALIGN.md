# vBRDC238 — Aether shared-FFmpeg platform alignment

Release: vBRDC238
Version: 1.0.941 (941)

## Build fix
vBRDC237 correctly unified AetherEngine and KSPNUVIO on FFmpegBuild 2.0.0, removing duplicate Libav* package products. GitHub Actions then reached the build phase and exposed a deployment-target mismatch: the generated KSPNUVIO Package.swift still declared tvOS 13 while FFmpegBuild 2.0.0 requires tvOS 16.

The KSPNUVIO patch manifest now aligns dependent minimums with FFmpegBuild 2.0.0:
- macOS 14
- iOS 16
- tvOS 16

Debrid Channels itself remains tvOS 17 in project.yml. No playback logic, Aether/KS fallback routing, resume/progress, zero-delay handoff, Now Playing/Bluetooth ownership, source failover, or Live TV focus behavior changed in this release.
