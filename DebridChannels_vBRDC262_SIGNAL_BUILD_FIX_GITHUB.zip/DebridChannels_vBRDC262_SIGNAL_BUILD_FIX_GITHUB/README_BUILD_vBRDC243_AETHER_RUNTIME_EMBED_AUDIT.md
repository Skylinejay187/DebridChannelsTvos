# Debrid Channels vBRDC243 — Aether runtime embed + dyld audit

Release: **vBRDC243**  
Version: **1.0.946 (946)**

## Why vBRDC242 installed but would not open
The on-device `.ips` report for DebridChannelsTVOS 1.0.945 (945) is a launch-time
DYLD termination, not an app-code crash. `AetherPlaybackBridge.framework` was embedded
successfully, but its dynamic dependency `@rpath/AetherLibavcodec.framework/AetherLibavcodec`
was absent from `DebridChannelsTVOS.app/Frameworks`.

That proves the vBRDC242 dynamic framework isolation compiled and installed, while the
transitive Aether FFmpeg runtime frameworks were not copied into the final application bundle.

## vBRDC243 correction
The DebridChannelsTVOS app target now has a deterministic post-build runtime embed phase.
It copies all nine FFmpegBuild 3.0.0 namespaced dynamic frameworks from Xcode's processed
build products into the final app bundle:

- AetherLibavcodec.framework
- AetherLibavformat.framework
- AetherLibavutil.framework
- AetherLibswresample.framework
- AetherLibswscale.framework
- AetherLibavfilter.framework
- AetherLibdav1d.framework
- AetherLibzimg.framework
- AetherLibzvbi.framework

The embedded copies have development-only Headers/PrivateHeaders/Modules removed.

## Runtime dependency hardening
After embedding, the build runs `otool -L` on `AetherPlaybackBridge` and every embedded
Aether runtime framework. Any `@rpath/Aether*.framework/...` dependency that does not exist
inside the final app's `Frameworks` directory terminates the build immediately.

This converts the exact vBRDC242 device-launch failure from a runtime surprise into a
GitHub build-time contract.

## Architecture preserved
- AetherEngine 6.57.0 remains behind `AetherPlaybackBridge`.
- AetherFFmpegBuild remains exact 3.0.0.
- KSPlayer/KSPNUVIO remains on its native FFmpegKit 6.1.3 ABI.
- No app source imports AetherEngine or AetherLibav* directly.
- Aether remains primary with KSPlayer fallback.
- Resume/progress, zero-delay source handoff, Now Playing/Bluetooth, source failover,
  Live TV unity navigation, and Live TV upward focus-to-Home behavior are unchanged.
