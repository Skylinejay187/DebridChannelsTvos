# vBRDC257 — 1.0.960 (960)

Post-Phase-5 stabilization gate before Aether-native VOD cache / Live TV timeshift.

## Primary fixes
- Live TV now enters Aether through the full engine transition path instead of direct surface flags.
- Aether Live TV receives an explicit IPTV-safe HTTP request profile while preserving source headers.
- MediaFlow live routing receives the same upstream headers.
- Live Aether buffering no longer writes into the VOD PlaybackKit session lane.
- Source Intelligence suppresses duplicate status/message publications in addition to duplicate link-array publications.

## Roadmap lock
No VOD cache or DVR/timeshift implementation is included yet. Reliable ordinary Aether Live TV playback is the prerequisite.
