# APP-WIDE REGRESSION LOCKS — vBRDC218

1. Main Home/Movies/TV Shows Up/Down keeps the catalog rail at a fixed Y position. No vertical offset, fade, row crossfade, or whole-rail spring may be introduced.
2. Main vertical row rebind must keep the focused card visually focused throughout the focus-graph handoff; the 390×220 focused geometry must never briefly fall to the 82% unfocused geometry during Up/Down.
3. The main vertical hot path must not publish `topMenuFocusLocked = true`; catalog presentation ownership already disables the top navigation.
4. VOD/Live-TV playback catalog browsing remains the visual reference and keeps its existing fixed-slot row behavior.
5. Bluetooth/headphone Play/Pause ownership from v214-v217 remains intact.
6. Now Playing metadata publication, media types, artwork and 10-second heartbeat from v217 remain intact.
7. Universal Stremio source-addon fan-out and v212 Source Intelligence/catalog loading fast paths remain intact.
8. Trakt restore/resync behavior remains intact.
