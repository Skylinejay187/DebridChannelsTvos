# vBRDC213 Regression Locks

vBRDC213 is a compile/package correction release. Preserve all verified vBRDC211 and vBRDC212 runtime behavior.

## vBRDC211 locks
- Keep KSPlayer/VLC as the real playback engines.
- Keep DebridSystemMediaAnchor.m4a bundled only for MPNowPlayingSession/MediaRemote ownership.
- Keep session-scoped Now Playing metadata and session + shared remote command centers.
- Keep Bluetooth VOD/Live TV command routing and duplicate suppression.
- Keep Trakt explicit resync success confirmation.
- Keep restore-code Keychain recovery and exactly-one automatic Trakt playback resync when eligible.
- Keep `playbackAlreadySynchronized` / `skipPlaybackRefresh` protection against a duplicate progress refresh.

## vBRDC212 locks
- Keep fail-fast Source Intelligence request/resource budgets and no waits-for-connectivity.
- Keep bounded 12-lane sliding provider concurrency and completion-order publishing.
- Keep source links interactive on first arrival.
- Keep parallel identity hydration, manifest capability filtering, type boundary filtering, and configure-page normalization.
- Keep bounded short-lived memory caches; never persist debrid/source URLs to disk.
- Keep PLAY starting from the first ranked direct source.
- Keep force-reload generation supersede and first-paint publication bypass.
- Keep dedicated high-connection catalog session and bounded parallel first-page fallback.
- Keep fast visible reload followed by background full-shelf paging.
- Keep durable cached catalogs as fallback.

## vBRDC213 lock
- App, Top Shelf, project, Trakt app version, and runtime release User-Agents must remain vBRDC213 / 1.0.916 / 916 for this package.
