# Debrid Channels vBRDC227 — Membership Lockout Compile Fix

Base: vBRDC226.

## Build fix
GitHub Actions reported a Swift compiler type-check timeout in `DebridChannelsTVOSApp.swift` at the unified Live TV list row. The row had accumulated layout, conditional styling, focus and playback interaction modifiers in one generic SwiftUI expression.

vBRDC227 splits that expression into three opaque helper boundaries:
- `liveListRow`
- `liveListRowFocusable`
- `liveListRowChrome`

This preserves the exact List presentation and interaction behavior while reducing the generic expression the Swift compiler must solve at once. No membership logic, Live TV playback logic, Grid/List/EPG behavior, artwork logic or backend contract was changed.

Version: 1.0.930 (930)
