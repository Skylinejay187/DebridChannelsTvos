#!/usr/bin/env bash
set -euo pipefail

echo "============================================================"
echo "DEBRID CHANNELS TVOS V733 PREGEN FETCH REAL LIBMPV"
echo "MPVKit is removed. FFmpegKit remains the only SwiftPM FFmpeg provider."
echo "This runs BEFORE xcodebuild so Vendor/libmpv/libmpv.framework exists before link/embed."
echo "============================================================"

ROOT="$(pwd)"
mkdir -p "$ROOT/Vendor/libmpv" "$ROOT/Vendor/MPV" "$ROOT/.build-cache/libmpv"
rm -rf "$ROOT/Vendor/MPVKit"

TARGET_FW="$ROOT/Vendor/libmpv/libmpv.framework"
TARGET_XC="$ROOT/Vendor/libmpv/libmpv.xcframework"
if [ -d "$TARGET_FW" ]; then
  BYTES=$(find "$TARGET_FW" -type f -exec stat -f%z {} \; 2>/dev/null | awk '{s+=$1} END {print s+0}')
  echo "Existing libmpv.framework bytes: $BYTES"
  if [ "$BYTES" -ge 5000000 ]; then
    echo "Existing real libmpv.framework present; skipping download."
    exit 0
  fi
  echo "Existing libmpv.framework too small; replacing."
  rm -rf "$TARGET_FW" "$TARGET_XC"
fi

CACHE="$ROOT/.build-cache/libmpv"
rm -rf "$CACHE/extract"
mkdir -p "$CACHE/extract"

ASSET_URL="${LIBMPV_XCFRAMEWORK_URL:-}"
if [ -n "$ASSET_URL" ]; then
  echo "Using LIBMPV_XCFRAMEWORK_URL override: $ASSET_URL"
fi

if [ -z "$ASSET_URL" ]; then
  echo "Querying media-kit/libmpv-darwin-build release API for tvOS xcframework artifact..."
  for REPO in media-kit/libmpv-darwin-build bsogulcan/libmpv-darwin-build; do
    for TAG in v0.7.0 v0.6.4 v0.6.3 v0.6.2 v0.6.1 v0.6.0; do
      API="https://api.github.com/repos/$REPO/releases/tags/$TAG"
      JSON="$CACHE/release_${REPO//\//_}_$TAG.json"
      echo "Checking $API"
      if curl -fsSL --retry 3 --retry-delay 3 --connect-timeout 30 -H 'Accept: application/vnd.github+json' -o "$JSON" "$API"; then
        CANDIDATE=$(python3 - "$JSON" <<'PY'
import json, re, sys
path=sys.argv[1]
try:
    data=json.load(open(path))
except Exception:
    sys.exit(0)
assets=data.get('assets') or []
patterns=[
    re.compile(r'libmpv.*xcframeworks?_.*tvos.*video.*(default|full).*\.(tar\.gz|tgz|zip)$', re.I),
    re.compile(r'libmpv.*tvos.*xcframeworks?.*video.*(default|full).*\.(tar\.gz|tgz|zip)$', re.I),
    re.compile(r'libmpv.*xcframeworks?_.*appletvos.*video.*(default|full).*\.(tar\.gz|tgz|zip)$', re.I),
    re.compile(r'libmpv.*(tvos|appletvos).*\.(tar\.gz|tgz|zip)$', re.I),
]
for pat in patterns:
    for a in assets:
        name=a.get('name','')
        url=a.get('browser_download_url','')
        if 'simulator' in name.lower() or 'iossimulator' in name.lower():
            continue
        if pat.search(name) and url:
            print(url)
            raise SystemExit
PY
)
        if [ -n "$CANDIDATE" ]; then
          ASSET_URL="$CANDIDATE"
          echo "Selected libmpv asset: $ASSET_URL"
          break 2
        fi
      fi
    done
  done
fi

if [ -z "$ASSET_URL" ]; then
  echo "ERROR: Could not locate a prebuilt tvOS libmpv/mpv xcframework asset."
  echo "This is intentional: we refuse to build a fake MPV option."
  echo "Set LIBMPV_XCFRAMEWORK_URL to a real tvOS libmpv.xcframework archive or add Vendor/libmpv/libmpv.framework."
  exit 1
fi

ARCHIVE="$CACHE/$(basename "${ASSET_URL%%\?*}")"
echo "Downloading real libmpv tvOS artifact: $ASSET_URL"
curl -fL --retry 5 --retry-delay 5 --connect-timeout 30 -o "$ARCHIVE" "$ASSET_URL"
ARCHIVE_BYTES=$(stat -f%z "$ARCHIVE")
echo "Downloaded libmpv archive bytes: $ARCHIVE_BYTES"
if [ "$ARCHIVE_BYTES" -lt 1000000 ]; then
  echo "ERROR: Downloaded libmpv artifact is too small."
  exit 1
fi

case "$ARCHIVE" in
  *.zip) unzip -q "$ARCHIVE" -d "$CACHE/extract" ;;
  *.tar.gz|*.tgz) tar -xzf "$ARCHIVE" -C "$CACHE/extract" ;;
  *) echo "ERROR: Unsupported libmpv archive: $ARCHIVE"; exit 1 ;;
esac

echo "Extracted MPV candidates:"
find "$CACHE/extract" -maxdepth 9 \( -iname 'libmpv.xcframework' -o -iname 'mpv.xcframework' -o -iname 'libmpv.framework' -o -iname 'mpv.framework' \) -print | head -100

FOUND_XC=$(find "$CACHE/extract" \( -iname 'libmpv.xcframework' -o -iname 'mpv.xcframework' \) -type d -print | head -n 1 || true)
FOUND_FW=""
if [ -n "$FOUND_XC" ]; then
  echo "Found xcframework: $FOUND_XC"
  rm -rf "$TARGET_XC"
  cp -R "$FOUND_XC" "$TARGET_XC"
  FOUND_FW=$(find "$TARGET_XC" \( -path '*/tvos-arm64/*.framework' -o -path '*/appletvos-arm64/*.framework' -o -path '*/*tvos*/*.framework' \) -type d -print | grep -vi simulator | head -n 1 || true)
fi
if [ -z "$FOUND_FW" ]; then
  FOUND_FW=$(find "$CACHE/extract" \( -iname 'libmpv.framework' -o -iname 'mpv.framework' \) -type d -print | grep -vi simulator | head -n 1 || true)
fi
if [ -z "$FOUND_FW" ]; then
  echo "ERROR: Could not find a tvOS arm64 libmpv/mpv framework inside artifact."
  find "$CACHE/extract" -maxdepth 7 -print | head -300
  exit 1
fi

echo "Using libmpv framework slice: $FOUND_FW"
rm -rf "$TARGET_FW"
cp -R "$FOUND_FW" "$TARGET_FW"
FW_BYTES=$(find "$TARGET_FW" -type f -exec stat -f%z {} \; 2>/dev/null | awk '{s+=$1} END {print s+0}')
echo "Vendored libmpv.framework bytes: $FW_BYTES"
if [ "$FW_BYTES" -lt 1000000 ]; then
  echo "ERROR: Vendored libmpv.framework is too small."
  exit 1
fi

echo "SUCCESS: real libmpv is now vendored before xcodebuild."
