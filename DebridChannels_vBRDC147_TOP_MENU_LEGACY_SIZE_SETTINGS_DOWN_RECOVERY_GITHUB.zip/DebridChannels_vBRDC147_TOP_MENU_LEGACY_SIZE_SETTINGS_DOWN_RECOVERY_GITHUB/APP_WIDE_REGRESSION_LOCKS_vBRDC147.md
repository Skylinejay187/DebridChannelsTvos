# vBRDC147 Regression Locks

- vBRDC146 is the authoritative base.
- v810 is reference-only for global top-menu sizing constants.
- Do not restore vBRDC132's universal Top Menu Down -> Live TV behavior.
- Top Menu Down must route to `focusedTab ?? selectedTab`.
- Live TV entry must continue through `liveTVMenuFocusEntryToken`.
- Home/Movies/TV Shows entry must continue through the existing catalog presentation + `contentFocusToken` path.
- Settings must reclaim its selected category when its content focus token is issued.
- No Live TV grid paging, Guide entry/exit, artwork/Gracenote recovery, playback, MediaFlow, Bluetooth, Sports, or provider behavior may change as part of this correction.
