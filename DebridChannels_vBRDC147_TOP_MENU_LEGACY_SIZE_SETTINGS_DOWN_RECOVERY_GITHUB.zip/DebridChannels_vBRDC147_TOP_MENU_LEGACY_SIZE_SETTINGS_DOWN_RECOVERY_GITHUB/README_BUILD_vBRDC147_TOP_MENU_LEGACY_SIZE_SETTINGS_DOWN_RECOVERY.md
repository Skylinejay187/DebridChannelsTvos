# Debrid Channels vBRDC147 — Top Menu Legacy Size + Settings Down Recovery

Release: **vBRDC147**  
Marketing version: **1.0.850**  
Apple build: **850**

## Base / donor discipline

- Build base: packaged **vBRDC146** only.
- Reference donor: packaged **v810** only for the original global top-menu tab sizing geometry.
- No v810 provider, playback, catalog, Live TV, Sports, Settings content, or backend code was imported.

## Changes

1. Restored the v810 global top-menu tab sizing geometry: 25-point configured font, 0.2 tracking, donor 22/12 horizontal and 9/7 vertical focus padding, 7-point tab stack spacing, 22/24-point rounded geometry, 54/64-point underline widths, and 1.018 focused scale.
2. Removed the vBRDC132 universal `Down -> Live TV` override. Down from the top menu now enters the category currently highlighted by the user.
3. Live TV still uses its dedicated native grid-entry token; Home/Movies/TV Shows still use the existing catalog content token; Settings/Favorites/Sports retain their native surface focus ownership.
4. Settings explicitly reclaims its selected category when Down returns from the top menu to Settings itself.

## Preserved

The vBRDC146 Live TV 12-card paging, Guide double-Down entry, Guide glow/exit rail, compact animated Live TV logo, triple-Left Live Controls protection, post-VOD Gracenote/logo recovery, playback, Bluetooth VOD ownership, MediaFlow, catalog loading, Sports, and backend runtime are unchanged.

## Validation

- vBRDC147 focused contract: **29/29 PASS**
- production Swift parse: **65/65 PASS**
- backend runtime suites: **36 passed + 2 subtests**
- app/Top Shelf plists: **PASS**
- project.yml parse: **PASS**

GitHub Actions/Xcode and physical tvOS hardware remain authoritative for Apple SDK compilation and final focus-engine behavior.
