from pathlib import Path
import plistlib, re, sys

ROOT = Path(__file__).resolve().parents[1]
APP = (ROOT / 'Sources/DebridChannelsTVOSApp.swift').read_text()
PROJ = (ROOT / 'project.yml').read_text()
checks = []
def check(name, cond): checks.append((name, bool(cond)))
def block_between(text, start, end):
    a = text.index(start); b = text.index(end, a); return text[a:b]

with (ROOT/'Sources/Info.plist').open('rb') as f: info = plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top = plistlib.load(f)
check('release id vBRDC147', info.get('DebridChannelsReleaseID') == 'vBRDC147' and top.get('DebridChannelsReleaseID') == 'vBRDC147')
check('marketing 1.0.850', info.get('CFBundleShortVersionString') == '1.0.850' and top.get('CFBundleShortVersionString') == '1.0.850' and PROJ.count('MARKETING_VERSION: 1.0.850') == 2)
check('build 850', info.get('CFBundleVersion') == '850' and top.get('CFBundleVersion') == '850' and PROJ.count('CURRENT_PROJECT_VERSION: 850') == 2)

top_menu = block_between(APP, 'struct TopMenuBar: View', 'struct GlobalSearchScreen: View')
move = top_menu[top_menu.index('.onMoveCommand'):top_menu.index('.onChange(of: store.menuFocusToken)')]
visual = top_menu[top_menu.index('HStack(spacing: topMenuSpacing)'):top_menu.index('.padding(.horizontal, topMenuUsesRail')]

# Exact v810 donor sizing geometry only.
check('v810 25-point top-menu label size restored', 'PopupTypography.font(topMenuFontPreset, size: 25' in visual)
check('v810 top-menu label tracking restored', '.tracking(0.2)' in visual)
check('v810 focused/unfocused horizontal padding restored', '.padding(.horizontal, focusedTab == tab ? 22 : 12)' in visual)
check('v810 focused/unfocused vertical padding restored', '.padding(.vertical, focusedTab == tab ? 9 : 7)' in visual)
check('v810 tab stack spacing restored', 'VStack(spacing: 7)' in visual)
check('v810 tab corner geometry restored', 'RoundedRectangle(cornerRadius: 22, style: .continuous)' in visual and 'RoundedRectangle(cornerRadius: 24, style: .continuous)' in visual)
check('v810 focused scale restored', '.scaleEffect(focusedTab == tab ? 1.018 : 1.0)' in visual)
check('v810 underline width geometry restored', '.frame(width: tab.rawValue == "Settings" ? 64 : 54, height: 4)' in visual)
check('later theme-family tab visual no longer drives global menu sizing', 'TopMenuTabVisual(' not in visual)

# Settings/top-menu Down recovery.
check('Down destination follows highlighted tab', 'let destination = focusedTab ?? store.selectedTab' in move)
check('Down no longer universally rewrites selection to Live TV', 'store.selectedTab = .live' not in move)
check('Down can switch selected category to highlighted destination', 'store.selectedTab = destination' in move)
check('Live TV destination still uses native entry token', 'if destination == .live' in move and 'store.liveTVMenuFocusEntryToken &+= 1' in move)
check('catalog destination still enters rows with one content token', 'UnitySurfaceSystem.catalogBranchActive(for: destination)' in move and 'store.catalogRowsPresented = true' in move and 'store.contentFocusToken &+= 1' in move)
check('Settings/Favorites/Sports native surfaces reclaim focus', 'Settings / Favorites / Sports / Membership own their native focus' in move and 'store.contentFocusToken &+= 1' in move)
check('Settings explicitly reclaims its selected category after top-menu Down', '.onChange(of: store.contentFocusToken)' in APP and 'focused = .category(selectedSettingsCategory ?? .general)' in APP)
check('top-menu focus is cleared before content re-entry', 'focusedTab = nil' in move and 'searchFocused = false' in move and 'store.topMenuFocusLocked = false' in move)

# vBRDC146 Live TV work remains intact.
check('12-card Live TV page remains', 'private let liveTVGridPageSize: Int = 12' in APP)
check('page-one triple-left hardening remains', 'leftEdgePanelArmCount >= 3' in APP)
check('bottom-row double-down Guide remains', 'liveTVGuideDockOriginChannelID == focusedID' in APP and 'openFullLiveTVGuide(from: focusedID)' in APP)
check('30-second glowing Guide hint remains', '30_000_000_000' in APP and 'LiveTVGuideGlowHint' in APP)
check('Guide exit rail remains', 'LiveTVGuideExitHint' in APP and 'Text("BACK\\nMENU")' in APP and 'Text("LEFT\\nTWICE")' in APP)
check('compact animated Live TV logo remains', 'private struct LiveTVAnimatedHeaderLogo: View' in APP and '.frame(width: 52, height: 30)' in APP)
check('post-VOD artwork recovery remains', 'beginForcedLiveTVArtworkBootstrap(reason: "movie/show playback return")' in APP)
check('Bluetooth VOD ownership remains', 'BluetoothVODMediaButtonCoordinator.shared.claimVODSession(' in (ROOT/'Sources/CatalogStore.swift').read_text())
check('MediaFlow router remains packaged', (ROOT/'Sources/MediaFlowProxyRouter.swift').exists())

passed = sum(ok for _, ok in checks)
for name, ok in checks:
    print(('PASS' if ok else 'FAIL') + ': ' + name)
print(f'\n{passed}/{len(checks)} checks passed')
if passed != len(checks): sys.exit(1)
