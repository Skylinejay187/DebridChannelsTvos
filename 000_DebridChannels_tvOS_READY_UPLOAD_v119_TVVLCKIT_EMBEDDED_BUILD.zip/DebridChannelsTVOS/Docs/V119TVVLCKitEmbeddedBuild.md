# v119 TVVLCKit embedded build repair

Purpose: fix the installed-app runtime message that TVVLCKit was not compiled into the IPA.

Changes:
- Removed the pinned old TVVLCKit version and allowed CocoaPods to resolve the current compatible TVVLCKit pod.
- GitHub Actions now verifies that the TVVLCKit module exists after `pod install`.
- GitHub Actions now builds the `.xcworkspace` only.
- GitHub Actions now fails before artifact upload if the resulting `.app` does not contain TVVLCKit/VLC framework files.
- Added a `Vendor/TVVLCKit` slot for a future manually vendored framework if needed.

This does not alter v73 Home/detail visuals.
