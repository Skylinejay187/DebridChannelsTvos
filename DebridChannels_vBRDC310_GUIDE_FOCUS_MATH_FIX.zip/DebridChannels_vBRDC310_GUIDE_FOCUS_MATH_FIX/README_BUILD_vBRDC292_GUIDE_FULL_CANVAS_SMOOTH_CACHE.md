# vBRDC292 — Guide Full Canvas / Focus / Smoothness / Poster Cache

Version: 1.0.995 (995)

Changes:
- Guide category selection now retains focus on the chosen category instead of snapping to All Channels.
- First Down from the Live TV mode switch enters the left Guide category rail; Right collapses the rail and moves into the EPG.
- Guide gets near edge-to-edge horizontal canvas while Grid/List keep their prior safe margins.
- Guide live preview is feathered on all four sides and still dissolves most strongly into the information side.
- Empty user-selected channel groups stay selected instead of silently reverting to All.
- Removed per-row Guide focus spring animation to reduce repeated geometry work during vertical scrolling.
- Premium artwork prefetch now decodes the useful 768px poster/card bucket rather than full originals.
- Artwork URLCache uses returnCacheDataElseLoad and explicitly stores successful responses in the 1 GB disk cache so poster bytes persist across launches even when CDN cache headers are weak.
- Background artwork publications are staggered over a few frames after navigation settles instead of all publishing on one MainActor frame.
- Global speculative artwork prefetch concurrency reduced from four to two jobs to prioritize Siri Remote scrolling.

Validation in this package is syntax/plist/YAML/asset/zip validation. The GitHub Xcode run remains the actual tvOS compiler check.
