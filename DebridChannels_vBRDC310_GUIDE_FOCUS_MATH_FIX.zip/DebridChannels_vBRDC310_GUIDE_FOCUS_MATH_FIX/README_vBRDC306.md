# vBRDC306 — Final Pre-Watch-Party Fixes

Base lineage: locked vBRDC303 -> vBRDC304 -> vBRDC305 -> vBRDC306
Version: 1.0.1009 (1009)

Fixes:
- Expanded Canvas catalog left-edge clipping: larger focus overscan margin for the 390x220 focused card.
- KSPlayer VOD handoff: manual/automatic KS switches immediately dismiss the engine panel and place a full loading cover above the outgoing frozen frame until first-frame confirmation.
- Volume Amplification: Aether 6.81 has no public >1.0 gain stage. Selecting +3/+6/+9/+12 dB while Aether is active now preserves the current timestamp and hands only that playback session to KSPlayer's existing FFmpeg volume-filter gain stage so the feature actually works.
- Trailer cadence: muxed full-screen trailers now use the dedicated native AVPlayerLayer path in Auto mode (matching NuvioTV's native tvOS strategy); split video/audio trailers retain KSPlayer.
- Trailer buffering/cadence: native trailer AVPlayer now waits to minimize stalling, uses a 6-second forward-buffer preference, retains unrestricted bitrate/4K ceiling, and no longer forces the live video subtree through SwiftUI compositingGroup.
- Explicit Aether trailer mode enables match-content instead of forcing display matching off.

Preserved:
- vBRDC305 Guide crash stack hardening.
- vBRDC304 Guide preview 16:9/fade and category-to-guide focus fixes.
