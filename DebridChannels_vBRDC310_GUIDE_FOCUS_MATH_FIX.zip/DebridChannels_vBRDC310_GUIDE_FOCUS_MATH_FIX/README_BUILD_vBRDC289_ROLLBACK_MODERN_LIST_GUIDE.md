# Signal vBRDC289 — 1.0.992 (992)

This package deliberately rolls Live TV back to the vBRDC280 architecture and preserves the v280 Grid presentation/behavior.

Targeted changes only:
- Grid remains the vBRDC280 Grid renderer.
- User-facing Live TV modes are Grid → List → Guide.
- List uses the approved modern list concept (#9): vertical channels on the left, large preview/program detail pane on the right.
- Guide is restyled around the requested living-room guide composition: borderless category rail on the left, large selected-program hero with a right-side live/artwork fade, and a wide EPG timeline below.
- Carousel is retired from the user-facing mode cycle.
- App icon, tvOS image-stack assets, raw compatibility icon, and inside-app SIGNAL wordmark are carried forward exactly from vBRDC288.
- The vBRDC284/vBRDC288 proven icon bundle post-build restoration is retained so tvOS receives both the asset-catalog icon and compatibility icon metadata.
- vBRDC280 Aether/KSPlayer, native trailer resolver, Aether EOF/Up Next hardening, Live TV source/EPG logic, Top Shelf architecture, and existing app features remain on the rollback baseline.

Validation in this package is static/local. The GitHub/Xcode tvOS build remains the final compiler/signing/runtime test.
