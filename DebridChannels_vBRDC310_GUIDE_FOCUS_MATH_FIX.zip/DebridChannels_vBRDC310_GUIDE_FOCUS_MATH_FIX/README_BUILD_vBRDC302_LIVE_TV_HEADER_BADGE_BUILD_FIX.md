# vBRDC302 — Live TV header/page badge compile fix

Minimal build-fix patch on vBRDC301. Restores the original v280 Live TV broadcast header and page-position badge helper views that remained referenced by Grid but were accidentally removed from the source. No behavior, styling, preview, paging, Aether glow, or Live TV preview-style changes beyond restoring those missing helpers.

Version: 1.0.1005 (1005)
