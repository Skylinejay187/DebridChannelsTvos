# Signal vBRDC278 — CI speed + icon build-phase fix

Version: 1.0.981 (981)

This build patches vBRDC277 only.

## Build failure fixed
The v277 failure came from the legacy `V379 Force compile AppIcon and merge actool partial plist` post-build phase. Xcode had already compiled `Assets.xcassets` successfully and created `Assets.car`; the redundant script then failed during its legacy raw-icon compatibility checks. The entire second `actool` pass is removed. The canonical `AppIcon.brandassets` collection remains in the Resources phase and the source Info.plist already contains the tvOS icon and Top Shelf keys.

## Faster clean GitHub builds
- Release app compilation now uses whole-module compilation for clean CI builds while retaining `-O` optimization.
- Xcode index-store generation is disabled in Release CI builds.
- Release debug info is `dwarf` rather than generating a separate dSYM during normal `build` jobs.
- Removed dead Carthage framework search paths that only produced linker warnings.
- Removed the redundant second asset-catalog compilation/audit pass.

No runtime feature, trailer resolver, playback architecture, branding artwork, or Top Shelf artwork was removed.
