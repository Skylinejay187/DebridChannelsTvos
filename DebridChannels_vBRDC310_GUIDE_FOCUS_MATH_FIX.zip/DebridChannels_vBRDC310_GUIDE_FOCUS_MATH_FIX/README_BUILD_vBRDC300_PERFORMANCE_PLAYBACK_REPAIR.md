# vBRDC300 — Performance + playback repair

- Version: 1.0.1003 (1003)
- Restores automatic Settings category preview while browsing category cards. Down enters detail controls.
- Removes Grid Program Peek completely from UI, settings, backup/restore, and rendering.
- Raises Live TV artwork decode/prefetch concurrency to three, matching the bounded Nuvio-style decode architecture.
- Allows lightweight Up Next episode identity preparation during the final three minutes of an episode so AetherEngine and KSPlayer can show Up Next before EOF; provider/source preparation remains decoder-safe after stop/EOF.
- Widens the Spotlight Hub and related-title cards so poster/title content is not cropped.
- Increases AVPlayer clock publication to 250 ms and adds playback-clock presentation stabilization groundwork.
- Removes dead manual Settings category router left behind by the v297 focus rewrite.
