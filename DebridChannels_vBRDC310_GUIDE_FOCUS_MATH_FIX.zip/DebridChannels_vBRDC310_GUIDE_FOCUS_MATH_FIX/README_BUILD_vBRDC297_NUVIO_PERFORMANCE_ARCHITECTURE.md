# vBRDC297 — Nuvio-Inspired Performance Architecture

Version: **1.0.1000 (1000)**

This build keeps Signal's existing appearance/features while adapting proven public tvOS performance patterns observed in NuvioTVOS.

## Artwork / poster pipeline
- One global ImageIO decode gate limits concurrent heavy decodes to 3.
- Decoded-memory cache increased to 220 entries / 140 MB.
- Decode requests are normalized into reusable pixel buckets so near-identical card/hero sizes do not decode the same source repeatedly.
- Existing in-flight request coalescing and URL-keyed persistent source-byte cache remain authoritative.
- Persistent cache hits no longer write file metadata on every read; LRU access touches are throttled.
- Live TV Grid, Guide, Quick Guide and channel surfaces now share in-flight artwork requests and the same persistent source-byte cache.
- Live TV artwork URLSession is persistent instead of ephemeral and has a bounded disk URLCache.
- Live TV decoded sizes are bucketed so Grid/Guide requests can reuse the same bitmap.
- Speculative poster work remains cache-only during navigation; no fly-by ImageIO decode fan-out.

## Catalog / navigation
- Adds **Native Smooth**, an ease-out 0.22 s catalog-row motion with no spring settling or overshoot, and makes it the new default.
- Existing installs carrying the former default Classic Spring migrate once to Native Smooth; users may still select Classic Spring afterward.
- Focused hero metadata enrichment is delayed to 350 ms so it cannot compete with a remote-navigation frame.
- Live TV background artwork prefetch waits 350 ms after focus settles.
- Existing persistent fixed-slot catalog virtualization is preserved; only the small visible structural corridor stays mounted.

## Settings
- Settings category navigation is now a native horizontal tvOS ScrollView with one real focus target per category.
- While the detail pane owns focus, only the open category remains in the spatial focus graph, preventing focus flashes/double hops.
- Merely moving across category pills no longer constructs/replaces the full settings form; the detail pane mounts only on Select/Down.
- Category cards/backdrop are Equatable to reduce unrelated SwiftUI body work.
- The detail pane uses more of the 16:9 canvas, reducing wrapping and extra vertical work.

## Live TV
- KSPlayer remains the preview engine for Live TV Grid/Guide streams; this build does not substitute AVFoundation for ORL/live playback.
- Existing v296 native-focus page logic and delayed preview startup are retained.
- Live TV art fetch/decode is now shared/coalesced across Grid and Guide and disk-first across launches.

## Regression locks retained
- Original v280 Grid presentation.
- Grid + Guide only user-facing Live TV modes.
- Nuvio-style HD resolver only for manual Trailer button; lightweight catalog previews remain separate.
- KSPlayer loading cover for VOD.
- Aether/KSPlayer playback routing and TV-show Up Next work.
- Proven tvOS app icon stack, smaller in-app SIGNAL wordmark, and carousel Top Shelf.
