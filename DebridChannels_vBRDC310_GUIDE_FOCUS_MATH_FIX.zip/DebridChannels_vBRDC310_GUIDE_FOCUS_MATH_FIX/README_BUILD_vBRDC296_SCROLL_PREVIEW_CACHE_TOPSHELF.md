# vBRDC296 — Scrolling, Preview, Cache, and Top Shelf

Version: **1.0.999 (999)**

- Restores KSPlayer-backed Live TV Grid and Guide previews behind navigation dwell gates.
- Removes overlapping Live TV card focus springs and the two-step nil focus page handoff.
- Debounces Guide metadata/preview work while remote focus is moving.
- Reduces page-turn/background artwork work during Live TV navigation.
- Adds an app-owned 768 MB persistent source-byte artwork cache in addition to URLCache.
- Restores a deterministic KSPlayer VOD loading cover until the first rendered frame.
- Replaces the large Current Grid bottom video panel with a compact focused-program information strip.
- Removes top-menu focus animation overlap and suppresses double-selected emphasis.
- Converts the dynamic Top Shelf extension from sectioned posters to immersive carousel content using movie/show backgrounds.
