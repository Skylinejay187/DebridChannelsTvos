# vBRDC293 — Preview Performance / Trailer Playback Fix

Version: 1.0.996 (996)

This build is based on vBRDC292 and keeps the v280 Grid + Modern List + Guide rollback architecture.

Changes:
- Catalog focused-card previews remain on the original lightweight preview/backend lane; they never invoke Signal's Nuvio/Innertube HD Trailer-button resolver.
- Direct preview media is used immediately when metadata already exposes it.
- Catalog previews arm only after 2.5 seconds of settled focus and are skipped while UNITY reports active navigation.
- Live TV Grid focused-card preview no longer mounts KSPlayer/FFmpeg/Metal; it uses the lightweight AVFoundation preview surface and still preserves audible preview behavior.
- Live TV preview is skipped if the 3-second dwell expires while navigation is still active.
- Trailer Auto no longer selects KSPlayer for ordinary muxed MP4/HLS trailers; it uses AetherEngine. Explicit KSPlayer remains user-selectable for diagnostics.
- Native Nuvio-style resolver now prefers any reachable muxed progressive fallback before split adaptive video/audio, avoiding unnecessary KSPlayer adaptive handoffs and black trailer surfaces.
- Poster prefetch now warms persistent URLCache bytes only. It does not speculatively ImageIO-decode/GPU-upload posters while scrolling.
- The 1 GB persistent poster/artwork URLCache and explicit cached-response storage remain enabled.
- Removed v292's additional randomized post-navigation artwork publication delay that made rows feel sticky.

No change to v292 Guide geometry, app icon, inside SIGNAL wordmark, Top Shelf, Aether VOD path, or TV-show Up Next hardening.
