# vBRDC275 — Nuvio-style native trailer resolution

Version: 1.0.978 (978)

This build moves trailer resolution into the Signal tvOS app using the same public architecture observed in NuvioTVOS: direct Trailerio CDN first, then app-native YouTube Innertube player responses using iOS/Android/Android VR client contexts. HD HLS is preferred, then muxed HD MP4, then a 1080p/720p split adaptive video+audio pair.

Signal intentionally caps the native path at 1080p because the trailer popup does not benefit from 1440p/4K startup cost. The existing dedicated proxy and backend resolver remain compatibility fallbacks only. No cookie, Docker, or per-user YouTube setup is required for the native lane.

Also preserves Stremio trailer YouTube IDs as exact watch URLs so native resolving does not fall back to title search. Split adaptive pairs are handed to KSPlayer with the external audio URL; HLS/progressive can use the selected trailer engine.

Validation in this package is local/static only; GitHub/Xcode and Apple TV runtime are authoritative.
