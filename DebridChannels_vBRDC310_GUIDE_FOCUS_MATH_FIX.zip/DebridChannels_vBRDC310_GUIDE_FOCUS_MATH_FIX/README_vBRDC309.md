# vBRDC309 — Frame Budget Hardening
Version: 1.0.1012 (1012)

This pass is driven by the on-device HUD results: the display remained at 60 Hz while
Signal fell to 5–15 FPS and produced 400–1500 ms worst frames. The bottleneck is therefore
application work starving the 16.67 ms UI frame budget, not the Apple TV display mode.

Changes:
- Hidden main catalog shell now enters a true dormant presentation state. Its SwiftUI state
  survives, but hero/cards/RemoteImageFit owners are unmounted while Settings, Live TV,
  Guide, Favorites, Sports, etc. own the screen.
- Covered catalog shells no longer rebuild large row snapshots, restart hero metadata,
  preview resolution, or emergency artwork readiness on background store revisions.
- Catalog rows rebuild atomically when the catalog becomes visible again.
- Catalog/general ImageIO decode concurrency reduced 3 -> 1 to prevent CPU fan-out from
  multiple simultaneous poster/hero completions.
- Catalog artwork HTTP connection fan-out reduced 6 -> 3.
- Stale artwork requests with no mounted subscriber are cancelled after 60 ms during active
  navigation (160 ms otherwise), replacing the old 280 ms grace.
- Focused 390x220 catalog card decode budget reduced from 1024 to 768; hero/fullscreen
  quality budgets remain unchanged.
- Live TV ImageIO decode concurrency reduced 3 -> 1, prefetch jobs 3 -> 1, and artwork HTTP
  connections 4 -> 2. Visible identity/logo loads remain authoritative.
- Guide preview decoder warmup moved later (360 ms initial / 850 ms focus change) so focus
  and EPG geometry win the frame before video startup.
- v307/v308 performance HUD, Guide focus repair, Expanded Canvas position, trailer behavior,
  Aether/KSPlayer architecture, and crash hardening are preserved.

The trailer pipeline is intentionally untouched.
