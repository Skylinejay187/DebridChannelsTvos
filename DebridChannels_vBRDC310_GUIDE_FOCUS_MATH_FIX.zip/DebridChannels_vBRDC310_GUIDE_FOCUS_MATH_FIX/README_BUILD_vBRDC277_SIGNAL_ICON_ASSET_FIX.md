# Signal vBRDC277 — tvOS app-icon asset-stack build fix

Version: **1.0.980 (980)**

This build patches only the failed tvOS icon packaging from vBRDC276 while preserving the approved black SIGNAL artwork and the v276 native trailer/Top Shelf changes.

## Fix
- Corrected both Apple TV image-stack layer orders to front → middle → back.
- The fully opaque black SIGNAL background layer is now the final content-bearing layer, satisfying `actool`'s tvOS requirement.
- No new icon mockup or artwork redesign was performed.
- Top Shelf artwork and sizing from v276 are preserved.
- Manual Docker/YouTube resolver IP input remains removed; native trailer resolution remains unchanged.
- App and Top Shelf identifiers synchronized to vBRDC277 / 1.0.980 / 980.

## Previous GitHub failure addressed
`The last image stack layer with content, “Front”, must be a fully opaque bitmap.`
