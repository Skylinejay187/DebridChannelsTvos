# Signal vBRDC276 — native trailer cleanup + approved branding

Version: **1.0.979 (979)**

- Removed the manual YouTube Docker/proxy IP input from Settings.
- Removed the retired per-user YouTubeProxy lane and package.
- Signal trailer resolution now starts with the v275 native Trailerio/YouTube Innertube resolver and falls through automatically to the existing direct/cached/backend trailer fallback when necessary.
- Replaced Apple TV app-icon artwork with the approved black widescreen SIGNAL artwork at exact tvOS asset dimensions.
- Rebuilt Top Shelf static fallback assets at exact 1920×720 and 2320×720 sizes without stretching, and bumped the Top Shelf cache identity so old artwork is not retained after update.
- App and Top Shelf version identifiers synchronized to vBRDC276 / 1.0.979 / 979.
