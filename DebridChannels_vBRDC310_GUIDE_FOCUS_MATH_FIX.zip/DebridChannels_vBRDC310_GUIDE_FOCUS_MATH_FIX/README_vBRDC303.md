# vBRDC303 — Native Grid + Expanded Canvas

- Replaces the 12-card Live TV page LazyVGrid with a stable non-lazy 3x4 focus graph.
- Keeps the v280 visual card design while reducing edge remount/focus churn.
- LEFT edge deliberate paging now rejects repeats inside 650 ms.
- Settings category rail uses native tvOS focus scrolling without programmatic scroll-to-center.
- Focus release/defocus uses a slower ease-out settle instead of snapping.
- Live TV header/focus pulse timing is slowed.
- Live TV Preview Pop Out has a larger lift/shadow once preview is active.
- Expanded App Canvas no longer scales the 1920x1080 root. It reflows margins in Live TV, Settings, and catalog rails instead to avoid clipping the SIGNAL logo/focused cards.
- Full-screen playback remains unscaled.
