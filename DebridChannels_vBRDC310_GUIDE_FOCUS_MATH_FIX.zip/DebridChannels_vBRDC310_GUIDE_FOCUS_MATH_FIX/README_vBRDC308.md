# vBRDC308 — v307 Performance Build Fix
Version: 1.0.1011 (1011)

Fixes only the compile errors exposed by the v307 GitHub tvOS build while preserving the
v307 performance architecture changes:
- Performance HUD AppStorage moved to SettingsScreen, its actual owner.
- HUD setting uses the existing SettingsButton control; no nonexistent SettingsToggleRow.
- Guide lifecycle cancellation uses LiveTVScreen's actual liveTVAsyncRuntime owner.
- Guide preview warmup cancellation uses gridInteractionRuntime.guidePreviewWarmupTask and
  invalidates guidePreviewWarmupGeneration.
- v307 frame pacing probe, Guide focus fix, Expanded Canvas geometry, image decode budget,
  trailer behavior, player changes, and prior crash hardening remain intact.
