# vBRDC310 — Guide Focus Math Fix
Version: 1.0.1013 (1013)

Focused correction on top of vBRDC309.

Problem:
tvOS could find a valid Guide channel to the right of most category rows and transfer focus
natively. In that case the category row's onMoveCommand never fired, so the rail stayed open.
Only rows near the bottom/edge, where tvOS had no natural geometric target, reached the old
move handler and collapsed correctly.

Fix:
- Category -> Guide handoff is now driven by FocusState ownership transitions, not by the
  child onMoveCommand.
- The last real category-row index is retained independently.
- When native focus enters a Guide channel while the rail is open, Signal computes the
  destination row ordinal from the current rendered channel corridor and clamps that ordinal
  into the newly selected category.
- Category selection, virtual-window reset, channel selection, rail collapse and destination
  guide focus commit in one no-animation transaction.
- The old onMoveCommand remains only as an edge/bottom fallback and uses the exact same helper.
- Left from Guide rows re-opens the rail and primes the same source index for the next Right.

All vBRDC309 frame-budget hardening and trailer behavior are preserved.
