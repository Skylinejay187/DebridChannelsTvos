# vBRDC301 — Aether VOD glow + Live TV preview style + LEFT paging fix

- Removes the TheaterAmbientArtworkGlow layer only while AetherEngine owns VOD playback, eliminating the extra white lighting that was washing out cast/portrait artwork.
- Adds Live TV Preview Style with Standard (default) and Pop Out. Pop Out increases focused-card lift only after the live KSPlayer preview has actually started; normal browsing geometry is unchanged.
- Absorbs duplicate LEFT-edge Siri Remote repeats within 300 ms so page-back remains a deliberate second LEFT press instead of an accidental double action.
- Preserves v300 playback, Up Next, skip, cache, Grid/Guide and performance work.
