# vBRDC291 — Guide rail collapse + reference-style EPG

Version: 1.0.994 (994)

Built from the vBRDC290/v280 rollback line. The original v280 Live TV Grid remains untouched.

Live TV Guide changes:
- Guide now opens with the left channel/category rail owning focus.
- Right from the category rail collapses it and expands the EPG into the reclaimed width.
- Left from the guide restores the rail and returns focus to the active category.
- Collapse/expand uses a spring layout transition rather than a simple label hide.
- Timeline header and hero remain fixed; only channel rows scroll vertically.
- The EPG row viewport is hard-clipped so channel/program cells cannot bleed into the time header or preview area.
- Upper-right preview/artwork remains aspect-fill and uses a stronger horizontal fade into black.
- Guide schedule cells are flat dark blocks without artwork thumbnails; the focused live program becomes a bright tile.
- A single red current-time line spans the timeline instead of per-cell progress markers.
- Category rail has no divider wall; inactive categories blend into the black surface.

Preserved:
- Original v280 Grid.
- Modern List (#9).
- Existing source/EPG/Gracenote loading and playback behavior.
- Aether/trailer/Up Next baseline.
- Current app icon and inside SIGNAL wordmark.
