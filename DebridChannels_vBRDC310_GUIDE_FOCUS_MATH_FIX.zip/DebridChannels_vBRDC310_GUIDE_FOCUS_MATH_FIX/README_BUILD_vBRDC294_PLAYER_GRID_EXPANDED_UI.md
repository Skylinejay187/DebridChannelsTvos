# vBRDC294 — VOD Default Player / Live TV Grid + Guide / Expanded Canvas

Version: 1.0.997 (997)

- Fixes persistent VOD internal-player preference so an explicit KSPlayer default is never migrated back to Aether.
- Live TV user-facing modes are Grid and Guide only; List/Carousel renderers are retired from the selector.
- Guide preview uses the lightweight AVFoundation browse surface and a more visible feathered presentation.
- Adds Appearance > Expanded App Canvas (off by default) to use more of the television canvas across non-playback app surfaces.
- Current Live TV Grid layout gains a bottom Now/Next preview/detail panel; Spread Out remains unchanged.
- Keeps v293 trailer split: focused previews stay lightweight while the Trailer button keeps the native Nuvio-style HD resolver.
