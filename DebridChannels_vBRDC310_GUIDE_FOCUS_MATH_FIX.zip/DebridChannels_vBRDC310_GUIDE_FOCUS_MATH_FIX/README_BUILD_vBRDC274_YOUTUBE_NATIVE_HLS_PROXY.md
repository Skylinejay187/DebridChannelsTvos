# vBRDC274 / 1.0.977 / 977 — YouTube Native-HLS Proxy Contract

This candidate is based on vBRDC273 and changes only the dedicated YouTube trailer proxy contract plus exact YouTube identity handoff when already available in catalog metadata.

## App-side
- Extracts a YouTube video ID from an existing `previewURL` when it is a YouTube watch, youtu.be, embed, Shorts, or live URL.
- Passes `videoId=` to the dedicated proxy so yt-dlp search is bypassed whenever Signal already knows the exact YouTube identity.
- Existing title/year fallback remains for catalog items that do not carry a YouTube URL.
- Existing proxy -> legacy trailer resolver fallback remains intact.

## Bundled proxy v275
- True progressive H.264/AAC MP4 remains a Range-capable direct relay.
- Separate YouTube video/audio no longer use the rejected fragmented-MP4 pipe.
- Adaptive H.264 + AAC are stream-copied into standard Apple HLS (MPEG-TS) with 1-second segments.
- HLS media lives only in Docker tmpfs/RAM and is destroyed with its session/container; no persistent trailer file is stored.
- HLS is prewarmed on resolve for lower first-frame latency.
- Idle ffmpeg remux sessions stop after 45 seconds without HLS requests.

No Aether Live TV recovery-ladder, VOD playback-engine, resume, catalog, or UI behavior was intentionally changed in this candidate.
