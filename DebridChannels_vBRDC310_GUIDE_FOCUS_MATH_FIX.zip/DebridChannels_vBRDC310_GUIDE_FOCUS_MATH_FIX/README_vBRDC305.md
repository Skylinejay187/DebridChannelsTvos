# vBRDC305 — Guide Crash Hardening

Base: vBRDC304, itself patched directly from locked vBRDC303.

Preserved fixes:
- Expanded Canvas first-card focus safety margin.
- Guide preview true 16:9 geometry, aspect-fit video/stills, existing fade retained.
- Guide category rail Right handoff targets a real Guide channel after collapse.

Crash fix from IPS evidence:
- IPS reports main-thread `Thread stack size exceeded` / EXC_BAD_ACCESS / SIGSEGV.
- Crashed stack names VODPlayerScreen playerInputTree, playerOverlayStateTree,
  playerPlaybackStateTree, playerTimelineStateTree and playerCommandTree through
  SwiftUI AttributeGraph.
- Those five large modifier stages now have explicit AnyView runtime type-erasure
  boundaries so AttributeGraph does not recursively traverse one giant generic tree.
- Removed duplicate synchronous LiveTV Quick Guide snapshot publication on player appear.
- The one authoritative startup snapshot publication is deferred one main-run-loop turn,
  avoiding ObservableObject publication while VODPlayerScreen.onAppear/setupPlayer is
  still mutating player state.

Version: 1.0.1008 (1008)
