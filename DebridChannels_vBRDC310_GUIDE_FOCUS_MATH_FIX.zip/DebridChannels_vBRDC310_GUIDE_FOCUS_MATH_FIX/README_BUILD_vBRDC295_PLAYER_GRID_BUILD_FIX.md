# vBRDC295 — Player/Grid Build Fix

Version: **1.0.998 (998)**

This is a minimal compile-fix patch on top of vBRDC294.

## Fix
GitHub/Xcode failed in `DebridChannelsTVOSApp.swift` on the new Current-grid bottom preview with:

`error: extra argument 'height' in call`

The invalid combined SwiftUI modifier:

`.frame(maxWidth: .infinity, height: 154, alignment: .leading)`

was split into two valid modifiers:

`.frame(height: 154)`
`.frame(maxWidth: .infinity, alignment: .leading)`

No Live TV behavior, VOD player preference logic, Guide behavior, poster cache behavior, preview routing, icon assets, or UI feature set was otherwise changed in this patch.
