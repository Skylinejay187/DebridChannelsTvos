# Signal vBRDC279 — 1.0.982 (982)

This build patches directly from vBRDC278.

## Changes

- Restores the tvOS Home Screen app icon using a real layered `AppIcon.brandassets` stack with non-empty Front/Middle layers and an opaque Back layer.
- Removes legacy raw-icon Info.plist declarations that could conflict with the asset-catalog primary icon. Raw 1280x768 artwork remains bundled only for sideload/browser compatibility.
- Uses the approved black SIGNAL identity with the outer gold perimeter lighting removed; the internal amber SIGNAL accents remain.
- Adds a raw high-resolution SIGNAL wordmark resource so the in-app top-left themed logo no longer depends solely on `Assets.car` lookup.
- Rebuilds 400x240 / 1280x768 tvOS app-icon assets and 1920x720 / 2320x720 Top Shelf assets.
- Fixes Aether trailer geometry at the engine layer: `AetherEngine.videoGravity` is explicitly set to `resizeAspectFill` for trailer playback rather than attempting to scale the UIKit host from SwiftUI.
- Speeds clean CI builds by restoring parallel single-file Swift compilation (`-O`, batch mode) instead of whole-module compilation.
- Runs KSPNUVIO, AetherEngine and TVVLCKit preparation concurrently instead of sequentially.
- Adds a fast preflight before dependency downloads: Swift syntax parse and tvOS `actool` AppIcon validation fail early if source/assets are broken.

The native Nuvio-style trailer resolver and removal of the old Docker/IP YouTube resolver remain unchanged.
