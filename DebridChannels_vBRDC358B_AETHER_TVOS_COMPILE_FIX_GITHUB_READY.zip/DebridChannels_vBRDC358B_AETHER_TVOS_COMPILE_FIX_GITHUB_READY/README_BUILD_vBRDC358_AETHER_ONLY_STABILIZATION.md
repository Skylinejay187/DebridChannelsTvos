# Signal / Debrid Channels — vBRDC358 AetherEngine-Only Stabilization

Source authority: patched forward from the supplied vBRDC357 Apple TV package only.
Version: 1.0.1060 (1060).
Deployment target remains tvOS 17.0.

## Playback architecture

- Removed KSPlayer from the XcodeGen/SwiftPM dependency graph.
- Removed the KSPlayer PlaybackKit surface and KSPNUVIO vendor/fetch path.
- AetherEngine is the single internal VOD and Live TV playback owner.
- Historic KSPlayer selections/fallback call sites converge to AetherEngine instead of starting a second decoder.
- Live TV guide/grid preview surfaces were moved to AetherPlaybackKit as well.
- Existing system AVFoundation helpers (media-session anchor and explicitly native helper surfaces) remain system-framework utilities; they are not a second FFmpeg player stack.

## AetherEngine / FFmpeg update

- Pinned AetherEngine to 6.89.1, the final 6.x line documented for tvOS 17 support.
- Updated Aether's package graph to FFmpegBuild 3.3.x (Aether-namespaced FFmpeg n8.1.2) and LibDovi 2.1.x.
- Removed the old Aether 6.81/Xcode-compat patch step from dependency preparation.
- Dependency prep now fetches Aether only; KSPNUVIO is not downloaded or linked.

## Live TV stabilization

- Full-screen/live preview joins use `.standard` instead of `.fastZap`.
- `liveJoinStartsImmediately` is disabled so the live audio/video pipeline can establish stable continuity before presentation.
- Enabled a 30-minute `dvrWindowSeconds` window for Aether Live TV timeshift support.
- Added handling for Aether 6.89.x `audioDelivery == .droppedNoPipeline`:
  - Live TV uses the existing bounded Aether retune/recovery ladder.
  - VOD surfaces a real playback failure so Signal's ranked-source failover can act.
- Existing `playbackPhase`, `liveSourceReset`, first-frame and bounded route recovery remain authoritative.

## Subtitles / tracks

- Replaced reflection-based subtitle text extraction with Aether 6.89.x typed `SubtitleCue.text` handling for text/rich-text cues.
- Existing Aether audio/subtitle track selection remains wired through the Signal VOD overlay.
- Bitmap subtitle rendering still requires physical-device validation because Aether supplies CGImage cues and Signal's current overlay bridge is text-oriented.

## Up Next

- Fixed the pre-EOF presentation gate that required `!isPlaying`. Up Next can now surface from playback-time updates while the episode is still playing instead of waiting for a remote-button/state event.
- End-of-episode auto-advance safety remains separately gated.

## Volume amplification

KSPlayer's old FFmpeg volume filter has intentionally not been reintroduced as a second player. Aether 6.89.1 does not expose a public arbitrary >1.0 host gain control across all playback routes. Signal now preserves the requested amplification preference without restarting playback or sacrificing Atmos/bitstream passthrough. A future Aether-native decoded-audio gain implementation should apply only on decoded/bridged audio paths where it can be done without destroying passthrough/object metadata.

## Validation performed here

- All Swift files pass `swiftc -parse` with Swift 6.2.1.
- `project.yml` parses successfully.
- App and Top Shelf plists parse successfully and both report 1.0.1060 (1060).
- Shell syntax checks pass for the Aether dependency preparation scripts.
- Contract checks confirm no active `import KSPlayer`, `canImport(KSPlayer)`, KSPlayer package dependency, KSPlayer render-surface source, or KSPNUVIO fetch remains in the active source/build graph.

## Requires GitHub / physical Apple TV validation

This Linux environment cannot resolve github.com, so it cannot run the remote SwiftPM fetch or an Xcode/tvOS link/archive. GitHub Actions must confirm AetherEngine 6.89.1 + FFmpegBuild resolution and compile/link on Xcode. Physical Apple TV testing remains authoritative for Dolby Vision (especially P5), HDR switching, Atmos/multichannel, Live TV long-run audio continuity, channel changes, subtitles, Up Next, remote/Bluetooth commands, DVR/timeshift, seek/resume, alternate audio, and long-play stability.
