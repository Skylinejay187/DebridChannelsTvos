# vBRDC358B — AetherEngine tvOS compile compatibility fix

Narrow patch over vBRDC358 Aether-only stabilization. No rollback to KSPlayer.

- Keeps AetherEngine 6.89.1 and namespaced FFmpegBuild 3.3.x / FFmpeg 8.1.2.
- Imports AVFoundation pre-concurrency in the fetched Aether source for Xcode 16.4 compatibility.
- Excludes macOS-only supplemental VideoToolbox registration from tvOS.
- Excludes SDK-26-only display-layer properties from the Xcode 16.4 tvOS compile path while preserving Aether's AVDisplayCriteria/currentEDRHeadroom HDR path.
- Keeps KSPlayer absent from the project graph.
