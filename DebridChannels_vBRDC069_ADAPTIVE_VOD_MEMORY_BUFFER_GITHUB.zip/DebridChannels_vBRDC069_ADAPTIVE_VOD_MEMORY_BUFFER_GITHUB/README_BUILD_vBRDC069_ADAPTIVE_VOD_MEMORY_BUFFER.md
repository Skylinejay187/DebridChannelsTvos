# Debrid Channels vBRDC069 — Adaptive VOD Memory Buffer

- Release ID: **vBRDC069**
- Marketing version: **1.0.772**
- Apple build: **772**
- Code Name: **UNITY**
- Donor: packaged **vBRDC068** only
- Backend: **v693 unchanged**

## Physical-device problem

Large VOD sources (reported around 16 GB and above) can terminate Debrid Channels during playback without producing a normal app crash `.ips`. The regression lines up with vBRDC061 restoring KSPNUVIO's main-VOD `maxBufferDuration` from 30 seconds to 300 seconds, followed by vBRDC062 instant-open/background filling.

KSPNUVIO's main VOD reserve is time-based rather than byte-budgeted. Five minutes of packets for a high-bitrate movie can therefore retain hundreds of MB or more than 1 GB of compressed media, in addition to VideoToolbox surfaces, decoded-frame queues, audio, UI, and artwork. tvOS can terminate the process under memory pressure/jetsam without the Swift exception signature expected from a conventional crash.

## vBRDC069 correction

vBRDC069 preserves instant playback and the real buffer ghost, but stops giving every VOD title the same 300-second in-memory reserve.

Selected Source Intelligence metadata already includes the source size in the playback route label. PlaybackKit parses that existing local label with no network request and chooses the maximum packet-buffer duration before KSPNUVIO opens:

- **8 GB+ or high-memory tags** (`2160`, `4K`, `UHD`, `REMUX`, `TrueHD`, `DTS-HD`): **30 seconds max**, 3-second preferred reserve.
- **4 GB to <8 GB**: **120 seconds max**, 5-second preferred reserve.
- **Known <4 GB**: **300 seconds max**, 5-second preferred reserve.
- **Unknown size**: **90 seconds max**, 5-second preferred reserve (fail-safe instead of assuming a tiny file).

The 8 GB+ lane also receives the existing constrained demux queue sizes previously reserved only for explicit 4K/remux/audio-risk labels (`thread_queue_size`, reorder queue, IO buffer, probe/analyze envelope). This catches large 1080p Blu-ray/WEB sources that do not contain the word REMUX.

## Why this is preferable to a global rollback

A blanket return to 30 seconds would remove the deep buffering requested in vBRDC061 from every ordinary source. vBRDC069 keeps the five-minute reserve for genuinely small files while bounding the memory exposure of large/high-bitrate sources.

## Intentionally unchanged

- vBRDC062 instant-open (`isSecondOpen = true`)
- real KSPNUVIO `playableTime` buffer ghost
- vBRDC063 matched-frame A/V recovery
- vBRDC064 IDET signed-counter crash patch
- hardware decoding and decoded-frame queue policy
- seek/resume and automatic source failover
- Live TV buffer profile
- trailer buffer profile
- TorBox / Real-Debrid / Torrentio / Usenet provider behavior
- backend v693
- vBRDC068 franchise and catalog-row motion UI

## Physical Apple TV test

1. Re-test the same ~16 GB source that previously terminated the app.
2. In logs, confirm the PlaybackKit diagnostic reports `largeFileVOD=true`, the parsed source size, `memoryProfile=true`, and `buffer=3.0/30.0` (or equivalent numeric formatting).
3. Leave the title playing long enough for the scrubber buffer ghost to reach the 30-second ceiling and confirm memory remains stable.
4. Test a 4–8 GB source and confirm the ceiling is 120 seconds.
5. Test a known <4 GB source and confirm it can still build toward the 300-second deep reserve.
6. Verify Live TV and trailers are unchanged.

GitHub Actions/Xcode remains authoritative for the full Apple-platform compile. Physical Apple TV playback is required to confirm the jetsam/memory-pressure regression is eliminated.
