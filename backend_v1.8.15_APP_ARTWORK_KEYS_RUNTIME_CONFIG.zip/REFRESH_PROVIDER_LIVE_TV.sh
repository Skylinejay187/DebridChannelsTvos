#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${1:-http://192.168.100.55:8181}"
USER_ID="${2:-demo}"
echo "[DebridChannels] Refreshing provider-native Live TV for user ${USER_ID} at ${BASE_URL}"
curl -sS -X POST "${BASE_URL}/live/refresh" -H 'content-type: application/json' -d "{\"userId\":\"${USER_ID}\"}" | python3 -m json.tool || true
curl -sS "${BASE_URL}/api/live/instant?userId=${USER_ID}&limit=8" | python3 -m json.tool || true
