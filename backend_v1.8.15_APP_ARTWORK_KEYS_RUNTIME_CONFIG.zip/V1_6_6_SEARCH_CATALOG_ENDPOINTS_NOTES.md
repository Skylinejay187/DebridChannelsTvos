# v1.6.6 Search/Catalog Endpoint Notes

- Added `/api/catalog/movies` and `/api/catalog/shows` from backend cached Stremio/catalog rows.
- Added `/api/search?q=` over backend cached catalog rows.
- Live TV remains app-owned; backend still returns disabled messages for live provider routes.
