# Backend v1.8.13.1 Trailer Reliability Audit

Base: backend v1.8.13.

Changes:
- Preserves v1.8.13 Live TV/backend behavior.
- Honors prefer4k/quality query flags instead of forcing false.
- Adds progressive-first trailer playback when yt-dlp provides a 720p+ muxed MP4, reducing Android TV buffering compared with split video/audio DASH.
- Keeps split DASH fallback for higher quality when no reliable progressive stream is available.
- Adds trailer reliability env flags: TRAILER_PROGRESSIVE_FIRST, TRAILER_MIN_PROGRESSIVE_HEIGHT, YTDLP_TIMEOUT_MS, TRAILER_CACHE_TTL_MS.
- Cloudflare/CDN tunnel remains optional; trailer streams themselves are generally third-party signed URLs and are not automatically cached by Cloudflare unless proxied through a backend relay.
