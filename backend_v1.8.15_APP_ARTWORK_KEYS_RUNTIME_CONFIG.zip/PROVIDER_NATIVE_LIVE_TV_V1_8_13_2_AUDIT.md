# Backend v1.8.13.2 Provider-Native Live TV Audit

Base: backend v1.8.13.1 trailer reliability / stable v1.8.13 line.

Goal: stop treating the backend/CDN as the source of truth for IPTV provider data. IPTV providers remain authoritative for:

- M3U stream URLs
- XMLTV guide data
- provider logos (`tvg-logo`)
- provider categories/groups (`group-title`)
- channel ids (`tvg-id`)

What changed:

- Added provider-native env support: `IPTV_M3U_URL`, `IPTV_XMLTV_URL`, `IPTV_PROVIDER_NAME`, `IPTV_LOGO_BASE_URL`.
- Removed fake/default Channels DVR IP fallback. `CHANNELS_DVR_URL` is only used if explicitly configured.
- M3U loader now preserves provider `group-title` and `tvg-logo` as first-class data.
- XMLTV loader can attach provider guide/program artwork directly to M3U channels.
- Stream playback remains direct to provider by default: `LIVE_PROXY_PROVIDER_STREAMS=0`.
- Backend cache is a normalized view only, not a replacement for provider source data.
- Version markers updated to `backend_v1.8.13.2_PROVIDER_NATIVE_LIVE_TV`.

Cutout/foreground subject extraction remains paused/backlogged.

Safe rebuild:

```bash
sudo docker compose down
sudo docker compose build --no-cache
sudo docker compose up -d
curl http://192.168.100.55:8181/health
curl http://192.168.100.55:8181/api/version
```

Provider-source refresh:

```bash
curl -X POST http://192.168.100.55:8181/live/refresh \
  -H 'content-type: application/json' \
  -d '{"userId":"demo"}'
```

