Backend v1.8.13.10 poster+logo composite contract audit

Added:
- posterLogoUrl / posterLogo4k / posterWithLogoUrl fields in instant-home item payloads.
- /api/card/poster-logo and /api/artwork/poster-logo routes.
- Image rewrite/collection now recognizes posterLogoUrl-style fields.
- Version updated in package.json to 1.8.13.10.

Preserved:
- Bunny broad auto-prewarm remains disabled.
- Normal /api/image poster/logo/backdrop proxy remains enabled.
- Focused-card preview/trailer cache remains keep/manual-cleanup oriented from v1.8.13.9.
- Live TV/provider-direct IPTV backend behavior untouched.

Important implementation note:
- This backend source currently provides a safe redirect-fallback for /api/card/poster-logo so the app can use the new contract immediately without broken images.
- Real baked compositing should be enabled next with a server image compositor (Sharp/Canvas/Pillow) once the laptop/dev environment is ready and dependencies can be tested.
