# Android TV Cache Optimization Audit - v1.8.7

Base: backend_v1.8.6_UGREEN_HOST_TUNNEL_CLOUDFLARE_FIX_FULL / original v1.8.3 active backend.

Preserved:
- Existing trailer extraction routes and yt-dlp behavior.
- Existing /api/home, /api/catalog, /api/search, /api/streams, /api/image, /api/cdn/status routes.
- Existing Docker services: api, worker, Redis, Postgres, MinIO, cloudflared tunnel sidecar.
- Backend port remains 8181; Cloudflare tunnel service remains http://192.168.100.55:8181.

Added / improved:
- Android TV response cache for /api/home, /api/catalog/movies, /api/catalog/shows, and /api/search.
- Cache headers tuned for Cloudflare: public max-age with stale-while-revalidate.
- Proxy image URL rewriting by default so posters/backdrops/logos can flow through /api/image cache. Disable with PROXY_IMAGES_BY_DEFAULT=0 or per request ?proxyImages=0.
- /api/prewarm and /api/cache/prewarm to queue poster/backdrop/logo image caching from current home rows.
- /api/cache/purge and /api/cdn/purge to clear Android response cache.
- /api/cdn/status now reports Android cache TTLs and proxy image mode.
- /api/refresh clears Android response cache after catalog refresh.

No new domains are required. The same domain is used:
- https://api.skylinejay187.it.com

Recommended route:
- Cloudflare Tunnel hostname: api.skylinejay187.it.com
- Service URL: http://192.168.100.55:8181

Recommended quick tests:
1. https://api.skylinejay187.it.com/api/home
2. https://api.skylinejay187.it.com/api/cdn/status
3. POST https://api.skylinejay187.it.com/api/prewarm
