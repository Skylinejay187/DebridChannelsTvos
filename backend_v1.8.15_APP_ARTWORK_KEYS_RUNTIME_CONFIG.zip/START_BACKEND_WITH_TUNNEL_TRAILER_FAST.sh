#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Starting Debrid Channels backend v1.8.13.5 with Cloudflare tunnel + Bunny artwork + trailer metadata-only fast mode..."
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down --remove-orphans
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml up -d --build --force-recreate
echo "\nVersion:"
curl -fsS http://127.0.0.1:8181/api/version || true
echo "\nTrailer status:"
curl -fsS http://127.0.0.1:8181/api/trailers/status || true
echo "\nCDN status:"
curl -fsS http://127.0.0.1:8181/api/cdn/status || true
