# backend_v1.8.13.6_BUNNY_ARTWORK_PREWARM Audit

Base: backend v1.8.13.5 trailer metadata fast/no Bunny video.

Changes:
- Added BunnyCDN artwork prewarm endpoints:
  - `POST /api/cdn/prewarm?limit=240&scope=home-live`
  - `GET /api/cdn/prewarm/status`
- Prewarm requests only image/artwork URLs through the Bunny pull-zone host.
- IPTV/M3U/Xtream/HLS streams are not requested or proxied.
- Trailer video is not requested or cached by Bunny.
- Added periodic low-volume startup prewarm when enabled, default every 24 hours.
- Added env variables for prewarm limit, concurrency, timeout, and interval.
- Kept provider-direct Live TV architecture and cutout backlog paused.

Verification:
- `curl http://192.168.100.55:8181/api/cdn/status`
- `curl -X POST http://192.168.100.55:8181/api/cdn/prewarm?limit=240`
- `curl http://192.168.100.55:8181/api/cdn/prewarm/status`
