# Backend v1.8.13.3 - BunnyCDN artwork direct-first

Base: backend v1.8.13.2 provider-native Live TV direct-first.

## What changed
- Added `CDN_ASSET_BASE_URL=https://debridchannels-assets.b-cdn.net`.
- Added `CDN_ARTWORK_ENABLED=1`.
- Artwork fields only (`poster`, `backdrop`, `logo`, `image`, `imageUrl`, `icon`, `thumbnail`, `still`, `background`) are rewritten to BunnyCDN-backed `/api/image?url=` routes.
- IPTV/Xtream/M3U/HLS stream URLs are not rewritten and remain provider-direct.
- Added `/api/version` proof endpoint.
- Updated backend version marker to `backend_v1.8.13.3_BUNNYCDN_ARTWORK_DIRECT_FIRST`.

## Test URLs
- `https://debridchannels-assets.b-cdn.net/api/version`
- `https://debridchannels-assets.b-cdn.net/api/cdn/status`
- `https://debridchannels-assets.b-cdn.net/api/image?url=<encoded-poster-url>`

## Safety notes
- Cutout/foreground extraction remains paused/backlogged.
- Live TV provider-native direct stream behavior is preserved.
- BunnyCDN is used for artwork/metadata acceleration only, not video relay.
