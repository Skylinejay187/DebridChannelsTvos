# v1.8.13.8 Backend Patch

- Disabled broad Bunny artwork auto-prewarm by default.
- Normal poster/logo/backdrop CDN proxy/loading remains enabled.
- `/api/cdn/prewarm*` and `/api/artwork/prewarm*` now report disabled unless manual/admin flags are explicitly enabled.
- Startup catalog refresh no longer queues Bunny prewarm.
- Scheduled Bunny prewarm loop is disabled by default.
- Added focused-card preview aliases: `/api/trailers/resolve`, `/api/focused-card/preview/resolve`, `/api/preview/resolve`.
- Preview resolver returns `previewUrl`, `playbackUrl`, `previewDurationSeconds: 30`, muted/loop/focus timing flags, and artwork-motion fallback metadata when no playable clip is available.
