# Backend v1.8.8 — Instant Home Pipeline for Android v2.8.26.7

This backend update matches the Android TV app Instant Home Pipeline.

## Added endpoints

- `GET /api/home/hero`
  - Tiny hero-first payload for fastest first paint.
  - Includes the focused hero item, 4K-preferred artwork fields, logo, genre, ratings, and cache policy.

- `GET /api/home/instant`
  - Ready-to-render home JSON for Android TV.
  - Normalizes rows/items so the app does not need to rebuild home from multiple external catalogs at startup.
  - Uses stale-while-revalidate cache headers.
  - Prewarms only hero/visible-window artwork and a small trailer window, not the full catalog burst.

- `GET /api/artwork/cache/:id?url=<encoded-image-url>`
  - Alias into the existing persistent image proxy/cache.
  - Intended for app/backend-normalized artwork URLs.

- `GET /api/trailers/cache/:id?title=&year=&type=&prefer4k=0`
  - Resolves and caches trailer metadata/stream URLs using the existing trailer resolver.

## Important behavior

- Does not re-enable backend Live TV provider handling.
- Does not preload the entire catalog at once.
- Preserves existing `/api/home`, `/api/catalog/movies`, `/api/catalog/shows`, `/api/search`, image proxy, addon proxy, and trailer routes.
- Backend version marker updated to `backend_v1.8.8_INSTANT_HOME_PIPELINE`.
