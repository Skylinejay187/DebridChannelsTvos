# backend v1.8.10 Live TV non-blocking Gracenote restore

Base: backend v1.8.9 Live TV instant pipeline.

Regression repair goals:
- Keep /api/home/instant and /api/home/hero unchanged for Android app compatibility.
- Keep Live TV instant endpoints, but cap the initial shell/window payloads.
- Preserve Gracenote/XMLTV text program data behavior through guide/window/now-next payloads.
- Do not prewarm or eagerly proxy all Live TV artwork.
- Avoid full guide dumps during app startup; return visible-window-sized payloads only.

Endpoints preserved:
- /api/live/instant
- /api/live/categories
- /api/live/channels?category=
- /api/live/guide/now-next
- /api/live/guide/window?channelId=&hours=
- /api/live/logos/cache/:id
- /api/live/artwork/cache/:id
