# Backend v1.8.15 Artwork Provider Keys

Adds runtime artwork-provider key storage for app settings.

Endpoints:

- `GET /api/artwork/provider-keys/status`
- `POST /api/artwork/provider-keys`

POST body:

```json
{
  "tmdbApiKey": "...",
  "fanartTvApiKey": "...",
  "tvdbApiToken": "..."
}
```

Keys are saved to `data/artwork-provider-keys.json`. Existing environment variables still override runtime values. Updating keys clears the artwork pool cache so the next resolver pass can hydrate richer artwork.
