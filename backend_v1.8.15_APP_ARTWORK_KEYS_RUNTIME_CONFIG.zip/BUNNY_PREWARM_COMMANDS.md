# BunnyCDN artwork prewarm commands — v1.8.13.7

This backend prewarms artwork only. It does not request IPTV streams, M3U/HLS, Xtream playback URLs, or trailer video.

Trigger manually in browser:

```text
https://api.skylinejay187.it.com/api/cdn/prewarm/start?force=1&limit=600&scope=home-live
```

Check status:

```text
https://api.skylinejay187.it.com/api/cdn/prewarm/status
```

Local NAS status:

```bash
curl "http://192.168.100.55:8181/api/cdn/prewarm/status"
```

Verify env:

```bash
sudo docker exec debrid-channels-api printenv | grep -iE "BUNNY|CDN"
```

The backend also scans periodically for new artwork after catalogs/home rows/Live TV cache change and queues a smaller prewarm run automatically.
