# Backend v1.8.13.11

- Adds real `/api/card/poster-logo` and `/api/artwork/poster-logo` compositing using Sharp when installed.
- Keeps previews/trailers indefinitely/manual cleanup from prior backend.
- Keeps broad Bunny artwork auto-prewarm disabled.
- Falls back to clean poster redirect if Sharp/logo fetch is unavailable so artwork never breaks.
