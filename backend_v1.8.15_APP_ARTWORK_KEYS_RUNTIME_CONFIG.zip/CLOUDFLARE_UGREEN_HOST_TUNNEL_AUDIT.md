# Cloudflare / UGREEN Host Tunnel Audit

Base preserved: backend v1.8.3 CDN no-route-removal backend.

## What changed
- Kept backend API public LAN port as `8181:8181`.
- Forced API environment `HOST=0.0.0.0`, `PORT=8181`.
- Added UGREEN-safe Cloudflare tunnel compose using `network_mode: host`.
- Added `.env` with `PUBLIC_BASE_URL=https://api.skylinejay187.it.com` and the provided Cloudflare tunnel token.

## Why
UGREEN NAS often has Docker bridge routing issues. Running `cloudflared` in host mode lets it reach the backend exactly like your browser can.

## Cloudflare Tunnel route
Set the published application service URL to:

```text
http://192.168.100.55:8181
```

You already confirmed this works locally:

```text
http://192.168.100.55:8181/api/home
```

## Run command
```bash
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml up -d
sudo docker logs debrid-channels-cloudflared
```

Expected cloudflared log:

```text
Updated to new configuration ... service=\"http://192.168.100.55:8181\"
Registered tunnel connection
```

## Test
```text
https://api.skylinejay187.it.com/api/home
```

## Preserved
- trailer extraction routes
- yt-dlp support
- existing app routes
- CDN/image/cache routes
- dashboard/backend behavior
