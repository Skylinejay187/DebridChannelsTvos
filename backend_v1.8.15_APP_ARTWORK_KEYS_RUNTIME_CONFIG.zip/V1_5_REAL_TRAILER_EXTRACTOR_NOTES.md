# v1.5 Real Trailer Extractor Patch

This backend includes the real trailer extractor:

- `/trailers/resolve`
- `/trailers/prewarm`
- `/api/trailer/:id`
- `yt-dlp` + `ffmpeg` installed by Dockerfile
- official trailer title/year matching
- 1080p/4K preference support
- direct DASH/HLS/MP4 stream response for Android playback
