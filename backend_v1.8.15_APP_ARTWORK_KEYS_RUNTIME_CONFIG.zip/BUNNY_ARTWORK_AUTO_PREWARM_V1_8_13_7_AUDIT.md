# backend v1.8.13.7 — Bunny artwork auto-prewarm

Base: backend_v1.8.13.6_BUNNY_ARTWORK_PREWARM_FULL

Purpose:
- Fully wire BunnyCDN artwork prewarm so it can be triggered from a browser or script.
- Automatically scan for new/changed home row, catalog, Live TV logo, and Gracenote/XMLTV thumbnail artwork.
- Prewarm Bunny cache by requesting Bunny CDN artwork URLs only.

Preserved:
- IPTV streams remain provider-direct.
- Xtream/M3U/HLS playback URLs are not rewritten to Bunny.
- Trailer video is not cached/proxied through Bunny.
- Cutout/foreground extraction remains paused/backlogged.
- Existing v1.8.13 backend routes are preserved.

New routes:
- GET/POST /api/cdn/prewarm
- GET/POST /api/cdn/prewarm/start
- GET /api/cdn/prewarm/status
- GET/POST /api/artwork/prewarm
- GET/POST /api/artwork/prewarm/start
- GET /api/artwork/prewarm/status

Automation:
- Startup delayed scan/prewarm.
- Periodic scan every BUNNY_ARTWORK_PREWARM_SCAN_INTERVAL_MS.
- Fingerprint detection to detect new/changed artwork.
- Full scheduled run every BUNNY_ARTWORK_PREWARM_INTERVAL_HOURS.

Verification:
- /api/cdn/status should show externalCdn.enabled=true.
- /api/cdn/prewarm/start?force=1&limit=600&scope=home-live should return 202 accepted.
- /api/cdn/prewarm/status should show discovered/requested/warmed/failed totals.
