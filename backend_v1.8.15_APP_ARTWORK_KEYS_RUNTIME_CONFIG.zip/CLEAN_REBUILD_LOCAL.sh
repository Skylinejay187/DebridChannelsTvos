#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "[Debrid Channels] Clean local rebuild for backend v1.8.13.3 BunnyCDN artwork"
sudo docker compose down --remove-orphans || true
sudo docker compose build --no-cache
sudo docker compose up -d --force-recreate
echo ""
echo "Verify local:  curl http://192.168.100.55:8181/api/version"
echo "Verify Bunny:  https://debridchannels-assets.b-cdn.net/api/version"
