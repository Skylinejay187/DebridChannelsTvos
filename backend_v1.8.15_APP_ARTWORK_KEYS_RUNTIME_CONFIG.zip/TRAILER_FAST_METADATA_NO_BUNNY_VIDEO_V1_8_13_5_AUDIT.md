# backend_v1.8.13.5_TRAILER_METADATA_FAST_NO_BUNNY_VIDEO

Base: backend v1.8.13.4 BunnyCDN env autoload proof.

Purpose:
- Improve trailer startup reliability without routing trailer video through BunnyCDN.
- Keep BunnyCDN scoped to artwork/metadata only.
- Keep IPTV/Xtream/M3U/HLS provider streams direct.

Changes:
- Added trailer status endpoint: `/api/trailers/status` and `/trailers/status`.
- Added fast trailer mode defaults for low-end Android TV devices such as Xgimi.
- Trailer prewarm now queues metadata/URL resolution only.
- Trailer prewarm reports `cacheVideo:false` and `bunnyVideoProxy:false`.
- Resolver prefers progressive MP4-style playback up to 1080p before adaptive/DASH manifests.
- 4K trailer requests are ignored in fast mode to avoid slow device buffering.
- Backend version marker updated to v1.8.13.5.

Preserved:
- Provider-direct IPTV streams.
- BunnyCDN artwork-only mode.
- Existing Live TV/provider-native backend behavior.
- Cutouts remain paused/backlogged.
- Merged `.env` remains included.

Verification:
- `node --check server.js` passes.
- Check runtime with: `curl http://192.168.100.55:8181/api/trailers/status`.
