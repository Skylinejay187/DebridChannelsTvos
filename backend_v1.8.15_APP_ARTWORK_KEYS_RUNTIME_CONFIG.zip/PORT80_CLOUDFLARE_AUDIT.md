# Port 80 / Cloudflare Audit

Base: backend_v1.8.3_CDN_ADDED_NO_ROUTE_REMOVAL_FULL

Changes made:
- docker-compose API service now publishes host port `80` to container port `8181`: `80:8181`.
- Backend app still runs internally on `PORT=8181`, preserving existing route/runtime behavior.
- Default `PUBLIC_BASE_URL` updated to `https://api.skylinejay187.it.com`.
- `.env.example` updated to the Cloudflare API hostname.

Preserved:
- Existing trailer extraction routes and yt-dlp logic.
- Existing dashboard/backend/app-facing routes.
- CDN image/cache/addon routes from v1.8.3.
- MinIO, Redis, Postgres service definitions.

Run:
```bash
docker compose down
docker compose up -d --build
```

Test after Cloudflare DNS is configured:
```bash
curl http://api.skylinejay187.it.com/health
curl https://api.skylinejay187.it.com/health
```

If port 80 is already used on the NAS, stop the other service or use a reverse proxy.
