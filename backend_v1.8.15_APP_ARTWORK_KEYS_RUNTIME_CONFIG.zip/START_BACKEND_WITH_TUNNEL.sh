#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sudo docker compose --env-file .env -f docker-compose.yml -f docker-compose.tunnel.yml up -d --force-recreate
