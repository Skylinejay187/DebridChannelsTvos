# backend_v1.8.11_LIVE_TV_FOCUS_RECOVERY_GUIDE_TIMEOUT_FIX

Purpose: pair with Android app v2.8.26.13.

- Preserves all v1.8.10 Live TV instant/non-blocking endpoints.
- Keeps Gracenote/XMLTV guide metadata available.
- Initial Live TV responses remain capped/visible-window friendly.
- Backend is not allowed to force full-guide eager loads for Android TV startup.
- App-owned M3U/XMLTV direct loading remains supported; backend cache endpoints stay compatible.
