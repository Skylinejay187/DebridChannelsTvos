#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "[Debrid Channels] Starting backend v1.8.13.7 with Cloudflare tunnel + Bunny artwork auto-prewarm..."
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down --remove-orphans
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml up -d --build --force-recreate
echo
echo "[Debrid Channels] CDN env inside API container:"
sudo docker exec debrid-channels-api printenv | grep -iE 'BUNNY|CDN' || true
echo
echo "[Debrid Channels] CDN status local:"
curl -s "http://127.0.0.1:8181/api/cdn/status" || true
echo
echo "[Debrid Channels] Prewarm status local:"
curl -s "http://127.0.0.1:8181/api/cdn/prewarm/status" || true
echo
