# Backend v1.8.13.9 audit

- Bunny broad auto-prewarm remains disabled.
- Normal poster/logo/backdrop proxy loading remains enabled.
- Focused-card preview resolver remains enabled.
- Trailer/preview cache retention defaults to keep indefinitely / manual cleanup only.
- Added KEEP_TRAILER_PREVIEW_CACHE_FOREVER=1 and long TRAILER_CACHE_TTL_MS defaults.
- No app-side Live TV/backend/player behavior was removed.
