# backend_v1.8.5_CLOUDFLARE_TUNNEL_8181_RESTORE Audit

## Purpose
This build fixes the port-conflict path by restoring the backend's LAN port to `8181:8181` and treating Cloudflare Tunnel as the public HTTPS entrypoint.

## Changed
- `docker-compose.yml` now maps host `8181` to container `8181` again.
- Removed the port-80 dependency from the backend compose mapping because the NAS already uses port 80/8080.
- Added `docker-compose.tunnel.yml` as an optional Cloudflare Tunnel sidecar.
- Kept `PUBLIC_BASE_URL` default as `https://api.skylinejay187.it.com`.

## Preserved
- Trailer extraction routes and yt-dlp behavior.
- Existing app-facing routes.
- CDN/cache/image routes.
- Dashboard/backend behavior.
- Backend still listens on `0.0.0.0:8181` inside the container.

## Correct Cloudflare Tunnel route options

### If cloudflared runs as the optional compose sidecar
Set the Cloudflare route service URL to:

```text
http://api:8181
```

### If cloudflared runs separately on the NAS host
Set the route service URL to whichever works from the cloudflared container/host:

```text
http://192.168.100.55:8181
```

If a separate Docker cloudflared container cannot reach the LAN IP, use the sidecar compose file instead.

## Verification commands

Local LAN:

```bash
curl http://192.168.100.55:8181/health
curl http://192.168.100.55:8181/api/home
```

Cloudflare after route is set:

```bash
curl https://api.skylinejay187.it.com/health
curl https://api.skylinejay187.it.com/api/home
```
