# Backend v1.8.13 Hero Cutout Path Init Fix

Fixes startup crash:

```
ReferenceError: Cannot access path before initialization
```

Cause: v1.8.12 added HERO_ASSET_CACHE_DIR before `path`/`fs` were required and before DATA_DIR existed.

Fix:
- Hoisted `fs`, `path`, and `crypto` requires to the top of server.js.
- Added `DATA_DIR = path.join(__dirname, "data")` before hero asset constants.
- Removed duplicate later require declarations.
- Bumped backend marker to backend_v1.8.13_HERO_CUTOUT_PATH_INIT_FIX.

No route removals. Existing Live TV, Gracenote/XMLTV, instant home, CDN cache, and hero cutout contract remain preserved.
