
const fs = require('fs');
const path = require('path');

const CACHE_DIR = path.join(__dirname, 'data');
const HOME_CACHE_PATH = path.join(CACHE_DIR, 'home-rows.json');
const STATE_PATH = path.join(CACHE_DIR, 'catalog-state.json');
const LIVE_USERS_PATH = path.join(CACHE_DIR, 'live-users.json');
const LIVE_PUBLIC_SOURCES_PATH = path.join(CACHE_DIR, 'live-public-sources.json');
const LIVE_CACHE_PATH = path.join(CACHE_DIR, 'live-cache.json');

const DEFAULT_SOURCES = [
  {
    key: 'cinemeta',
    title: 'Cinemeta',
    manifestUrl: process.env.CINEMETA_MANIFEST_URL || 'https://v3-cinemeta.strem.io/manifest.json',
    enabled: (process.env.CINEMETA_ENABLED || 'true') !== 'false',
    preferredCatalogs: (process.env.CINEMETA_CATALOG_IDS || 'top,year,imdbRating').split(',').map(s => s.trim()).filter(Boolean),
    maxRails: Number(process.env.CINEMETA_MAX_RAILS || 4)
  },
  {
    key: 'streaming_catalogs',
    title: 'Streaming Catalogs',
    manifestUrl: process.env.STREAMING_CATALOGS_MANIFEST_URL || 'https://7a82163c306e-stremio-netflix-catalog-addon.baby-beamup.club/ZG5wLGFtcCxhdHAsaGJtLG5meCxwbXAscGNwLGhsdSxzdHosY3J1OnQwLWZyZWUtcnBkYjpVUzoxNzY5Mzg5ODgyNjI3OjA6MDpVUw%3D%3D/manifest.json',
    enabled: (process.env.STREAMING_CATALOGS_ENABLED || 'true') !== 'false',
    preferredCatalogs: (process.env.STREAMING_CATALOGS_CATALOG_IDS || 'nfx,dnp,hbm,atp,hlu,pmp,pcp,stz,cru').split(',').map(s => s.trim()).filter(Boolean),
    maxRails: Number(process.env.STREAMING_CATALOGS_MAX_RAILS || 6)
  }
];

function ensureCacheDir() {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return fallback;
  }
}

function writeJson(filePath, value) {
  ensureCacheDir();
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2));
}

function loadHomeRows() {
  return readJson(HOME_CACHE_PATH, {
    generatedAt: new Date(0).toISOString(),
    source: 'built-in-fallback',
    rails: []
  });
}

function loadState() {
  return readJson(STATE_PATH, { lastRefreshAt: null, sources: [] });
}

async function fetchJson(url, timeoutMs = 15000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { 'user-agent': 'Debrid-Channels-Backend/0.3', ...headers },
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

async function fetchText(url, timeoutMs = 15000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      headers: { 'user-agent': 'Debrid-Channels-Backend/0.3', ...headers },
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.text();
  } finally {
    clearTimeout(timer);
  }
}

function buildAddonBase(manifestUrl) {
  return manifestUrl.replace(/\/manifest\.json(?:\?.*)?$/i, '');
}

function buildCatalogUrl(manifestUrl, type, id) {
  const base = buildAddonBase(manifestUrl);
  return `${base}/catalog/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`;
}

function pickCatalogs(manifest, source) {
  const catalogs = Array.isArray(manifest.catalogs) ? manifest.catalogs : [];
  const filtered = catalogs.filter(c => c && (c.type === 'movie' || c.type === 'series'));
  const pref = [];
  for (const catalogId of source.preferredCatalogs) {
    for (const c of filtered) {
      if (c.id === catalogId && !pref.includes(c)) pref.push(c);
    }
  }
  for (const c of filtered) {
    if (!pref.includes(c)) pref.push(c);
  }
  return pref.slice(0, source.maxRails);
}

function cleanText(value, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback;
}

function normalizeItem(item, sourceKey, sourceTitle) {
  const releaseInfo = cleanText(item.releaseInfo, '');
  const parsedYear = Number(String(releaseInfo).match(/\d{4}/)?.[0] || item.year || 0) || null;
  return {
    id: cleanText(item.id, `unknown-${Math.random().toString(36).slice(2, 9)}`),
    type: item.type === 'series' ? 'series' : 'movie',
    title: cleanText(item.name, cleanText(item.title, 'Untitled')),
    year: parsedYear,
    poster: cleanText(item.poster, cleanText(item.posterShape === 'landscape' ? item.background : '', '')),
    posterUrl: cleanText(item.poster, ''),
    backdrop: cleanText(item.background, cleanText(item.poster, '')),
    backdropUrl: cleanText(item.background, ''),
    background: cleanText(item.background, ''),
    logo: cleanText(item.logo, ''),
    logoUrl: cleanText(item.logo, ''),
    clearLogo: cleanText(item.clearLogo || item.logo, ''),
    landscapeCardUrl: cleanText(item.landscape || item.thumbnail || (item.posterShape === 'landscape' ? (item.poster || item.background || '') : ''), ''),
    rowCardUrl: cleanText(item.landscape || item.thumbnail || (item.posterShape === 'landscape' ? (item.poster || item.background || '') : ''), ''),
    bannerUrl: cleanText(item.banner, ''),
    stillUrl: cleanText(item.still || item.thumbnail, ''),
    imdbId: cleanText(item.imdb_id || item.imdbId || (typeof item.id === 'string' && item.id.startsWith('tt') ? item.id : ''), ''),
    overview: cleanText(item.description, ''),
    genres: Array.isArray(item.genres) ? item.genres : [],
    source: sourceTitle,
    sourceKey,
    streamLookupId: cleanText(item.id, ''),
    streamLookupType: item.type === 'series' ? 'series' : 'movie'
  };
}

function dedupeItems(items) {
  const out = [];
  const seen = new Set();
  for (const item of items) {
    const key = item.imdbId || `${item.type}:${item.title}:${item.year || ''}`.toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      out.push(item);
    }
  }
  return out;
}

async function fetchCatalogRail(source, catalog) {
  const url = buildCatalogUrl(source.manifestUrl, catalog.type, catalog.id);
  const payload = await fetchJson(url);
  const metas = Array.isArray(payload?.metas) ? payload.metas : [];
  const items = dedupeItems(metas.map(item => normalizeItem(item, source.key, source.title))).slice(0, 24);
  return {
    slug: `${source.key}-${catalog.type}-${catalog.id}`,
    title: cleanText(catalog.name, `${source.title} ${catalog.type}`),
    type: catalog.type,
    catalogId: catalog.id,
    source: source.title,
    sourceKey: source.key,
    items
  };
}

async function refreshCatalogs() {
  const rails = [];
  const sourceStates = [];
  for (const source of DEFAULT_SOURCES.filter(s => s.enabled)) {
    const state = {
      key: source.key,
      title: source.title,
      manifestUrl: source.manifestUrl,
      ok: false,
      railsFetched: 0,
      error: null,
      catalogs: []
    };
    try {
      const manifest = await fetchJson(source.manifestUrl);
      const catalogs = pickCatalogs(manifest, source);
      state.catalogs = catalogs.map(c => ({ id: c.id, type: c.type, name: c.name || '' }));
      for (const catalog of catalogs) {
        try {
          const rail = await fetchCatalogRail(source, catalog);
          if (rail.items.length) {
            rails.push(rail);
            state.railsFetched += 1;
          }
        } catch (err) {
          state.error = state.error || `catalog ${catalog.id}: ${err.message}`;
        }
      }
      state.ok = state.railsFetched > 0;
    } catch (err) {
      state.error = err.message;
    }
    sourceStates.push(state);
  }

  const payload = {
    generatedAt: new Date().toISOString(),
    source: 'remote-catalog-ingestion',
    rails
  };
  writeJson(HOME_CACHE_PATH, payload);
  writeJson(STATE_PATH, {
    lastRefreshAt: payload.generatedAt,
    sources: sourceStates
  });
  return { home: payload, state: loadState() };
}

function loadLiveUsers() {
  return readJson(LIVE_USERS_PATH, { users: {} });
}

function saveLiveUsers(value) {
  writeJson(LIVE_USERS_PATH, value);
}

function loadLivePublicSources() {
  return readJson(LIVE_PUBLIC_SOURCES_PATH, { sources: [] });
}

function loadLiveCache() {
  return readJson(LIVE_CACHE_PATH, { generatedAt: null, users: {} });
}

function saveLiveCache(value) {
  writeJson(LIVE_CACHE_PATH, value);
}

function sanitizeUrl(input) {
  const value = cleanText(input, '');
  return value.replace(/\/$/, '');
}

function slugify(input) {
  return cleanText(input, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'source';
}

function normalizeSourcePayload(payload) {
  const type = cleanText(payload.type).toLowerCase();
  if (!['channels_dvr', 'm3u', 'xtream', 'public_demo'].includes(type)) {
    throw new Error('Unsupported source type');
  }
  const name = cleanText(payload.name, type === 'channels_dvr' ? 'Channels DVR' : type === 'm3u' ? 'M3U Source' : 'Public Demo');
  const sourceId = cleanText(payload.sourceId, `${slugify(type)}-${slugify(name)}-${Date.now().toString(36)}`);
  return {
    sourceId,
    type,
    name,
    url: sanitizeUrl(payload.url || payload.m3uUrl || payload.playlistUrl),
    m3uUrl: sanitizeUrl(payload.m3uUrl || payload.playlistUrl || payload.url),
    xmltvUrl: sanitizeUrl(payload.xmltvUrl || payload.guideUrl || payload.epgUrl),
    logoBaseUrl: sanitizeUrl(payload.logoBaseUrl || payload.iconBaseUrl),
    providerNative: payload.providerNative !== false,
    username: cleanText(payload.username, ''),
    password: cleanText(payload.password, ''),
    headers: typeof payload.headers === 'object' && payload.headers ? payload.headers : {},
    enabled: payload.enabled !== false,
    visibility: cleanText(payload.visibility, 'private'),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
}

function buildEnvProviderSource() {
  const m3uUrl = sanitizeUrl(process.env.IPTV_M3U_URL || process.env.LIVE_M3U_URL || process.env.XTREAM_M3U_URL || '');
  const xmltvUrl = sanitizeUrl(process.env.IPTV_XMLTV_URL || process.env.LIVE_XMLTV_URL || process.env.XMLTV_URL || process.env.EPG_XMLTV_URL || '');
  const channelsDvrUrl = sanitizeUrl(process.env.CHANNELS_DVR_URL || process.env.LIVE_CHANNELS_DVR_URL || process.env.CHANNELS_DVR_BASE_URL || '');
  if (m3uUrl) {
    return {
      sourceId: 'provider-native-env-m3u',
      type: 'm3u',
      name: cleanText(process.env.IPTV_PROVIDER_NAME || process.env.LIVE_PROVIDER_NAME, 'Provider Native M3U'),
      url: m3uUrl,
      m3uUrl,
      xmltvUrl,
      logoBaseUrl: sanitizeUrl(process.env.IPTV_LOGO_BASE_URL || process.env.LIVE_LOGO_BASE_URL || ''),
      headers: {},
      providerNative: true,
      enabled: true,
      visibility: 'private'
    };
  }
  if (channelsDvrUrl) {
    return {
      sourceId: 'channels-dvr-env',
      type: 'channels_dvr',
      name: cleanText(process.env.CHANNELS_DVR_NAME || process.env.LIVE_CHANNELS_DVR_NAME, 'Channels DVR'),
      url: channelsDvrUrl,
      headers: {},
      providerNative: true,
      enabled: true,
      visibility: 'private'
    };
  }
  return null;
}

function listLiveSources(userId) {
  const users = loadLiveUsers().users || {};
  const publicSources = loadLivePublicSources().sources || [];
  const sources = [
    ...((users[userId]?.sources || []).filter(s => s.enabled !== false)),
    ...publicSources.filter(s => s.enabled !== false)
  ];
  const envSource = buildEnvProviderSource();
  if (!sources.length && envSource) sources.push(envSource);
  return sources;
}

function upsertLiveSource(userId, payload) {
  if (!userId) throw new Error('userId is required');
  const data = loadLiveUsers();
  if (!data.users[userId]) data.users[userId] = { sources: [] };
  const normalized = normalizeSourcePayload(payload);
  const idx = data.users[userId].sources.findIndex(s => s.sourceId === normalized.sourceId);
  if (idx >= 0) {
    normalized.createdAt = data.users[userId].sources[idx].createdAt || normalized.createdAt;
    data.users[userId].sources[idx] = { ...data.users[userId].sources[idx], ...normalized, updatedAt: new Date().toISOString() };
  } else {
    data.users[userId].sources.push(normalized);
  }
  saveLiveUsers(data);
  return data.users[userId].sources;
}

function m3uAttr(line, name) {
  const re = new RegExp(name + "=(?:\\\"([^\\\"]*)\\\"|\'([^\']*)\'|([^\\s,]+))", "i");
  const m = re.exec(line || '');
  return (m && (m[1] || m[2] || m[3])) ? String(m[1] || m[2] || m[3]).trim() : '';
}

function parseM3U(text, source) {
  const lines = String(text || '').split(/\r?\n/);
  const channels = [];
  let pending = null;
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF:')) {
      const channelId = extinfAttr(line, 'channel-id') || extinfAttr(line, 'tvg-id') || extinfAttr(line, 'tvc-guide-stationid') || extinfAttr(line, 'CUID');
      const tvgLogo = extinfAttr(line, 'tvg-logo') || extinfAttr(line, 'logo');
      const tvgName = extinfAttr(line, 'tvg-name');
      const number = extinfAttr(line, 'channel-number') || extinfAttr(line, 'tvg-chno') || extinfAttr(line, 'ch-number');
      const group = extinfAttr(line, 'group-title') || 'Channels DVR';
      const commaName = line.split(',').slice(1).join(',').trim();
      const name = tvgName || commaName || channelId || 'Channel';
      pending = { channelId, tvgLogo, group, name, number };
      continue;
    }
    if (pending && !line.startsWith('#')) {
      const extId = pending.channelId || pending.number || pending.name;
      channels.push({
        id: `${source.sourceId}:${tvgSafe(extId)}`,
        externalId: extId,
        number: pending.number || '',
        name: pending.name,
        logo: absolutizeProviderUrl(pending.tvgLogo || '', source),
        poster: absolutizeProviderUrl(pending.tvgLogo || '', source),
        backdrop: '',
        sourceType: source.type,
        sourceId: source.sourceId,
        sourceName: source.name,
        group: splitGroups(pending.group).join(' / ') || 'Channels DVR',
        groups: (splitGroups(pending.group).length ? splitGroups(pending.group) : ['Channels DVR']),
        streamUrl: line,
        current: {
          title: pending.name,
          description: '',
          start: null,
          end: null,
          progress: null
        },
        next: null
      });
      pending = null;
    }
  }
  return channels;
}

function tvgSafe(v) {
  return String(v || '').replace(/[^a-zA-Z0-9_-]+/g, '_');
}

function extinfAttr(line, name) {
  const m = new RegExp('(?:^|\\s)' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '="([^"]*)"', 'i').exec(line || '');
  return m ? m[1].trim() : '';
}

function splitGroups(raw) {
  return String(raw || '').split(/[;,|]/).map(s => s.trim()).filter(Boolean).filter((v, i, a) => a.findIndex(x => x.toLowerCase() === v.toLowerCase()) === i);
}

function dvrDedupeKey(channel) {
  const number = String(channel.number || '').trim().toLowerCase();
  const url = String(channel.streamUrl || '').trim().toLowerCase();
  const name = String(channel.name || '').trim().toLowerCase();
  if (number) return 'num:' + number;
  if (url) return 'url:' + url;
  return 'name:' + name;
}

function channelSortNumber(value) {
  const m = String(value || '').match(/\d+(?:\.\d+)?/);
  return m ? Number(m[0]) : Number.MAX_SAFE_INTEGER;
}


function unescapeXml(value) {
  return String(value || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .trim();
}

function parseXmlAttr(attrs, name) {
  const m = new RegExp(name + '="([^"]*)"', 'i').exec(attrs || '');
  return m ? unescapeXml(m[1]) : '';
}

function parseXmlTag(body, name) {
  const m = new RegExp('<' + name + '[^>]*>([\\s\\S]*?)</' + name + '>', 'i').exec(body || '');
  return m ? unescapeXml(m[1]) : '';
}

function normalizeGuideKey(value) {
  return String(value || '').toLowerCase().replace(/hd|fhd|uhd|4k/g, '').replace(/[^a-z0-9]+/g, '');
}

function parseXmltvGuide(xml) {
  const channelNames = new Map();
  const channelRegex = /<channel\s+([^>]*)>([\s\S]*?)<\/channel>/gi;
  let match;
  while ((match = channelRegex.exec(xml || ''))) {
    const attrs = match[1] || '';
    const body = match[2] || '';
    const id = parseXmlAttr(attrs, 'id');
    if (!id) continue;
    const names = new Set([id]);
    const displayRegex = /<display-name[^>]*>([\s\S]*?)<\/display-name>/gi;
    let d;
    while ((d = displayRegex.exec(body))) names.add(unescapeXml(d[1]));
    channelNames.set(id, Array.from(names).filter(Boolean));
  }

  const buckets = new Map();
  const programRegex = /<programme\s+([^>]*)>([\s\S]*?)<\/programme>/gi;
  while ((match = programRegex.exec(xml || ''))) {
    const attrs = match[1] || '';
    const body = match[2] || '';
    const channel = parseXmlAttr(attrs, 'channel');
    if (!channel) continue;
    const title = parseXmlTag(body, 'title') || 'No information';
    const description = parseXmlTag(body, 'desc');
    const icon = /<icon[^>]*src="([^"]+)"/i.exec(body)?.[1] || '';
    const program = {
      title,
      name: title,
      description,
      start: parseXmlAttr(attrs, 'start'),
      end: parseXmlAttr(attrs, 'stop'),
      startLabel: parseXmlAttr(attrs, 'start'),
      endLabel: parseXmlAttr(attrs, 'stop'),
      imageUrl: unescapeXml(icon),
      poster: unescapeXml(icon),
      backdrop: ''
    };
    const keys = new Set([channel, normalizeGuideKey(channel)]);
    for (const name of (channelNames.get(channel) || [])) {
      keys.add(name);
      keys.add(normalizeGuideKey(name));
    }
    for (const key of keys) {
      if (!key) continue;
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key).push(program);
    }
  }
  for (const [key, list] of buckets.entries()) {
    buckets.set(key, list.slice(0, 12));
  }
  return buckets;
}

function guideProgramsForChannel(guide, channel) {
  if (!guide || guide.size === 0 || !channel) return [];
  const rawKeys = [channel.externalId, channel.number, channel.name, channel.id];
  if (channel.id && String(channel.id).includes(':')) rawKeys.push(String(channel.id).split(':').pop());
  const keys = rawKeys
    .filter(Boolean)
    .flatMap(v => [String(v), normalizeGuideKey(v)]);
  for (const key of keys) {
    const programs = guide.get(key);
    if (programs && programs.length) return programs;
  }
  return [];
}

function absolutizeProviderUrl(value, source) {
  const raw = cleanText(value, '');
  if (!raw) return '';
  if (/^https?:\/\//i.test(raw) || raw.startsWith('data:')) return raw;
  const base = source.logoBaseUrl || source.url || source.m3uUrl || '';
  try { return new URL(raw, base).toString(); } catch { return raw; }
}

function attachXmltvGuideToChannels(channels, source, guide) {
  if (!guide || guide.size === 0) return channels;
  return channels.map(channel => {
    const programs = guideProgramsForChannel(guide, channel);
    if (!programs.length) return channel;
    const current = programs[0] || channel.current || null;
    const next = programs[1] || channel.next || null;
    const art = current && (current.poster || current.imageUrl || current.logo || '');
    return {
      ...channel,
      programs,
      current,
      next,
      poster: channel.poster || art || channel.logo || '',
      backdrop: channel.backdrop || art || '',
      providerGuideSource: source.xmltvUrl || 'provider-xmltv'
    };
  });
}

function normalizeChannelsDvrItem(item, source) {
  const channelId = cleanText(String(item.id || item.channelId || item.slug || item.number || item.name), 'channel');
  const streamUrl = cleanText(item.streamUrl, `${source.url}/devices/ANY/channels/${encodeURIComponent(channelId)}/stream.m3u8`);
  const title = cleanText(item.title || item.programTitle || item.name || item.channel, 'Unknown Program');
  return {
    id: `${source.sourceId}:${channelId}`,
    externalId: channelId,
    number: cleanText(String(item.number || item.channelNumber || ''), ''),
    name: cleanText(item.channel || item.name || title, 'Channel'),
    logo: cleanText(item.logo || item.icon || '', ''),
    poster: cleanText(item.poster || item.image || item.logo || '', ''),
    backdrop: cleanText(item.backdrop || item.background || item.poster || '', ''),
    sourceType: source.type,
    sourceId: source.sourceId,
    sourceName: source.name,
    group: cleanText(item.group || item.category || 'Channels DVR', 'Channels DVR'),
    streamUrl,
    current: {
      title,
      description: cleanText(item.description || 'Now playing', ''),
      start: cleanText(item.startLabel || item.start || '', ''),
      end: cleanText(item.endLabel || item.end || '', ''),
      progress: typeof item.progress === 'number' ? item.progress : null
    },
    next: item.nextTitle ? {
      title: cleanText(item.nextTitle, ''),
      start: cleanText(item.nextStart || '', ''),
      end: cleanText(item.nextEnd || '', '')
    } : null
  };
}

async function fetchChannelsForSource(source) {
  if (source.type === 'channels_dvr') {
    if (!source.url) throw new Error('Channels DVR source requires url');
    const base = String(source.url).replace(/\/$/, '');
    let channels = [];

    // Channels DVR can expose filtered M3U/JSON views depending on device/filter.
    // Merge every known export instead of stopping at the first one, so large DVR
    // lineups and real playlist categories are preserved.
    const m3uUrls = [
      `${base}/devices/ANY/channels.m3u?format=ts&codec=copy`,
      `${base}/devices/ANY/channels.m3u?format=ts`,
      `${base}/devices/ANY/channels.m3u?format=hls`,
      `${base}/devices/ANY/channels.m3u`
    ];
    for (const m3uUrl of m3uUrls) {
      try {
        const text = await fetchText(m3uUrl, 30000, { Accept: 'audio/x-mpegurl,application/x-mpegURL,text/plain,*/*', ...(source.headers || {}) });
        const parsed = parseM3U(text, { ...source, type: 'channels_dvr' });
        if (parsed.length) channels.push(...parsed);
      } catch (err) {}
    }

    try {
      const payload = await fetchJson(`${base}/devices/ANY/channels`, 30000, source.headers || {});
      const items = Array.isArray(payload) ? payload : Array.isArray(payload?.channels) ? payload.channels : [];
      channels.push(...items.map(item => normalizeChannelsDvrItem(item, source)));
    } catch (err) {}

    const seen = new Set();
    channels = channels.filter(ch => {
      const key = dvrDedupeKey(ch);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).sort((a, b) => channelSortNumber(a.number) - channelSortNumber(b.number) || String(a.name).localeCompare(String(b.name), undefined, { numeric: true }));

    try {
      const durationSeconds = Number(process.env.EPG_DURATION_SECONDS || 43200);
      const xml = await fetchText(`${base}/devices/ANY/guide/xmltv?duration=${durationSeconds}`, 30000, { Accept: 'application/xml,text/xml,*/*', ...(source.headers || {}) });
      const guide = parseXmltvGuide(xml);
      channels = channels.map(channel => {
        const programs = guideProgramsForChannel(guide, channel);
        if (!programs.length) return channel;
        return {
          ...channel,
          programs,
          current: programs[0] || channel.current,
          next: programs[1] || channel.next
        };
      });
    } catch (err) {
      // Keep channels usable even if guide is temporarily unavailable.
    }
    return channels;
  }
  if (source.type === 'm3u' || source.type === 'public_demo' || source.type === 'xtream') {
    const playlistUrl = source.m3uUrl || source.url;
    if (!playlistUrl) throw new Error('M3U source requires url');
    const text = await fetchText(playlistUrl, Number(process.env.PROVIDER_M3U_TIMEOUT_MS || 30000), { Accept: 'audio/x-mpegurl,application/x-mpegURL,text/plain,*/*', ...(source.headers || {}) });
    let channels = parseM3U(text, { ...source, url: playlistUrl });
    if (source.xmltvUrl) {
      try {
        const xml = await fetchText(source.xmltvUrl, Number(process.env.PROVIDER_XMLTV_TIMEOUT_MS || 45000), { Accept: 'application/xml,text/xml,*/*', ...(source.headers || {}) });
        const guide = parseXmltvGuide(xml);
        channels = attachXmltvGuideToChannels(channels, source, guide);
      } catch (err) {
        // Provider-native mode keeps channel playback usable even if XMLTV is temporarily unavailable.
      }
    }
    return channels;
  }
  return [];
}

function buildQuickGuide(channels, selectedChannelId) {
  const maxItems = Number(process.env.LIVE_MAX_QUICK_GUIDE_ITEMS || 12);
  const selectedIndex = Math.max(channels.findIndex(c => c.id === selectedChannelId), 0);
  const start = Math.max(0, Math.min(selectedIndex - 2, Math.max(0, channels.length - maxItems)));
  const slice = channels.slice(start, start + maxItems);
  const focused = slice.find(c => c.id === selectedChannelId) || slice[0] || null;
  return {
    generatedAt: new Date().toISOString(),
    selectedChannelId: focused?.id || null,
    items: slice,
    focused
  };
}

function groupChannels(channels) {
  const groups = new Map();
  for (const channel of channels) {
    const keys = Array.isArray(channel.groups) && channel.groups.length ? channel.groups : [channel.group || 'Other'];
    for (const keyRaw of keys) {
      const key = String(keyRaw || 'Other').trim() || 'Other';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(channel);
    }
  }
  return Array.from(groups.entries()).map(([title, items]) => ({ title, items }));
}

async function refreshLiveData({ userId } = {}) {
  const users = loadLiveUsers().users || {};
  const allUserIds = userId ? [userId] : Object.keys(users);
  const cache = loadLiveCache();
  const next = {
    generatedAt: new Date().toISOString(),
    users: cache.users || {}
  };
  for (const uid of allUserIds) {
    const sources = listLiveSources(uid);
    const channels = [];
    const sourceStates = [];
    for (const source of sources) {
      const state = { sourceId: source.sourceId, name: source.name, type: source.type, ok: false, channels: 0, error: null };
      try {
        const sourceChannels = await fetchChannelsForSource(source);
        channels.push(...sourceChannels);
        state.ok = sourceChannels.length > 0;
        state.channels = sourceChannels.length;
      } catch (err) {
        state.error = err.message;
      }
      sourceStates.push(state);
    }
    const normalized = channels
      .sort((a, b) => String(a.number || a.name).localeCompare(String(b.number || b.name), undefined, { numeric: true }))
      .map((ch, idx) => ({ ...ch, sortOrder: idx }));
    next.users[uid] = {
      generatedAt: next.generatedAt,
      sources: sourceStates,
      channels: normalized,
      groups: groupChannels(normalized)
    };
  }
  saveLiveCache(next);
  return next;
}

function getLiveUserView(userId) {
  const cache = loadLiveCache();
  return cache.users?.[userId] || { generatedAt: null, sources: [], channels: [], groups: [] };
}

function getChannelById(userId, channelId) {
  const view = getLiveUserView(userId);
  return view.channels.find(c => c.id === channelId) || null;
}

function resolvePlayback(userId, channelId) {
  const channel = getChannelById(userId, channelId);
  if (!channel) throw new Error('Channel not found');
  return {
    userId,
    channelId,
    sourceId: channel.sourceId,
    sourceName: channel.sourceName,
    streamUrl: channel.streamUrl,
    directPlay: true,
    headers: {},
    playbackType: 'direct',
    resolvedAt: new Date().toISOString()
  };
}

module.exports = {
  DEFAULT_SOURCES,
  loadHomeRows,
  loadState,
  refreshCatalogs,
  loadLiveUsers,
  listLiveSources,
  upsertLiveSource,
  loadLiveCache,
  refreshLiveData,
  getLiveUserView,
  getChannelById,
  buildQuickGuide,
  resolvePlayback
};
