# backend_v1.8.3_CDN_ADDED_NO_ROUTE_REMOVAL Audit

Base: `bacEnd_v1.8.2_backend_web_dash_no_android_client.zip` / `work182`

## Rule followed
This build keeps the original backend as the active backend. It does not move v1.8.2 into a legacy-only folder and does not replace `server.js` with a separate minimal CDN server.

## Preserved active routes
- `/health`, `/api/health`
- `/api/home`, `/api/catalog/movies`, `/api/catalog/shows`, `/api/search`
- `/api/sources`, `/api/refresh`
- Existing trailer extraction stack:
  - `/trailers/extractor/status`
  - `/api/trailers/extractor/status`
  - `/trailers/extract`
  - `/api/trailers/extract`
  - `/trailers/extractor/resolve`
  - `/api/trailers/extractor/resolve`
  - `/trailers/resolve`
  - `/trailers/prewarm`
  - `/api/trailer/:id`

## Added CDN-ready routes
- `/api/cdn/status`
- `/api/image?url=<encoded-image-url>`
- `/api/proxy/image?url=<encoded-image-url>`
- `/api/addon/manifest?manifestUrl=<manifest>`
- `/api/addon/catalog?manifestUrl=<manifest>&type=movie&id=<catalog>`
- `/api/addon/meta?manifestUrl=<manifest>&type=movie&id=<id>`
- `/api/addon/streams?manifestUrl=<manifest>&type=movie&id=<id>`
- `/api/streams?manifestUrl=<manifest>&type=movie&id=<id>`

## Validation performed
- `npm run check`
- `node --check` on server/lib/worker

## Notes
- No app-side routes were intentionally removed.
- Image proxy uses built-in Node fetch and filesystem cache; no new dependency required.
- Video stream URLs are not CDN-cached.
