# Trailer backend notes

This backend is used by both focused-card trailers and movie/show detail background trailers.

- `/trailers/resolve` resolves a playable trailer stream using yt-dlp.
- `prefer4k=true` requests 2160p first, then falls back to 1080p/best available.
- `/trailers/prewarm` lets the Android TV app warm trailer results before the user opens cards or detail pages.
- Results are cached to reduce repeat yt-dlp work and keep scrolling/detail pages smooth.
