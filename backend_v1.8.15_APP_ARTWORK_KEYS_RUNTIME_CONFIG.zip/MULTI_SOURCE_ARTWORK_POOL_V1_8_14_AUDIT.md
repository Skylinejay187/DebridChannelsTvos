# Debrid Channels Backend v1.8.14 — Multi-Source Artwork Pool

Base used: `backend_v1.8.13.16_UNCHANGED_FOR_V76.zip`

## Goal
Add a backend artwork contract that both Android TV and tvOS can consume for richer randomized artwork without breaking the existing v1.8.13 catalog, live TV, Bunny/CDN proxy, trailer, or home endpoints.

## Added
- Multi-source artwork pool schema:
  - `posters[]`
  - `backdrops[]`
  - `logos[]`
  - `clearlogos[]`
  - `landscape[]`
  - `banners[]`
  - `stills[]`
  - `programArt[]`
  - `channelLogos[]`
  - `previewImages[]`
- Stable randomized artwork selection:
  - `selectedArtwork.poster`
  - `selectedArtwork.backdrop`
  - `selectedArtwork.logo`
  - `selectedArtwork.clearlogo`
  - `selectedArtwork.landscape`
  - `selectedArtwork.banner`
  - `selectedArtwork.still`
  - `selectedArtwork.programArt`
  - `selectedArtwork.channelLogo`
  - `selectedArtwork.previewImage`
- Sticky randomization window so artwork does not flicker while scrolling.
- Optional provider env keys:
  - `TMDB_API_KEY`
  - `FANART_TV_API_KEY`
  - `TVDB_API_TOKEN`
- Runtime artwork resolver endpoint upgraded:
  - `GET /api/artwork/resolve?imdbId=&tmdbId=&tvdbId=&type=`
- Home item payloads now include:
  - `artworkPool`
  - `artworkPoolStats`
  - `selectedArtwork`
  - `artworkRandomize`
- Provider metadata fallback remains active even when external API keys are missing.

## Preserved
- Existing `/api/home`, `/api/home/instant`, `/api/home/hero` behavior.
- Existing image proxy/CDN behavior.
- Existing poster-logo and hero-logo compositor routes.
- Existing live TV cache/logo/artwork routes.
- Existing trailer routes and yt-dlp logic.

## Notes
The backend now gives both apps a normalized artwork model. The apps should prefer `selectedArtwork` for stable randomized art and may use `artworkPool` arrays for manual rotation or user-selected artwork modes.
