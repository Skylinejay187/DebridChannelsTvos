
const http = require('http');
const zlib = require('zlib');
const { URL } = require('url');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
let sharp = null;
try { sharp = require('sharp'); } catch { sharp = null; }
const DATA_DIR = path.join(__dirname, 'data');
const {
  loadHomeRows,
  loadState,
  refreshCatalogs,
  DEFAULT_SOURCES,
  loadLiveUsers,
  listLiveSources,
  upsertLiveSource,
  loadLiveCache,
  refreshLiveData,
  getLiveUserView,
  getChannelById,
  buildQuickGuide,
  resolvePlayback
} = require('./lib');

const port = Number(process.env.PORT || 8181);
const publicBaseUrl = process.env.PUBLIC_BASE_URL || `http://localhost:${port}`;
const backendVersion = 'backend_v1.8.15_APP_ARTWORK_KEYS_RUNTIME_CONFIG';
const cdnAssetBaseUrl = String(process.env.CDN_ASSET_BASE_URL || process.env.BUNNY_CDN_ASSET_BASE_URL || '').replace(/\/$/, '');
const cdnArtworkEnabled = !!cdnAssetBaseUrl && String(process.env.CDN_ARTWORK_ENABLED || '1') !== '0';
// Disabled by default: normal artwork loading/CDN proxy remains active, but broad Bunny auto-prewarm is off.
const BUNNY_PREWARM_ENABLED = String(process.env.BUNNY_ARTWORK_PREWARM_ENABLED || process.env.CDN_ARTWORK_PREWARM_ENABLED || '0') === '1';
const BUNNY_PREWARM_MANUAL_ENABLED = String(process.env.BUNNY_ARTWORK_PREWARM_MANUAL_ENABLED || process.env.CDN_ARTWORK_PREWARM_MANUAL_ENABLED || '0') === '1';
const BUNNY_PREWARM_LIMIT = Number(process.env.BUNNY_ARTWORK_PREWARM_LIMIT || process.env.CDN_ARTWORK_PREWARM_LIMIT || 240);
const BUNNY_PREWARM_CONCURRENCY = Math.max(1, Math.min(Number(process.env.BUNNY_ARTWORK_PREWARM_CONCURRENCY || 4), 12));
const BUNNY_PREWARM_TIMEOUT_MS = Number(process.env.BUNNY_ARTWORK_PREWARM_TIMEOUT_MS || 12000);
const ARTWORK_POOL_CACHE_FILE = path.join(DATA_DIR, 'artwork-pool-cache.json');
const ARTWORK_PROVIDER_KEYS_FILE = path.join(DATA_DIR, 'artwork-provider-keys.json');
const ARTWORK_RANDOMIZE_ENABLED = String(process.env.ARTWORK_RANDOMIZE_ENABLED || '1') !== '0';
const ARTWORK_RANDOM_STICKY_HOURS = Math.max(1, Number(process.env.ARTWORK_RANDOM_STICKY_HOURS || 24));
const ARTWORK_PROVIDER_TIMEOUT_MS = Number(process.env.ARTWORK_PROVIDER_TIMEOUT_MS || 9000);
function readArtworkProviderKeys() {
  try {
    const parsed = JSON.parse(fs.readFileSync(ARTWORK_PROVIDER_KEYS_FILE, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch { return {}; }
}
function writeArtworkProviderKeys(keys = {}) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const clean = {
    tmdbApiKey: String(keys.tmdbApiKey || keys.tmdb || '').trim(),
    fanartTvApiKey: String(keys.fanartTvApiKey || keys.fanart || keys.fanarttv || '').trim(),
    tvdbApiToken: String(keys.tvdbApiToken || keys.tvdb || '').trim(),
    updatedAt: new Date().toISOString()
  };
  fs.writeFileSync(ARTWORK_PROVIDER_KEYS_FILE, JSON.stringify(clean, null, 2));
  try { fs.writeFileSync(ARTWORK_POOL_CACHE_FILE, JSON.stringify({ entries: {}, generatedAt: new Date().toISOString(), clearedReason: 'provider-keys-updated' }, null, 2)); } catch {}
  return clean;
}
function artworkProviderKeys() {
  const saved = readArtworkProviderKeys();
  return {
    tmdbApiKey: process.env.TMDB_API_KEY || saved.tmdbApiKey || '',
    fanartTvApiKey: process.env.FANART_TV_API_KEY || process.env.FANARTTV_API_KEY || saved.fanartTvApiKey || '',
    tvdbApiToken: process.env.TVDB_API_TOKEN || process.env.TVDB_BEARER_TOKEN || saved.tvdbApiToken || ''
  };
}
function artworkProviderKeyStatus() {
  const keys = artworkProviderKeys();
  return {
    tmdb: !!keys.tmdbApiKey,
    fanartTv: !!keys.fanartTvApiKey,
    tvdb: !!keys.tvdbApiToken,
    source: fs.existsSync(ARTWORK_PROVIDER_KEYS_FILE) ? 'runtime-file-or-env' : 'env-only'
  };
}
const BUNNY_PREWARM_STATUS_FILE = path.join(DATA_DIR, 'bunny-prewarm-status.json');
const BUNNY_PREWARM_INTERVAL_HOURS = Number(process.env.BUNNY_ARTWORK_PREWARM_INTERVAL_HOURS || 24);
const BUNNY_PREWARM_SCAN_INTERVAL_MS = Number(process.env.BUNNY_ARTWORK_PREWARM_SCAN_INTERVAL_MS || 15 * 60 * 1000);
const BUNNY_PREWARM_STARTUP_DELAY_MS = Number(process.env.BUNNY_ARTWORK_PREWARM_STARTUP_DELAY_MS || 20000);
const BUNNY_PREWARM_NEW_ARTWORK_LIMIT = Number(process.env.BUNNY_ARTWORK_PREWARM_NEW_LIMIT || BUNNY_PREWARM_LIMIT);

function liveDisabled(res) {
  return json(res, 410, {
    ok: false,
    disabled: true,
    message: 'Live TV provider handling was moved to the Android app. Configure Channels DVR Direct, M3U, or Xtream/IPTV in app settings.'
  });
}



const trailerCache = new Map();
const inflightTrailerResolves = new Map();
const KEEP_TRAILER_PREVIEW_CACHE_FOREVER = String(process.env.KEEP_TRAILER_PREVIEW_CACHE_FOREVER || '1') !== '0';
const TRAILER_CACHE_TTL_MS = KEEP_TRAILER_PREVIEW_CACHE_FOREVER
  ? Number(process.env.TRAILER_CACHE_TTL_MS || 3650 * 24 * 60 * 60 * 1000)
  : Number(process.env.TRAILER_CACHE_TTL_MS || 6 * 60 * 60 * 1000);
function trailerCacheValid(entry) {
  if (!entry) return false;
  return KEEP_TRAILER_PREVIEW_CACHE_FOREVER || entry.expiresAt > Date.now();
}
function trailerCacheExpiresAt() {
  return KEEP_TRAILER_PREVIEW_CACHE_FOREVER ? Number.MAX_SAFE_INTEGER : Date.now() + TRAILER_CACHE_TTL_MS;
}
const YTDLP_TIMEOUT_MS = Number(process.env.YTDLP_TIMEOUT_MS || 30000);

const TRAILER_PROGRESSIVE_FIRST = String(process.env.TRAILER_PROGRESSIVE_FIRST || '1') !== '0';
const TRAILER_METADATA_ONLY_PREWARM = String(process.env.TRAILER_METADATA_ONLY_PREWARM || process.env.TRAILER_CACHE_VIDEO || '0') !== '1';
const TRAILER_FAST_MODE = String(process.env.TRAILER_FAST_MODE || process.env.XGIMI_TRAILER_FAST_MODE || '1') !== '0';
const TRAILER_DEFAULT_MAX_HEIGHT = Number(process.env.TRAILER_DEFAULT_MAX_HEIGHT || (TRAILER_FAST_MODE ? 1080 : 2160));
const TRAILER_PREWARM_LIMIT = Number(process.env.TRAILER_PREWARM_LIMIT || 10);


function ytDlpCandidates() {
  const raw = [
    process.env.YTDLP_BIN,
    '/usr/local/bin/yt-dlp',
    '/usr/bin/yt-dlp',
    'yt-dlp'
  ].filter(Boolean);
  return [...new Set(raw)];
}

function execYtDlp(args, timeoutMs = 60000) {
  return new Promise((resolve, reject) => {
    const candidates = ytDlpCandidates();
    let index = 0;
    const tryNext = (lastError) => {
      if (index >= candidates.length) {
        const err = lastError || new Error('yt-dlp not found');
        err.message = `yt-dlp failed. Tried: ${candidates.join(', ')}\n${err.message}`;
        return reject(err);
      }
      const bin = candidates[index++];
      execFile(bin, args, {
        timeout: timeoutMs,
        maxBuffer: 1024 * 1024 * 25,
        env: { ...process.env, PATH: `/usr/local/bin:/usr/bin:/bin:${process.env.PATH || ''}` }
      }, (err, stdout, stderr) => {
        if (err) {
          err.message = [err.message, stderr].filter(Boolean).join('\n');
          if (err.code === 'ENOENT') return tryNext(err);
          return reject(err);
        }
        resolve({ stdout, stderr, bin });
      });
    };
    tryNext();
  });
}

async function execYtDlpStdout(args, timeoutMs = 60000) {
  const result = await execYtDlp(args, timeoutMs);
  return result.stdout;
}


function cleanTitleForTrailer(title) {
  return String(title || '')
    .replace(/\s*[•|-]\s*(S\d+|Season\s+\d+|Episode\s+\d+|E\d+).*$/i, '')
    .replace(/\s*\((19|20)\d{2}\)\s*$/i, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function trailerSearchQuery(title, year) {
  const clean = cleanTitleForTrailer(title);
  return [clean, year, 'official trailer'].filter(Boolean).join(' ');
}

function normalizeQualityLabel(height, fallback = 'best') {
  if (!height) return fallback;
  if (height >= 2160) return '2160p 4K';
  if (height >= 1440) return '1440p';
  if (height >= 1080) return '1080p';
  return `${height}p`;
}

function titleTokens(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9 ]+/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 1 && !['the','and','official','trailer','teaser','movie','film','series','season','clip','hd','4k','uhd'].includes(t));
}

function scoreTrailerCandidate(entry, requestedTitle, requestedYear) {
  const reqTokens = titleTokens(cleanTitleForTrailer(requestedTitle));
  const haystack = `${entry.title || ''} ${entry.channel || ''} ${entry.uploader || ''} ${entry.description || ''}`.toLowerCase();
  let score = 0;
  for (const token of reqTokens) {
    if (haystack.includes(token)) score += 12;
    else score -= 18;
  }
  if (/official trailer/i.test(entry.title || '')) score += 40;
  if (/trailer/i.test(entry.title || '')) score += 15;
  if (/teaser/i.test(entry.title || '')) score -= 8;
  if (/fan\s*made|concept|reaction|review|breakdown|explained|clip|scene|music video/i.test(entry.title || '')) score -= 80;
  if (/official/i.test(`${entry.channel || ''} ${entry.uploader || ''}`)) score += 20;
  if (/warner|universal|paramount|marvel|disney|pixar|netflix|prime video|hulu|hbo|max|20th century|sony pictures|lionsgate|a24/i.test(`${entry.channel || ''} ${entry.uploader || ''}`)) score += 16;
  if (requestedYear && haystack.includes(String(requestedYear))) score += 12;
  const duration = Number(entry.duration || 0);
  if (duration > 0) {
    if (duration >= 45 && duration <= 240) score += 10;
    if (duration > 420) score -= 30;
  }
  return score;
}

function bestTrailerEntry(info, requestedTitle, requestedYear) {
  const entries = Array.isArray(info.entries) ? info.entries.filter(Boolean) : [info].filter(Boolean);
  if (!entries.length) throw new Error('No trailer results found');
  return entries
    .map(entry => ({ entry, score: scoreTrailerCandidate(entry, requestedTitle, requestedYear) }))
    .sort((a, b) => b.score - a.score)[0].entry;
}

function bestMuxedFormat(formats, prefer4k) {
  const withAudioVideo = (formats || []).filter(f => f.url && f.vcodec && f.vcodec !== 'none' && f.acodec && f.acodec !== 'none');
  const maxHeight = Math.min(prefer4k && !TRAILER_FAST_MODE ? 2160 : 1080, TRAILER_DEFAULT_MAX_HEIGHT || 1080);
  const minPreferredHeight = prefer4k && !TRAILER_FAST_MODE ? 1080 : 720;
  return withAudioVideo
    .filter(f => !f.height || f.height <= maxHeight)
    .sort((a, b) => {
      const ah = a.height || 0;
      const bh = b.height || 0;
      const aPreferred = ah >= minPreferredHeight ? 1 : 0;
      const bPreferred = bh >= minPreferredHeight ? 1 : 0;
      const aMp4 = String(a.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
      const bMp4 = String(b.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
      const aHttp = /^https?:/i.test(String(a.url || '')) ? 1 : 0;
      const bHttp = /^https?:/i.test(String(b.url || '')) ? 1 : 0;
      return bPreferred - aPreferred || bMp4 - aMp4 || bh - ah || bHttp - aHttp || (b.tbr || 0) - (a.tbr || 0);
    })[0] || null;
}

function pickTrailerInfo(info, prefer4k, requestedTitle, requestedYear) {
  const chosen = bestTrailerEntry(info, requestedTitle, requestedYear);
  if (!chosen) throw new Error('No trailer results found');

  const formats = Array.isArray(chosen.formats) ? chosen.formats : [];
  const heights = formats.map(f => Number(f.height || 0)).filter(Boolean);
  const maxAvailableHeight = heights.length ? Math.max(...heights) : 0;
  const has4k = maxAvailableHeight >= 2160;
  const has1080 = maxAvailableHeight >= 1080;

  const muxed = bestMuxedFormat(chosen.formats || [], prefer4k);
  if (TRAILER_PROGRESSIVE_FIRST && muxed) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: muxed.url,
      mimeType: muxed.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4',
      quality: muxed.format_note || normalizeQualityLabel(muxed.height, 'best'),
      maxHeight: muxed.height || 0,
      fallbackUsed: prefer4k && (muxed.height || 0) < 2160,
      source: 'yt-dlp-progressive-first-no-cdn-video'
    };
  }

  const manifestUrl = chosen.dash_url || chosen.manifest_url || chosen.hls_url || '';
  if (manifestUrl && (prefer4k || has1080) && !TRAILER_FAST_MODE) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: manifestUrl,
      mimeType: manifestUrl.includes('.m3u8') ? 'application/x-mpegURL' : 'application/dash+xml',
      quality: has4k && prefer4k ? '2160p 4K adaptive' : (has1080 ? '1080p adaptive' : normalizeQualityLabel(maxAvailableHeight, 'adaptive')),
      maxHeight: maxAvailableHeight,
      fallbackUsed: prefer4k && !has4k,
      source: 'yt-dlp-adaptive-manifest'
    };
  }

  if (muxed) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: muxed.url,
      mimeType: muxed.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4',
      quality: muxed.format_note || normalizeQualityLabel(muxed.height, 'best'),
      maxHeight: muxed.height || 0,
      fallbackUsed: prefer4k && (muxed.height || 0) < 2160,
      source: 'yt-dlp-direct-muxed'
    };
  }

  if (chosen.url) {
    return {
      videoId: chosen.id || '',
      title: chosen.title || '',
      channel: chosen.channel || chosen.uploader || '',
      duration: chosen.duration || 0,
      playbackUrl: chosen.url,
      mimeType: 'video/mp4',
      quality: chosen.format_note || 'best',
      source: 'yt-dlp-direct'
    };
  }
  throw new Error('No playable trailer stream found');
}


function pickBestVideoAudioFormats(formats, prefer4k) {
  const maxHeight = Math.min(prefer4k && !TRAILER_FAST_MODE ? 2160 : 1080, TRAILER_DEFAULT_MAX_HEIGHT || 1080);
  const minHeight = prefer4k && !TRAILER_FAST_MODE ? 1080 : 720;
  const videoOnly = (formats || []).filter(f =>
    f && f.url && f.vcodec && f.vcodec !== 'none' && (!f.acodec || f.acodec === 'none') && Number(f.height || 0) <= maxHeight
  ).sort((a, b) => {
    const ah = Number(a.height || 0), bh = Number(b.height || 0);
    const ap = ah >= minHeight ? 1 : 0, bp = bh >= minHeight ? 1 : 0;
    const aMp4 = String(a.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
    const bMp4 = String(b.ext || '').toLowerCase() === 'mp4' ? 1 : 0;
    return bp - ap || bh - ah || bMp4 - aMp4 || Number(b.tbr || 0) - Number(a.tbr || 0);
  });
  const audioOnly = (formats || []).filter(f =>
    f && f.url && (!f.vcodec || f.vcodec === 'none') && f.acodec && f.acodec !== 'none'
  ).sort((a, b) => {
    const aM4a = String(a.ext || '').toLowerCase() === 'm4a' ? 1 : 0;
    const bM4a = String(b.ext || '').toLowerCase() === 'm4a' ? 1 : 0;
    return bM4a - aM4a || Number(b.abr || b.tbr || 0) - Number(a.abr || a.tbr || 0);
  });
  const progressive = bestMuxedFormat(formats || [], prefer4k);
  return { video: videoOnly[0] || null, audio: audioOnly[0] || null, progressive };
}

function formatPayloadFromInfo(info, prefer4k, originalUrl) {
  const requestedFormats = Array.isArray(info.requested_formats) ? info.requested_formats : [];
  const formats = requestedFormats.length ? requestedFormats : (Array.isArray(info.formats) ? info.formats : []);
  const { video, audio, progressive } = pickBestVideoAudioFormats(formats, prefer4k);
  const height = Number((video && video.height) || (progressive && progressive.height) || info.height || 0);
  const payload = {
    ok: true,
    extractor: 'yt-dlp',
    id: info.id || '',
    title: info.title || '',
    webpageUrl: info.webpage_url || originalUrl,
    requestedUrl: originalUrl,
    quality: normalizeQualityLabel(height, prefer4k ? 'best up to 4K' : 'best up to 1080p'),
    height,
    maxHeight: height,
    source: video && audio ? 'yt-dlp-split-dash' : 'yt-dlp-progressive',
    expiresAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString()
  };
  if (process.env.TRAILER_PROGRESSIVE_FIRST !== '0' && progressive && progressive.url && Number(progressive.height || 0) >= Number(process.env.TRAILER_MIN_PROGRESSIVE_HEIGHT || 720)) {
    payload.playbackUrl = progressive.url;
    payload.url = progressive.url;
    payload.merged = progressive.url;
    payload.mergedUrl = progressive.url;
    payload.mimeType = progressive.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4';
    payload.source = 'yt-dlp-progressive-reliable-first';
    payload.height = Number(progressive.height || payload.height || 0);
    payload.maxHeight = payload.height;
    payload.quality = normalizeQualityLabel(payload.height, prefer4k ? 'best up to 4K' : 'best up to 1080p');
    payload.format = { progressive: { id: progressive.format_id, ext: progressive.ext, height: progressive.height, vcodec: progressive.vcodec, acodec: progressive.acodec, tbr: progressive.tbr } };
    return payload;
  }

  if (video && audio) {
    payload.videoUrl = video.url;
    payload.audioUrl = audio.url;
    payload.video_url = video.url;
    payload.audio_url = audio.url;
    payload.videoMimeType = video.ext === 'webm' ? 'video/webm' : 'video/mp4';
    payload.audioMimeType = audio.ext === 'webm' ? 'audio/webm' : 'audio/mp4';
    payload.playbackUrl = video.url;
    payload.mimeType = payload.videoMimeType;
    payload.format = {
      video: { id: video.format_id, ext: video.ext, height: video.height, fps: video.fps, vcodec: video.vcodec, tbr: video.tbr },
      audio: { id: audio.format_id, ext: audio.ext, acodec: audio.acodec, abr: audio.abr, tbr: audio.tbr }
    };
    return payload;
  }
  if (progressive && progressive.url) {
    payload.playbackUrl = progressive.url;
    payload.url = progressive.url;
    payload.merged = progressive.url;
    payload.mergedUrl = progressive.url;
    payload.mimeType = progressive.ext === 'm3u8' ? 'application/x-mpegURL' : 'video/mp4';
    payload.format = { progressive: { id: progressive.format_id, ext: progressive.ext, height: progressive.height, vcodec: progressive.vcodec, acodec: progressive.acodec, tbr: progressive.tbr } };
    return payload;
  }
  if (info.url) {
    payload.playbackUrl = info.url;
    payload.url = info.url;
    payload.merged = info.url;
    payload.mergedUrl = info.url;
    payload.mimeType = inferMimeFromUrl(info.url);
    return payload;
  }
  throw new Error('No playable trailer URLs found in yt-dlp response');
}

async function extractTrailerStreams(videoUrl, prefer4k) {
  const cacheKey = ['extract-v182', videoUrl, prefer4k ? '4k' : '1080'].join('|');
  const cached = trailerCache.get(cacheKey);
  if (trailerCacheValid(cached)) return { ...cached.value, cached: true, keepForever: KEEP_TRAILER_PREVIEW_CACHE_FOREVER };

  // IMPORTANT: do NOT force the Android YouTube client here. On many videos that
  // client only exposes itag 18 / 360p progressive to yt-dlp, even when `yt-dlp -F`
  // shows 1080p/4K DASH formats. Use the normal web extractor and force split
  // DASH first so the app can merge video+audio with Media3.
  const maxHeight = Math.min(prefer4k && !TRAILER_FAST_MODE ? 2160 : 1080, TRAILER_DEFAULT_MAX_HEIGHT || 1080);
  const format = [
    `bestvideo[height<=${maxHeight}][height>=1080][ext=mp4]+bestaudio[ext=m4a]`,
    `bestvideo[height<=${maxHeight}][height>=1080]+bestaudio`,
    `bestvideo[height<=${maxHeight}]+bestaudio`,
    `best[height<=${maxHeight}][height>=720]`,
    `best[height<=${maxHeight}]`,
    'best'
  ].join('/');

  const stdout = await execYtDlpStdout([
    '--dump-single-json', '--no-playlist', '--no-warnings', '--skip-download', '--force-ipv4',
    '--format', format,
    '--format-sort', 'res,ext:mp4:m4a',
    videoUrl
  ], YTDLP_TIMEOUT_MS);
  const info = JSON.parse(stdout);
  const payload = formatPayloadFromInfo(info, prefer4k, videoUrl);

  // Hard guard: if a 1080p/4K video still resolves as 360p progressive, tell the
  // client/backend log the truth instead of silently pretending this is HD.
  if ((payload.height || 0) < 720 && payload.source === 'yt-dlp-progressive') {
    payload.warning = 'yt-dlp returned only low progressive from this extractor response; check cookies/age/region restrictions or run yt-dlp -F on the same host.';
  }
  const value = {
    ...payload,
    trailer: {
      playbackUrl: payload.playbackUrl,
      videoUrl: payload.videoUrl,
      audioUrl: payload.audioUrl,
      video_url: payload.video_url,
      audio_url: payload.audio_url,
      mimeType: payload.mimeType,
      videoMimeType: payload.videoMimeType,
      audioMimeType: payload.audioMimeType,
      quality: payload.quality,
      maxHeight: payload.maxHeight,
      height: payload.height,
      title: payload.title,
      source: payload.source
    }
  };
  trailerCache.set(cacheKey, { value, expiresAt: trailerCacheExpiresAt(), keepForever: KEEP_TRAILER_PREVIEW_CACHE_FOREVER });
  return value;
}

function candidateVideoId(entry) {
  return entry && (entry.id || entry.url || entry.webpage_url || '');
}

async function resolveTrailer({ title, year, prefer4k, mediaId, mediaType }) {
  const cleanTitle = cleanTitleForTrailer(title);
  const scopedId = String(mediaId || '').trim();
  const scopedType = String(mediaType || '').trim();
  const cacheKey = [scopedType, scopedId, cleanTitle, year, prefer4k].join('|').toLowerCase();
  const cached = trailerCache.get(cacheKey);
  if (trailerCacheValid(cached)) return { ...cached.value, cached: true, keepForever: KEEP_TRAILER_PREVIEW_CACHE_FOREVER };
  if (inflightTrailerResolves.has(cacheKey)) return await inflightTrailerResolves.get(cacheKey);

  const promise = (async () => {
    const query = trailerSearchQuery(cleanTitle, year);
    let chosenTitle = '';
    let videoUrl = `ytsearch1:${query}`;

    // Real HD path: score a trailer candidate, then extract split DASH video+audio.
    let value;
    try {
      const searchStdout = await execYtDlpStdout([
        '--dump-single-json',
        '--no-playlist',
        '--no-warnings',
        '--skip-download',
        '--force-ipv4',
        '--extractor-args', 'youtube:player_client=android,web,tv_embedded',
        'ytsearch5:' + query
      ], YTDLP_TIMEOUT_MS);
      const searchInfo = JSON.parse(searchStdout);
      const chosen = bestTrailerEntry(searchInfo, cleanTitle, year);
      chosenTitle = chosen.title || '';
      const id = candidateVideoId(chosen);
      if (id) videoUrl = String(id).startsWith('http') ? id : `https://www.youtube.com/watch?v=${id}`;
    } catch (err) {
      chosenTitle = '';
      videoUrl = `ytsearch1:${query}`;
    }
    value = await extractTrailerStreams(videoUrl, prefer4k);

    value.searchTitle = chosenTitle || value.title || query;
    value.query = query;
    value.resolvedAt = new Date().toISOString();
    trailerCache.set(cacheKey, { value, expiresAt: trailerCacheExpiresAt(), keepForever: KEEP_TRAILER_PREVIEW_CACHE_FOREVER });
    return value;
  })().finally(() => inflightTrailerResolves.delete(cacheKey));


  inflightTrailerResolves.set(cacheKey, promise);
  return await promise;
}

function buildFocusedPreviewPayload(trailer, { title, year, mediaId, mediaType } = {}) {
  const previewUrl = firstNonEmpty(
    trailer && trailer.previewUrl,
    trailer && trailer.preview_url,
    trailer && trailer.playbackUrl,
    trailer && trailer.url,
    trailer && trailer.mergedUrl,
    trailer && trailer.merged,
    trailer && trailer.trailer && trailer.trailer.playbackUrl,
    trailer && trailer.trailer && trailer.trailer.url
  );
  const videoUrl = firstNonEmpty(
    trailer && trailer.videoUrl,
    trailer && trailer.video_url,
    trailer && trailer.trailer && trailer.trailer.videoUrl,
    trailer && trailer.trailer && trailer.trailer.video_url
  );
  const audioUrl = firstNonEmpty(
    trailer && trailer.audioUrl,
    trailer && trailer.audio_url,
    trailer && trailer.trailer && trailer.trailer.audioUrl,
    trailer && trailer.trailer && trailer.trailer.audio_url
  );
  const playableUrl = previewUrl || videoUrl;
  return {
    ok: !!playableUrl,
    title: title || (trailer && trailer.title) || '',
    year: year || '',
    mediaId: mediaId || '',
    mediaType: mediaType || '',
    previewUrl: playableUrl || null,
    playbackUrl: playableUrl || null,
    videoUrl: videoUrl || null,
    audioUrl: audioUrl || null,
    previewType: playableUrl ? (audioUrl ? 'official-trailer-dash-preview' : 'official-trailer-progressive-preview') : 'artwork-motion-fallback',
    previewSource: playableUrl ? firstNonEmpty(trailer && trailer.source, trailer && trailer.trailer && trailer.trailer.source, 'yt-dlp-official-trailer-resolver') : 'none',
    previewDurationSeconds: 30,
    retention: KEEP_TRAILER_PREVIEW_CACHE_FOREVER ? 'keep-indefinitely-manual-cleanup-only' : 'ttl',
    muted: true,
    loop: true,
    startAfterFocusMs: 1700,
    killOnFocusLoss: true,
    noPreview: !playableUrl,
    fallback: playableUrl ? null : 'artwork-motion',
    resolvedAt: new Date().toISOString(),
    cached: !!(trailer && trailer.cached),
    quality: trailer && (trailer.quality || trailer.maxHeight || trailer.height) || null,
    mimeType: firstNonEmpty(trailer && trailer.mimeType, trailer && trailer.trailer && trailer.trailer.mimeType, audioUrl ? 'application/dash-like-split' : '') || null
  };
}

function parseBool(value) {
  return ['1', 'true', 'yes', 'on'].includes(String(value || '').trim().toLowerCase());
}

function json(res, statusCode, payload, options = {}) {
  const body = JSON.stringify(payload, null, 2);
  const cacheControl = options.cacheControl || 'no-store';
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': cacheControl,
    'X-Debrid-Channels-Backend': backendVersion,
    ...(options.headers || {})
  };
  res.writeHead(statusCode, headers);
  res.end(body);
}

function cacheKeyFromUrl(prefix, url) {
  const query = new URLSearchParams(url.searchParams);
  return `${prefix}:${url.pathname}?${query.toString()}`;
}

function responseCacheGet(key) {
  return cacheGet(`response:${key}`);
}

function responseCacheSet(key, value, ttlMs) {
  return cacheSet(`response:${key}`, value, ttlMs);
}

function cachedJson(res, key, ttlMs, cacheControl, producer) {
  const hit = responseCacheGet(key);
  if (hit) {
    return json(res, 200, hit, {
      cacheControl,
      headers: { 'X-Debrid-Channels-Response-Cache': 'hit' }
    });
  }
  const value = producer();
  responseCacheSet(key, value, ttlMs);
  return json(res, 200, value, {
    cacheControl,
    headers: { 'X-Debrid-Channels-Response-Cache': 'miss' }
  });
}

function shouldProxyImages(url) {
  const requested = url.searchParams.get('proxyImages');
  if (requested === '0' || requested === 'false') return false;
  if (requested === '1' || requested === 'true') return true;
  return PROXY_IMAGES_BY_DEFAULT;
}

function proxiedImageUrl(sourceUrl) {
  if (!sourceUrl || !isAllowedProxyUrl(sourceUrl)) return sourceUrl || '';
  const raw = String(sourceUrl);
  if (cdnArtworkEnabled && raw.startsWith(`${cdnAssetBaseUrl}/api/image?url=`)) return raw;
  if (raw.includes('/api/image?url=')) {
    // Convert already-proxied backend artwork URLs to the Bunny pull-zone host only for images.
    try {
      const parsed = new URL(raw);
      if (cdnArtworkEnabled) return `${cdnAssetBaseUrl}${parsed.pathname}${parsed.search}`;
    } catch {}
    return raw;
  }
  const base = (cdnArtworkEnabled ? cdnAssetBaseUrl : publicBaseUrl).replace(/\/$/, '');
  return `${base}/api/image?url=${encodeURIComponent(raw)}`;
}

function posterLogoCompositeUrl(poster, logo, id = '') {
  // v1.8.13.10 contract: Android row renderer can request one baked poster+logo image.
  // This source-only fallback redirects to the clean poster when the optional real compositor
  // is not installed yet, so Performance/Auto mode never breaks artwork loading.
  if (!poster) return '';
  const base = publicBaseUrl.replace(/\/$/, '');
  const q = new URLSearchParams();
  q.set('poster', poster);
  if (logo) q.set('logo', logo);
  if (id) q.set('id', id);
  q.set('quality', '4k-source');
  return `${base}/api/card/poster-logo?${q.toString()}`;
}

function rewriteImagesDeep(value, enabled) {
  if (!enabled) return value;
  const imageKeys = new Set(['poster', 'posterUrl', 'poster4k', 'posterLogoUrl', 'posterLogo4k', 'posterWithLogoUrl', 'bakedPosterLogoUrl', 'cardPosterLogoUrl', 'backdrop', 'backdropUrl', 'logo', 'logoUrl', 'clearLogo', 'image', 'imageUrl', 'icon', 'thumbnail', 'thumbnailUrl', 'still', 'stillUrl', 'background', 'banner', 'bannerUrl', 'rowCardUrl', 'landscapeCardUrl', 'landscapeCard4k', 'rowLandscapeUrl', 'rowLandscape4k', 'cardLandscapeUrl', 'cardLandscape4k', 'cardStillUrl', 'cardStill4k', 'promoStillUrl', 'imdbStillUrl', 'tmdbStillUrl', 'fanartLandscapeUrl', 'fanartLandscape4k', 'tvdbBackgroundUrl', 'tvdbStillUrl', 'programArt', 'programArtUrl', 'channelLogo', 'channelLogoUrl', 'previewImage', 'previewImageUrl', 'url']);
  const clone = JSON.parse(JSON.stringify(value));
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) return node.forEach(walk);
    for (const [key, val] of Object.entries(node)) {
      if (typeof val === 'string' && imageKeys.has(key) && isAllowedProxyUrl(val)) {
        node[key] = proxiedImageUrl(val);
      } else if (val && typeof val === 'object') {
        walk(val);
      }
    }
  };
  walk(clone);
  return clone;
}

function collectImageUrls(value, urls = new Set()) {
  const imageKeys = new Set(['poster', 'posterUrl', 'poster4k', 'posterLogoUrl', 'posterLogo4k', 'posterWithLogoUrl', 'bakedPosterLogoUrl', 'cardPosterLogoUrl', 'backdrop', 'backdropUrl', 'logo', 'logoUrl', 'clearLogo', 'image', 'imageUrl', 'icon', 'thumbnail', 'thumbnailUrl', 'still', 'stillUrl', 'background', 'banner', 'bannerUrl', 'rowCardUrl', 'landscapeCardUrl', 'landscapeCard4k', 'rowLandscapeUrl', 'rowLandscape4k', 'cardLandscapeUrl', 'cardLandscape4k', 'cardStillUrl', 'cardStill4k', 'promoStillUrl', 'imdbStillUrl', 'tmdbStillUrl', 'fanartLandscapeUrl', 'fanartLandscape4k', 'tvdbBackgroundUrl', 'tvdbStillUrl', 'programArt', 'programArtUrl', 'channelLogo', 'channelLogoUrl', 'previewImage', 'previewImageUrl', 'url']);
  const walk = (node) => {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) return node.forEach(walk);
    for (const [key, val] of Object.entries(node)) {
      if (typeof val === 'string' && imageKeys.has(key) && isAllowedProxyUrl(val) && !String(val).includes('/api/image?url=')) urls.add(val);
      else if (val && typeof val === 'object') walk(val);
    }
  };
  walk(value);
  return [...urls];
}

async function prewarmImagesFromPayload(payload, limit = 80) {
  const urls = collectImageUrls(payload).slice(0, limit);
  let queued = 0;
  for (const sourceUrl of urls) {
    const key = sha256(sourceUrl);
    const metaPath = path.join(CDN_IMAGE_DIR, `${key}.json`);
    try {
      const existingMeta = fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : null;
      if (existingMeta && existingMeta.expiresAt > Date.now() && fs.existsSync(existingMeta.file)) continue;
    } catch {}
    queued += 1;
    setTimeout(async () => {
      try {
        ensureCdnDirs();
        const upstream = await fetchWithTimeout(sourceUrl, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' });
        if (!upstream.ok) return;
        const contentType = upstream.headers.get('content-type') || 'image/jpeg';
        if (!String(contentType).toLowerCase().startsWith('image/')) return;
        const buffer = Buffer.from(await upstream.arrayBuffer());
        if (!buffer.length || buffer.length > CDN_MAX_IMAGE_BYTES) return;
        const ext = safeExtFromContentType(contentType, sourceUrl);
        const filePath = path.join(CDN_IMAGE_DIR, `${key}${ext}`);
        fs.writeFileSync(filePath, buffer);
        fs.writeFileSync(metaPath, JSON.stringify({ sourceUrl, file: filePath, contentType, bytes: buffer.length, cachedAt: Date.now(), expiresAt: Date.now() + CDN_IMAGE_TTL_MS }, null, 2));
      } catch {}
    }, queued * 75);
  }
  return { discovered: urls.length, queued };
}

function readBunnyPrewarmStatus() {
  try { return JSON.parse(fs.readFileSync(BUNNY_PREWARM_STATUS_FILE, 'utf8')); } catch {}
  return { ok: true, version: backendVersion, enabled: cdnArtworkEnabled && BUNNY_PREWARM_ENABLED, running: false, lastRun: null, totals: { discovered: 0, requested: 0, warmed: 0, failed: 0 }, recentErrors: [] };
}

function writeBunnyPrewarmStatus(status) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(BUNNY_PREWARM_STATUS_FILE, JSON.stringify({ ...status, version: backendVersion, updatedAt: new Date().toISOString() }, null, 2));
  } catch {}
}

function bunnyCdnImageUrl(sourceUrl) {
  if (!cdnArtworkEnabled || !cdnAssetBaseUrl || !isAllowedProxyUrl(sourceUrl)) return '';
  const raw = String(sourceUrl);
  if (raw.startsWith(`${cdnAssetBaseUrl}/`)) return raw;
  if (raw.includes('/api/image?url=')) {
    try {
      const parsed = new URL(raw);
      return `${cdnAssetBaseUrl}${parsed.pathname}${parsed.search}`;
    } catch { return ''; }
  }
  return `${cdnAssetBaseUrl}/api/image?url=${encodeURIComponent(raw)}`;
}

function collectPrewarmPayload(scope = 'home-live') {
  const chunks = [];
  // Home rows/catalog rows are the main first-open artwork set.
  try { chunks.push(loadHomeRows()); } catch {}
  // Catalog state can contain newly discovered movie/show artwork before rows refresh.
  if (scope === 'home' || scope === 'home-live' || scope === 'catalog' || scope === 'all') {
    try { chunks.push(loadState()); } catch {}
    try {
      const homeRowsPath = path.join(DATA_DIR, 'home-rows.json');
      if (fs.existsSync(homeRowsPath)) chunks.push(JSON.parse(fs.readFileSync(homeRowsPath, 'utf8')));
    } catch {}
  }
  // Live cache includes channel logos and Gracenote/XMLTV guide thumbnails.
  if (scope === 'home-live' || scope === 'live' || scope === 'all') {
    try { chunks.push(loadLiveCache()); } catch {}
  }
  return { scope, chunks };
}

function prewarmFingerprintForPayload(payload) {
  const urls = collectImageUrls(payload).sort();
  return { count: urls.length, fingerprint: sha256(urls.join('\n')), urls };
}

function queueBunnyPrewarmIfArtworkChanged(reason = 'scan', { limit = BUNNY_PREWARM_NEW_ARTWORK_LIMIT, scope = 'home-live' } = {}) {
  if (!cdnArtworkEnabled || !BUNNY_PREWARM_ENABLED) return { ok: false, skipped: true, reason: 'disabled' };
  const current = readBunnyPrewarmStatus();
  if (current.running) return { ok: true, skipped: true, reason: 'already-running' };
  const payload = collectPrewarmPayload(scope);
  const fp = prewarmFingerprintForPayload(payload);
  if (!fp.count) return { ok: true, skipped: true, reason: 'no-artwork-discovered', count: 0 };
  if (current.lastFingerprint === fp.fingerprint && current.totals && current.totals.discovered === fp.count) {
    return { ok: true, skipped: true, reason: 'unchanged', count: fp.count, fingerprint: fp.fingerprint };
  }
  const queued = {
    ...current,
    ok: true,
    enabled: true,
    running: false,
    queued: true,
    queuedAt: new Date().toISOString(),
    queuedReason: reason,
    discovered: fp.count,
    lastSeenFingerprint: fp.fingerprint,
    message: 'New or changed artwork detected; Bunny artwork prewarm queued.'
  };
  writeBunnyPrewarmStatus(queued);
  setTimeout(() => runBunnyArtworkPrewarm({ limit, scope, force: false, reason }).catch(() => {}), 500);
  return { ok: true, queued: true, reason, count: fp.count, fingerprint: fp.fingerprint };
}

async function runBunnyArtworkPrewarm({ limit = BUNNY_PREWARM_LIMIT, scope = 'home-live', force = false } = {}) {
  const current = readBunnyPrewarmStatus();
  if (!cdnArtworkEnabled || !BUNNY_PREWARM_ENABLED) {
    const disabled = { ...current, ok: true, enabled: false, running: false, message: 'Bunny artwork prewarm disabled or CDN asset base URL missing' };
    writeBunnyPrewarmStatus(disabled);
    return disabled;
  }
  if (current.running && !force) return { ...current, accepted: false, message: 'Bunny artwork prewarm already running' };
  const payload = collectPrewarmPayload(scope);
  const fp = prewarmFingerprintForPayload(payload);
  const sourceUrls = fp.urls.slice(0, Math.max(1, Number(limit) || BUNNY_PREWARM_LIMIT));
  const cdnUrls = [...new Set(sourceUrls.map(bunnyCdnImageUrl).filter(Boolean))];
  const status = {
    ok: true,
    enabled: true,
    running: true,
    startedAt: new Date().toISOString(),
    lastRun: current.lastRun || null,
    assetBaseUrl: cdnAssetBaseUrl,
    scope,
    reason: arguments[0] && arguments[0].reason || 'manual',
    lastFingerprint: fp.fingerprint,
    totals: { discovered: sourceUrls.length, requested: 0, warmed: 0, failed: 0 },
    recentErrors: []
  };
  writeBunnyPrewarmStatus(status);

  let index = 0;
  async function worker() {
    while (index < cdnUrls.length) {
      const cdnUrl = cdnUrls[index++];
      status.totals.requested += 1;
      try {
        const response = await fetchWithTimeout(cdnUrl, BUNNY_PREWARM_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8', 'cache-control': 'no-cache' });
        const ct = response.headers.get('content-type') || '';
        if (response.ok && String(ct).toLowerCase().startsWith('image/')) status.totals.warmed += 1;
        else {
          status.totals.failed += 1;
          if (status.recentErrors.length < 10) status.recentErrors.push({ url: cdnUrl, status: response.status, contentType: ct });
        }
      } catch (err) {
        status.totals.failed += 1;
        if (status.recentErrors.length < 10) status.recentErrors.push({ url: cdnUrl, error: err.message || String(err) });
      }
      if (status.totals.requested % 10 === 0) writeBunnyPrewarmStatus(status);
    }
  }
  await Promise.all(Array.from({ length: Math.min(BUNNY_PREWARM_CONCURRENCY, cdnUrls.length || 1) }, worker));
  status.running = false;
  status.finishedAt = new Date().toISOString();
  status.lastRun = status.finishedAt;
  status.lastFingerprint = fp.fingerprint;
  status.message = 'Bunny artwork prewarm finished. IPTV/live streams and trailer video were not requested.';
  writeBunnyPrewarmStatus(status);
  return status;
}

function scheduleBunnyArtworkPrewarmOnce() {
  if (!cdnArtworkEnabled || !BUNNY_PREWARM_ENABLED) return;
  const status = readBunnyPrewarmStatus();
  const last = status.lastRun ? Date.parse(status.lastRun) : 0;
  const intervalMs = Math.max(1, BUNNY_PREWARM_INTERVAL_HOURS) * 60 * 60 * 1000;
  const shouldRunByTime = !last || Date.now() - last > intervalMs;
  setTimeout(() => {
    if (shouldRunByTime) runBunnyArtworkPrewarm({ limit: BUNNY_PREWARM_LIMIT, scope: 'home-live', reason: 'startup-or-scheduled' }).catch(() => {});
    else queueBunnyPrewarmIfArtworkChanged('startup-artwork-change-scan', { limit: BUNNY_PREWARM_NEW_ARTWORK_LIMIT, scope: 'home-live' });
  }, BUNNY_PREWARM_STARTUP_DELAY_MS);

  setInterval(() => {
    const current = readBunnyPrewarmStatus();
    const lastRun = current.lastRun ? Date.parse(current.lastRun) : 0;
    const dueByTime = !lastRun || Date.now() - lastRun > intervalMs;
    if (dueByTime) runBunnyArtworkPrewarm({ limit: BUNNY_PREWARM_LIMIT, scope: 'home-live', reason: 'scheduled-interval' }).catch(() => {});
    else queueBunnyPrewarmIfArtworkChanged('new-artwork-detected', { limit: BUNNY_PREWARM_NEW_ARTWORK_LIMIT, scope: 'home-live' });
  }, Math.max(60000, BUNNY_PREWARM_SCAN_INTERVAL_MS));
}

function clearResponseCache(prefix = '') {
  let removed = 0;
  for (const key of [...cdnMemoryCache.keys()]) {
    if (key.startsWith(`response:${prefix}`) || (!prefix && key.startsWith('response:'))) {
      cdnMemoryCache.delete(key);
      removed += 1;
    }
  }
  return removed;
}

function notFound(res, url) {
  return json(res, 404, {
    ok: false,
    error: 'Not found',
    path: url.pathname
  });
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1024 * 1024) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (err) {
        reject(new Error('Invalid JSON body'));
      }
    });
    req.on('error', reject);
  });
}

function getUserId(url, req) {
  return url.searchParams.get('user_id') || url.searchParams.get('userId') || req.headers['x-user-id'] || '';
}

const epgSettings = { refreshEveryHours: Number(process.env.EPG_REFRESH_EVERY_HOURS || 6), durationHours: 12, backgroundDurationHours: Number(process.env.EPG_BACKGROUND_DURATION_HOURS || 48) };
const iconCache = new Map();
function channelIconUrlFor(userId, channelId) {
  const view = getLiveUserView(userId || 'demo');
  const wanted = normalizeKey(channelId);
  const channel = (view.channels || []).find(ch => [ch.id, ch.externalId, ch.name, ch.number].map(normalizeKey).includes(wanted));
  return channel && (channel.logo || channel.icon || channel.image || '');
}
function proxyChannelIcon(res, userId, channelId) {
  const sourceUrl = channelIconUrlFor(userId, channelId);
  if (!sourceUrl) return json(res, 404, { ok: false, error: 'Icon not found' });
  const cached = iconCache.get(sourceUrl);
  if (cached && cached.expiresAt > Date.now()) {
    res.writeHead(200, { 'Content-Type': cached.contentType || 'image/png', 'Cache-Control': 'public, max-age=86400' });
    return res.end(cached.buffer);
  }
  const client = sourceUrl.startsWith('https:') ? require('https') : require('http');
  client.get(sourceUrl, upstream => {
    const chunks = [];
    upstream.on('data', chunk => chunks.push(chunk));
    upstream.on('end', () => {
      const buffer = Buffer.concat(chunks);
      const contentType = upstream.headers['content-type'] || 'image/png';
      if (upstream.statusCode === 200 && buffer.length) iconCache.set(sourceUrl, { buffer, contentType, expiresAt: Date.now() + 24 * 60 * 60 * 1000 });
      res.writeHead(upstream.statusCode || 200, { 'Content-Type': contentType, 'Cache-Control': 'public, max-age=86400' });
      res.end(buffer);
    });
  }).on('error', err => json(res, 502, { ok: false, error: err.message }));
}
const epgJobs = new Map();
function epgProgress(userId) { const key = userId || 'demo'; if (!epgJobs.has(key)) epgJobs.set(key, { ok: true, running: false, userId: key, stage: 'idle', message: 'Guide refresh idle', percent: 0, startedAt: null, finishedAt: null, error: null }); return epgJobs.get(key); }
function setEpgProgress(userId, patch) { const current = epgProgress(userId); Object.assign(current, patch, { userId: userId || 'demo', updatedAt: new Date().toISOString() }); return current; }
function startEpgRefresh(userId, durationHours, force) { const uid = userId || 'demo'; setEpgProgress(uid, { ok: false, running: false, stage: 'disabled', percent: 100, message: 'Live TV guide refresh moved to Android app local provider cache.', finishedAt: new Date().toISOString(), durationHours: Number(durationHours || epgSettings.durationHours || 12) }); return epgProgress(uid); }


function normalizeKey(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '');
}
function programFromNowNext(entry, fallbackTitle) {
  if (!entry) return null;
  const title = entry.title || entry.name || fallbackTitle || 'No information';
  return { title, name: title, description: entry.description || '', start: entry.start || entry.startLabel || '', end: entry.end || entry.endLabel || '', startLabel: entry.start || entry.startLabel || '', endLabel: entry.end || entry.endLabel || '', imageUrl: entry.image || entry.poster || entry.backdrop || '', poster: entry.poster || entry.image || '', backdrop: entry.backdrop || '' };
}
function guidePayloadForRequest(url, userId) {
  const channelId = url.searchParams.get('channel_id') || url.searchParams.get('channelId') || '';
  const channelName = url.searchParams.get('channelName') || url.searchParams.get('name') || '';
  const channelNumber = url.searchParams.get('channelNumber') || url.searchParams.get('number') || '';
  const tvgId = url.searchParams.get('tvgId') || url.searchParams.get('tvg_id') || '';
  const view = getLiveUserView(userId);
  const wanted = [channelId, channelName, channelNumber, tvgId].map(normalizeKey).filter(Boolean);
  let channels = view.channels || [];
  let selected = null;
  if (wanted.length) {
    selected = channels.find(ch => [ch.id, ch.externalId, ch.name, ch.number].map(normalizeKey).some(v => v && wanted.includes(v))) || null;
    channels = selected ? [selected] : [];
  }
  let programs = [];
  if (selected) {
    if (Array.isArray(selected.programs) && selected.programs.length) {
      programs = selected.programs.slice(0, 12);
    } else {
      const now = programFromNowNext(selected.current, selected.name);
      const next = programFromNowNext(selected.next, 'Upcoming');
      if (now) programs.push(now);
      if (next) programs.push(next);
    }
  }
  return { view, channels, selected, programs };
}


function mediaItemsFromHomeRows(typeFilter) {
  const home = loadHomeRows();
  const rails = Array.isArray(home.rails) ? home.rails : [];
  const out = [];
  for (const rail of rails) {
    const items = Array.isArray(rail.items) ? rail.items : [];
    for (const item of items) {
      const type = item.type === "series" || item.streamLookupType === "series" ? "series" : "movie";
      if (typeFilter && type !== typeFilter) continue;
      out.push({
        id: item.id || item.streamLookupId || item.imdbId || item.title,
        externalId: item.imdbId || item.streamLookupId || item.id || "",
        type,
        title: item.title || item.name || "Untitled",
        name: item.title || item.name || "Untitled",
        meta: [item.source || rail.source || "Stremio Catalog", item.year || ""].filter(Boolean).join(" • "),
        overview: item.overview || item.description || "",
        description: item.overview || item.description || "",
        poster: item.poster || item.posterUrl || "",
        posterUrl: item.poster || item.posterUrl || "",
        background: item.backdrop || item.background || item.poster || "",
        backdropUrl: item.backdrop || item.background || item.poster || "",
        logo: item.logo || item.logoUrl || ""
      });
    }
  }
  const seen = new Set();
  return out.filter(item => {
    const key = `${item.type}|${item.externalId || item.title}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function searchMediaItems(query) {
  const q = String(query || '').trim().toLowerCase();
  const all = mediaItemsFromHomeRows(null);
  if (!q) return all.slice(0, 120);
  const tokens = q.split(/\s+/).filter(Boolean);
  return all.map(item => {
    const haystack = `${item.title} ${item.meta} ${item.overview}`.toLowerCase();
    const score = tokens.reduce((acc, token) => acc + (haystack.includes(token) ? 1 : 0), 0) + (item.title.toLowerCase().includes(q) ? 5 : 0);
    return { item, score };
  }).filter(x => x.score > 0).sort((a, b) => b.score - a.score).map(x => x.item).slice(0, 120);
}


// -----------------------------------------------------------------------------
// Instant Home Pipeline additions for Android app v2.8.26.7
// Backend prepares a tiny hero-first payload and a ready-to-render home payload.
// The app can paint cached rows instantly, then refresh from these endpoints in
// the background without rebuilding rows from multiple external addon sources.
// -----------------------------------------------------------------------------
const INSTANT_HOME_VERSION = 'backend_v1.8.13_HERO_CUTOUT_PATH_INIT_FIX';
const INSTANT_HOME_TTL_MS = Number(process.env.INSTANT_HOME_TTL_MS || 5 * 60 * 1000);
const INSTANT_HERO_TTL_MS = Number(process.env.INSTANT_HERO_TTL_MS || 2 * 60 * 1000);
const INSTANT_HOME_ROW_LIMIT = Number(process.env.INSTANT_HOME_ROW_LIMIT || 12);
const INSTANT_HOME_ITEM_LIMIT = Number(process.env.INSTANT_HOME_ITEM_LIMIT || 50);
const INSTANT_HOME_PREWARM_LIMIT = Number(process.env.INSTANT_HOME_PREWARM_LIMIT || 24);
const INSTANT_HOME_TRAILER_PREWARM_LIMIT = Number(process.env.INSTANT_HOME_TRAILER_PREWARM_LIMIT || 8);

const HERO_ASSET_CACHE_DIR = path.join(DATA_DIR, 'hero-assets');
function ensureHeroAssetCacheDir() {
  try { fs.mkdirSync(HERO_ASSET_CACHE_DIR, { recursive: true }); } catch (_) {}
}
function safeAssetId(item = {}) {
  return String(firstNonEmpty(item.externalId, item.imdbId, item.tmdbId, item.id, item.title, 'hero'))
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'hero';
}
function heroAssetEnvelope(item = {}, proxy = true) {
  // v1.8.13: app-facing contract for the real future 3D hero pipeline.
  // If upstream catalog already provides a transparent foreground cutout, pass it through.
  // If not, leave hero_foreground_cutout blank so Android falls back safely instead of
  // boosting a whole backdrop as a fake cutout.
  const id = safeAssetId(item);
  const backdrop = firstNonEmpty(item.hero_backdrop, item.heroBackdropUrl, item.backdropUrl, item.backdrop, item.background, item.posterUrl, item.poster);
  const foreground = firstNonEmpty(item.hero_foreground_cutout, item.heroForegroundCutoutUrl, item.foregroundCutoutUrl, item.foregroundCutout, item.cutoutUrl, item.cutout);
  const palette = {
    id,
    dominant: firstNonEmpty(item.dominantColor, item.paletteColor, '#101418'),
    accent: firstNonEmpty(item.accentColor, '#F5C84C'),
    ambient: firstNonEmpty(item.ambientColor, '#090B10'),
    mode: 'backend-cache-ready'
  };
  const maskQuality = {
    id,
    available: !!foreground,
    source: foreground ? 'catalog-provided-transparent-cutout' : 'missing-cutout-fallback-safe',
    confidence: foreground ? 0.92 : 0.0,
    recommendation: foreground ? 'render-transparent-foreground' : 'use-backdrop-fallback-no-fake-opacity-pop'
  };
  return {
    hero_backdrop: backdrop,
    heroBackdropUrl: backdrop,
    hero_foreground_cutout: foreground,
    heroForegroundCutoutUrl: foreground,
    hero_palette: `/api/artwork/hero-assets/${encodeURIComponent(id)}/palette.json`,
    heroPaletteUrl: `/api/artwork/hero-assets/${encodeURIComponent(id)}/palette.json`,
    hero_mask_quality: `/api/artwork/hero-assets/${encodeURIComponent(id)}/mask-quality.json`,
    heroMaskQualityUrl: `/api/artwork/hero-assets/${encodeURIComponent(id)}/mask-quality.json`,
    heroAssets: {
      id,
      backdrop,
      foregroundCutout: foreground,
      palette,
      maskQuality,
      cacheLocal: true,
      cdnReady: true,
      formatPreference: 'webp-transparent-for-cutout'
    }
  };
}
function writeHeroAssetSidecars(item = {}) {
  ensureHeroAssetCacheDir();
  const id = safeAssetId(item);
  const envelope = heroAssetEnvelope(item, false);
  try { fs.writeFileSync(path.join(HERO_ASSET_CACHE_DIR, `${id}.palette.json`), JSON.stringify(envelope.heroAssets.palette, null, 2)); } catch (_) {}
  try { fs.writeFileSync(path.join(HERO_ASSET_CACHE_DIR, `${id}.mask-quality.json`), JSON.stringify(envelope.heroAssets.maskQuality, null, 2)); } catch (_) {}
  return envelope;
}

function firstNonEmpty(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && String(value).trim()) return value;
  }
  return '';
}

function yearFromItem(item) {
  const raw = firstNonEmpty(item.year, item.releaseYear, item.released, item.releaseDate, item.premiered, item.meta);
  const match = String(raw || '').match(/(19|20)\d{2}/);
  return match ? match[0] : '';
}


function buildTmdbImageUrl(path, size = 'original') {
  if (!path) return '';
  const clean = String(path).startsWith('/') ? String(path) : `/${path}`;
  return `https://image.tmdb.org/t/p/${size}${clean}`;
}

function bestLandscapeArtwork(item = {}) {
  // Rows must not reuse the hero backdrop as the first card source. Prefer real
  // row-card/still/landscape sources from Fanart.tv, TMDB, TVDB, IMDb-style
  // promo fields, Stremio thumbnails, or provider-provided card images.
  return firstNonEmpty(
    item.landscapeCard4k,
    item.landscapeCardUrl,
    item.rowLandscape4k,
    item.rowLandscapeUrl,
    item.cardLandscape4k,
    item.cardLandscapeUrl,
    item.cardStill4k,
    item.cardStillUrl,
    item.promoStill4k,
    item.promoStillUrl,
    item.imdbStillUrl,
    item.tmdbStillUrl,
    item.fanartLandscape4k,
    item.fanartLandscapeUrl,
    item.fanartTvThumb,
    item.tvdbBackgroundUrl,
    item.tvdbStillUrl,
    item.thumbnail4k,
    item.thumbnailUrl,
    item.thumbnail,
    item.cardImage4k,
    item.cardImageUrl,
    item.imageUrl
  );
}


function readArtworkPoolCache() {
  try { return JSON.parse(fs.readFileSync(ARTWORK_POOL_CACHE_FILE, 'utf8')); } catch { return { generatedAt: null, entries: {} }; }
}

function writeArtworkPoolCache(value) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(ARTWORK_POOL_CACHE_FILE, JSON.stringify(value, null, 2));
  } catch {}
}

function asArray(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  return [value];
}

function addArtworkVariant(target, bucket, url, source = 'metadata', width = 0, height = 0) {
  const clean = firstNonEmpty(url, '');
  if (!clean || !isAllowedProxyUrl(clean)) return;
  if (!target[bucket]) target[bucket] = [];
  if (target[bucket].some(v => v.url === clean)) return;
  target[bucket].push({ url: clean, source, width: Number(width || 0), height: Number(height || 0) });
}

function addArtworkVariants(target, bucket, values, source = 'metadata') {
  for (const value of asArray(values)) {
    if (!value) continue;
    if (typeof value === 'string') addArtworkVariant(target, bucket, value, source);
    else if (typeof value === 'object') addArtworkVariant(target, bucket, value.url || value.file || value.href || value.image || value.src, value.source || source, value.width, value.height);
  }
}

function makeEmptyArtworkPool() {
  return { posters: [], backdrops: [], logos: [], clearlogos: [], landscape: [], banners: [], stills: [], programArt: [], channelLogos: [], previewImages: [] };
}

function collectMetadataArtworkPool(item = {}, poster = '', backdrop = '', logo = '') {
  const pool = makeEmptyArtworkPool();
  addArtworkVariant(pool, 'posters', poster, 'provider');
  addArtworkVariants(pool, 'posters', [item.poster, item.posterUrl, item.poster4k, item.cardPosterUrl, item.cardPoster4k, item.image, item.icon], 'provider');
  addArtworkVariant(pool, 'backdrops', backdrop, 'provider');
  addArtworkVariants(pool, 'backdrops', [item.backdrop, item.backdropUrl, item.background, item.fanart, item.heroBackdropUrl, item.hero_backdrop], 'provider');
  addArtworkVariant(pool, 'logos', logo, 'provider');
  addArtworkVariants(pool, 'logos', [item.logo, item.logoUrl, item.clearLogo, item.titleLogo], 'provider');
  addArtworkVariants(pool, 'clearlogos', [item.clearLogo, item.logo, item.logoUrl, item.titleLogo], 'provider');
  addArtworkVariants(pool, 'landscape', [
    item.landscapeCard4k, item.landscapeCardUrl, item.rowLandscape4k, item.rowLandscapeUrl,
    item.cardLandscape4k, item.cardLandscapeUrl, item.cardStill4k, item.cardStillUrl,
    item.promoStill4k, item.promoStillUrl, item.imdbStillUrl, item.tmdbStillUrl,
    item.fanartLandscape4k, item.fanartLandscapeUrl, item.fanartTvThumb,
    item.tvdbBackgroundUrl, item.tvdbStillUrl, item.thumbnail4k, item.thumbnailUrl,
    item.thumbnail, item.cardImage4k, item.cardImageUrl, item.imageUrl
  ], 'provider');
  addArtworkVariants(pool, 'banners', [item.banner, item.bannerUrl, item.fanartBannerUrl, item.tvdbBannerUrl], 'provider');
  addArtworkVariants(pool, 'stills', [item.still, item.stillUrl, item.episodeStill, item.cardStillUrl, item.tvdbStillUrl, item.tmdbStillUrl, item.imdbStillUrl], 'provider');
  addArtworkVariants(pool, 'programArt', [item.programArt, item.programArtUrl, item.gracenoteImage, item.guideImage, item.previewImage, item.imageUrl], 'provider-live');
  addArtworkVariants(pool, 'channelLogos', [item.channelLogo, item.channelLogoUrl, item.tvgLogo, item.logo, item.icon], 'provider-live');
  addArtworkVariants(pool, 'previewImages', [item.previewImage, item.previewImageUrl, item.stillUrl, item.cardStillUrl, item.backdropUrl], 'provider');

  if (item.artworkPool && typeof item.artworkPool === 'object') {
    for (const [bucket, values] of Object.entries(item.artworkPool)) {
      if (pool[bucket]) addArtworkVariants(pool, bucket, values, 'upstream-pool');
    }
  }
  return pool;
}

function bucketSeed(id, bucket) {
  const period = Math.floor(Date.now() / (ARTWORK_RANDOM_STICKY_HOURS * 60 * 60 * 1000));
  return crypto.createHash('sha1').update(`${id}|${bucket}|${period}`).digest()[0];
}

function pickArtworkVariant(id, bucket, variants) {
  if (!Array.isArray(variants) || !variants.length) return '';
  if (!ARTWORK_RANDOMIZE_ENABLED || variants.length === 1) return variants[0].url;
  return variants[bucketSeed(id, bucket) % variants.length].url;
}

function selectArtworkFromPool(id, pool) {
  return {
    poster: pickArtworkVariant(id, 'posters', pool.posters),
    backdrop: pickArtworkVariant(id, 'backdrops', pool.backdrops),
    logo: pickArtworkVariant(id, 'logos', pool.logos),
    clearlogo: pickArtworkVariant(id, 'clearlogos', pool.clearlogos),
    landscape: pickArtworkVariant(id, 'landscape', pool.landscape),
    banner: pickArtworkVariant(id, 'banners', pool.banners),
    still: pickArtworkVariant(id, 'stills', pool.stills),
    programArt: pickArtworkVariant(id, 'programArt', pool.programArt),
    channelLogo: pickArtworkVariant(id, 'channelLogos', pool.channelLogos),
    previewImage: pickArtworkVariant(id, 'previewImages', pool.previewImages)
  };
}

function mergeArtworkPools(...pools) {
  const out = makeEmptyArtworkPool();
  for (const pool of pools) {
    if (!pool || typeof pool !== 'object') continue;
    for (const bucket of Object.keys(out)) addArtworkVariants(out, bucket, pool[bucket] || [], 'merged');
  }
  return out;
}

function proxiedArtworkPool(pool) {
  const out = makeEmptyArtworkPool();
  for (const bucket of Object.keys(out)) {
    out[bucket] = (pool[bucket] || []).map(v => ({ ...v, url: proxiedImageUrl(v.url) }));
  }
  return out;
}

function artworkPoolStats(pool) {
  const stats = {};
  for (const bucket of Object.keys(pool || {})) stats[bucket] = Array.isArray(pool[bucket]) ? pool[bucket].length : 0;
  return stats;
}

async function resolveTmdbArtwork({ imdbId = '', tmdbId = '', type = 'movie' } = {}) {
  const pool = makeEmptyArtworkPool();
  const { tmdbApiKey } = artworkProviderKeys();
  if (!tmdbApiKey) return pool;
  let mediaType = type === 'series' || type === 'tv' || type === 'show' ? 'tv' : 'movie';
  let id = tmdbId;
  if (!id && imdbId) {
    try {
      const findUrl = `https://api.themoviedb.org/3/find/${encodeURIComponent(imdbId)}?api_key=${encodeURIComponent(tmdbApiKey)}&external_source=imdb_id`;
      const found = await fetchJsonWithTimeout(findUrl, ARTWORK_PROVIDER_TIMEOUT_MS);
      const list = mediaType === 'tv' ? found.tv_results : found.movie_results;
      const first = Array.isArray(list) ? list[0] : null;
      if (first && first.id) id = String(first.id);
    } catch {}
  }
  if (!id) return pool;
  try {
    const imagesUrl = `https://api.themoviedb.org/3/${mediaType}/${encodeURIComponent(id)}/images?api_key=${encodeURIComponent(tmdbApiKey)}&include_image_language=en,null`;
    const images = await fetchJsonWithTimeout(imagesUrl, ARTWORK_PROVIDER_TIMEOUT_MS);
    for (const p of images.posters || []) addArtworkVariant(pool, 'posters', buildTmdbImageUrl(p.file_path), 'tmdb', p.width, p.height);
    for (const b of images.backdrops || []) {
      addArtworkVariant(pool, 'backdrops', buildTmdbImageUrl(b.file_path), 'tmdb', b.width, b.height);
      addArtworkVariant(pool, 'landscape', buildTmdbImageUrl(b.file_path), 'tmdb', b.width, b.height);
    }
    for (const l of images.logos || []) addArtworkVariant(pool, 'logos', buildTmdbImageUrl(l.file_path), 'tmdb', l.width, l.height);
    for (const l of images.logos || []) addArtworkVariant(pool, 'clearlogos', buildTmdbImageUrl(l.file_path), 'tmdb', l.width, l.height);
  } catch {}
  return pool;
}

async function resolveFanartArtwork({ tmdbId = '', tvdbId = '', type = 'movie' } = {}) {
  const pool = makeEmptyArtworkPool();
  const { fanartTvApiKey } = artworkProviderKeys();
  if (!fanartTvApiKey) return pool;
  const isTv = type === 'series' || type === 'tv' || type === 'show';
  const id = isTv ? tvdbId : tmdbId;
  if (!id) return pool;
  const endpoint = isTv ? `https://webservice.fanart.tv/v3/tv/${encodeURIComponent(id)}` : `https://webservice.fanart.tv/v3/movies/${encodeURIComponent(id)}`;
  try {
    const data = await fetchJsonWithTimeout(`${endpoint}?api_key=${encodeURIComponent(fanartTvApiKey)}`, ARTWORK_PROVIDER_TIMEOUT_MS);
    const mappings = [
      ['movieposter', 'posters'], ['tvposter', 'posters'], ['hdmovieclearart', 'logos'], ['hdclearart', 'logos'],
      ['movielogo', 'logos'], ['hdtvlogo', 'logos'], ['clearlogo', 'logos'], ['moviebackground', 'backdrops'],
      ['showbackground', 'backdrops'], ['moviethumb', 'landscape'], ['tvthumb', 'landscape'], ['moviebanner', 'banners'], ['tvbanner', 'banners']
    ];
    for (const [key, bucket] of mappings) {
      for (const entry of data[key] || []) addArtworkVariant(pool, bucket, entry.url, 'fanart.tv');
    }
  } catch {}
  return pool;
}

async function resolveTvdbArtwork({ tvdbId = '' } = {}) {
  const pool = makeEmptyArtworkPool();
  const { tvdbApiToken } = artworkProviderKeys();
  if (!tvdbApiToken || !tvdbId) return pool;
  try {
    const data = await fetchJsonWithTimeout(`https://api4.thetvdb.com/v4/series/${encodeURIComponent(tvdbId)}/artworks`, ARTWORK_PROVIDER_TIMEOUT_MS, { authorization: `Bearer ${tvdbApiToken}` });
    const artworks = Array.isArray(data?.data?.artworks) ? data.data.artworks : [];
    for (const art of artworks) {
      const url = art.image || art.thumbnail || '';
      const type = String(art.type || art.typeName || '').toLowerCase();
      if (type.includes('poster')) addArtworkVariant(pool, 'posters', url, 'tvdb');
      else if (type.includes('banner')) addArtworkVariant(pool, 'banners', url, 'tvdb');
      else if (type.includes('background') || type.includes('fanart')) {
        addArtworkVariant(pool, 'backdrops', url, 'tvdb');
        addArtworkVariant(pool, 'landscape', url, 'tvdb');
      } else if (type.includes('clear') || type.includes('logo')) addArtworkVariant(pool, 'logos', url, 'tvdb');
      else addArtworkVariant(pool, 'stills', url, 'tvdb');
    }
  } catch {}
  return pool;
}

async function fetchJsonWithTimeout(targetUrl, timeoutMs = 9000, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(targetUrl, { headers: { 'user-agent': 'Debrid-Channels-Backend/1.8.14', accept: 'application/json', ...headers }, signal: controller.signal });
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
    return await res.json();
  } finally { clearTimeout(timer); }
}

async function resolveExternalArtworkPool(query = {}) {
  const key = sha256(JSON.stringify({ imdbId: query.imdbId || '', tmdbId: query.tmdbId || '', tvdbId: query.tvdbId || '', type: query.type || 'movie' }));
  const cache = readArtworkPoolCache();
  const ttlMs = Number(process.env.ARTWORK_POOL_CACHE_TTL_MS || 7 * 24 * 60 * 60 * 1000);
  const existing = cache.entries && cache.entries[key];
  if (existing && existing.expiresAt > Date.now()) return existing.pool;
  const [tmdb, fanart, tvdb] = await Promise.all([
    resolveTmdbArtwork(query),
    resolveFanartArtwork(query),
    resolveTvdbArtwork(query)
  ]);
  const pool = mergeArtworkPools(tmdb, fanart, tvdb);
  cache.entries = cache.entries || {};
  cache.entries[key] = { key, query, pool, generatedAt: new Date().toISOString(), expiresAt: Date.now() + ttlMs };
  cache.generatedAt = new Date().toISOString();
  writeArtworkPoolCache(cache);
  return pool;
}

function enrichArtworkContract(item = {}, poster = '', backdrop = '', logo = '') {
  const id = firstNonEmpty(item.id, item.externalId, item.imdbId, item.tmdbId, item.title, item.name, 'artwork');
  const metadataPool = collectMetadataArtworkPool(item, poster, backdrop, logo);
  const selected = selectArtworkFromPool(id, metadataPool);
  const rowCard = firstNonEmpty(selected.landscape, bestLandscapeArtwork(item));
  const payload = {
    rowCardUrl: rowCard,
    landscapeCardUrl: rowCard,
    landscapeCard4k: rowCard,
    rowLandscapeUrl: rowCard,
    rowLandscape4k: rowCard,
    cardStillUrl: firstNonEmpty(selected.still, item.cardStillUrl, item.tmdbStillUrl, item.imdbStillUrl, item.promoStillUrl, rowCard),
    promoStillUrl: firstNonEmpty(item.promoStillUrl, item.imdbStillUrl, item.tmdbStillUrl, rowCard),
    fanartLandscapeUrl: firstNonEmpty(item.fanartLandscapeUrl, item.fanartTvThumb, ''),
    tvdbBackgroundUrl: firstNonEmpty(item.tvdbBackgroundUrl, item.tvdbStillUrl, ''),
    poster4k: firstNonEmpty(selected.poster, item.poster4k, poster),
    cleanPosterUrl: firstNonEmpty(selected.poster, poster),
    clearLogo: firstNonEmpty(selected.clearlogo, selected.logo, logo),
    bannerUrl: selected.banner,
    previewImageUrl: selected.previewImage,
    programArtUrl: selected.programArt,
    channelLogoUrl: selected.channelLogo,
    artworkPool: metadataPool,
    artworkPoolStats: artworkPoolStats(metadataPool),
    selectedArtwork: selected,
    artworkRandomize: {
      enabled: ARTWORK_RANDOMIZE_ENABLED,
      stickyHours: ARTWORK_RANDOM_STICKY_HOURS,
      note: 'Selections are stable for the sticky window so artwork does not flicker while scrolling.'
    },
    artworkSources: {
      tmdb: !!(item.tmdbStillUrl || item.tmdbId || TMDB_API_KEY),
      fanarttv: !!(item.fanartLandscapeUrl || item.fanartTvThumb || FANART_TV_API_KEY),
      tvdb: !!(item.tvdbBackgroundUrl || item.tvdbStillUrl || item.tvdbId || TVDB_API_TOKEN),
      imdbPromo: !!item.imdbStillUrl,
      provider: Object.values(artworkPoolStats(metadataPool)).some(Boolean),
      externalResolveEndpoint: '/api/artwork/resolve?imdbId=&tmdbId=&tvdbId=&type=',
      note: 'Apps can use selectedArtwork for a stable randomized pick or artworkPool arrays for rotation.'
    }
  };
  payload.heroFallbackUrl = firstNonEmpty(selected.backdrop, backdrop);
  return payload;
}

function normalizeInstantItem(item = {}, rail = {}, index = 0) {
  const type = item.type === 'series' || item.type === 'show' || item.streamLookupType === 'series' ? 'series' : 'movie';
  const title = firstNonEmpty(item.title, item.name, item.label, 'Untitled');
  const id = firstNonEmpty(item.id, item.streamLookupId, item.imdbId, item.tmdbId, `${type}:${title}`);
  const imdbId = firstNonEmpty(item.imdbId, item.imdb, String(id).startsWith('tt') ? id : '');
  const tmdbId = firstNonEmpty(item.tmdbId, item.tmdb, '');
  const poster = firstNonEmpty(item.poster4k, item.posterUrl, item.poster, item.cardPoster4k, item.cardPosterUrl, item.image, item.icon);
  const backdrop = firstNonEmpty(item.backdrop, item.backdropUrl, item.background, item.fanart, poster);
  const logo = firstNonEmpty(item.logo, item.logoUrl, item.clearLogo, item.titleLogo);
  const artworkContract = enrichArtworkContract(item, poster, backdrop, logo);
  const posterLogoSource = firstNonEmpty(artworkContract.landscapeCardUrl, poster);
  const posterLogoUrl = firstNonEmpty(item.posterLogo4k, item.posterLogoUrl, item.posterWithLogoUrl, item.bakedPosterLogoUrl, item.cardPosterLogoUrl) || posterLogoCompositeUrl(posterLogoSource, logo, id);
  const overview = firstNonEmpty(item.overview, item.description, item.plot, '');
  const year = yearFromItem(item);
  const genres = Array.isArray(item.genres) ? item.genres : String(firstNonEmpty(item.genre, item.genresText, '')).split(/[•,|]/).map(v => v.trim()).filter(Boolean);
  const rating = firstNonEmpty(item.imdbRating, item.rating, item.voteAverage, item.score);
  const tmdbRating = firstNonEmpty(item.tmdbRating, item.tmdbScore, '');
  const trailerUrl = firstNonEmpty(item.trailerUrl, item.trailer, item.youtubeTrailer, item.previewUrl);
  return {
    id,
    externalId: firstNonEmpty(item.externalId, imdbId, item.streamLookupId, id),
    imdbId,
    tmdbId,
    type,
    title,
    name: title,
    year,
    genres,
    genre: genres[0] || '',
    meta: firstNonEmpty(item.meta, [year, ...genres.slice(0, 2), rating ? `IMDb ${rating}` : ''].filter(Boolean).join('  •  ')),
    overview,
    description: overview,
    poster,
    posterUrl: poster,
    ...artworkContract,
    posterLogoUrl,
    posterLogo4k: posterLogoUrl,
    posterWithLogoUrl: posterLogoUrl,
    backdrop,
    backdropUrl: backdrop,
    background: backdrop,
    logo,
    logoUrl: logo,
    rating,
    imdbRating: rating,
    tmdbRating,
    source: firstNonEmpty(item.source, rail.source, rail.title, 'Backend Catalog'),
    rowIndex: rail.rowIndex || 0,
    index,
    trailerUrl,
    trailer: trailerUrl ? { playbackUrl: trailerUrl, source: 'item-provided' } : null,
    ...writeHeroAssetSidecars({ ...item, id, externalId: firstNonEmpty(item.externalId, imdbId, item.streamLookupId, id), imdbId, tmdbId, title, posterUrl: poster, backdropUrl: backdrop }),
    cacheHints: {
      hero4k: true,
      artworkProxy: true,
      preloadPriority: index < 8 ? 'visible-window' : 'background'
    }
  };
}

function normalizeInstantRail(rail = {}, rowIndex = 0) {
  const items = Array.isArray(rail.items) ? rail.items.slice(0, INSTANT_HOME_ITEM_LIMIT) : [];
  return {
    id: firstNonEmpty(rail.id, rail.key, rail.title, `row-${rowIndex}`),
    key: firstNonEmpty(rail.key, rail.id, rail.title, `row-${rowIndex}`),
    title: firstNonEmpty(rail.title, rail.name, `Row ${rowIndex + 1}`),
    source: firstNonEmpty(rail.source, rail.provider, 'Backend Catalog'),
    rowIndex,
    items: items.map((item, index) => normalizeInstantItem(item, { ...rail, rowIndex }, index))
  };
}

function buildInstantHomePayload(options = {}) {
  const proxy = options.proxyImages !== false;
  const home = loadHomeRows();
  const rails = (Array.isArray(home.rails) ? home.rails : [])
    .slice(0, INSTANT_HOME_ROW_LIMIT)
    .map(normalizeInstantRail)
    .filter(rail => rail.items.length);
  const hero = rails[0] && rails[0].items[0] ? rails[0].items[0] : null;
  const payload = {
    ok: true,
    version: INSTANT_HOME_VERSION,
    pipeline: 'instant-home-v2.8.26.39-hero-cutout-assets-v1.8.13',
    generatedAt: home.generatedAt || new Date().toISOString(),
    source: home.source || 'backend-ready-home',
    staleWhileRefresh: true,
    hero,
    rails,
    cachePolicy: {
      jsonMaxAgeSeconds: ANDROID_JSON_MAX_AGE_SECONDS,
      staleWhileRevalidateSeconds: 3600,
      heroArtwork: '4k-preferred',
      imageProxy: proxy,
      prewarmVisibleWindowOnly: true
    }
  };
  return rewriteImagesDeep(payload, proxy);
}

function buildInstantHeroPayload(options = {}) {
  const home = buildInstantHomePayload(options);
  const hero = home.hero || ((home.rails[0] && home.rails[0].items[0]) ? home.rails[0].items[0] : null);
  return {
    ok: true,
    version: INSTANT_HOME_VERSION,
    pipeline: 'hero-first-v2.8.26.39-hero-cutout-assets',
    generatedAt: home.generatedAt,
    hero,
    cachePolicy: {
      jsonMaxAgeSeconds: 120,
      heroArtwork: '4k-preferred',
      imageProxy: options.proxyImages !== false
    }
  };
}

async function prewarmInstantHomeAssets(payload) {
  // Non-blocking: only warm hero and visible-window art/trailers, never the full catalog burst.
  const rails = Array.isArray(payload.rails) ? payload.rails : [];
  const visibleItems = [];
  for (const rail of rails.slice(0, 4)) {
    for (const item of (rail.items || []).slice(0, 6)) visibleItems.push(item);
  }
  const artworkPayload = { rails: rails.slice(0, 4).map(rail => ({ ...rail, items: (rail.items || []).slice(0, 6) })) };
  prewarmImagesFromPayload(artworkPayload, INSTANT_HOME_PREWARM_LIMIT).catch(() => {});
  let queuedTrailers = 0;
  for (const item of visibleItems.slice(0, INSTANT_HOME_TRAILER_PREWARM_LIMIT)) {
    if (!item || !item.title) continue;
    queuedTrailers += 1;
    resolveTrailer({
      title: item.title,
      year: item.year || '',
      prefer4k: false,
      mediaId: item.id || item.externalId || item.imdbId || item.title,
      mediaType: item.type || 'movie'
    }).catch(() => {});
  }
  return { artworkQueuedLimit: INSTANT_HOME_PREWARM_LIMIT, trailersQueued: queuedTrailers };
}


// -----------------------------------------------------------------------------
// CDN/cache additions for v1.8.3
// Non-destructive: all original v1.8.2 routes remain active. These helpers add
// image proxying and addon passthrough/caching without replacing trailer routes.
// -----------------------------------------------------------------------------
const CDN_CACHE_DIR = path.join(__dirname, 'data', 'cdn-cache');
const CDN_IMAGE_DIR = path.join(CDN_CACHE_DIR, 'images');
const cdnMemoryCache = new Map();
const CDN_JSON_TTL_MS = Number(process.env.CDN_JSON_TTL_MS || 10 * 60 * 1000);
const CDN_IMAGE_TTL_MS = Number(process.env.CDN_IMAGE_TTL_MS || 30 * 24 * 60 * 60 * 1000);
const CDN_FETCH_TIMEOUT_MS = Number(process.env.CDN_FETCH_TIMEOUT_MS || 15000);
const CDN_MAX_IMAGE_BYTES = Number(process.env.CDN_MAX_IMAGE_BYTES || 20 * 1024 * 1024);
const ANDROID_HOME_TTL_MS = Number(process.env.ANDROID_HOME_TTL_MS || 5 * 60 * 1000);
const ANDROID_CATALOG_TTL_MS = Number(process.env.ANDROID_CATALOG_TTL_MS || 10 * 60 * 1000);
const ANDROID_SEARCH_TTL_MS = Number(process.env.ANDROID_SEARCH_TTL_MS || 2 * 60 * 1000);
const ANDROID_JSON_MAX_AGE_SECONDS = Number(process.env.ANDROID_JSON_MAX_AGE_SECONDS || 300);
const PROXY_IMAGES_BY_DEFAULT = String(process.env.PROXY_IMAGES_BY_DEFAULT || '1') !== '0';

function ensureCdnDirs() {
  fs.mkdirSync(CDN_IMAGE_DIR, { recursive: true });
}

function sha256(value) {
  return crypto.createHash('sha256').update(String(value || '')).digest('hex');
}

function safeExtFromContentType(contentType, sourceUrl) {
  const lower = String(contentType || '').toLowerCase();
  if (lower.includes('image/png')) return '.png';
  if (lower.includes('image/webp')) return '.webp';
  if (lower.includes('image/gif')) return '.gif';
  if (lower.includes('image/svg')) return '.svg';
  const pathname = (() => { try { return new URL(sourceUrl).pathname.toLowerCase(); } catch { return ''; } })();
  if (pathname.endsWith('.png')) return '.png';
  if (pathname.endsWith('.webp')) return '.webp';
  if (pathname.endsWith('.gif')) return '.gif';
  if (pathname.endsWith('.svg')) return '.svg';
  return '.jpg';
}

function cacheGet(key) {
  const hit = cdnMemoryCache.get(key);
  if (!hit) return null;
  if (hit.expiresAt && hit.expiresAt < Date.now()) {
    cdnMemoryCache.delete(key);
    return null;
  }
  return hit.value;
}

function cacheSet(key, value, ttlMs) {
  cdnMemoryCache.set(key, { value, expiresAt: Date.now() + ttlMs });
  return value;
}

function setCdnHeaders(res, contentType, maxAgeSeconds) {
  res.setHeader('Content-Type', contentType);
  res.setHeader('Cache-Control', `public, max-age=${maxAgeSeconds}, stale-while-revalidate=86400`);
  res.setHeader('X-Debrid-Channels-Cache', 'cdn-ready');
}

function isAllowedProxyUrl(value) {
  try {
    const parsed = new URL(String(value || ''));
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

async function fetchWithTimeout(resourceUrl, timeoutMs = CDN_FETCH_TIMEOUT_MS, headers = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(resourceUrl, {
      signal: controller.signal,
      headers: {
        'user-agent': 'Debrid-Channels-Backend/1.8.3 CDN Proxy',
        ...headers
      }
    });
  } finally {
    clearTimeout(timer);
  }
}

async function handleCdnImageProxy(req, res, url) {
  const sourceUrl = (url.searchParams.get('url') || url.searchParams.get('src') || '').trim();
  if (!isAllowedProxyUrl(sourceUrl)) return json(res, 400, { ok: false, error: 'Valid image url is required' });
  ensureCdnDirs();
  const key = sha256(sourceUrl);
  const metaPath = path.join(CDN_IMAGE_DIR, `${key}.json`);
  try {
    const existingMeta = fs.existsSync(metaPath) ? JSON.parse(fs.readFileSync(metaPath, 'utf8')) : null;
    if (existingMeta && existingMeta.file && existingMeta.expiresAt > Date.now() && fs.existsSync(existingMeta.file)) {
      setCdnHeaders(res, existingMeta.contentType || 'image/jpeg', Math.floor(CDN_IMAGE_TTL_MS / 1000));
      res.setHeader('X-Debrid-Channels-Image-Cache', 'hit');
      return fs.createReadStream(existingMeta.file).pipe(res);
    }
  } catch {}

  const upstream = await fetchWithTimeout(sourceUrl, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' });
  if (!upstream.ok) return json(res, upstream.status || 502, { ok: false, error: `Image upstream failed: ${upstream.status} ${upstream.statusText}` });
  const contentType = upstream.headers.get('content-type') || 'image/jpeg';
  if (!String(contentType).toLowerCase().startsWith('image/')) return json(res, 415, { ok: false, error: `Upstream is not an image: ${contentType}` });
  const arrayBuffer = await upstream.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  if (buffer.length > CDN_MAX_IMAGE_BYTES) return json(res, 413, { ok: false, error: 'Image too large for proxy cache' });
  const ext = safeExtFromContentType(contentType, sourceUrl);
  const filePath = path.join(CDN_IMAGE_DIR, `${key}${ext}`);
  fs.writeFileSync(filePath, buffer);
  fs.writeFileSync(metaPath, JSON.stringify({ sourceUrl, file: filePath, contentType, bytes: buffer.length, cachedAt: Date.now(), expiresAt: Date.now() + CDN_IMAGE_TTL_MS }, null, 2));
  setCdnHeaders(res, contentType, Math.floor(CDN_IMAGE_TTL_MS / 1000));
  res.setHeader('X-Debrid-Channels-Image-Cache', 'miss');
  return res.end(buffer);
}

function addonBaseFromManifest(manifestUrl) {
  return String(manifestUrl || '').replace(/\/manifest\.json(?:\?.*)?$/i, '');
}

async function cachedJsonFetch(cacheKey, targetUrl, ttlMs = CDN_JSON_TTL_MS) {
  const hit = cacheGet(cacheKey);
  if (hit) return { fromCache: true, value: hit };
  const upstream = await fetchWithTimeout(targetUrl, CDN_FETCH_TIMEOUT_MS, { accept: 'application/json' });
  if (!upstream.ok) throw new Error(`${upstream.status} ${upstream.statusText}`);
  const value = await upstream.json();
  cacheSet(cacheKey, value, ttlMs);
  return { fromCache: false, value };
}

function detectStreamProvider(name, sourceUrl = '') {
  const haystack = `${name || ''} ${sourceUrl || ''}`.toLowerCase();
  if (haystack.includes('mediafusion')) return 'MediaFusion';
  if (haystack.includes('torbox')) return 'Torbox';
  if (haystack.includes('torrentio')) return 'Torrentio';
  if (haystack.includes('comet')) return 'Comet';
  if (haystack.includes('jackett')) return 'Jackett';
  return 'Other';
}

function detectQuality(name) {
  const value = String(name || '').toLowerCase();
  if (/2160|4k|uhd/.test(value)) return '4K';
  if (/1080/.test(value)) return '1080p';
  if (/720/.test(value)) return '720p';
  if (/480/.test(value)) return '480p';
  return 'Unknown';
}

function normalizeStreamsPayload(payload, manifestUrl) {
  const streams = Array.isArray(payload && payload.streams) ? payload.streams : [];
  return {
    ok: true,
    providerTagged: true,
    sourceManifest: manifestUrl,
    streams: streams.map((stream, index) => ({
      ...stream,
      index,
      provider: stream.provider || detectStreamProvider(stream.name || stream.title || stream.description, manifestUrl),
      quality: stream.quality || detectQuality(`${stream.name || ''} ${stream.title || ''} ${stream.description || ''}`)
    }))
  };
}

async function handleAddonProxy(req, res, url) {
  const manifestUrl = (url.searchParams.get('manifestUrl') || url.searchParams.get('manifest') || url.searchParams.get('url') || '').trim();
  if (!isAllowedProxyUrl(manifestUrl)) return json(res, 400, { ok: false, error: 'manifestUrl is required' });
  const type = (url.searchParams.get('type') || 'movie').trim();
  const id = (url.searchParams.get('id') || '').trim();
  const extra = (url.searchParams.get('extra') || '').trim();
  const base = addonBaseFromManifest(manifestUrl);
  let targetUrl = manifestUrl;
  let ttl = CDN_JSON_TTL_MS;
  if (url.pathname.includes('/catalog')) {
    if (!id) return json(res, 400, { ok: false, error: 'id is required for catalog proxy' });
    targetUrl = `${base}/catalog/${encodeURIComponent(type)}/${encodeURIComponent(id)}${extra ? '/' + extra : ''}.json`;
    ttl = Number(process.env.CDN_CATALOG_TTL_MS || 30 * 60 * 1000);
  } else if (url.pathname.includes('/meta')) {
    if (!id) return json(res, 400, { ok: false, error: 'id is required for meta proxy' });
    targetUrl = `${base}/meta/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`;
    ttl = Number(process.env.CDN_META_TTL_MS || 60 * 60 * 1000);
  } else if (url.pathname.includes('/stream') || url.pathname === '/api/streams') {
    if (!id) return json(res, 400, { ok: false, error: 'id is required for stream proxy' });
    targetUrl = `${base}/stream/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`;
    ttl = Number(process.env.CDN_STREAM_TTL_MS || 2 * 60 * 1000);
  } else {
    ttl = Number(process.env.CDN_MANIFEST_TTL_MS || 60 * 60 * 1000);
  }
  try {
    const cacheKey = `${url.pathname}|${targetUrl}`;
    const { fromCache, value } = await cachedJsonFetch(cacheKey, targetUrl, ttl);
    const payload = (url.pathname.includes('/stream') || url.pathname === '/api/streams') ? normalizeStreamsPayload(value, manifestUrl) : value;
    res.setHeader('X-Debrid-Channels-Addon-Cache', fromCache ? 'hit' : 'miss');
    return json(res, 200, payload, { cacheControl: `public, max-age=${Math.floor(ttl / 1000)}` });
  } catch (err) {
    return json(res, 502, { ok: false, error: err.message, targetUrl });
  }
}

function cdnStatusPayload() {
  let imageFiles = 0;
  try { ensureCdnDirs(); imageFiles = fs.readdirSync(CDN_IMAGE_DIR).filter(name => !name.endsWith('.json')).length; } catch {}
  return {
    ok: true,
    version: backendVersion,
    mode: 'non-destructive-v1.8.13.7-bunny-artwork-auto-prewarm-no-streams',
    externalCdn: { enabled: cdnArtworkEnabled, assetBaseUrl: cdnAssetBaseUrl || null, scope: 'artwork-and-metadata-only-no-streams' },
    bunnyPrewarm: { enabled: cdnArtworkEnabled && BUNNY_PREWARM_ENABLED, limit: BUNNY_PREWARM_LIMIT, concurrency: BUNNY_PREWARM_CONCURRENCY, intervalHours: BUNNY_PREWARM_INTERVAL_HOURS, status: readBunnyPrewarmStatus() },
    memoryEntries: cdnMemoryCache.size,
    androidCache: { homeTtlMs: ANDROID_HOME_TTL_MS, catalogTtlMs: ANDROID_CATALOG_TTL_MS, searchTtlMs: ANDROID_SEARCH_TTL_MS, proxyImagesByDefault: PROXY_IMAGES_BY_DEFAULT },
    imageFiles,
    routesAdded: [
      '/api/image?url=',
      '/api/proxy/image?url=',
      '/api/cdn/status',
      '/api/prewarm',
      '/api/cdn/prewarm',
      '/api/cdn/prewarm/status',
      '/api/cdn/prewarm/start',
      '/api/cache/purge',
      '/api/addon/manifest?manifestUrl=',
      '/api/addon/catalog?manifestUrl=&type=&id=',
      '/api/addon/meta?manifestUrl=&type=&id=',
      '/api/addon/streams?manifestUrl=&type=&id=',
      '/api/streams?manifestUrl=&type=&id='
    ],
    preservedOriginalRoutes: [
      '/trailers/extractor/status',
      '/trailers/extract',
      '/trailers/resolve',
      '/trailers/prewarm',
      '/api/trailer/:id',
      '/api/home',
      '/api/home/hero',
      '/api/home/instant',
      '/api/artwork/cache/:id',
      '/api/trailers/cache/:id',
      '/api/live/instant',
      '/api/live/categories',
      '/api/live/channels?category=',
      '/api/live/guide/now-next',
      '/api/live/guide/window?channelId=&hours=',
      '/api/live/logos/cache/:id',
      '/api/live/artwork/cache/:id',
      '/api/catalog/movies',
      '/api/catalog/shows',
      '/api/search'
    ]
  };
}

function compactLiveChannel(channel = {}, index = 0) {
  const logo = channel.logo || channel.icon || channel.image || '';
  return {
    id: channel.id || channel.externalId || channel.name || String(index),
    externalId: channel.externalId || channel.id || '',
    number: channel.number || '',
    name: channel.name || 'Channel',
    group: channel.group || ((channel.groups || [])[0]) || 'Live TV',
    groups: channel.groups || (channel.group ? [channel.group] : []),
    sourceType: channel.sourceType || '',
    sourceName: channel.sourceName || '',
    streamUrl: channel.streamUrl || '',
    logo,
    icon: logo ? proxiedImageUrl(logo) : '',
    current: channel.current || null,
    next: channel.next || null,
    catchupType: channel.catchupType || '',
    catchupSource: channel.catchupSource || '',
    catchupDays: channel.catchupDays || 0,
    sortOrder: typeof channel.sortOrder === 'number' ? channel.sortOrder : index
  };
}

function buildLiveCategories(channels = []) {
  const counts = new Map();
  for (const ch of channels) {
    const groups = Array.isArray(ch.groups) && ch.groups.length ? ch.groups : [ch.group || 'Live TV'];
    for (const g of groups) {
      const key = String(g || '').trim();
      if (!key) continue;
      counts.set(key, (counts.get(key) || 0) + 1);
    }
  }
  return [{ id: 'all', name: 'All Channels', count: channels.length }]
    .concat(Array.from(counts.entries()).sort((a,b)=>a[0].localeCompare(b[0])).slice(0, 80).map(([name,count]) => ({ id: slugForApi(name), name, count })));
}

function slugForApi(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'all';
}

function filterLiveChannelsByCategory(channels, category) {
  const cat = String(category || 'all').trim().toLowerCase();
  if (!cat || cat === 'all') return channels;
  return channels.filter(ch => {
    const groups = Array.isArray(ch.groups) && ch.groups.length ? ch.groups : [ch.group || ''];
    return groups.some(g => String(g).toLowerCase() === cat || slugForApi(g) === cat);
  });
}

function buildLiveInstantPayload(url, req) {
  const userId = getUserId(url, req) || 'demo';
  const view = getLiveUserView(userId);
  const all = Array.isArray(view.channels) ? view.channels : [];
  const category = url.searchParams.get('category') || 'all';
  const limit = Math.max(1, Math.min(80, Number(url.searchParams.get('limit') || 48))); // v1.8.11: cap instant shell so backend never dumps full guide at startup
  const filtered = filterLiveChannelsByCategory(all, category);
  const channels = filtered.slice(0, limit).map(compactLiveChannel);
  return {
    ok: true,
    version: backendVersion,
    pipeline: 'live-tv-provider-native-v1.8.13.6-bunny-artwork-prewarm-provider-direct-streams',
    userId,
    generatedAt: view.generatedAt || null,
    source: 'provider-native-live-cache',
    staleWhileRefresh: true,
    cachePolicy: {
      jsonMaxAgeSeconds: 60,
      staleWhileRevalidateSeconds: 600,
      startup: 'instant-shell-first',
      artwork: 'logos-visible-window-only',
      programArtworkPrewarm: false,
      providerNativeXmltv: 'direct-provider-xmltv-first',
      providerCategories: 'm3u-group-title-preserved',
      providerLogos: 'tvg-logo-preserved-proxied-only-when-needed',
      startupSafety: 'no-full-guide-dump-on-instant-endpoint'
    },
    categories: buildLiveCategories(all),
    totalChannels: all.length,
    visibleChannels: channels.length,
    channels,
    nowNext: channels.map(ch => ({ channelId: ch.id, current: ch.current, next: ch.next })),
    endpoints: {
      instant: '/api/live/instant',
      categories: '/api/live/categories',
      channels: '/api/live/channels?category=',
      nowNext: '/api/live/guide/now-next',
      window: '/api/live/guide/window?channelId=&hours=',
      logoCache: '/api/live/logos/cache/:id?url=',
      artworkCache: '/api/live/artwork/cache/:id?url='
    }
  };
}

function buildLiveGuideWindow(url, req) {
  const userId = getUserId(url, req) || 'demo';
  const view = getLiveUserView(userId);
  const all = Array.isArray(view.channels) ? view.channels : [];
  const channelId = url.searchParams.get('channelId') || url.searchParams.get('channel_id') || '';
  const hours = Math.max(1, Math.min(8, Number(url.searchParams.get('hours') || 4))); // v1.8.11 cap guide window for Android TV stability
  const category = url.searchParams.get('category') || 'all';
  const filtered = channelId ? all.filter(ch => [ch.id, ch.externalId, ch.name, ch.number].map(normalizeKey).includes(normalizeKey(channelId))) : filterLiveChannelsByCategory(all, category).slice(0, 48); // v1.8.11 visible-window guide only
  const channels = filtered.map((ch, index) => {
    const compact = compactLiveChannel(ch, index);
    const programs = Array.isArray(ch.programs) && ch.programs.length ? ch.programs.slice(0, hours * 3) : [ch.current, ch.next].filter(Boolean);
    return { ...compact, programs };
  });
  return { ok: true, version: backendVersion, userId, generatedAt: view.generatedAt || null, hours, channels };
}

async function handle(req, res) {
  const url = new URL(req.url, publicBaseUrl);
  if (url.pathname === '/live' || url.pathname.startsWith('/live/') || url.pathname === '/guide' || url.pathname.startsWith('/epg')) {
    return liveDisabled(res);
  }


  if (req.method === 'GET' && (url.pathname === '/api/version' || url.pathname === '/version')) {
    return json(res, 200, {
      ok: true,
      version: backendVersion,
      publicBaseUrl,
      cdnAssetBaseUrl: cdnAssetBaseUrl || null,
      cdnArtworkEnabled,
      providerDirectStreams: true,
      cutouts: 'paused-backlogged',
      liveTvMode: 'provider-native-direct-first',
      trailers: { progressiveFirst: TRAILER_PROGRESSIVE_FIRST, fastMode: TRAILER_FAST_MODE, defaultMaxHeight: TRAILER_DEFAULT_MAX_HEIGHT, bunnyVideoProxy: false, metadataOnlyPrewarm: TRAILER_METADATA_ONLY_PREWARM }
    }, { cacheControl: 'no-store' });
  }

  if (req.method === 'GET' && (url.pathname === '/health' || url.pathname === '/api/health')) {
    return json(res, 200, {
      ok: true,
      service: 'channels-debrid-backend',
      version: backendVersion,
      cdn: cdnStatusPayload(),
      port,
      publicBaseUrl,
      lastRefreshAt: loadState().lastRefreshAt
    });
  }


  if (req.method === 'GET' && url.pathname === '/api/live/instant') {
    const cacheKey = cacheKeyFromUrl('live-tv-instant', url);
    return cachedJson(res, cacheKey, 60 * 1000, 'public, max-age=60, stale-while-revalidate=600', () => buildLiveInstantPayload(url, req));
  }

  if (req.method === 'GET' && url.pathname === '/api/live/categories') {
    const userId = getUserId(url, req) || 'demo';
    const view = getLiveUserView(userId);
    return json(res, 200, { ok: true, version: backendVersion, userId, generatedAt: view.generatedAt || null, categories: buildLiveCategories(view.channels || []) }, { cacheControl: 'public, max-age=60, stale-while-revalidate=600' });
  }

  if (req.method === 'GET' && url.pathname === '/api/live/channels') {
    const payload = buildLiveInstantPayload(url, req);
    return json(res, 200, { ok: true, version: payload.version, userId: payload.userId, generatedAt: payload.generatedAt, totalChannels: payload.totalChannels, channels: payload.channels }, { cacheControl: 'public, max-age=60, stale-while-revalidate=600' });
  }

  if (req.method === 'GET' && url.pathname === '/api/live/guide/now-next') {
    const payload = buildLiveInstantPayload(url, req);
    return json(res, 200, { ok: true, version: payload.version, userId: payload.userId, generatedAt: payload.generatedAt, nowNext: payload.nowNext }, { cacheControl: 'public, max-age=30, stale-while-revalidate=300' });
  }

  if (req.method === 'GET' && url.pathname === '/api/live/guide/window') {
    return json(res, 200, buildLiveGuideWindow(url, req), { cacheControl: 'public, max-age=60, stale-while-revalidate=600' });
  }

  if (req.method === 'GET' && (url.pathname.startsWith('/api/live/logos/cache/') || url.pathname.startsWith('/api/live/artwork/cache/'))) {
    try { return await handleCdnImageProxy(req, res, url); }
    catch (err) { return json(res, 502, { ok: false, error: err.message }); }
  }

  if (req.method === 'GET' && (url.pathname === '/api/cdn/status' || url.pathname === '/cdn/status')) {
    return json(res, 200, cdnStatusPayload(), { cacheControl: 'no-store' });
  }


  if (req.method === 'GET' && (url.pathname === '/api/cdn/prewarm/status' || url.pathname === '/api/artwork/prewarm/status')) {
    return json(res, 200, readBunnyPrewarmStatus(), { cacheControl: 'no-store' });
  }

  if ((req.method === 'GET' || req.method === 'POST') && (url.pathname === '/api/cdn/prewarm' || url.pathname === '/api/cdn/prewarm/start' || url.pathname === '/api/artwork/prewarm' || url.pathname === '/api/artwork/prewarm/start')) {
    const limit = Number(url.searchParams.get('limit') || BUNNY_PREWARM_LIMIT);
    const scope = url.searchParams.get('scope') || 'home-live';
    const force = url.searchParams.get('force') === '1' || req.method === 'POST';
    if (!BUNNY_PREWARM_ENABLED || !BUNNY_PREWARM_MANUAL_ENABLED) {
      const disabled = {
        ok: true,
        accepted: false,
        enabled: false,
        manualEnabled: false,
        version: backendVersion,
        message: 'Bunny artwork auto-prewarm is disabled. Normal poster/logo/backdrop loading and CDN image proxy remain enabled.',
        status: '/api/cdn/prewarm/status',
        scope,
        limit,
        force
      };
      writeBunnyPrewarmStatus({ ...readBunnyPrewarmStatus(), ...disabled, running: false, updatedAt: new Date().toISOString() });
      return json(res, 200, disabled, { cacheControl: 'no-store' });
    }
    runBunnyArtworkPrewarm({ limit, scope, force, reason: req.method === 'GET' ? 'manual-browser-trigger' : 'manual-post-trigger' }).catch(() => {});
    return json(res, 202, { ok: true, accepted: true, version: backendVersion, message: 'Bunny artwork prewarm queued by explicit manual/admin request.', status: '/api/cdn/prewarm/status', scope, limit, force }, { cacheControl: 'no-store' });
  }


  if (req.method === 'POST' && (url.pathname === '/api/cache/purge' || url.pathname === '/api/cdn/purge')) {
    const prefix = url.searchParams.get('prefix') || '';
    const removed = clearResponseCache(prefix);
    return json(res, 200, { ok: true, removed, prefix }, { cacheControl: 'no-store' });
  }

  if (req.method === 'POST' && (url.pathname === '/api/prewarm' || url.pathname === '/api/cache/prewarm')) {
    const limit = Number(url.searchParams.get('limit') || process.env.PREWARM_IMAGE_LIMIT || 80);
    const payload = loadHomeRows();
    const images = await prewarmImagesFromPayload(payload, limit);
    return json(res, 202, { ok: true, images, message: 'Android TV cache prewarm queued' }, { cacheControl: 'no-store' });
  }




  if (req.method === 'GET' && url.pathname === '/api/artwork/provider-keys/status') {
    return json(res, 200, { ok: true, version: backendVersion, providers: artworkProviderKeyStatus() }, { cacheControl: 'no-store' });
  }

  if (req.method === 'POST' && url.pathname === '/api/artwork/provider-keys') {
    try {
      const body = await readBody(req);
      const saved = writeArtworkProviderKeys(body || {});
      return json(res, 200, {
        ok: true,
        version: backendVersion,
        message: 'Artwork provider keys saved. Artwork pool cache was cleared so new provider art can hydrate on next resolve.',
        providers: { tmdb: !!saved.tmdbApiKey, fanartTv: !!saved.fanartTvApiKey, tvdb: !!saved.tvdbApiToken }
      }, { cacheControl: 'no-store' });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message }, { cacheControl: 'no-store' });
    }
  }

  if (req.method === 'GET' && url.pathname === '/api/artwork/resolve') {
    const title = (url.searchParams.get('title') || '').trim();
    const imdbId = (url.searchParams.get('imdbId') || url.searchParams.get('externalId') || '').trim();
    const tmdbId = (url.searchParams.get('tmdbId') || '').trim();
    const tvdbId = (url.searchParams.get('tvdbId') || '').trim();
    const type = (url.searchParams.get('type') || 'movie').trim();
    const id = firstNonEmpty(imdbId, tmdbId, tvdbId, title, `${type}-artwork`);
    const metadataPool = makeEmptyArtworkPool();
    const externalPool = await resolveExternalArtworkPool({ imdbId, tmdbId, tvdbId, type });
    const mergedPool = mergeArtworkPools(metadataPool, externalPool);
    const selected = selectArtworkFromPool(id, mergedPool);
    const shouldProxy = shouldProxyImages(url);
    const responsePool = shouldProxy ? proxiedArtworkPool(mergedPool) : mergedPool;
    const responseSelected = shouldProxy ? Object.fromEntries(Object.entries(selected).map(([k, v]) => [k, proxiedImageUrl(v)])) : selected;
    return json(res, 200, {
      ok: true,
      title,
      imdbId,
      tmdbId,
      tvdbId,
      type,
      version: 'backend_v1.8.14_MULTI_SOURCE_ARTWORK_POOL',
      selectedArtwork: responseSelected,
      artworkPool: responsePool,
      artworkPoolStats: artworkPoolStats(mergedPool),
      randomize: { enabled: ARTWORK_RANDOMIZE_ENABLED, stickyHours: ARTWORK_RANDOM_STICKY_HOURS },
      sourcesConfigured: {
        tmdb: !!TMDB_API_KEY,
        fanarttv: !!FANART_TV_API_KEY,
        tvdb: !!TVDB_API_TOKEN,
        imdbCinemetaFallback: true,
        stremioProviderArtwork: true,
        gracenotesXmltvLiveArtwork: true,
        channelsDvrChannelLogos: true
      },
      fields: ['posters[]','backdrops[]','logos[]','clearlogos[]','landscape[]','banners[]','stills[]','programArt[]','channelLogos[]','previewImages[]'],
      note: 'Both tvOS and Android can use selectedArtwork for stable randomized art or the arrays for their own rotation.'
    }, { cacheControl: 'public, max-age=3600, stale-while-revalidate=86400' });
  }

  if (req.method === 'GET' && (url.pathname === '/api/hero/poster-logo' || url.pathname === '/api/artwork/hero-logo')) {
    const hero = url.searchParams.get('hero') || url.searchParams.get('poster') || '';
    const logo = url.searchParams.get('logo') || '';
    const id = url.searchParams.get('id') || '';
    if (!hero || !isAllowedProxyUrl(hero)) {
      return json(res, 404, { ok: false, error: 'Missing hero for hero+logo composite', id }, { cacheControl: 'no-store' });
    }
    if (!sharp || !logo || !isAllowedProxyUrl(logo)) {
      const target = proxiedImageUrl(hero);
      res.statusCode = 302;
      res.setHeader('Location', target);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('X-Debrid-Channels-Hero-Logo-Mode', sharp ? 'hero-only-fallback' : 'sharp-not-installed-fallback');
      return res.end();
    }
    try {
      ensureCdnDirs();
      const key = crypto.createHash('sha1').update(`hero-logo-v2-no-half-tint|${hero}|${logo}|${id}`).digest('hex');
      const outPath = path.join(CDN_IMAGE_DIR, `hero-logo-${key}.webp`);
      if (fs.existsSync(outPath)) {
        setCdnHeaders(res, 'image/webp', 31536000);
        res.setHeader('X-Debrid-Channels-Hero-Logo-Mode', 'real-composite-cache-hit');
        return fs.createReadStream(outPath).pipe(res);
      }
      const [heroRes, logoRes] = await Promise.all([
        fetchWithTimeout(hero, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' }),
        fetchWithTimeout(logo, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' })
      ]);
      if (!heroRes.ok) throw new Error(`hero ${heroRes.status}`);
      if (!logoRes.ok) throw new Error(`logo ${logoRes.status}`);
      const heroBuf = Buffer.from(await heroRes.arrayBuffer());
      const logoBuf = Buffer.from(await logoRes.arrayBuffer());
      const width = 3840;
      const height = 2160;
      const logoWidth = Math.round(width * 0.34);
      const logoHeight = Math.round(height * 0.20);
      const logoPng = await sharp(logoBuf)
        .resize({ width: logoWidth, height: logoHeight, fit: 'inside', withoutEnlargement: true })
        .png()
        .toBuffer();
      // v1.8.13.15: no full-height left shade. The app already applies its
      // normal hero readability overlay; baking another half-screen tint into
      // the image caused the visible split/tint artifact in Performance mode.
      // Keep the hero image clean and only bake the title logo in the same
      // visual safe area as the themed logo engine.
      const output = await sharp(heroBuf)
        .resize({ width, height, fit: 'cover', position: 'attention' })
        .composite([
          { input: logoPng, left: Math.round(width * 0.035), top: Math.round(height * 0.13), blend: 'over' }
        ])
        .webp({ quality: 94, effort: 4 })
        .toBuffer();
      fs.writeFileSync(outPath, output);
      setCdnHeaders(res, 'image/webp', 31536000);
      res.setHeader('X-Debrid-Channels-Hero-Logo-Mode', 'real-composite-generated');
      return res.end(output);
    } catch (err) {
      const target = proxiedImageUrl(hero);
      res.statusCode = 302;
      res.setHeader('Location', target);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.setHeader('X-Debrid-Channels-Hero-Logo-Mode', 'composite-error-fallback');
      return res.end();
    }
  }

  if (req.method === 'GET' && (url.pathname === '/api/card/poster-logo' || url.pathname === '/api/artwork/poster-logo')) {
    const poster = url.searchParams.get('poster') || '';
    const logo = url.searchParams.get('logo') || '';
    const id = url.searchParams.get('id') || '';
    if (!poster || !isAllowedProxyUrl(poster)) {
      return json(res, 404, { ok: false, error: 'Missing poster for poster+logo composite', id }, { cacheControl: 'no-store' });
    }
    if (!sharp || !logo || !isAllowedProxyUrl(logo)) {
      const target = proxiedImageUrl(poster);
      res.statusCode = 302;
      res.setHeader('Location', target);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader('X-Debrid-Channels-Poster-Logo-Mode', sharp ? 'poster-only-fallback' : 'sharp-not-installed-fallback');
      return res.end();
    }
    try {
      ensureCdnDirs();
      const key = crypto.createHash('sha1').update(`poster-logo-v4-safe16x9|${poster}|${logo}|${id}`).digest('hex');
      const outPath = path.join(CDN_IMAGE_DIR, `poster-logo-${key}.webp`);
      if (fs.existsSync(outPath)) {
        setCdnHeaders(res, 'image/webp', 31536000);
        res.setHeader('X-Debrid-Channels-Poster-Logo-Mode', 'real-composite-cache-hit');
        return fs.createReadStream(outPath).pipe(res);
      }
      const [posterRes, logoRes] = await Promise.all([
        fetchWithTimeout(poster, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' }),
        fetchWithTimeout(logo, CDN_FETCH_TIMEOUT_MS, { accept: 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8' })
      ]);
      if (!posterRes.ok) throw new Error(`poster ${posterRes.status}`);
      if (!logoRes.ok) throw new Error(`logo ${logoRes.status}`);
      const posterBuf = Buffer.from(await posterRes.arrayBuffer());
      const logoBuf = Buffer.from(await logoRes.arrayBuffer());
      // v1.8.13.16: row cards are always emitted as true 16:9 TV card composites.
      // This prevents the app's rounded 16:9 card from center-cropping the baked logo
      // off the bottom. Restore the v71-style behavior: one baked card image for
      // focused and unfocused performance rows, but with a larger safe bottom margin.
      const width = 1280;
      const height = 720;
      const logoWidth = Math.round(width * 0.44);
      const logoHeight = Math.round(height * 0.17);
      const insetX = Math.round(width * 0.055);
      const insetY = Math.round(height * 0.095);
      const logoPng = await sharp(logoBuf)
        .resize({ width: logoWidth, height: logoHeight, fit: 'inside', withoutEnlargement: true })
        .png()
        .toBuffer();
      const shadeHeight = Math.round(height * 0.34);
      const shade = await sharp({
        create: { width, height: shadeHeight, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0.54 } }
      }).png().toBuffer();
      const output = await sharp(posterBuf)
        .resize({ width, height, fit: 'cover', position: 'attention' })
        .composite([
          { input: shade, left: 0, top: height - shadeHeight, blend: 'over' },
          { input: logoPng, left: insetX, top: Math.max(Math.round(height * 0.60), height - insetY - logoHeight), blend: 'over' }
        ])
        .webp({ quality: 94, effort: 4 })
        .toBuffer();
      fs.writeFileSync(outPath, output);
      setCdnHeaders(res, 'image/webp', 31536000);
      res.setHeader('X-Debrid-Channels-Poster-Logo-Mode', 'real-composite-generated-safe16x9');
      return res.end(output);
    } catch (err) {
      const target = proxiedImageUrl(poster);
      res.statusCode = 302;
      res.setHeader('Location', target);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.setHeader('X-Debrid-Channels-Poster-Logo-Mode', `composite-error-fallback`);
      return res.end();
    }
  }

  if (req.method === 'GET' && (url.pathname === '/api/image' || url.pathname === '/api/proxy/image' || url.pathname === '/image')) {
    try {
      return await handleCdnImageProxy(req, res, url);
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && (
    url.pathname === '/api/addon/manifest' ||
    url.pathname === '/api/addon/catalog' ||
    url.pathname === '/api/addon/meta' ||
    url.pathname === '/api/addon/streams' ||
    url.pathname === '/api/streams'
  )) {
    return await handleAddonProxy(req, res, url);
  }



  if (req.method === 'GET' && url.pathname.startsWith('/api/artwork/hero-assets/')) {
    ensureHeroAssetCacheDir();
    const parts = url.pathname.split('/').filter(Boolean);
    const file = parts[parts.length - 1] || '';
    const id = decodeURIComponent(parts[parts.length - 2] || 'hero');
    const safeId = safeAssetId({ id });
    if (file === 'palette.json') {
      const p = path.join(HERO_ASSET_CACHE_DIR, `${safeId}.palette.json`);
      if (fs.existsSync(p)) return json(res, 200, JSON.parse(fs.readFileSync(p, 'utf8')), { cacheControl: 'public, max-age=86400, stale-while-revalidate=604800' });
      return json(res, 200, heroAssetEnvelope({ id: safeId }, false).heroAssets.palette, { cacheControl: 'public, max-age=3600' });
    }
    if (file === 'mask-quality.json') {
      const p = path.join(HERO_ASSET_CACHE_DIR, `${safeId}.mask-quality.json`);
      if (fs.existsSync(p)) return json(res, 200, JSON.parse(fs.readFileSync(p, 'utf8')), { cacheControl: 'public, max-age=86400, stale-while-revalidate=604800' });
      return json(res, 200, heroAssetEnvelope({ id: safeId }, false).heroAssets.maskQuality, { cacheControl: 'public, max-age=3600' });
    }
    return json(res, 404, { ok: false, error: 'Unknown hero asset sidecar', id: safeId }, { cacheControl: 'no-store' });
  }

  if (req.method === 'GET' && url.pathname === '/api/home/hero') {
    const cacheKey = cacheKeyFromUrl('instant-home-hero', url);
    const cacheControl = 'public, max-age=120, stale-while-revalidate=1800';
    return cachedJson(res, cacheKey, INSTANT_HERO_TTL_MS, cacheControl, () => buildInstantHeroPayload({ proxyImages: shouldProxyImages(url) }));
  }

  if (req.method === 'GET' && url.pathname === '/api/home/instant') {
    const cacheKey = cacheKeyFromUrl('instant-home-ready', url);
    const cacheControl = `public, max-age=${ANDROID_JSON_MAX_AGE_SECONDS}, stale-while-revalidate=3600`;
    return cachedJson(res, cacheKey, INSTANT_HOME_TTL_MS, cacheControl, () => {
      const payload = buildInstantHomePayload({ proxyImages: shouldProxyImages(url) });
      prewarmInstantHomeAssets(payload).catch(() => {});
      return payload;
    });
  }

  if (req.method === 'GET' && url.pathname.startsWith('/api/artwork/cache/')) {
    const sourceUrl = (url.searchParams.get('url') || url.searchParams.get('src') || '').trim();
    if (!sourceUrl) return json(res, 400, { ok: false, error: 'url query parameter is required for artwork cache endpoint' }, { cacheControl: 'no-store' });
    return await handleCdnImageProxy(req, res, url);
  }

  if (req.method === 'GET' && url.pathname.startsWith('/api/trailers/cache/')) {
    try {
      const id = decodeURIComponent(url.pathname.split('/').pop() || '');
      const title = (url.searchParams.get('title') || id || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const mediaType = (url.searchParams.get('mediaType') || url.searchParams.get('type') || 'movie').trim();
      const prefer4k = url.searchParams.get('prefer4k') === '1';
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId: id, mediaType });
      return json(res, 200, { ok: true, id, title, trailer, cached: !!trailer.cached, version: INSTANT_HOME_VERSION }, { cacheControl: 'private, max-age=600' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message }, { cacheControl: 'no-store' });
    }
  }

  if (req.method === 'GET' && url.pathname === '/api/home') {
    const cacheKey = cacheKeyFromUrl('android-home', url);
    const cacheControl = `public, max-age=${ANDROID_JSON_MAX_AGE_SECONDS}, stale-while-revalidate=3600`;
    return cachedJson(res, cacheKey, ANDROID_HOME_TTL_MS, cacheControl, () => rewriteImagesDeep(loadHomeRows(), shouldProxyImages(url)));
  }

  if (req.method === 'GET' && url.pathname === '/api/catalog/movies') {
    const cacheKey = cacheKeyFromUrl('android-catalog-movies', url);
    const cacheControl = `public, max-age=${ANDROID_JSON_MAX_AGE_SECONDS}, stale-while-revalidate=3600`;
    return cachedJson(res, cacheKey, ANDROID_CATALOG_TTL_MS, cacheControl, () => rewriteImagesDeep({ ok: true, items: mediaItemsFromHomeRows('movie') }, shouldProxyImages(url)));
  }

  if (req.method === 'GET' && url.pathname === '/api/catalog/shows') {
    const cacheKey = cacheKeyFromUrl('android-catalog-shows', url);
    const cacheControl = `public, max-age=${ANDROID_JSON_MAX_AGE_SECONDS}, stale-while-revalidate=3600`;
    return cachedJson(res, cacheKey, ANDROID_CATALOG_TTL_MS, cacheControl, () => rewriteImagesDeep({ ok: true, items: mediaItemsFromHomeRows('series') }, shouldProxyImages(url)));
  }

  if (req.method === 'GET' && url.pathname === '/api/search') {
    const cacheKey = cacheKeyFromUrl('android-search', url);
    const cacheControl = `public, max-age=${Math.min(ANDROID_JSON_MAX_AGE_SECONDS, 120)}, stale-while-revalidate=600`;
    return cachedJson(res, cacheKey, ANDROID_SEARCH_TTL_MS, cacheControl, () => rewriteImagesDeep({ ok: true, items: searchMediaItems(url.searchParams.get('q') || '') }, shouldProxyImages(url)));
  }

  if (req.method === 'GET' && (url.pathname === '/performance/status' || url.pathname === '/api/performance/status')) {
    const userId = getUserId(url, req) || 'demo';
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      engine: 'channels-debrid-performance-engine-v9',
      userId,
      modules: {
        liveTv: { enabled: true, channels: (view.channels || []).length, groups: (view.groups || []).length, epg: epgProgress(userId) },
        posters: { enabled: true, source: 'backend-catalog-cache' },
        trailers: { enabled: true, cacheEntries: trailerCache.size, inflight: inflightTrailerResolves.size, playback: 'media3-nuvio-style-client' },
        icons: { enabled: true, cacheEntries: iconCache.size }
      },
      settings: epgSettings,
      generatedAt: view.generatedAt
    });
  }

  if (req.method === 'GET' && (url.pathname.startsWith('/icons/') || url.pathname.startsWith('/live/icons/') || url.pathname.startsWith('/api/live/icons/'))) {
    const userId = getUserId(url, req) || 'demo';
    const channelId = decodeURIComponent(url.pathname.split('/').pop() || '');
    return proxyChannelIcon(res, userId, channelId);
  }

  if (req.method === 'GET' && url.pathname === '/api/sources') {
    return json(res, 200, {
      configuredSources: DEFAULT_SOURCES.map(({ preferredCatalogs, maxRails, ...rest }) => ({ ...rest, preferredCatalogs, maxRails })),
      state: loadState()
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/refresh') {
    try {
      const result = await refreshCatalogs();
      const cleared = clearResponseCache('android-');
      return json(res, 200, { ok: true, cacheCleared: cleared, ...result });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && url.pathname === '/live/sources') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    return json(res, 200, { ok: true, userId, sources: listLiveSources(userId) });
  }

  if (req.method === 'POST' && url.pathname === '/live/sources/connect') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const sources = upsertLiveSource(userId, body);
      await refreshLiveData({ userId });
      return json(res, 200, { ok: true, userId, sources });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }


  if (req.method === 'POST' && (url.pathname === '/live/epg/settings' || url.pathname === '/api/live/epg/settings')) {
    try {
      const body = await readBody(req).catch(() => ({}));
      epgSettings.refreshEveryHours = Number(body.refreshEveryHours ?? epgSettings.refreshEveryHours ?? 6);
      epgSettings.durationHours = Number(body.durationHours ?? epgSettings.durationHours ?? 12);
      return json(res, 200, { ok: true, settings: epgSettings });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && (url.pathname === '/live/epg/refresh' || url.pathname === '/api/live/epg/refresh' || url.pathname === '/epg/refresh' || url.pathname === '/api/epg/refresh')) {
    try {
      const body = await readBody(req).catch(() => ({}));
      const userId = body.userId || body.user_id || getUserId(url, req) || 'demo';
      const durationHours = Number(body.durationHours || url.searchParams.get('durationHours') || epgSettings.durationHours || 12);
      const force = body.force !== false;
      const job = startEpgRefresh(userId, durationHours, force);
      return json(res, 202, { ok: true, accepted: true, userId, progress: job });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && (url.pathname === '/live/epg/status' || url.pathname === '/live/epg/progress' || url.pathname === '/api/live/epg/status' || url.pathname === '/api/live/epg/progress' || url.pathname === '/epg/status' || url.pathname === '/api/epg/status')) {
    const userId = getUserId(url, req) || 'demo';
    return json(res, 200, { ok: true, settings: epgSettings, progress: epgProgress(userId) });
  }

  if (req.method === 'GET' && (url.pathname === '/live/epg' || url.pathname === '/api/live/epg' || url.pathname === '/api/live/guide' || url.pathname === '/api/guide' || url.pathname === '/guide' || url.pathname === '/epg/guide' || url.pathname === '/api/epg/guide')) {
    const userId = getUserId(url, req) || 'demo';
    const { view, channels, selected, programs } = guidePayloadForRequest(url, userId);
    return json(res, 200, { ok: true, userId, generatedAt: view.generatedAt, progress: epgProgress(userId), channel: selected, programs, guide: programs, channels: channels.map(channel => ({ id: channel.id, externalId: channel.externalId, number: channel.number, name: channel.name, group: channel.group, groups: channel.groups || (channel.group ? [channel.group] : []), current: channel.current, next: channel.next, logo: channel.logo, icon: channel.logo ? '/icons/' + encodeURIComponent(channel.id) + '.png' : '', poster: channel.poster, backdrop: channel.backdrop })) });
  }

  if (req.method === 'GET' && url.pathname === '/live/channels') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      generatedAt: view.generatedAt,
      source: 'live-control-plane',
      channels: view.channels,
      groups: view.groups
    });
  }

  if (req.method === 'GET' && url.pathname === '/live/guide') {
    const userId = getUserId(url, req) || 'demo';
    let cachedView = getLiveUserView(userId);
    if (url.searchParams.get('refresh') === '1' || !(cachedView.channels || []).length) {
      try { await refreshLiveData({ userId }); } catch (err) { setEpgProgress(userId, { ok: false, running: false, stage: 'failed', error: err.message, message: 'Guide refresh failed' }); }
    }
    const { view, channels, selected, programs } = guidePayloadForRequest(url, userId);
    return json(res, 200, { ok: true, userId, generatedAt: view.generatedAt, channel: selected, programs, guide: programs, channels: channels.map(channel => ({ id: channel.id, externalId: channel.externalId, number: channel.number, name: channel.name, group: channel.group, groups: channel.groups || (channel.group ? [channel.group] : []), streamUrl: channel.streamUrl, programs: channel.programs || [], current: channel.current, next: channel.next, logo: channel.logo, icon: channel.logo ? '/icons/' + encodeURIComponent(channel.id) + '.png' : '', poster: channel.poster, backdrop: channel.backdrop })) });
  }

  if (req.method === 'GET' && url.pathname.startsWith('/live/channel/')) {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = decodeURIComponent(url.pathname.split('/').pop() || '');
    const channel = getChannelById(userId, channelId);
    if (!channel) return json(res, 404, { ok: false, error: 'Channel not found' });
    return json(res, 200, { ok: true, userId, channel });
  }

  if (req.method === 'GET' && url.pathname === '/live/quick-guide') {
    const userId = getUserId(url, req);
    if (!userId) return json(res, 400, { ok: false, error: 'user_id is required' });
    const channelId = url.searchParams.get('channel_id') || '';
    const view = getLiveUserView(userId);
    return json(res, 200, {
      ok: true,
      userId,
      source: 'live-control-plane',
      quickGuide: buildQuickGuide(view.channels, channelId)
    });
  }

  if (req.method === 'POST' && url.pathname === '/live/playback/resolve') {
    try {
      const body = await readBody(req);
      const userId = body.userId || body.user_id;
      const channelId = body.channelId || body.channel_id;
      if (!userId || !channelId) return json(res, 400, { ok: false, error: 'userId and channelId are required' });
      return json(res, 200, { ok: true, playback: resolvePlayback(userId, channelId) });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message });
    }
  }

  if (req.method === 'POST' && url.pathname === '/live/refresh') {
    try {
      const body = await readBody(req).catch(() => ({}));
      const userId = body.userId || body.user_id || getUserId(url, req) || undefined;
      const result = await refreshLiveData({ userId });
      return json(res, 200, { ok: true, generatedAt: result.generatedAt, users: userId ? [userId] : Object.keys(result.users) });
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message });
    }
  }


  if (req.method === 'GET' && (
    url.pathname === '/trailers/extractor/status' ||
    url.pathname === '/api/trailers/extractor/status' ||
    url.pathname === '/api/trailer/extractor/status'
  )) {
    try {
      const result = await execYtDlp(['--version'], 10000);
      return json(res, 200, {
        ok: true,
        extractor: 'yt-dlp',
        installed: true,
        bin: result.bin,
        version: String(result.stdout || '').trim(),
        candidates: ytDlpCandidates(),
        timeoutMs: YTDLP_TIMEOUT_MS,
        path: process.env.PATH || '',
        ytdlpBinEnv: process.env.YTDLP_BIN || '',
        checkedAt: new Date().toISOString()
      }, { cacheControl: 'no-store' });
    } catch (err) {
      return json(res, 500, {
        ok: false,
        extractor: 'yt-dlp',
        installed: false,
        error: err.message,
        candidates: ytDlpCandidates(),
        path: process.env.PATH || '',
        ytdlpBinEnv: process.env.YTDLP_BIN || '',
        checkedAt: new Date().toISOString()
      }, { cacheControl: 'no-store' });
    }
  }


  if (req.method === 'GET' && (
    url.pathname === '/trailers/extract' ||
    url.pathname === '/api/trailers/extract' ||
    url.pathname === '/trailer/extract' ||
    url.pathname === '/api/trailer/extract'
  )) {
    try {
      const videoUrl = (url.searchParams.get('url') || '').trim();
      if (!videoUrl) return json(res, 400, { ok: false, error: 'url is required' }, { cacheControl: 'no-store' });
      const prefer4k = url.searchParams.get('quality') === '4k' || url.searchParams.get('prefer4k') === '1';
      const extracted = await extractTrailerStreams(videoUrl, prefer4k);
      return json(res, 200, extracted, { cacheControl: 'private, max-age=300' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message, path: url.pathname }, { cacheControl: 'no-store' });
    }
  }

  if (req.method === 'GET' && (
    url.pathname === '/trailers/extractor/resolve' ||
    url.pathname === '/api/trailers/extractor/resolve'
  )) {
    try {
      const videoUrl = (url.searchParams.get('url') || '').trim();
      if (!videoUrl) return json(res, 400, { ok: false, error: 'url is required' });
      const prefer4k = url.searchParams.get('quality') === '4k' || url.searchParams.get('prefer4k') === '1';
      const trailer = await resolveTrailerUrlDirect(videoUrl, prefer4k);
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=300' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message }, { cacheControl: 'no-store' });
    }
  }


  if (req.method === 'GET' && (url.pathname === '/api/trailers/status' || url.pathname === '/trailers/status')) {
    return json(res, 200, {
      ok: true,
      version: backendVersion,
      mode: 'metadata-resolve-cache-only',
      bunnyVideoProxy: false,
      progressiveFirst: TRAILER_PROGRESSIVE_FIRST,
      fastMode: TRAILER_FAST_MODE,
      defaultMaxHeight: TRAILER_DEFAULT_MAX_HEIGHT,
      metadataOnlyPrewarm: TRAILER_METADATA_ONLY_PREWARM,
      cacheEntries: trailerCache.size,
      inflight: inflightTrailerResolves.size,
      message: 'Trailer optimization is URL/metadata pre-resolve only; no trailer video bytes are cached or sent through BunnyCDN.'
    }, { cacheControl: 'no-store' });
  }

  if (req.method === 'POST' && url.pathname === '/trailers/prewarm') {
    try {
      const body = await readBody(req);
      const items = Array.isArray(body.items) ? body.items.slice(0, TRAILER_PREWARM_LIMIT) : [];
      const requested4k = parseBool(body.prefer4k) || parseBool(body.prefer_4k);
      const prefer4k = TRAILER_FAST_MODE ? false : requested4k;
      for (const item of items) {
        const title = String(item.title || '').trim();
        if (!title) continue;
        const year = String(item.year || '').trim();
        resolveTrailer({ title, year, prefer4k, mediaId: item.id || item.externalId || item.tmdbId || item.imdbId || title, mediaType: item.type || item.mediaType || "movie" }).catch(() => {});
      }
      return json(res, 202, { ok: true, queued: items.length, metadataOnly: TRAILER_METADATA_ONLY_PREWARM, cacheVideo: false, bunnyVideoProxy: false, prefer4k }, { cacheControl: 'no-store' });
    } catch (err) {
      return json(res, 400, { ok: false, error: err.message || 'Invalid prewarm request' });
    }
  }

  if (req.method === 'GET' && url.pathname.startsWith('/api/trailer/')) {
    try {
      const id = decodeURIComponent(url.pathname.split('/').pop() || '');
      const title = (url.searchParams.get('title') || id || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const prefer4k = parseBool(url.searchParams.get('prefer4k')) || url.searchParams.get('quality') === '4k' || String(url.searchParams.get('quality') || '').includes('2160');
      const mediaType = (url.searchParams.get('mediaType') || url.searchParams.get('type') || 'movie').trim();
      if (!title) return json(res, 400, { ok: false, error: 'title is required' });
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId: id, mediaType });
      return json(res, 200, { ok: true, trailer }, { cacheControl: 'private, max-age=600' });
    } catch (err) {
      return json(res, 502, { ok: false, error: err.message });
    }
  }

  if (req.method === 'GET' && (url.pathname === '/trailers/resolve' || url.pathname === '/api/trailers/resolve' || url.pathname === '/api/focused-card/preview/resolve' || url.pathname === '/api/preview/resolve')) {
    try {
      const title = (url.searchParams.get('title') || '').trim();
      const year = (url.searchParams.get('year') || '').trim();
      const prefer4k = parseBool(url.searchParams.get('prefer4k')) || url.searchParams.get('quality') === '4k' || String(url.searchParams.get('quality') || '').includes('2160');
      const mediaId = (url.searchParams.get('mediaId') || url.searchParams.get('id') || '').trim();
      const mediaType = (url.searchParams.get('mediaType') || url.searchParams.get('type') || '').trim();
      if (!title) return json(res, 400, { ok: false, error: 'title is required' });
      const trailer = await resolveTrailer({ title, year, prefer4k, mediaId, mediaType });
      const preview = buildFocusedPreviewPayload(trailer, { title, year, mediaId, mediaType });
      return json(res, 200, { ok: true, trailer, preview, ...preview }, { cacheControl: 'private, max-age=1800, stale-while-revalidate=86400' });
    } catch (err) {
      const fallback = {
        ok: true,
        noPreview: true,
        previewUrl: null,
        playbackUrl: null,
        previewType: 'artwork-motion-fallback',
        previewSource: 'resolver-error',
        previewDurationSeconds: 30,
    retention: KEEP_TRAILER_PREVIEW_CACHE_FOREVER ? 'keep-indefinitely-manual-cleanup-only' : 'ttl',
        muted: true,
        loop: true,
        startAfterFocusMs: 1700,
        killOnFocusLoss: true,
        fallback: 'artwork-motion',
        error: err.message
      };
      return json(res, 200, { ok: true, preview: fallback, ...fallback }, { cacheControl: 'private, max-age=900' });
    }
  }

  if (req.method === 'GET' && url.pathname === '/') {
    return json(res, 200, {
      ok: true,
      message: 'Channels Debrid backend is running',
      endpoints: [
        '/health',
        '/api/health',
        '/api/home',
        '/api/sources',
        '/api/refresh',
        '/api/cdn/status',
      '/api/prewarm',
      '/api/cdn/prewarm',
      '/api/cdn/prewarm/status',
      '/api/cache/purge',
        '/api/image?url=',
        '/api/addon/manifest?manifestUrl=',
        '/api/addon/catalog?manifestUrl=&type=&id=',
        '/api/addon/meta?manifestUrl=&type=&id=',
        '/api/addon/streams?manifestUrl=&type=&id=',
        '/api/streams?manifestUrl=&type=&id=',
        '/live/sources',
        '/live/channels',
        '/live/guide',
        '/live/quick-guide',
        '/live/playback/resolve',
        '/live/refresh',
        '/trailers/extractor/status',
        '/trailers/extract',
        '/trailers/resolve',
        '/trailers/prewarm',
        '/api/trailer/:id'
      ]
    });
  }

  return notFound(res, url);
}

function inferMimeFromUrl(url) {
  const lower = String(url || '').toLowerCase();
  if (lower.includes('.m3u8')) return 'application/x-mpegURL';
  if (lower.includes('.mpd')) return 'application/dash+xml';
  if (lower.includes('mime=video%2fmp4') || lower.includes('mime=video/mp4')) return 'video/mp4';
  return 'video/mp4';
}

function firstPlayableUrl(stdout) {
  return String(stdout || '')
    .split(/\r?\n/)
    .map(s => s.trim())
    .filter(Boolean)
    .find(s => /^https?:\/\//i.test(s)) || '';
}

async function resolveTrailerUrlDirect(videoUrl, prefer4k) {
  const effective4k = prefer4k && !TRAILER_FAST_MODE;
  const maxHeight = Math.min(effective4k ? 2160 : 1080, TRAILER_DEFAULT_MAX_HEIGHT || 1080);
  const format = `b[height<=${maxHeight}][height>=720][ext=mp4]/b[height<=${maxHeight}][height>=720]/22/best[height<=${maxHeight}][height>=720]/best[height<=${maxHeight}]/best`;
  const stdout = await execYtDlpStdout([
    '--no-playlist',
    '--no-warnings',
    '--force-ipv4',
    '--format', format,
    '--extractor-args', 'youtube:player_client=android,web,tv_embedded',
    '--get-url',
    videoUrl
  ], YTDLP_TIMEOUT_MS);
  const playbackUrl = firstPlayableUrl(stdout);
  if (!playbackUrl) throw new Error('yt-dlp did not return a playable URL');
  return {
    videoId: videoUrl,
    title: '',
    channel: '',
    duration: 0,
    playbackUrl,
    mimeType: inferMimeFromUrl(playbackUrl),
    quality: effective4k ? 'best up to 4K direct' : 'best up to 1080p direct',
    maxHeight,
    fallbackUsed: true,
    source: 'yt-dlp-get-url-direct-no-cdn-video'
  };
}

const server = http.createServer((req, res) => {
  handle(req, res).catch((err) => {
    json(res, 500, { ok: false, error: err.message });
  });
});

server.listen(port, '0.0.0.0', () => {
  console.log(`Channels Debrid backend listening on 0.0.0.0:${port}`);
  refreshCatalogs().then((result) => {
    console.log('Warm catalog refresh complete', result.generatedAt || 'ok');
    // Bunny artwork auto-prewarm intentionally disabled; normal catalog/artwork loading stays active.
  }).catch((err) => {
    console.warn('Warm catalog refresh failed:', err.message);
  });
  // scheduleBunnyArtworkPrewarmOnce(); // disabled by default to stop broad Bunny auto-prewarm bandwidth usage
});
