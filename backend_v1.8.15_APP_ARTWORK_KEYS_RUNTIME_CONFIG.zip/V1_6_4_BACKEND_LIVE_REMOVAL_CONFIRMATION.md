# v1.6.4 Backend Live TV Removal Confirmation

Live TV source ownership is now app-side only:
- Channels DVR Direct
- Native HDHomeRun
- M3U/IPTV
- Xtream/IPTV

The backend no longer imports or runs live refresh jobs in the worker. `/live/*`, `/guide`, `/epg`, and `/api/live/*` return disabled responses so Docker is not used as a Live TV middleman.
