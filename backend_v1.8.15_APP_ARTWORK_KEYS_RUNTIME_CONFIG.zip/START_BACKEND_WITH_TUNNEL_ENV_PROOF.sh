#!/usr/bin/env bash
set -euo pipefail
echo "[Debrid Channels] Starting backend with .env + Cloudflare tunnel + BunnyCDN env proof"
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml down --remove-orphans
sudo docker compose -f docker-compose.yml -f docker-compose.tunnel.yml up -d --build --force-recreate
echo
echo "[Debrid Channels] API container CDN env:"
sudo docker exec debrid-channels-api printenv | grep -i CDN || true
echo
echo "[Debrid Channels] CDN status local:"
curl -s "http://192.168.100.55:8181/api/cdn/status?ts=$(date +%s)" || true
echo
