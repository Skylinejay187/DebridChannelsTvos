# Backend v1.8.13.12 Artwork Source Pipeline

Adds row-card artwork contract fields for Android TV rows:
- rowCardUrl / landscapeCardUrl / landscapeCard4k
- rowLandscapeUrl / rowLandscape4k
- cardStillUrl / promoStillUrl
- fanartLandscapeUrl
- tvdbBackgroundUrl
- poster4k / cleanPosterUrl

Rows should use dedicated row-card/landscape/still/fanart artwork and avoid hero backdrop reuse.
External provider support is keyed by env vars for later full fetch/caching:
- TMDB_API_KEY
- FANART_TV_API_KEY
- TVDB_API_KEY

The existing poster+logo composite endpoint stays available for Performance mode.
