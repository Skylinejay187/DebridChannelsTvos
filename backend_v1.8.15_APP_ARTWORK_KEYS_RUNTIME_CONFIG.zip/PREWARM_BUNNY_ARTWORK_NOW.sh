#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://192.168.100.55:8181}"
LIMIT="${2:-240}"
SCOPE="${3:-home-live}"
echo "Queueing Bunny artwork prewarm at $BASE (limit=$LIMIT scope=$SCOPE)..."
curl -sS -X POST "$BASE/api/cdn/prewarm?limit=$LIMIT&scope=$SCOPE" | python3 -m json.tool || true
echo "Status:"
curl -sS "$BASE/api/cdn/prewarm/status" | python3 -m json.tool || true
