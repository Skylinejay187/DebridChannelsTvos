# v1.5.4 Trailer Speed/1080p Patch

- Backend now defaults trailer extraction to 1080p.
- Backend uses a fast yt-dlp direct `ytsearch1` path first to reduce trailer startup delay.
- Slower scored JSON search remains as fallback only.
- Trailer resolve timeout default reduced to 30 seconds.
- Prewarm endpoint now queues 1080p cache entries.
