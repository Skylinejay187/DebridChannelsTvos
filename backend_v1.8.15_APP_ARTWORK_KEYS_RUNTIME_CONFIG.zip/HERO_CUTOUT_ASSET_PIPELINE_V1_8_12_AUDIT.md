# Backend v1.8.12 — Hero Cutout Asset Pipeline Contract

Adds app-facing contract fields for real layered hero rendering:

- hero_backdrop / heroBackdropUrl
- hero_foreground_cutout / heroForegroundCutoutUrl
- hero_palette / heroPaletteUrl
- hero_mask_quality / heroMaskQualityUrl
- heroAssets object

Adds sidecar endpoints:

- /api/artwork/hero-assets/:id/palette.json
- /api/artwork/hero-assets/:id/mask-quality.json

Behavior:
- If upstream/catalog data provides a real transparent cutout URL, it is passed through to the Android app.
- If not, hero_foreground_cutout stays blank so the app does not fake the whole poster as a cutout.
- Palette and mask-quality sidecars are cached locally under data/hero-assets.
- CDN/proxy compatibility is preserved through existing image proxy/CDN cache routes.

No Live TV or guide/Gracenote behavior was changed.
