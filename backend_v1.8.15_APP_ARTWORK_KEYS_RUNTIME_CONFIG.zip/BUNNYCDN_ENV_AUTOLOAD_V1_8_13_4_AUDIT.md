# Debrid Channels backend v1.8.13.4 BunnyCDN env autoload audit

Base: backend v1.8.13.3 BunnyCDN artwork direct-first.

Fixes:
- Added `env_file: .env` to `api` service.
- Added `env_file: .env` to `worker` service.
- Explicitly passes Bunny/CDN variables into the `api` container so `docker exec debrid-channels-api printenv | grep -i CDN` proves they are loaded.
- Preserves Cloudflare tunnel as origin path for Bunny.
- Preserves provider-direct IPTV/Xtream/M3U/HLS streams.
- BunnyCDN remains artwork/metadata only.
- Cutout work remains paused/backlogged.

Expected proof after startup:

```bash
sudo docker exec debrid-channels-api printenv | grep -i CDN
curl "http://192.168.100.55:8181/api/cdn/status?ts=$(date +%s)"
```

Expected `/api/cdn/status`:

```json
"enabled": true
"assetBaseUrl": "https://debridchannels-assets.b-cdn.net"
```
