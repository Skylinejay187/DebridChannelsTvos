# backend_v1.8.9_LIVE_TV_INSTANT_PIPELINE

Base: backend_v1.8.8_INSTANT_HOME_PIPELINE_ANDROID_APP_v2.8.26.7_FULL.zip

Clean consolidation: preserved existing instant home, artwork cache, trailer cache, Cloudflare/tunnel files, Docker layout, and app-compatible defaults.

Added app-facing Live TV instant endpoints:
- GET /api/live/instant
- GET /api/live/categories
- GET /api/live/channels?category=&limit=
- GET /api/live/guide/now-next
- GET /api/live/guide/window?channelId=&hours=
- GET /api/live/logos/cache/:id?url=
- GET /api/live/artwork/cache/:id?url=

Design:
- Cache-first JSON shell.
- Visible-window channels only by default.
- Now/next payload split from larger guide window.
- Logo/art cache endpoints use existing persistent CDN image cache.
- Program-art prewarm is intentionally not part of Live TV startup.
- Gracenote/XMLTV/current/next text metadata remains preserved when present in cached live view.
