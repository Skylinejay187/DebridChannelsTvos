# vBRDC114 Regression Locks

1. MediaFlow Proxy ON means Live TV provider/bootstrap traffic is not allowed to bypass MediaFlow.
2. Channels DVR lineup/API, M3U, Xtream live API, XMLTV and Channels DVR/Gracenote guide fetches use the shared LiveTVSourceModel fetch path and therefore `/proxy/forward`.
3. MediaFlow Proxy OFF preserves the original direct Live TV provider requests.
4. Invalid enabled MediaFlow configuration fails closed; do not silently fall back to the remote Apple TV network.
5. Stored channel stream URLs remain provider/original URLs; actual Live TV playback and grid preview continue to use the dedicated `.liveTV` MediaFlow HLS/stream wrapper at ownership time.
6. A successfully fetched Live TV lineup/guide remains durable under the vBRDC110 commit rule and may not be discarded merely because the UI frame lane stayed busy.
7. vBRDC109 catalog single-owner transition, vBRDC107 focused preview ownership, vBRDC106 visible-only VOD rotation, vBRDC105 3s/15s Live TV preview, and vBRDC103 persistent row scrolling remain unchanged.
8. Bluetooth VOD media-control/type-check containment from vBRDC111–113 remains unchanged.
