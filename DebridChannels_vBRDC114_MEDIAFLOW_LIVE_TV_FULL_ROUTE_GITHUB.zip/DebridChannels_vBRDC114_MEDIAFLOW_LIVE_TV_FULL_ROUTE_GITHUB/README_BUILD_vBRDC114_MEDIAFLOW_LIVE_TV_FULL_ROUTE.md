# vBRDC114 — MediaFlow Live TV Full Route

Marketing version **1.0.817**, Apple build **817**. Built only from packaged vBRDC113.

## Purpose
Correct the away-from-home Live TV path when MediaFlow Proxy is enabled. vBRDC113 proxied the final Live TV playback URL, but Live TV provider/bootstrap requests (`Channels DVR`, M3U, Xtream API, XMLTV/Gracenote) were still fetched directly by the Apple TV. Private home-network endpoints therefore could not populate channels remotely.

## Change
- `LiveTVSourceModel.fetchText` now routes all configured Live TV bootstrap/API/guide GETs through `MediaFlowProxyRouter.forwardRequestIfAllowed(..., kind: .liveTV)` when MediaFlow is enabled.
- Direct behavior is unchanged when MediaFlow is off.
- MediaFlow misconfiguration fails closed; the app does not silently bypass the proxy.
- Plain-HTTP MediaFlow endpoints continue to use `PlainHTTPClient`; HTTPS MediaFlow uses the existing connectivity-aware provider session.
- Final Live TV stream playback remains on the existing `playbackURLIfAllowed(..., kind: .liveTV)` HLS/stream route.
- vBRDC110 durable Live TV publication remains intact.

No catalog scrolling, catalog open/close, VOD overlay, Bluetooth, Dynamic Wallpaper, provider credentials, or playback/resume behavior was intentionally changed.
