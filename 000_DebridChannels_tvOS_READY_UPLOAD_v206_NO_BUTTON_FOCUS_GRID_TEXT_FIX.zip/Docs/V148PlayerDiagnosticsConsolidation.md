# V148 player diagnostics consolidation

- Preserves v73 Home/detail visuals.
- Keeps legacy experimental engine code removed from active source/package/workflow references.
- Keeps KSPlayer primary and TVVLCKit/VLC fallback.
- Adds a lightweight diagnostics panel for HW Decode, Render Backend, Decoder, FPS, Dropped Frames, and Active Engine.
- Keeps movie-loading animation and minimal VOD overlay.
