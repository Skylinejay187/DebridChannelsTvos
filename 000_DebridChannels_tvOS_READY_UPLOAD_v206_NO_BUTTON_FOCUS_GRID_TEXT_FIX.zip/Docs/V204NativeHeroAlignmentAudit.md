# V204 Native Hero + Right Row Alignment Audit

Base: v203.

Changes:
- Replaced custom hand-driven slot hero offset animation with a native SwiftUI/tvOS default transition.
- Removed the hidden previous-card offset/fade state that kept the hero feeling like the old custom scroll path.
- Fixed the top-right first card alignment issue: the first right-side poster slot had `SafeCardScrollMotion(isFocused: slot == 1...)`, which permanently raised/scaled slot 1 even when it was not actually focused.
- Right-side poster cards now keep identical y-position and size so the first top row card aligns with the rest of the row.
- Preserved v203 menu/search behavior and Live TV grid fit work.
