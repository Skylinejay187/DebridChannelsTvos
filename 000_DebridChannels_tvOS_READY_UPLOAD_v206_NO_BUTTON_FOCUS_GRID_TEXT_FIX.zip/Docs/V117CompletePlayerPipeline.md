# v117 Complete Player Pipeline

This is the careful player completion pass requested after v116.

Included:
- Dolby Vision/HDR-aware profile detection before playback.
- Apple Native AVKit/AVFoundation remains first for HLS/MP4/MOV/HEVC/HDR/Dolby Vision Profile 5/8-style streams to preserve Apple TV hardware decode, frame pacing, and HDR/DV metadata.
- MKV/Profile 7/DTS/TrueHD/WebM/VP9/AV1-style hints route to embedded TVVLCKit when compiled, because those are not consistently Apple-native.
- AVURLAsset pipeline keeps identity encoding, video-friendly Accept headers, byte-range request hint, isPlayable validation, track/characteristic inspection, no bitrate cap, 4096x2160 preferred max resolution, and larger high-bitrate buffer.
- Allows Apple-native late-bound video track startup for Apple containers/DV streams instead of wrongly rejecting streams whose tracks are exposed late by CDN/debrid servers.
- Keeps Infuse/VLC/SenPlayer external handoff as a backup.
- Preserves v73 Home/detail visuals and the Apple-style VOD overlay.

Honest limitation:
No tvOS app can make AVFoundation decode a codec/profile Apple does not support. The completion architecture is dual-engine internal playback: Apple Native for Apple-supported 4K/HDR/DV, TVVLCKit for unsupported containers/codecs, with external players preserved.
