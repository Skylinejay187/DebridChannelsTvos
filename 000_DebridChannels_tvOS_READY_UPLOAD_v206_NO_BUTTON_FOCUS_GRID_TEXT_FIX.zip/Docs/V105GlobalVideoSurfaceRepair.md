# V105 Global Video Surface Repair

Fixes black-screen playback where every direct link reached the player but no video picture rendered.

Changes:
- AVFoundation playback now renders through AVPlayerViewController with showsPlaybackControls=false for a reliable tvOS video layer while preserving the custom Debrid Channels overlay.
- Keeps fallback AVPlayerLayer surface in source with explicit layout frame handling.
- Forces UniversalVideoSurface to occupy full screen instead of relying on implicit UIViewRepresentable sizing.
- Tightens VLC preference matching so URLs that merely mention mkv in unrelated text are not all routed as codec fallback.
