# v120 TVVLCKit Embed Verify

This build fixes the practical problem where the IPA stayed small and TVVLCKit was not actually embedded.

Changes:
- Builds only from `DebridChannelsTVOS.xcworkspace` after `pod install`.
- Verifies `Podfile.lock` and `Pods/Manifest.lock` contain TVVLCKit.
- Verifies a TVVLCKit/VLCKit framework exists inside the built `.app` bundle before packaging.
- Refuses to upload a small broken IPA if the framework is missing.
- Keeps v73 visuals and v117/v118 player pipeline.
