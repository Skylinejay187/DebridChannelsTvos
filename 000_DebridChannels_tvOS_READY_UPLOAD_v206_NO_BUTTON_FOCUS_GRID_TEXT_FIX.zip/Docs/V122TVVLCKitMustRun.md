# v122 TVVLCKit Must-Run Workflow

This package contains a workflow identity guard. The GitHub Actions log must show:

DEBRID CHANNELS TVOS V122 WORKFLOW IS RUNNING

If that text is missing, GitHub is not running the workflow from this ZIP.

The workflow refuses to upload an IPA under 50MB and refuses packaging when TVVLCKit/VLC files are not embedded in the .app.
