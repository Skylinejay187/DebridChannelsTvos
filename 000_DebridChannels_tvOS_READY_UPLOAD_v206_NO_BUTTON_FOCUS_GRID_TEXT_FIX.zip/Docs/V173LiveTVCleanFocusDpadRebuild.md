# V173 Live TV Clean Focus / DPAD Rebuild

- Rebuilt Live TV DPAD routing from the v172 source base.
- Removed hidden offscreen DPAD capture button and duplicate focus redirection.
- Restored real tvOS focus targets on grid tiles and guide rows.
- Kept native focus/hit testing alive while relying on Debrid Channels custom cyan/purple focus styling.
- Preserved RIGHT-to-guide behavior only from the last card in each row.
- Preserved Channels DVR/M3U/XMLTV/Xtream endpoint wiring and Gracenotes-style logo matching.
- Updated visible build markers to v173.
