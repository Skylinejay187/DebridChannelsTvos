# v112 Dual Engine Apple VOD Overlay

Base: v111 external player compile fix, preserving the v73 approved Home and media-detail visuals.

Changes:
- Added a true dual internal render path: Apple Native AVKit/AVFoundation and embedded TVVLCKit/libVLC when the pod/framework is present.
- The Debrid Channels VOD overlay is shared over both internal engines.
- Added manual Apple/VLC engine controls inside the overlay.
- Apple Native remains preferred for HLS/MP4/MOV/HEVC/HDR/Dolby Vision hardware playback.
- VLC Internal is available for MKV/DTS/TrueHD/odd container fallback when TVVLCKit compiles into the IPA.
- External player handoff remains available for Infuse, VLC App, and SenPlayer.
- Rebuilt the VOD overlay with a new Apple-style glass layout, poster, title, metadata, rating badge, engine badge, progress bar, and cleaner rounded controls.
- v73 Home/detail layouts are intentionally untouched.
