# V183 VOD Bootstrap Autostart Fix

This build separates Live TV playback startup from VOD cache-backed playback startup.

- Live TV remains direct TS/HLS playback with the temporary VOD cache disabled.
- VOD now waits for the temporary localhost cache proxy to exist and for playable bytes to be written before handing the URL to KSPlayer/VLC.
- This prevents the black-screen startup state where the player had to be woken by Pause/Play or by waiting for the cache to fill.
- HLS/non-cacheable VOD still starts directly.
- Build marker updated to V183.
