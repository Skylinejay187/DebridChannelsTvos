# v116 Native Pipeline Careful Rebuild

Careful playback rebuild focused on Apple Native internal playback stability.

- Keeps v73 Home/detail visuals frozen.
- Keeps Apple-style VOD overlay from v112.
- Starts playback through AVURLAsset preparation instead of raw URL handoff.
- Loads isPlayable and tracks before creating the visible AVPlayer.
- Rejects audio-only native assets before black-screen playback begins.
- Uses identity encoding and video-friendly Accept headers for debrid/CDN streams.
- Uses no peak bitrate cap and preferred 3840x2160 max resolution.
- Uses a 90 second forward buffer for high-bitrate streams.
- Keeps VLC Internal and external player handoff available, but focuses this pass on fixing Apple Native.
