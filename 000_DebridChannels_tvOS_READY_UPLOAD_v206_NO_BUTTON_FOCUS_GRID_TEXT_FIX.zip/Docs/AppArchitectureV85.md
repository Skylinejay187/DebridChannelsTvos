import Foundation
import SwiftUI
import AVFoundation

// DEBRID_CHANNELS_TVOS_BUILD_V85_FULL_1_TO_8_PASS
// This file documents and anchors the v85 architecture pass so future builds do not stack patches.
// v73 Home/detail geometry remains the frozen visual baseline.

enum DebridBuildMarkerV85 {
    static let marker = "DEBRID_CHANNELS_TVOS_BUILD_V85_FULL_1_TO_8_PASS"
    static let visualBaseline = "v73 Home/detail layout frozen"
}

@MainActor
final class NavigationCoordinatorV85: ObservableObject {
    @Published var detailStack: [MediaItem] = []
    @Published var activeDetail: MediaItem? = nil
    @Published var playerItem: MediaItem? = nil
    @Published var playerURL: URL? = nil

    func openDetail(_ item: MediaItem, pushCurrent: Bool) {
        if pushCurrent, let activeDetail { detailStack.append(activeDetail) }
        if !pushCurrent { detailStack.removeAll() }
        activeDetail = item
    }

    func backFromDetail() {
        activeDetail = detailStack.popLast()
    }

    func openPlayer(item: MediaItem, url: URL) {
        playerItem = item
        playerURL = url
    }

    func closePlayer() {
        playerURL = nil
        playerItem = nil
    }
}

struct CodecStrategyV85 {
    enum Backend: String { case avFoundationPrimary, libVLCBinaryFallback, ffmpegProbeFallback }

    static func preferredBackend(for url: URL) -> Backend {
        let lower = url.absoluteString.lowercased()
        if lower.contains(".mkv") || lower.contains("dts") || lower.contains("truehd") || lower.contains("vc-1") {
            return .libVLCBinaryFallback
        }
        if lower.contains(".m3u8") || lower.contains(".mp4") || lower.contains(".mov") || lower.contains(".m4v") || lower.contains("/hls/") {
            return .avFoundationPrimary
        }
        return .ffmpegProbeFallback
    }

    static let note = "v85 keeps AVFoundation as the shipping tvOS player core and defines the binary fallback boundary for libVLC/FFmpeg. The fallback libraries must be added as compiled tvOS frameworks in a future dependency build; they are not faked in Swift code."
}
