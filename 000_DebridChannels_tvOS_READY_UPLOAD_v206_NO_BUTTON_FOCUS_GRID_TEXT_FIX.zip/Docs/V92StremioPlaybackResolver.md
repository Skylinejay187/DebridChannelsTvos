# v92 Stremio/TorBox resolver pass

- Normalizes `/configure` addon links to `/manifest.json` candidates when possible.
- Scans all configured manifests and all stream type/id candidates.
- Treats signed HTTP(S) `stream.url` values as direct-playable even when they have no file extension.
- Keeps non-direct/magnet/infoHash results visible but does not falsely claim they are playable without a backend/debrid resolver.
- Adds clearer diagnostics for Torrentio/TorBox configured-manifest requirements.
