# v162 VOD DPAD / Progress / Cache Fix

Careful continuation from v161.

Changes:
- Rebuilt VOD control interaction so the player shell owns Select/DPAD routing.
- Removed native Button focus from VOD control chips to stop tvOS double-moving focus and skipping two buttons.
- Select now activates the currently highlighted control exactly once.
- UP/DOWN reveal controls and keep them visible for navigation.
- Started the playback clock for KSPlayer/VLC surfaces so runtime progress advances during internal playback.
- Cache progress now advances with playback progress instead of remaining static.
- Preserved KSPlayer primary, VLC fallback, MPV removal, v73 visuals, and existing VOD overlay layout.
