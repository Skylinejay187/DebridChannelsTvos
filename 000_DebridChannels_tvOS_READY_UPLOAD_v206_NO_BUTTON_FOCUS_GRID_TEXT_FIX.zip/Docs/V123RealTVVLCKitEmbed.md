# v123 Real TVVLCKit Embed

This build stops relying on CocoaPods auto-embedding and vendors the official VideoLAN TVVLCKit binary during GitHub Actions before XcodeGen runs.

The workflow:
1. Runs Carthage against VideoLAN's official `Packaging/TVVLCKit.json` binary definition.
2. Copies the downloaded framework into `Vendor/TVVLCKit`.
3. Injects the actual framework path into `project.yml`.
4. Links and embeds TVVLCKit directly in the tvOS target.
5. Refuses to package if the app/IPA is still too small to contain VLC.

Expected result: IPA should be much larger than the previous small AVFoundation-only IPA, typically in the 100MB+ range depending on the TVVLCKit binary payload.
