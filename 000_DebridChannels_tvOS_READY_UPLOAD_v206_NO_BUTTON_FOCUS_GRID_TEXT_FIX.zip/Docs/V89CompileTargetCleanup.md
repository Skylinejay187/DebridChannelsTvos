# v89 Compile Target Cleanup

Purpose: fix GitHub Actions exit code 65 caused by generated architecture/audit Swift files being compiled into the tvOS target.

Changes:
- Only three Swift files are included in the app target: CatalogStore.swift, DebridChannelsTVOSApp.swift, RemoteImageFit.swift.
- V84/V85/V86/V88 architecture/audit files were moved out of Sources into Docs as non-compiling markdown references.
- Unreferenced V85 architecture prototype Swift modules were moved out of the target to avoid duplicate symbols and target pollution.
- Build marker updated to DEBRID_CHANNELS_TVOS_BUILD_V89_COMPILE_TARGET_CLEANUP.
- v73 visual baseline and v88 runtime behavior are preserved.
