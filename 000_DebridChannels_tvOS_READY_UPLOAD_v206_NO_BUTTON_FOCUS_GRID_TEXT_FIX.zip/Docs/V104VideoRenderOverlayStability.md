# v104 Video Render + Overlay Stability

- Keeps VOD controls visible while paused; auto-hide is disabled when paused/loading/error/panel-open.
- Adds AVFoundation render watchdog: if stream opens but no video frames/presentation size appear, retry next direct link instead of sitting on a black screen.
- Cancels watchdog/hide tasks on teardown.
- Updates build marker to v104.
- Preserves v73 visual baseline and v103 custom VOD controls.
