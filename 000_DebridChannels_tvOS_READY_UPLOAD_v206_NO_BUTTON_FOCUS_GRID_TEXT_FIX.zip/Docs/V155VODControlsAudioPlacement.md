# v155 VOD Controls / Audio / Placement Repair

Base: v154 KSPlayer cadence stability line.

Changes:
- Preserved smooth v154 KSPlayer/VLC playback cadence work.
- Converted VOD overlay controls to parent-owned manual DPAD focus so tvOS native focus and custom routing do not double-skip two controls at a time.
- Added separate DPAD move debounce for player controls.
- Increased overlay auto-hide delay and keeps controls visible while navigating.
- Reinforced English audio preference for KSPlayer/FFmpeg options and late track selection.
- Media information box moved farther right and lower per latest projector screenshot.
- MPV remains fully removed.
- v73 Home/detail visual baseline preserved.
