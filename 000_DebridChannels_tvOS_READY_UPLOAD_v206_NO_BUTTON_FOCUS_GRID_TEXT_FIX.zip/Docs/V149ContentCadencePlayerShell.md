# v149 Content Cadence Player Shell

- Preserves v73 Home/detail visuals.
- Keeps MPV fully removed.
- Keeps KSPlayer primary and VLC fallback.
- Moves diagnostics off the active playback hot path so it does not redraw over every playing frame.
- Replaces fake “60 hinted” diagnostics with content-cadence inference such as 23.976/24 target.
- Reduces overlay chrome opacity and hides the overlay faster while playing.
- Tunes VLC to drop late frames/skip frames when necessary so playback catches up instead of running slow.
- Reduces KSPlayer buffering latency and adds low-delay/framedrop hints.
