# v177 Live TV large guide + manual source cleanup

- Removed Channels DVR Auto Scan and HDHomeRun Auto Scan settings from the visible Live TV source setup.
- Live TV now loads only explicitly configured manual sources: Channels DVR base URL, HDHomeRun manual lineup URL, HDHomeRun/XMLTV guide URL, M3U, XMLTV, and Xtream.
- Kept Channels DVR endpoint normalization for `http://IP:8089` and exact DVR endpoints: `/devices/ANY/channels.m3u`, `/devices/ANY/guide/xmltv?duration=86400`, `/devices/ANY/guide/xmltv`, `/devices`, `/devices/{device}/channels`, and `/dvr/lineups`.
- Stabilized large lineup guide layout by clamping guide rows to fixed-width visible program cells instead of allowing long XMLTV durations to overflow across the screen.
- Added stronger XMLTV/Gracenotes matching through `tvc-guide-stationid` priority, numeric station-id fallback, XMLTV icon backfill, and base-relative logo normalization.
- Restored Live TV click-to-play on focused grid/guide rows while preserving cache-disabled TS/HLS direct playback.
