# V185 Live TV cache, Google-style guide, VOD autostart cleanup

- Keeps the loaded Live TV lineup in memory for the current app session and only refreshes after a 3-hour TTL or app restart.
- Stops reloading Channels DVR/M3U/XMLTV/Xtream every time the user leaves and re-enters Live TV.
- Rebuilds the guide into a side-rail-free Google-TV-style timeline with large program hero, black glass rows, and a red current-time marker.
- Leaves category control in the top rail only; no guide side bar is rendered.
- Starts VOD playback immediately and lets the temporary disk cache warm in the background so movies/shows do not require pause/play wake-up.
- Live TV remains direct TS/HLS playback with VOD cache disabled.
- Includes the supplied Debrid Channels launcher logo artwork in Resources for the app asset pipeline.
