# V136 KSPlayer Overlay/Tracks/Smoothing

- Preserves v73 Home/detail visuals.
- Keeps KSPlayer as primary internal engine and VLC as fallback.
- Hides KSPlayer native chrome/control subviews so only Debrid VOD overlay is visible.
- Debrid overlay hit testing now disables when auto-hidden and auto-hide is explicitly started on appear.
- Player control buttons remain custom Debrid controls.
- KSPlayer options prefer KSMEPlayer/FFmpeg first, VideoToolbox hardware decode, smaller buffer window to reduce slow-frame/choppy playback, English audio preference, and embedded subtitles default off.
