# v180 Live TV Google Guide + Gracenotes + Center Click Fix

- Preserves the v179 single-step DPAD ownership fix.
- Restores centered Select/OK playback actions on focused grid and guide rows.
- Changes RIGHT-edge guide launch so landing on the last card does not instantly open the guide; a second RIGHT edge press opens guide intentionally.
- Prevents guide exit from category rail unless focus is on All, while guide-row LEFT can still return to the grid.
- Adds XMLTV programme icon extraction for Gracenotes-style top preview artwork.
- Updates the Live TV guide preview toward a Google-TV-style black glass hero + programme structure.
