# v164 Live TV Gracenotes-style Guide Start

- Replaces placeholder Live TV page with Channels DVR-inspired Live TV screen.
- Adds top category rail, Gracenotes-style channel boxes, focusable channel tiles, and RIGHT-to-open guide behavior.
- Adds full guide view with left category list, channel preview area, time columns, and program blocks.
- This is a visual/native start pass with mock guide data; backend IPTV/Channels DVR XMLTV wiring remains the next step.
