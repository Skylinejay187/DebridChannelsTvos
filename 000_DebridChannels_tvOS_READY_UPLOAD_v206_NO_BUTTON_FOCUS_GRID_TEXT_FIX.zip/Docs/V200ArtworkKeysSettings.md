# v200 Artwork Keys Settings

Base: v199 REAL_SLOT_HERO_TRANSPARENT_FOCUS.

Changes:
- Adds Settings fields for backend URL, TMDB API key, Fanart.tv API key, and TVDB API bearer token.
- Adds a "Save Artwork Keys To Backend" action.
- Preserves Live TV manual sources, slot hero behavior, transparent focus, and current playback stack.
- Adds Apple TV default menu behavior where focusing a top menu item switches sections automatically.

Backend contract used:
- POST /api/artwork/provider-keys
- GET /api/artwork/provider-keys/status
