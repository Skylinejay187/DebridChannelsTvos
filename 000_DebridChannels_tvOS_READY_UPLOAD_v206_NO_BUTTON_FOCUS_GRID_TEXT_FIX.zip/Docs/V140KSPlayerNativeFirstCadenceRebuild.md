# V140 KSPlayer Native-First Cadence Rebuild

Base: v138 KSPlayer/VLC line.

Goals:
- Preserve approved v73 Home/detail visuals.
- Keep KSPlayer as primary internal engine and VLC/TVVLCKit as fallback.
- Avoid broad risky playback changes.
- Improve frame cadence by trying KSPlayer Apple-native path first, then KSPlayer FFmpeg/Metal path second.
- Keep Debrid Channels overlay as the only visible VOD overlay.
- Preserve English audio preference and subtitles off by default.

Changes:
- KSOptions first player type changed to KSAVPlayer for Apple-native cadence where compatible.
- KSMEPlayer remains second player type for FFmpeg/Metal fallback.
- Buffer window increased carefully for high-bitrate streams.
- Build markers updated to v140.

Notes:
- This does not force tvOS Match Frame Rate when the user disables it in Apple TV settings.
- It should reduce unnecessary FFmpeg/Metal cadence issues on streams that KSPlayer can handle through the Apple-native path.
