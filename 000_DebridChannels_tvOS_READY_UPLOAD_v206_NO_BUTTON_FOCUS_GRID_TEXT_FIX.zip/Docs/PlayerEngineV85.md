import Foundation
import AVFoundation
import Combine

@MainActor
final class PlayerEngineV85: ObservableObject {
    @Published var player: AVPlayer? = nil
    @Published var isLoading = false
    @Published var isPlaying = false
    @Published var errorText: String? = nil
    @Published var currentSeconds: Double = 0
    @Published var durationSeconds: Double = 0
    @Published var selectedCodecBackend: CodecStrategyV85.Backend = .avFoundationPrimary

    private var timeObserver: Any?
    private var statusObserver: NSKeyValueObservation?
    private var endObserver: NSObjectProtocol?

    func load(url: URL, autoplay: Bool = true) {
        teardown()
        selectedCodecBackend = CodecStrategyV85.preferredBackend(for: url)
        isLoading = true
        errorText = nil
        let item = AVPlayerItem(url: url)
        let av = AVPlayer(playerItem: item)
        player = av

        statusObserver = item.observe(\.status, options: [.new, .initial]) { [weak self, weak av] observedItem, _ in
            Task { @MainActor in
                guard let self else { return }
                switch observedItem.status {
                case .readyToPlay:
                    self.isLoading = false
                    let seconds = CMTimeGetSeconds(observedItem.duration)
                    self.durationSeconds = seconds.isFinite ? seconds : 0
                    if autoplay { av?.play(); self.isPlaying = true }
                case .failed:
                    self.isLoading = false
                    self.errorText = observedItem.error?.localizedDescription ?? "The selected stream could not be played."
                default:
                    break
                }
            }
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self, weak av] time in
            guard let self else { return }
            self.currentSeconds = CMTimeGetSeconds(time).isFinite ? CMTimeGetSeconds(time) : 0
            if let duration = av?.currentItem?.duration {
                let seconds = CMTimeGetSeconds(duration)
                if seconds.isFinite { self.durationSeconds = seconds }
            }
            self.isPlaying = av?.timeControlStatus == .playing
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: item, queue: .main) { [weak self] _ in
            self?.isPlaying = false
        }
    }

    func togglePlay() {
        guard let player else { return }
        if player.timeControlStatus == .playing { player.pause(); isPlaying = false } else { player.play(); isPlaying = true }
    }

    func seek(by seconds: Double) {
        guard let player else { return }
        let target = max(0, CMTimeGetSeconds(player.currentTime()) + seconds)
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
    }

    func teardown() {
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        statusObserver?.invalidate()
        statusObserver = nil
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        player?.pause()
        player = nil
        isPlaying = false
        isLoading = false
    }
}
