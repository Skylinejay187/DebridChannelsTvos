# V175 Live TV Auto Scan + HDHomeRun/DVR Source Restore

Base: v174 Android guide resolver port.

Changes:
- Added tvOS Settings toggles for Channels DVR Auto Scan and HDHomeRun Auto Scan.
- Added HDHomeRun manual lineup override field supporting base URLs, /lineup.json, /lineup.m3u, /lineup.xml, and /discover.json.
- Added HDHomeRun manual XMLTV/Gracenotes guide override toggle and guide URL field.
- Manual sources remain honored even when auto-scan is off.
- Channels DVR auto scan probes saved/base server paths and persists the working base for guide XMLTV loading.
- HDHomeRun auto scan uses my.hdhomerun.com discovery and loads discovered lineup JSON into the Live TV grid and guide resolver.
- HDHomeRun manual XMLTV guide backfills logos/program guide data using the existing Android-ported XMLTV matching logic.
- Preserves v173 invisible tvOS focus target system and v174 guide resolver matching.

Audit notes:
- VOD cache remains disabled for Live TV playback.
- Existing M3U/XMLTV/Xtream paths remain additive and were not removed.
- Build marker updated to v175.
