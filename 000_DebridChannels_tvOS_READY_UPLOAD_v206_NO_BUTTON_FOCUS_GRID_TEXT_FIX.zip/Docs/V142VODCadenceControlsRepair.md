# v142 VOD Cadence + Controls Repair

Base: v141 KSPlayer tvOS compile fix.

Changes:
- Avoids mounting the glass VOD chrome background while controls are hidden during playback.
- Restores KSPlayer play/pause state handoff.
- Keeps VLC selectable and removes v130 risky hardware decode forcing.
- Reinforces English audio preference and subtitles-off defaults for KSPlayer and VLC options.
- Preserves v73 Home/detail visuals and v141 package structure.
