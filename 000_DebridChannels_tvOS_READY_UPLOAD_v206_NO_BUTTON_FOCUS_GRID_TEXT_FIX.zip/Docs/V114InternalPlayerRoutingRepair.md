# v114 Internal Player Routing Repair

- Fixes the real issue left after TVVLCKit packaging: unsupported containers were still opened by Apple Native first.
- Adds preflight engine selection so MKV/DTS/TrueHD/Profile 7/WebM/TS-style hints route directly to VLC Internal when compiled.
- Keeps MP4/M4V/MOV/HLS on Apple Native for hardware decode/HDR/Dolby Vision.
- Reduces overlay redraw during 4K playback by removing repeating bitrate text updates from the 0.5s timer.
- Keeps aspect-fit default and the v73 visual baseline.
