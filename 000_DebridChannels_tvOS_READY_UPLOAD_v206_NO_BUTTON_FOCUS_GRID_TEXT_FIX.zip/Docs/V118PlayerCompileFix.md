# V118 Player Compile Fix

Fixed tvOS compile failure by moving `appliesMediaSelectionCriteriaAutomatically` from `AVPlayerItem` to `AVPlayer`, where it is available. Preserves v117 complete player pipeline behavior.
