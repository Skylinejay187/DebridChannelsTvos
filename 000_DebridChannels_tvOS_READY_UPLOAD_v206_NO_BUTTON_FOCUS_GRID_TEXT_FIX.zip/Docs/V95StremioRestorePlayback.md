# v95 Stremio Restore + Playback

Regression fix after v94 codec fallback packaging.

- Restores robust Stremio JSON/addon loading.
- Accepts https and stremio:// addon URLs.
- Normalizes configure links to manifest candidates when possible.
- Preserves Cinemeta metadata manifest so stream-only addons such as Torrentio/TorBox still have browsable media IDs.
- Treats streaming-only manifests as valid active addons even when they add no Home rows.
- Keeps TVVLCKit/libVLC fallback boundary from v94.
