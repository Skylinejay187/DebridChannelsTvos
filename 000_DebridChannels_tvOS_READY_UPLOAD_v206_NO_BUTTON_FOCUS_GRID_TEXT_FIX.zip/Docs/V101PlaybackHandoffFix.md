# v101 Playback Handoff Fix

- Selected stream chips now start playback with all direct playable alternates armed for adaptive retry.
- Stremio `externalUrl` browser handoff links are no longer misclassified as direct-playable streams.
- Debrid/TorBox signed HTTP URLs are normalized before AVFoundation handoff.
- AVFoundation assets now include basic HTTP headers for direct CDN/debrid streams.
- VLC preference is narrowed to MKV/DTS/TrueHD-style edge cases so Apple-native HEVC/EAC3/HLS/MP4 paths are still attempted normally.
