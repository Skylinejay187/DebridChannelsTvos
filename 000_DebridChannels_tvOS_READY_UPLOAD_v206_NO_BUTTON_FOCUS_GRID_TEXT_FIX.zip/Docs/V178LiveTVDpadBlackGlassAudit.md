# v178 Live TV DPAD + black-glass cleanup

- Reworked Settings DPAD route debounce to stop double-step movement when one remote press is received.
- Retuned Live TV guide/grid DPAD debounce to one intentional step per press.
- Removed duplicate tile focus assignment that could cause paired focus updates.
- Replaced purple Live TV guide/grid surfaces with a black-glass treatment while preserving cyan focus styling.
- Kept manual Channels DVR/M3U/XMLTV/Xtream source behavior and live playback cache-disabled.
