# V154 KSPlayer Cadence Stability Rebuild

- Preserves v73 Home/detail visuals.
- MPV remains fully removed.
- KSPlayer remains primary; TVVLCKit/VLC remains fallback.
- Removes aggressive low-latency FFmpeg flags (`nobuffer`, `low_delay`, forced framedrop) that can cause slow/juddery tvOS VOD playback.
- Increases stable buffer/probe windows for high-bitrate 1080p/4K files.
- Re-applies layout/tracks without repeatedly calling play after startup.
- Keeps diagnostics off the hot playback path while video is actively playing.
