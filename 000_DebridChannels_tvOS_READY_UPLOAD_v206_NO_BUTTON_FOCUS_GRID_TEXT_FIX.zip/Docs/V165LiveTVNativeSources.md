# v165 Live TV Native Sources

Base: v164 Live TV guide start.

Added native Live TV source loading paths based on the uploaded Android/NewtoOld source:

- Channels DVR manual base URL support.
- Channels DVR endpoints: `/status`, `/devices`, `/devices/ANY/channels.m3u?format=ts&codec=copy`, `/devices/ANY/channels.m3u?format=ts`, `/devices/{device}/channels`, `/devices/{device}/channels/{channel}/stream.mpg?format=ts&codec=copy`, `/devices/ANY/guide/xmltv?duration=43200`, `/dvr/lineups`.
- M3U playlist parsing with tvg-id, tvg-name, tvg-logo, tvg-chno/channel-number, group-title.
- XMLTV guide matching for DVR/M3U channels.
- Xtream Codes loading via `player_api.php?action=get_live_categories` and `player_api.php?action=get_live_streams`, with playback URLs under `/live/{user}/{pass}/{stream_id}.{ext}`.
- Cached lineup persistence for faster reopen.
- Channels-style grid + full guide remains visually based on v164.

Preserved: KSPlayer/VLC VOD stack, MPV removal, temp VOD cache, v73 Home/detail visual baseline.
