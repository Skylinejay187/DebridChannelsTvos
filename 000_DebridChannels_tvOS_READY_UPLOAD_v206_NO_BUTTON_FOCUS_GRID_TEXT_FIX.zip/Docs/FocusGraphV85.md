import SwiftUI

// Explicit DPAD graph primitives used by v85 screens. These avoid relying on random tvOS focus guessing.
protocol DPadRoutableNode: Hashable {}

enum PlayerFocusNodeV85: Hashable, DPadRoutableNode {
    case back10, playPause, forward10, audio, subtitles, episodes, zoom, settings, close

    func move(_ direction: MoveCommandDirection) -> PlayerFocusNodeV85 {
        let nodes: [PlayerFocusNodeV85] = [.back10, .playPause, .forward10, .audio, .subtitles, .episodes, .zoom, .settings, .close]
        guard let index = nodes.firstIndex(of: self) else { return .playPause }
        switch direction {
        case .left: return nodes[(index - 1 + nodes.count) % nodes.count]
        case .right: return nodes[(index + 1) % nodes.count]
        default: return self
        }
    }
}

enum DetailFocusNodeV85: Hashable, DPadRoutableNode {
    case topMenu
    case play, trailer, findLinks, close
    case searchLinks
    case stream(Int)
    case related(Int)
}
