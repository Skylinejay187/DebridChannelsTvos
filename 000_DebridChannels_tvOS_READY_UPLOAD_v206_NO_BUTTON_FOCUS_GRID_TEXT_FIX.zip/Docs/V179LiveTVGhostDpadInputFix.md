# v179 Live TV ghost DPAD input fix

Base: v178 black-glass Live TV branch.

Changes:
- Removed Settings manual DPAD routing so the native tvOS focus engine owns Settings movement once.
- Reworked Live TV movement so normal grid and guide navigation are not manually advanced on top of native focus movement.
- Kept only special app transitions in Live TV: RIGHT from the last grid card opens the guide, LEFT from the guide returns to the grid.
- Added select debounce for Live TV play actions so Button/select and play/pause events cannot double-launch playback.
- Removed duplicate grid Button plus onTapGesture handling.
- Preserved black-glass theme, manual DVR/M3U/XMLTV/Xtream source paths, Live TV cache-disabled playback, and invisible/native focus target behavior.
