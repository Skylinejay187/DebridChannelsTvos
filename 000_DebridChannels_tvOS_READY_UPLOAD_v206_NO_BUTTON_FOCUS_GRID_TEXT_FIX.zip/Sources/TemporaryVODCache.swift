import Foundation
import Network
import SwiftUI

/// Temporary watch-session cache for Debrid Channels VOD playback.
///
/// This is intentionally not a download library and it does not persist media after playback.
/// It starts a background writer when a movie/episode starts, exposes a localhost byte-range
/// proxy URL to the player, serves already-cached bytes while the writer continues downloading,
/// and deletes the temp file when the VOD screen exits.
@MainActor
final class TemporaryVODCacheSession: ObservableObject {
    @Published var playbackURL: URL?
    @Published var cachedBytes: Int64 = 0
    @Published var totalBytes: Int64?
    @Published var limitBytes: Int64?
    @Published var statusText: String = "Cache idle"
    @Published var isProxyActive: Bool = false

    private var proxy: VODLocalCacheProxy?

    func start(originURL: URL, limitGB: Int) {
        stopAndDelete()
        guard originURL.scheme?.lowercased().hasPrefix("http") == true else {
            statusText = "Cache bypassed for non-HTTP stream"
            playbackURL = originURL
            return
        }
        if originURL.pathExtension.lowercased() == "m3u8" || originURL.absoluteString.lowercased().contains(".m3u8") {
            // HLS is already segmented and managed by the engine; this temp cache proxy is for direct file streams.
            statusText = "HLS uses engine-managed segment cache"
            playbackURL = originURL
            return
        }

        let limit: Int64? = limitGB == -1 ? nil : Int64(limitGB) * 1_073_741_824
        limitBytes = limit
        statusText = "Starting temporary disk cache…"

        let newProxy = VODLocalCacheProxy(originURL: originURL, limitBytes: limit)
        newProxy.onProgress = { [weak self] cached, total, state in
            Task { @MainActor in
                self?.cachedBytes = cached
                self?.totalBytes = total
                self?.statusText = state
            }
        }
        newProxy.onReady = { [weak self] proxyURL in
            Task { @MainActor in
                self?.playbackURL = proxyURL
                self?.isProxyActive = true
                self?.statusText = "Caching ahead to disk"
            }
        }
        proxy = newProxy
        newProxy.start()
    }

    func stopAndDelete() {
        proxy?.stop(deleteFile: true)
        proxy = nil
        playbackURL = nil
        cachedBytes = 0
        totalBytes = nil
        isProxyActive = false
        statusText = "Cache cleared"
    }

    var progress: Double {
        let denominator: Int64
        if let totalBytes, totalBytes > 0 {
            denominator = min(totalBytes, limitBytes ?? totalBytes)
        } else if let limitBytes, limitBytes > 0 {
            denominator = limitBytes
        } else {
            // Unknown unlimited stream/file size: show progress as indeterminate until headers arrive.
            return 0
        }
        guard denominator > 0 else { return 0 }
        return min(max(Double(cachedBytes) / Double(denominator), 0), 1)
    }

    var usedGB: Double { Double(cachedBytes) / 1_073_741_824.0 }
    var totalGB: Double? { totalBytes.map { Double($0) / 1_073_741_824.0 } }
}

final class VODLocalCacheProxy: NSObject, URLSessionDataDelegate {
    let originURL: URL
    let limitBytes: Int64?
    var onProgress: ((Int64, Int64?, String) -> Void)?
    var onReady: ((URL) -> Void)?

    private let queue = DispatchQueue(label: "DebridChannels.VODLocalCacheProxy", qos: .userInitiated)
    private var listener: NWListener?
    private var task: URLSessionDataTask?
    private var session: URLSession?
    private var fileHandle: FileHandle?
    private var cacheFileURL: URL
    private var cachedBytes: Int64 = 0
    private var totalBytes: Int64?
    private var isDownloadComplete = false
    private var isStopped = false

    init(originURL: URL, limitBytes: Int64?) {
        self.originURL = originURL
        self.limitBytes = limitBytes
        let dir = FileManager.default.temporaryDirectory
            .appendingPathComponent("DebridChannelsVODCache", isDirectory: true)
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        self.cacheFileURL = dir.appendingPathComponent("stream.cache")
        FileManager.default.createFile(atPath: self.cacheFileURL.path, contents: nil)
        super.init()
    }

    func start() {
        startServer()
        startDownload()
    }

    func stop(deleteFile: Bool) {
        queue.async {
            self.isStopped = true
            self.task?.cancel()
            self.task = nil
            self.session?.invalidateAndCancel()
            self.session = nil
            self.listener?.cancel()
            self.listener = nil
            try? self.fileHandle?.close()
            self.fileHandle = nil
            if deleteFile {
                let root = self.cacheFileURL.deletingLastPathComponent()
                try? FileManager.default.removeItem(at: root)
            }
        }
    }

    private func startServer() {
        do {
            let listener = try NWListener(using: .tcp, on: .any)
            listener.newConnectionHandler = { [weak self] connection in
                self?.handle(connection: connection)
            }
            listener.stateUpdateHandler = { [weak self] state in
                guard let self else { return }
                switch state {
                case .ready:
                    if let port = listener.port {
                        let url = URL(string: "http://127.0.0.1:\(port.rawValue)/vod-cache")!
                        self.onReady?(url)
                    }
                case .failed(let error):
                    self.onProgress?(self.cachedBytes, self.totalBytes, "Cache proxy failed: \(error.localizedDescription)")
                default: break
                }
            }
            self.listener = listener
            listener.start(queue: queue)
        } catch {
            onProgress?(cachedBytes, totalBytes, "Cache proxy failed to start: \(error.localizedDescription)")
        }
    }

    private func startDownload() {
        queue.async {
            guard !self.isStopped else { return }
            self.fileHandle = try? FileHandle(forWritingTo: self.cacheFileURL)
            var request = URLRequest(url: self.originURL)
            request.setValue("DebridChannels-tvOS/TemporaryVODCache", forHTTPHeaderField: "User-Agent")
            request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
            request.setValue("keep-alive", forHTTPHeaderField: "Connection")
            request.timeoutInterval = 60
            let config = URLSessionConfiguration.default
            config.requestCachePolicy = .reloadIgnoringLocalCacheData
            config.urlCache = nil
            config.timeoutIntervalForRequest = 60
            config.timeoutIntervalForResource = 24 * 60 * 60
            let session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
            self.session = session
            self.task = session.dataTask(with: request)
            self.task?.resume()
            self.onProgress?(self.cachedBytes, self.totalBytes, "Temporary cache downloading ahead")
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        queue.async {
            let expected = response.expectedContentLength > 0 ? response.expectedContentLength : nil
            self.totalBytes = expected
            self.onProgress?(self.cachedBytes, self.totalBytes, expected == nil ? "Caching ahead; file size unknown" : "Caching ahead to disk")
            completionHandler(.allow)
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        queue.async {
            guard !self.isStopped else { return }
            let remaining: Int
            if let limit = self.limitBytes {
                let allowed = max(0, limit - self.cachedBytes)
                remaining = min(data.count, Int(min(Int64(data.count), allowed)))
            } else {
                remaining = data.count
            }
            guard remaining > 0 else {
                self.isDownloadComplete = true
                self.task?.cancel()
                self.onProgress?(self.cachedBytes, self.totalBytes, "Cache limit reached")
                return
            }
            let chunk = remaining == data.count ? data : data.prefix(remaining)
            do {
                try self.fileHandle?.seekToEnd()
                try self.fileHandle?.write(contentsOf: Data(chunk))
                self.cachedBytes += Int64(remaining)
                self.onProgress?(self.cachedBytes, self.totalBytes, "Caching ahead to disk")
            } catch {
                self.onProgress?(self.cachedBytes, self.totalBytes, "Cache write failed: \(error.localizedDescription)")
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        queue.async {
            self.isDownloadComplete = true
            if let error = error as NSError?, error.code != NSURLErrorCancelled {
                self.onProgress?(self.cachedBytes, self.totalBytes, "Cache stopped: \(error.localizedDescription)")
            } else {
                self.onProgress?(self.cachedBytes, self.totalBytes, "Cache complete")
            }
        }
    }

    private func handle(connection: NWConnection) {
        connection.start(queue: queue)
        receiveRequest(on: connection, accumulated: Data())
    }

    private func receiveRequest(on connection: NWConnection, accumulated: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16 * 1024) { [weak self] data, _, isComplete, error in
            guard let self else { connection.cancel(); return }
            if error != nil || isComplete { connection.cancel(); return }
            var requestData = accumulated
            if let data { requestData.append(data) }
            if let range = requestData.range(of: Data("\r\n\r\n".utf8)) {
                let head = requestData[..<range.lowerBound]
                let requestText = String(data: head, encoding: .utf8) ?? ""
                self.serve(requestText: requestText, connection: connection)
            } else {
                self.receiveRequest(on: connection, accumulated: requestData)
            }
        }
    }

    private func parseRange(_ requestText: String) -> (start: Int64, end: Int64?) {
        for line in requestText.components(separatedBy: "\r\n") {
            let lower = line.lowercased()
            guard lower.hasPrefix("range:") else { continue }
            guard let eq = lower.range(of: "bytes=") else { continue }
            let spec = String(lower[eq.upperBound...]).trimmingCharacters(in: .whitespaces)
            let parts = spec.split(separator: "-", omittingEmptySubsequences: false)
            let start = Int64(String(parts.first ?? "0")) ?? 0
            let end = parts.count > 1 ? Int64(String(parts[1])) : nil
            return (max(0, start), end)
        }
        return (0, nil)
    }

    private func serve(requestText: String, connection: NWConnection) {
        let range = parseRange(requestText)
        waitUntilAvailable(range.start) { [weak self] available in
            guard let self, available else { connection.cancel(); return }
            let totalForHeader = self.totalBytes ?? max(self.cachedBytes, range.end.map { $0 + 1 } ?? self.cachedBytes)
            let requestedEnd = range.end ?? max(range.start, totalForHeader - 1)
            let headerEnd = min(requestedEnd, max(totalForHeader - 1, range.start))
            let headers = "HTTP/1.1 206 Partial Content\r\n" +
                "Content-Type: application/octet-stream\r\n" +
                "Accept-Ranges: bytes\r\n" +
                "Content-Range: bytes \(range.start)-\(headerEnd)/\(max(totalForHeader, headerEnd + 1))\r\n" +
                "Connection: close\r\n\r\n"
            connection.send(content: Data(headers.utf8), completion: .contentProcessed { _ in
                self.sendBytes(connection: connection, offset: range.start, requestedEnd: requestedEnd)
            })
        }
    }

    private func waitUntilAvailable(_ offset: Int64, completion: @escaping (Bool) -> Void) {
        queue.asyncAfter(deadline: .now() + 0.03) {
            if self.isStopped { completion(false); return }
            if self.cachedBytes > offset || self.isDownloadComplete { completion(self.cachedBytes > offset); return }
            self.waitUntilAvailable(offset, completion: completion)
        }
    }

    private func sendBytes(connection: NWConnection, offset: Int64, requestedEnd: Int64) {
        guard !isStopped else { connection.cancel(); return }
        let maxChunk: Int64 = 256 * 1024
        if offset > requestedEnd || (isDownloadComplete && offset >= cachedBytes) {
            connection.cancel()
            return
        }
        if offset >= cachedBytes {
            waitUntilAvailable(offset) { [weak self] available in
                guard let self, available else { connection.cancel(); return }
                self.sendBytes(connection: connection, offset: offset, requestedEnd: requestedEnd)
            }
            return
        }
        let availableEnd = min(requestedEnd, cachedBytes - 1)
        let length = Int(min(maxChunk, availableEnd - offset + 1))
        guard length > 0 else {
            connection.cancel()
            return
        }
        do {
            let readHandle = try FileHandle(forReadingFrom: cacheFileURL)
            try readHandle.seek(toOffset: UInt64(offset))
            let data = try readHandle.read(upToCount: length) ?? Data()
            try readHandle.close()
            guard !data.isEmpty else { connection.cancel(); return }
            connection.send(content: data, completion: .contentProcessed { [weak self] _ in
                self?.sendBytes(connection: connection, offset: offset + Int64(data.count), requestedEnd: requestedEnd)
            })
        } catch {
            connection.cancel()
        }
    }
}
