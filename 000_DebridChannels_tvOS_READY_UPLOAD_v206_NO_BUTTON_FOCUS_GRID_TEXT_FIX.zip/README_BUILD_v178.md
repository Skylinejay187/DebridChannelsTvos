# Debrid Channels tvOS v178

Ready-to-upload GitHub Actions repo ZIP.

Changes:
- Settings and Live TV guide DPAD debounce pass: one press should move one step.
- Black-glass Live TV color pass replacing purple guide/grid surfaces.
- Duplicate Live TV focus assignment cleanup.
- Preserves manual DVR/M3U/XMLTV/Xtream sources and TS/HLS direct Live TV playback.
