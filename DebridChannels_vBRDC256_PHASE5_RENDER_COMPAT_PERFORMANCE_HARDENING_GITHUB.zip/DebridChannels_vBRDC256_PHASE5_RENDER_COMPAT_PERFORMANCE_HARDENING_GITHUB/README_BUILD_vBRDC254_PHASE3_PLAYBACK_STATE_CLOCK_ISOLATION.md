# vBRDC254 — Phase 3 Playback State / Clock Isolation

Version: 1.0.957 (957)
Release: vBRDC254
Baseline: successfully built vBRDC253 Phase 2 Build Fix 2.

Scope is intentionally Phase 3 only. Deferred UI/Source Intelligence/Live TV Guide hitching remains assigned to the Phase 5 performance pass.

Phase 3 hardening in this candidate:
- Preserves PlaybackKit session clock as the VOD timeline authority across AetherEngine and KSPlayer.
- Adds Aether runtime buffering-state publication across the dynamic bridge boundary without importing Aether into the app target.
- Scopes Aether buffering updates to the active playback presentation/session before mutating PlaybackController state.
- PlaybackSnapshot now receives Aether buffering transitions through the same session-owned clock model used for elapsed/duration/progress.
- Preserves existing first-frame readiness, seek/resume, EOF/next-episode, source-failover, and engine-switch contracts.
- No Aether/KSPlayer packaging changes and no build-speed optimization.
