import SwiftUI

struct LiveTVProgramProgressLine: View {
    let progress: CGFloat
    let isFocused: Bool
    let width: CGFloat
    let tick: Int

    private var clampedProgress: CGFloat {
        min(max(progress, 0.0), 1.0)
    }

    var body: some View {
        ZStack(alignment: Alignment.leading) {
            Rectangle()
                .fill(Color.black.opacity(isFocused ? 0.42 : 0.26))
            Rectangle()
                .fill(Color.cyan.opacity(isFocused ? 0.58 : 0.24))
                .frame(width: max(2.0, width * clampedProgress))
        }
        .frame(width: width, height: isFocused ? 4.0 : 2.0)
        .clipShape(Capsule())
        .opacity(isFocused ? 0.92 : 0.42)
        .id(tick)
        .accessibilityHidden(true)
    }
}
