# DebridChannels v826 — VOD Full-Width Overlay + Red Progress Fix

Baseline: `DebridChannels_v825_ARTWORK3_PURE_BLACK_FINAL_POLISH.zip`

Scope locked to VOD overlay visual geometry and VOD timeline color only.

## Changes

- Kept the compact VOD overlay height from v825.
- Removed the uniform 0.88 shrink that made the VOD chrome start from the middle/inset area.
- Changed the VOD bottom chrome to full horizontal scale so it anchors visually from the left and right sides of the screen.
- Reduced horizontal padding from 72 to 28 so the poster/content and cast-wall side sit closer to the real screen edges.
- Changed the VOD timeline/progress fill from cyan/blue to red.
- Changed timeline focus stroke and scrubber glow from cyan to red so the focused timeline matches the new red progress treatment.

## Not touched

- Playback engine logic
- VOD control actions
- Pause/overlay visibility behavior
- Character Spotlight logic/timing
- Advisory
- Sports
- Live TV
- Membership
- Artwork Hero themes
- Backend
