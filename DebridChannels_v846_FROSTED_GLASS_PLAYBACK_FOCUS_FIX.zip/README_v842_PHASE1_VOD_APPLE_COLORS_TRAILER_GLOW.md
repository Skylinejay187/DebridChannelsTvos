# v842 Phase 1 VOD Apple Colors + Trailer Glow

Baseline: DebridChannels_v842_SCROLL_RECOVERY_SCAN_TRAILER_VOD_COLOR_FIX.zip

Scope intentionally limited to VOD/trailer visual polish only.

Changes:
- Kept the VOD timeline track as black/dark glass.
- Removed the remaining purple VOD scrubber/chip styling.
- Restored Apple-style blue + gray overlay accents with only a tiny red position accent.
- Updated VOD chip selected background/glow to blue/gray instead of purple.
- Updated VOD status pill icon/stroke accent to blue/gray.
- Moved the VOD poster/info stage farther inside the left safe area.
- Added more bottom spacing under the VOD information stage so it stays clear of the scrubber lane.
- Restored the trailer popup background glow behind the black-glass video card.

Not changed:
- Live TV grid/scrolling logic.
- Playback engines or playback logic.
- VOD chip scrolling/navigation logic.
- Source Intelligence.
- Guide/source ingestion.
- Catalog logic or catalog scrolling.

Validation:
- `swiftc -parse` was run across all Swift files.
- Parser validation passed with only the pre-existing UniversalCodecSupport warning.
