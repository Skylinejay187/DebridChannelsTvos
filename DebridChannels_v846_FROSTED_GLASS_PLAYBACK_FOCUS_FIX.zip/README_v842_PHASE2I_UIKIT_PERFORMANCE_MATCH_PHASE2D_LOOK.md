# v842 Phase 2I — UIKit Performance Renderer Matched Back to Phase 2D Look

Starting point: `DebridChannels_v842_PHASE2B_ORIGINAL_LOOK_FOCUS_RETURN_FLICKER_FIX.zip`.

Scope: Live TV grid renderer only.

Changes:
- Kept the Phase 2B UIKit `UICollectionView` scrolling/reuse renderer.
- Re-shaped the UIKit cell so the visible card no longer fills the whole collection cell; it now renders as the original 16:9 landscape tile inside the spacing envelope.
- Focus ring/shadow paths now attach to the visible card rectangle, not the whole cell, preventing the out-of-range focus border.
- Restored the original metadata arrangement:
  - small channel logo bottom-left,
  - channel number below it,
  - current program title to the right,
  - channel name below the program title.
- Restored the original smaller footer typography and bottom dark gradient instead of a heavy black block.
- Preserved side-blur artwork treatment, 4 columns, 3-row spacing envelope, focused-only progress bar, and focus-return behavior.

Not changed:
- Playback engine
- Live TV guide/source loading
- VOD overlay
- Source Intelligence
- Catalog rows
