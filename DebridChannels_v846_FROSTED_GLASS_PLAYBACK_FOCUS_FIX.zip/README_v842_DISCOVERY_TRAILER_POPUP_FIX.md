# v842-only manual discovery + trailer popup shape fix

Base: DebridChannels v842-only line. No v843+ logic merged.

Changes:
- Startup remains saved-source only. No automatic Channels DVR or HDHomeRun discovery runs on app launch or Live TV grid entry.
- Live TV Settings now has user-triggered scan buttons:
  - Scan Channels DVR
  - Scan HDHomeRun
- HDHomeRun scan saves discovered lineup URLs into the normal HDHomeRun manual source field so the same shared ingestion/matching path is used afterward.
- Channels DVR scan tries the configured base first, then common local hostnames only when the user explicitly presses the scan button.
- Regular M3U and XMLTV fields remain part of the shared ingestion path, so Channels DVR M3U, HDHomeRun M3U, HDHomeRun XMLTV, and Gracenote XMLTV guide data can enrich channels no matter which regular field receives the URL.
- Trailer popup video card is now clipped as one continuous rounded black-glass card, with sweep/stroke/glow clipped inside the same shape to prevent protruding corners.

Validation:
- `swiftc -parse Sources/*.swift` completed with no parser errors.
