# v842 Phase 2K — Exact Grid Geometry, Focus Pop and Return Focus

Base: working smooth UIKit Phase 2J renderer.

Changes are limited to the Live TV grid renderer:
- stronger focused-card pop/3D lift while preserving UIKit scrolling
- subtler outer white focus ring
- nearly invisible inner gray ring
- larger blurred/translucent side wings around centered artwork
- grid moved farther below the top menu
- viewport/item geometry tuned for exactly three fully visible rows
- explicit preferred-focus environment restores the same last selected/played channel after playback

No Live TV source, guide, playback, catalog, Source Intelligence, trailer, or VOD logic changed.
