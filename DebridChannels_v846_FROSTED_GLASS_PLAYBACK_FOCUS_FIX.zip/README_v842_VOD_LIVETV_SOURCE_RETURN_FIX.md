# v842-only VOD / Live TV / Source Intelligence correction

Base: DebridChannels v842 only (with the previously applied original-resolution TMDB artwork and HDHomeRun Gracenote fixes).

Changes only:
- Increased separation between VOD information/poster stage and scrubber.
- Cast Wall remains dark black glass, clipped to one clean continuous rounded shape with neutral border.
- VOD scrubber accent changed from red to purple-gray.
- VOD selected chip tint/glow changed to purple-gray while keeping black glass as the main overlay theme.
- Disabled the native tvOS focus wash on VOD control buttons.
- Live TV grid now relies on native tvOS focus-driven scrolling instead of racing focus with animated scrollTo calls.
- Focused-only Live TV progress waits for settled card focus so the progress/timestamp state does not appear before the card visually becomes focused.
- Source Intelligence remains mounted after launching playback and is restored when playback exits; it closes only when the user explicitly exits Source Intelligence.

No v843+ code was merged. Playback engines, VOD seek behavior, chip scrolling architecture, guide/source loading, and catalog row logic were not replaced.
