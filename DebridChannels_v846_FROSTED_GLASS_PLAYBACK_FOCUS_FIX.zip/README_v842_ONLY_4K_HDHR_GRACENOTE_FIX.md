# DebridChannels v842 Only - 4K Artwork + HDHomeRun Gracenote Fix

Base: DebridChannels_v842_VOD_OVERLAY_CATALOG_4K_NO_LINK_CACHE.zip

Scope intentionally limited per request:
- No v850/v851/v852 overlay logic.
- No new playback changes.
- No scrolling/focus changes.
- No Live TV auto-discovery rewrites.
- No Source Intelligence logic changes.

Changes applied:
1. 4K/best-quality artwork parity with Android TMDB handling:
   - TMDB image URLs continue to normalize to /t/p/original.
   - Additional TMDB poster-path variants normalize to /poster/original.
   - PremiumRemoteImageLoader keeps larger in-memory artwork cache and stores cache cost by downloaded image size.

2. HDHomeRun Gracenote/XMLTV matching improvement:
   - Guide matching now includes station-id-stripped aliases, decimal-free channel numbers, callsign aliases, and HD/SD-stripped names.
   - Normalized guide keys now handle common Gracenote/channel name variants such as HD/SD/East/West suffixes and common sports/news aliases.

Validation:
- Swift parser validation passed for all Sources/*.swift.
