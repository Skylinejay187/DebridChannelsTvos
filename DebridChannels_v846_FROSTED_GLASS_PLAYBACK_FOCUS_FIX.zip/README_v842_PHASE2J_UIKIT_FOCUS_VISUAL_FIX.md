# v842 Phase 2J — UIKit Live TV Focus Visual Fix

Base: v842 Phase 2I UIKit performance / matched Phase 2D look.

Fixes:
- Keeps the smooth UIKit `UICollectionView` Live TV scrolling path.
- Makes every Live TV grid cell explicitly focusable.
- Adds an in-cell `didUpdateFocus` fallback so the focused card visual state is applied even if the collection delegate focus animation path does not fire on-device.
- Keeps the same Phase 2D card geometry and layout.
- Restores visible focused-card treatment: subtle outer white ring, inner gray line, lightweight zoom, shadow lift, focused-only progress line.
- Does not touch VOD, playback, guide/source loading, Source Intelligence, catalogs, or membership logic.

Notes:
- This does not change the grid card look; it only fixes the missing focused visual state on the working UIKit smooth-scrolling build.
