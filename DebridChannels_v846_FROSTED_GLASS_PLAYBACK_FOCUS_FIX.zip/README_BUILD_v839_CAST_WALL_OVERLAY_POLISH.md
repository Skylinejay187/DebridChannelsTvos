# DebridChannels v839 — Cast Wall Overlay Polish

Baseline: v838 FORCE_REAL_CATALOGS_NO_SAMPLE_ART.

Scope:
- Rolled forward from v838 only; no playback engine changes.
- Repositioned Cast Wall to the right-side scrubber/end-time zone instead of floating over the center title area.
- Expanded Cast Wall to rotate through the full available cast list rather than only the first five names.
- Updated Cast Wall visual treatment with a larger character spotlight, full portrait fit, and a horizontal mini-cast rail.
- Actor images use fit mode and taller portrait framing to avoid aggressive face-only cropping.
- Increased VOD synopsis visibility with a smaller font and up to five lines for movies/shows.
- Added a Restart control that seeks to 0:00 without recreating the player.

Preserved:
- v833/v834 playback behavior.
- v835 alert hardening.
- v838 real catalog startup behavior.
- Full-width red progress bar.
- Existing player engine behavior.
- Source Intelligence data path.
- Navigation/focus architecture.
