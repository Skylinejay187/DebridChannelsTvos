# DebridChannels v817 - Comet/Torrentio Wiring Fix

Base: v816 built-in addon wiring fix.

Changes:
- Removed the visible "Install TorBox Search" action from the built-in Addon/Debrid Manager.
- Removed the automatic TorBox Search manifest injection from Source Intelligence.
- Kept Torrentio install actions for Real-Debrid and TorBox.
- Reworked Comet install URL generation to use Comet-style encoded config manifest URLs instead of Torrentio-style key=value path segments.
- Added fallback Real-Debrid infoHash resolution for Comet/Torrentio-style stream results that return infoHash/fileIdx without a direct playable URL.
- Kept MediaFusion out of the built-in manager.

Scope untouched:
- Playback engine selection
- Sports / Live TV / Membership
- Timeline focus / VOD overlay behavior
