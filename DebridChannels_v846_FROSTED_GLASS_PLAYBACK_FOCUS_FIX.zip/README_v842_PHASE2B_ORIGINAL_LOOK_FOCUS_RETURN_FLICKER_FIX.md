# v842 Phase 2B — Original Live TV Look on UIKit Renderer

Baseline: v842 Phase 2 UIKit UICollectionView Live TV renderer.

Changes limited to the Live TV rendering surface:
- Kept UICollectionView reuse, prefetching, async image loading/downsampling, and smooth scrolling.
- Restored the original v842 Live TV card geometry and visual treatment: 16pt continuous corners, full-card artwork, 82pt dark footer, compact typography, subtle focus border/outer ring, 1.035 focus zoom, original shadow profile, and focused-only red progress line.
- Removed generic Phase 2 oversized card styling.
- Added preferred focused channel restoration so exiting playback returns to the same channel card.
- Stopped unconditional reloadData on every SwiftUI update/progress tick.
- Progress timer now refreshes only visible focused progress state instead of rebuilding the grid.
- Cached artwork is retained during cell reuse until replacement arrives to reduce flicker/blank flashes.

Untouched:
- Playback engines and routing
- Guide/source ingestion and discovery
- VOD and Source Intelligence
- Catalog rows
- Trailer logic

Validation: Swift parser validation passed.
