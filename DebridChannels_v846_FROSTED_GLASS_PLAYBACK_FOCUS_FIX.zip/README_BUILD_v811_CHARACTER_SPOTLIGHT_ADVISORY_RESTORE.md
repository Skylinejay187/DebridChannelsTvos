# DebridChannels v811 — Character Spotlight + Advisory Restore

Base: v810 Sports Hero Widget + VOD Overlay Compact Fix

Scope applied:
- Added premium Character Spotlight presentation in the VOD theater metadata area for movies/shows.
- Uses TMDB cast member image when available.
- Falls back to the existing cast metadata when image data is limited.
- Kept Live TV program-info handling unchanged.
- Restored advisory rebuild behavior so advisory facts are derived from the currently selected media item and optional OMDb facts every time the selection token changes.
- Expanded advisory descriptor parsing for violence, language, nudity, sexual content, drugs, smoking, alcohol, mature themes, frightening/scary/intense scenes.

Explicitly untouched:
- VOD scrolling/focus/navigation logic.
- Timeline focus lock.
- Playback controls and engines.
- Source Intelligence.
- Sports architecture and widgets.
- Live TV.
- Backend.
- Membership.
