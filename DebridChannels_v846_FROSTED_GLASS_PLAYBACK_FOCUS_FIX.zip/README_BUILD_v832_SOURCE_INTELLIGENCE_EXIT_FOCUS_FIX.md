# DebridChannels v832 — Source Intelligence Exit Focus Fix

Baseline: `DebridChannels_v831_1_PLAYBACK_BUFFER_BUILD_FIX.zip`

Scope:
- Fix Source Intelligence focus/back trap after exiting VOD playback.
- Preserve v831 playback buffer cache changes.
- Preserve link cache, favorites, Stremio parity, alerts, VOD overlay geometry, red progress bar, playback engines, Live TV, Sports, Membership, and backend.

Changes:
1. Source Intelligence overlay now releases focus before internal playback starts.
2. Returning from VOD playback forcibly clears stale Source Intelligence overlay state and returns focus to Find Links.
3. MENU/BACK while Source Intelligence is resolving now cancels the resolver, clears opening/scanning flags, resets the link window, and restores normal details focus.
4. Cached/session links remain available; reopening Find Links can restore them without keeping the overlay mounted behind playback.

Reason:
The player could close back into a stale Source Intelligence focus section. That stale overlay could retain scroll/back ownership, making it feel like the app was stuck and unable to exit the Source Intelligence screen.
