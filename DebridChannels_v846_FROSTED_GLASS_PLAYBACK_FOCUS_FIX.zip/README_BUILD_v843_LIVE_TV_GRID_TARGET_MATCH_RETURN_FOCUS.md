# v843 — Live TV Grid Target Match + Return Focus

Scoped only to the UIKit Live TV grid renderer in `Sources/DebridChannelsTVOSApp.swift`.

- Removed the full-card blurred artwork layer behind the center image.
- Card now renders one sharp center artwork image only.
- Added left/right artwork wings clipped strictly to the side regions, with translucent dark blur glass overlays.
- Widened the side wings to match the supplied correct reference while preserving the 4-column / 3-visible-row grid geometry and existing top spacing.
- Preserved and tuned the subtle outer white + inner gray focus rings and existing focus pop.
- Before playback, the exact selected UIKit index path is pinned as preferred focus.
- On playback dismissal/focus restore token changes, the collection view scrolls to the stored channel ID/index and reasserts UIKit focus over several run-loop turns so focus returns active and scrollable on that exact card.

No VOD, catalogs, Source Intelligence, guide/source loading, playback engine, or navigation code was changed.
