# v845 — v843 Base + v840 Live TV Grid Design + Scroll/Return Focus Fix

Base: v843 only.

Changes limited to Live TV grid renderer:
- Ported v840 grid row placement/spacing: 4 columns, 34 vertical spacing, 36 horizontal spacing, v840 top placement and viewport height.
- Ported v840 card artwork treatment: full-card soft blurred fill layer plus one sharp aspect-fit foreground artwork.
- Ported v840 focus pop and two-ring styling.
- Removed v843 custom UICollectionView preferredFocusEnvironments interception that could orphan focus and lock scrolling.
- Preserved native UICollectionView focus environment and remembersLastFocusedIndexPath.
- Tracks last clicked and last focused index paths in the coordinator.
- On playback-return token, scrolls vertically to the exact saved channel and requests focus over safe run-loop turns.
- Explicitly keeps vertical scrolling and user interaction enabled.

No VOD, catalogs, Source Intelligence, guide/source loading, playback engines, or app navigation changes.
