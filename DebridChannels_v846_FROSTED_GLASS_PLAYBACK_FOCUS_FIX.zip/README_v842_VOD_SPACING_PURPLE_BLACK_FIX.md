# v842 VOD Spacing + Purple Black Focus Fix

Base: DebridChannels_v842_LIVETV_NATIVE_SCROLL_PROGRESS_RESTORE.zip

Scope intentionally limited to the VOD overlay visual spacing and accent colors only.

Changes:
- Increased the vertical safe lane between the VOD information/poster stage and the scrubber.
- Moved the movie/show text block farther away from the poster using a fixed wider gap.
- Slightly reduced the VOD poster footprint and added bottom separation so it cannot sit on the scrubber lane.
- Strengthened the scrubber accent from washed-out gray to a visible purple/black gradient.
- Strengthened focused VOD chip background, border, and glow to a visible purple/black treatment.
- Kept the main VOD overlay black-glass themed.

Not changed:
- Playback engines
- Scrubbing/seek behavior
- VOD chip scrolling logic
- Live TV logic
- Source Intelligence
- Catalog logic
- Trailer logic

Validation:
- swiftc -parse passed for all Swift source files.
