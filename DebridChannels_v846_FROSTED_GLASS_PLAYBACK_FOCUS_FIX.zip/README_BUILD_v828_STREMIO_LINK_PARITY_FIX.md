# DebridChannels v828 — Stremio Link Parity Fix

Baseline: `DebridChannels_v827_1_BUILD_FIX.zip`

Scope locked to Source Intelligence / addon stream fetching only.

## Changes

- Removed the old 25/50 visible-link cap from Source Intelligence so valid addon-returned streams are ranked but not hidden.
- Kept incremental provider loading behavior: first usable links still publish immediately, slower addon results append as they arrive.
- Preserved exact configured addon identity in dedupe keys so multiple configured addons with similar provider names do not collapse each other's streams.
- Added per-provider parity counters in provider status messages:
  - raw stream count returned by addon
  - newly appended count
  - total shown count
  - title-filter drop count
  - duplicate drop count
- Preserved Stremio-style exact ID behavior: exact `/stream/{type}/{id}.json` results are accepted unless they are true duplicates.
- Kept playback engines, overlay layout, VOD geometry, red progress bar, backend, Live TV, Membership, Sports, Artwork, Character Spotlight, and navigation untouched.

## Intent

If Stremio receives a stream from the same configured addon, DebridChannels should receive and show that same valid stream instead of hiding it behind caps or overly broad dedupe.
