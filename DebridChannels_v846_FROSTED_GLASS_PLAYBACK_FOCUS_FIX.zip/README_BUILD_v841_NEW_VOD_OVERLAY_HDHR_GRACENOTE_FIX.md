# v841 — New VOD Overlay + HDHomeRun Gracenote Fix

Base: v840.

Scope:
- Preserves v840 trailer playback logic exactly.
- Replaces the v840 VOD information header/cast presentation with a clean-sheet display-only stage.
- Keeps all playback engines, seek logic, cache behavior, timeline behavior, trailer logic, and Source Intelligence untouched.
- Poster, themed title logo, rating/year/genres, full scrollable About text, and a dynamic full-cast wall.
- Cast portraits use fit presentation to avoid aggressive face cropping; the wall cycles through the entire cast list.
- Keeps Restart control.
- Preserves v838 real-catalog startup forcing in CatalogStore; no sample/demo catalog publishing.
- M3U settings field now accepts XMLTV/Channels DVR Gracenote guide URLs and applies them to the loaded lineup.
- HDHomeRun guide matching continues through channel number, tvg-id, callsign/display-name normalization and XMLTV aliases.

No trailer playback changes. No VOD playback changes. No backend changes.
