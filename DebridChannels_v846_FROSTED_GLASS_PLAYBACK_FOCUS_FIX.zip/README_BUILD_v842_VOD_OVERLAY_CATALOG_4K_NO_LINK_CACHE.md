# DebridChannels v842 — VOD Overlay Redesign, Catalog 4K Artwork, No Source Link Cache

Base: v841

Scope:
- Preserved v840/v832 trailer playback logic and all playback/scrolling behavior.
- Rebuilt VOD information stage again with a lower, cleaner placement.
- Added poster, themed logo, ratings/facts, full visible about text, and refreshed status/meta chips.
- Replaced Cast Wall with a one-person dynamic spotlight that cycles through the full cast.
- Cast images use fit mode to avoid cropped faces/bodies.
- Removed Source Intelligence restored-link behavior when Find Links is opened again; scans start fresh.
- Normalized catalog poster/landscape/logo image URLs to highest available quality where possible.
- Kept HDHomeRun/Gracenote fix from v841.

Not touched:
- Playback engine logic.
- Trailer playback logic.
- VOD seeking/scrubbing logic.
- Navigation/focus scrolling logic.
- Backend.
