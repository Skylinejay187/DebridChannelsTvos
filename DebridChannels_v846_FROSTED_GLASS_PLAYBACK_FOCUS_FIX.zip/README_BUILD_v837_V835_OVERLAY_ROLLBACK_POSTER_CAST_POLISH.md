# DebridChannels v837 — v835 Overlay Rollback + Poster/Cast Polish

Baseline: DebridChannels_v835_EPISODE_ALERTS_PRODUCTION_HARDENING.zip

Scope locked:
- Fully rolled back the v836 Cinematic Glass VOD overlay experiment.
- Restored the exact v835 VOD overlay structure and behavior.
- No playback, alerts, Source Intelligence, navigation, focus, backend, or architecture changes.

Visual polish only:
- Poster keeps the exact v835 size, alignment, and placement.
- Added a cleaner premium layered frame, subtle edge highlight, controlled depth shadow, and soft artwork sheen.
- Cast Wall keeps the exact v835 location, scale, behavior, and Character Spotlight rotation.
- Refined Cast Wall glass depth and border treatment.
- Actor portraits remain fit-based for natural head-and-shoulders visibility, with reduced visual heaviness and cleaner portrait framing.

Rollback:
- v836/v836.1 Cinematic Glass layout code is not included.
