# v842 Recovery Fix

Built only on the supplied v842 VOD spacing build-fix line.

- Restored original Live TV focused-card zoom, ring-compatible focus behavior, shadow and spring animation.
- Restored rendered-window grid path so thousands of channels do not instantiate at once.
- Kept focused-only Live TV progress and its ON/OFF setting.
- Prevented the broken all-visible-channel LazyVGrid path that caused artwork disappearance/reload during scrolling.
- Preserved manual Channels DVR and HDHomeRun scan actions and shared source ingestion.
- Rejected purple accent; restored blue/gray focus accents with restrained red remaining in existing progress treatment.
- Nudged VOD poster stage farther inside the left safe area.
- Preserved playback, VOD chip navigation, Source Intelligence, catalogs and guide ingestion.

Swift parser validation passed.
