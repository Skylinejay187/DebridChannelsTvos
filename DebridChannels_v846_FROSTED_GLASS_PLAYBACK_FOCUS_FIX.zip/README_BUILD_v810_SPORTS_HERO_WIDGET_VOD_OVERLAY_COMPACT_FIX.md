# DebridChannels v810 — Sports Hero Widget + VOD Overlay Compact Fix

Base: v809 Sports Content + Premium VOD Chips

Scope:
- Added Sports hero/widget area above the active Sports quick-panel row.
- Hero/widget is not a new row; it updates based on the currently active Sports row and selected card.
- Preserved Sports one-row-at-a-time navigation from v808/v809.
- Added compact live-widget style metadata pills for row title, league/source, status, and live-score readiness.
- Tightened VOD small information chips so the overlay consumes less vertical space.
- Reduced VOD bottom chrome bottom padding so the controls sit lower on screen.

Kept untouched:
- Playback engine behavior.
- Source Intelligence logic.
- Membership.
- Backend.
- Sports row navigation/focus architecture.
