# v823 VOD Overlay Compact Centered Chips

Base: DebridChannels_v822_ARTWORK3_REAL_LIVETV_AMBIENT_PURE_BLACK_LOGO.zip

Scope locked to VOD overlay layout only.

Changes:
- Reduced the overall VOD bottom overlay scale by ~12% using the bottom edge as the anchor.
- Kept playback engine, timeline focus behavior, scrolling logic, Source Intelligence, and all player actions unchanged.
- Centered the bottom chip rail mathematically inside the available screen width.
- Seeded the bottom chip rail to center on Play/Pause when the overlay appears, while preserving focused-chip auto-centering during left/right navigation.
- Kept Resume, Play/Pause, Back 30, Forward 60, Audio, Subtitles, Episodes, Player Engine, External Player, and Settings actions intact.

Do not touch:
- Playback engine
- Timeline focus
- Source Intelligence
- Live TV
- Sports
- Membership
- Artwork themes
