# Debrid Channels vBRDC187 — Playback Catalog Logo Identity + Top Bar Removal

Built only from packaged vBRDC186.

## Playback catalog top bar removed
The extra capsule bar that showed `HOME` / `MOVIES` / `TV SHOWS` with `MENU returns to playback` has been removed completely from the in-player catalog surface. MENU/Back still exits through the existing playback catalog close handler, so navigation behavior is unchanged.

## Stale themed-logo fix during Live TV and VOD playback browsing
The supplied video shows the catalog hero already advancing to the new title while the themed logo painted inside the large focused card still belongs to the previous title. Example from the recording: the hero has reached *The Gentlemen* while the focused-card logo still reads *The Whisper Man* before eventually correcting.

Root cause: `CardThemedLogo` retained its previous decoded bitmap and did not have permission to publish replacement artwork while full-screen playback owned the artwork gate. This made active Live TV/VOD catalog browsing keep the outgoing clearlogo until another lifecycle/focus event caused publication.

vBRDC187:
- passes the playback-foreground artwork lane into `CardThemedLogo`;
- force-allows bounded visible clearlogo publication while the playback catalog is open;
- disables previous-logo retention only for playback browsing;
- keys the focused-card clearlogo loader by media identity + logo URL;
- applies the same identity-strict playback behavior to the large catalog hero clearlogo;
- preserves the established seamless logo-retention behavior for normal Home/Movies/Shows browsing outside playback.

No catalog rows, provider ordering, source search, playback engine, or Media Information logic changed.

## Version
- Release: vBRDC187
- Marketing: 1.0.890
- Apple build: 890
