# Debrid Channels vBRDC179 — Live TV From-Scratch Presentation Rebuild

Version: 1.0.882 (882)
Base: packaged vBRDC178 only

## Live TV grid
- Replaced the previous deck/backdrop reskin with a new structural layout.
- Preserved fixed 12-channel paging, bottom-right PAGE indicator, focus ring, focus/navigation behavior and smooth focus-motion owner.
- Added a new broadcast header with current station/program context instead of the old decorative header rail.
- Rebuilt cards as broadcast windows: artwork/live preview is isolated above a dedicated information dock. The existing card data/content is retained.
- Removed the previous PremiumCanvas, card base gradient, optical edge and accent-rail layers.
- Rebuilt the grid's left channel/tools panel as a flat navigation blade instead of capsule/theme-card rows.
- Dynamic Wallpaper remains the actual grid canvas; there is no enclosing grid panel.

## Guide
- Kept the user-locked live preview and Exit/Back hint presentation.
- Rebuilt everything around them: station identity bar, Now Playing module, horizontal program art, NEXT context, channel lanes, timeline header and schedule cells.
- Guide color follows the selected Live TV theme/channel accent rather than a forced black skin.
- Category selector/drop-down logic remains inline and independent from the grid's left tools panel.

## Channel logo reliability
- Added a dedicated bounded station-logo cache (256 entries / 24 MB) separate from high-churn program artwork.
- Logo cache survives normal transient Live TV surface handoffs and is cleared only by the explicit full cache release/memory-pressure path.
- Logo requests retain immediate publication and page-first prefetch behavior.
- Increased bounded prefetch concurrency from 4 to 6 while preserving decode gating.

## Regression locks
- CatalogStore untouched.
- Alternate Audio / PlaybackKit source untouched.
- Adaptive VOD cache untouched.
- Live TV page indicator preserved.
- Guide preview + Exit/Back hint preserved.
