# vBRDC189 Regression Locks

1. Expanded VOD controls must remain on one fixed non-scrolling horizontal rail.
2. VOD control slots are calculated evenly from the available rail width and the current control count.
3. Focus movement may scale/glow the selected control but must not translate the whole VOD row.
4. The VOD Video Fit chip must remain available and open the full fit/aspect-ratio panel.
5. Video Fit changes must not restart the VOD stream or reset resume/progress state.
6. Live TV playback stays Source / Fit and must not inherit a saved VOD geometry override.
7. vBRDC188 approved main icon assets remain unchanged.
8. vBRDC187 playback UNITY catalog top-bar removal and clearlogo identity hardening remain unchanged.
