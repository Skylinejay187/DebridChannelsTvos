# vBRDC188 Regression Locks

1. The primary tvOS icon uses the approved black/silver/orange retro-TV artwork locked by the user.
2. Do not generate or substitute another icon design unless the user explicitly asks for a new design.
3. The installed tvOS icon stays exactly 400×240 and the App Store icon stays exactly 1280×768.
4. Do not add extra inset, border, padding, letterboxing, or crop around the approved artwork.
5. Top Shelf artwork is unchanged by this icon-only release.
6. All vBRDC187 playback catalog logo-identity and top-bar-removal behavior remains unchanged.
