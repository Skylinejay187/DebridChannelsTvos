# Debrid Channels vBRDC189 — VOD Even Control Rail + Video Fit Restore

Built only from packaged vBRDC188.

## VOD control rail
- Removed the horizontal ScrollView from the expanded VOD control shelf.
- Every visible VOD control is assigned one mathematically equal slot across a fixed 1800-point safe-width rail.
- The control row itself no longer pans when focus moves left/right; only the focused chip scales/glows.
- Resume and Episodes may add controls dynamically without changing the equal-slot calculation.
- Live TV's separate playback control row is unchanged.

## Video Fit / Aspect Ratio restored
The missing VOD Video Fit chip is restored. It opens a dedicated panel and changes picture geometry without tearing down or restarting the active playback session.

Sizing modes:
- Source / Fit
- Fill Screen
- Crop / Zoom
- Stretch
- Zoom 110%, 125%, 150%

Aspect-ratio overrides:
- 16:9, 4:3, 21:9, 32:9, 17:9, 16:10, 3:2, 14:9, 5:4, 1:1
- 9:16 and 3:4 vertical
- 1.66:1, 1.85:1, 2.00:1, 2.20:1, 2.35:1, 2.39:1, 2.40:1, 2.55:1, 2.76:1

The geometry contract is shared by AVPlayer and KSPlayer; VLC receives the same container/content-mode intent. Live TV is locked to Source / Fit and is not affected by a saved VOD fit choice.

## Locked behavior retained
- vBRDC188 approved main icon remains byte-identical.
- vBRDC187 playback-catalog top-bar removal and themed-logo identity hardening remain unchanged.
- Home / Movies / TV Shows playback UNITY catalogs remain available.
- No provider/backend/catalog logic was changed.

## Version
- Release: vBRDC189
- Marketing: 1.0.892
- Apple build: 892
