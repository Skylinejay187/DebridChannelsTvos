# Debrid Channels vBRDC188 — Main Icon 4K Refresh

Built only from packaged vBRDC187.

## Main tvOS icon refresh
The locked approved Debrid Channels artwork is now the primary tvOS app icon. The 3840×2304 approved master was used only as the source artwork and was downsampled directly into Apple's existing required primary-icon slots:

- Installed tvOS home-screen tile: 400×240
- App Store primary icon: 1280×768

The master is already the exact 5:3 aspect ratio, so the icon required no crop, inset, letterbox, or composition change. The existing transparent front/middle parallax layers remain untouched and the refreshed artwork is placed in the back layer exactly as the prior icon was.

`DebridChannelsHomeIcon.png` was synchronized to the same approved artwork at 1280×768 so no legacy/main-icon asset can display the old design.

Top Shelf artwork, playback/catalog code, backend, providers, settings, and all app behavior are unchanged from vBRDC187.

## Version
- Release: vBRDC188
- Marketing: 1.0.891
- Apple build: 891
