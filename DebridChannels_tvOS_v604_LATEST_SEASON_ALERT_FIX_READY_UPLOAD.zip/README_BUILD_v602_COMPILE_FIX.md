# Debrid Channels tvOS v602 Compile Fix

Fix pass for v602 build failure.

## Fixed
- Removed duplicate VOD language `@AppStorage` declarations inside the VOD player view.
- Made Settings DPAD routing exhaustive for the new VOD audio/subtitle preference focus cases.
- Preserved v602 scope: VOD speed/stability, language preferences, title logo reduction, and New Episode Alerts changes.

## Not changed
- Trailer system untouched.
- Backend untouched.
- Membership untouched.
- Sports untouched.
