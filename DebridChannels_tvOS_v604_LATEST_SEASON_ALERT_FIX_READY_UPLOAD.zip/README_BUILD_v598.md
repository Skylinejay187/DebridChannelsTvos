# Debrid Channels tvOS v598 — Global Frame Cadence Restore + Top Bar Layout Fix

Base: v597 source, compared against v304 smooth KSPlayer build.

Changes:
- Restored v304-style KSPlayer VOD cadence behavior.
- Removed repeated non-trailer KSPlayer play/resume nudges that were disturbing movie/show frame pacing.
- Trailer rescue/replay nudges remain trailer-only.
- KSPlayer surface defaults back to fill-style render behavior from the smoother older builds.
- Top media information bar restored to left-poster + black-glass metadata rail.
- Viewer/Movie Advisory moved to middle-right alignment instead of bottom-right.
- Trailer popup visuals untouched.
- Backend untouched; continue testing with backend v1.8.15.76.
