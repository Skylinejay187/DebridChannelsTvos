# Debrid Channels tvOS v599 — Stable Match Frame Cadence Restore

Base: v598

Scope:
- Restores v304-style stable KSPlayer VOD session behavior so Apple TV Match Frame Rate can affect playback again.
- Normal movie/show VOD no longer rebuilds KSPlayer when only reloadToken/state churn changes.
- VOD keeps the v304 KSPlayer option profile and stable User-Agent.
- Trailer rescue/retry logic remains trailer-only.
- Existing top bar v598 layout retained.
- Backend untouched; continue using backend v1.8.15.76 for trailer testing.

Notes:
- tvOS Match Frame Rate is still a system-level output setting, but v599 stops the app from fighting it by keeping VOD player sessions stable.
