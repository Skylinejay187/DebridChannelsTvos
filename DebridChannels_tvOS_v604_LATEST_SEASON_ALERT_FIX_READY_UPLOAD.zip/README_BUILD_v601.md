# Debrid Channels tvOS v601

Scope:
- Adds silent Live TV guide refresh every 20 minutes.
- Background refresh runs while VOD/movie/show playback is active without interrupting KSPlayer playback.
- Live TV guide/session cache is updated in the background so the grid/guide is fresher when returning to Live TV.
- Preserves VOD cache/proxy route from v600.
- Keeps streaming catalog quick-panel logo size from v600.
- No backend changes.
- Live TV playback/guide UI behavior is untouched except for background guide freshness.
