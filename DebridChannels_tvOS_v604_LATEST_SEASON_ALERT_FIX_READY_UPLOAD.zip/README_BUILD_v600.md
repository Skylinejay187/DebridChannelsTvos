# Debrid Channels tvOS v600 — VOD Cache Playback Route + Quick Panel Logo Size

Scope:
- VOD movie/show playback now starts from the temporary local cache/proxy URL when available instead of always forcing KSPlayer to the origin URL.
- Live TV remains direct and untouched.
- Unsupported cache sources such as plain HTTP/HLS still safely bypass to direct playback.
- Cache status text now reflects whether playback is using cache/proxy or direct fallback.
- Movies/Shows quick-panel streaming catalog logo size reduced by 50%.
- Backend untouched.

Notes:
- Previous builds could show “Cache is caching” while playback still used the original source URL because the KSPlayer path returned `url` whenever `forceKSPlayerSurface` was active.
- v600 promotes `cacheSession.playbackURL` into `preparedPlaybackURL` before the visible VOD surface starts when cache is viable.
