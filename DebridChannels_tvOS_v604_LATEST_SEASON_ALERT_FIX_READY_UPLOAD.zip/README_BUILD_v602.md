# Debrid Channels tvOS v602 — VOD Speed/Stability + Language Preferences

Scope kept focused on the uploaded v601 source.

Changes:
- VOD startup no longer blocks on long cache readiness waits.
- VOD cache/proxy is preferred during initial startup when available, but playback is not held on a black loading screen while cache warms.
- KSPlayer playback session avoids switching from origin to cache after visible playback starts, preventing overlay/control-induced stutters.
- Added VOD language preferences:
  - Audio: English / Original / Ask
  - Subtitles: Off / English / Forced Only
- Added matching language preference controls inside the VOD Settings panel and app Settings Video Player section.
- Auto English audio/subtitle selection now uses real track labels when exposed.
- Home / Movies / Shows quick-panel title logo text reduced by roughly 50%.
- New Episode Alerts strict verified-only mode now defaults off so followed-show alerts are less likely to be hidden while metadata warms.

Preserved:
- v601 background Live TV guide refresh
- v600 cache/proxy route foundation
- v599 stable KSPlayer cadence path
- Trailer system untouched
- Backend untouched
