Debrid Channels tvOS v40 full-screen responsive 1+8 layout. Preserves v14 Signulous-compatible packaging.
