# Debrid Channels tvOS v30 Signing Safe

Upload this repo package to GitHub and run **00 Build tvOS IPA From Source ZIP**.

The workflow outputs two IPA files. Extract the GitHub artifact ZIP before uploading to Signulous.

Try first:
`DebridChannelsTVOS_v30_adhoc_signulous.ipa`

If Signulous still rejects it, try:
`DebridChannelsTVOS_v30_unsigned_clean.ipa`
