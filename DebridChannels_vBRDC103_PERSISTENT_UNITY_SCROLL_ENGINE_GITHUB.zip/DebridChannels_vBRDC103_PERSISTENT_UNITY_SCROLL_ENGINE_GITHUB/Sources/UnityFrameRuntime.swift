import Foundation
import Combine

/// vBRDC102 — UNITY Frame Runtime
///
/// One process-wide authority for interactive frame ownership. Existing visual themes,
/// row-motion presets, wallpapers and transitions keep their appearance; this runtime
/// decides *when* supporting work may publish so navigation/transition geometry never
/// competes with artwork decoding, Gracenote/EPG publication, prefetch, persistence or
/// perpetual animation on the same frame.
final class UnityFrameRuntime: ObservableObject {
    static let shared = UnityFrameRuntime()

    enum Lane: String, CaseIterable {
        case navigationGeometry
        case transitionGeometry
        case criticalArtwork
        case interactiveMetadata
        case liveSchedule
        case backgroundPrefetch
        case persistence
        case ambientMotion
        case recovery
        case overlayChrome
        case playbackChrome
        case alerts
    }

    struct TransitionProfile: Equatable {
        let preflight: TimeInterval
        let visibleDuration: TimeInterval
        let branchSettle: TimeInterval
        let focusBind: TimeInterval
        let focusSettle: TimeInterval
        let ambientTail: TimeInterval
    }

    struct Snapshot: Equatable {
        var sceneActive: Bool = true
        var navigationActive: Bool = false
        var postNavigationRecoveryActive: Bool = false
        var surfaceTransitionActive: Bool = false
        var sourceOpeningActive: Bool = false
        var trailerActive: Bool = false
        var playbackActive: Bool = false
        var navigationSource: String = "none"
        var transitionSource: String = "none"
    }

    @Published private(set) var revision: UInt64 = 0
    private(set) var snapshot = Snapshot()

    private var navigationGeneration: UInt64 = 0
    private var navigationSettleWorkItem: DispatchWorkItem?
    private var navigationRecoveryWorkItem: DispatchWorkItem?

    private init() {}

    /// Keeps the existing theme motion untouched while providing one shared transaction
    /// schedule for catalog <-> persistent Live TV root handoffs.
    func catalogTransitionProfile(leavingCatalogForLiveRoot: Bool, enteringCatalogFromLiveRoot: Bool) -> TransitionProfile {
        if enteringCatalogFromLiveRoot {
            return TransitionProfile(
                preflight: 0.024,
                visibleDuration: 0.38,
                branchSettle: 0.40,
                focusBind: 0.018,
                focusSettle: 0.190,
                ambientTail: 0.220
            )
        }
        if leavingCatalogForLiveRoot {
            return TransitionProfile(
                preflight: 0.0,
                visibleDuration: 0.34,
                branchSettle: 0.36,
                focusBind: 0.230,
                focusSettle: 0.070,
                ambientTail: 0.100
            )
        }
        return TransitionProfile(
            preflight: 0.0,
            visibleDuration: 0.26,
            branchSettle: 0.28,
            focusBind: 0.060,
            focusSettle: 0.110,
            ambientTail: 0.100
        )
    }

    /// A repeat-heavy Siri Remote burst is one ownership transaction. Repeated key events
    /// extend the deadline without publishing another ObservableObject revision.
    func registerNavigationActivity(source: String, settleAfter: TimeInterval, recoveryAfter: TimeInterval = 0.085) {
        let normalized = source.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "unknown" : source
        navigationGeneration &+= 1
        let generation = navigationGeneration

        navigationSettleWorkItem?.cancel()
        navigationRecoveryWorkItem?.cancel()
        navigationRecoveryWorkItem = nil

        let wasNavigationActive = snapshot.navigationActive
        let wasRecovering = snapshot.postNavigationRecoveryActive
        snapshot.navigationSource = normalized
        snapshot.postNavigationRecoveryActive = false
        snapshot.navigationActive = true
        if !wasNavigationActive || wasRecovering { publishRevision() }

        let settle = DispatchWorkItem { [weak self] in
            guard let self, generation == self.navigationGeneration else { return }
            self.navigationSettleWorkItem = nil
            guard self.snapshot.navigationActive else { return }
            self.snapshot.navigationActive = false
            self.snapshot.navigationSource = "none"
            self.snapshot.postNavigationRecoveryActive = true
            self.publishRevision()

            let recovery = DispatchWorkItem { [weak self] in
                guard let self, generation == self.navigationGeneration else { return }
                self.navigationRecoveryWorkItem = nil
                guard self.snapshot.postNavigationRecoveryActive else { return }
                self.snapshot.postNavigationRecoveryActive = false
                self.publishRevision()
            }
            self.navigationRecoveryWorkItem = recovery
            DispatchQueue.main.asyncAfter(deadline: .now() + max(0.05, recoveryAfter), execute: recovery)
        }
        navigationSettleWorkItem = settle
        DispatchQueue.main.asyncAfter(deadline: .now() + max(0.10, settleAfter), execute: settle)
    }

    func setSurfaceTransitionActive(_ active: Bool, source: String) {
        let normalized = source.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "surface" : source
        if snapshot.surfaceTransitionActive == active {
            if active { snapshot.transitionSource = normalized }
            return
        }
        snapshot.surfaceTransitionActive = active
        snapshot.transitionSource = active ? normalized : "none"
        publishRevision()
    }

    func synchronizeExclusiveState(sceneActive: Bool, sourceOpeningActive: Bool, trailerActive: Bool, playbackActive: Bool) {
        var changed = false
        if snapshot.sceneActive != sceneActive { snapshot.sceneActive = sceneActive; changed = true }
        if snapshot.sourceOpeningActive != sourceOpeningActive { snapshot.sourceOpeningActive = sourceOpeningActive; changed = true }
        if snapshot.trailerActive != trailerActive { snapshot.trailerActive = trailerActive; changed = true }
        if snapshot.playbackActive != playbackActive { snapshot.playbackActive = playbackActive; changed = true }
        if changed { publishRevision() }
    }

    func permits(_ lane: Lane) -> Bool {
        guard snapshot.sceneActive else {
            return lane == .persistence
        }

        if snapshot.playbackActive {
            switch lane {
            case .playbackChrome, .alerts, .persistence: return true
            default: return false
            }
        }

        if snapshot.trailerActive || snapshot.sourceOpeningActive {
            switch lane {
            case .overlayChrome, .playbackChrome, .alerts, .persistence: return true
            default: return false
            }
        }

        if snapshot.surfaceTransitionActive {
            switch lane {
            case .navigationGeometry, .transitionGeometry, .criticalArtwork, .overlayChrome, .alerts:
                return true
            case .interactiveMetadata, .liveSchedule, .backgroundPrefetch, .persistence, .ambientMotion, .recovery, .playbackChrome:
                return false
            }
        }

        if snapshot.navigationActive {
            switch lane {
            case .navigationGeometry, .transitionGeometry, .overlayChrome, .alerts:
                return true
            case .criticalArtwork, .interactiveMetadata, .liveSchedule, .backgroundPrefetch, .persistence, .ambientMotion, .recovery, .playbackChrome:
                return false
            }
        }

        if snapshot.postNavigationRecoveryActive {
            switch lane {
            case .backgroundPrefetch, .ambientMotion, .recovery:
                return false
            default:
                return true
            }
        }

        return lane != .playbackChrome
    }

    /// Critical visible artwork may complete during a cross-surface transition and during
    /// the short post-navigation recovery tail, but never while geometry is actively moving.
    /// Noncritical publications wait through the complete transaction.
    func shouldDeferVisualPublication(critical: Bool) -> Bool {
        if !snapshot.sceneActive || snapshot.playbackActive || snapshot.trailerActive || snapshot.sourceOpeningActive {
            return true
        }
        if snapshot.navigationActive { return true }
        if critical { return false }
        return snapshot.postNavigationRecoveryActive || snapshot.surfaceTransitionActive
    }

    /// Cancellable idle gate used by row rebuilding, Gracenote publication and prefetch.
    /// It replaces independent hard-coded settle clocks with the runtime's real ownership state.
    func waitUntilPermitted(_ lane: Lane, maxWait: TimeInterval = 1.50, poll: TimeInterval = 0.028) async -> Bool {
        if permits(lane) { return true }
        let deadline = Date().addingTimeInterval(max(0.05, maxWait))
        while Date() < deadline {
            if Task.isCancelled { return false }
            try? await Task.sleep(nanoseconds: Self.nanoseconds(max(0.012, poll)))
            if permits(lane) { return true }
        }
        return permits(lane)
    }

    func resetTransientOwnership() {
        navigationGeneration &+= 1
        navigationSettleWorkItem?.cancel()
        navigationSettleWorkItem = nil
        navigationRecoveryWorkItem?.cancel()
        navigationRecoveryWorkItem = nil

        let hadTransient = snapshot.navigationActive
            || snapshot.postNavigationRecoveryActive
            || snapshot.surfaceTransitionActive
            || snapshot.sourceOpeningActive
            || snapshot.trailerActive
        snapshot.navigationActive = false
        snapshot.postNavigationRecoveryActive = false
        snapshot.surfaceTransitionActive = false
        snapshot.sourceOpeningActive = false
        snapshot.trailerActive = false
        snapshot.navigationSource = "none"
        snapshot.transitionSource = "none"
        if hadTransient { publishRevision() }
    }

    var diagnosticSummary: String {
        "scene=\(snapshot.sceneActive ? "active" : "inactive") nav=\(snapshot.navigationActive ? snapshot.navigationSource : "idle") navRecovery=\(snapshot.postNavigationRecoveryActive) transition=\(snapshot.surfaceTransitionActive ? snapshot.transitionSource : "idle") sourceOpening=\(snapshot.sourceOpeningActive) trailer=\(snapshot.trailerActive) playback=\(snapshot.playbackActive)"
    }

    static func nanoseconds(_ seconds: TimeInterval) -> UInt64 {
        UInt64(max(0, seconds) * 1_000_000_000)
    }

    private func publishRevision() {
        revision &+= 1
        #if DEBUG
        print("[UNITY Frame] revision=\(revision) \(diagnosticSummary)")
        #endif
    }
}
