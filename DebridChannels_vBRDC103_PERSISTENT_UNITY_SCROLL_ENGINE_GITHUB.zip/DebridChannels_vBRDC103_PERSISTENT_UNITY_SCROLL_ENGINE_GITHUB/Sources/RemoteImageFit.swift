import SwiftUI
import UIKit
import ImageIO

/// Central artwork URL upgrader used before every image request.
/// v703: Premium decode path. Do not let SwiftUI/URLCache reuse low-res image entries,
/// and do not downsample artwork before the view displays it. TMDB gets /original/;
/// provider/Cinemeta/Stremio URLs stay intact so signed URLs and catalog art do not break.
enum PremiumArtworkURL {
    static func upgraded(_ input: String?) -> String? {
        guard var raw = input?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://"), !isPrivateLocalHTTP(raw) {
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }

        if raw.contains("image.tmdb.org/t/p/") {
            let tmdbSizes = ["/w45/", "/w92/", "/w154/", "/w185/", "/w300/", "/w342/", "/w500/", "/h632/", "/w780/", "/w1280/", "/original/"]
            for size in tmdbSizes where raw.contains(size) {
                raw = raw.replacingOccurrences(of: size, with: "/original/")
            }
            for size in ["w45", "w92", "w154", "w185", "w300", "w342", "w500", "h632", "w780", "w1280"] {
                raw = raw.replacingOccurrences(of: "/t/p/\(size)", with: "/t/p/original")
            }
        }

        return raw
    }

    private static func isPrivateLocalHTTP(_ raw: String) -> Bool {
        guard let host = URL(string: raw)?.host?.lowercased() else { return false }
        if host == "localhost" || host == "127.0.0.1" || host.hasSuffix(".local") { return true }
        if host.hasPrefix("10.") || host.hasPrefix("192.168.") { return true }
        let parts = host.split(separator: ".").compactMap { Int($0) }
        if parts.count == 4, parts[0] == 172, (16...31).contains(parts[1]) { return true }
        return false
    }

    static func url(_ input: String?) -> URL? {
        guard let raw = upgraded(input), !raw.isEmpty else { return nil }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }
}

// vBRDC091: artwork loaded by short-lived heavyweight surfaces must never evict the
// warm Home/Movies/Shows cache. Sports and Favorites get isolated decoded caches that
// are released on surface exit; persistent catalog/Live TV artwork keeps the donor cache.
enum PremiumArtworkCacheDomain: Hashable {
    case persistent
    case sports
    case favorites
}

private struct PremiumArtworkCacheDomainEnvironmentKey: EnvironmentKey {
    static let defaultValue: PremiumArtworkCacheDomain = .persistent
}

extension EnvironmentValues {
    var premiumArtworkCacheDomain: PremiumArtworkCacheDomain {
        get { self[PremiumArtworkCacheDomainEnvironmentKey.self] }
        set { self[PremiumArtworkCacheDomainEnvironmentKey.self] = newValue }
    }
}

// vBRDC099: mounted catalog artwork gets a direct generation-based recovery signal after
// playback/foreground/surface handoffs. This intentionally is NOT an ObservableObject:
// publishing one global epoch through SwiftUI would invalidate every mounted artwork view
// at once and could recreate the very return/scroll hitch this recovery path is meant to fix.
// The coordinator talks directly to weakly registered loaders; healthy images are untouched.
@MainActor
final class PremiumArtworkRehydrationCoordinator {
    static let shared = PremiumArtworkRehydrationCoordinator()
    private var generation: UInt64 = 0

    private init() {}

    func force(reason: String) {
        generation &+= 1
        PremiumRemoteImageLoader.forceMountedBlankRehydration(reason: reason, generation: generation)
    }
}

@MainActor
final class PremiumRemoteImageLoader: ObservableObject {
    @Published var image: UIImage?
    @Published private(set) var imageURL: URL? = nil
    @Published var failed = false

    // vBRDC088: a single original source URL may legitimately be decoded at different
    // display budgets (small rail poster vs. focused card vs. full-screen hero). Keep the
    // decode bucket in every cache/in-flight key so a display-sized card bitmap can never
    // poison a full-resolution presentation that requests the same source URL.
    private struct LoadKey: Hashable {
        let url: URL
        let maxPixelSize: Int
        let domain: PremiumArtworkCacheDomain

        var cacheKey: NSString {
            "\(url.absoluteString)|decode=\(maxPixelSize)|domain=\(String(describing: domain))" as NSString
        }
    }

    private static let memoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        // Same 96 MB persistent process budget as the donor build. vBRDC088 makes high-churn card
        // entries display-sized, allowing more useful warm images inside the same ceiling.
        cache.countLimit = 160
        cache.totalCostLimit = 96 * 1024 * 1024
        return cache
    }()
    private static let sportsMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 64
        cache.totalCostLimit = 28 * 1024 * 1024
        return cache
    }()
    private static let favoritesMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 48
        cache.totalCostLimit = 28 * 1024 * 1024
        return cache
    }()

    // vBRDC099: playback may release the large persistent decode reservoir, but the exact
    // artwork visible immediately before playback is useful return-state. Snapshot only
    // mounted persistent card/hero owners into this small bounded cache so Home/Movies/Shows
    // can repaint synchronously on return without carrying the full 96 MB catalog cache.
    private static let playbackReturnMemoryCache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.countLimit = 36
        cache.totalCostLimit = 28 * 1024 * 1024
        return cache
    }()

    private final class WeakBox {
        weak var value: PremiumRemoteImageLoader?
        init(_ value: PremiumRemoteImageLoader) { self.value = value }
    }
    private static var mountedLoaders: [WeakBox] = []

    private static func cache(for domain: PremiumArtworkCacheDomain) -> NSCache<NSString, UIImage> {
        switch domain {
        case .persistent: return memoryCache
        case .sports: return sportsMemoryCache
        case .favorites: return favoritesMemoryCache
        }
    }

    // vBRDC092: a popup/focused card may request a larger decode bucket than the same
    // artwork already visible on the row. Use that warm lower-resolution bitmap as an
    // immediate provisional frame, then replace it directly when the requested decode
    // finishes. This removes black/transparent reload flashes without lowering final quality.
    private static let reusableDecodeBuckets = [3072, 2560, 2048, 1600, 1280, 1024, 768, 640, 512, 384, 320]

    private static func bestProvisionalCachedImage(
        url: URL,
        requestedMaxPixelSize: Int,
        domain: PremiumArtworkCacheDomain
    ) -> UIImage? {
        let candidates: [Int]
        if requestedMaxPixelSize == 0 {
            candidates = reusableDecodeBuckets
        } else {
            candidates = reusableDecodeBuckets.filter { $0 < requestedMaxPixelSize }
        }
        let domains: [PremiumArtworkCacheDomain] = domain == .persistent ? [.persistent] : [domain, .persistent]
        for candidateDomain in domains {
            for bucket in candidates {
                let candidate = LoadKey(url: url, maxPixelSize: bucket, domain: candidateDomain)
                if let image = cache(for: candidateDomain).object(forKey: candidate.cacheKey) { return image }
                if candidateDomain == .persistent,
                   let image = playbackReturnMemoryCache.object(forKey: candidate.cacheKey) { return image }
            }
        }
        return nil
    }
    private static var inFlightLoads: [LoadKey: [ObjectIdentifier: (UIImage?) -> Void]] = [:]
    private static var pendingSubscriberCancellationTasks: [LoadKey: Task<Void, Never>] = [:]
    private static var prefetchTasks: [URL: URLSessionDataTask] = [:]
    private static var activeNetworkTasks: [LoadKey: URLSessionDataTask] = [:]
    private static var nonRetryableFailures: Set<LoadKey> = []
    // vBRDC092: detail artwork may be warmed after focus settles, but that speculative
    // decode must never survive into the next Siri Remote movement. Once a real view
    // subscribes to the key it stops being speculative and is allowed to finish.
    private static var idlePrewarmKeys: Set<LoadKey> = []
    private static var exclusivePlaybackActive = false
    private static let maxActivePrefetchTasks = 4
    private static let normalDecodedCacheLimitBytes = 96 * 1024 * 1024
    private static let exclusiveVODDecodedCacheLimitBytes = 32 * 1024 * 1024
    private static let imageSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 24
        configuration.timeoutIntervalForResource = 36
        configuration.waitsForConnectivity = true
        configuration.httpMaximumConnectionsPerHost = 6
        return URLSession(configuration: configuration)
    }()
    private var task: URLSessionDataTask?
    private var currentURL: URL?
    private var currentKey: LoadKey?
    // vBRDC090: decoded pixels may finish on the same frame as a Siri Remote move.
    // Cache them immediately, but defer the ObservableObject publication until focus
    // settles so artwork completion cannot steal the navigation frame budget.
    private var deferredPublicationTask: Task<Void, Never>?
    // vBRDC099: a transient CDN/DNS miss must not pin a mounted catalog card blank until
    // the user scrolls it away. Keep retries view-owned and bounded so cancellation still
    // follows normal SwiftUI lifecycle.
    private var transientRetryTask: Task<Void, Never>?
    private var transientRetryAttempt: Int = 0
    // vBRDC101: visible catalog hero/card/logo artwork is transition-critical. It may
    // publish during the bounded UNITY surface handoff while ordinary/background image
    // completions remain deferred. Navigation bursts and playback exclusivity still win.
    private var allowPublicationDuringSurfaceHandoff: Bool = false

    init() {
        Self.mountedLoaders.removeAll { $0.value == nil }
        Self.mountedLoaders.append(WeakBox(self))
    }

    private static func snapshotMountedPersistentArtworkForPlaybackReturn(reason: String) {
        // Do not clear the rolling reservoir here. Catalog views may already have unmounted
        // (for example Home -> Live -> channel playback), and their recently decoded cards
        // are exactly what we want to keep for a later smooth catalog return.
        var retained: [WeakBox] = []
        retained.reserveCapacity(mountedLoaders.count)
        var captured = 0
        for box in mountedLoaders {
            guard let loader = box.value else { continue }
            retained.append(box)
            guard let key = loader.currentKey,
                  key.domain == .persistent,
                  key.maxPixelSize > 0,
                  key.maxPixelSize <= 1280,
                  let image = loader.image,
                  loader.imageURL == key.url else { continue }
            let cost = image.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
            playbackReturnMemoryCache.setObject(image, forKey: key.cacheKey, cost: cost)
            captured += 1
        }
        mountedLoaders = retained
        print("[ArtworkContinuity][vBRDC099] captured=\(captured) mounted=\(retained.count) reason=\(reason)")
    }

    func load(
        _ url: URL?,
        preserveCurrentImage: Bool = false,
        maxPixelSize: Int? = nil,
        cacheDomain: PremiumArtworkCacheDomain = .persistent,
        allowPublicationDuringSurfaceHandoff: Bool = false
    ) {
        self.allowPublicationDuringSurfaceHandoff = allowPublicationDuringSurfaceHandoff
        guard let url else {
            cancel()
            image = nil
            imageURL = nil
            failed = false
            currentURL = nil
            currentKey = nil
            return
        }
        let decodeBudget = maxPixelSize.map { max(320, $0) } ?? 0
        let key = LoadKey(url: url, maxPixelSize: decodeBudget, domain: cacheDomain)
        if currentKey == key, image != nil { return }

        let keyChanged = currentKey != key
        if keyChanged {
            transientRetryTask?.cancel()
            transientRetryTask = nil
            transientRetryAttempt = 0
        }

        if let previousKey = currentKey {
            Self.removeInFlightSubscriber(for: previousKey, owner: self)
        }
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil
        task = nil
        currentURL = url
        currentKey = key
        failed = false
        if !preserveCurrentImage {
            image = nil
            imageURL = nil
        }

        if let cached = Self.cache(for: key.domain).object(forKey: key.cacheKey) {
            imageURL = url
            image = cached
            transientRetryAttempt = 0
            return
        }
        if key.domain == .persistent,
           let cached = Self.playbackReturnMemoryCache.object(forKey: key.cacheKey) {
            let cost = cached.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
            Self.memoryCache.setObject(cached, forKey: key.cacheKey, cost: cost)
            imageURL = url
            image = cached
            transientRetryAttempt = 0
            return
        }
        // vBRDC091: transient Sports/Favorites surfaces may reuse an already-warm
        // persistent catalog bitmap, but they never write their own new decode into the
        // persistent cache. This preserves fast entry without allowing those surfaces to
        // evict Home/Movies/Shows artwork.
        if key.domain != .persistent {
            let persistentKey = LoadKey(url: url, maxPixelSize: decodeBudget, domain: .persistent)
            if let cached = Self.memoryCache.object(forKey: persistentKey.cacheKey) {
                imageURL = url
                image = cached
                return
            }
        }

        // Show the already-decoded row/card image immediately while the larger requested
        // bucket upgrades in place. Do not return: the final decode still proceeds.
        if let provisional = Self.bestProvisionalCachedImage(
            url: url,
            requestedMaxPixelSize: decodeBudget,
            domain: key.domain
        ) {
            imageURL = url
            image = provisional
        }

        if Self.enqueueInFlightLoad(for: key, owner: self) { return }

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 24
        request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS-PremiumArtwork/1.0", forHTTPHeaderField: "User-Agent")

        task = Self.imageSession.dataTask(with: request) { data, response, error in
            let status = (response as? HTTPURLResponse)?.statusCode
            let permanentClientFailure = status.map { (400...499).contains($0) && $0 != 408 && $0 != 429 } ?? false
            guard error == nil,
                  !permanentClientFailure,
                  status.map({ (200...299).contains($0) || $0 == 408 || $0 == 429 || $0 >= 500 }) ?? true,
                  let data,
                  !data.isEmpty else {
                DispatchQueue.main.async {
                    Self.activeNetworkTasks.removeValue(forKey: key)
                    if permanentClientFailure {
                        if Self.nonRetryableFailures.count >= 256 { Self.nonRetryableFailures.removeAll(keepingCapacity: true) }
                        Self.nonRetryableFailures.insert(key)
                    } else {
                        Self.nonRetryableFailures.remove(key)
                    }
                    Self.finishInFlightLoad(for: key, image: nil)
                }
                return
            }
            // vBRDC088: retain original source URLs/quality policy, but card callers can ask
            // ImageIO to decode only the pixels the display can use. This removes multi-MP
            // decompression/GPU upload waves during scrolling without changing card geometry,
            // artwork selection, interpolation, crop mode, or full-screen image behavior.
            let decoded = Self.decodedForDisplay(data: data, maxPixelSize: key.maxPixelSize)
            DispatchQueue.main.async {
                Self.activeNetworkTasks.removeValue(forKey: key)
                Self.nonRetryableFailures.remove(key)
                Self.finishInFlightLoad(for: key, image: decoded)
            }
        }
        if let task { Self.activeNetworkTasks[key] = task }
        task?.resume()
    }

    func cancel() {
        transientRetryTask?.cancel()
        transientRetryTask = nil
        transientRetryAttempt = 0
        if let key = currentKey {
            Self.removeInFlightSubscriber(for: key, owner: self)
        }
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil
        task = nil
        currentURL = nil
        currentKey = nil
        image = nil
        imageURL = nil
        failed = false
    }

    private func forceRehydrateCurrentIfBlank() {
        guard !Self.exclusivePlaybackActive,
              !VODExclusivePlaybackGate.isActive,
              image == nil,
              let key = currentKey,
              !Self.nonRetryableFailures.contains(key) else { return }
        // A playback/background cancellation can leave a mounted owner with a valid request
        // identity but no URLSession task. Restart exactly that request. In-flight work remains
        // deduplicated by LoadKey, and a real 4xx is deliberately not hammered again.
        failed = false
        load(
            key.url,
            preserveCurrentImage: true,
            maxPixelSize: key.maxPixelSize > 0 ? key.maxPixelSize : nil,
            cacheDomain: key.domain,
            allowPublicationDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff
        )
    }

    static func forceMountedBlankRehydration(reason: String, generation: UInt64) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive else { return }
        var retained: [WeakBox] = []
        retained.reserveCapacity(mountedLoaders.count)
        var restarted = 0
        for box in mountedLoaders {
            guard let loader = box.value else { continue }
            retained.append(box)
            let before = loader.image
            loader.forceRehydrateCurrentIfBlank()
            if before == nil, loader.image == nil, loader.currentKey != nil { restarted += 1 }
        }
        mountedLoaders = retained
        print("[ArtworkRehydrate][vBRDC099] generation=\(generation) mounted=\(retained.count) blankCandidates=\(restarted) reason=\(reason)")
    }

    static func prefetch(_ urls: [URL], keeping keepAliveURLs: Set<URL> = []) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive else { return }
        let uniqueURLs = Array(Set(urls)).prefix(18)
        cancelObsoletePrefetches(keeping: Set(uniqueURLs).union(keepAliveURLs))

        for url in uniqueURLs {
            let key = LoadKey(url: url, maxPixelSize: 0, domain: .persistent)
            if cache(for: key.domain).object(forKey: key.cacheKey) != nil { continue }
            if inFlightLoads[key] != nil { continue }
            if prefetchTasks[url] != nil { continue }
            if prefetchTasks.count >= maxActivePrefetchTasks { break }

            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 18
            request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS-PremiumArtworkPrefetch/1.0", forHTTPHeaderField: "User-Agent")

            let task = Self.imageSession.dataTask(with: request) { data, _, error in
                guard error == nil, let data, !data.isEmpty else {
                    DispatchQueue.main.async { prefetchTasks.removeValue(forKey: url) }
                    return
                }
                let decoded = Self.decodedForDisplay(data: data, maxPixelSize: 0)
                DispatchQueue.main.async {
                    prefetchTasks.removeValue(forKey: url)
                    if let decoded {
                        let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                        cache(for: key.domain).setObject(decoded, forKey: key.cacheKey, cost: cost)
                    }
                }
            }
            prefetchTasks[url] = task
            task.resume()
        }
    }

    /// vBRDC092: warm one exact presentation bucket without creating a view-owned loader.
    /// If the destination view mounts while this request is still running it subscribes to
    /// the same in-flight key rather than starting a duplicate network/decode operation.
    static func prewarm(
        _ url: URL?,
        maxPixelSize: Int,
        cacheDomain: PremiumArtworkCacheDomain = .persistent
    ) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive, let url else { return }
        let key = LoadKey(url: url, maxPixelSize: max(320, maxPixelSize), domain: cacheDomain)
        if cache(for: cacheDomain).object(forKey: key.cacheKey) != nil { return }
        if inFlightLoads[key] != nil || activeNetworkTasks[key] != nil { return }

        // Empty subscriber map marks a speculative in-flight decode. A view that arrives
        // later joins this map through enqueueInFlightLoad() and promotes it to required.
        inFlightLoads[key] = [:]
        idlePrewarmKeys.insert(key)
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 18
        request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS-DetailArtworkPrewarm/1.0", forHTTPHeaderField: "User-Agent")

        let task = imageSession.dataTask(with: request) { data, _, error in
            let decoded: UIImage?
            if error == nil, let data, !data.isEmpty {
                decoded = decodedForDisplay(data: data, maxPixelSize: key.maxPixelSize)
            } else {
                decoded = nil
            }
            DispatchQueue.main.async {
                activeNetworkTasks.removeValue(forKey: key)
                idlePrewarmKeys.remove(key)
                if let decoded {
                    let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                    cache(for: key.domain).setObject(decoded, forKey: key.cacheKey, cost: cost)
                }
                finishInFlightLoad(for: key, image: decoded)
            }
        }
        activeNetworkTasks[key] = task
        task.resume()
    }

    /// Cancel only speculative detail prewarms that no visible image loader has joined.
    /// Called at the start of a new navigation burst so high-resolution decode/network work
    /// cannot become a hidden source of frame loss while the user is scrolling again.
    static func cancelIdlePrewarmsForNavigation() {
        let keys = idlePrewarmKeys
        for key in keys {
            guard inFlightLoads[key]?.isEmpty == true else {
                idlePrewarmKeys.remove(key)
                continue
            }
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
            inFlightLoads.removeValue(forKey: key)
            idlePrewarmKeys.remove(key)
        }
    }

    static func beginExclusivePlayback() {
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "VOD playback entry")
        exclusivePlaybackActive = true
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        idlePrewarmKeys.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        memoryCache.totalCostLimit = exclusiveVODDecodedCacheLimitBytes
        print("[ReleaseStability][v1133] VOD entry released decoded artwork cache and reduced playback cache ceiling to 32 MB")
    }

    static func releaseDecodedArtworkForHiddenVODOverlay() {
        guard exclusivePlaybackActive || VODExclusivePlaybackGate.isActive else { return }
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        print("[ReleaseStability][v1144] hidden VOD overlay cancelled decorative artwork work; bounded decoded cache retained")
    }

    static func endExclusivePlayback() {
        guard exclusivePlaybackActive else {
            memoryCache.totalCostLimit = normalDecodedCacheLimitBytes
            return
        }
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        // Entry already released heavyweight caches. Clearing again on exit races the
        // remounting catalog and can erase artwork that just finished during focus recovery.
        memoryCache.totalCostLimit = normalDecodedCacheLimitBytes
        exclusivePlaybackActive = false
    }

    static func suspendForBackground() {
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "scene inactive")
        // Background is a real lifecycle boundary. Cancel the underlying request owners too;
        // otherwise a request started before sleep can finish afterward and repopulate a cache
        // the app intentionally released. Foreground rehydration restarts only mounted blanks.
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        inFlightLoads.removeAll()
        idlePrewarmKeys.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        print("[ArtworkLifecycle][vBRDC099] suspended all artwork request owners and released decoded cache")
    }

    static func handleMemoryPressure() {
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        playbackReturnMemoryCache.removeAllObjects()
        nonRetryableFailures.removeAll(keepingCapacity: false)
        print("[ArtworkLifecycle][Phase7] released decoded artwork cache and prefetch work")
    }

    static func releaseTransientSurfaceResources(domain: PremiumArtworkCacheDomain, reason: String) {
        guard domain != .persistent else { return }

        let keys = activeNetworkTasks.keys.filter { $0.domain == domain }
        for key in keys {
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
        }

        let pendingKeys = pendingSubscriberCancellationTasks.keys.filter { $0.domain == domain }
        for key in pendingKeys {
            pendingSubscriberCancellationTasks[key]?.cancel()
            pendingSubscriberCancellationTasks.removeValue(forKey: key)
        }

        let inFlightKeys = inFlightLoads.keys.filter { $0.domain == domain }
        for key in inFlightKeys {
            inFlightLoads.removeValue(forKey: key)
        }

        cache(for: domain).removeAllObjects()
        print("[ArtworkLifecycle][vBRDC091] released \(domain) transient surface artwork reason=\(reason)")
    }

    static func cancelObsoletePrefetches(keeping urlsToKeep: Set<URL>) {
        let obsolete = prefetchTasks.keys.filter { !urlsToKeep.contains($0) }
        for url in obsolete {
            prefetchTasks[url]?.cancel()
            prefetchTasks.removeValue(forKey: url)
        }
    }

    static func releaseDecodedArtworkForLiveTVPlayback() {
        snapshotMountedPersistentArtworkForPlaybackReturn(reason: "Live TV playback entry")
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        memoryCache.removeAllObjects()
        sportsMemoryCache.removeAllObjects()
        favoritesMemoryCache.removeAllObjects()
        print("[LiveTVMemory][v975] released decoded artwork cache for full-screen Live TV playback")
    }

    private static func enqueueInFlightLoad(for key: LoadKey, owner: PremiumRemoteImageLoader) -> Bool {
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: key)
        let ownerID = ObjectIdentifier(owner)
        let callback: (UIImage?) -> Void = { [weak owner] decoded in
            guard let owner, owner.currentKey == key else { return }
            if let decoded {
                let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                cache(for: key.domain).setObject(decoded, forKey: key.cacheKey, cost: cost)
                // Keep a small rolling set of recent catalog-card decodes even after those
                // views unmount. This covers Home -> Live -> playback -> Home as well as VOD
                // return without retaining full-screen/original artwork during playback.
                if key.domain == .persistent, key.maxPixelSize > 0, key.maxPixelSize <= 1280 {
                    playbackReturnMemoryCache.setObject(decoded, forKey: key.cacheKey, cost: cost)
                }
            }
            owner.publishDecodedImage(decoded, for: key)
        }

        if inFlightLoads[key] != nil {
            inFlightLoads[key]?[ownerID] = callback
            idlePrewarmKeys.remove(key)
            return true
        }
        inFlightLoads[key] = [ownerID: callback]
        return false
    }

    private func publishDecodedImage(_ decoded: UIImage?, for key: LoadKey) {
        deferredPublicationTask?.cancel()
        deferredPublicationTask = nil

        let apply: @MainActor () -> Void = { [weak self] in
            guard let self, self.currentKey == key else { return }
            if let decoded {
                self.imageURL = key.url
                self.image = decoded
                self.failed = false
                self.transientRetryAttempt = 0
                self.transientRetryTask?.cancel()
                self.transientRetryTask = nil
            } else {
                self.imageURL = nil
                self.failed = true
                self.scheduleTransientRetryIfNeeded(for: key)
            }
        }

        guard UnityAnimationCoordinator.shared.shouldDeferVisualPublication(
            allowDuringSurfaceHandoff: allowPublicationDuringSurfaceHandoff
        ) else {
            apply()
            return
        }

        deferredPublicationTask = Task { @MainActor [weak self] in
            // vBRDC102: decoded image publication no longer owns a private 35 ms polling
            // clock or force-publishes after 350 ms. It joins the exact same frame lane as
            // navigation/UNITY. Obsolete owners cancel naturally as focus changes.
            guard let self else { return }
            let lane: UnityFrameRuntime.Lane = self.allowPublicationDuringSurfaceHandoff
                ? .criticalArtwork
                : .backgroundPrefetch
            guard await UnityFrameRuntime.shared.waitUntilPermitted(lane, maxWait: 2.50),
                  !Task.isCancelled,
                  self.currentKey == key else {
                self.deferredPublicationTask = nil
                return
            }
            apply()
            self.deferredPublicationTask = nil
        }
    }

    private func scheduleTransientRetryIfNeeded(for key: LoadKey) {
        guard currentKey == key,
              image == nil,
              transientRetryAttempt < 2,
              !Self.nonRetryableFailures.contains(key),
              !Self.exclusivePlaybackActive,
              !VODExclusivePlaybackGate.isActive else { return }

        transientRetryTask?.cancel()
        transientRetryAttempt += 1
        let delay: UInt64 = transientRetryAttempt == 1 ? 500_000_000 : 1_400_000_000
        transientRetryTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: delay)
            guard !Task.isCancelled,
                  let self,
                  self.currentKey == key,
                  self.image == nil,
                  !Self.exclusivePlaybackActive,
                  !VODExclusivePlaybackGate.isActive else { return }
            self.failed = false
            self.load(
                key.url,
                preserveCurrentImage: true,
                maxPixelSize: key.maxPixelSize > 0 ? key.maxPixelSize : nil,
                cacheDomain: key.domain
            )
        }
    }

    private static func removeInFlightSubscriber(for key: LoadKey, owner: PremiumRemoteImageLoader) {
        guard var subscribers = inFlightLoads[key] else { return }
        subscribers.removeValue(forKey: ObjectIdentifier(owner))
        guard subscribers.isEmpty else {
            inFlightLoads[key] = subscribers
            return
        }

        inFlightLoads[key] = subscribers
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks[key] = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 280_000_000)
            guard !Task.isCancelled, inFlightLoads[key]?.isEmpty == true else {
                pendingSubscriberCancellationTasks[key] = nil
                return
            }
            inFlightLoads.removeValue(forKey: key)
            activeNetworkTasks[key]?.cancel()
            activeNetworkTasks.removeValue(forKey: key)
            pendingSubscriberCancellationTasks[key] = nil
        }
    }

    private static func finishInFlightLoad(for key: LoadKey, image: UIImage?) {
        pendingSubscriberCancellationTasks[key]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: key)
        guard let callbacks = inFlightLoads.removeValue(forKey: key) else { return }
        callbacks.values.forEach { $0(image) }
    }

    nonisolated private static func decodedForDisplay(data: Data, maxPixelSize: Int) -> UIImage? {
        autoreleasepool {
            if maxPixelSize > 0,
               let imageSource = CGImageSourceCreateWithData(data as CFData, nil) {
                let options: [CFString: Any] = [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceShouldCacheImmediately: true,
                    kCGImageSourceThumbnailMaxPixelSize: maxPixelSize
                ]
                if let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) {
                    return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
                }
            }

            // Full-screen/default callers preserve donor behavior exactly. Also serves as a
            // compatibility fallback for formats ImageIO cannot thumbnail directly.
            guard let source = UIImage(data: data) else { return nil }
            guard source.cgImage != nil else { return source }
            let format = UIGraphicsImageRendererFormat.default()
            format.scale = source.scale
            format.opaque = false
            let renderer = UIGraphicsImageRenderer(size: source.size, format: format)
            return renderer.image { _ in
                source.draw(in: CGRect(origin: .zero, size: source.size))
            }
        }
    }

    static var releaseStabilityActiveWorkCount: Int {
        activeNetworkTasks.count + prefetchTasks.count + inFlightLoads.count
    }

    static var releaseStabilityDecodedCacheLimitBytes: Int {
        exclusivePlaybackActive ? exclusiveVODDecodedCacheLimitBytes : normalDecodedCacheLimitBytes
    }

    deinit {
        transientRetryTask?.cancel()
        task = nil
    }
}


private struct RemoteImageFitAspectModifier: ViewModifier {
    let mode: RemoteImageFit.Mode

    @ViewBuilder
    func body(content: Content) -> some View {
        switch mode {
        case .fill:
            content.scaledToFill()
        case .fit:
            content.scaledToFit()
        case .stretch:
            content
        }
    }
}

struct RemoteImageFit: View {
    enum Mode { case fill, fit, stretch }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true
    // Optional display decode budget. nil keeps the donor's original-resolution decode.
    // High-churn card surfaces set a generous cap above their rendered size in vBRDC088.
    var maxPixelSize: Int? = nil
    // vBRDC021: opt-in only. Keeps the previous decoded frame visible while a new URL
    // is downloaded/decoded, then swaps directly to the ready replacement.
    var preservePreviousOnURLChange: Bool = false
    // vBRDC101: opt-in for visible hero/card/logo layers that must be allowed to paint
    // while the outer UNITY branch itself is animating. All other exclusivity rules remain.
    var publishDuringSurfaceHandoff: Bool = false

    @StateObject private var loader = PremiumRemoteImageLoader()
    @Environment(\.premiumArtworkCacheDomain) private var cacheDomain

    private var resolvedURL: URL? {
        PremiumArtworkURL.url(url)
    }

    var body: some View {
        Group {
            if let image = loader.image, preservePreviousOnURLChange || loader.imageURL == resolvedURL {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .antialiased(true)
                    .modifier(RemoteImageFitAspectModifier(mode: mode))
                    // vBRDC023: the seamless catalog path already retains the old decoded
                    // frame until the replacement is ready. Do not then fade the ready
                    // replacement from transparent; that final opacity transition was the
                    // remaining small brightness flash seen on physical Apple TV.
                    .transition(preservePreviousOnURLChange ? .identity : .opacity)
            } else {
                placeholder(showSpinner: !loader.failed && resolvedURL != nil)
            }
        }
        .clipped()
        .animation(preservePreviousOnURLChange ? nil : .easeInOut(duration: 0.18), value: loader.imageURL)
        .onAppear {
            loader.load(
                resolvedURL,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff
            )
        }
        .onChange(of: resolvedURL) { newValue in
            loader.load(
                newValue,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: maxPixelSize,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff
            )
        }
        .onChange(of: maxPixelSize) { newValue in
            loader.load(
                resolvedURL,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: newValue,
                cacheDomain: cacheDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff
            )
        }
        .onChange(of: cacheDomain) { newDomain in
            loader.load(
                resolvedURL,
                preserveCurrentImage: preservePreviousOnURLChange,
                maxPixelSize: maxPixelSize,
                cacheDomain: newDomain,
                allowPublicationDuringSurfaceHandoff: publishDuringSurfaceHandoff
            )
        }
        .onDisappear { loader.cancel() }
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            if showPlaceholder {
                LinearGradient(colors: [.black.opacity(0.92), .gray.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if showSpinner {
                    ProgressView().scaleEffect(0.78).opacity(0.30)
                }
            } else {
                Color.clear
            }
        }
    }
}
