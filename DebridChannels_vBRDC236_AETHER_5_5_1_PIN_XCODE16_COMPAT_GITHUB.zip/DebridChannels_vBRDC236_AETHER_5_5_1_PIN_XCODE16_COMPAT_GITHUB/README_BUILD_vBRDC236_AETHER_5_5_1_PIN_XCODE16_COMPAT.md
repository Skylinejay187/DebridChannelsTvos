# vBRDC236 — AetherEngine 5.5.1 Exact Pin / Xcode 16.4 tvOS Compatibility

Built directly from vBRDC235.

## Build failure fixed
GitHub Actions successfully extracted vBRDC235 and reached Xcode compilation, but XcodeGen's `from: 6.30.1` requirement floated SwiftPM to AetherEngine 6.80.0. That release references newer SDK symbols and stricter Swift concurrency paths that fail under the workflow's Xcode 16.4 tvOS SDK.

## Changes
- Pin AetherEngine exactly to 5.5.1 so SwiftPM cannot float to 6.x/6.80.0.
- Keep AetherEngine as the primary playback engine and KSPlayer as compatibility/failure fallback.
- Adapt the phase-1 host to the 5.5.1 public surface: remove `liveJoinProfile` and `nativeRemoteHLSIngestFallback`, and use `isSessionReady` as the cinematic-cover readiness bridge.
- Preserve Debrid Channels ownership of resume/progress, Now Playing, Bluetooth/media commands, source failover, prepared-source zero-delay handoff, VOD overlay and Live TV UI/focus work.
- No unrelated navigation or catalog behavior changed.

Version: 1.0.939 (939)
Release: vBRDC236
