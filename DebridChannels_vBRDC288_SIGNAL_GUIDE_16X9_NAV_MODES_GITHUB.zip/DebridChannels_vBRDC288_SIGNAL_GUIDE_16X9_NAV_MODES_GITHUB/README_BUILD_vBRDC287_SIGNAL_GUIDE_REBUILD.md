# vBRDC287 — Signal Live Guide Rebuild

Version: **1.0.990 (990)**

This build replaces the v286 guide geometry with a full-canvas guide-first Live TV surface.

- Guide fills the television canvas beneath Signal's persistent top navigation.
- Left category rail is a continuous black plane with no divider line or boxed sidebar.
- Selected category uses the large light focus tile treatment.
- Program information hero is substantially larger.
- Live channel preview/artwork occupies the upper-right and is masked/faded into black toward the metadata area rather than appearing as a hard preview box.
- Timeline uses larger station rows, larger dark program blocks, one light focused current-program block and a red live-time marker.
- Down from the Signal top menu enters the guide directly.
- Guide remains the Live TV landing surface; retired Grid/List/Carousel renderers are not mounted.
- Existing startup modes, preview/player routing, EPG sources, channel actions, icon/wordmark and Top Shelf assets are preserved.

The guide rebuild is implemented with native SwiftUI and existing Signal playback/data models; no third-party product name or branding is shown in the interface.
