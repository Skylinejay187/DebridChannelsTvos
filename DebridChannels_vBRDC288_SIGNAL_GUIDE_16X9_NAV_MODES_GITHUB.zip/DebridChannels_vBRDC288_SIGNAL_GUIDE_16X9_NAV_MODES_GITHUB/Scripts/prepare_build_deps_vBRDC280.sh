#!/bin/bash
# Compatibility entry point retained for older GitHub workflows that still call the vBRDC280 path.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$SCRIPT_DIR/prepare_build_deps_vBRDC284.sh" "$@"
