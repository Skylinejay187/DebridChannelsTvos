# vBRDC288 — Signal Live Guide 16:9 + Navigation Modes

Version: **1.0.991 (991)**

This build keeps the guide-first Live TV architecture and rebuilds its presentation around a 16:9 tvOS-safe canvas.

## Live TV guide
- Uses the actual post-padding GeometryReader size so the guide no longer lays itself out against the full pre-safe-area screen and then gets compressed/clipped.
- Safe margins are 68 pt left/right, 58 pt bottom, and 62 pt top for Side Menu mode or 106 pt when the Signal top menu is visible.
- Programme hero remains integrated with the upper-right live preview/artwork and a broader leftward black fade.
- Timeline cells are flatter/darker and no longer embed artwork thumbnails, closer to the supplied television-guide reference.
- Current programme focus remains a light tile; current-time line and Now/Next data are preserved.

## Navigation modes
Settings now cycles **Top Menu → Side Menu → Both**.
- Top Menu: existing Signal top navigation only.
- Side Menu: hides the persistent top menu while Live TV is active and uses the collapsible left app rail.
- Both: keeps both navigation paths for recovery/testing.

The side app rail uses staged behavior inspired by the supplied video: compact icon rail while browsing, LEFT expands it to labels, RIGHT collapses it, and RIGHT again returns focus to guide categories.

## Preserved
App icon and inside SIGNAL wordmark, Top Shelf assets, native YouTube trailer resolution, Aether/KS fallback architecture, guide-first startup choices, Live TV source/EPG/Gracenote loading, Quick Guide, channel actions, and playback return-to-guide behavior are unchanged.
