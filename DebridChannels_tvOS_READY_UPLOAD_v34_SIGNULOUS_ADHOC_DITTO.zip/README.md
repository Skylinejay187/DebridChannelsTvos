# Debrid Channels tvOS v34

Upload this repository ZIP to GitHub. Run `00 Build tvOS IPA From Source ZIP`.

Download the artifact, extract it, and upload only:

`DebridChannelsTVOS_v34_SIGNULOUS_UPLOAD_ME.ipa`

This build uses an ad-hoc signed tvOS app bundle packaged with ditto for Signulous re-sign parsing.
