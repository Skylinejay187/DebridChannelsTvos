# Signal vBRDC280 — 1.0.983 (983)

Patched directly from vBRDC279.

## Stabilization fixes

- Uses the final approved black SIGNAL artwork for the real tvOS Home Screen icon and compatibility icon assets. The external gold/orange perimeter lighting is gone; only the internal SIGNAL amber accents remain.
- Keeps a valid tvOS layered AppIcon stack with an opaque final Back layer at 400x240 and 1280x768.
- Keeps the raw high-resolution SIGNAL wordmark fallback bundled for the in-app themed logo so it is not dependent on an Assets.car lookup succeeding.
- Rebuilds Top Shelf static art at 1920x720 and 2320x720 without stretching the approved artwork and bumps the Top Shelf cache identity.
- Preserves vBRDC279's Aether trailer presentation fix: AetherEngine owns `resizeAspectFill` at the engine layer.
- Hardens Aether TV-series Up Next. Aether EOF is now recognized from ended/finished/completed states or a one-shot decoder-clock EOF fallback, and the app directly enters the decoder-safe post-EOF Up Next lane even if SwiftUI did not receive a fresh `isPlaying` edge.
- Preserves the native Nuvio-style trailer resolver and the removal of the old Docker/IP YouTube resolver.

## Faster CI path

- Keeps optimized Release (`-O`) while restoring parallel single-file/batch-mode compilation instead of whole-module compilation.
- Runs KSPNUVIO, AetherEngine, and TVVLCKit preparation concurrently.
- Performs Swift parse + tvOS AppIcon `actool` preflight before dependency downloads so source/asset errors surface early.
- Retains the removal of the redundant second asset-catalog compile from vBRDC278.

No Live TV timeshift/VOD cache implementation is mixed into this stabilization build; that is the next phase after this build passes on Apple TV.
