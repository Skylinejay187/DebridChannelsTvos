# Debrid Channels tvOS v16

Ready-to-upload repo package. GitHub Actions builds an unsigned tvOS IPA from the embedded source zip.

v16 changes:
- Android-style centered top menu: Home, Live TV, Movies, Shows, Settings, Search.
- Full-screen hero backdrop driven by focused card artwork.
- Removed boxed hero image/card border.
- Removed default tvOS white focus square from row cards.
- Added custom animated blue pulse glow on focused cards.
- Added top-right poster artwork for the focused item.
- Added logo pulse behavior and logo/backdrop support from Stremio metadata.
- Kept landscape row cards by default.
- Catalog wiring remains manual from Settings; RD/Torbox intentionally not wired yet.

Workflow unchanged from recursive build-from-zip workflow.
