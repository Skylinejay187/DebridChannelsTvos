# vBRDC389R2 — VOD Trailer Display-Mode Inheritance

Version 1.0.1104 / build 1104.

## Physical regression addressed
When normal VOD had already matched the Apple TV output to HDR/Dolby Vision/frame-rate, the VOD-overlay trailer path used the standalone trailer policy (`enableDisplayMatch = false`). On physical Apple TV that could prevent the trailer from presenting after the VOD display transition.

## Fix
VOD-overlay trailers now use an explicit **inherit current display mode** policy:

- Normal VOD continues to use tvOS/Aether content matching normally.
- A trailer launched over active VOD keeps Aether content/HDR-aware presentation enabled (`matchContentEnabled = true`).
- That trailer suppresses a new display-criteria request (`suppressDisplayCriteria = true`), so it does not ask tvOS for a second Dynamic Range / Frame Rate switch.
- Standalone/catalog trailers retain their no-match policy.
- Trailer exit returns to the retained VOD session without changing the display policy.

The physically confirmed vBRDC389R1 SDR artwork isolation remains unchanged. No changes were made to Live TV, timeshift, VOD cache, Kingfisher, ambient effects, navigation, subtitle colors, amplification, or the approved trailer cadence path.
