import Foundation
struct MediaItem {
    var tmdbId: String? = nil
    var imdbId: String? = nil
    var tvdbId: String? = nil
    var title: String
    var year: String
    var seasonNumber: Int? = nil
    var episodeNumber: Int? = nil
}
