# Debrid Channels vBRDC055

**Release ID:** vBRDC055  
**Marketing version:** 1.0.758  
**Apple build:** 758  
**Backend:** v692 unchanged  
**Base:** packaged vBRDC054 only

## Physical Apple TV findings addressed

vBRDC055 is a focused correction based on the vBRDC054 physical-device screenshot.

### 1. Restore the two missing source controls

vBRDC054 made managed Torrentio opt-in, but accidentally nested the existing source preferences inside `if managedTorrentioEnabled`. As a result, disabling optional Torrentio also hid:

- `Cached Only (torrent addons)` / `Cached + Uncached (torrent addons)`
- `Exclude CAM / Low Quality`

vBRDC055 restores both controls as always-visible source defaults. Torrentio itself remains OFF by default and still requires explicit opt-in.

### 2. TorBox Usenet no longer appears before a real TorBox search connection

The Source Intelligence path previously created a `TorBox Usenet` status even when no TorBox API key existed. Cached Source Intelligence restoration could also re-surface an old TorBox Usenet row after the key had been removed.

vBRDC055 now credential- and connection-gates the TorBox Usenet surface:

- no effective TorBox API key -> no TorBox Usenet provider pill/status
- no effective TorBox API key -> stale cached TorBox Usenet rows are not restored
- a stale selected `TorBox Usenet` provider resets to `All Providers` when no key exists
- a TorBox key starts the Voyager request silently
- only a successful Voyager request exposes `TorBox Usenet` in Source Intelligence
- a successful zero-result request may show `Connected • Voyager + Usenet • no NZB links`
- a failed Voyager connection is diagnosed in Settings -> Connection Status instead of creating a phantom Source Intelligence provider

This keeps Source Intelligence truthful while retaining detailed TorBox diagnostics in Settings.

## What the screenshot confirms about the current TorBox path

The physical test showed:

- Main TorBox API authenticated
- Account: Pro
- TorBox Usenet API connected
- Voyager search host `search-api.torbox.app` failed hostname resolution

Therefore TorBox processing/authentication is working; the missing Usenet links are specifically blocked at the Voyager discovery/search host on that device/network. vBRDC055 does not replace TorBox's published Voyager hostname with an invented endpoint. The Settings diagnostic remains the authoritative place to see that failure.

## Preserved behavior

- Torrentio remains explicitly optional and OFF by default.
- Main Real-Debrid and TorBox credentials remain authoritative.
- Managed Debridio remains removed; user-added Debridio works through Saved Stremio JSON URLs.
- Managed Comet remains removed.
- Saved Stremio addons remain credential-isolated.
- Native TorBox Usenet remains independent from Torrentio.
- Backend remains v692.
- Locked vBRDC049 playback/graphics stability files remain byte-for-byte unchanged.

## Validation

Local validation before packaging:

- 34/34 vBRDC055 static contracts pass.
- 60/60 production Swift files parse.
- Focused `TorBoxUsenetClient` Swift typecheck passes with a minimal `MediaItem` fixture.
- Focused Global Debrid Bridge + Connection Health Swift typecheck passes.
- App and Top Shelf plists parse and match 1.0.758 / 758 / vBRDC055.
- `project.yml` parses and matches version/build.
- KSP patch scripts remain syntax-valid.
- Locked playback/intro stability files compare byte-for-byte to packaged vBRDC054.
- Python bytecode/cache artifacts are removed from the distributable package.
- GitHub Actions/Xcode remains the authoritative Apple-platform compile.
