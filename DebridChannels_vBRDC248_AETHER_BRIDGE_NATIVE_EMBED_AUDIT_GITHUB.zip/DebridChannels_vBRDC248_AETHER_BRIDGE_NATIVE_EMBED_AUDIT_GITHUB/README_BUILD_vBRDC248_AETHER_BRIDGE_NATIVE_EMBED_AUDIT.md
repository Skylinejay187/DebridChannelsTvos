# vBRDC248 — Aether Bridge Native Embed + Runtime Closure Audit

Release: vBRDC248
Version: 1.0.951 (951)

The physical Apple TV IPS from vBRDC247 proved Signulous installation now succeeds, but dyld terminated at launch because `AetherPlaybackBridge.framework` was linked yet absent from `DebridChannelsTVOS.app/Frameworks`.

## Fix
- Keep vBRDC247's local SwiftPM bridge architecture.
- Mark the app dependency on the dynamic SwiftPM product `AetherPlaybackBridge` with `embed: true`.
- Add a post-build `otool -L` runtime closure audit. The GitHub build now fails if the bridge is absent or if any `@rpath/Aether*.framework` dependency referenced by the bridge/runtime is absent from the final app bundle.
- Do not restore the v243-v246 manual Aether framework injection path.

This preserves Aether primary, KSPlayer fallback, FFmpeg isolation, zero-delay handoff, resume/progress, Now Playing/Bluetooth, failover, previews, and Live TV focus/navigation behavior.
