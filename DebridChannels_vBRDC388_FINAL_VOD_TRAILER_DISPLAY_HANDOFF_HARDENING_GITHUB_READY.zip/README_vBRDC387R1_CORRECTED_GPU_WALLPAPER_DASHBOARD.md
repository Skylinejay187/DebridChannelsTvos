# vBRDC387R1 — Corrected GPU / Dynamic Wallpaper / Preview Mirror Cleanup

Base: vBRDC386R1 (1.0.1089 / 1089). The rejected vBRDC387 is not used as source.
Version: 1.0.1090 / 1090. Release ID: vBRDC387R1.

## Regression locks carried forward
- v386R1 seamless VOD amplification and amplification persistence across audio-track switching.
- Subtitle translucent background removal and White/Yellow/Cyan/Green subtitle colors.
- v386 Phase 4 authoritative VOD cache visual refresh.
- VOD disk cache profiles/cleanup, R7 Live stability, F3 Live timeshift, R3 Preview Mirror navigation/logo/exit behavior.

## Corrected GPU enhancement
- Restores the approved Classic Smoke visual implementation from v386R1. No replacement smoke textures/animation design.
- Classic Smoke is flattened with SwiftUI drawingGroup so its existing gradients/smoke geometry are composited through a Metal-backed offscreen surface.
- Built-in Dynamic Wallpaper keeps the exact existing procedural Canvas renderer and colors; Canvas remains asynchronous and its post-processing is flattened through drawingGroup.
- Live Dynamic Wallpaper now actually honors the existing Unity navigation/handoff render-budget gate instead of computing `yieldToNavigation` and ignoring it. It pauses/resumes the existing renderer; it does not recreate or reset the wallpaper.
- Existing ownership gates still unmount ambient/wallpaper outside the allowed Live surface and during playback.

## Preview Mirror cleanup
- Removes the redundant upper-right GRID mode chip from the Preview Mirror header.
- ALL CHANNELS / selected category and the live dynamic channel count occupy that trailing position.
- Bottom-right GUIDE remains the Guide entry point.
- Clock remains unchanged.

## Deferred
- Incognito/Private Watching phase.
- Final VOD Trailer phase includes native-cadence/frame-pacing repair to make trailer motion match normal VOD quality.
