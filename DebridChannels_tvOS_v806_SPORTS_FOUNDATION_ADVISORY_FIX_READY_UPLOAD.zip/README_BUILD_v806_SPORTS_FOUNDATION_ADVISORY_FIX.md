# Debrid Channels tvOS v806 - Sports Foundation Advisory Fix

- Started from `DebridChannels_tvOS_v805_TICKER_VISIBILITY_SEARCH_SPORTS_MINIMAL_ROW_FIX_READY_UPLOAD.zip`; v805 was not renamed in place.
- Kept the working Movies/Shows ticker path and moved its Live TV card clearance from 6pt to 14pt so it sits slightly higher without changing rotation/content behavior.
- Replaced the active Sports tab render with a lower quick-panel foundation: one hero foundation plus one `LIVE & UPCOMING GAMES` card row.
- Kept the old SportsCenter/fullscreen components out of the active Sports navigation path.
- Restored dynamic advisory refresh by keying advisory state to selected title metadata and enriching certification/rating/descriptors from available local and OMDb data.
- Did not touch KSPlayer, AVPlayer, playback controls, Source Intelligence, Membership, Live TV guide/cache/parsing, Backend, Search icon styling, Media Info layout, or top-bar transparency behavior.
