# Signal vBRDC342 — Live TV visual rebuild (candidate)

Base: approved vBRDC334 source only; rejected v335–v341 visual implementation was not imported. tvOS version 1.0.1044, build 1044, vBRDC342. Test candidate, not approved release.

## Scope

- Main Signal home icon rebuilt from supplied metallic play/SIGNAL artwork as a 1280×768 tvOS tile. Updated both App Store/Home Screen image stacks (400×240) and the standalone and HomeIcon fallback art. Three icon stack layers present; Back contains full artwork, transparent Middle and Front avoid old overlays.
- `Signal TV` header renders the user's actual Live + red-TV supplied image via `SignalLiveTVArtwork` rather than a SwiftUI-drawn substitute. Other selectable header types restricted to Retro Tube and the three user-supplied icon variations; no old choices exposed. Older dead style functions remain unreferenced rather than deleting unrelated code in this pass.
- New `signalLiveTVCardThemeV342`: Original UNITY, UNITY 3D Left, UNITY 3D Right, Premium Glass, Broadcast Studio, Cinema Wall, Channel Slate. Selected presentation modifies the real grid card artwork composition, depth, footer, corner shape and/or information surfaces rather than changing only header chrome. Default: Original UNITY.
- **Full-screen preview/confirmation** opened from Live TV Settings. Preview uses `LiveTVGridTileContent`, the same production card renderer, in an offline sample 4 × 3 dashboard. Next cycles themes; Apply persists; Cancel/Back dismisses without changing current theme. Offline sample channels are explicitly labeled; preview doesn't purport to show the user's actual current channel lineup.
- Existing 12-card page focus/nav, guide, provider requests, artwork loader, VOD player and app-wide catalog runtime remain based on v334. The existing focus ring is invoked once in the production tile renderer; no new rings or per-card timers were added. Offline dashboard suppresses footer timeline ticks, artwork fetches and playback.
- Dynamic wallpaper ownership logic is retained from v334: animated while Live TV Grid is visible and unmounted in Guide or non-live sections. No new 4K wallpaper footage is included in this specifically scoped candidate.

## Validation and caveats

Swift frontend parse all `Sources/*.swift` only, ZIP CRC/integrity, asset dimensions and plist/project version synchronization. These do not validate Apple SDK SwiftUI typechecking or on-device visual/focus tests. Run the GitHub Xcode workflow and test Settings preview, remote focus, selected theme restore, Apple TV icon visual and Live TV branding before accepting as a new baseline.
