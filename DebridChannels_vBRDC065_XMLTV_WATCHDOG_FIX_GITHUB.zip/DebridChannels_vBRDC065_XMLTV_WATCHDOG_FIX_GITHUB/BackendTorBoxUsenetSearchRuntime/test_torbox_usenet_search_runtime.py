import json
import unittest
from urllib.parse import unquote

from torbox_usenet_search_runtime import (
    HTTPResult,
    RelayConfig,
    TorBoxUsenetRelayError,
    relay_torbox_usenet_search,
)


class FakeFetcher:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, url, headers, timeout, maximum_bytes):
        self.calls.append((url, dict(headers), timeout, maximum_bytes))
        return self.responses.pop(0)


def response(status, payload):
    return HTTPResult(status=status, body=json.dumps(payload).encode("utf-8"))


class TorBoxUsenetRelayTests(unittest.TestCase):
    def test_identity_search_forwards_bearer_and_required_flags(self):
        fetcher = FakeFetcher([
            response(200, {"success": True, "data": {"nzbs": [{"title": "Movie.2026", "hash": "abc"}]}})
        ])
        result = relay_torbox_usenet_search(
            {"identityType": "imdb", "identityID": "tt1234567", "query": "Movie 2026", "checkCache": True, "checkOwned": True, "searchUserEngines": True, "cachedOnly": False},
            "secret-token",
            fetcher=fetcher,
        )
        self.assertTrue(result["success"])
        url, headers, timeout, maximum_bytes = fetcher.calls[0]
        self.assertIn("/usenet/imdb:tt1234567?", url)
        self.assertIn("check_cache=true", url)
        self.assertIn("check_owned=true", url)
        self.assertIn("search_user_engines=true", url)
        self.assertIn("cached_only=false", url)
        self.assertEqual(headers["Authorization"], "Bearer secret-token")
        self.assertNotIn("secret-token", url)
        self.assertEqual(timeout, 18)
        self.assertGreater(maximum_bytes, 0)

    def test_empty_identity_response_falls_back_to_title_query(self):
        fetcher = FakeFetcher([
            response(200, {"success": True, "data": {"nzbs": []}}),
            response(200, {"success": True, "data": {"nzbs": [{"title": "Show.S01E02", "hash": "xyz"}]}}),
        ])
        result = relay_torbox_usenet_search(
            {"identityType": "tvdb", "identityID": "123", "query": "Show S01E02", "season": 1, "episode": 2},
            "secret",
            fetcher=fetcher,
        )
        self.assertEqual(len(fetcher.calls), 2)
        self.assertIn("/usenet/search/Show%20S01E02?", fetcher.calls[1][0])
        self.assertIn("season=1", fetcher.calls[1][0])
        self.assertIn("episode=2", fetcher.calls[1][0])
        self.assertIn("search_user_engines=false", fetcher.calls[1][0])
        self.assertEqual(result["data"]["nzbs"][0]["hash"], "xyz")

    def test_query_is_path_encoded_and_upstream_host_is_fixed(self):
        fetcher = FakeFetcher([response(200, {"success": True, "data": {"nzbs": []}})])
        relay_torbox_usenet_search({"query": "A/B ? C"}, "secret", fetcher=fetcher)
        url = fetcher.calls[0][0]
        self.assertTrue(url.startswith("https://search-api.torbox.app/usenet/search/"))
        self.assertIn("A%2FB%20%3F%20C", url)
        self.assertEqual(unquote(url.split("/usenet/search/", 1)[1].split("?", 1)[0]), "A/B ? C")

    def test_rejected_upstream_never_echoes_token(self):
        fetcher = FakeFetcher([response(403, {"detail": "request rejected"})])
        with self.assertRaises(TorBoxUsenetRelayError) as context:
            relay_torbox_usenet_search({"query": "Movie"}, "super-secret", fetcher=fetcher)
        message = str(context.exception)
        self.assertIn("HTTP 403", message)
        self.assertNotIn("super-secret", message)

    def test_missing_token_is_rejected(self):
        with self.assertRaises(TorBoxUsenetRelayError) as context:
            relay_torbox_usenet_search({"query": "Movie"}, "")
        self.assertEqual(context.exception.status_code, 401)

    def test_oversized_response_is_rejected(self):
        config = RelayConfig(maximum_response_bytes=16)
        fetcher = FakeFetcher([HTTPResult(status=200, body=b"x" * 17)])
        with self.assertRaises(TorBoxUsenetRelayError):
            relay_torbox_usenet_search({"query": "Movie"}, "secret", config=config, fetcher=fetcher)


if __name__ == "__main__":
    unittest.main()
