"""Debrid Channels backend v693 — TorBox Usenet discovery relay.

This runtime gives the Apple app a fixed-backend egress path to TorBox Voyager search.
It does not own TorBox credentials: the user's token is supplied only for the individual
request through ``X-TorBox-Token``, forwarded as a Bearer credential to the fixed TorBox
Search host, and never persisted, cached, logged, or included in public responses.

Route:
    POST /api/torbox/usenet/search

The relay is intentionally search-only. Usenet creation, status polling, unpacking and
final CDN URL resolution stay app -> api.torbox.app so playback ownership remains native
to the user's TorBox account.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

SEARCH_BASE = "https://search-api.torbox.app"
SCHEMA_VERSION = 1
MAX_RESPONSE_BYTES = 4 * 1024 * 1024


class TorBoxUsenetRelayError(RuntimeError):
    def __init__(self, message: str, status_code: int = 502) -> None:
        super().__init__(message)
        self.status_code = status_code


@dataclass(frozen=True)
class RelayConfig:
    timeout_seconds: int = 18
    maximum_response_bytes: int = MAX_RESPONSE_BYTES


@dataclass(frozen=True)
class HTTPResult:
    status: int
    body: bytes

    def json(self) -> Any:
        return json.loads(self.body.decode("utf-8", errors="replace"))


HTTPFetcher = Callable[[str, Mapping[str, str], int, int], HTTPResult]


def _default_fetcher(url: str, headers: Mapping[str, str], timeout: int, maximum_bytes: int) -> HTTPResult:
    # nosec B310 - target URL is constructed only from the fixed TorBox Search host.
    request = Request(url=url, method="GET", headers=dict(headers))
    try:
        with urlopen(request, timeout=timeout) as response:
            return HTTPResult(
                status=int(getattr(response, "status", 200)),
                body=response.read(maximum_bytes + 1),
            )
    except HTTPError as exc:
        return HTTPResult(status=int(exc.code), body=exc.read(maximum_bytes + 1))
    except URLError as exc:
        raise TorBoxUsenetRelayError(f"TorBox Search connection failed: {_safe_message(exc.reason)}") from exc


def _safe_message(value: Any, limit: int = 320) -> str:
    text = str(value or "").replace("\r", " ").replace("\n", " ").strip()
    return text[:limit] or "Unknown error"


def _clean_token(raw: Any) -> str:
    token = str(raw or "").strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token or len(token) > 4096:
        return ""
    if any(ord(ch) < 0x20 or ord(ch) == 0x7F for ch in token):
        return ""
    return token


def _clean_text(raw: Any, limit: int) -> str:
    return str(raw or "").replace("\r", " ").replace("\n", " ").strip()[:limit]


def _optional_nonnegative_int(raw: Any) -> Optional[int]:
    if raw is None or raw == "":
        return None
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    return value if value >= 0 else None


def _bool(raw: Any, default: bool) -> bool:
    if isinstance(raw, bool):
        return raw
    if isinstance(raw, (int, float)):
        return bool(raw)
    if isinstance(raw, str):
        lower = raw.strip().lower()
        if lower in {"1", "true", "yes", "on"}:
            return True
        if lower in {"0", "false", "no", "off"}:
            return False
    return default


def _query_items(payload: Mapping[str, Any]) -> Dict[str, str]:
    values = {
        "metadata": "true" if _bool(payload.get("metadata"), False) else "false",
        "check_cache": "true" if _bool(payload.get("checkCache"), True) else "false",
        "check_owned": "true" if _bool(payload.get("checkOwned"), True) else "false",
        "search_user_engines": "true" if _bool(payload.get("searchUserEngines"), False) else "false",
        "cached_only": "true" if _bool(payload.get("cachedOnly"), False) else "false",
    }
    season = _optional_nonnegative_int(payload.get("season"))
    episode = _optional_nonnegative_int(payload.get("episode"))
    if season is not None:
        values["season"] = str(season)
    if episode is not None and episode > 0:
        values["episode"] = str(episode)
    return values


def _candidate_urls(payload: Mapping[str, Any]) -> Tuple[str, ...]:
    query_string = urlencode(_query_items(payload))
    urls = []

    identity_type = _clean_text(payload.get("identityType"), 16).lower()
    identity_id = _clean_text(payload.get("identityID"), 80)
    if identity_type in {"imdb", "tmdb", "tvdb"} and identity_id:
        identity = quote(f"{identity_type}:{identity_id}", safe=":")
        urls.append(f"{SEARCH_BASE}/usenet/{identity}?{query_string}")

    query = _clean_text(payload.get("query"), 300)
    if query:
        encoded = quote(query, safe="")
        urls.append(f"{SEARCH_BASE}/usenet/search/{encoded}?{query_string}")

    if not urls:
        raise TorBoxUsenetRelayError("A media identity or search query is required.", status_code=422)
    return tuple(urls)


def _extract_detail(value: Any) -> str:
    if isinstance(value, Mapping):
        for key in ("detail", "error", "message"):
            if value.get(key):
                return _safe_message(value.get(key))
    return ""


def _result_count(value: Any) -> int:
    if not isinstance(value, Mapping):
        return 0
    payload = value.get("data", value)
    if isinstance(payload, Mapping):
        for key in ("nzbs", "results"):
            if isinstance(payload.get(key), list):
                return len(payload[key])
        if any(key in payload for key in ("raw_title", "title", "name")):
            return 1
    if isinstance(payload, list):
        return len(payload)
    return 0


def relay_torbox_usenet_search(
    payload: Mapping[str, Any],
    token: str,
    config: RelayConfig = RelayConfig(),
    fetcher: HTTPFetcher = _default_fetcher,
) -> Any:
    """Relay one TorBox Voyager search without retaining the supplied token."""

    clean_token = _clean_token(token)
    if not clean_token:
        raise TorBoxUsenetRelayError("A TorBox API token is required.", status_code=401)

    headers = {
        "Authorization": f"Bearer {clean_token}",
        "Accept": "application/json",
        "Accept-Encoding": "identity",
        "User-Agent": "DebridChannels-Backend/v693 TorBoxUsenetRelay",
    }
    urls = _candidate_urls(payload)
    errors = []
    last_success: Any = None

    for index, url in enumerate(urls):
        try:
            result = fetcher(url, headers, config.timeout_seconds, config.maximum_response_bytes)
        except TorBoxUsenetRelayError as exc:
            errors.append(str(exc))
            continue
        except Exception as exc:  # keep provider failures isolated from the backend process
            errors.append(f"TorBox Search connection failed: {_safe_message(exc)}")
            continue

        if len(result.body) > config.maximum_response_bytes:
            errors.append("TorBox Search response exceeded the relay size limit.")
            continue

        try:
            parsed = result.json()
        except Exception:
            parsed = None

        if 200 <= result.status < 300:
            if parsed is None:
                errors.append("TorBox Search returned unreadable JSON.")
                continue
            last_success = parsed
            # Prefer the stable media-identity route, but if it gives a genuine empty set
            # and a title query is available, perform the title fallback before returning.
            if _result_count(parsed) > 0 or index == len(urls) - 1:
                return parsed
            continue

        detail = _extract_detail(parsed)
        if result.status in {401, 403}:
            message = f"TorBox Search rejected backend discovery (HTTP {result.status})"
            if detail:
                message += f": {detail}"
            errors.append(message)
        else:
            message = f"TorBox Search returned HTTP {result.status}"
            if detail:
                message += f": {detail}"
            errors.append(message)

    if last_success is not None:
        return last_success
    detail = "; ".join(errors[-2:]) if errors else "TorBox Search did not return a usable response."
    # Defensive redaction in case an upstream exception ever reflects an Authorization value.
    detail = detail.replace(clean_token, "[redacted]")
    raise TorBoxUsenetRelayError(detail, status_code=502)


def create_fastapi_router(config: RelayConfig = RelayConfig()):
    """Create the search-only FastAPI router without making FastAPI a test dependency."""
    try:
        from fastapi import APIRouter, Header, HTTPException
    except ImportError as exc:  # pragma: no cover - deployment integration guard
        raise RuntimeError("FastAPI is required to create the TorBox Usenet relay router") from exc

    router = APIRouter()

    @router.post("/api/torbox/usenet/search")
    async def torbox_usenet_search_endpoint(
        body: Dict[str, Any],
        x_torbox_token: str = Header(default="", alias="X-TorBox-Token"),
    ):
        try:
            return relay_torbox_usenet_search(body, x_torbox_token, config=config)
        except TorBoxUsenetRelayError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc

    return router
