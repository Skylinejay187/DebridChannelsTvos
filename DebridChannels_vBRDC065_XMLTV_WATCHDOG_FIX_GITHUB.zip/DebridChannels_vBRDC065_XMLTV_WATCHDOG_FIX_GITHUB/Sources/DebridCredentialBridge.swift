import Foundation
#if canImport(Security)
import Security
#endif

enum DebridServiceID: String, CaseIterable, Hashable {
    case realDebrid = "realdebrid"
    case torBox = "torbox"

    var displayName: String {
        switch self {
        case .realDebrid: return "Real-Debrid"
        case .torBox: return "TorBox"
        }
    }
}

struct DebridCredentialSnapshot: Hashable {
    let service: DebridServiceID
    let credential: String
    let sourceDescription: String
}

/// vBRDC053: one authoritative credential bridge for native services and Torrentio.
///
/// The old per-Torrentio override fields are no longer exposed. Existing installations
/// are migrated once into the matching main service key so no credential is lost.
/// Arbitrary/custom Stremio addons never receive this credential pool automatically.
enum DebridCredentialBridge {
    private static func clean(_ value: String?) -> String {
        (value ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    static func migrateLegacyOverridesIfNeeded(defaults: UserDefaults = .standard) {
        removeRetiredManagedAddonStateIfNeeded(defaults: defaults)
        migrateLegacy(
            mainKey: "realDebridApiKey",
            legacyKey: "torrentioRealDebridApiKey",
            defaults: defaults
        )
        migrateLegacy(
            mainKey: "torBoxApiKey",
            legacyKey: "torrentioTorBoxApiKey",
            defaults: defaults
        )
    }


    private static func removeRetiredManagedAddonStateIfNeeded(defaults: UserDefaults) {
        let migrationKey = "migration.vBRDC053.retiredManagedAddonsCleaned"
        guard !defaults.bool(forKey: migrationKey) else { return }
        for key in [
            "managedDebridioScraperEnabled.v1",
            "managedDebridioWatchtowerEnabled.v1",
            "managedDebridioTMDBEnabled.v1",
            "managedDebridioTVDBEnabled.v1",
            "managedDebridioTMDBLanguage.v1"
        ] {
            defaults.removeObject(forKey: key)
        }
#if canImport(Security)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: "com.channelsdebrid.tvos.managedaddons",
            kSecAttrAccount as String: "debridio-api-key-v1"
        ]
        SecItemDelete(query as CFDictionary)
#endif
        defaults.set(true, forKey: migrationKey)
    }

    private static func migrateLegacy(mainKey: String, legacyKey: String, defaults: UserDefaults) {
        let main = clean(defaults.string(forKey: mainKey))
        let legacy = clean(defaults.string(forKey: legacyKey))
        if main.isEmpty, !legacy.isEmpty {
            defaults.set(legacy, forKey: mainKey)
        }
        if !legacy.isEmpty {
            defaults.removeObject(forKey: legacyKey)
        }
    }

    static func credential(for service: DebridServiceID, defaults: UserDefaults = .standard) -> DebridCredentialSnapshot? {
        migrateLegacyOverridesIfNeeded(defaults: defaults)
        let key: String
        let description: String
        switch service {
        case .realDebrid:
            key = "realDebridApiKey"
            description = "Main Real-Debrid API key"
        case .torBox:
            key = "torBoxApiKey"
            description = "Main TorBox API key"
        }
        let value = clean(defaults.string(forKey: key))
        guard !value.isEmpty else { return nil }
        return DebridCredentialSnapshot(service: service, credential: value, sourceDescription: description)
    }

    static func effectiveTorBoxAPIKey(defaults: UserDefaults = .standard) -> String {
        credential(for: .torBox, defaults: defaults)?.credential ?? ""
    }

    static func effectiveRealDebridAPIKey(defaults: UserDefaults = .standard) -> String {
        credential(for: .realDebrid, defaults: defaults)?.credential ?? ""
    }

    static func connectedServiceSummary(defaults: UserDefaults = .standard) -> String {
        let values = DebridServiceID.allCases.compactMap {
            credential(for: $0, defaults: defaults)?.service.displayName
        }
        return values.isEmpty ? "No global debrid credentials detected" : values.joined(separator: " + ")
    }
}
