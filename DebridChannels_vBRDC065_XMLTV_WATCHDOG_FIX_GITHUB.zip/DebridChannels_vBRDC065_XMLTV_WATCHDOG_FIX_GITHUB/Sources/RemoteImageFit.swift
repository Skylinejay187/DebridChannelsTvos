import SwiftUI
import UIKit

/// Central artwork URL upgrader used before every image request.
/// v703: Premium decode path. Do not let SwiftUI/URLCache reuse low-res image entries,
/// and do not downsample artwork before the view displays it. TMDB gets /original/;
/// provider/Cinemeta/Stremio URLs stay intact so signed URLs and catalog art do not break.
enum PremiumArtworkURL {
    static func upgraded(_ input: String?) -> String? {
        guard var raw = input?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://"), !isPrivateLocalHTTP(raw) {
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }

        if raw.contains("image.tmdb.org/t/p/") {
            let tmdbSizes = ["/w45/", "/w92/", "/w154/", "/w185/", "/w300/", "/w342/", "/w500/", "/h632/", "/w780/", "/w1280/", "/original/"]
            for size in tmdbSizes where raw.contains(size) {
                raw = raw.replacingOccurrences(of: size, with: "/original/")
            }
            for size in ["w45", "w92", "w154", "w185", "w300", "w342", "w500", "h632", "w780", "w1280"] {
                raw = raw.replacingOccurrences(of: "/t/p/\(size)", with: "/t/p/original")
            }
        }

        return raw
    }

    private static func isPrivateLocalHTTP(_ raw: String) -> Bool {
        guard let host = URL(string: raw)?.host?.lowercased() else { return false }
        if host == "localhost" || host == "127.0.0.1" || host.hasSuffix(".local") { return true }
        if host.hasPrefix("10.") || host.hasPrefix("192.168.") { return true }
        let parts = host.split(separator: ".").compactMap { Int($0) }
        if parts.count == 4, parts[0] == 172, (16...31).contains(parts[1]) { return true }
        return false
    }

    static func url(_ input: String?) -> URL? {
        guard let raw = upgraded(input), !raw.isEmpty else { return nil }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }
}

@MainActor
final class PremiumRemoteImageLoader: ObservableObject {
    @Published var image: UIImage?
    @Published private(set) var imageURL: URL? = nil
    @Published var failed = false

    private static let memoryCache: NSCache<NSURL, UIImage> = {
        let cache = NSCache<NSURL, UIImage>()
        // v856: keep decoded artwork hot without allowing the Live TV grid to grow unbounded.
        // This preserves full source quality; it only caches the already-decoded bitmap so fast
        // focus/scroll passes do not repeatedly trigger first-display image decompression.
        // v1133 release-stability: keep full-resolution artwork quality, but cap the
        // decoded-bitmap reservoir so VideoToolbox/KSPlayer always has headroom. A single
        // 4K RGBA backdrop is ~32 MB, so the old 220 MB cache could hold several decoder-
        // sized surfaces before playback even began.
        cache.countLimit = 160
        cache.totalCostLimit = 96 * 1024 * 1024
        return cache
    }()
    private static var inFlightLoads: [URL: [ObjectIdentifier: (UIImage?) -> Void]] = [:]
    // vBRDC004: fast Lazy-grid recycling can remove the last subscriber for only a few
    // milliseconds. Immediate vBRDC002 cancellation turned that into cancel/restart churn
    // and repeated original-resolution decodes. Give a short grace window before killing
    // a shared request; full-screen playback/memory-pressure paths still cancel instantly.
    private static var pendingSubscriberCancellationTasks: [URL: Task<Void, Never>] = [:]
    private static var prefetchTasks: [URL: URLSessionDataTask] = [:]
    private static var activeNetworkTasks: [URL: URLSessionDataTask] = [:]
    private static var exclusivePlaybackActive = false
    private static let maxActivePrefetchTasks = 4
    private static let normalDecodedCacheLimitBytes = 96 * 1024 * 1024
    private static let exclusiveVODDecodedCacheLimitBytes = 32 * 1024 * 1024
    private static let imageSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 24
        configuration.timeoutIntervalForResource = 30
        configuration.httpMaximumConnectionsPerHost = 6
        return URLSession(configuration: configuration)
    }()
    private var task: URLSessionDataTask?
    private var currentURL: URL?

    func load(_ url: URL?, preserveCurrentImage: Bool = false) {
        guard let url else {
            cancel()
            image = nil
            imageURL = nil
            failed = false
            currentURL = nil
            return
        }
        if currentURL == url, image != nil || failed { return }
        // vBRDC002: unsubscribe this loader from its previous shared request. If another
        // visible image still needs that URL the network request stays alive; if this was
        // the last visible subscriber the request is cancelled instead of decoding a
        // full-resolution bitmap after the view has disappeared.
        if let previousURL = currentURL {
            Self.removeInFlightSubscriber(for: previousURL, owner: self)
        }
        task = nil
        currentURL = url
        failed = false
        // vBRDC021: catalog hero artwork may upgrade from the already-visible provider image
        // to a richer/original-resolution URL after focus/detail hydration. For that narrow
        // presentation path, retain the decoded image until the replacement has fully loaded
        // and decoded so tvOS never exposes the placeholder/black frame between sources.
        // Every existing caller keeps the v720 stale-art protection by default.
        if !preserveCurrentImage {
            image = nil
            imageURL = nil
        }

        if let cached = Self.memoryCache.object(forKey: url as NSURL) {
            imageURL = url
            image = cached
            return
        }

        if Self.enqueueInFlightLoad(for: url, owner: self) { return }

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 24
        request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS-PremiumArtwork/1.0", forHTTPHeaderField: "User-Agent")

        task = Self.imageSession.dataTask(with: request) { data, response, error in
            guard error == nil, let data, !data.isEmpty else {
                DispatchQueue.main.async {
                    Self.activeNetworkTasks.removeValue(forKey: url)
                    Self.finishInFlightLoad(for: url, image: nil)
                }
                return
            }
            // Decode off the main thread at original quality.  This does not resize/downsample artwork;
            // it simply forces bitmap decompression before SwiftUI needs to draw the cell during scrolling.
            let decoded = Self.decodedForDisplay(data: data)
            DispatchQueue.main.async {
                Self.activeNetworkTasks.removeValue(forKey: url)
                Self.finishInFlightLoad(for: url, image: decoded)
            }
        }
        if let task { Self.activeNetworkTasks[url] = task }
        task?.resume()
    }

    func cancel() {
        if let url = currentURL {
            Self.removeInFlightSubscriber(for: url, owner: self)
        }
        task = nil
        currentURL = nil
        // Keep warmth in the bounded process cache, not in every off-screen StateObject.
        // Reappearing views synchronously recover the same UIImage from NSCache when present.
        image = nil
        imageURL = nil
        failed = false
    }

    static func prefetch(_ urls: [URL], keeping keepAliveURLs: Set<URL> = []) {
        guard !exclusivePlaybackActive, !VODExclusivePlaybackGate.isActive else { return }
        let uniqueURLs = Array(Set(urls)).prefix(18)
        cancelObsoletePrefetches(keeping: Set(uniqueURLs).union(keepAliveURLs))

        for url in uniqueURLs {
            if memoryCache.object(forKey: url as NSURL) != nil { continue }
            if inFlightLoads[url] != nil { continue }
            if prefetchTasks[url] != nil { continue }
            if prefetchTasks.count >= maxActivePrefetchTasks { break }

            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.timeoutInterval = 18
            request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS-PremiumArtworkPrefetch/1.0", forHTTPHeaderField: "User-Agent")

            let task = Self.imageSession.dataTask(with: request) { data, _, error in
                guard error == nil, let data, !data.isEmpty else {
                    DispatchQueue.main.async { prefetchTasks.removeValue(forKey: url) }
                    return
                }
                let decoded = Self.decodedForDisplay(data: data)
                DispatchQueue.main.async {
                    prefetchTasks.removeValue(forKey: url)
                    if let decoded {
                        let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                        memoryCache.setObject(decoded, forKey: url as NSURL, cost: cost)
                    }
                }
            }
            prefetchTasks[url] = task
            task.resume()
        }
    }


    static func beginExclusivePlayback() {
        exclusivePlaybackActive = true
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        // v1133: the root removes the entire catalog/Live TV render tree as soon as VOD
        // is published. Retaining its decoded artwork in the process-wide cache therefore
        // has no visible benefit and competes directly with the video decoder.
        memoryCache.removeAllObjects()
        // Keep only a very small decorative-art reservoir while video owns the decoder.
        // Visible SwiftUI image views retain their own UIImage, so this does not reduce
        // VOD overlay quality; it prevents cast/production cards from rebuilding the old
        // catalog-sized decoded cache while a 4K stream is active.
        memoryCache.totalCostLimit = exclusiveVODDecodedCacheLimitBytes
        print("[ReleaseStability][v1133] VOD entry released decoded artwork cache and reduced playback cache ceiling to 32 MB")
    }

    static func releaseDecodedArtworkForHiddenVODOverlay() {
        guard exclusivePlaybackActive || VODExclusivePlaybackGate.isActive else { return }
        // v1144: hiding the VOD chrome must not synchronously deallocate every decoded
        // image on the MainActor. Phase 15 can have many cast/episode thumbnails alive,
        // and flushing the whole NSCache at the exact overlay-hide frame produced a
        // visible video hitch on physical Apple TV. Cancel speculative work immediately,
        // but leave decoded entries under the existing 32 MB exclusive-playback ceiling.
        // Full cache purges still happen on VOD entry/exit, memory pressure/background.
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        print("[ReleaseStability][v1144] hidden VOD overlay cancelled decorative artwork work; bounded decoded cache retained")
    }

    static func endExclusivePlayback() {
        // Clear any cast/production/discovery artwork retained by the VOD overlay before
        // the catalog tree remounts. This keeps repeated play/exit cycles from ratcheting
        // the decoded-image footprint upward.
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        memoryCache.removeAllObjects()
        memoryCache.totalCostLimit = normalDecodedCacheLimitBytes
        exclusivePlaybackActive = false
    }

    static func suspendForBackground() {
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        // Visible image requests may still own their SwiftUI view when tvOS suspends the
        // scene. Cancel only speculative prefetches so foreground return cannot strand a
        // visible loader in a permanent failed state.
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        // Visible views own their UIImage independently of NSCache. Releasing only the
        // extra decoded reservoir on scene inactivity lowers suspend/resume pressure
        // without blanking currently mounted artwork or touching player-owned surfaces.
        memoryCache.removeAllObjects()
        print("[ArtworkLifecycle][v1133] suspended speculative artwork work and released decoded cache")
    }

    static func handleMemoryPressure() {
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        // Keep currently visible image requests alive; cancel only speculative prefetch work.
        // Clearing NSCache does not remove UIImage instances already owned by visible views.
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        memoryCache.removeAllObjects()
        print("[ArtworkLifecycle][Phase7] released decoded artwork cache and prefetch work")
    }

    static func cancelObsoletePrefetches(keeping urlsToKeep: Set<URL>) {
        let obsolete = prefetchTasks.keys.filter { !urlsToKeep.contains($0) }
        for url in obsolete {
            prefetchTasks[url]?.cancel()
            prefetchTasks.removeValue(forKey: url)
        }
    }

    // v975 Phase 4: the full Live TV grid is removed during channel playback, so
    // retaining up to 220 MB of decoded card artwork provides no visible benefit and
    // compounds the decoder/player footprint that triggered the Jetsam termination.
    static func releaseDecodedArtworkForLiveTVPlayback() {
        for task in activeNetworkTasks.values { task.cancel() }
        activeNetworkTasks.removeAll()
        for task in prefetchTasks.values { task.cancel() }
        prefetchTasks.removeAll()
        for task in pendingSubscriberCancellationTasks.values { task.cancel() }
        pendingSubscriberCancellationTasks.removeAll()
        inFlightLoads.removeAll()
        memoryCache.removeAllObjects()
        print("[LiveTVMemory][v975] released decoded artwork cache for full-screen Live TV playback")
    }

    private static func enqueueInFlightLoad(for url: URL, owner: PremiumRemoteImageLoader) -> Bool {
        pendingSubscriberCancellationTasks[url]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: url)
        let ownerID = ObjectIdentifier(owner)
        let callback: (UIImage?) -> Void = { [weak owner] decoded in
            guard let owner, owner.currentURL == url else { return }
            if let decoded {
                let cost = decoded.cgImage.map { $0.bytesPerRow * $0.height } ?? 0
                memoryCache.setObject(decoded, forKey: url as NSURL, cost: cost)
                owner.imageURL = url
                owner.image = decoded
                owner.failed = false
            } else {
                owner.imageURL = nil
                owner.failed = true
            }
        }

        if inFlightLoads[url] != nil {
            inFlightLoads[url]?[ownerID] = callback
            return true
        }

        inFlightLoads[url] = [ownerID: callback]
        return false
    }

    private static func removeInFlightSubscriber(for url: URL, owner: PremiumRemoteImageLoader) {
        guard var subscribers = inFlightLoads[url] else { return }
        subscribers.removeValue(forKey: ObjectIdentifier(owner))
        guard subscribers.isEmpty else {
            inFlightLoads[url] = subscribers
            return
        }

        // Keep the empty slot alive briefly. If the same artwork remounts during a fast
        // focus/scroll pass, enqueueInFlightLoad simply re-subscribes to the existing task.
        inFlightLoads[url] = subscribers
        pendingSubscriberCancellationTasks[url]?.cancel()
        pendingSubscriberCancellationTasks[url] = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 280_000_000)
            guard !Task.isCancelled, inFlightLoads[url]?.isEmpty == true else {
                pendingSubscriberCancellationTasks[url] = nil
                return
            }
            inFlightLoads.removeValue(forKey: url)
            activeNetworkTasks[url]?.cancel()
            activeNetworkTasks.removeValue(forKey: url)
            pendingSubscriberCancellationTasks[url] = nil
        }
    }

    private static func finishInFlightLoad(for url: URL, image: UIImage?) {
        pendingSubscriberCancellationTasks[url]?.cancel()
        pendingSubscriberCancellationTasks.removeValue(forKey: url)
        guard let callbacks = inFlightLoads.removeValue(forKey: url) else { return }
        callbacks.values.forEach { $0(image) }
    }

    nonisolated private static func decodedForDisplay(data: Data) -> UIImage? {
        // v1133: contain compressed-source and renderer intermediates inside an
        // autorelease pool. The returned bitmap remains original-size/original-quality;
        // this only shortens the lifetime of temporary decode allocations.
        autoreleasepool {
            guard let source = UIImage(data: data) else { return nil }
            guard source.cgImage != nil else { return source }
            let format = UIGraphicsImageRendererFormat.default()
            format.scale = source.scale
            format.opaque = false
            let renderer = UIGraphicsImageRenderer(size: source.size, format: format)
            return renderer.image { _ in
                source.draw(in: CGRect(origin: .zero, size: source.size))
            }
        }
    }

    static var releaseStabilityActiveWorkCount: Int {
        activeNetworkTasks.count + prefetchTasks.count + inFlightLoads.count
    }

    static var releaseStabilityDecodedCacheLimitBytes: Int {
        exclusivePlaybackActive ? exclusiveVODDecodedCacheLimitBytes : normalDecodedCacheLimitBytes
    }

    deinit { task = nil }
}



private struct RemoteImageFitAspectModifier: ViewModifier {
    let mode: RemoteImageFit.Mode

    @ViewBuilder
    func body(content: Content) -> some View {
        switch mode {
        case .fill:
            content.scaledToFill()
        case .fit:
            content.scaledToFit()
        case .stretch:
            content
        }
    }
}

struct RemoteImageFit: View {
    enum Mode { case fill, fit, stretch }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true
    // vBRDC021: opt-in only. Keeps the previous decoded frame visible while a new URL
    // is downloaded/decoded, then swaps directly to the ready replacement.
    var preservePreviousOnURLChange: Bool = false

    @StateObject private var loader = PremiumRemoteImageLoader()

    private var resolvedURL: URL? {
        PremiumArtworkURL.url(url)
    }

    var body: some View {
        Group {
            if let image = loader.image, preservePreviousOnURLChange || loader.imageURL == resolvedURL {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .antialiased(true)
                    .modifier(RemoteImageFitAspectModifier(mode: mode))
                    // vBRDC023: the seamless catalog path already retains the old decoded
                    // frame until the replacement is ready. Do not then fade the ready
                    // replacement from transparent; that final opacity transition was the
                    // remaining small brightness flash seen on physical Apple TV.
                    .transition(preservePreviousOnURLChange ? .identity : .opacity)
            } else {
                placeholder(showSpinner: !loader.failed && resolvedURL != nil)
            }
        }
        .clipped()
        .animation(preservePreviousOnURLChange ? nil : .easeInOut(duration: 0.18), value: loader.imageURL)
        .onAppear { loader.load(resolvedURL) }
        .onChange(of: resolvedURL) { newValue in
            loader.load(newValue, preserveCurrentImage: preservePreviousOnURLChange)
        }
        .onDisappear { loader.cancel() }
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            if showPlaceholder {
                LinearGradient(colors: [.black.opacity(0.92), .gray.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if showSpinner {
                    ProgressView().scaleEffect(0.78).opacity(0.30)
                }
            } else {
                Color.clear
            }
        }
    }
}
