import Foundation

/// Persistent tvOS playback resume/history cache.
///
/// v1119 freeze correction: resume updates remain in a small in-memory dictionary and
/// are encoded/written on a serial utility queue. The player clock no longer JSON-encodes
/// the complete resume/history collection on the main thread every five seconds.
struct PlaybackResumeEntry: Codable, Hashable {
    var key: String
    var title: String
    var type: String
    var catalog: String
    var season: Int?
    var episode: Int?
    var seconds: Double
    var duration: Double
    var updatedAt: Date
    var artworkURL: String?
}


extension PlaybackResumeEntry {
    var dcProgressFraction: Double {
        guard duration > 0 else { return 0 }
        return min(max(seconds / duration, 0), 1)
    }

    var dcRemainingSeconds: Double {
        guard duration > seconds else { return 0 }
        return max(0, duration - seconds)
    }

    var dcRemainingText: String {
        let remaining = dcRemainingSeconds
        if remaining >= 3600 {
            return "\(Int(remaining / 3600))h \(Int((remaining.truncatingRemainder(dividingBy: 3600)) / 60))m"
        }
        return "\(max(1, Int(remaining / 60)))m"
    }

    var dcResumePositionText: String {
        let total = max(0, Int(seconds.rounded()))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        return hours > 0 ? String(format: "%d:%02d:%02d", hours, minutes, secs) : String(format: "%d:%02d", minutes, secs)
    }
}

final class PlaybackResumeCacheManager {
    static let shared = PlaybackResumeCacheManager()

    private struct Payload: Codable {
        var entries: [String: PlaybackResumeEntry]
        var recents: [PlaybackResumeEntry]
    }

    private let legacyEntriesKey = "DebridChannels.v498.playbackResume.entries"
    private let legacyRecentsKey = "DebridChannels.v498.playbackResume.recents"
    private let minimumResumeSeconds: Double = 8
    private let completionThreshold: Double = 0.95
    // v1153: one logical title/episode may be indexed by several resolver identity aliases.
    // Keep enough alias slots to preserve the original ~180 logical-title history depth.
    private let maxEntries = 1200
    private let maxRecents = 60
    private let lock = NSLock()
    private let writerQueue = DispatchQueue(label: "DebridChannels.PlaybackResumeCache.writer", qos: .utility)
    private var payload: Payload

    private static var storageFileURL: URL? {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent("DebridChannels", isDirectory: true)
            .appendingPathComponent("playback-resume-v1119.json")
    }

    private var fileURL: URL? { Self.storageFileURL }

    private init() {
        let initialFileURL = Self.storageFileURL
        if let initialFileURL,
           let data = try? Data(contentsOf: initialFileURL),
           let decoded = try? JSONDecoder().decode(Payload.self, from: data) {
            payload = decoded
            return
        }
        let defaults = UserDefaults.standard
        let legacyEntries: [String: PlaybackResumeEntry]
        if let data = defaults.data(forKey: legacyEntriesKey),
           let decoded = try? JSONDecoder().decode([String: PlaybackResumeEntry].self, from: data) {
            legacyEntries = decoded
        } else {
            legacyEntries = [:]
        }
        let legacyRecents: [PlaybackResumeEntry]
        if let data = defaults.data(forKey: legacyRecentsKey),
           let decoded = try? JSONDecoder().decode([PlaybackResumeEntry].self, from: data) {
            legacyRecents = decoded
        } else {
            legacyRecents = []
        }
        payload = Payload(entries: legacyEntries, recents: legacyRecents)
        if !legacyEntries.isEmpty || !legacyRecents.isEmpty {
            scheduleWrite(payload, removeLegacyAfterSuccess: true)
        }
    }

    func resumeEntry(for item: MediaItem) -> PlaybackResumeEntry? {
        let aliases = playbackKeyAliases(for: item)
        lock.lock()
        let directMatches = aliases.compactMap { payload.entries[$0] }
        let entry: PlaybackResumeEntry?
        if let newestDirect = directMatches.max(by: { $0.updatedAt < $1.updatedAt }) {
            entry = newestDirect
        } else {
            // Legacy scan is fallback-only so episode-card rendering stays O(alias-count)
            // after the first v1153 checkpoint has populated source-independent aliases.
            entry = payload.entries.values
                .filter { legacyIdentityMatches($0, item: item) }
                .max { $0.updatedAt < $1.updatedAt }
        }
        lock.unlock()
        guard let entry, entry.seconds >= minimumResumeSeconds else { return nil }
        if entry.duration > 0, entry.seconds / entry.duration >= completionThreshold {
            clear(for: item)
            return nil
        }
        return entry
    }

    func saveProgress(item: MediaItem, seconds: Double, duration: Double, synchronously: Bool = false) {
        guard seconds.isFinite, seconds >= minimumResumeSeconds else { return }
        let normalizedDuration = duration.isFinite && duration > 0 ? duration : 0
        if normalizedDuration > 0, seconds / normalizedDuration >= completionThreshold {
            clear(for: item)
            return
        }

        let key = playbackKey(for: item)
        let aliases = playbackKeyAliases(for: item)
        let entry = PlaybackResumeEntry(
            key: key,
            title: item.title,
            type: item.type,
            catalog: item.catalog,
            season: item.seasonNumber,
            episode: item.episodeNumber,
            seconds: seconds,
            duration: normalizedDuration,
            updatedAt: Date(),
            artworkURL: item.landscapeURL ?? item.posterURL
        )

        lock.lock()
        // v1153: remove stale single-key/legacy copies first, then publish the same newest
        // checkpoint under every known identity for this exact movie or S/E episode. Find
        // Links may hydrate IMDb -> TMDB (or the reverse), but all routes now meet here.
        payload.entries = payload.entries.filter { _, existing in
            !legacyIdentityMatches(existing, item: item)
        }
        for alias in aliases { payload.entries[alias] = entry }
        if payload.entries.count > maxEntries {
            payload.entries = Dictionary(uniqueKeysWithValues: payload.entries
                .sorted { $0.value.updatedAt > $1.value.updatedAt }
                .prefix(maxEntries)
                .map { ($0.key, $0.value) })
        }
        payload.recents.removeAll { existing in
            aliases.contains(existing.key) || legacyIdentityMatches(existing, item: item)
        }
        payload.recents.insert(entry, at: 0)
        if payload.recents.count > maxRecents { payload.recents = Array(payload.recents.prefix(maxRecents)) }
        let snapshot = payload
        lock.unlock()
        if synchronously {
            writeSynchronously(snapshot)
        } else {
            scheduleWrite(snapshot)
        }
    }

    func clear(for item: MediaItem, synchronously: Bool = false) {
        let aliases = playbackKeyAliases(for: item)
        lock.lock()
        payload.entries = payload.entries.filter { key, existing in
            !aliases.contains(key) && !legacyIdentityMatches(existing, item: item)
        }
        payload.recents.removeAll { existing in
            aliases.contains(existing.key) || legacyIdentityMatches(existing, item: item)
        }
        let snapshot = payload
        lock.unlock()
        if synchronously {
            writeSynchronously(snapshot)
        } else {
            scheduleWrite(snapshot)
        }
    }

    /// Writes the latest in-memory resume payload before tvOS can suspend or terminate
    /// the process. Normal playback checkpoints remain asynchronous; lifecycle/exit saves
    /// use this bounded synchronous flush so a correct timeline cannot disappear on relaunch.
    func flushSynchronously() {
        lock.lock()
        let snapshot = payload
        lock.unlock()
        writeSynchronously(snapshot)
    }

    func recentEntries() -> [PlaybackResumeEntry] {
        lock.lock()
        let values = payload.recents.sorted { $0.updatedAt > $1.updatedAt }
        lock.unlock()
        return values
    }

    func playbackKey(for item: MediaItem) -> String {
        let season = item.seasonNumber
        let episode = item.episodeNumber
        let lowerType = item.type.lowercased()
        let isEpisode = season != nil || episode != nil || lowerType.contains("episode") || lowerType.contains("series") || lowerType.contains("show")

        if isEpisode {
            let showID = stableShowID(for: item)
            return "episode|\(showID)|s\(season ?? 0)|e\(episode ?? 0)"
        }

        if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) { return "movie|tmdb|\(tmdb)" }
        if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) { return "movie|imdb|\(imdb)" }
        return "movie|fallback|\(safe([item.catalog, item.title, item.year, item.id].joined(separator: "|")))"
    }


    /// v1153 source-independent identity aliases. Resolver hydration is allowed to improve
    /// metadata IDs without creating a second playback timeline for the same title/episode.
    func playbackKeyAliases(for item: MediaItem) -> [String] {
        let season = item.seasonNumber
        let episode = item.episodeNumber
        let lowerType = item.type.lowercased()
        let isEpisode = season != nil || episode != nil || lowerType.contains("episode") || lowerType.contains("series") || lowerType.contains("show")
        var aliases: [String] = [playbackKey(for: item)]

        func append(_ value: String?) {
            guard let value, !value.isEmpty, !aliases.contains(value) else { return }
            aliases.append(value)
        }

        if isEpisode {
            let s = season ?? 0
            let e = episode ?? 0
            for identity in stableShowIDAliases(for: item) {
                append("episode|\(identity)|s\(s)|e\(e)")
            }
            if let seriesStem = normalizedSeriesTitleStem(for: item), !seriesStem.isEmpty {
                append("episode|title|\(safe([seriesStem, item.year].joined(separator: "|")))|s\(s)|e\(e)")
            }
        } else {
            if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) {
                append("movie|tmdb|\(tmdb)")
            }
            if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) {
                append("movie|imdb|\(imdb)")
            }
            if let tvdb = item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !tvdb.isEmpty {
                append("movie|tvdb|\(safe(tvdb))")
            }
            let title = normalizedIdentityTitle(item.title)
            if !title.isEmpty {
                append("movie|title|\(safe([title, item.year].joined(separator: "|")))")
            }
        }
        return aliases
    }

    private func stableShowIDAliases(for item: MediaItem) -> [String] {
        var values: [String] = []
        func add(_ value: String?) {
            guard let value, !value.isEmpty, !values.contains(value) else { return }
            values.append(value)
        }
        add(stableShowID(for: item))
        if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) { add("tmdb:\(tmdb)") }
        if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) { add("imdb:\(imdb)") }
        if let tvdb = item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !tvdb.isEmpty { add("tvdb:\(tvdb)") }

        var raw = item.id
        if let range = raw.range(of: #"[:|/_-]s?\d{1,3}[:|/_-]e?\d{1,4}$"#, options: [.regularExpression, .caseInsensitive]) {
            raw.removeSubrange(range)
        }
        let cleanRaw = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if !cleanRaw.isEmpty { add("raw:\(safe(cleanRaw))") }
        return values
    }

    private func normalizedSeriesTitleStem(for item: MediaItem) -> String? {
        var value = item.title.trimmingCharacters(in: .whitespacesAndNewlines)
        if let range = value.range(of: #"\s+s\d{1,3}e\d{1,4}\b"#, options: [.regularExpression, .caseInsensitive]) {
            value = String(value[..<range.lowerBound])
        }
        value = normalizedIdentityTitle(value)
        return value.isEmpty ? nil : value
    }

    private func normalizedIdentityTitle(_ value: String) -> String {
        value.lowercased()
            .replacingOccurrences(of: #"[^a-z0-9]+"#, with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func legacyIdentityMatches(_ entry: PlaybackResumeEntry, item: MediaItem) -> Bool {
        let itemSeason = item.seasonNumber
        let itemEpisode = item.episodeNumber
        let lowerType = item.type.lowercased()
        let itemIsEpisode = itemSeason != nil || itemEpisode != nil || lowerType.contains("episode") || lowerType.contains("series") || lowerType.contains("show")
        let entryLowerType = entry.type.lowercased()
        let entryIsEpisode = entry.season != nil || entry.episode != nil || entryLowerType.contains("episode") || entryLowerType.contains("series") || entryLowerType.contains("show")
        guard itemIsEpisode == entryIsEpisode else { return false }

        if itemIsEpisode {
            guard (entry.season ?? 0) == (itemSeason ?? 0), (entry.episode ?? 0) == (itemEpisode ?? 0) else { return false }
            var legacyTitle = entry.title.trimmingCharacters(in: .whitespacesAndNewlines)
            if let range = legacyTitle.range(of: #"\s+s\d{1,3}e\d{1,4}\b"#, options: [.regularExpression, .caseInsensitive]) {
                legacyTitle = String(legacyTitle[..<range.lowerBound])
            }
            let entryStem = normalizedIdentityTitle(legacyTitle)
            let itemStem = normalizedSeriesTitleStem(for: item) ?? normalizedIdentityTitle(item.title)
            return !entryStem.isEmpty && entryStem == itemStem
        }

        return normalizedIdentityTitle(entry.title) == normalizedIdentityTitle(item.title)
    }

    private func stableShowID(for item: MediaItem) -> String {
        if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) { return "tmdb:\(tmdb)" }
        if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) { return "imdb:\(imdb)" }
        if let tvdb = item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !tvdb.isEmpty { return "tvdb:\(tvdb)" }
        var raw = item.id
        if let range = raw.range(of: #"[:|/_-]s?\d{1,3}[:|/_-]e?\d{1,4}$"#, options: [.regularExpression, .caseInsensitive]) {
            raw.removeSubrange(range)
        } else if let range = raw.range(of: "season", options: .caseInsensitive) {
            raw = String(raw[..<range.lowerBound])
        }
        return "fallback:\(safe([item.catalog, item.title, item.year, raw].joined(separator: "|")))"
    }

    private func tmdbID(in value: String) -> String? {
        let lower = value.lowercased()
        guard lower.contains("tmdb") else { return nil }
        if let range = value.range(of: #"tmdb[:_/|-]?(?:movie|tv|show|series)?[:_/|-]?(\d+)"#, options: [.regularExpression, .caseInsensitive]) {
            let fragment = String(value[range])
            if let digits = fragment.range(of: #"\d+"#, options: .regularExpression) { return String(fragment[digits]) }
        }
        return nil
    }

    private func tmdbIDFromLooseValue(_ value: String) -> String? {
        value.range(of: #"\d+"#, options: .regularExpression).map { String(value[$0]) }
    }

    private func imdbID(in value: String) -> String? {
        if let range = value.range(of: #"tt\d{6,}"#, options: [.regularExpression, .caseInsensitive]) {
            return String(value[range]).lowercased()
        }
        return nil
    }

    private func imdbIDFromLooseValue(_ value: String) -> String? {
        imdbID(in: value)
    }

    private func safe(_ value: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? String(abs(trimmed.hashValue))
    }

    private func scheduleWrite(_ snapshot: Payload, removeLegacyAfterSuccess: Bool = false) {
        guard let fileURL else { return }
        writerQueue.async {
            self.write(snapshot, to: fileURL, removeLegacyAfterSuccess: removeLegacyAfterSuccess)
        }
    }

    private func writeSynchronously(_ snapshot: Payload) {
        guard let fileURL else { return }
        // Serializing through the same queue drains any older async snapshot first, then
        // commits the newest payload before returning to the lifecycle caller.
        writerQueue.sync {
            self.write(snapshot, to: fileURL, removeLegacyAfterSuccess: false)
        }
    }

    private func write(_ snapshot: Payload, to fileURL: URL, removeLegacyAfterSuccess: Bool) {
        do {
            try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(snapshot)
            try data.write(to: fileURL, options: [.atomic])
            if removeLegacyAfterSuccess {
                UserDefaults.standard.removeObject(forKey: legacyEntriesKey)
                UserDefaults.standard.removeObject(forKey: legacyRecentsKey)
            }
        } catch {
            // Resume memory must never interrupt playback.
        }
    }
}
