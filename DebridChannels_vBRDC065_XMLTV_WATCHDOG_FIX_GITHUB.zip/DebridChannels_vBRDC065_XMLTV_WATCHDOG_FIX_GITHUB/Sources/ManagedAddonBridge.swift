import Foundation

struct ManagedAddonManifest: Hashable, Identifiable {
    let id: String
    let displayName: String
    let manifestURL: String
    let bridgedService: DebridServiceID?
}

/// vBRDC054: the managed bridge is intentionally narrow and opt-in.
///
/// Torrentio is generated ephemerally only after the user explicitly enables it. Merely
/// entering a Real-Debrid/TorBox key never installs or activates Torrentio. User-added
/// Stremio manifests continue to be handled by Saved JSON URLs and stay credential-isolated.
enum ManagedAddonBridge {
    static func coreDebridStreamManifests(defaults: UserDefaults = .standard) -> [ManagedAddonManifest] {
        guard defaults.bool(forKey: "managedTorrentioEnabled") else { return [] }
        let cachedOnly = defaults.object(forKey: "builtInAddonCachedOnly") as? Bool ?? true
        let excludeCam = defaults.object(forKey: "builtInAddonExcludeCam") as? Bool ?? true
        var output: [ManagedAddonManifest] = []

        for service in DebridServiceID.allCases {
            guard let credential = DebridCredentialBridge.credential(for: service, defaults: defaults),
                  let torrentio = torrentioManifestURL(
                    credential: credential,
                    cachedOnly: cachedOnly,
                    excludeCam: excludeCam
                  ) else { continue }
            output.append(ManagedAddonManifest(
                id: "torrentio-\(service.rawValue)",
                displayName: "Torrentio • \(service.displayName)",
                manifestURL: torrentio,
                bridgedService: service
            ))
        }
        return output
    }

    private static func torrentioManifestURL(
        credential: DebridCredentialSnapshot,
        cachedOnly: Bool,
        excludeCam: Bool
    ) -> String? {
        let serviceKey: String
        switch credential.service {
        case .realDebrid: serviceKey = "realdebrid"
        case .torBox: serviceKey = "torbox"
        }
        let allowed = CharacterSet.urlPathAllowed.subtracting(CharacterSet(charactersIn: "|"))
        let key = credential.credential.addingPercentEncoding(withAllowedCharacters: allowed) ?? credential.credential
        var parts = ["\(serviceKey)=\(key)"]
        if cachedOnly { parts.append("debridoptions=nodownloadlinks") }
        if excludeCam { parts.append("qualityfilter=cam,ts,telesync,hdcam,scr") }
        return "https://torrentio.strem.fun/\(parts.joined(separator: "|"))/manifest.json"
    }
}
