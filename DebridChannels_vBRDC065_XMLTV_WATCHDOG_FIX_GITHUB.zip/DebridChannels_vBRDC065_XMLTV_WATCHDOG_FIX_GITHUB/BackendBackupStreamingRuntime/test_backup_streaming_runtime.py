import json
import unittest
from urllib.parse import parse_qs

from backup_streaming_runtime import (
    BackupStreamingRuntimeConfig,
    HTTPResult,
    resolve_febbox_streams,
    verify_febbox_cookie,
)


class FakeFetcher:
    def __init__(self):
        self.calls = []

    def __call__(self, method, url, headers, body, timeout):
        self.calls.append((method, url, dict(headers), body, timeout))
        if url.endswith('/console/user_cards'):
            return HTTPResult(200, {}, json.dumps({'data': {'flow': {'traffic_limit_mb': 102400, 'traffic_usage_mb': 2048}}}).encode())
        if 'showbox.media/search' in url:
            return HTTPResult(200, {}, b'<div class="film-poster"><a class="film-poster-ahref" href="/movie/detail/123-example" title="Example Movie"></a></div>')
        if 'showbox.media/movie/detail' in url:
            return HTTPResult(200, {}, b'<a href="https://www.febbox.com/share/share123">FebBox</a>')
        if 'febbox.com/share/share123' in url:
            return HTTPResult(200, {}, b'<div class="file" data-id="55"><p class="file_name">Example.Movie.2025.2160p.HEVC.TrueHD.7.1.8.5GB.mkv</p></div>')
        if url.endswith('/file/player'):
            request = parse_qs((body or b'').decode())
            if request.get('fid') == ['55']:
                return HTTPResult(200, {}, b'var sources = [{"label":"2160p","file":"https://febbox.example/video-2160.mp4"},{"label":"1080p","file":"https://febbox.example/video-1080.mp4"}];')
        return HTTPResult(404, {}, b'{}')


class BackupStreamingRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.fetcher = FakeFetcher()
        self.config = BackupStreamingRuntimeConfig(febbox_region='USA7', timeout_seconds=2, maximum_streams_per_provider=50)

    def test_verify_cookie_uses_request_scoped_ui_cookie(self):
        result = verify_febbox_cookie({'febboxCookie': 'ui=secret-cookie; Path=/'}, self.config, self.fetcher)
        self.assertTrue(result['valid'])
        call = next(c for c in self.fetcher.calls if c[1].endswith('/console/user_cards'))
        self.assertEqual(call[2]['Cookie'], 'ui=secret-cookie')
        self.assertNotIn('secret-cookie', json.dumps(result))

    def test_verify_cookie_rejects_missing_value(self):
        result = verify_febbox_cookie({}, self.config, self.fetcher)
        self.assertFalse(result['valid'])
        self.assertEqual(self.fetcher.calls, [])

    def test_resolve_movie_returns_full_febbox_quality_ladder(self):
        result = resolve_febbox_streams({'title': 'Example Movie', 'year': '2025', 'mediaType': 'movie', 'febboxCookie': 'secret-cookie'}, self.config, self.fetcher)
        self.assertEqual(result['status'], 'ready')
        self.assertEqual(result['providers']['febbox'], 2)
        self.assertEqual([s['quality'] for s in result['streams']], ['2160p', '1080p'])
        self.assertIn('H.265', result['streams'][0]['codecs'])
        self.assertIn('TrueHD', result['streams'][0]['codecs'])
        self.assertNotIn('secret-cookie', json.dumps(result))

    def test_resolve_cookie_is_only_sent_to_febbox_hosts(self):
        resolve_febbox_streams({'title': 'Example Movie', 'year': '2025', 'mediaType': 'movie', 'febboxCookie': 'secret-cookie'}, self.config, self.fetcher)
        showbox_calls = [c for c in self.fetcher.calls if 'showbox.media' in c[1]]
        febbox_calls = [c for c in self.fetcher.calls if 'febbox.com' in c[1]]
        self.assertTrue(showbox_calls)
        self.assertTrue(febbox_calls)
        self.assertTrue(all('Cookie' not in c[2] for c in showbox_calls))
        self.assertTrue(all('secret-cookie' in c[2].get('Cookie', '') for c in febbox_calls))

    def test_control_characters_cannot_become_cookie_header(self):
        result = resolve_febbox_streams({'title': 'Example Movie', 'mediaType': 'movie', 'febboxCookie': 'abc\r\nInjected: yes'}, self.config, self.fetcher)
        self.assertEqual(result['status'], 'no_links')
        self.assertEqual(self.fetcher.calls, [])


if __name__ == '__main__':
    unittest.main()
