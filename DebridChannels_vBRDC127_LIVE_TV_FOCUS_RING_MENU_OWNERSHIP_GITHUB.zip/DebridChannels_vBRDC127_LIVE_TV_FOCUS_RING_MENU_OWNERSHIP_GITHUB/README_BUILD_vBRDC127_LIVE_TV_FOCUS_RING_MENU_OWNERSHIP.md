# Debrid Channels vBRDC127 — Live TV Focus Ring + Top Menu Ownership

- Release ID: `vBRDC127`
- Marketing version: `1.0.830`
- Apple build: `830`
- Donor: packaged `vBRDC126` only

## Physical-device findings addressed

The supplied Apple TV photos/video showed three concrete presentation/focus faults after vBRDC126:

1. The configurable Live TV focused ring no longer visually tracked the exact clipped card outline.
2. Pulse/breathing glow was too faint to read as an intentional animation on a television.
3. Selecting Home, Movies, or TV Shows from the top menu could be followed by focus dropping into a catalog row or the persistent Live TV grid underneath instead of remaining on the selected top-menu tab.

## vBRDC127 corrections

### Exact Live TV card-shaped ring

- Added one authoritative `LiveTVGridCardGeometry.cornerRadius` shared by the Live TV card clip, base border, and configurable focus ring.
- The configurable ring is now attached as a true overlay of the exact laid-out card bounds.
- `strokeBorder` keeps the visible outline inside the card mask instead of allowing the stroke to extend beyond it.
- The focused inner outline never scales independently from the card.
- Pulse/Breathing animate glow intensity/blur only; the ring geometry itself is not deformed.
- The ring remains present through the short defocus settle instead of disappearing on the first state edge.

### Stronger but isolated focused glow

- Classic Glow gets a clearer halo while preserving the single focused-leaf architecture.
- Soft Pulse uses a faster, more visible opacity/blur swing.
- Breathing Glow uses a slower, deeper glow swing.
- No pulse mode scales the card, artwork subtree, footer, grid, or ring outline.

### Stronger Live TV preview emphasis

- Non-preview Live TV cards now dim to `0.42` opacity while the focused preview is active (vBRDC126 used `0.56`).
- The focused preview card remains at full brightness.
- Dimming remains compositor-only and does not alter card geometry or artwork logic.

### Top-menu-owned Home / Movies / TV Shows handoff

- Selecting Home, Movies, or TV Shows with Select now marks the top menu as the authoritative focus owner for that tab handoff.
- The selected top-menu tab remains focused until the user explicitly presses Down.
- Down clears the menu ownership marker and emits the existing content-focus token.
- The persistent Live TV cards and Live TV category rail are removed from the tvOS focus graph whenever `selectedTab != .live`.
- During the outgoing Live TV transition, only the visual focused-card snapshot remains pinned; real Live TV `FocusState` is cleared immediately.
- Catalog branch activation/appear/scene recovery cannot assign row focus while the top menu owns the selected tab.
- Late catalog/provider row publications may update data but cannot assign `focusedRow` while the menu owns focus.
- Catalog lifecycle/interactivity recovery may repair state while preserving the top-menu focus hold instead of generating an unsolicited content-focus token.

## Preserved

- vBRDC126 Live TV single-owner grid motion engine, virtual-window coalescing, preview duration choices, ring colors/motion settings, and nonpublishing interaction runtime.
- vBRDC125 catalog artwork identity/motion hardening.
- vBRDC124 Live TV menu/surface handoff and bounded artwork/decode corrections.
- vBRDC123 VOD foreground artwork/cast/episode hardening.
- vBRDC121 Bluetooth VOD ownership/media controls.
- Live TV card dimensions, four-column geometry, artwork presentation, footer, EPG, provider routing, guide, playback, MediaFlow, Sports, Cast Explorer, PlaybackKit, VOD resume and source routing.

## Validation

- vBRDC127 cumulative regression contract: **162/162 passed**.
- Production Swift syntax parse: **65/65 files passed**.
- Backend runtime suites: **36/36 passed**.
- App / Top Shelf / project version consistency passed: `vBRDC127 / 1.0.830 / 830`.
- Changed Swift trailing-whitespace check passed.
- Locked donor hashes passed for Unity catalog visuals/coordinator, MediaFlow, Cast Explorer, Sports and PlaybackKit.
- ZIP integrity is checked after final packaging.
- GitHub Actions/Xcode remains authoritative for the tvOS Release compile.
- Physical Apple TV remains authoritative for final subjective ring/glow/focus verification.
