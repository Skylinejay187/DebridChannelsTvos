# App-Wide Regression Locks — vBRDC127

vBRDC127 is additive to packaged vBRDC126 and extends the cumulative contract to **162 checks**.

## New locks

- Live TV focused ring, card clip, and base border share one authoritative continuous-rounded card geometry.
- Focus ring uses `strokeBorder` and never independently scales its outline.
- Soft Pulse / Breathing Glow animate only halo intensity/blur, not card/ring geometry.
- Preview dimming uses the stronger `0.42` nonfocused opacity while the preview owner remains full brightness.
- Persistent Live TV tiles and category rail cannot remain focusable when another tab owns the surface.
- Outgoing Live TV handoff clears real tile/category/guide FocusState while retaining only the temporary visual focus pin.
- `CatalogStore.topMenuSelectedTabFocusOwner` is deliberately non-`@Published`.
- Selecting Home/Movies/Shows from the top menu keeps that tab as real focus owner until Down.
- Down explicitly clears top-menu ownership and transfers focus to content through the existing content-focus token.
- Automatic catalog row-focus restoration cannot run while top-menu ownership is active.
- Catalog visual focus pin cannot simultaneously focus a row while the menu owns the incoming branch.
- Root tab handoff cannot emit a content-focus token while the selected top-menu tab owns the transition.
- Late catalog/provider row publication cannot assign FocusState while top-menu ownership is active.
- Catalog lifecycle/interactivity recovery cannot generate an unsolicited content-focus token during the top-menu hold.

## Preserved cumulative locks

Every vBRDC126 lock remains, including the single-owner Live TV focus motion engine, staged/coalesced virtual corridor, nonpublishing task runtime, preview lifetime controls, focus ring palette/motion settings, vBRDC125 catalog artwork identity, vBRDC124 Live TV artwork/focus handoff, MediaFlow, Bluetooth VOD, Cast Explorer, Sports, PlaybackKit, guide/EPG caches, and app-wide frame authority.

Run:

```bash
python validation_vBRDC127/test_vBRDC127_contract.py
```

Expected: `162/162 checks passed`.
