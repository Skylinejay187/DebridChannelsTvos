# App-Wide Regression Locks — vBRDC134

vBRDC134 extends the cumulative vBRDC133 contract with runtime-quiescence locks.

New locks verify that:

- All nonvisual `Task` handles are absent from SwiftUI `@State`.
- Root, catalog overlay, catalog rail, Live TV lifecycle and VOD hot surfaces use retained non-publishing runtime owners.
- Search, Media Information, details, popup metadata, trailers, Sports and Favorites use the same ownership model.
- Runtime owner classes contain no `@Published` properties.
- VOD AVPlayer observer tokens are no longer `@State`.
- VOD heavy chrome still unmounts when hidden.
- PlaybackKit still suppresses hidden overlay tick publication.
- VOD-exclusive entry still cancels nonessential registered work.
- MediaFlow heartbeat remains cancelled during playback.
- The completed top-bar ticker no longer owns an idle 2.6-second Timer publisher.
- The unused diagnostics pulse is absent.
- The vBRDC126 Live TV grid interaction runtime, covered-grid compaction and VOD hidden clock quiet mode remain present.

Cumulative result: `210/210`.
