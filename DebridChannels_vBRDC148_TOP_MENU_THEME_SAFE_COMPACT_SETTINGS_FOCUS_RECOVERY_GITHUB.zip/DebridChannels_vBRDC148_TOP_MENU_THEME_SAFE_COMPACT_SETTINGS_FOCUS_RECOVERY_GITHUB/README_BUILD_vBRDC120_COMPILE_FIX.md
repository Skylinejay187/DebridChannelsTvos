# Debrid Channels vBRDC120 — vBRDC119 Compile Correction

Release: **vBRDC120**  
Marketing version: **1.0.823**  
Apple build: **823**  
Donor: **attached packaged vBRDC119 ZIP only**

## Scope

This is a compile-only corrective candidate for the GitHub Actions/Xcode failure in build log `90200857660`. It preserves the complete vBRDC119 final app-wide frame-budget/performance pass and changes no intended visuals, navigation, playback behavior, provider behavior, artwork quality, animations, or feature policy.

## Corrections

1. Dynamic Wallpaper streaming decoder: removed a second `guard let self` inside a scope where `self` had already been promoted from the weak capture. The generation/URL/pause safety checks remain unchanged.
2. HDHomeRun / Channels DVR provider parsing: restored the provider value-normalization helper that vBRDC119's off-main parser isolation had made local to the Xtream worker, and restored the generic HDHomeRun XML tag reader.
3. Live TV focus preview: unwraps `previewChannelID` before calling the new O(1) indexed `channel(id: Int)` lookup.

## Non-regression

The vBRDC119 event-driven frame gates, durable publication lanes, O(1) Live TV indexing, parser offloading, Dynamic Wallpaper pause gate, guide-cache write coalescing, VOD cast navigation, and all locked visual/provider/playback files remain in place.

GitHub Actions/Xcode remains the authoritative full tvOS Release compile.
