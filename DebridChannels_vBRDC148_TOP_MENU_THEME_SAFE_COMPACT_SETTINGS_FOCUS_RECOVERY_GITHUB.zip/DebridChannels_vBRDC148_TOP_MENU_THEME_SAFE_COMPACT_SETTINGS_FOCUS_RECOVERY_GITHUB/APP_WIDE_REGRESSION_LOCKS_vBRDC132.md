# vBRDC132 App-Wide Regression Locks

vBRDC132 adds a narrow directional-navigation lock on top of the vBRDC131 cumulative contract.

## Top menu command separation

- **Select/tap** on Home, Movies, TV Shows, Sports, Favorites, Live TV, or Settings keeps its normal category action.
- **Back/Menu** from a catalog keeps the vBRDC131 real catalog-surface dismissal and returns to that selected top-menu item.
- **Down** from the global top menu has one universal destination: the persistent Live TV grid.
- Down never reopens Home/Movies/TV Shows rows and never emits a catalog `contentFocusToken`.
- Down clears transient menu/catalog presentation ownership, activates `.live`, then emits the dedicated `liveTVMenuFocusEntryToken` after one render turn when switching from another surface.
- The Live TV grid remains natively focusable; no vBRDC127 conditional focus graph is restored.

## Preserved visual/runtime locks

- vBRDC128 exact card-shaped Live TV focus ring remains unchanged.
- vBRDC126 Live TV grid motion engine and preview controls remain unchanged.
- vBRDC131 catalog close/reopen compositor path remains unchanged.
- vBRDC125 catalog artwork identity hardening remains unchanged.
- MediaFlow, PlaybackKit, Sports, Cast Explorer, UNITY animation/visual systems remain donor-identical.
