# vBRDC124 Release Performance Audit

## Highest-impact findings resolved

| Area | Finding | Fix | User-visible intent |
|---|---|---|---|
| Live Controls | Focus mutations and panel motion overlapped | Split visual motion from focus ownership | Smooth natural open/close |
| Live TV return | Real focus could reclaim the card before close settled | Surface focus pin + guarded final bind | No closing snap/re-grow |
| Live Controls counts | Provider lineup filtered repeatedly per category | Reuse provider indexes | Remove menu-open MainActor spike |
| EPG cards | Current-program scan repeated across visible cards | Schedule-boundary cache | Less D-pad body work |
| Artwork decoder | Cancelled jobs stayed in two-slot wait queue | Cancellation-aware waiter removal | Prevent navigation decode convoys |
| Artwork publication | Private 35 ms loop polled frame availability | Shared revision continuation | Eliminate polling wakeups |
| Tiny artwork | Some guide/playback icons decoded source resolution | Display-bounded ImageIO decode | Lower CPU/memory bandwidth |
| Tile rendering | Unchanged Live TV card subtree could recompute | Equatable tile content | Reduce focus-neighbor body churn |
| Catalog motion | Focus bind could overlap reverse transition tail | Retuned UNITY profile | Natural menu-style close |

## Deliberately not changed

No layout geometry, visual effect, card size, channel/provider routing, playback selection, VOD behavior, Bluetooth ownership, Sports routing, Favorites behavior, or catalog data logic was redesigned in this pass. Potentially broader refactors were rejected because release safety is more important than speculative micro-optimization.

## Validation boundary

Static/runtime validation verifies code contracts and syntax, but only Xcode/GitHub Actions and physical Apple TV testing can confirm platform compilation and actual frame pacing. The build intentionally does not claim a measured 60 FPS number from the Linux environment.
