# vBRDC130 App-Wide Regression Locks

vBRDC130 adds the following locks on top of the full vBRDC129 cumulative contract:

1. Catalog Back/Menu owns an explicit nonpublishing `catalogRowsYieldingToTopMenu` state and one cancellable handoff task.
2. The persistent `GridOSFixedSlotCatalogRail` remains mounted but exposes an `allowsFocus` gate.
3. Back/Menu keeps `selectedTab` unchanged and sets `topMenuSelectionHoldTab` to the selected Home / Movies / TV Shows category.
4. While that hold is active, the catalog rail is not a valid tvOS focus destination.
5. The top-menu focus request occurs only after a one-frame yield; there is no Live TV fallback and no retry loop.
6. Delayed catalog detail/row/lifecycle restoration cannot restore row focus during the menu-yield window.
7. A deliberate content-focus token cancels the exit handoff and immediately re-enables normal catalog focus.
8. vBRDC128 exact Live TV card-owned focus ring geometry remains locked.
9. vBRDC129 automatic catalog entry and explicit Live TV Down-entry behavior remain locked.

Expected physical behavior:

- Select Home / Movies / TV Shows -> rows open normally.
- Press Back/Menu once from those rows -> focus moves to that same selected top-menu item.
- Press Down -> rows are immediately enterable again.
- Select Live TV, then Down -> native Live TV grid is enterable and scrollable.
- No catalog Back/Menu path may focus a Live TV card.
