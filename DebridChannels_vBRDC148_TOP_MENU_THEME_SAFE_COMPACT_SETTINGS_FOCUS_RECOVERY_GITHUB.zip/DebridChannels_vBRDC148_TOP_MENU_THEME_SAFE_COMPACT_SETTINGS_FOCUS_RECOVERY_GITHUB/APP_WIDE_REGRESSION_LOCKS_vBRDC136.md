# App-Wide Regression Locks — vBRDC136

Cumulative automated contract: **229/229 passed**.

New vBRDC136 locks cover:

- Catalog card press captures the durable originating media identity before Media Information opens.
- Media Information preview ownership uses the captured origin/anchor rather than ambient `focusedRow`.
- Same-id metadata hydration cannot invalidate the active preview.
- Canonical same-media identity remains accepted across provider/detail hydration.
- Active same-card preview preservation still executes before the destructive replacement/teardown path.
- Existing teardown rules for a real media change, playback, Trailer, Search, scene exit and memory warning remain present.

All vBRDC135 cumulative locks are retained in `validation_vBRDC136/test_vBRDC136_contract.py`.
