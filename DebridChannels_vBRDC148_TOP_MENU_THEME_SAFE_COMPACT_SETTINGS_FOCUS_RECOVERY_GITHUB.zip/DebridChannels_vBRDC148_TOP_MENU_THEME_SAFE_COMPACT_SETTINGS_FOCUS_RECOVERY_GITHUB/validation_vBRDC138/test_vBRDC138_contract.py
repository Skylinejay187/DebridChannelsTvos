from pathlib import Path
import hashlib, plistlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
FRAME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
CAT=(ROOT/'Sources/CatalogStore.swift').read_text()
CACHE=(ROOT/'Sources/LiveTVGuideCacheManager.swift').read_text()
MFP=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
PROJ=(ROOT/'project.yml').read_text()
PHASE15=(ROOT/'Sources/Phase15FinalIntegration.swift').read_text()
VODGATE=(ROOT/'Sources/VODExclusivePlaybackGate.swift').read_text()
PBK=(ROOT/'Sources/PlaybackKit/PlaybackKitFoundation.swift').read_text()
PBKS=(ROOT/'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift').read_text()
RESUME=(ROOT/'Sources/PlaybackResumeCache.swift').read_text()
SECURITY=(ROOT/'Sources/ReleaseCandidateSecurityManager.swift').read_text()
checks=[]
def check(name, cond): checks.append((name, bool(cond)))
def block_between(text,start,end):
    a=text.index(start); b=text.index(end,a); return text[a:b]

# Release/version
with (ROOT/'Sources/Info.plist').open('rb') as f: info=plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top=plistlib.load(f)
check('release id vBRDC138', info.get('DebridChannelsReleaseID')=='vBRDC138' and top.get('DebridChannelsReleaseID')=='vBRDC138')
check('marketing 1.0.841', info.get('CFBundleShortVersionString')=='1.0.841' and top.get('CFBundleShortVersionString')=='1.0.841' and PROJ.count('MARKETING_VERSION: 1.0.841')==2)
check('build 841', info.get('CFBundleVersion')=='841' and top.get('CFBundleVersion')=='841' and PROJ.count('CURRENT_PROJECT_VERSION: 841')==2)


# vBRDC122 compile-only corrections from GitHub/Xcode build 90200857660
check('wallpaper MainActor closure no longer optional-binds promoted self', 'guard let self, self.configuredURL == url, self.decoderGeneration == generation, !self.isPaused' not in APP)
check('HDHomeRun and DVR provider string helper restored', 'private func stringValue(_ row: [String: Any], keys: [String]) -> String' in APP)
check('HDHomeRun generic XML tag helper restored', 'private func tagText(_ body: String, tag: String) -> String' in APP)
check('optional preview channel id is flattened before indexed lookup', 'previewChannelID.flatMap { liveModel.channel(id: $0) } ?? selectedChannel' in APP)

# Event-driven shared frame authority
check('shared revision waiter hub exists', 'private final class UnityFrameRevisionWaiterHub' in FRAME)
check('waiter hub uses continuations', 'CheckedContinuation<Bool, Never>' in FRAME and 'withCheckedContinuation' in FRAME)
check('waiter hub is cancellation aware', 'withTaskCancellationHandler' in FRAME and 'pendingCancellationIDs' in FRAME)
check('frame revision wakes shared waiters', 'revisionWaiters.publish(revision)' in FRAME)
normal_wait=block_between(FRAME,'func waitUntilPermitted(_ lane: Lane','/// Authoritative results')
check('courtesy gate no sleep polling', 'Task.sleep' not in normal_wait and 'waitForChange(' in normal_wait)
check('legacy poll arg retained but unused', '_ = poll' in normal_wait)
durable=block_between(FRAME,'func waitUntilPermittedDurably(_ lane: Lane)','func resetTransientOwnership')
check('durable authoritative gate has no timeout', 'timeout: nil' in durable and 'Task.sleep' not in durable)
check('durable gate respects cancellation', 'Task.isCancelled' in durable)
check('authoritative catalog publications use durable gate', CAT.count('waitUntilPermittedDurably(.interactiveMetadata)') >= 3)
check('decoded image publication uses durable gate', 'waitUntilPermittedDurably(lane)' in IMG)
check('authoritative app publications use durable gate widely', APP.count('waitUntilPermittedDurably(.interactiveMetadata)') >= 10)
check('selected Live TV channel persistence is durable', 'waitUntilPermittedDurably(.persistence)' in APP)

# Catalog invalidation suppression
update_rows=block_between(CAT,'private func updateVisibleCatalogRows','private func schedule')
check('CatalogStore skips identical row publication', 'guard nextRows != rows else { return false }' in update_rows)
rebuild=block_between(APP,'private func rebuildRenderedRows(reason: String)','private func scheduleRenderedRowsRebuild')
check('catalog retained snapshot skips identical projection', 'guard updated != previousRows else { return }' in rebuild)

# Stable Live TV identity / O(1) focus access
liveprogram=block_between(APP,'struct LiveProgram: Identifiable','struct XMLTVGuideChannelSnapshot')
check('LiveProgram id no longer random UUID', 'let id: UInt64' in liveprogram and 'UUID()' not in liveprogram)
check('LiveProgram deterministic identity hashing', 'stableIdentity' in liveprogram or 'stableID' in liveprogram or '1469598103934665603' in liveprogram)
check('Live TV provider builds id lookup', 'private var indexedChannelByID: [Int: LiveTVChannel]' in APP)
check('Live TV provider builds position lookup', 'private var channelBrowsePositionIndex: [String: [Int: Int]]' in APP)
check('focused channel lookup is O(1)', 'func channel(id: Int) -> LiveTVChannel? { indexedChannelByID[id] }' in APP)
check('focused position lookup is O(1)', 'func browsePosition(of channelID: Int, category: String) -> Int?' in APP)

# Live TV publication batching/equality
check('channel publication equality guard exists', 'private func publishChannelsIfChanged(_ next: [LiveTVChannel]) -> Bool' in APP and 'guard next != channels else { return false }' in APP)
check('guide publication equality guard exists', 'private func publishGuideProgramsIfChanged(_ next: [String: [LiveProgram]]) -> Bool' in APP and 'guard next != guidePrograms else { return false }' in APP)
check('guide batches merge atomically', 'private func mergeGuideProgramsAtomically' in APP)
check('no direct per-key guide publication remains', re.search(r'guidePrograms\s*\[[^\]]+\]\s*=', APP) is None)

# XMLTV/Gracenote parsing
parser=block_between(APP,'private enum LiveTVXMLTVBackgroundParser','@MainActor\nfinal class LiveTVSourceModel')
check('XMLTV parser has one per-parse context', 'private final class ParseContext' in APP and 'let context = ParseContext()' in APP)
check('XMLTV stores program once by channel id', 'programsByChannelID[channelID, default: []].append' in APP)
check('XMLTV uses reverse alias index', 'channelIDsByLookupKey' in APP)
check('XMLTV parse is detached utility work', 'LiveTVXMLTVBackgroundParser.parse(' in APP and 'Task.detached(priority: .utility)' in APP)
check('legacy main-thread XMLTV date helpers absent', 'private func xmltvDate(' not in APP and 'private func guideTimeText(' not in APP)
check('XMLTV lookup regexes compiled once on model', 'private static let xmltvLookupDigitRegex' in APP and 'private static let xmltvLookupNumberedNameRegex' in APP)
check('unused legacy channel-name parser removed', APP.count('channelLookupNames(_ xml: String)') == 0)

# M3U/Xtream CPU work off MainActor
check('M3U parsing has Sendable draft', 'struct M3ULiveDraft: Sendable' in APP)
check('M3U parsing uses detached utility worker', 'Self.parseM3UDrafts(text, source: source, baseURL: baseURL)' in APP and 'Task.detached(priority: .utility)' in APP)
check('M3U uses one attribute regex pass', 'private nonisolated static func parseM3UDrafts' in APP and 'attributeRegex' in APP)
check('Xtream short EPG parser is nonisolated', 'private nonisolated static func parseXtreamShortEPGOffMain' in APP)
check('Xtream short EPG parse is detached', 'Self.parseXtreamShortEPGOffMain(data: data, now: now, cutoff: cutoff)' in APP)
check('legacy per-field Xtream date helper absent', 'xtreamEPGDate' not in APP)

# Large guide cache IO leaves MainActor
check('guide cache owns utility persistence queue', 'DispatchQueue(label: "com.debridchannels.livetv-guide-cache", qos: .utility)' in CACHE)
check('channel persistence coalesces latest snapshot', 'pendingChannels' in CACHE and 'channelWorkerScheduled' in CACHE and 'drainChannelWrites()' in CACHE)
check('guide persistence coalesces latest snapshot', 'pendingGuide' in CACHE and 'guideWorkerScheduled' in CACHE and 'drainGuideWrites()' in CACHE)
check('large JSON encode occurs inside writer drain', 'JSONEncoder().encode(cached)' in CACHE and 'persistenceQueue.async' in CACHE)

# Dynamic wallpaper event-driven pausing
check('wallpaper pause gate exists', 'private final class DynamicWallpaperPauseGate' in APP)
wallgate=block_between(APP,'private final class DynamicWallpaperPauseGate','private final class DynamicWallpaperAnimatedUIImageView')
check('wallpaper pause gate continuation based', 'CheckedContinuation<Bool, Never>' in wallgate and 'waitUntilRunning()' in wallgate)
animated=block_between(APP,'private final class DynamicWallpaperAnimatedUIImageView','private struct DynamicWallpaper')
check('animated wallpaper waits on pause signal', 'await self.pauseGate.waitUntilRunning()' in animated)
check('old 45ms paused poll removed from wallpaper decoder', '45_000_000' not in animated)

# Episode/date metadata repeated construction removed
check('episode metadata parser pool exists', 'private final class DCEpisodeMetadataParser' in APP)
episode_block=block_between(APP,'private final class DCEpisodeMetadataParser','private func dcNextUpcomingEpisodeAlertItem')
check('episode parser reuses date formatters', 'alternateDateFormatters' in episode_block and 'displayFormatter' in episode_block)
check('episode parser reuses season/date regexes', 'ymdRegex' in episode_block and 'seasonEpisodeRegexes' in episode_block)
check('episode date presentation no longer constructs formatter per call', 'DateFormatter()' not in block_between(APP,'private func dcEpisodeDatePresentation','private func dcParsedSeasonEpisode'))
check('episode alert scanner pools date parser objects', 'private static let episodeAlertDateParserLock = NSLock()' in CAT and 'episodeAlertAirDateFormatters' in CAT and 'episodeAlertFractionalISOFormatter' in CAT)
scanner_parse=block_between(CAT,'private static func parseEpisodeAirDate','private static func sendEpisodeNotification')
check('episode alert scan parse no per-episode formatter construction', 'DateFormatter()' not in scanner_parse and 'ISO8601DateFormatter()' not in scanner_parse)

# VOD high-frequency state write guards
check('AVPlayer duration writes equality guarded', APP.count('abs(durationSeconds -') >= 3)
check('AVPlayer playing-state writes equality guarded', 'if isPlaying != nextPlaying { isPlaying = nextPlaying }' in APP)

# v118 performance/visual behavior preserved
check('heavy-load opt-in defaults false', 'var deferHeavyLoadDuringNavigation: Bool = false' in IMG)
check('4K decorative surfaces keep deferred cache-miss option', APP.count('deferHeavyLoadDuringNavigation: true') == 4)
check('35-second catalog preview retained', 'CMTime(seconds: 35.0' in APP and 'finishCurrentPreview(reason: "35-second cap")' in APP)
check('Bluetooth Now Playing retained', 'MPNowPlayingInfoCenter.default().nowPlayingInfo' in APP and 'MPRemoteCommandCenter.shared()' in APP)
check('MediaFlow LAN bootstrap route retained', 'let endpoints = epg ? ["/proxy/epg", "/proxy/stream"] : ["/proxy/stream"]' in MFP)
check('episode alert 530x176 retained', '.frame(width: 530, height: 176' in APP)
check('episode alert 18pt screen edge retained', 'private let newEpisodeAlertScreenEdgeInset: CGFloat = 18' in APP)

# vBRDC119 additive VOD Cast manual navigation
check('VOD cast has manual navigation token', 'featuredCastManualNavigationToken' in APP and 'castManualNavigationToken:' in APP)
check('focused VOD cast routes LEFT and RIGHT manually', 'case .left:\n                moveFeaturedCast(by: -1)' in APP and 'case .right:\n                moveFeaturedCast(by: 1)' in APP)
check('manual cast navigation wraps through image-backed members', 'private func moveFeaturedCast(by delta: Int)' in APP and 'members.count > 1' in APP and 'featuredCastSpotlightIndex = next' in APP)
check('manual cast navigation resets existing 7-second clock only', r'manual:\(manualNavigationToken)' in APP and '7_000_000_000' in APP)
check('cast navigation arrows are transient focus hint', 'castNavigationHintVisible' in APP and '2_200_000_000' in APP and 'chevron.left' in APP and 'chevron.right' in APP)
check('cast hint stays inside portrait surfaces', 'fullPosterCastNavigationHint' in APP and 'compactCastNavigationHint' in APP)
check('cast accessibility advertises left-right browse', 'Press Left or Right to browse cast. Press Select to open Cast Explorer.' in APP)

# Critical visual/provider files that v119 intentionally does not rewrite
expected={
'Sources/UnityCatalogVisualSystem.swift':'e5e4a14c0b61f11f46c2866ed7b0e7f5d14cb46f00269411fc6766defffcd7c3',
'Sources/UnityAnimationCoordinator.swift':'2206eabc3ce477f02de2116b3035b4bae96ee4dca7ef7e2135b1c68cbf820132',
'Sources/MediaFlowProxyRouter.swift':'eaedc162e1b1eff687207b412fb2157cb3168da047b9cf7724d991a9a9bf3c0c',
'Sources/CastExplorerService.swift':'eb465f7a9dfde71e5136e7e14e9931de54159b86ea2b90383e0290961f697b4a',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
}
for rel,want in expected.items():
    got=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
    check(f'locked donor unchanged: {Path(rel).name}', got==want)

# vBRDC122 Bluetooth VOD ownership recovery
check('Bluetooth snapshot retained for reassertion', all(x in APP for x in ['activeTitle: String', 'activeDuration: Double', 'activeElapsed: Double', 'activeIsPlaying: Bool']))
check('Bluetooth route changes reassert VOD ownership', 'AVAudioSession.routeChangeNotification' in APP and 'reassertActiveVODOwnership(reason: "audio route changed")' in APP)
check('audio interruption end reasserts VOD ownership', 'AVAudioSession.interruptionNotification' in APP and 'AVAudioSession.InterruptionType(rawValue: raw) == .ended' in APP)
check('media service reset reasserts VOD ownership', 'AVAudioSession.mediaServicesWereResetNotification' in APP and 'reassertActiveVODOwnership(reason: "media services reset")' in APP)
check('app activation reasserts VOD ownership', 'UIApplication.didBecomeActiveNotification' in APP and 'reassertActiveVODOwnership(reason: "app became active")' in APP)
check('first real VOD frame reasserts ownership', 'reassertActiveVODOwnership(reason: "VOD first frame")' in APP)
check('VOD scene activation reasserts ownership', 'reassertActiveVODOwnership(reason: "VOD scene active")' in APP)
check('reassertion remains event driven no Bluetooth timer', 'installSystemOwnershipObserversIfNeeded()' in APP and 'systemObserverTokens' in APP)
check('release stays UUID guarded', 'if activeSessionID == sessionID {' in APP and 'releaseVODSession(playbackPresentationID)' in CAT)


# vBRDC122 physical Cast Explorer artwork recovery
explorer=block_between(APP,'struct V1134CastExplorerOverlay: View','struct V1134CastFactChip')
credit=block_between(APP,'private struct V1143CastCreditPoster: View','private struct V1143CastCreditText')
check('Cast Explorer visible-artwork force policy defaults false', 'var forceVisiblePlaybackPublication: Bool = false' in IMG)
check('Cast Explorer profile opts into bounded must-paint policy', explorer.count('maxPixelSize: 768, publishDuringPlayback: true, forceVisiblePlaybackPublication: true') == 2)
check('Cast Explorer credits opt into bounded must-paint policy', 'maxPixelSize: 512, publishDuringPlayback: true, forceVisiblePlaybackPublication: true' in credit)
check('must-paint policy has short navigation courtesy wait', 'maxWait: 0.45' in IMG and 'forceVisiblePlaybackPublication && self.allowPublicationDuringPlayback' in IMG)
check('must-paint fallback stays playback and scene scoped', 'runtime.sceneActive' in IMG and 'runtime.playbackActive' in IMG and '!runtime.trailerActive' in IMG and '!runtime.sourceOpeningActive' in IMG)
check('opening Cast Explorer cancels stale VOD auto-hide owner', 'hideTask?.cancel()' in block_between(APP,'private func openCastExplorer','private func closeCastExplorer'))
controls=block_between(APP,'.onChange(of: controlsVisible)','        .onChange(of: isPlaying)')
check('hidden base chrome cannot cancel visible Cast Explorer artwork', 'if castExplorerMember == nil && !vodEpisodeBrowserVisible && pendingVODSwitchItem == nil' in controls)


# vBRDC123 foreground VOD artwork + cast rotation hardening
featured=block_between(APP,'struct V1111FeaturedCastPosterCard: View','struct V1108ProductionRatingsPanel: View')
check('Featured Cast compact uses foreground must-paint publication', 'maxPixelSize: 512' in featured and 'forceVisiblePlaybackPublication: true' in featured)
check('Featured Cast full poster uses foreground must-paint publication', 'maxPixelSize: 1024' in featured and featured.count('forceVisiblePlaybackPublication: true') >= 2)
check('Featured Cast rotation keeps seven-second cadence', '7_000_000_000' in featured)
check('Featured Cast rotation identity tracks actual member ids and urls', 'imageMemberRotationSignature' in featured and 'imageURL ?? ""' in featured)
check('Featured Cast retained-frame handoff remains enabled', featured.count('preservePreviousOnURLChange: true') >= 2 and 'commitDisplayedCastMember' in featured)
check('full VOD episode browser artwork uses foreground must-paint publication', 'Phase15EpisodeCard' in PHASE15 and 'maxPixelSize: 768' in PHASE15 and 'publishDuringPlayback: true' in PHASE15 and 'forceVisiblePlaybackPublication: true' in PHASE15)
check('episode browser artwork fallback ignores blank urls and checks preview', '[episode.landscapeURL, episode.previewURL, episode.posterURL]' in PHASE15 and 'clean.isEmpty ? nil : clean' in PHASE15)
hero=block_between(APP,'struct HeroEpisodePreviewCard: View','struct ManualStreamLinksRow: View')
check('detail episode cards use foreground VOD publication', 'maxPixelSize: 768' in hero and 'publishDuringPlayback: true' in hero and 'forceVisiblePlaybackPublication: true' in hero)
upnext=block_between(APP,'private var upNextEpisodeOverlay: some View','private func handleBluetoothVODMediaCommand')
check('Up Next episode artwork uses foreground VOD publication', 'maxPixelSize: 768' in upnext and 'publishDuringPlayback: true' in upnext and 'forceVisiblePlaybackPublication: true' in upnext)
check('foreground publication remains explicit opt-in', 'var forceVisiblePlaybackPublication: Bool = false' in IMG)
check('foreground must-paint still bounded by 450ms courtesy gate', 'maxWait: 0.45' in IMG and 'waitUntilPermitted(' in IMG)
check('hidden VOD chrome still preserves episode/cast foreground owners', 'if castExplorerMember == nil && !vodEpisodeBrowserVisible && pendingVODSwitchItem == nil' in controls)


# vBRDC125 UNITY Live TV golden-motion + secondary-artwork hardening
live_loader=block_between(APP,'private actor LiveTVArtworkDecodeGate','private struct LiveTVQuickGuideContainedArtworkFrame')
quick_window=block_between(APP,'private func stageLiveTVSurfaceFocusHandoff','private func scheduleQuickWindowHide')
live_tile=block_between(APP,'private func liveTile(channel: LiveTVChannel','private func suppressChannelTap')
channel_count=block_between(APP,'private func channelCount(for category: String)','private func iconForGuideCategory')
current_program=block_between(APP,'func currentProgram(for channel: LiveTVChannel','func nextProgram(for channel: LiveTVChannel')
check('Live TV ImageIO gate removes cancelled waiters immediately', 'withTaskCancellationHandler' in live_loader and 'cancelWaiter' in live_loader and 'pendingCancellationIDs' in live_loader and 'CheckedContinuation<Bool, Never>' in live_loader)
check('Live TV decoded publication uses shared event-driven frame revision', 'waitUntilVisualPublicationPermitted' in FRAME and 'waitForChange(after: observedRevision, timeout: nil)' in FRAME and 'waitUntilVisualPublicationPermitted(' in live_loader and 'for _ in 0..<10' not in live_loader)
check('Live TV artwork failure bookkeeping publishes only real state changes', 'private func markURLSuccessful' in live_loader and 'guard failedURLs.contains(url) else { return }' in live_loader and 'private func markURLFailed' in live_loader and 'guard !failedURLs.contains(url) else { return }' in live_loader)
check('Live TV playback and Quick Guide artwork decode sizes are bounded', APP.count('maxPixelSize: 768, allowDuringFullScreenPlayback: true') >= 2 and 'maxPixelSize: 512, allowDuringFullScreenPlayback: true' in APP and 'LiveTVBoundedFitArtwork' in APP)
check('Live TV current-program resolution is cached to schedule boundaries', 'CurrentProgramCacheEntry' in APP and 'currentProgramCache[channel.id]' in current_program and 'let nextBoundary = rows.compactMap(\\.startDate)' in current_program and 'validUntil = end' in current_program)
check('Live TV per-channel caches prune identities removed by provider refresh', 'channelMatchingKeyCache = channelMatchingKeyCache.filter { channelByID[$0.key] != nil }' in APP and 'currentProgramCache = currentProgramCache.filter { channelByID[$0.key] != nil }' in APP)
check('Live Controls category counts reuse provider indexes', 'liveModel.browseHDChannels().count' in channel_count and 'liveModel.browseChannels(inExactCategory: category).count' in channel_count and 'liveModel.channels.filter' not in channel_count)
check('Live Controls open-close uses one visual animation and staged focus handoff', 'quickWindowFocusHandoffActive = true' in quick_window and 'Transaction()' in quick_window and 'disablesAnimations = true' in quick_window and 'timingCurve(0.16, 1.0, 0.30, 1.0, duration: 0.28)' in quick_window and 'timingCurve(0.32, 0.0, 0.22, 1.0, duration: 0.24)' in quick_window and 'DispatchQueue.main.asyncAfter' not in quick_window)
check('Live TV selected card remains visually pinned through menu and catalog focus ownership', 'liveTVVisualFocusPinned && selectedChannelID == channel.id' in live_tile and 'stageLiveTVSurfaceFocusHandoff(from: previousTab, to: tab)' in APP and 'withTransaction(release) { liveTVVisualFocusPinned = false }' in APP)
check('Live TV card body can skip unchanged subtree recomputation', 'private struct LiveTVGridTileContent: View, Equatable' in APP and '.equatable()' in live_tile)
check('UNITY catalog motion uses golden open-close profile and focus binds after close', 'visibleDuration: 0.27' in FRAME and 'visibleDuration: 0.24' in FRAME and 'focusBind: 0.265' in FRAME and 'timingCurve(0.16, 1.0, 0.30, 1.0, duration: frameProfile.visibleDuration)' in APP and 'timingCurve(0.32, 0.0, 0.22, 1.0, duration: frameProfile.visibleDuration)' in APP)



# vBRDC125 catalog artwork identity / row-motion hardening
focused_card=block_between(APP,'struct FixedSlotFocusedCatalogCard: View','struct FixedSlotPreviewCatalogCard: View')
preview_card=block_between(APP,'struct FixedSlotPreviewCatalogCard: View','struct MovieInfoComicBubbleShape: Shape')
hero_background=block_between(APP,'private func mainArtworkBackground(itemID: String, url artworkURL: String)','private var mainArtworkSideGradient')
hero_depth=block_between(APP,'private func artworkDepthLayers(itemID: String, url artworkURL: String)','private func catalogHeroRuntimeLabel')
hero_logo=block_between(APP,'struct Artwork4HeroLogoLayer: View','private func dcFavoriteCleanToken')
catalog_rail=block_between(APP,'private func catalogRail(row: MediaRow','@ViewBuilder\n    private func nextRowTitle')
check('focused catalog artwork owner is scoped to row and media identity', '.id("catalog-focused-artwork-\\(rowID)-\\(item.id)")' in focused_card)
check('preview catalog artwork owners are scoped to row depth and media identity', '.id("catalog-preview-artwork-\\(rowID)-\\(depth)-\\(item.id)")' in preview_card)
check('catalog hero backdrop cannot retain pixels across media identities', '.id("catalog-hero-background-\\(itemID)")' in hero_background and 'preservePreviousOnURLChange: true' in hero_background)
check('catalog hero depth layer follows the incoming media identity', '.id("catalog-hero-depth-\\(itemID)")' in hero_depth and 'preservePreviousOnURLChange: true' in hero_depth)
check('catalog clearlogo retention is limited to the same media identity', '.id("catalog-hero-logo-\\(item.id)")' in hero_logo and 'preservePreviousOnURLChange: true' in hero_logo)
check('persistent catalog rail and no-peek vertical row swap remain unchanged', '.transition(.identity)' in catalog_rail and '.animation(nil, value: activeRowIndex)' in catalog_rail)


# vBRDC126 UNITY Live TV grid single-owner motion engine + presentation controls
focus_host=block_between(APP,'private struct LiveTVGridFocusMotionHost<Content: View>: View','private final class LiveTVGridInteractionRuntime')
focus_ring=block_between(APP,'private struct LiveTVGridFocusRingOverlay: View','struct GridLockedDockPoster: View')
runtime=block_between(APP,'private final class LiveTVGridInteractionRuntime: ObservableObject','private struct LiveTVGridFocusRingOverlay: View')
live_tile_126=block_between(APP,'private func liveTile(channel: LiveTVChannel, loadArtwork: Bool) -> some View','private func suppressChannelTap')
window_maintenance=block_between(APP,'private func scheduleLiveTVVirtualWindowMaintenance(focusedID: Int)','private func keepFocusedChannelInVirtualWindow')
preview_schedule=block_between(APP,'private func scheduleLiveTVGridFocusPreview(for channelID: Int)','private func liveTVGridFocusPreviewURL')
preview_warmup=block_between(APP,'private func scheduleLivePreviewWarmup(immediate: Bool = false)','private func moveGuideFocus')
settings_live_block=block_between(APP,'private var liveTVSourcesSection: some View','private func liveTextField')
check('Live TV focus transform has one dedicated compositor owner', 'LiveTVGridFocusMotionHost(' in live_tile_126 and '.scaleEffect(visualFocused ?' in focus_host and '.offset(' in focus_host)
check('Live TV expensive tile subtree explicitly rejects focus animation inheritance', 'content' in focus_host and '.transaction { transaction in' in focus_host and 'transaction.animation = nil' in focus_host)
check('Live TV focus host uses one focused shadow owner', '.shadow(' in focus_host and 'visualFocused ? 0.88 : 0.30' in focus_host)
tile_content=block_between(APP,'private struct LiveTVGridTileContent: View, Equatable','private struct LiveTVGridTileArtwork: View')
check('Live TV tile subtree no longer owns duplicate focused glow/shadow animation', 'focusPopOverlay' not in tile_content and 'tileBorder' not in tile_content and '.animation(' not in tile_content and 'baseTileBorder' in tile_content)
check('focused ring is owned by exact card overlay instead of outer transform host', 'LiveTVGridFocusRingOverlay' not in focus_host and 'if isFocused {' in tile_content and 'LiveTVGridFocusRingOverlay' in tile_content and '.allowsHitTesting(false)' in focus_ring)
check('focused ring exposes requested color palette', 'White' in APP and 'Cyan' in APP and 'Orange' in APP and 'Blue' in APP and 'Purple' in APP and 'Green' in APP and 'Red' in APP and 'Gold' in APP and 'LiveTVGridFocusRingPalette' in APP)
check('focused ring exposes classic steady pulse and breathing motion styles', 'static let names = ["Classic Glow", "Steady Ring", "Soft Pulse", "Breathing Glow"]' in APP)
check('Live TV preview duration supports 15 30 60 and Unlimited', 'static let names = ["15 Seconds", "30 Seconds", "60 Seconds", "Unlimited"]' in APP and 'case "Unlimited": return nil' in APP and 'LiveTVGridPreviewDuration.seconds(liveTVGridFocusPreviewDuration)' in preview_schedule)
check('Live TV preview dimming targets only nonpreview cards and is stronger', 'liveTVGridDimOthersDuringPreview' in live_tile_126 and 'gridFocusPreviewChannelID != channel.id' in live_tile_126 and '.opacity(visualDimmed ? 0.36 : 1.0)' in focus_host)
check('Live TV settings expose preview duration dimming ring color and ring motion', 'Live TV Preview Length:' in settings_live_block and 'Dim Grid During Preview' in settings_live_block and 'Live TV Focus Ring Color:' in settings_live_block and 'Live TV Focus Ring Motion:' in settings_live_block)
check('new Live TV presentation preferences are backed up and restored', all(key in APP for key in ['liveTVGridFocusPreviewDurationV1','liveTVGridDimOthersDuringPreviewV1','liveTVGridFocusRingColorV1','liveTVGridFocusRingMotionV1']))
check('new Live TV presentation preferences are stable-feature allowlisted', all(key in (ROOT/'Sources/StableFeatureGateManager.swift').read_text() for key in ['liveTVGridFocusPreviewDurationV1','liveTVGridDimOthersDuringPreviewV1','liveTVGridFocusRingColorV1','liveTVGridFocusRingMotionV1']))
check('new Live TV presentation preferences are cloud-backup allowlisted', all(key in (ROOT/'Sources/ReleaseCandidateSecurityManager.swift').read_text() for key in ['liveTVGridFocusPreviewDurationV1','liveTVGridDimOthersDuringPreviewV1','liveTVGridFocusRingColorV1','liveTVGridFocusRingMotionV1']))
check('nonvisual Live TV focus tasks moved out of SwiftUI State', 'LiveTVGridInteractionRuntime' in APP and 'previewArmTask' in runtime and 'windowMaintenanceTask' in runtime and '@StateObject private var gridInteractionRuntime = LiveTVGridInteractionRuntime()' in APP and '@State private var gridFocusPreviewArmTask' not in APP and '@State private var liveTVArtworkPrefetchTask' not in APP)
check('guide preview warmup generation is also nonpublishing runtime state', 'guidePreviewWarmupGeneration' in runtime and '@State private var previewWarmupToken' not in APP)
check('unused per-focus timestamp invalidation source stays removed', 'lastGridFocusChangeAt' not in APP)
check('Live TV virtual corridor maintenance is staged outside routine focus transaction', 'maintenanceBuffer = 20' in window_maintenance and 'emergencyBuffer = 8' in window_maintenance and '125_000_000' in window_maintenance and 'transaction.disablesAnimations = true' in window_maintenance)
check('rapid Live TV focus moves coalesce virtual-window maintenance to latest card', 'windowMaintenanceTask?.cancel()' in window_maintenance and 'selectedChannelID == focusedID' in window_maintenance and 'tileFocus == focusedID' in window_maintenance)
check('grid focus no longer performs duplicate preview cancellation before rearm', 'guard let value, !quickWindowVisible else {' in APP and 'scheduleLiveTVGridFocusPreview(for: value)' in APP and 'cancelLiveTVGridFocusPreview()\n                    guard let value, !quickWindowVisible' not in APP)
check('grid selection bookkeeping is animation-free after native focus move', 'var selectionTransaction = Transaction()' in APP and 'selectionTransaction.disablesAnimations = true' in APP and 'withTransaction(selectionTransaction) { selectedChannelID = value }' in APP)
check('guide warmup does not run on ordinary grid selected-channel changes', 'if showGuide { scheduleLivePreviewWarmup() }' in APP and 'keepFocusedChannelInVirtualWindow()' in preview_warmup)
check('valid guide focus edge no longer schedules preview warmup twice', 'selectedChannelID = value\n                scheduleLivePreviewWarmup(immediate: false)' not in APP)


# vBRDC129 top-menu/catalog focus-flow hardening on the vBRDC128 native Live TV base
top_menu=block_between(APP,'struct TopMenuBar: View','struct GlobalSearchScreen: View')
catalog_close=block_between(APP,'private func closeOverlay()','struct CatalogHeroMetadataRibbon: View')
catalog_focus_restore=block_between(APP,'private func scheduleQuickPanelFocusRestore(reason: String)','@discardableResult')
surface_handoff=block_between(APP,'private func scheduleUnitySurfaceHandoff(from oldTab: AppTab','private func scheduleCatalogInteractionRecovery(reason: String)')
live_surface_handoff=block_between(APP,'private func stageLiveTVSurfaceFocusHandoff(from oldTab: AppTab','private func openQuickWindow')
check('v127 selected-tab focus owner architecture stays rolled back', 'topMenuSelectedTabFocusOwner' not in APP and 'topMenuSelectedTabFocusOwner' not in CAT)
check('Live TV grid remains natively focusable without selected-tab predicate', '.focusable(!quickWindowVisible && !quickWindowFocusHandoffActive && channelActionChannelID == nil)' in live_tile_126 and '.focusable(store.selectedTab == .live && !quickWindowVisible' not in live_tile_126)
check('Live TV category rail native focusability stays restored', '.focusable(!quickWindowVisible)' in APP and '.focusable(store.selectedTab == .live && !quickWindowVisible)' not in APP)
check('top-menu hold stays nonpublishing and never mutates focus graph', 'var topMenuSelectionHoldTab: AppTab? = nil' in CAT and '@Published var topMenuSelectionHoldTab' not in CAT)
check('catalog top-menu selection clears hold and enters rows immediately', 'UnitySurfaceSystem.catalogBranchActive(for: tab)' in top_menu and 'store.topMenuSelectionHoldTab = nil' in top_menu and 'store.catalogRowsPresented = true' in top_menu and 'focusedTab = nil' in top_menu)
check('reselecting already-active catalog explicitly re-enters rows', 'let wasAlreadySelected = store.selectedTab == tab' in top_menu and 'if wasAlreadySelected {' in top_menu and 'store.contentFocusToken &+= 1' in top_menu)
check('Live TV top-menu selection remains on Live TV until Down', 'store.topMenuSelectionHoldTab = tab == .live ? .live : nil' in top_menu and 'focusedTab = .live' in top_menu)
check('top-menu Down is universal Live TV return independent of highlighted tab', 'Top menu Down → Live TV' in top_menu and 'store.selectedTab = .live' in top_menu and 'let destination = store.selectedTab' not in top_menu)
check('top-menu Down never reopens highlighted catalog or sends catalog focus token', 'store.catalogRowsPresented = false' in top_menu and 'store.contentFocusToken &+= 1' not in top_menu[top_menu.index('.onMoveCommand'):])
check('top-menu Down uses explicit native Live TV entry token', 'liveTVMenuFocusEntryToken' in CAT and 'store.liveTVMenuFocusEntryToken &+= 1' in top_menu and '.onChange(of: store.liveTVMenuFocusEntryToken)' in APP)
check('non-Live top-menu Down yields one render turn before native grid focus request', 'if store.selectedTab != .live {' in top_menu and 'store.selectedTab = .live' in top_menu and 'await Task.yield()' in top_menu and 'guard store.selectedTab == .live' in top_menu)
check('catalog Back no longer changes selected tab to Live TV', 'store.selectedTab = UnitySurfaceSystem.backDestination' not in catalog_close and re.search(r'store\.selectedTab\s*=\s*[^=]', catalog_close) is None)
check('catalog Back keeps selected category and requests presentation dismissal', 'store.topMenuSelectionHoldTab = store.selectedTab' in catalog_close and 'store.catalogRowsPresented = false' in catalog_close and 'focusedRow = nil' not in catalog_close and 'store.menuFocusToken &+= 1' not in catalog_close)
check('catalog Back cancels delayed row focus owners without flattening visual pin', 'quickPanelFocusRecoveryTask?.cancel()' in catalog_close and 'rowEntryFocusTask?.cancel()' in catalog_close and 'surfaceHandoffVisualFocusPinned = false' not in catalog_close)
check('catalog recovery respects hidden presentation and top-menu hold after Back', '!store.catalogRowsPresented' in catalog_focus_restore and 'store.topMenuSelectionHoldTab == store.selectedTab' in catalog_focus_restore and 'quickPanelFocusRecoveryTask?.cancel()' in catalog_focus_restore)
check('root handoff auto-focuses catalog when no menu hold is active', 'let topMenuSelectionHeld = store.topMenuSelectionHoldTab == newTab' in surface_handoff and 'if !topMenuSelectionHeld' in surface_handoff and 'store.contentFocusToken &+= 1' in surface_handoff)
check('leaving Live TV always clears hidden real FocusState', 'if newTab != .live {' in live_surface_handoff and 'tileFocus = nil' in live_surface_handoff and 'categoryFocus = nil' in live_surface_handoff and 'guideFocus = nil' in live_surface_handoff)
check('Live TV top-menu selection cannot auto-bind grid before Down', 'if store.topMenuSelectionHoldTab != .live' in live_surface_handoff)
check('ring remains owned by exact card overlay instead of outer transform host', 'LiveTVGridFocusRingOverlay' not in focus_host and 'if isFocused {' in tile_content and 'LiveTVGridFocusRingOverlay' in tile_content and '.allowsHitTesting(false)' in focus_ring)
check('ring still uses exact same 16 point continuous card shape', 'RoundedRectangle(cornerRadius: 16, style: .continuous)' in focus_ring and '.clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))' in tile_content)
check('ring never changes silhouette with scale animation', '.scaleEffect(' not in focus_ring and 'TimelineView(.animation' in focus_ring and 'pulsePhase' in focus_ring)
check('preview dim remains stronger while focused preview plays', '.opacity(visualDimmed ? 0.36 : 1.0)' in focus_host)


# vBRDC131 catalog presentation dismissal hardening
catalog_overlay=block_between(APP,'struct GridOSCatalogOverlay: View','struct CatalogHeroMetadataRibbon: View')
catalog_menu_visibility=block_between(APP,'private func synchronizeUnityCatalogMenuPresentation(presented: Bool)','private func scheduleUnitySurfaceHandoff(from oldTab: AppTab')
root_catalog_state=block_between(APP,'private var catalogQuickPanelActive: Bool','private var globalTickerOverlaysAllowed: Bool')
check('catalog row presentation is explicit published state separate from selected tab', '@Published var catalogRowsPresented: Bool = false' in CAT)
check('catalog presentation lookup requires explicit rows-presented state', 'store.catalogRowsPresented' in root_catalog_state and 'UnitySurfaceSystem.catalogBranchActive(for: store.selectedTab)' in root_catalog_state)
check('Back closes catalog presentation without changing selected tab', 'store.catalogRowsPresented = false' in catalog_close and re.search(r'store\.selectedTab\s*=\s*[^=]', catalog_close) is None)
check('Back no longer clears row FocusState or disables rail to fake an exit', 'focusedRow = nil' not in catalog_close and 'catalogRowsYieldingToTopMenu' not in catalog_overlay and 'catalogExitToTopMenuTask' not in catalog_overlay)
check('Back keeps focused catalog geometry pinned through reverse motion', 'surfaceHandoffVisualFocusPinned = !rows.isEmpty' in catalog_overlay and 'focusedRow = min(max(activeRowIndex, 0), rows.count - 1)' in catalog_overlay)
check('catalog rail remains focus-capable during visible close so card does not flatten', 'allowsFocus: true' in catalog_overlay)
check('same UNITY compositor scalar owns catalog menu close and reopen', 'unityCatalogBranchProgress = 1' in catalog_menu_visibility and 'unityCatalogBranchProgress = 0' in catalog_menu_visibility and 'timingCurve(0.16, 1.0, 0.30, 1.0' in catalog_menu_visibility and 'timingCurve(0.32, 0.0, 0.22, 1.0' in catalog_menu_visibility)
check('top menu receives focus only after catalog close settles invisible', 'try? await Task.sleep(nanoseconds: UnityFrameRuntime.nanoseconds(frameProfile.branchSettle))' in catalog_menu_visibility and 'unityPresentedCatalogTab = nil' in catalog_menu_visibility and 'store.menuFocusToken &+= 1' in catalog_menu_visibility)
check('catalog top-menu click explicitly presents rows even when same tab remains selected', 'store.catalogRowsPresented = true' in top_menu and 'let wasAlreadySelected = store.selectedTab == tab' in top_menu and 'store.contentFocusToken &+= 1' in top_menu)
check('Down from selected catalog top-menu item returns to Live TV instead of reopening rows', 'store.catalogRowsPresented = false' in top_menu and 'store.selectedTab = .live' in top_menu and 'store.liveTVMenuFocusEntryToken &+= 1' in top_menu)
overlay_window=APP[APP.index('GridOSCatalogOverlay(')-800:APP.index('GridOSCatalogOverlay(')+1800]
check('root catalog overlay hit testing follows visible branch presentation not selected-tab alone', '!catalogSurfacePresented' in overlay_window and 'catalogSurfacePresented && UnitySurfaceSystem.catalogBranchActive(for: store.selectedTab)' in overlay_window)
menu_owner_window=APP[APP.index('let catalogQuickPanelOwnsFocus'):APP.index('TopMenuBar()', APP.index('let catalogQuickPanelOwnsFocus'))]
check('hidden selected catalog does not make top menu yield to catalog focus', 'store.catalogRowsPresented && UnitySurfaceSystem.catalogBranchActive(for: store.selectedTab)' in menu_owner_window)
restore_window=APP[APP.index('private func restoreQuickPanelFocusIfPossible'):APP.index('private func scheduleDetailHeroAnchorRelease')]
check('catalog focus recovery cannot reassert rows while presentation is hidden', '!store.catalogRowsPresented' in catalog_focus_restore and 'store.catalogRowsPresented' in restore_window)
check('corrected Live TV ring architecture remains untouched', 'RoundedRectangle(cornerRadius: 16, style: .continuous)' in focus_ring and '.scaleEffect(' not in focus_ring)


# vBRDC133 universal top-menu Down -> Live TV recovery
move_block=top_menu[top_menu.index('.onMoveCommand'):top_menu.index('.onChange(of: store.menuFocusToken)')]
check('vBRDC133 Down routing contains no per-tab destination switch', 'destination' not in move_block and 'UnitySurfaceSystem.catalogBranchActive' not in move_block and 'store.contentFocusToken' not in move_block)
check('vBRDC133 Down clears transient catalog/menu presentation ownership', 'store.topMenuSelectionHoldTab = nil' in move_block and 'store.catalogRowsPresented = false' in move_block and 'store.topMenuFocusLocked = false' in move_block and 'store.liveQuickPanelOpen = false' in move_block)
check('vBRDC133 Down exits top menu focus before restoring Live TV tile focus', 'focusedTab = nil' in move_block and 'searchFocused = false' in move_block and 'store.liveTVMenuFocusEntryToken &+= 1' in move_block)
check('vBRDC133 category Select behavior still opens catalog rows', 'store.catalogRowsPresented = true' in top_menu[:top_menu.index('.onMoveCommand')] and 'store.selectedTab = tab' in top_menu[:top_menu.index('.onMoveCommand')])
check('vBRDC133 catalog Back still dismisses rows without tab rewrite', 'store.catalogRowsPresented = false' in catalog_close and re.search(r'store\.selectedTab\s*=\s*[^=]', catalog_close) is None)


# vBRDC133 catalog-to-Live zero-flash handoff
branch_handoff=block_between(APP,'private func synchronizeUnityCatalogBranchPresentation(from oldTab: AppTab, to newTab: AppTab)','private func synchronizeUnityCatalogMenuPresentation(presented: Bool)')
check('vBRDC133 hidden catalog branch is cleared instead of revived', 'if unityCatalogBranchProgress <= 0.001 {' in branch_handoff and 'unityPresentedCatalogTab = nil' in branch_handoff and 'unityCatalogBranchTransitionActive = false' in branch_handoff and 'return' in branch_handoff)
check('vBRDC133 removes forced hidden catalog progress 0 to 1 revival', 'if unityCatalogBranchProgress <= 0.001 { unityCatalogBranchProgress = 1 }' not in branch_handoff)
check('vBRDC133 visible catalog still reverses smoothly from current progress', 'if unityPresentedCatalogTab == nil { unityPresentedCatalogTab = oldTab }' in branch_handoff and 'unityCatalogBranchProgress = 0' in branch_handoff and 'timingCurve(0.32, 0.0, 0.22, 1.0' in branch_handoff)
check('vBRDC133 universal top-menu Down to Live TV routing remains intact', 'Top menu Down → Live TV' in top_menu and 'store.selectedTab = .live' in top_menu and 'store.liveTVMenuFocusEntryToken &+= 1' in top_menu)


# vBRDC134 app-wide runtime quiescence hardening
runtime_block=block_between(APP,'private final class RootAsyncTaskRuntime: ObservableObject','struct RootView: View')
check('all nonvisual Task handles removed from SwiftUI State', re.search(r'@State\s+private\s+var\s+\w+Task\s*:', APP) is None)
check('runtime ownership covers root catalog Live TV and VOD hot surfaces', all(name in runtime_block for name in ['RootAsyncTaskRuntime','CatalogOverlayAsyncTaskRuntime','CatalogRailAsyncTaskRuntime','LiveTVScreenAsyncTaskRuntime','VODPlayerAsyncTaskRuntime']))
check('runtime ownership covers search details trailers sports and favorites', all(name in runtime_block for name in ['SearchAsyncTaskRuntime','MediaInfoAsyncTaskRuntime','DetailPageAsyncTaskRuntime','PopupMetadataAsyncTaskRuntime','TrailerAsyncTaskRuntime','SportsAsyncTaskRuntime','FavoritesAsyncTaskRuntime']))
check('nonvisual runtime owners publish no view-change signals', '@Published' not in runtime_block)
check('Root task handles proxy into retained nonpublishing runtime', '@StateObject private var rootAsyncRuntime = RootAsyncTaskRuntime()' in APP and 'rootAsyncRuntime.unityCatalogTransitionTask' in APP and 'rootAsyncRuntime.catalogCompletenessWatchdogTask' in APP)
check('catalog overlay and rail task handles no longer invalidate row trees', '@StateObject private var catalogAsyncRuntime = CatalogOverlayAsyncTaskRuntime()' in APP and 'catalogAsyncRuntime.focusedCardPreviewTask' in APP and '@StateObject private var catalogRailAsyncRuntime = CatalogRailAsyncTaskRuntime()' in APP)
check('Live TV lifecycle tasks use nonpublishing runtime owner', '@StateObject private var liveTVAsyncRuntime = LiveTVScreenAsyncTaskRuntime()' in APP and 'liveTVAsyncRuntime.liveRefreshTask' in APP and 'liveTVAsyncRuntime.liveTVScheduleBoundaryTask' in APP)
check('VOD task handles use nonpublishing runtime owner', '@StateObject private var vodAsyncRuntime = VODPlayerAsyncTaskRuntime()' in APP and 'vodAsyncRuntime.upNextWatchdogTask' in APP and 'vodAsyncRuntime.firstFrameProbeTask' in APP and 'vodAsyncRuntime.alternateAudioBridgeTask' in APP)
check('VOD AV observer handles are no longer SwiftUI State', '@State private var timeObserver' not in APP and '@State private var statusObserver' not in APP and '@State private var endObserver' not in APP and 'vodAsyncRuntime.timeObserver' in APP and 'vodAsyncRuntime.statusObserver' in APP and 'vodAsyncRuntime.endObserver' in APP)
check('VOD hidden heavy chrome remains unmounted', 'if controlsVisible || activePanel != nil || isScrubbingTimeline || isSeekingInPlayer {' in APP and 'The lightweight player canvas already owns hidden-state focus' in APP)
check('PlaybackKit bridge still suppresses hidden overlay tick publication', 'guard overlayVisible else { return }' in PBK and 'snapshots.setPublishingEnabled(visible)' in PBK)
check('VOD exclusive entry still cancels nonessential registered app work', 'VODExclusiveWorkRegistry.cancelAll()' in VODGATE and 'guard !VODExclusivePlaybackGate.isActive else' in VODGATE)
check('MediaFlow heartbeat is still cancelled during playback', 'if active {' in MFP and 'heartbeatTask?.cancel()' in MFP and 'guard appIsActive, !playbackIsActive, phase == .connected' in MFP)
check('finite top-bar ticker no longer leaves an idle Timer heartbeat', 'this ticker is a finite presentation, not a permanent heartbeat' in APP and '.task(id: items.joined(separator: "|"))' in APP and 'Timer.publish(every: 2.6' not in APP)
check('unused one-second VOD diagnostics pulse scaffold removed', 'startDiagnosticsPulse' not in APP and 'diagnosticsTick' not in APP)
check('Live TV nonpublishing grid interaction runtime remains retained', '@StateObject private var gridInteractionRuntime = LiveTVGridInteractionRuntime()' in APP and 'var previewArmTask: Task<Void, Never>?' in APP and 'var previewStopTask: Task<Void, Never>?' in APP)
check('existing Live TV covered compaction remains active', 'liveTVCoveredCompactionTask' in APP and 'coveredRenderedChannelLimit' in APP and 'renderedChannelLimit = coveredRenderedChannelLimit' in APP)
check('existing VOD player clock quiet mode remains active', 'hiddenSteadyPlayback' in APP and 'hiddenSteadyPlayback ? 5.0 : 1.0' in APP)


# vBRDC135 VOD frame pacing, invisible Bluetooth ownership and hot-surface decode/runtime hardening
check('Bluetooth VOD transport setting is fully removed from user-facing state', 'bluetoothVODPlayPauseToggle' not in APP and '@AppStorage("bluetoothVODPlayPauseEnabledV1")' not in APP and 'Bluetooth Media Controls' not in APP)
check('retired Bluetooth preference cannot disable active VOD transport ownership', 'BluetoothVODMediaControlPreferences' not in APP and 'UserDefaults.standard.removeObject(forKey: "bluetoothVODPlayPauseEnabledV1")' in APP)
check('Bluetooth media commands remain active-session scoped and invisible', 'let available = activeSessionID != nil' in APP and 'guard let sessionID else' in APP and 'debridBluetoothVODMediaCommand' in APP)
check('authoritative VOD decoder clock refreshes Bluetooth Now Playing without a SwiftUI timer', 'BluetoothVODMediaButtonCoordinator.shared.updateNowPlaying(' in APP and 'onPlaybackTimeUpdate:' in APP)
check('retired Bluetooth preference is no longer backed up/restored', 'bluetoothVODPlayPauseEnabledV1' not in SECURITY)
check('full-screen tvOS VOD uses physical-display-paced rendering lane', 'KSOptions.preferredFrame = !isVODStylePlayback' in PBKS)
check('4K decoded queue is bounded below donor 24-frame footprint', 'frameCount = fps >= 45 ? 18 : 16' in PBKS)
check('Live TV grid artwork decode bucket reduced to display-sized 640', 'LiveTVBoundedArtworkLoader.prefetch(urls, maxPixelSize: 640)' in APP and 'artworkLoader.load(candidate.url, maxPixelSize: 640, preserveCurrentImage: true)' in APP)
focused_card=block_between(APP,'struct FixedSlotFocusedCatalogCard: View','struct FixedSlotPreviewCatalogCard: View')
preview_card=block_between(APP,'struct FixedSlotPreviewCatalogCard: View','struct MovieInfoComicBubbleShape: Shape')
check('catalog focused card decode bucket reduced without changing geometry', 'maxPixelSize: 1024' in focused_card and 'maxPixelSize: 1280' not in focused_card)
check('catalog trailing poster decode bucket reduced to 384', 'maxPixelSize: 384' in preview_card and 'maxPixelSize: 640' not in preview_card)
check('normal resume checkpoint mutation is utility-queue owned', 'writerQueue.async(execute: applyAndWrite)' in RESUME and 'applyProgressMutation' in RESUME)
check('durable resume checkpoint drains queue before newest mutation/write', 'writerQueue.sync(execute: applyAndWrite)' in RESUME and 'includeLegacyCleanup: synchronously' in RESUME)
check('resume flush snapshots only after pending checkpoint queue drains', 'snapshot only after the writer queue has drained older async' in RESUME and 'writerQueue.sync {' in RESUME)


# vBRDC136 focused catalog preview ownership across connected Media Information
preview_allowed=block_between(APP,'private func focusedCardPreviewPresentationAllowed(for item: MediaItem) -> Bool','private func scheduleFocusedCardPreview(reason: String)')
open_selected=block_between(APP,'private func openSelected()','private func removeSelectedSportsChannel')
preview_scheduler=block_between(APP,'private func scheduleFocusedCardPreview(reason: String)','private func finishFocusedCardPreview(key: String)')
check('catalog card captures durable originating identity before opening Media Information', 'store.quickPanelRestoreIdentityItem = selectedItem' in open_selected and 'store.openDetail(selectedItem, pushCurrent: false, origin: presentationOrigin)' in open_selected)
check('Media Information preview ownership uses captured origin instead of ambient focusedRow', 'store.quickPanelRestoreIdentityItem' in preview_allowed and 'store.detailPresentationAnchorItem' in preview_allowed and 'let rowItem = rowFocusedBackdropItem' not in preview_allowed)
check('same-id hydrated detail remains valid preview owner even if strong metadata enriches', 'detail.id == originItem.id' in preview_allowed and 'item.id == originItem.id' in preview_allowed)
check('canonical identity remains accepted for same media across provider hydration', 'store.catalogItemsShareCanonicalIdentity(detail, originItem)' in preview_allowed and 'store.catalogItemsShareCanonicalIdentity(item, originItem)' in preview_allowed)
check('active same-card preview still returns before destructive replacement path', preview_scheduler.index('if focusedCardPreviewKey == requestedKey') < preview_scheduler.index('stopFocusedCardPreview()\n        guard focusedCardPreviewsEnabled'))
check('preview teardown rules for playback search scene and memory warning remain present', APP.count('stopFocusedCardPreview()') >= 10 and '.debridTrailerExclusivePlaybackDidBegin' in APP and 'UIApplication.didReceiveMemoryWarningNotification' in APP)


# vBRDC137 Live TV cold-launch guide/artwork generation validation
live_model=block_between(APP,'final class LiveTVSourceModel: ObservableObject','struct LiveTVScreen: View')
refresh_if_needed=block_between(APP,'func refreshIfNeeded() async','func forceRefreshGuide() async')
cached_load=block_between(APP,'func loadCachedOrDemo()','private func loadPersistedGuidePrograms')
cold_hydration=block_between(APP,'private func scheduleLiveTVColdStartHydrationIfNeeded()','private func startLiveTVRefreshIfActive')
active_refresh=block_between(APP,'private func startLiveTVRefreshIfActive(reason: String)','private var liveWallpaperOwnsRenderBudget')
forced_art=block_between(APP,'private func beginForcedLiveTVArtworkBootstrap(reason: String)','private func scheduleGuideHintAutoHide')
check('disk-restored guide is marked for fresh process validation', 'coldLaunchPersistedGuideNeedsValidation = true' in cached_load and 'hasLoadedThisAppSession = false' in cached_load)
check('normal three-hour TTL cannot suppress cold-launch validation', 'if coldLaunchPersistedGuideNeedsValidation {' in refresh_if_needed and refresh_if_needed.index('if coldLaunchPersistedGuideNeedsValidation {') < refresh_if_needed.index('guard !hasLoadedThisAppSession || shouldRefreshNow'))
check('cold-launch validation performs fresh configured-source refresh', 'await refreshFromConfiguredSources()' in refresh_if_needed and 'hasLoadedThisAppSession = false' in refresh_if_needed)
check('failed startup validation remains armed for a later Live TV entry', 'if hasLoadedThisAppSession {' in refresh_if_needed and 'coldLaunchPersistedGuideNeedsValidation = false' in refresh_if_needed)
check('hidden persistent Live TV may prevalidate disk guide once before entry', 'if coldLaunchPersistedGuideNeedsValidation { return true }' in live_model)
check('cold-start guide completion directly re-arms mounted artwork owners', 'LiveTVBoundedArtworkLoader.resumeRetainedRequests()' in cold_hydration)
check('interactive guide publication directly re-arms mounted artwork owners', 'LiveTVBoundedArtworkLoader.resumeRetainedRequests()' in active_refresh and 'liveTVArtworkRefreshToken &+= 1' in active_refresh)
check('forced artwork bootstrap reinforces blank retained requests without scroll', forced_art.count('LiveTVBoundedArtworkLoader.resumeRetainedRequests()') >= 3 and forced_art.count('liveTVArtworkRefreshToken &+= 1') >= 3)


# vBRDC138 Bluetooth VOD session-lifetime hardening
start_playback=block_between(CAT,'func startPlayback(item: MediaItem','/// Phase 0 entry point')
close_start=CAT.index('func closePlayer(expectedPresentationID')
close_player=CAT[close_start:close_start+5000]
player_lifecycle=block_between(APP,'private var playerLifecycleTree: some View','private var playerInputTree: some View')
bluetooth_handler=block_between(APP,'private func handleBluetoothVODMediaCommand','private var playerVisualTree: some View')
check('Bluetooth coordinator is module-visible for authoritative store ownership', 'final class BluetoothVODMediaButtonCoordinator' in APP and 'private final class BluetoothVODMediaButtonCoordinator' not in APP)
check('VOD start claims Bluetooth owner from authoritative CatalogStore session', 'BluetoothVODMediaButtonCoordinator.shared.claimVODSession(' in start_playback and 'nextPresentationID' in start_playback)
check('VOD replacement claims new Bluetooth UUID without SwiftUI disappearance gap', 'let previousPresentationID = playbackPresentationID' in start_playback and 'let nextPresentationID = UUID()' in start_playback and 'playbackPresentationID = nextPresentationID' in start_playback)
check('Live TV start releases prior VOD Bluetooth owner', 'if item.type.lowercased() == "live"' in start_playback and 'releaseVODSession(previousPresentationID)' in start_playback)
check('authoritative player close releases Bluetooth owner', 'BluetoothVODMediaButtonCoordinator.shared.releaseVODSession(playbackPresentationID)' in close_player)
check('SwiftUI VOD onDisappear no longer tears down Bluetooth owner', 'releaseVODSession(playbackPresentationID)' not in player_lifecycle)
check('external Bluetooth commands bypass generic 440ms playerAction debounce', 'playerAction { togglePlay() }' not in bluetooth_handler and bluetooth_handler.count('togglePlay()') >= 3)
check('external Bluetooth commands retain VOD modal ownership guards', 'castExplorerMember == nil' in bluetooth_handler and '!vodEpisodeBrowserVisible' in bluetooth_handler and 'pendingVODSwitchItem == nil' in bluetooth_handler)
check('existing 180ms external command duplicate suppression remains', '(now - lastSwiftUIPlayPauseAt) < 0.18' in APP and '(now - lastExternalCommandAt) < 0.18' in APP)

passed=sum(ok for _,ok in checks)
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
print(f'\n{passed}/{len(checks)} checks passed')
if passed != len(checks): sys.exit(1)
