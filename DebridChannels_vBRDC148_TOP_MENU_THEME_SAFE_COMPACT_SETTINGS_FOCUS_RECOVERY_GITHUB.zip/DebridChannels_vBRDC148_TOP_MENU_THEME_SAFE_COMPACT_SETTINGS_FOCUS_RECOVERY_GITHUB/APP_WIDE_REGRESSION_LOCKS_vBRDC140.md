# App-Wide Regression Locks — vBRDC140

All vBRDC139 cumulative locks remain active. vBRDC140 adds the following permanent Live TV artwork/bootstrap contracts:

- The same Live TV URL + decode bucket must be idempotent while its request is already in flight; reinforcement tokens may not cancel/restart it.
- Artwork request handles are generation-owned so an older cancelled task cannot clear a newer task handle.
- A successful decoded Live TV bitmap must be inserted into the bounded cache before visual-publication deferral.
- The first real bitmap for an otherwise generated/blank card must not be starved by noncritical navigation publication gating.
- Channel-logo first paint remains bounded to 384 px and may publish immediately; program/Gracenote artwork remains bounded to 640 px.
- The actual Live TV grid mount must own a bootstrap generation so startup readiness cannot depend on parent-before-child mount timing.
- Initial visible-corridor prefetch includes channel logos and program artwork, matching the useful v987 ownership behavior without restoring v987's old image/UI implementation.
- Logo and program prefetch buckets share one retained cancellation set; one bucket may not cancel the other.
- Home/Movies/TV Shows startup must not invoke the hidden Live TV cold-hydration provider task.
- Existing vBRDC139 focus quiescence remains: hidden Live TV cannot briefly focus/highlight its first card underneath catalog presentation.
- No visible Bluetooth toggle, VOD frame-pacing regression, catalog-preview regression, navigation regression, or Live TV focus-ring regression is permitted.

Automated contract: `validation_vBRDC140/test_vBRDC140_contract.py`.
