# App-Wide Regression Locks — vBRDC139

This file carries forward the vBRDC137/vBRDC138 history and adds the vBRDC139 locks below.

New vBRDC137 locks cover:

- A disk-restored Live TV guide is marked for fresh process validation.
- The normal three-hour TTL cannot suppress that cold-launch validation.
- Cold-launch validation executes a fresh configured-source refresh.
- Failed startup validation remains armed for a later Live TV entry.
- The hidden persistent Live TV root may prevalidate the disk guide once before the user enters Live TV.
- Cold-start guide completion directly re-arms already-mounted Live TV artwork owners.
- Interactive guide publication directly re-arms mounted artwork before publishing the artwork refresh generation.
- Forced artwork bootstrap reinforces blank retained requests without requiring a grid scroll.

All vBRDC136 cumulative locks are retained in `validation_vBRDC137/test_vBRDC137_contract.py`.

## vBRDC138 additive lock — Bluetooth VOD session lifetime

- Bluetooth/headset VOD media control remains invisible: no Settings toggle and no playback-panel toggle.
- `CatalogStore` playback UUID is the authoritative claim/release lifetime for Bluetooth/Now Playing ownership.
- SwiftUI VOD `onDisappear` must never release Bluetooth ownership by itself.
- VOD-to-VOD replacement must claim the new UUID without an ownership gap.
- Live TV must never claim the VOD Bluetooth bridge and must release any previous VOD UUID.
- External Bluetooth Play/Pause must not pass through the generic 440 ms UI action throttle; the existing 180 ms duplicate-event protection remains authoritative.
- Cast Explorer, Episode Browser, and pending episode-switch modal guards remain authoritative for external media commands.

# App-Wide Regression Locks — vBRDC139

New vBRDC139 locks:

- Live TV channel identity is visible immediately while Gracenote/program artwork resolves.
- Channel logo is the first bounded remote fallback; successful Gracenote artwork upgrades without clearing the logo first.
- Failed mounted artwork owners advance the fallback ladder without a LazyVGrid remount/scroll.
- Scene activation re-arms retained mounted artwork only while Live TV owns the active surface, without adding a repeating poll or waking hidden catalog-covered decoders.
- A complete persisted guide never performs hidden provider/Gracenote validation under Home/Movies/Shows.
- Cold persisted-guide validation remains armed and is consumed by the normal active Live TV refresh path.
- Persistent Live TV root mount does not assign real tile/category focus while another surface owns the app.
- Entering a catalog clears Live TV real + visual focus immediately, so no focused card is rendered behind catalog rows.
- Native Live TV card focusability remains unchanged; the rejected vBRDC127 selected-tab focusability restriction is not restored.
