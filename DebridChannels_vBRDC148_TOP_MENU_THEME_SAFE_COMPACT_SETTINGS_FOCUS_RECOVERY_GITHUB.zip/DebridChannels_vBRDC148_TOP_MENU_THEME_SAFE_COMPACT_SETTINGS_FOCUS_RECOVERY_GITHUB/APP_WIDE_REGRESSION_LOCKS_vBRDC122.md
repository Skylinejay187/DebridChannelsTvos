# vBRDC122 Regression Lock Addendum

Future builds must preserve all prior locks plus these Cast Explorer rules:

- Cast Explorer profile/fallback portraits remain bounded to 768 px and use `publishDuringPlayback: true` plus `forceVisiblePlaybackPublication: true`.
- Cast Explorer credit posters remain bounded to 512 px and use the same visible-playback publication policy.
- The visible-playback must-paint fallback stays narrowly playback/scene scoped and must not become a global bypass for catalog, wallpaper, Live TV, Sports, Favorites, or ordinary background artwork.
- Base VOD chrome cleanup must not cancel shared artwork while Cast Explorer, Episode Browser, or a pending VOD switch surface is still visible.
- Opening Cast Explorer must retire stale root VOD auto-hide ownership.
- `CastExplorerService.swift` remains unchanged unless a separate data-service bug is physically demonstrated.
