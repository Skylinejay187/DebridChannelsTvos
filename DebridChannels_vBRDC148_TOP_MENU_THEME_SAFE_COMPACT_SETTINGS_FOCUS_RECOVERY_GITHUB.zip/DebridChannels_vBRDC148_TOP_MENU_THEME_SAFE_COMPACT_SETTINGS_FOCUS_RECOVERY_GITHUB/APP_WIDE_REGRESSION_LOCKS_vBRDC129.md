# vBRDC129 App-Wide Regression Locks

vBRDC129 adds the following release invariants on top of the complete prior contract:

1. vBRDC127's selected-tab focus-owner architecture remains absent.
2. Live TV cards/category rail remain natively focusable; no selected-tab predicate is added to their `.focusable` conditions.
3. `topMenuSelectionHoldTab` remains non-publishing and may not alter the tvOS focus graph.
4. Home/Movies/TV Shows top-menu selection clears the menu hold and enters catalog content normally.
5. Re-selecting the already-active catalog tab explicitly requests content focus.
6. Live TV top-menu selection remains on the Live TV button until Down.
7. Down emits exactly one destination focus token; Live TV Down does not also wake the persistent catalog rail.
8. Catalog Back does not mutate `selectedTab` to `.live`.
9. Catalog Back keeps the current category selected, cancels delayed row focus owners, clears real row FocusState, and moves focus to the selected top-menu item.
10. Catalog lifecycle/provider recovery cannot reclaim row focus while the selected top-menu hold is active.
11. Root catalog entry auto-focus remains available whenever no top-menu hold is active.
12. Leaving Live TV for any non-Live surface clears hidden real Live TV FocusState while retaining UNITY's temporary visual focus pin.
13. Live TV cannot bind its grid before the explicit Down entry when its top-menu hold is active.
14. The configurable Live TV focus ring remains card-owned and uses the same 16-point continuous shape as the card clip.
15. Ring pulse/breathing effects may change halo intensity only; they may not scale/deform the ring silhouette.
16. Live TV preview dimming remains 0.36 for non-preview cards.

The cumulative executable contract passes **167/167** checks.
