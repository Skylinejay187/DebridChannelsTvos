# vBRDC142 Regression Locks

This build is intentionally narrow. Preserve every vBRDC141 behavior except the movie/show playback-return artwork remount issue.

Locked behavior:
- No UI/layout/focus-ring/top-menu/catalog visual changes.
- No provider, MediaFlow, Sports, Cast Explorer, resume, Bluetooth VOD, source-resolution, or playback logic changes.
- No change to vBRDC141 cache-first Live TV refresh semantics or top-right loading spinner ownership.
- No change to Live TV playback focus snapshot/restore behavior.
- No background provider/XMLTV refresh introduced under Movies/Shows.
- Only one bounded post-VOD artwork rehydration generation may be consumed by the newly mounted Live TV root.
- Channel identity remains the vBRDC141 native `AsyncImage` fallback; Gracenote/program art remains bounded at 640 px.
