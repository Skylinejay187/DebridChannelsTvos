# Debrid Channels vBRDC143 — Live TV Broadcast Deck Refresh

Release: vBRDC143  
Marketing: 1.0.846  
Apple build: 846

## Source of truth

Built only from the user-supplied packaged vBRDC142 `POST_VOD_LIVE_TV_ARTWORK_REHYDRATION` ZIP. The vBRDC142 post-movie/show Live TV Gracenote/channel-artwork recovery remains intact.

## Scope

This build refreshes only the main Live TV grid presentation, its page navigation, Guide entry/exit routing, and the hot focus/scroll path that made repeated UP/DOWN movement feel heavy. Movies, TV Shows, Sports, Favorites, VOD playback, provider loading, XMLTV/Gracenote parsing, MediaFlow routing, and catalog presentation are not redesigned.

## New Live TV broadcast deck

- Adds the dedicated `°LIVE TV` screen identity.
- Replaces the main Live TV grid's continuously scrolling interaction surface with a fixed 4-column × 3-row broadcast page.
- Shows a lightweight `PAGE NN / NN` position indicator that does not consume remote focus.
- RIGHT from the right edge advances to the next channel page while preserving the current row.
- LEFT from the left edge on page 2+ returns to the previous page while preserving the current row.
- Page 1 retains the existing two-LEFT Live Controls/category access.
- Only the main grid is paged; the full Guide keeps its existing larger virtual program corridor.

## Guide navigation

- From any card in the bottom row, first DOWN transfers focus to the real Guide dock.
- DOWN again opens the full Guide. This is focus/state driven, not a timed double-press detector.
- UP from the dock returns to the exact originating card.
- Back/Menu closes the full Guide immediately.
- LEFT twice while the full Guide is open also closes it.
- Closing the Guide restores the same selected channel, the correct channel page, and exact grid-card focus without reloading the provider/EPG pipeline.

## Premium card refresh

- 24-point continuous broadcast-card silhouette.
- Focused cards use one compositor-owned 3D lift, scale and shadow so the card visibly rises from the deck.
- New lightweight LIVE + channel-number chrome and channel-accent signal spine.
- Cleaner lower broadcast shelf for program title/channel identity.
- Focused program progress remains focused-only.
- Existing configurable focus ring and focus-preview systems are retained.
- No per-card Material blur was added and the old per-card forced `drawingGroup()` was removed.

## Performance work

The main-grid hot path now mounts only 12 interactive focus hosts rather than the former up-to-96-card virtual scrolling corridor. Routine grid focus changes no longer perform virtual-window maintenance. Main-grid artwork prefetch and schedule-boundary checks are page bounded. There is no per-move `ScrollViewReader.scrollTo`, page-transition polling loop, or whole-grid animation. Page swaps use animation-disabled state and rebind focus on the next run-loop turn.

## Production delta from vBRDC142

Functional source:
- `Sources/DebridChannelsTVOSApp.swift`

Version metadata only:
- `Sources/Info.plist`
- `TopShelfExtension/Info.plist`
- `project.yml`

No other production file changed.

## Validation

- 293/293 cumulative vBRDC143 source/regression contracts passed.
- 74 Swift files parsed cleanly with `swiftc -parse`.
- App and Top Shelf plists lint cleanly.
- `project.yml` parses cleanly.
- 36 backend runtime tests + 2 subtests passed.
- Production-delta audit confirms exactly the four files listed above differ from packaged vBRDC142.

Physical Apple TV testing and the GitHub Actions/Xcode compile remain authoritative for tvOS Focus Engine behavior and final rendered performance.
