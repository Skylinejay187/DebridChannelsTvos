# Debrid Channels vBRDC130 — Catalog Exit -> Top Menu Focus Recovery

Release: `vBRDC130`  
Marketing version: `1.0.833`  
Apple build: `833`

## Donor / scope

vBRDC130 is built directly from packaged vBRDC129. This is a narrow corrective build for the physical-tvOS regression where Home / Movies / TV Shows catalogs could be entered normally but Back/Menu would appear to leave focus trapped inside the persistent catalog row.

The vBRDC128 exact card-owned Live TV focus ring, vBRDC126 Live TV motion engine/settings, vBRDC125 catalog artwork identity hardening, and vBRDC129 selected-category navigation contract remain intact.

## Root cause

The vBRDC129 Back handler cleared the parent catalog `FocusState` and requested the selected top-menu item, but the persistent fixed-slot catalog rail itself remained focusable during the same Focus Engine update. On physical Apple TV, tvOS could therefore choose the still-mounted rail as the nearest valid focus destination before the top-menu request committed. The result looked like Back did nothing.

## vBRDC130 correction

Back/Menu from Home / Movies / TV Shows now performs a two-phase focus handoff:

1. keep the currently selected top-menu category selected,
2. set a nonpublishing catalog-row yield state,
3. cancel every delayed catalog focus-restoration owner,
4. clear the real row `FocusState` without animation,
5. make the still-mounted persistent rail temporarily nonfocusable via the existing top-menu selection hold,
6. yield one render frame,
7. request focus for that same selected top-menu item.

The rail is never unmounted. Pressing Down or explicitly selecting a catalog category clears the hold, re-enables the rail, and uses the normal vBRDC129 content focus token to enter rows.

## Preserved behavior

- Home / Movies / TV Shows selection automatically enters catalog rows.
- Back/Menu from a catalog returns to that same selected top-menu item.
- The selected category does not change to Live TV on Back.
- Live TV only receives focus when Live TV itself is selected and the user moves Down into its grid.
- The exact Live TV focus ring shape and glow implementation are unchanged.
- The stronger Live TV preview dim and preview-duration settings are unchanged.
- Persistent catalog scrolling/motion and vBRDC125 media-identity artwork ownership remain unchanged.
- MediaFlow, PlaybackKit, Sports routing, Cast Explorer, Bluetooth VOD controls, resume logic, provider routing, and backend behavior are unchanged.

## Validation

- cumulative regression contract: **173/173**
- production Swift parse: **65/65**
- backend runtime suites: **36/36**
- release identity: `vBRDC130 / 1.0.833 / 833`
- production changed-file scope: only `Sources/DebridChannelsTVOSApp.swift`, two Info.plists, and `project.yml`

GitHub Actions/Xcode and physical Apple TV testing remain authoritative for Apple SDK compilation and final Focus Engine behavior.
