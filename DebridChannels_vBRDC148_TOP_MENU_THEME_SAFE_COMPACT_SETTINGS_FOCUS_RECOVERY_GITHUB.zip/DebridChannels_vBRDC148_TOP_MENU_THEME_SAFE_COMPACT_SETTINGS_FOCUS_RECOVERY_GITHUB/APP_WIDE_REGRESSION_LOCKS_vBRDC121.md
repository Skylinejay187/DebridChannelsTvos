# APP-WIDE REGRESSION LOCKS — vBRDC121

## VOD Bluetooth / media-command ownership

- The existing Bluetooth Media Play/Pause setting remains default-On and remains VOD-only.
- MPRemoteCommandCenter Play, Pause, and Toggle handlers stay registered once at app launch.
- Active VOD publishes Now Playing title, duration, elapsed time, playback rate, and non-live state.
- Active VOD owns AVAudioSession `.playback` + `.moviePlayback` while presented.
- The latest VOD Now Playing snapshot remains retained by the coordinator for event-driven recovery.
- VOD media ownership is reasserted after first frame, app reactivation, Bluetooth/audio route change, interruption end, and media-services reset.
- Reassertion must not use a polling timer.
- Live TV, trailers, catalog previews, and navigation must not claim this VOD Bluetooth bridge.
- Releasing the actual owning VOD presentation clears Now Playing and deactivates the owned playback audio session.
- Stale presentation releases must not clear a newer VOD presentation because release remains UUID-guarded.
- The existing MPRemoteCommandCenter / SwiftUI duplicate-event suppression remains intact.

## Prior locks

All vBRDC119 app-wide frame-budget/performance invariants and all vBRDC120 compile corrections remain locked unless explicitly scoped by a future build.
