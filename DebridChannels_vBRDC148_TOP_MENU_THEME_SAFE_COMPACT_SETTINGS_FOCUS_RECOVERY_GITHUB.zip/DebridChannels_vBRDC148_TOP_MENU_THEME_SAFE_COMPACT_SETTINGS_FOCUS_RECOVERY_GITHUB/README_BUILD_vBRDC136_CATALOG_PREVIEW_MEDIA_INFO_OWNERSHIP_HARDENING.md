# Debrid Channels vBRDC136 — Catalog Preview Media Information Ownership Hardening

- Release ID: `vBRDC136`
- Marketing version: `1.0.839`
- Apple build: `839`
- Donor: packaged `vBRDC135_VOD_FRAME_PACING_BLUETOOTH_RUNTIME_HARDENING_GITHUB.zip` only

## Physical-test regression addressed

On Home / Movies / TV Shows catalog rows, a muted focused-card preview could stop immediately when the user pressed the already-focused card to open the connected Media Information popup.

## Root cause

The preview was already designed to survive Media Information, but one ownership guard still derived the originating media from the ambient catalog `FocusState`. When the popup took tvOS focus, `focusedRow` could legitimately become `nil`; the helper then fell back to row 0. If the preview originated from another row, the active preview was falsely classified as stale and torn down.

## Fix

The preview-preservation guard now uses the durable origin identity captured before `openDetail` (`quickPanelRestoreIdentityItem`, then the detail presentation anchor) instead of relying on the current row FocusState while the popup owns focus.

The comparison accepts either the exact stable media id or the existing canonical catalog identity bridge, so normal metadata hydration cannot invalidate the same title while a genuinely different related/franchise/detail item still cancels the old preview.

## Explicitly preserved

- vBRDC135 Bluetooth media-button behavior remains invisible and automatic.
- vBRDC135 VOD physical-display frame-pacing lane remains unchanged.
- vBRDC135 4K decoded-frame queue tuning remains unchanged.
- vBRDC135 resume checkpoint offloading remains unchanged.
- vBRDC134 app-wide runtime quiescence remains unchanged.
- vBRDC133 zero-flash catalog-to-Live TV handoff remains unchanged.
- vBRDC132 universal top-menu Down-to-Live-TV behavior remains unchanged.
- vBRDC131 catalog close animation remains unchanged.
- vBRDC128 Live TV card-shaped focus ring remains unchanged.
- vBRDC126 Live TV motion/preview controls remain unchanged.
- vBRDC125 catalog artwork identity hardening remains unchanged.
- MediaFlow, providers, source ranking, Sports, Cast Explorer, playback selection, resume policy and UI geometry are unchanged.

## Validation

- 229/229 cumulative regression checks passed.
- 65/65 production Swift files parsed.
- 36/36 packaged backend runtime tests passed.
- Production donor comparison: only `Sources/DebridChannelsTVOSApp.swift` plus the three version metadata files differ from vBRDC135.
- ZIP integrity is required before release handoff.

Physical Apple TV testing remains authoritative for AVPlayer preview continuity.
