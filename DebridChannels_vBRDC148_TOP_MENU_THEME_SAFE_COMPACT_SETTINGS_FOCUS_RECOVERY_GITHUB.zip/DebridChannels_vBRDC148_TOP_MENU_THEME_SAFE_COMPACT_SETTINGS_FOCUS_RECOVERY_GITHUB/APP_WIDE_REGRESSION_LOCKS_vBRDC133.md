# APP-WIDE REGRESSION LOCKS — vBRDC133

Donor: vBRDC132.

## New lock — hidden catalog must never flash during Down → Live TV

When Home / Movies / TV Shows rows have already been dismissed and `unityCatalogBranchProgress <= 0.001`, a later selected-tab change to Live TV must not restore the catalog to full progress. The hidden branch is cleared immediately and the persistent Live TV root receives the handoff.

A catalog that is actually visible may still reverse from its current compositor progress to zero. It must never be forced back to `1` solely because the previous selected tab belongs to the catalog family.

## Preserved navigation contract

- Select a top-menu category opens its normal content.
- Back/Menu from catalog rows dismisses the catalog and returns to the same selected top-menu item.
- Down from any top-menu item returns to the persistent Live TV grid.
- Live TV focus ring/card geometry and vBRDC126 grid motion remain unchanged.
