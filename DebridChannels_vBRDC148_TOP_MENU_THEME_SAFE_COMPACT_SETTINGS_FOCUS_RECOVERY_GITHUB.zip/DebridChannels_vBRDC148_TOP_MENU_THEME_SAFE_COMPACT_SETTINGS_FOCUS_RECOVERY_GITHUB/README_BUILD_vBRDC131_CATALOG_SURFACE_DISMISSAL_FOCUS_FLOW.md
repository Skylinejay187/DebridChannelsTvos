# Debrid Channels vBRDC131 — Catalog Surface Dismissal / Focus Flow Recovery

Release: **vBRDC131**  
Marketing version: **1.0.834**  
Apple build: **834**  
Donor: packaged **vBRDC130_CATALOG_EXIT_TOP_MENU_FOCUS_RECOVERY**

## Physical-device failure reproduced from user video

vBRDC130 treated Back/Menu from Home / Movies / TV Shows as a focus-only handoff. It cleared the row's real FocusState / focusability while leaving the catalog presentation fully visible. On tvOS this produced exactly the reported result: the selected catalog card lost its raised geometry and the entire catalog became visually flat instead of dismissing.

## vBRDC131 correction

Catalog **selection** and catalog **presentation** are now explicit independent state.

- `selectedTab` continues to represent the selected top-menu category.
- `catalogRowsPresented` represents whether the Home / Movies / TV Shows catalog branch is actually open.
- Back/Menu from catalog rows sets `catalogRowsPresented = false` and **does not change `selectedTab`**.
- The root drives the same existing UNITY catalog branch compositor scalar from 1 -> 0 to close the rows.
- The outgoing focused card remains visually pinned for the complete reverse motion. Back no longer clears `focusedRow` and no longer makes the persistent rail non-focusable to fake an exit.
- Only after the branch is fully invisible does Root release `unityPresentedCatalogTab` and issue one `menuFocusToken`, landing focus on the already-selected Home / Movies / TV Shows top-menu item.
- Selecting that category again, or pressing Down from it, sets `catalogRowsPresented = true` and reopens the already-mounted persistent rows through the same compositor path.
- Selecting Live TV keeps its existing explicit Down-entry behavior. No catalog exit routes focus to a Live TV card.

## Preserved

- vBRDC128 exact card-shaped Live TV focus ring.
- Live TV focus-ring colors and glow/pulse modes.
- stronger Live TV preview dimming and preview duration controls.
- vBRDC126 Live TV single-owner grid motion engine.
- vBRDC125 catalog artwork identity hardening.
- MediaFlow, PlaybackKit, Sports, Cast Explorer, Bluetooth VOD, provider routing, resume, Gracenote/XMLTV and playback ownership logic.

## Validation

- cumulative regression contract: **181/181 PASS**
- production Swift syntax parse: **65/65 PASS**
- packaged backend runtime suites: **36/36 PASS**
- plist/version identity: PASS
- ZIP integrity: PASS

GitHub Actions/Xcode and physical Apple TV hardware remain authoritative for Apple SDK compile and final tvOS Focus Engine behavior.
