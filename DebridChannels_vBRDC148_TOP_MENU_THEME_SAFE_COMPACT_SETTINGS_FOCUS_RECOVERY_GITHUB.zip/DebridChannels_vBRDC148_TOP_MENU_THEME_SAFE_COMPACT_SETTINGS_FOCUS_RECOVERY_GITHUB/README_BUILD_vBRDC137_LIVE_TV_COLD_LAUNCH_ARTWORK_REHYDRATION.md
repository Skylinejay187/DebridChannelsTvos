# Debrid Channels vBRDC137 — Live TV Cold-Launch Artwork Rehydration

- Release ID: `vBRDC137`
- Marketing version: `1.0.840`
- Apple build: `840`
- Donor: packaged `vBRDC136_CATALOG_PREVIEW_MEDIA_INFO_OWNERSHIP_HARDENING_GITHUB.zip` only

## Physical-test regression addressed

After force-closing Debrid Channels and reopening it, the Live TV Guide could restore normally while the Live TV grid remained on generic/blank channel cards instead of program posters. Grid scrolling did not reliably recover the artwork.

## Root cause

A persisted lineup + guide restored from disk was marked as `hasLoadedThisAppSession = true`. `refreshIfNeeded()` could therefore honor the normal three-hour refresh TTL and skip a fresh configured-source/Gracenote pass on a brand-new app process.

That is safe for schedule text, but not for remote artwork generations: cached programme rows can remain readable while their image URLs/request generation is stale. Because the persistent Live TV grid can already be mounted before fresh network state exists, its `StateObject` image owners could also retain a blank/cancelled request until a later surface transition woke them.

## Fix

- A guide restored from disk is now treated as an immediate visual bootstrap, not as a network-validated app-session generation.
- Every new process performs one fresh configured-source validation even if the persisted guide is inside the normal three-hour TTL.
- If startup networking is not ready, the validation remains armed and retries on the next real Live TV entry.
- When Live TV is hidden under another UNITY branch, the existing bounded cold-start lane is allowed to perform that one validation early.
- Fresh guide publication directly resumes mounted Live TV artwork requests before incrementing the tile refresh token.
- The existing forced artwork bootstrap now re-arms blank retained requests at its reinforcement checkpoints as well as asking mounted tiles to recompute their source.
- No repeating artwork poll/timer was added.

## Explicitly preserved

- vBRDC136 catalog preview continuity through Media Information is unchanged.
- vBRDC135 invisible Bluetooth VOD media-button ownership is unchanged.
- vBRDC135 VOD physical-display frame pacing and 4K decode-queue tuning are unchanged.
- vBRDC135 resume checkpoint offloading is unchanged.
- vBRDC134 app-wide runtime quiescence is unchanged.
- vBRDC133 zero-flash catalog-to-Live TV handoff is unchanged.
- vBRDC132 universal top-menu Down-to-Live-TV behavior is unchanged.
- vBRDC131 catalog close animation is unchanged.
- vBRDC128 exact Live TV card-shaped focus ring is unchanged.
- vBRDC126 Live TV motion/preview controls are unchanged.
- vBRDC125 catalog artwork identity hardening is unchanged.
- MediaFlow routing, providers, Sports, Cast Explorer, VOD playback selection, resume policy, UI geometry and Live TV Guide presentation are unchanged.

## Validation

- 237/237 cumulative regression checks passed.
- 65/65 production Swift files parsed.
- 36/36 packaged backend runtime tests passed.
- Production donor comparison is limited to `Sources/DebridChannelsTVOSApp.swift` and version metadata.
- ZIP integrity and package hash are required before release handoff.

Physical Apple TV testing remains authoritative for provider/network artwork behavior.
