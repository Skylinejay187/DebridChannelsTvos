# Debrid Channels vBRDC146 — Live TV Compact Logo / Guide Exit Rail / Left-Edge Hardening

Base: packaged `vBRDC145` only  
Release: `vBRDC146`  
Marketing: `1.0.849`  
Apple build: `849`

## Scope
Live TV presentation/navigation polish only. No provider, XMLTV, Gracenote, MediaFlow, playback, catalog, Sports, Favorites, or VOD logic changes.

## Changes
- Reduced both optional animated Live TV header logo styles by roughly one quarter while preserving their existing isolated compositor pulse/shine behavior and Settings toggles.
- Replaced the clipped top-right Guide exit capsule with a narrow glowing vertical rail in the left safe margin: EXIT / BACK-MENU / LEFT-TWICE. It remains presentation-only and keeps the existing 30-second auto-hide.
- Hardened the page-1 first-column Live Controls entry. Later-page navigation remains double-LEFT, but page 1 now requires three deliberate LEFT edge commands from the same card before Live Controls opens.
- All existing vBRDC145 bottom-row preview/Guide behavior remains intact.

## Locked behavior preserved
- 4x3 / 12-card Live TV pages.
- Two-press RIGHT/LEFT page changes on page boundaries (page 2+ for LEFT).
- Bottom-row DOWN twice opens Guide; first DOWN does not cancel focused-card preview.
- Guide Back/Menu and double-LEFT exit behavior.
- 30-second glowing grid Guide hint and 30-second Guide exit hint.
- vBRDC142 post-VOD Live TV artwork rehydration and all Gracenote/channel-logo loading behavior.
