# Performance Audit — vBRDC139

## Live TV grid

- Removed hidden provider/Gracenote validation when a complete persisted guide is already available under Home/Movies/Shows. Validation remains pending until Live TV is actually active.
- Prevented the persistent hidden Live TV root from starting its forced artwork bootstrap while a catalog owns the surface.
- Prevented hidden Live TV tile/category FocusState ownership on mount and removed the visual focus pin during Live -> catalog handoff. This avoids focused-card compositor work behind catalog rows.
- Scene foreground re-arm is active-surface gated, so returning to the app on a catalog does not resume Live TV image decoders.
- Kept the current bounded 640 px program-art pipeline; channel logos use a smaller 384 px first-paint path. The old v987 unbounded/heavier image loader was not transplanted.

## Catalog rows

- Catalogs no longer contend with hidden Live TV Gracenote/provider validation or hidden Live TV forced artwork decoding after foreground/mount.
- Catalog geometry, persistent rail, preview ownership, artwork identity hardening, and zero-flash Live TV handoff remain unchanged.

## Reliability / first paint

- A Live TV tile always has generated channel identity immediately.
- If a channel logo exists, it paints before a pending program/Gracenote image and remains visible during the upgrade.
- Failed program-art requests re-evaluate the fallback ladder on the mounted tile, eliminating the prior dependency on scroll/remount.

No repeating polling timer was added. Physical Apple TV testing remains authoritative for final network/provider timing and focus feel.
