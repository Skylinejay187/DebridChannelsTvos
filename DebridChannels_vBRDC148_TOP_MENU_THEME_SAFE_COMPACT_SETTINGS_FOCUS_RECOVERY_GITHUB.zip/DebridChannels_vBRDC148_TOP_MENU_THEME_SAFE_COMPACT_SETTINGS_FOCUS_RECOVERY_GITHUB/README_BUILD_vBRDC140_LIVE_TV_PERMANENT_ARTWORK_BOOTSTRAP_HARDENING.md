# Debrid Channels vBRDC140 — Live TV Permanent Artwork Bootstrap Hardening

- Release ID: `vBRDC140`
- Marketing version: `1.0.843`
- Apple build: `843`
- Donor/source of truth: packaged `vBRDC139`.
- Comparison donor only: packaged `v987`; only its Live TV logo/program prefetch ownership behavior was used as a reference.

## Root cause corrected

The vBRDC139 force-artwork bootstrap could repeatedly call `load()` for the exact same mounted URL while that request was still in DNS/TLS/network/decode or waiting for the shared visual-publication lane. Because the loader treated the retry token as a replacement request until pixels had already published, the reinforcement token could cancel and restart its own in-flight request. On cold launch or process return this could leave grid cards on generated identities until a tab round-trip created a clean loading opportunity.

A second lifetime flaw existed after decode: the decoded bitmap was not inserted into the bounded cache until after the visual-publication gate. A successful network/decode could therefore be discarded by a focus/surface cancellation before becoming reusable.

A third issue existed in prefetch ownership: channel-logo and program-art prefetch were launched as separate cancellation sets. The second bucket could cancel the first even though both belonged to the same visible Live TV corridor.

## vBRDC140 changes

1. **Idempotent mounted artwork request ownership**
   - Re-requesting the exact same URL + decode bucket while its task is active no longer cancels/restarts it.
   - Each request has a monotonically increasing generation so an older cancelled task cannot clear the handle for a newer request.
   - Every task completion clears its own handle only when it still owns the current generation.

2. **Decode survives focus/surface publication deferral**
   - A successful decoded bitmap enters the bounded cache before waiting for SwiftUI visual publication.
   - A subsequent re-arm can therefore publish the already-decoded image without another network/decode pass.
   - The first real bitmap on a blank visible card is never starved behind the noncritical visual-publication lane.

3. **Guaranteed channel identity first paint**
   - Channel logos remain the first remote fallback at a 384 px decode budget.
   - Channel identity may publish immediately once decoded.
   - Program/Gracenote art remains the preferred final image and uses the existing 640 px bounded path.
   - Generated channel identity remains the final no-network fallback.

4. **Grid-mount bootstrap**
   - The actual Live TV grid ScrollView now starts the artwork bootstrap as well as the persistent parent surface.
   - This closes the launch-order race where a parent bootstrap could fire before LazyVGrid tile artwork owners existed.

5. **v987 prefetch ownership restored through the modern bounded loader**
   - The initial visible corridor prefetches channel logos as well as current program art.
   - Logo and program URLs are retained as one cancellation set, while still decoding at separate 384/640 px budgets.
   - Immediate logo warming occurs before the background-prefetch frame gate; it does not publish SwiftUI state by itself.

6. **Hidden catalog quiescence completed**
   - Home/Movies/TV Shows no longer schedule the leftover one-shot hidden Live TV cold-hydration provider task.
   - Provider/Gracenote validation starts when Live TV actually owns the surface through the existing active refresh path.
   - This removes invisible provider/image competition from catalog focus and scrolling.

## Preserved

- vBRDC139 Live TV channel-logo/generated fallback ladder and catalog focus quiescence.
- vBRDC138 Bluetooth VOD session-lifetime ownership.
- vBRDC137 persisted guide behavior and active-surface validation.
- vBRDC136 catalog preview ownership.
- vBRDC135 VOD frame pacing, 4K decode tuning, resume checkpoint offloading and invisible Bluetooth handling.
- Live TV exact-card focus ring, preview behavior, navigation, virtual-window motion engine and guide behavior.
- Catalog artwork identity, catalog close/return navigation, MediaFlow, PlaybackKit, Sports, Cast Explorer and provider/source logic.

No UI redesign or player/provider behavior was intentionally changed.
