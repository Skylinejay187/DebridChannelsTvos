# Debrid Channels vBRDC126 — UNITY Live TV Grid Motion Engine

- Release ID: `vBRDC126`
- Marketing version: `1.0.829`
- Apple build: `829`
- Donor: packaged `vBRDC125` only

## Release goal

Make physical-tvOS Live TV grid navigation feel like one continuous native focus motion rather than several animations competing during each D-pad step, while preserving the existing Live TV card dimensions, four-column geometry, artwork presentation, footer information, provider logic, guide behavior, and playback ownership. Add user-facing Live TV controls for focused-ring appearance, preview dimming, and preview lifetime.

## Root causes found

The donor Live TV card had more than one visual owner reacting to the same `FocusState` edge. The outer tile scaled/offset/shadowed while the inner tile simultaneously changed focused border/glow/footer/preview content. Because the outer implicit focus animation could propagate into the subtree, one navigation event could look like a scale plus a second border/glow/content settle.

Several nonvisual interaction owners were also stored in SwiftUI `@State`: preview arm/stop tasks, prefetch task, persistence task and generations. Replacing/cancelling those handles during focus movement could create additional view invalidation even though the task handles themselves are not UI.

The 96-card Live TV virtual corridor could recenter near an edge in the same turn that tvOS was moving native focus. The grid also had duplicate preview/warmup bookkeeping on common focus paths. Those operations are individually small, but together they compete with the frame in which the focused card is supposed to move.

## vBRDC126 motion correction

- Added a single `LiveTVGridFocusMotionHost` that exclusively owns the focused card's compositor scale, offset, opacity and black shadow.
- The expensive tile subtree explicitly receives `transaction.animation = nil`, so artwork, footer, progress, preview and card backing cannot inherit the focus transform animation.
- Preserved the donor focus geometry exactly: normal focused scale `1.154025`, focused Y offset `-6`, and existing grid-locked values where applicable.
- Focus gain uses a velocity-friendly spring; defocus uses a short settle so the outgoing card does not continue bouncing while the next card gains focus.
- Removed the duplicate focused shadow/glow ownership from `LiveTVGridTileContent`. The base card border remains; the configurable ring is now a focused-only leaf outside the disabled tile transaction.
- `Classic Glow` preserves the current white-glow visual by default. Optional ring motion only animates the one focused overlay, never the whole grid/card subtree.
- Moved preview, prefetch, selection-persistence, virtual-window and guide-warmup generation bookkeeping to one retained non-publishing `LiveTVGridInteractionRuntime` instead of SwiftUI `@State`.
- Removed the duplicate valid-focus preview cancellation/re-arm edge.
- Selection metadata bookkeeping is committed inside an animation-disabled transaction after native FocusState already owns the visual move.
- Ordinary grid focus no longer executes the full-guide preview warmup path.

## Virtual grid frame-budget correction

- The existing 96-card mounted corridor remains; card size, spacing and focusable geometry are unchanged.
- Routine virtual-window maintenance now waits 125 ms and coalesces rapid D-pad inputs to the newest focused card.
- The donor five-row maintenance corridor remains (`20` channels), with a two-row emergency buffer (`8` channels) that can still recenter immediately so focus never reaches an unmounted edge.
- Every recenter is animation-disabled. tvOS native focus movement is allowed to start/settle before routine structural maintenance runs.
- Leaving Live TV or unmounting cancels any pending virtual-window maintenance.

## New Live TV settings

### Focus ring color

Choices:
- White (default)
- Cyan
- Orange
- Blue
- Purple
- Green
- Red
- Gold

### Focus ring motion

Choices:
- Classic Glow (default; preserves current look)
- Steady Ring
- Soft Pulse
- Breathing Glow

Pulse/breathing animation is isolated to the focused ring overlay only.

### Focus preview lifetime

Choices:
- 15 Seconds (default)
- 30 Seconds
- 60 Seconds
- Unlimited

The existing 3-second focus dwell before preview creation is unchanged. “Unlimited” means unlimited while that card remains the valid preview owner; moving focus, entering playback, opening Guide/Live Controls/channel actions, changing surface, or any existing decoder-ownership conflict still cancels the preview immediately.

### Dim Grid During Preview

Enabled by default. While a focused-card preview is actually active, every other Live TV card settles to `0.56` opacity. The focused preview card remains full brightness. Dimming has its own short compositor-only opacity settle and does not animate card content.

## Preserved behavior

- vBRDC125 catalog artwork identity/motion hardening remains intact.
- vBRDC124 Live TV menu/catalog focus handoff and secondary-artwork hardening remain intact.
- vBRDC123 foreground VOD/cast/episode artwork hardening remains intact.
- vBRDC121 Bluetooth VOD ownership/media controls remain intact.
- Live TV card dimensions, four-column grid, artwork style, footer, progress line, categories, provider routing, Gracenote/XMLTV, guide, channel actions, direct playback and playback-return restore behavior are preserved.
- MediaFlow, PlaybackKit, Sports, Cast Explorer, VOD resume/source selection, and backend runtime logic are not changed by this release.

## Validation

- vBRDC126 cumulative regression contract: **147/147 passed**.
- Production Swift syntax parse: **65/65 files passed**.
- Backend runtime suites: **36/36 passed** (Alternate Audio Bridge 15, Alternate Audio Discovery 8, Backup Streaming 6, TorBox Usenet Search 7).
- App and Top Shelf version/plist consistency passed: `vBRDC126 / 1.0.829 / 829`.
- Changed Swift whitespace check passed.
- Packaged ZIP integrity is checked after final packaging.
- GitHub Actions/Xcode remains authoritative for the tvOS Release compile.
- Physical Apple TV remains authoritative for measured frame pacing and subjective focus-motion verification.
