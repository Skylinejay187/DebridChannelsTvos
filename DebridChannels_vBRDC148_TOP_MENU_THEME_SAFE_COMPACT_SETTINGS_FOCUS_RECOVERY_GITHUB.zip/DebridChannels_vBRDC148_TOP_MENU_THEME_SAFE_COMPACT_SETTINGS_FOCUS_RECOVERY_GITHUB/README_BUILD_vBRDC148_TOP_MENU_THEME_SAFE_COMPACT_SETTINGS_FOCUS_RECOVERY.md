# Debrid Channels vBRDC148 — Top Menu Theme-Safe Compact + Settings Focus Recovery

Release: vBRDC148  
Marketing version: 1.0.851  
Apple build: 851

## Source-of-truth / rollback

This candidate is rebuilt directly from packaged vBRDC146. vBRDC147 is fully rejected as a donor and none of its plain legacy top-menu renderer survives.

The user-provided v810 package was treated only as a visual size reference. No v810 theme implementation, navigation architecture, catalog logic, playback code, Live TV code, or Settings implementation was imported.

## Scoped fixes

1. **Top menu size only — current themes preserved**
   - Keeps the complete vBRDC146 `TopMenuTabVisual` renderer and all current visual families.
   - Applies one 0.82 visual scale to the completed themed top-menu composition.
   - No theme is flattened into a legacy plain-text tab.
   - Existing theme fills, icons, rails, typography, accent color handling, and focus visuals remain unchanged.

2. **Restore established DOWN -> Live TV navigation outside Settings**
   - Home / Movies / TV Shows / Sports / Favorites keep the vBRDC146/vBRDC132 behavior: DOWN from the top menu returns to the persistent Live TV grid.
   - This fixes the vBRDC147 regression where DOWN entered whichever tab happened to be highlighted everywhere.

3. **Settings-only top-menu destination handoff**
   - When the top menu was entered from Settings, DOWN enters the highlighted top-menu destination.
   - If Settings remains highlighted, Settings explicitly reclaims its selected category focus.
   - This special case is isolated to Settings and does not alter the normal Home/Movies/Shows DOWN -> Live TV contract.

4. **Top Menu Theme picker focus recovery**
   - Selecting a theme closes the nested theme picker.
   - Focus returns to the `Top Menu Theme` Settings control immediately.
   - The next Siri Remote UP/DOWN continues through Settings normally instead of becoming stranded after the live top menu redraw.

## Explicitly unchanged

- Live TV 4x3 paged grid and page navigation.
- Guide DOWN-twice opening, Guide Back/Menu + double-LEFT exit, Guide glow/exit rail.
- Live TV focused-card previews.
- Animated Live TV header logos and their settings.
- Gracenote/XMLTV/channel-logo recovery and vBRDC142 post-VOD rehydration.
- Movies, TV Shows, Sports, Favorites data/source behavior.
- Playback, KSPlayer/AVPlayer, Bluetooth controls, resume, MediaFlow, TorBox/Usenet and providers.
- Catalog row scrolling/motion and visual themes.

## Validation

- vBRDC148 cumulative contract: 322/322 passed.
- Swift parse: 72/72 non-vendor Swift files parsed (65/65 production Swift files).
- Backend regression: 36 tests + 2 subtests passed.
- Both plists and project.yml parsed successfully.
- Production delta from vBRDC146: only `Sources/DebridChannelsTVOSApp.swift`, both version plists, and `project.yml`.
