# Debrid Channels vBRDC141 — Live TV Cache-First Native Logo Recovery

Release: vBRDC141  
Marketing: 1.0.844  
Apple build: 844

## Scope

Built only from packaged vBRDC140. v987 was inspected solely as a behavioral donor for the known-good Live TV cache/bootstrap contract; no old UI, playback, navigation, provider, or rendering subsystem was transplanted.

## Root cause confirmed from v987 comparison

vBRDC137 introduced `coldLaunchPersistedGuideNeedsValidation`, which deliberately marked a complete disk-restored lineup + guide as not loaded for the new process. `refreshIfNeeded()` therefore launched a complete configured-source refresh on every relaunch even while the cached Guide was already valid.

That refresh owns `LiveTVSourceModel.isLoading`, which directly owns the top-right ProgressView. It can include very large XMLTV/Gracenote/provider requests and can wait on slow/unreachable sources, competing with grid artwork on cold launch.

v987 does the opposite: a complete persisted lineup + guide sets `hasLoadedThisAppSession = true` and honors the normal three-hour refresh clock.

## Corrections

- Restored v987 cache-first semantics for a complete persisted Live TV lineup + guide.
- Removed the vBRDC137 every-process cold validation flag and the now-unused hidden cold-hydration task owner.
- A due scheduled refresh is silent when cached channels + guide are already usable; the top-right spinner is reserved for a genuinely blocking first load or explicit Force Refresh.
- Channel-logo first paint no longer shares `LiveTVBoundedArtworkLoader` ownership with Gracenote/program artwork.
- Visible grid cards use an independent native `AsyncImage` channel-logo fallback over an always-present generated channel identity.
- Bounded Gracenote/program artwork remains the higher-quality upgrade at 640 px.
- Removed duplicate custom logo prefetch/decode ownership and the unresolved per-card spinner animation.
- Program-art prefetch remains bounded and frame-budget gated.
- vBRDC140 request-generation/idempotence protections remain intact.

## Preserved

vBRDC140 artwork request lifetime hardening, vBRDC139 catalog quiescence/focus behavior, vBRDC138 Bluetooth VOD session lifetime, vBRDC136 catalog preview ownership, vBRDC135 VOD frame pacing/4K tuning, MediaFlow, Sports, Cast Explorer, resume behavior, catalog identity hardening, focus ring, and top-menu navigation are unchanged outside the single Live TV source file plus release metadata.

## Validation

- 266/266 cumulative regression/source contracts passed.
- 65/65 production Swift files parsed with `swiftc -parse`.
- 36/36 backend runtime tests passed.
- Donor delta: only `Sources/DebridChannelsTVOSApp.swift` plus version metadata differ from vBRDC140 in production.
- ZIP integrity tested after packaging.

Physical Apple TV testing remains authoritative for network timing and tvOS image/focus lifecycle behavior.
