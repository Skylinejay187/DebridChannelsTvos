# vBRDC146 regression locks

- Build only from packaged vBRDC145.
- Production scope is Live TV UI/navigation polish plus release metadata.
- Animated Live TV header remains optional, Settings-controlled, and isolated from provider/focus/grid state.
- Full Guide exit rail is non-focusable, left-safe-margin only, and auto-hides after 30 seconds.
- Page 1 Live Controls entry requires three LEFT edge commands; page 2+ previous-page navigation remains two LEFT commands.
- RIGHT paging, bottom-row Guide opening, focused-card preview, Guide exit behavior, Gracenote/channel-logo loading, post-VOD artwork recovery, MediaFlow, VOD, catalogs, Sports, and playback are locked unchanged.
