# APP-WIDE REGRESSION LOCKS — vBRDC125

vBRDC125 inherits the full vBRDC124 cumulative contract and adds six catalog-artwork identity locks.

1. Focused catalog card artwork is scoped to row + media identity; a new title cannot retain the previous focused title's bitmap.
2. Trailing structural depth-slot artwork is scoped to row + depth + media identity; slot reuse cannot produce duplicate outgoing posters.
3. Catalog hero backdrop retention is same-media only.
4. Catalog hero depth-layer retention is same-media only.
5. Catalog clearlogo retention is same-media only.
6. The persistent rail/no-peek vertical swap remains unchanged; the fix must not reintroduce row teardown or vertical crossfade.

The executable validation is `validation_vBRDC125/test_vBRDC125_contract.py` and must remain fully green before packaging.
