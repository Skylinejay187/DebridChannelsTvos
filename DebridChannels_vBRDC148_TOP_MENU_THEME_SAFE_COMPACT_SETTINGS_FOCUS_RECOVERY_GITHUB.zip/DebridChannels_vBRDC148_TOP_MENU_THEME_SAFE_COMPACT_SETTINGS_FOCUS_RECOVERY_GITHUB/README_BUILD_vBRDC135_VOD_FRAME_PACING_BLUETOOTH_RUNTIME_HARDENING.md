# Debrid Channels vBRDC135 — VOD Frame Pacing + Bluetooth Runtime Hardening

- Release ID: `vBRDC135`
- Marketing version: `1.0.838`
- Apple build: `838`
- Donor/source of truth: packaged `vBRDC134_APP_WIDE_RUNTIME_QUIESCENCE_HARDENING_GITHUB`
- Scope: invisible Bluetooth VOD transport recovery plus performance/frame-pacing hardening for VOD, Live TV grid, and catalog rails. No visual redesign or navigation rewrite.

## Bluetooth VOD media controls

Bluetooth/headset/controller media Play/Pause is again an invisible VOD capability rather than a user preference.

- Removed the Settings toggle and VOD player-panel toggle.
- Removed preference gating from `MPRemoteCommandCenter` ownership.
- Clears the retired `bluetoothVODPlayPauseEnabledV1` key at launch so a previously saved Off value cannot disable media buttons after upgrade.
- Commands remain scoped to the active VOD presentation UUID only; Live TV and navigation do not inherit the transport command owner.
- The authoritative KSPlayer decoder clock refreshes the retained Now Playing snapshot even while VOD chrome is hidden. `MPNowPlayingInfoCenter` publication remains internally throttled to state changes / ~5-second elapsed deltas.

## VOD frame-pacing / 4K work

### Physical-display-paced full-screen VOD

Full-screen VOD on tvOS no longer asks KSPNUVIO to quantize CADisplayLink to a rounded source FPS. The VOD renderer follows the output display cadence and the existing `DebridFlixorVODOptions.videoClockSync` remains responsible for timestamp-based hold/advance/drop decisions.

This does not synthesize new movie frames. A 23.976/24 fps source remains 23.976/24 unique frames; the change removes one extra scheduling lane that could contribute to uneven cadence on 50/60 Hz output. Live TV and trailers retain the donor scheduling path.

### Lower decoded 4K surface pressure

The donor retained 24 decoded frames for 4K VOD. vBRDC135 uses:

- 16 decoded frames for ordinary <= ~30 fps 4K.
- 18 decoded frames for high-frame-rate 4K.
- 24 decoded frames remains unchanged for 1080p.
- 16 remains unchanged below 1080p.

This reduces simultaneous 4K VideoToolbox pixel-buffer/texture pressure without changing source resolution, bitrate, hardware decoding, buffering policy, HDR handling, seek behavior, or playback source selection.

### Resume checkpoint work fully leaves the playback/UI thread

Normal playback checkpoints now serialize both the resume-cache mutation and disk encode/write on the existing utility writer queue. The old five-second checkpoint could still scan/reconcile the resume identity collection on its caller before queueing only the JSON write.

Durable exit/lifecycle saves synchronously drain older queued checkpoints, apply the newest mutation, and write before return. Full legacy identity reconciliation is reserved for durable writes instead of every ordinary five-second checkpoint.

## Live TV grid performance

The bounded grid artwork decode/prefetch bucket was reduced from 768 to 640 pixels. Live TV card geometry and artwork presentation are unchanged; the displayed card is substantially smaller than the previous decode bucket. This reduces image decode memory and bandwidth during rapid grid navigation.

The vBRDC126 single-owner focus-motion engine, vBRDC128 exact card-shaped focus ring, preview duration/dimming controls, and vBRDC133 zero-flash catalog-to-Live handoff are unchanged.

## Catalog rail performance

Persistent catalog slots and the vBRDC125 media-identity artwork hardening remain unchanged. Only decode buckets were right-sized:

- Focused landscape card: 1280 -> 1024.
- Small trailing poster slots: 640 -> 384.

The fixed-slot rail geometry, row animations, focus presentation, hero artwork, Connected Popup 2048 prewarm, and card identity rules remain unchanged.

## Preserved behavior

No changes were made to MediaFlow routing, provider/source ranking, TorBox/Usenet logic, Sports routing, Cast Explorer behavior, Up Next, Skip Intro behavior, resume policy, episode-alert behavior, VOD UI layout, Live TV navigation, catalog navigation, or the corrected top-menu/catalog handoff.

## Validation

- Cumulative contract: `223/223`
- Production Swift parse: `65/65`
- Backend runtime tests: `36/36`
- Donor immutable-file verification: passed; only 7 intended production/version files changed
- Version/plist validation: passed
- Production whitespace/conflict-marker checks: passed
- ZIP integrity: verified after packaging

Physical Apple TV testing remains authoritative for perceptual frame pacing, and GitHub/Xcode Release compilation remains authoritative for the full Apple-platform compile.
