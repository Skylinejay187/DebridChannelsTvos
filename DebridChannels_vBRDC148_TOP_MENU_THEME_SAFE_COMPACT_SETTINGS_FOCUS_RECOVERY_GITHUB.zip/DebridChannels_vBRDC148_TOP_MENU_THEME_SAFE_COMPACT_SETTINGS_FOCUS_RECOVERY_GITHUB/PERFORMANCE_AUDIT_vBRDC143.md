# vBRDC143 Live TV Grid Performance Audit

The user-reported hitch was concentrated in repeated vertical focus movement on the main Live TV grid. vBRDC142 still mounted an up-to-96-card virtual LazyVGrid inside a vertical ScrollView, retained absolute virtual spacer geometry, and maintained the 96-card corridor around focus even though tvOS native focus was already handling visible movement.

vBRDC143 makes the visible grid a fixed 12-card page. This removes the main-grid vertical ScrollView/ScrollViewReader path, eliminates moving virtual-corridor maintenance from ordinary grid focus changes, and bounds artwork prefetch plus schedule-boundary evaluation to the current page. The larger rendered corridor is retained only for the full Guide where it is still useful.

Focused-card depth uses scale/offset/3D rotation/shadow at the outer compositor host. The expensive card subtree rejects that animation transaction. The old per-card `drawingGroup()` was removed so twelve cards are not forced through unnecessary offscreen render textures. No continuously animated blur/material effect was introduced.

No provider, XMLTV, Gracenote, playback, MediaFlow, catalog, or background-refresh logic was changed for this performance pass.
