# Debrid Channels vBRDC144 — Live TV Focus / Navigation Polish

Release: vBRDC144  
Marketing: 1.0.847  
Apple build: 847

## Source of truth

Built only from the packaged vBRDC143 `LIVE_TV_BROADCAST_DECK_REFRESH` ZIP supplied/approved in this conversation. No older source tree was used.

## Scope

This is a corrective pass on the refreshed main Live TV grid only. Provider loading, Gracenote/XMLTV parsing, channel-logo recovery, playback, Movies, TV Shows, Sports, Favorites, MediaFlow routing, catalog scrolling, and the full Guide data model are unchanged.

## Focus/navigation correction

- Right-edge paging is now deliberately two-step: the first RIGHT stays on the fourth card; the second RIGHT from that same card advances to the next page.
- Left-edge paging on page 2+ mirrors that rule: the first LEFT stays on the first card; the second LEFT returns to the prior page.
- Page 1 still uses the existing double-LEFT Live Controls behavior.
- Bottom-row Guide entry is also two-step without adding another focusable control: first DOWN arms Guide and keeps the exact card focused; second DOWN from that card opens the full Guide.
- The Guide hint is now presentation-only and cannot enter the tvOS focus graph, removing the focus bounce seen in physical-device video.
- Guide Back/Menu exit and double-LEFT exit remain unchanged.

## Visual cleanup

- Removes the degree symbol from the screen title; header is now clean `LIVE TV`.
- Removes the detached `NOW BROADCASTING` capsule from the All view; non-All categories use a quiet inline label only.
- Removes the per-card red LIVE badge.
- Removes the per-card left accent spine.
- Keeps the channel-number badge, focused-card depth/lift, artwork, footer metadata, focus ring, and page indicator.
- Replaces the old `BOTTOM ROW • DOWN TWICE FOR GUIDE` capsule with a smaller, cleaner Guide status strip that changes to `PRESS ↓ AGAIN TO OPEN` after the first DOWN.

## Performance

The 12-card 4x3 page architecture remains intact. This correction removes a focusable Guide-dock node and two card overlay elements, reducing focus reconciliation and card chrome work rather than adding new runtime animation.
