# Debrid Channels vBRDC132 — Top Menu Down → Live TV Return

Release: **vBRDC132**  
Marketing version: **1.0.835**  
Apple build: **835**  
Donor: packaged **vBRDC131 Catalog Surface Dismissal / Focus Flow Recovery**

## Correction

vBRDC129-vBRDC131 accidentally made the global top-menu Down command depend on the currently selected tab. That changed a long-standing navigation rule: Down from Home/Movies/TV Shows could reopen catalog rows, while Down from Settings/Sports/Favorites could remain on those surfaces.

vBRDC132 separates menu commands again:

- Selecting a top-menu category performs that category's normal action.
- Back/Menu from catalog rows still closes the real catalog surface and returns focus to the selected menu item.
- Pressing **Down from any top-menu item always exits the menu to the persistent Live TV grid**.
- If the active surface is not Live TV, Down changes the active surface to Live TV, yields one render turn so the persistent root becomes interactive, then restores the native selected-channel focus through the existing dedicated Live TV entry token.

No focusability predicates, alternate Live TV grid, catalog rebuild, or extra animation owner was added.

## Validation

- cumulative contract: **188/188 PASS**
- production Swift parse: **65/65 PASS**
- backend runtime suites: **36/36 PASS**
- version identity: PASS
- locked high-risk donor sources: PASS
- ZIP integrity: PASS

GitHub Actions/Xcode and physical tvOS hardware remain authoritative for Apple SDK compilation and final focus-engine behavior.
