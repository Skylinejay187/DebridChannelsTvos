# Performance Audit — vBRDC141

The cold-launch artwork failure was coupled to unnecessary background provider work, not merely image decoding.

Key reduction:
- A complete cached guide no longer triggers an immediate full configured-source/XMLTV/Gracenote refresh on every process launch.
- Cache-backed TTL refreshes do not animate the global loading spinner and do not block first paint.
- Channel identity no longer duplicates work through both a custom bounded logo loader and the program-art prefetch corridor.
- Removed the unresolved per-tile ProgressView animation from the Live TV grid.
- Rich program art remains bounded to 640 px and frame-budget gated.

This lowers cold-launch network contention, MainActor publication pressure, decoder contention, and simultaneous spinner animation work without changing Live TV content selection or provider logic.
