# vBRDC148 Regression Locks

vBRDC148 is a rollback/corrective branch from packaged vBRDC146. These contracts are locked:

- The vBRDC146 `TopMenuTabVisual` theme renderer must remain the active top-menu renderer.
- Theme families including Liquid Island, Studio Chrome, Broadcast Deck, Modern Pills, Poster Tabs, Circle Dock, Marquee and Ribbon must remain present.
- Compact sizing must be applied to the finished theme composition rather than replacing theme-specific tab content.
- vBRDC147's inline legacy/plain tab renderer must not return.
- Outside Settings, DOWN from the global top menu must preserve the vBRDC146 fast return to Live TV.
- From Settings only, DOWN from the top menu may enter the highlighted destination.
- Returning to Settings must explicitly restore the selected Settings category focus.
- Selecting a Top Menu Theme must return focus to the Top Menu Theme Settings control.
- vBRDC146 Live TV grid/Guide/preview/artwork contracts remain unchanged.
