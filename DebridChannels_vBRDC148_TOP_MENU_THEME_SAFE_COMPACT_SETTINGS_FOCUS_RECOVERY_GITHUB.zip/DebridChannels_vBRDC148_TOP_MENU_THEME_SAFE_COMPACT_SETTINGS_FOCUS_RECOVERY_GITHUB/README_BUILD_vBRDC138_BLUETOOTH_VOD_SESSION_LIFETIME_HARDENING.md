# Debrid Channels vBRDC138 — Bluetooth VOD Session Lifetime Hardening

- Release ID: `vBRDC138`
- Marketing version: `1.0.841`
- Apple build: `841`
- Donor/source of truth: packaged `vBRDC137_LIVE_TV_COLD_LAUNCH_ARTWORK_REHYDRATION_GITHUB`
- Scope: persistent invisible Bluetooth/headset VOD Play/Pause ownership only. No UI, navigation, Live TV, catalog preview, MediaFlow, VOD frame-pacing, provider, artwork, or playback-source behavior redesign.

## Physical-test regression

Bluetooth/headset Play/Pause could work for one VOD presentation and then stop after exiting/re-entering playback. The prior bridge was process-installed, but the actual active-session claim/release was still coupled to SwiftUI `VODPlayerScreen.onAppear/onDisappear`.

That made media ownership depend on presentation lifetime rather than the authoritative playback session. It also sent external headset commands through the same 440 ms `playerAction` throttle used for rapid on-screen/Siri Remote actions, allowing a valid external Pause/Play to be discarded if it arrived shortly after another player action.

## Correction

- `CatalogStore.startPlayback` now creates the new playback UUID and claims invisible Bluetooth/Now Playing ownership for non-Live VOD before publishing the new player URL.
- Replacing one VOD with another claims the new UUID atomically; there is no SwiftUI disappearance gap.
- Starting Live TV explicitly releases the previous VOD Bluetooth owner and does not claim the bridge.
- `CatalogStore.closePlayer` is now the authoritative Bluetooth release point.
- `VODPlayerScreen.onDisappear` no longer releases system media ownership. Transient/remounted SwiftUI surfaces therefore cannot tear down headset transport control while the authoritative playback session still exists.
- The concrete VOD player still claims/reasserts the same UUID after engine setup and at the existing first-frame/audio lifecycle recovery points.
- MPRemoteCommandCenter duplicate delivery protection remains 180 ms.
- Bluetooth/headset transport commands bypass the separate 440 ms generic UI action throttle; Cast Explorer, Episode Browser, and pending episode-switch ownership guards remain intact.
- The Bluetooth setting remains completely removed; this is an automatic background capability.

## Preserved donor behavior

vBRDC137 Live TV cold-launch artwork rehydration, vBRDC136 catalog preview ownership, vBRDC135 VOD frame pacing/4K queue/resume performance work, Live TV focus ring and motion engine, catalog artwork identity, zero-flash catalog-to-Live handoff, MediaFlow, Bluetooth Now Playing metadata, Sports, Cast Explorer, source/provider routing, and resume policy are unchanged outside the two Bluetooth ownership call sites and version metadata.

## Validation

- Cumulative contract: `246/246`
- Production Swift parse: `65/65`
- Backend runtime tests: `36/36`
- Donor delta: only `Sources/DebridChannelsTVOSApp.swift`, `Sources/CatalogStore.swift`, normal version metadata, this release documentation, and vBRDC138 validation artifacts differ from vBRDC137.
- Physical Apple TV + affected Bluetooth headset remains authoritative for accessory transport delivery.
