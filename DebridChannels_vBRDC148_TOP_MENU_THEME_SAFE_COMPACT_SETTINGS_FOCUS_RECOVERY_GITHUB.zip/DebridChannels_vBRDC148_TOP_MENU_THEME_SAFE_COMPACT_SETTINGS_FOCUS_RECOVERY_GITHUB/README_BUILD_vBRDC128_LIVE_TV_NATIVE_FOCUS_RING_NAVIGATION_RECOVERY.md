# Debrid Channels vBRDC128 — Live TV Native Focus Ring + Navigation Recovery

Release: `vBRDC128`  
Marketing version: `1.0.831`  
Apple build: `831`

## Donor / rollback scope

vBRDC128 is built from the packaged vBRDC126 UNITY Live TV Grid Motion Engine donor. The vBRDC127 focus-graph restrictions were intentionally not carried forward. The vBRDC126 Live TV grid remains natively focusable and preserves its single-owner motion engine, bounded preview controls, virtual-window coalescing, artwork performance work, and all vBRDC125 catalog artwork identity hardening.

## Corrective behavior

### 1. Normal Live TV Down navigation is restored

vBRDC127 made hidden/persistent Live TV focusability depend on the selected tab and added a persistent selected-tab focus owner. That over-constrained tvOS focus routing. vBRDC128 removes that architecture completely.

Live TV cards and the category rail use the vBRDC126 native focusable conditions again. No `selectedTab == .live` predicate is inserted into the grid focus graph.

### 2. Top-menu selection now does only one simple thing

Selecting a top-menu tab records a non-publishing transient hold and keeps the selected top-menu button focused. Automatic catalog/content recovery is suppressed while that hold is active so a late row/provider publication cannot immediately push focus into content.

Pressing Down clears the hold immediately. Catalogs use their existing content-focus token. Live TV receives one explicit Down-edge token that assigns focus to the already-mounted selected channel. No focusable views are disabled or rebuilt.

When leaving Live TV through a top-menu selection, only the old real Live TV FocusState is cleared. The existing UNITY visual pin may still preserve the outgoing card frame during the surface animation, but the hidden grid cannot reclaim real focus.

### 3. Focus ring is card-owned again

The configurable colored ring is no longer drawn by the outer focus-transform host. It is drawn inside `LiveTVGridTileContent` on the same `RoundedRectangle(cornerRadius: 16, style: .continuous)` used by the card clip itself.

The ring never scales independently. Soft Pulse and Breathing Glow modulate only halo opacity / width / blur using a focused-only TimelineView. The card silhouette and ring silhouette remain identical throughout the effect.

### 4. Stronger preview dim

Non-preview cards now settle to `0.36` opacity while the focused Live TV preview is active. The focused preview card remains full brightness.

## Preserved systems

- vBRDC126 Live TV single-owner compositor focus motion
- 15 / 30 / 60 second / Unlimited Live TV preview duration setting
- configurable Live TV focus ring colors and motion styles
- persistent 96-card virtual corridor and delayed/coalesced recentering
- vBRDC125 catalog artwork identity hardening
- vBRDC124 Live TV menu/catalog transition motion
- Bluetooth VOD ownership and Now Playing
- MediaFlow routing
- Sports direct tune and Sports UNITY systems
- Cast Explorer / Featured Cast hardening
- episode artwork foreground publication
- provider, guide, XMLTV/Gracenote, playback, resume, and debrid routing behavior

## Validation

- vBRDC128 cumulative contract: **163/163**
- production Swift parse: **65/65**
- packaged backend runtime suites: **36/36**
- release identity: `vBRDC128 / 1.0.831 / 831`

Physical Apple TV testing remains authoritative for focus feel and final frame pacing.
