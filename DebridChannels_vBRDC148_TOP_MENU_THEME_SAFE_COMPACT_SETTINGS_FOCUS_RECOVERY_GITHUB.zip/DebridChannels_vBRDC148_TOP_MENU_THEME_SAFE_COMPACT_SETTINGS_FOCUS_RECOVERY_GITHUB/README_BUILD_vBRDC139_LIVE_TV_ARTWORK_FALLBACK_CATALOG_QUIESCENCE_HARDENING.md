# Debrid Channels vBRDC139 — Live TV Artwork Fallback + Catalog Quiescence Hardening

- Release ID: `vBRDC139`
- Marketing version: `1.0.842`
- Apple build: `842`
- Donor/source of truth: packaged `vBRDC138` supplied by the user.
- Comparison donor only: packaged `v987`; no old UI/playback/navigation source was transplanted.

## Scope

1. **Permanent Live TV first-paint fallback**
   - A blank mounted grid tile no longer waits behind a Gracenote/program image before showing channel identity.
   - When a program image exists and a channel logo exists, the bounded loader paints the channel logo first at a 384 px decode budget, then upgrades to the 640 px program/Gracenote image while preserving the logo pixels.
   - Genuine URL failures immediately re-evaluate the existing fallback ladder; no LazyVGrid remount or user scroll is required.
   - While any remote image is still unresolved, the generated channel identity is visible instead of a black spinner-only card.

2. **Foreground/re-entry artwork re-arm**
   - Scene activation directly re-arms retained Live TV artwork requests and increments the mounted artwork generation.
   - If Live TV is active, the existing normal refresh lane is re-entered and selection/artwork are revalidated.
   - There is no repeating artwork poll.

3. **Catalog quiescence / hidden Live TV focus correction**
   - A persistent Live TV root mounted underneath Home/Movies/Shows no longer assigns tile/category FocusState on mount.
   - Entering a catalog clears both real and visual Live TV focus in the same transaction, preventing a background first-card ring from appearing underneath catalog rows.
   - The Live TV focus graph itself remains native; no `selectedTab == .live` `.focusable` restriction from the rejected vBRDC127 architecture was restored.

4. **Hidden cold-launch work reduction**
   - A complete persisted guide no longer launches the vBRDC137 provider/Gracenote validation pass behind a catalog.
   - The persisted guide remains marked for validation; the existing `refreshIfNeeded()` one-shot consumes it when Live TV actually becomes active.
   - The root no longer performs the forced Live TV image bootstrap while mounted under another category.
   - A real cached lineup with no guide rows may still use the bounded cold-hydration exception.

## Preserved

- vBRDC138 Bluetooth VOD session-lifetime ownership.
- vBRDC137 Live TV guide/cache restore and active-surface validation.
- vBRDC136 catalog preview ownership.
- vBRDC135 VOD frame pacing, 4K decode queue, resume checkpoint offloading and invisible Bluetooth controls.
- Live TV focus ring, preview duration/dimming, virtual-window motion engine and top-menu navigation.
- Catalog artwork identity, row geometry, zero-flash catalog-to-Live-TV transition, MediaFlow, Sports, Cast Explorer and provider routing.

Physical Apple TV testing remains authoritative for final focus feel, provider/network availability and frame pacing.
