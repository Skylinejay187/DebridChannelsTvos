# Performance Audit — vBRDC134

## Audit target

Packaged vBRDC133 donor, with emphasis on Live TV grid scrolling, persistent catalog rails, VOD playback, and unnecessary work continuing outside the currently interactive surface.

## Primary finding — nonvisual `Task` handles were presentation state

The donor contained 88 declarations matching nonvisual `Task` handles stored in SwiftUI `@State`. These handles were used for cancellation/ownership only. They were not values rendered by the UI.

Examples included:

- Live TV refresh, focus restoration, covered-surface compaction, schedule-boundary and hydration tasks.
- Catalog row-entry, preview, hero metadata and readiness tasks.
- Root UNITY transition, completeness watchdog and recovery tasks.
- VOD startup, source failover, first-frame probe, resume, timeline recovery, Up Next, Skip Intro, alternate audio, metadata, Quick Guide and focus tasks.
- Search/detail/trailer/Sports/Favorites tasks.

### Cost mechanism

Changing an `@State` value can invalidate the owning SwiftUI view. Therefore code such as `task?.cancel(); task = Task { ... }` could schedule presentation reevaluation even though only an async ownership token changed. On large tvOS trees this is especially undesirable during focus movement and playback startup.

### Correction

Task handles are now retained in `@StateObject` runtime owners with ordinary stored properties and no `@Published` state. The runtime object identity remains stable across view reevaluations, while changes to its task references do not publish view updates.

Result: `88 -> 0` nonvisual `@State Task` handles in `DebridChannelsTVOSApp.swift`.

## Live TV audit

Retained and verified:

- vBRDC126 `LiveTVGridInteractionRuntime` continues to own preview, prefetch, selection-persistence and virtual-window maintenance task handles without publishing.
- Live TV lifecycle tasks now use the same non-publishing ownership model instead of `@State`.
- Covered Live TV still cancels refresh, force-refresh, schedule-boundary and artwork prefetch before compacting the off-screen virtual corridor.
- EPG current-program lookups remain cached to schedule boundaries.
- Artwork decode remains bounded/cancellation-aware.
- No new timer/poll loop was added.

Expected effect: fewer unrelated Live TV view invalidations when focus handoff, refresh cancellation, schedule-boundary replacement or covered-surface compaction bookkeeping changes.

## Catalog audit

Retained and verified:

- Persistent catalog rails remain mounted for decoded/layout reuse.
- vBRDC125 media-identity artwork ownership remains intact.
- vBRDC131/vBRDC133 presentation close and zero-flash Live TV handoff remain intact.
- Row-entry/recovery/preview/hero-metadata Task ownership no longer lives in `@State`.
- Persistent rail prewarm Task ownership no longer lives in `@State`.

Expected effect: task cancellation/replacement around rapid row focus movement no longer creates a second class of SwiftUI invalidation on top of the actual focused-card/row state change.

## VOD playback audit

Retained and verified:

- Heavy VOD chrome remains conditionally unmounted while hidden.
- PlaybackKit overlay bridge keeps only the latest clock snapshot in memory while hidden and does not publish normal ticks into SwiftUI.
- Hidden player clock quiet mode remains at 5 seconds and the KSPlayer helper exits once startup is resolved.
- MediaFlow heartbeat cancels while playback is active.
- VOD-exclusive entry continues cancelling registered nonessential UI/app work.
- Up Next watchdog remains adaptive: slow far from the ending and precise only near Skip Intro/Up Next/EOF windows.
- Timeline metadata recovery remains bounded rather than permanent.

New in vBRDC134:

- 36 VOD Task handles moved to non-publishing ownership.
- AVPlayer time/KVO/end observer tokens moved to non-publishing ownership.
- Unused diagnostics pulse scaffold removed.

Expected effect: arming/cancelling VOD watchdogs and metadata/control tasks no longer invalidates the VOD SwiftUI tree merely because a Task reference changed.

## Timer / loop audit

No `Timer.scheduledTimer` background loop was found in production Swift.

Remaining repeating work was classified as:

1. Required visible presentation — clocks, cast rotation, metadata/advisor rotation while their view is mounted.
2. Required playback lifecycle — adaptive/bounded Up Next, Skip Intro, first-frame/timeline recovery.
3. Required service lifecycle — low-frequency MediaFlow heartbeat, cancelled during playback.
4. Request-scoped retry/drain loops — TorBox/network retry and guide-cache writer drains.
5. Pause-gated visual decoding — dynamic wallpaper.

One concrete unnecessary repeating wake was found: the completed/hidden top-bar ticker still had an active autoconnected 2.6-second publisher. It was replaced by a finite task that terminates when the ticker finishes.

## Deliberately not changed

- Live TV card geometry, focus-ring visuals, preview timing settings or provider routing.
- Catalog row animation/look, artwork layout or focus geometry.
- Playback engines, buffering profiles, KSPlayer fork, AVPlayer behavior, resume semantics, source failover, Up Next logic or Bluetooth controls.
- MediaFlow URLs/routing.
- XMLTV/Gracenote/provider parsing behavior.
- Dynamic wallpaper visual quality settings.

These boundaries keep the performance pass behavior-preserving and avoid trading frame pacing for functional regressions.
