# App-Wide Regression Locks — vBRDC141

vBRDC141 is a narrow Live TV cold/re-entry recovery build from vBRDC140.

Locked invariants:
- Complete persisted Live TV lineup + guide is immediately authoritative and obeys the 3-hour refresh TTL.
- No forced full provider/Gracenote validation solely because a new app process started.
- Top-right Live TV loading spinner represents blocking initial/explicit refresh only, not ordinary cache-backed scheduled work.
- Channel logo fallback is independent of the bounded Gracenote/program-art loader.
- Generated channel identity always exists beneath the remote logo/program layers.
- Hidden Live TV remains quiescent beneath catalog branches.
- Native tvOS Live TV focus graph and exact-card focus ring remain intact.
- Catalog Back/Down/zero-flash handoff behavior remains intact.
- Bluetooth VOD session ownership remains app-session authoritative and invisible.
- VOD frame pacing, 4K queue tuning, resume durability, MediaFlow, Sports, Cast Explorer, catalog preview ownership and artwork identity remain unchanged.

Automated contract: `validation_vBRDC141/test_vBRDC141_contract.py`.
