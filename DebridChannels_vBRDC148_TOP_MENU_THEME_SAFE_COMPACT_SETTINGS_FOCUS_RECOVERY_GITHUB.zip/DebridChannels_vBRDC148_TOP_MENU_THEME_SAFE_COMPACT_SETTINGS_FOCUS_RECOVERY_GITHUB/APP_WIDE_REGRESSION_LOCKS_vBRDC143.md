# vBRDC143 Regression Locks

vBRDC143 is intentionally restricted to the main Live TV grid visual/navigation surface and its focus-performance path.

## Preserved from vBRDC142

- Post-movie/show Live TV artwork recovery generation and bounded remount rehydration.
- Gracenote/program artwork order and independent native channel-logo fallback.
- Cache-first Live TV lineup/guide recovery and three-hour refresh guard.
- Hidden Live TV provider/XMLTV work remains quiescent behind catalog surfaces.
- Live TV playback snapshot/focus-return path.
- Full Guide schedule/program data pipeline and live preview behavior.
- Existing Live Controls categories, Force Refresh Guide, Favorites and Sports actions.
- Existing long-press channel actions.
- Existing focus-ring color/motion and preview-duration settings.
- Movies, Shows, Sports, Favorites, Search, VOD playback, Bluetooth VOD transport, resume, trailers, catalog UI, dynamic wallpaper and MediaFlow routing.

## vBRDC143 navigation locks

- Main grid is 4 × 3 / 12 channels per page.
- RIGHT at a row's right edge advances one page and preserves row.
- LEFT at a row's left edge on page 2+ returns one page and preserves row.
- Page 1 retains double-LEFT Live Controls access.
- Bottom-row DOWN → Guide dock; dock DOWN → full Guide.
- Guide dock UP → exact originating card.
- Full Guide Back/Menu → immediate close.
- Full Guide LEFT twice within the bounded arm interval → close.
- Guide close restores selected channel, corresponding page, and exact card focus.

## Performance locks

- No vertical ScrollView/ScrollViewReader in the main paged grid.
- Routine main-grid focus does not move the 96-card Guide virtual corridor.
- Main-grid artwork prefetch and program-boundary work are limited to the mounted page.
- Focus depth is compositor-owned; card content does not inherit the focus spring.
- No per-card forced `drawingGroup()` on the refreshed Live TV tile.
