from pathlib import Path
import hashlib, plistlib, re, sys
ROOT=Path(__file__).resolve().parents[1]
APP=(ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
IMG=(ROOT/'Sources/RemoteImageFit.swift').read_text()
FRAME=(ROOT/'Sources/UnityFrameRuntime.swift').read_text()
CAT=(ROOT/'Sources/CatalogStore.swift').read_text()
CACHE=(ROOT/'Sources/LiveTVGuideCacheManager.swift').read_text()
MFP=(ROOT/'Sources/MediaFlowProxyRouter.swift').read_text()
PROJ=(ROOT/'project.yml').read_text()
checks=[]
def check(name, cond): checks.append((name, bool(cond)))
def block_between(text,start,end):
    a=text.index(start); b=text.index(end,a); return text[a:b]

# Release/version
with (ROOT/'Sources/Info.plist').open('rb') as f: info=plistlib.load(f)
with (ROOT/'TopShelfExtension/Info.plist').open('rb') as f: top=plistlib.load(f)
check('release id vBRDC121', info.get('DebridChannelsReleaseID')=='vBRDC121' and top.get('DebridChannelsReleaseID')=='vBRDC121')
check('marketing 1.0.824', info.get('CFBundleShortVersionString')=='1.0.824' and top.get('CFBundleShortVersionString')=='1.0.824' and PROJ.count('MARKETING_VERSION: 1.0.824')==2)
check('build 824', info.get('CFBundleVersion')=='824' and top.get('CFBundleVersion')=='824' and PROJ.count('CURRENT_PROJECT_VERSION: 824')==2)


# vBRDC121 compile-only corrections from GitHub/Xcode build 90200857660
check('wallpaper MainActor closure no longer optional-binds promoted self', 'guard let self, self.configuredURL == url, self.decoderGeneration == generation, !self.isPaused' not in APP)
check('HDHomeRun and DVR provider string helper restored', 'private func stringValue(_ row: [String: Any], keys: [String]) -> String' in APP)
check('HDHomeRun generic XML tag helper restored', 'private func tagText(_ body: String, tag: String) -> String' in APP)
check('optional preview channel id is flattened before indexed lookup', 'previewChannelID.flatMap { liveModel.channel(id: $0) } ?? selectedChannel' in APP)

# Event-driven shared frame authority
check('shared revision waiter hub exists', 'private final class UnityFrameRevisionWaiterHub' in FRAME)
check('waiter hub uses continuations', 'CheckedContinuation<Bool, Never>' in FRAME and 'withCheckedContinuation' in FRAME)
check('waiter hub is cancellation aware', 'withTaskCancellationHandler' in FRAME and 'pendingCancellationIDs' in FRAME)
check('frame revision wakes shared waiters', 'revisionWaiters.publish(revision)' in FRAME)
normal_wait=block_between(FRAME,'func waitUntilPermitted(_ lane: Lane','/// Authoritative results')
check('courtesy gate no sleep polling', 'Task.sleep' not in normal_wait and 'waitForChange(' in normal_wait)
check('legacy poll arg retained but unused', '_ = poll' in normal_wait)
durable=block_between(FRAME,'func waitUntilPermittedDurably(_ lane: Lane)','func resetTransientOwnership')
check('durable authoritative gate has no timeout', 'timeout: nil' in durable and 'Task.sleep' not in durable)
check('durable gate respects cancellation', 'Task.isCancelled' in durable)
check('authoritative catalog publications use durable gate', CAT.count('waitUntilPermittedDurably(.interactiveMetadata)') >= 3)
check('decoded image publication uses durable gate', 'waitUntilPermittedDurably(lane)' in IMG)
check('authoritative app publications use durable gate widely', APP.count('waitUntilPermittedDurably(.interactiveMetadata)') >= 10)
check('selected Live TV channel persistence is durable', 'waitUntilPermittedDurably(.persistence)' in APP)

# Catalog invalidation suppression
update_rows=block_between(CAT,'private func updateVisibleCatalogRows','private func schedule')
check('CatalogStore skips identical row publication', 'guard nextRows != rows else { return false }' in update_rows)
rebuild=block_between(APP,'private func rebuildRenderedRows(reason: String)','private func scheduleRenderedRowsRebuild')
check('catalog retained snapshot skips identical projection', 'guard updated != previousRows else { return }' in rebuild)

# Stable Live TV identity / O(1) focus access
liveprogram=block_between(APP,'struct LiveProgram: Identifiable','struct XMLTVGuideChannelSnapshot')
check('LiveProgram id no longer random UUID', 'let id: UInt64' in liveprogram and 'UUID()' not in liveprogram)
check('LiveProgram deterministic identity hashing', 'stableIdentity' in liveprogram or 'stableID' in liveprogram or '1469598103934665603' in liveprogram)
check('Live TV provider builds id lookup', 'private var indexedChannelByID: [Int: LiveTVChannel]' in APP)
check('Live TV provider builds position lookup', 'private var channelBrowsePositionIndex: [String: [Int: Int]]' in APP)
check('focused channel lookup is O(1)', 'func channel(id: Int) -> LiveTVChannel? { indexedChannelByID[id] }' in APP)
check('focused position lookup is O(1)', 'func browsePosition(of channelID: Int, category: String) -> Int?' in APP)

# Live TV publication batching/equality
check('channel publication equality guard exists', 'private func publishChannelsIfChanged(_ next: [LiveTVChannel]) -> Bool' in APP and 'guard next != channels else { return false }' in APP)
check('guide publication equality guard exists', 'private func publishGuideProgramsIfChanged(_ next: [String: [LiveProgram]]) -> Bool' in APP and 'guard next != guidePrograms else { return false }' in APP)
check('guide batches merge atomically', 'private func mergeGuideProgramsAtomically' in APP)
check('no direct per-key guide publication remains', re.search(r'guidePrograms\s*\[[^\]]+\]\s*=', APP) is None)

# XMLTV/Gracenote parsing
parser=block_between(APP,'private enum LiveTVXMLTVBackgroundParser','@MainActor\nfinal class LiveTVSourceModel')
check('XMLTV parser has one per-parse context', 'private final class ParseContext' in APP and 'let context = ParseContext()' in APP)
check('XMLTV stores program once by channel id', 'programsByChannelID[channelID, default: []].append' in APP)
check('XMLTV uses reverse alias index', 'channelIDsByLookupKey' in APP)
check('XMLTV parse is detached utility work', 'LiveTVXMLTVBackgroundParser.parse(' in APP and 'Task.detached(priority: .utility)' in APP)
check('legacy main-thread XMLTV date helpers absent', 'private func xmltvDate(' not in APP and 'private func guideTimeText(' not in APP)
check('XMLTV lookup regexes compiled once on model', 'private static let xmltvLookupDigitRegex' in APP and 'private static let xmltvLookupNumberedNameRegex' in APP)
check('unused legacy channel-name parser removed', APP.count('channelLookupNames(_ xml: String)') == 0)

# M3U/Xtream CPU work off MainActor
check('M3U parsing has Sendable draft', 'struct M3ULiveDraft: Sendable' in APP)
check('M3U parsing uses detached utility worker', 'Self.parseM3UDrafts(text, source: source, baseURL: baseURL)' in APP and 'Task.detached(priority: .utility)' in APP)
check('M3U uses one attribute regex pass', 'private nonisolated static func parseM3UDrafts' in APP and 'attributeRegex' in APP)
check('Xtream short EPG parser is nonisolated', 'private nonisolated static func parseXtreamShortEPGOffMain' in APP)
check('Xtream short EPG parse is detached', 'Self.parseXtreamShortEPGOffMain(data: data, now: now, cutoff: cutoff)' in APP)
check('legacy per-field Xtream date helper absent', 'xtreamEPGDate' not in APP)

# Large guide cache IO leaves MainActor
check('guide cache owns utility persistence queue', 'DispatchQueue(label: "com.debridchannels.livetv-guide-cache", qos: .utility)' in CACHE)
check('channel persistence coalesces latest snapshot', 'pendingChannels' in CACHE and 'channelWorkerScheduled' in CACHE and 'drainChannelWrites()' in CACHE)
check('guide persistence coalesces latest snapshot', 'pendingGuide' in CACHE and 'guideWorkerScheduled' in CACHE and 'drainGuideWrites()' in CACHE)
check('large JSON encode occurs inside writer drain', 'JSONEncoder().encode(cached)' in CACHE and 'persistenceQueue.async' in CACHE)

# Dynamic wallpaper event-driven pausing
check('wallpaper pause gate exists', 'private final class DynamicWallpaperPauseGate' in APP)
wallgate=block_between(APP,'private final class DynamicWallpaperPauseGate','private final class DynamicWallpaperAnimatedUIImageView')
check('wallpaper pause gate continuation based', 'CheckedContinuation<Bool, Never>' in wallgate and 'waitUntilRunning()' in wallgate)
animated=block_between(APP,'private final class DynamicWallpaperAnimatedUIImageView','private struct DynamicWallpaper')
check('animated wallpaper waits on pause signal', 'await self.pauseGate.waitUntilRunning()' in animated)
check('old 45ms paused poll removed from wallpaper decoder', '45_000_000' not in animated)

# Episode/date metadata repeated construction removed
check('episode metadata parser pool exists', 'private final class DCEpisodeMetadataParser' in APP)
episode_block=block_between(APP,'private final class DCEpisodeMetadataParser','private func dcNextUpcomingEpisodeAlertItem')
check('episode parser reuses date formatters', 'alternateDateFormatters' in episode_block and 'displayFormatter' in episode_block)
check('episode parser reuses season/date regexes', 'ymdRegex' in episode_block and 'seasonEpisodeRegexes' in episode_block)
check('episode date presentation no longer constructs formatter per call', 'DateFormatter()' not in block_between(APP,'private func dcEpisodeDatePresentation','private func dcParsedSeasonEpisode'))
check('episode alert scanner pools date parser objects', 'private static let episodeAlertDateParserLock = NSLock()' in CAT and 'episodeAlertAirDateFormatters' in CAT and 'episodeAlertFractionalISOFormatter' in CAT)
scanner_parse=block_between(CAT,'private static func parseEpisodeAirDate','private static func sendEpisodeNotification')
check('episode alert scan parse no per-episode formatter construction', 'DateFormatter()' not in scanner_parse and 'ISO8601DateFormatter()' not in scanner_parse)

# VOD high-frequency state write guards
check('AVPlayer duration writes equality guarded', APP.count('abs(durationSeconds -') >= 3)
check('AVPlayer playing-state writes equality guarded', 'if isPlaying != nextPlaying { isPlaying = nextPlaying }' in APP)

# v118 performance/visual behavior preserved
check('heavy-load opt-in defaults false', 'var deferHeavyLoadDuringNavigation: Bool = false' in IMG)
check('4K decorative surfaces keep deferred cache-miss option', APP.count('deferHeavyLoadDuringNavigation: true') == 4)
check('35-second catalog preview retained', 'CMTime(seconds: 35.0' in APP and 'finishCurrentPreview(reason: "35-second cap")' in APP)
check('Bluetooth Now Playing retained', 'MPNowPlayingInfoCenter.default().nowPlayingInfo' in APP and 'MPRemoteCommandCenter.shared()' in APP)
check('MediaFlow LAN bootstrap route retained', 'let endpoints = epg ? ["/proxy/epg", "/proxy/stream"] : ["/proxy/stream"]' in MFP)
check('episode alert 530x176 retained', '.frame(width: 530, height: 176' in APP)
check('episode alert 18pt screen edge retained', 'private let newEpisodeAlertScreenEdgeInset: CGFloat = 18' in APP)

# vBRDC119 additive VOD Cast manual navigation
check('VOD cast has manual navigation token', 'featuredCastManualNavigationToken' in APP and 'castManualNavigationToken:' in APP)
check('focused VOD cast routes LEFT and RIGHT manually', 'case .left:\n                moveFeaturedCast(by: -1)' in APP and 'case .right:\n                moveFeaturedCast(by: 1)' in APP)
check('manual cast navigation wraps through image-backed members', 'private func moveFeaturedCast(by delta: Int)' in APP and 'members.count > 1' in APP and 'featuredCastSpotlightIndex = next' in APP)
check('manual cast navigation resets existing 7-second clock only', r'manual:\(manualNavigationToken)' in APP and '7_000_000_000' in APP)
check('cast navigation arrows are transient focus hint', 'castNavigationHintVisible' in APP and '2_200_000_000' in APP and 'chevron.left' in APP and 'chevron.right' in APP)
check('cast hint stays inside portrait surfaces', 'fullPosterCastNavigationHint' in APP and 'compactCastNavigationHint' in APP)
check('cast accessibility advertises left-right browse', 'Press Left or Right to browse cast. Press Select to open Cast Explorer.' in APP)

# Critical visual/provider files that v119 intentionally does not rewrite
expected={
'Sources/UnityCatalogVisualSystem.swift':'e5e4a14c0b61f11f46c2866ed7b0e7f5d14cb46f00269411fc6766defffcd7c3',
'Sources/UnityAnimationCoordinator.swift':'2206eabc3ce477f02de2116b3035b4bae96ee4dca7ef7e2135b1c68cbf820132',
'Sources/MediaFlowProxyRouter.swift':'eaedc162e1b1eff687207b412fb2157cb3168da047b9cf7724d991a9a9bf3c0c',
'Sources/CastExplorerService.swift':'eb465f7a9dfde71e5136e7e14e9931de54159b86ea2b90383e0290961f697b4a',
'Sources/SportsCenterViewModel.swift':'dfaa96dc3e8f27dc11a11cbf20394f02c1dbb01d1b66c7607cd15fefd862598f',
'Sources/PlaybackKit/PlaybackKitFoundation.swift':'b9f705ef07d1c7c0ee0e8143ebc75c389181f28e2b87f0ed8a26d433dfc574ad',
}
for rel,want in expected.items():
    got=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
    check(f'locked donor unchanged: {Path(rel).name}', got==want)

# vBRDC121 Bluetooth VOD ownership recovery
check('Bluetooth snapshot retained for reassertion', all(x in APP for x in ['activeTitle: String', 'activeDuration: Double', 'activeElapsed: Double', 'activeIsPlaying: Bool']))
check('Bluetooth route changes reassert VOD ownership', 'AVAudioSession.routeChangeNotification' in APP and 'reassertActiveVODOwnership(reason: "audio route changed")' in APP)
check('audio interruption end reasserts VOD ownership', 'AVAudioSession.interruptionNotification' in APP and 'AVAudioSession.InterruptionType(rawValue: raw) == .ended' in APP)
check('media service reset reasserts VOD ownership', 'AVAudioSession.mediaServicesWereResetNotification' in APP and 'reassertActiveVODOwnership(reason: "media services reset")' in APP)
check('app activation reasserts VOD ownership', 'UIApplication.didBecomeActiveNotification' in APP and 'reassertActiveVODOwnership(reason: "app became active")' in APP)
check('first real VOD frame reasserts ownership', 'reassertActiveVODOwnership(reason: "VOD first frame")' in APP)
check('VOD scene activation reasserts ownership', 'reassertActiveVODOwnership(reason: "VOD scene active")' in APP)
check('reassertion remains event driven no Bluetooth timer', 'installSystemOwnershipObserversIfNeeded()' in APP and 'systemObserverTokens' in APP)
check('release stays UUID guarded', 'if activeSessionID == sessionID {' in APP and 'releaseVODSession(playbackPresentationID)' in APP)

passed=sum(ok for _,ok in checks)
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
print(f'\n{passed}/{len(checks)} checks passed')
if passed != len(checks): sys.exit(1)
