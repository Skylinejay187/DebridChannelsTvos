# Debrid Channels vBRDC133 — Catalog → Live TV Zero-Flash Handoff

Release: **vBRDC133**  
Marketing version: **1.0.836**  
Apple build: **836**  
Donor: packaged **vBRDC132 Top Menu Down → Live TV Return**

## Physical-device correction

The user video exposed a one-frame catalog resurrection after this sequence:

1. Open Home / Movies / TV Shows rows.
2. Press Back/Menu so the catalog closes and the selected top-menu item owns focus.
3. Press Down to return to the persistent Live TV grid.

The focus routing in vBRDC132 was correct, but `synchronizeUnityCatalogBranchPresentation` still treated the previous selected tab as a visibly presented catalog. When the catalog compositor was already at progress `0`, it forcibly reset progress to `1` and then animated back to `0`. That created the brief row flash seen in the video.

vBRDC133 removes that resurrection path:

- A catalog compositor already at zero visibility is cleared and handed directly to Live TV.
- A genuinely visible catalog still reverses smoothly from its current progress.
- No hidden catalog is ever forced from `0 → 1 → 0` during top-menu Down.
- vBRDC132 universal Down → Live TV routing is preserved unchanged.
- vBRDC131 catalog Back/dismissal behavior is preserved unchanged.
- The corrected Live TV focus ring, grid motion engine, preview controls, and artwork identity hardening are untouched.

## Validation

- cumulative contract: **192/192 PASS**
- production Swift parse: **65/65 PASS**
- backend runtime suites: **36/36 PASS**
- version identity: PASS
- locked high-risk donor sources: PASS
- ZIP integrity: PASS

GitHub Actions/Xcode and physical tvOS hardware remain authoritative for Apple SDK compilation and final focus-engine behavior.
