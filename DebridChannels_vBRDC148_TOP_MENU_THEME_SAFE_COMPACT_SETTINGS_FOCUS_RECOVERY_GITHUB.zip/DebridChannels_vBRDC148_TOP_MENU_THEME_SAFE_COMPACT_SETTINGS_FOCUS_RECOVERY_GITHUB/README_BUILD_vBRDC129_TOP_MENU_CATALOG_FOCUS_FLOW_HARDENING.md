# Debrid Channels vBRDC129 — Top Menu + Catalog Focus Flow Hardening

Release: `vBRDC129`  
Marketing version: `1.0.832`  
Apple build: `832`

## Donor / scope

vBRDC129 is built directly from packaged vBRDC128. The vBRDC128 native Live TV focus graph, exact card-owned focus ring, stronger preview dim, vBRDC126 Live TV motion engine, and vBRDC125 catalog artwork identity hardening remain intact.

This is a narrow navigation/focus correction. No catalog visuals, Live TV card geometry, provider routing, playback logic, MediaFlow behavior, Sports tuning, resume behavior, or artwork-provider logic was redesigned.

## Correct navigation contract

### Top-menu selection remains the selected category

The selected top-menu tab and the currently focused content are now treated as separate state.

- Selecting Home, Movies, or TV Shows keeps that tab selected and automatically enters its normal catalog rows.
- Re-selecting the already-active Home/Movies/TV Shows tab from the top menu also enters the rows immediately even though `selectedTab` does not change.
- Selecting Live TV keeps focus on the Live TV top-menu item until the user presses Down into the already-mounted native grid.

### Back from catalog rows returns to the same top-menu item

Back/Menu from Home, Movies, or TV Shows no longer changes `selectedTab` to Live TV.

Instead it:

1. cancels delayed catalog row focus recovery,
2. clears real catalog row FocusState without animation,
3. keeps the current category selected,
4. focuses that selected top-menu item.

The catalog remains the visible surface behind the top menu. Live TV is not used as a fallback focus destination.

### Live TV cannot reclaim focus while another section owns navigation

Whenever Live TV stops being the selected surface, its real tile/category/guide FocusState is cleared immediately while the existing UNITY visual pin preserves the outgoing card frame. The hidden native Live TV grid stays mounted and focusable for later entry, but it cannot compete with the incoming catalog surface.

### One Down-edge focus destination

Down from the top menu now emits exactly one content focus request:

- Live TV -> `liveTVMenuFocusEntryToken` only.
- Other selected sections -> the normal `contentFocusToken` only.

This prevents the hidden persistent catalog rail from being awakened during a Live TV Down-entry.

## Preserved vBRDC128 / vBRDC126 behavior

- native Live TV grid focusability
- exact card-owned 16-point continuous focus ring
- configurable Live TV ring colors / glow animations
- stronger Live TV preview dim at 0.36 for surrounding cards
- 15 / 30 / 60 second / Unlimited preview length setting
- single-owner Live TV compositor motion
- 96-card virtual focus corridor and coalesced recentering
- vBRDC125 catalog artwork identity hardening
- Bluetooth VOD controls / Now Playing ownership
- MediaFlow routing
- Gracenote/XMLTV guide behavior
- Sports direct tune
- Cast Explorer / Featured Cast hardening
- playback, debrid, source-selection, and resume behavior

## Validation

- cumulative regression contract: **167/167**
- production Swift parse: **65/65**
- backend runtime suites: **36/36**
- release identity: `vBRDC129 / 1.0.832 / 832`
- critical unchanged donor hashes: **PASS**
- changed-source whitespace check: **PASS**

GitHub Actions/Xcode and physical Apple TV testing remain authoritative for Apple SDK compilation and final tvOS focus feel.
