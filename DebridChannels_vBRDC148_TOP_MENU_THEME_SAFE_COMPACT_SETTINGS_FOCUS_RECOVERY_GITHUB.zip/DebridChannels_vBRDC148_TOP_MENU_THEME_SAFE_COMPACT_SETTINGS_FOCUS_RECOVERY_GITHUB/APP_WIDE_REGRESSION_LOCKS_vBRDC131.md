# vBRDC131 App-Wide Regression Locks

vBRDC131 adds these locks on top of the full cumulative contract:

1. Home / Movies / TV Shows selection is separate from catalog-row presentation.
2. Back/Menu from an open catalog must not mutate `selectedTab`.
3. Back/Menu must close the actual UNITY catalog presentation, not merely clear row focus.
4. The outgoing catalog card must remain at focused geometry through the final visible close frame.
5. Back/Menu must not set `focusedRow = nil` before the branch is invisible.
6. Back/Menu must not temporarily make the rail non-focusable as a focus-transfer workaround.
7. Top-menu focus is requested once, only after the catalog reverse transition settles to invisible.
8. The selected Home / Movies / TV Shows top-menu category remains highlighted after dismissal.
9. Selecting that same catalog tab again re-presents rows automatically.
10. Down from a selected catalog top-menu item re-presents rows before requesting catalog content focus.
11. Hidden catalog rows cannot be reclaimed by delayed focus-recovery work.
12. Live TV remains a native explicit Down-entry destination and is never a fallback for catalog Back.
13. The vBRDC128 exact 16-point continuous Live TV card-owned focus ring remains unchanged.

Expected physical flow:

- Select Home / Movies / TV Shows -> rows open and focus normally.
- Back/Menu once -> rows visibly close; selected top-menu item receives focus.
- Select that item again or press Down -> rows reopen normally.
- Select Live TV -> top menu remains on Live TV until Down.
- Down -> native Live TV grid enters and scrolls normally.
