# Debrid Channels vBRDC144 — Regression Locks

vBRDC144 is a corrective child of packaged vBRDC143. All earlier regression locks remain authoritative.

Additional locks for this build:

- Main Live TV remains a 4x3 / 12-card paged surface; provider and Guide data loading are unchanged.
- Reaching a fourth/right-edge card must leave that card stably focusable. Page advance requires another RIGHT from the same card.
- Reaching a first/left-edge card on page 2+ must leave that card stably focusable. Previous-page navigation requires another LEFT from the same card.
- Page 1 keeps the existing double-LEFT Live Controls behavior.
- Bottom-row first DOWN must keep the exact channel card focused and arm Guide only; second DOWN from that card opens Guide.
- The Guide hint must never enter the tvOS focus graph.
- Full Guide closes with Back/Menu or double-LEFT and restores the exact selected channel/page.
- Main-grid card chrome has no per-card LIVE badge and no left accent spine.
- Main Live TV title is `LIVE TV`; the degree mark and `NOW BROADCASTING` capsule are removed.
- vBRDC142 post-VOD Gracenote/channel-artwork rehydration remains intact.
