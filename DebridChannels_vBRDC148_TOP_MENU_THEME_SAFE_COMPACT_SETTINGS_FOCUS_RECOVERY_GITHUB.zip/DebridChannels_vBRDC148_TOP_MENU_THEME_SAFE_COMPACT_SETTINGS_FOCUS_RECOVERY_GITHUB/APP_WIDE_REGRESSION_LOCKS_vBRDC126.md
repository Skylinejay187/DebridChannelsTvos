# App-Wide Regression Locks — vBRDC126

vBRDC126 is additive to packaged vBRDC125 and extends the cumulative contract to **147 checks**.

## New Live TV grid locks

- One dedicated `LiveTVGridFocusMotionHost` owns focused scale/offset/shadow.
- Tile content rejects inherited focus animation with a scoped SwiftUI transaction.
- Duplicate focused ring/shadow animation ownership is absent from `LiveTVGridTileContent`.
- Focus ring animation remains a focused-only leaf.
- Ring palette includes White/Cyan/Orange/Blue/Purple/Green/Red/Gold.
- Ring motion includes Classic Glow/Steady Ring/Soft Pulse/Breathing Glow.
- Preview lifetime supports 15/30/60 seconds and Unlimited.
- Preview dimming affects only non-preview cards.
- New settings exist in Settings, backup/restore, stable-feature allowlist and cloud-backup allowlist.
- Preview/prefetch/persistence/window task owners and guide warmup generation remain outside SwiftUI `@State`.
- Routine 96-card virtual-window maintenance is coalesced/deferred with 20-channel maintenance and 8-channel emergency buffers.
- Valid focus movement has one preview cancel/re-arm owner.
- Selection bookkeeping is animation-disabled after native focus movement.
- Ordinary grid focus cannot invoke full-guide preview warmup.

## Preserved cumulative locks

The vBRDC126 contract retains every vBRDC125 cumulative check covering:

- vBRDC125 catalog artwork media-identity ownership and persistent rail motion.
- vBRDC124 Live TV focus handoff, bounded artwork/decode cancellation, EPG caches and indexed category counts.
- vBRDC123 foreground VOD/cast/episode artwork behavior.
- vBRDC121 Bluetooth VOD ownership/media controls.
- App-wide frame authority, catalog publication equality, Live TV stable indexes/publication batching, XMLTV parsing, guide-cache IO, dynamic wallpaper pause behavior, episode/date parser reuse, AVPlayer state guarding and 35-second catalog previews.
- Locked donor files for Unity catalog visuals/coordinator, MediaFlow, Cast Explorer service, Sports and PlaybackKit.

Run:

```bash
python validation_vBRDC126/test_vBRDC126_contract.py
```

Expected: `147/147 checks passed`.
