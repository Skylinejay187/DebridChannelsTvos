# App-Wide Regression Locks — vBRDC128

vBRDC128 preserves all cumulative vBRDC126 locks and adds the following release-critical contracts.

1. The vBRDC127 `topMenuSelectedTabFocusOwner` architecture must not return.
2. Live TV cards must retain the vBRDC126 native `.focusable(!quickWindowVisible && !quickWindowFocusHandoffActive && channelActionChannelID == nil)` contract.
3. Live TV category controls must not be disabled merely because another persistent UNITY branch is selected.
4. A top-menu click may suppress automatic content-focus recovery, but it must not mutate focusability of the destination content.
5. Pressing Down from the top menu must immediately clear the transient menu hold.
6. Down into Live TV must focus the already-mounted native grid without rebuilding or disabling its focus graph.
7. Late catalog/provider publication must not steal focus while the selected top-menu button is intentionally held.
8. Leaving Live TV from the top menu may clear old Live TV FocusState, but only as a real-focus cleanup; the existing visual pin remains presentation-only.
9. The Live TV focus ring must be owned by `LiveTVGridTileContent`, not by the outer transform host.
10. Ring and card must use the exact same `RoundedRectangle(cornerRadius: 16, style: .continuous)` geometry.
11. Soft Pulse / Breathing Glow must not scale or deform the ring silhouette.
12. Preview dimming must affect only non-preview cards and remain stronger than vBRDC126 (`0.36` versus `0.56`).
13. All vBRDC126 preview-duration, ring-color, ring-motion, virtual-corridor, cancellation, and frame-budget contracts remain active.
