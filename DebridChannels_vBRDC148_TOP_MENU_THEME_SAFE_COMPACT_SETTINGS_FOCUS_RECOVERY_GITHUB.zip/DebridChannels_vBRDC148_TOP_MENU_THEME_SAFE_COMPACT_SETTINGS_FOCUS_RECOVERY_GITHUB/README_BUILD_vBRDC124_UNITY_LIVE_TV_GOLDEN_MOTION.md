# Debrid Channels vBRDC124 — UNITY Live TV Golden Motion

- Release ID: `vBRDC124`
- Marketing version: `1.0.827`
- Apple build: `827`
- Donor: packaged `vBRDC123` only

## Release goal

This is the release-polish continuation of the vBRDC123 Works-chat audit. It does not redesign Live TV or catalogs. It removes animation/focus contention and avoidable main-thread work so opening a UNITY surface, closing it, and returning to the same Live TV card behave as one continuous interaction.

## Root causes found

1. Live Controls visibility, grid focus removal, panel focus ownership, and implicit SwiftUI animation could overlap. tvOS could therefore reconcile focus while the panel itself was still moving.
2. The selected Live TV card depended only on real `FocusState`, so it could visually shrink during an ownership handoff and grow again when focus returned.
3. Catalog-to-Live return could allow tvOS to restore real tile focus before the covering catalog transition had fully settled.
4. Opening Live Controls recomputed category counts by filtering the provider lineup, multiplying provider-size work at the exact frame the panel started moving.
5. `currentProgram(for:)` could repeatedly scan EPG rows for many visible cards during focus movement.
6. Cancelled Live TV artwork jobs could remain queued behind the two-slot ImageIO decode gate, creating a cancellation convoy during fast D-pad navigation.
7. Secondary Live TV artwork still contained a 35 ms publication polling path and several small playback/guide images could decode at source resolution.
8. Repeated success/failure bookkeeping could publish unchanged artwork state.

## Golden-motion changes

- Added a visual-focus pin independent of tvOS `FocusState`. The selected Live TV card stays visually focused through Live Controls and catalog ownership handoffs.
- Added a separate surface-focus handoff guard so automatic focus restoration cannot release the pin early during catalog close.
- Live Controls opening now performs focus preflight without animation, animates only panel visibility, then enables panel focus at a clean handoff point.
- Live Controls closing reverses the panel first, keeps the grid outside the focus graph during travel, restores the exact selected channel without animation, yields one frame, then releases the visual pin.
- Removed duplicate delayed focus retries and the broad implicit grid/panel animation that could retarget movement mid-flight.
- Tuned catalog open/close curves and the shared UNITY transition profile so the visual branch finishes before focus binding on return. Geometry, scale values, content, and navigation behavior are unchanged.
- Live TV card focus spring remains the same visual treatment but is more interruptible (`response 0.30`, `damping 0.92`, blend `0.10`).
- Live TV tile content is Equatable so unchanged card subtrees can skip recomputation.

## Frame-budget changes

- Live Controls category counts now reuse the provider indexes instead of rescanning the full channel lineup per category.
- Current-program resolution now caches each channel to the next real EPG schedule boundary and invalidates when guide data changes.
- Provider refresh prunes channel-key/current-program caches to live channel identities.
- The two-slot Live TV ImageIO decoder is cancellation-aware; cancelled waiters are removed immediately instead of consuming future decode turns.
- Live TV decoded-image publication now waits on the shared event-driven UNITY revision signal rather than private 35 ms polling.
- Small playback/Quick Guide/channel-logo surfaces use bounded ImageIO decoding (256–768 px according to presentation) instead of unbounded source-resolution decode.
- Artwork success/failure state is published only when the set actually changes.

## Preserved behavior

- vBRDC123 VOD foreground cast rotation and episode artwork hardening are preserved.
- vBRDC121 Bluetooth VOD media-control ownership recovery is preserved.
- MediaFlow routing, Gracenote/provider routing, source selection, playback ownership, Sports, Favorites, resume logic, Dynamic Wallpaper visuals, and all catalog/card geometry remain unchanged.
- `UnityCatalogVisualSystem.swift`, `UnityAnimationCoordinator.swift`, `MediaFlowProxyRouter.swift`, `CastExplorerService.swift`, `SportsCenterViewModel.swift`, and `PlaybackKitFoundation.swift` are donor-hash locked unchanged.

## Validation

- vBRDC124 cumulative regression contract: **119/119 passed**.
- Production Swift syntax parse: **65/65 files passed**.
- Backend runtime suites: **36/36 passed** (Alternate Audio Bridge 15, Alternate Audio Discovery 8, Backup Streaming 6, TorBox Usenet Search 7).
- App and Top Shelf version/plist consistency passed: `vBRDC124 / 1.0.827 / 827`.
- GitHub Actions/Xcode remains authoritative for the tvOS Release compile.
- Physical Apple TV remains authoritative for measured frame pacing and subjective remote/focus feel; this Linux validation environment cannot claim a measured 60 FPS result.
