# App-Wide Regression Locks — vBRDC135

Cumulative automated contract: **223/223 passed**.

New vBRDC135 locks cover:

- No visible Bluetooth VOD toggle in Settings or player panels.
- Retired Bluetooth preference cannot gate active VOD media-button ownership.
- Bluetooth transport remains active-session UUID scoped and Now Playing remains decoder-clock refreshed without a new SwiftUI timer.
- Full-screen VOD uses the physical-display-paced scheduling lane while Live TV/trailers retain donor scheduling.
- 4K decoded-frame queue is bounded to 16/18 rather than donor 24.
- Live TV grid artwork uses the 640 decode/prefetch bucket.
- Catalog focused/trailing cards use 1024/384 decode buckets while persistent geometry/identity stays intact.
- Normal resume-cache mutation is utility-queue owned.
- Durable resume saves drain queued checkpoints before committing the newest state.
- Resume flush snapshots after the writer queue drains.

All prior vBRDC134 cumulative locks remain included in `validation_vBRDC135/test_vBRDC135_contract.py`.
