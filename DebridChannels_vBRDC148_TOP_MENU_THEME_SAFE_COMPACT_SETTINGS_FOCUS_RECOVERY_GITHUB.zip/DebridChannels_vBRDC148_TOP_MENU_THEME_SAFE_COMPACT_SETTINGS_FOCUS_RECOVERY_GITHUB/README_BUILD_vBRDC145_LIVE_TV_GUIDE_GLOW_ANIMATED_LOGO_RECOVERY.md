# Debrid Channels vBRDC145 — Live TV Guide Glow / Animated Header / Preview Recovery

Base: exact packaged `vBRDC144_LIVE_TV_FOCUS_NAVIGATION_POLISH_GITHUB`.
Release: `vBRDC145`  
Marketing: `1.0.848`  
Apple build: `848`

This build is intentionally scoped to the Live TV grid/Guide presentation requested after vBRDC144.

## Live TV grid
- Keeps the existing 4x3 / 12-card paged grid, edge two-press paging, card geometry, focus lift, provider loading, Gracenote loading, channel-logo fallback, and playback route unchanged.
- Fixes the bottom-row focused-card preview regression: the first DOWN that arms Guide no longer destroys the existing one-shot muted preview. The preview is still torn down when the full Guide actually opens.
- Guide prompt now uses a continuously glowing cyan/blue presentation while visible and automatically disappears after 30 seconds. It remains presentation-only and never enters the tvOS focus graph.
- Re-arming Guide from a bottom-row card re-shows the prompt and restarts its 30-second visibility window.

## Full Guide
- Adds a non-focusable exit hint while Guide is open: `BACK/MENU TO EXIT • LEFT LEFT TO EXIT`.
- Exit hint automatically disappears after 30 seconds.
- Existing Back/Menu immediate exit and deliberate double-LEFT exit logic remain unchanged.

## Live TV header
- Replaces the vBRDC144 static header by default with an actual SwiftUI animated logo (not a mockup/image overlay).
- Two selectable styles inspired by the supplied references:
  - `Signal TV`
  - `Retro Tube`
- Both use isolated compositor-only pulse/shine animation and pause when the persistent Live TV root does not own the visible surface.
- Settings → Live TV adds:
  - `Animated Live TV Header Logo` On/Off
  - `Live TV Header Logo Style` selector
- Turning the animated logo Off uses a clean text-only LIVE TV header.
- New preferences participate in backup/restore, stable UI defaults, and release-security allowlisting.

No Movies, TV Shows, Sports, VOD playback, Live TV provider/network, Gracenote/XMLTV, MediaFlow, or unrelated app UI logic is intentionally changed.
