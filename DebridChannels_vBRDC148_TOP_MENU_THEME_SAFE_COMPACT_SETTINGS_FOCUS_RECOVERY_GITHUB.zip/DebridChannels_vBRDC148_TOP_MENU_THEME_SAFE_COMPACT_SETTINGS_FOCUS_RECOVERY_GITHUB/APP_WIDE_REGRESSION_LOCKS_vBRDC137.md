# App-Wide Regression Locks — vBRDC137

Cumulative automated contract: **237/237 passed**.

New vBRDC137 locks cover:

- A disk-restored Live TV guide is marked for fresh process validation.
- The normal three-hour TTL cannot suppress that cold-launch validation.
- Cold-launch validation executes a fresh configured-source refresh.
- Failed startup validation remains armed for a later Live TV entry.
- The hidden persistent Live TV root may prevalidate the disk guide once before the user enters Live TV.
- Cold-start guide completion directly re-arms already-mounted Live TV artwork owners.
- Interactive guide publication directly re-arms mounted artwork before publishing the artwork refresh generation.
- Forced artwork bootstrap reinforces blank retained requests without requiring a grid scroll.

All vBRDC136 cumulative locks are retained in `validation_vBRDC137/test_vBRDC137_contract.py`.
