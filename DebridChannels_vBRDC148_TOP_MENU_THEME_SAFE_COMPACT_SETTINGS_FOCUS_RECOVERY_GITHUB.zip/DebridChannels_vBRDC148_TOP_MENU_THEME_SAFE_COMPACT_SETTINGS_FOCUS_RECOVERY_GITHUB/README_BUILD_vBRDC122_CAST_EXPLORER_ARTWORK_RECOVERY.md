# Debrid Channels vBRDC122 — Cast Explorer Artwork Recovery

- Release ID: `vBRDC122`
- Marketing version: `1.0.825`
- Apple build: `825`
- Donor: packaged `vBRDC121`

## Physical-test regression addressed

Cast Explorer could show the person biography/facts while the profile portrait and some Known For / Movies / TV Shows posters remained blank during full-screen VOD. The vBRDC106 `publishDuringPlayback` flags were still present and `CastExplorerService.swift` remained unchanged, so source-presence regression checks passed even though the physical runtime behavior had regressed.

## Root cause / hardening

vBRDC119 made shared artwork publication waits durable/event-driven. That is correct for authoritative background work, but a user-opened Cast Explorer bitmap could finish decoding while playback/navigation owned the frame and then remain behind that durable waiter. Separately, hidden base-VOD chrome cleanup still had authority to cancel shared artwork work even if an independently visible VOD subsurface remained mounted.

vBRDC122 keeps the global vBRDC119 frame architecture and adds a narrowly scoped visible-playback policy only for Cast Explorer's bounded artwork:

1. Cast Explorer profile/fallback portraits (768 px) and credit posters (512 px) opt into `forceVisiblePlaybackPublication`.
2. These images wait up to 0.45 s as a navigation courtesy. If playback is still the active foreground scene, the visible bounded bitmap is then allowed to publish instead of remaining blank indefinitely.
3. This fallback is blocked if the scene is inactive, trailer/source-opening owns the session, or the Cast Explorer owner has been cancelled/superseded.
4. Opening Cast Explorer cancels any stale root VOD auto-hide task before artwork requests begin.
5. When base VOD chrome hides, shared decorative-artwork cleanup is skipped while Cast Explorer, Episode Browser, or a pending VOD source-switch surface is still visibly mounted.
6. Ordinary VOD Featured Cast/Production rotation, catalog 4K artwork, Dynamic Wallpaper, Live TV, Sports, Favorites, and background prefetch keep the existing vBRDC119 frame gates unchanged.

## Preserved behavior

- vBRDC121 Bluetooth VOD Play/Pause/Now Playing ownership recovery remains intact.
- vBRDC119 event-driven frame runtime remains intact globally.
- vBRDC118 4K heavy-load deferral remains intact.
- vBRDC106 visible-only VOD Cast/Production rotation remains intact.
- `CastExplorerService.swift` is unchanged.
- PlaybackKit, MediaFlow, Live TV/Gracenote, resume, source selection, and catalog motion systems are unchanged.

## Validation

- vBRDC122 targeted regression contract: 96/96 passed.
- Production Swift syntax parse: 65/65 files passed.
- App and Top Shelf plist syntax/version checks passed.
- GitHub Actions/Xcode remains the authoritative tvOS Release compile.
- Physical Apple TV remains authoritative for Cast Explorer artwork/compositor behavior.
