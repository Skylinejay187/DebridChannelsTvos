# Debrid Channels vBRDC134 — App-Wide Runtime Quiescence Hardening

- Release ID: `vBRDC134`
- Marketing version: `1.0.837`
- Apple build: `837`
- Donor/source of truth: packaged `vBRDC133_CATALOG_TO_LIVE_TV_ZERO_FLASH_HANDOFF_GITHUB`
- Scope: performance/runtime cleanup only; no visual redesign, navigation rewrite, provider-routing change, playback-policy change, or feature removal.

## Why this build exists

The vBRDC133 navigation/focus behavior is retained. This pass audited Live TV, catalog rails, VOD playback, Search, detail surfaces, Sports, Favorites, trailers, and root lifecycle work for asynchronous bookkeeping that could keep invalidating SwiftUI even when the bookkeeping itself had no visual meaning.

The largest concrete finding was app-wide: the donor still stored **88 `Task` handles** as `@State` inside SwiftUI views. Assigning, replacing, or clearing those handles is not user-visible state, yet an `@State` mutation can invalidate the owning view tree. That created avoidable update opportunities during D-pad navigation, catalog focus/preview scheduling, surface handoffs, VOD startup, watchdog cancellation, Up Next/Skip Intro work, alternate-audio work, and metadata loading.

## vBRDC134 changes

### Non-publishing async ownership

All 88 nonvisual task handles were moved out of SwiftUI `@State` and into retained, non-publishing runtime owners. Existing task bodies, priorities, delays, cancellation points, feature behavior, and call sites remain unchanged.

Hot-surface ownership now includes:

- Root lifecycle / UNITY handoff / catalog watchdog / alert scheduling: 13 task handles.
- Catalog overlay focus, row-entry, preview, hero metadata and readiness recovery: 8 task handles.
- Persistent catalog rail artwork prewarm: 1 task handle.
- Live TV lifecycle, refresh, schedule-boundary, focus restore and covered-surface compaction: 10 task handles.
- VOD player startup, metadata, resume, failover, first-frame, timeline, Up Next, Skip Intro, alternate audio, Quick Guide, player focus and control-shelf work: 36 task handles.
- Search, Media Information, details, popup metadata, trailers, Sports and Favorites: remaining 20 task handles.

The runtime-owner objects intentionally expose no `@Published` properties, so assigning or cancelling a task cannot itself request a SwiftUI redraw.

### VOD observer ownership

The AVPlayer periodic-time observer token, KVO status observer, and end-of-item notification token were also removed from `@State` and retained by the VOD runtime owner. Their callbacks and teardown behavior remain unchanged.

### Finite ticker cleanup

The top-bar media-info ticker used an autoconnected 2.6-second timer that continued waking the MainActor after the ticker had finished its finite sequence and hidden. It now uses a finite view-owned task that exits immediately when the sequence finishes and cancels automatically when the surface unmounts.

### Dead diagnostics scaffold removal

An unused one-second VOD diagnostics pulse function and its unused `diagnosticsTick` state were removed. It had no production call site, so this is cleanup rather than a behavior change and prevents accidental future activation of a permanent UI heartbeat.

## Background-work audit retained intentionally

The pass also re-audited existing loops and timers rather than deleting required behavior blindly:

- Live TV guide/cache persistence drains are queue-backed finite drains, not permanent polling loops.
- Live TV schedule refresh remains a one-shot task scheduled to the actual EPG program boundary.
- MediaFlow connection heartbeat remains 60-second, app-active only, and is cancelled whenever playback is active.
- Dynamic wallpaper decoding remains pause-gated and frame-rate bounded; it does not spin while paused.
- VOD hidden heavy chrome remains unmounted while controls/panels are hidden.
- PlaybackKit's overlay bridge still suppresses clock publications into SwiftUI while VOD chrome is hidden.
- VOD player clock quiet mode remains 5 seconds while hidden and exits entirely for KSPlayer once first-frame startup is resolved.
- Up Next, Skip Intro, first-frame and metadata-recovery loops remain bounded/adaptive because they are playback behavior, not decorative background work.
- VOD cast/artwork rotation timers remain mounted only with visible VOD chrome.
- Episode-alert heartbeat remains required user-selected alert infrastructure and is not treated as decorative work.

## Preserved release behavior

vBRDC134 keeps the vBRDC133 zero-flash catalog-to-Live-TV handoff, vBRDC132 universal top-menu Down-to-Live-TV behavior, vBRDC131 catalog close animation, vBRDC128 exact card-shaped Live TV focus ring, vBRDC126 Live TV grid motion/preview settings, and vBRDC125 catalog artwork identity hardening.

MediaFlow routing, PlaybackKit source files, Sports logic, Cast Explorer service, UNITY visual/coordinator files, provider logic, resume policy, Bluetooth VOD ownership, playback source selection, and UI geometry were not changed in this optimization pass.

## Validation

- Cumulative contract: `210/210`
- Production Swift parse: `65/65`
- Backend runtime tests: `36/36`
- Package file hashes: verified before ZIP creation
- ZIP integrity: verified after packaging

Physical Apple TV testing remains authoritative for perceived frame pacing and the GitHub/Xcode Release build remains authoritative for full compilation.
