# Debrid Channels vBRDC145 — Regression Locks

vBRDC145 is a corrective child of exact packaged vBRDC144. All earlier locks remain authoritative.

1. Live TV remains a fixed 4-column / 12-card paged grid.
2. RIGHT/LEFT page transitions retain the deliberate two-press edge model from vBRDC144.
3. Bottom-row first DOWN only arms Guide and keeps the exact card focused; second DOWN opens Guide.
4. First DOWN must not cancel the focused Live TV grid preview. Full Guide opening still cancels it.
5. Guide prompt is non-focusable, glows while visible, and auto-hides after 30 seconds.
6. Guide exit hint is non-focusable, advertises Back/Menu and double LEFT, and auto-hides after 30 seconds.
7. Back/Menu remains an immediate Guide exit. Double LEFT remains the alternate Guide exit.
8. vBRDC142 post-VOD Gracenote/channel-artwork recovery remains intact.
9. No Live TV provider, XMLTV/Gracenote, channel-logo fallback, MediaFlow, or playback routing semantics are changed.
10. Animated Live TV header is optional and isolated to one header view; it must pause when Live TV is covered.
11. Animated header offers exactly the two requested reference-derived styles: Signal TV and Retro Tube.
12. New header preferences remain backup/restore and stable-default safe.
