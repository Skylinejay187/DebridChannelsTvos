# vBRDC126 Performance Audit — UNITY Live TV Grid

## Scope

Physical-tvOS Live TV grid focus movement, card animation ownership, focus-preview lifecycle and virtualized-grid maintenance. No visual redesign and no provider/playback behavior change.

## Findings and corrections

### 1. Multiple animation owners on one focus edge

**Before:** `FocusState` changed the outer scale/offset/shadow while focused border/glow and focus-dependent card content lived inside the same animated hierarchy. This could visually read as two settles and made expensive subviews eligible to inherit the focus spring.

**Now:** `LiveTVGridFocusMotionHost` is the only scale/offset/black-shadow owner. Its child tile disables inherited animation. Focus-ring motion is a separate focused-only leaf.

### 2. Nonvisual Task state invalidated SwiftUI

**Before:** preview arm/stop, artwork prefetch and selection-persistence task handles/generations were SwiftUI state even though assigning those handles has no presentation meaning.

**Now:** `LiveTVGridInteractionRuntime` stores those non-publishing owners, including virtual-window work and guide-preview generation. Actual visible state remains in SwiftUI state.

### 3. Virtual corridor recenter could compete with native focus

**Before:** a selected-channel edge could immediately recenter/remount the 96-card corridor near its five-row buffer while tvOS was also moving focus.

**Now:** routine maintenance is coalesced and delayed 125 ms; only a two-row emergency condition recenters immediately. Recenter transactions disable animation.

### 4. Duplicate preview bookkeeping

**Before:** a valid tile-focus move cancelled preview once in the tile focus handler, then the schedule function immediately cancelled it again before arming the new session. Guide preview warmup could also be triggered from overlapping selection/focus callbacks.

**Now:** the schedule function is the sole cancel/re-arm owner for valid grid focus. Ordinary grid selected-channel changes no longer execute guide warmup, and guide focus relies on the selected-channel observer as the single warmup owner.

### 5. Selection state could join an ambient focus animation

**Now:** after FocusState has already selected the visual card, `selectedChannelID` bookkeeping is committed with animations disabled. This keeps metadata/persistence/preview ownership from creating a second animated visual edge.

## Expected physical effect

- One focused-card scale/offset motion per D-pad event.
- Faster outgoing-card settle with no double glow/shadow bounce.
- Less body invalidation from task bookkeeping.
- Fewer structural grid changes during the native tvOS focus frame.
- Rapid directional movement coalesces background corridor work to the latest card.
- Optional preview dimming and ring pulse remain compositor-local rather than animating the full tile hierarchy.

This package cannot claim measured 60 FPS without a physical Apple TV frame capture. Device testing remains authoritative.
