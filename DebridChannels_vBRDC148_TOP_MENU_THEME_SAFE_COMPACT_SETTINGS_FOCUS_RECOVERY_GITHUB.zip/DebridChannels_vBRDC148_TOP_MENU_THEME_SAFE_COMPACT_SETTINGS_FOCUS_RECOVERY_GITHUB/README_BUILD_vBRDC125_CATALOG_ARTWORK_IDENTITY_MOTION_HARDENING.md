# Debrid Channels vBRDC125 — Catalog Artwork Identity Motion Hardening

- Release ID: `vBRDC125`
- Marketing version: `1.0.828`
- Apple build: `828`
- Donor: packaged `vBRDC124` only

## Release goal

Fix the physical-tvOS catalog scrolling artwork corruption reported after vBRDC124 without changing catalog layout, focus rules, row motion presets, provider logic, or UI design.

## Root cause

vBRDC103 deliberately made the catalog rail persistent and reused fixed structural slots across horizontal and vertical navigation. Those slots also used `preservePreviousOnURLChange`, which kept the old decoded bitmap visible until the next URL decoded. The combination was visually smooth on cache misses but could temporarily pair the incoming card metadata with the outgoing title's pixels. Because several depth slots advance together, this could look like duplicated posters/double images across a row. The same retained-frame policy could also leave the previous focused title's hero backdrop or clearlogo visible while the incoming title resolved.

## vBRDC125 correction

- The persistent rail/compositor remains intact; it is **not** rebuilt on every D-pad move.
- Only the image owner inside the focused card is keyed to `rowID + media identity`.
- Only the image owner inside each trailing depth slot is keyed to `rowID + depth + media identity`.
- The catalog hero backdrop, optional depth copy, and clearlogo are keyed to the focused media identity.
- `preservePreviousOnURLChange` remains enabled *within the same media identity*, so metadata/artwork URL hydration can still upgrade without flashing.
- A different title can never inherit another title's retained decoded pixels. Exact cached artwork still appears synchronously; a true cache miss uses the existing neutral card/background backing until the correct bitmap is ready.
- The vBRDC124 Live TV golden-motion/focus changes remain unchanged.

## Preserved behavior

- All 48 catalog row motion presets and their existing timings remain unchanged.
- Persistent single-rail vertical navigation and no-peek row swap remain unchanged.
- Focused-card dimensions, perspective, glow, chrome, hero geometry, provider branding, and selection logic remain unchanged.
- vBRDC123 VOD cast/episode artwork hardening and vBRDC121 Bluetooth media controls remain preserved.
- MediaFlow, PlaybackKit, Live TV provider/guide routing, Sports, resume logic, source selection, and backend runtimes are untouched.

## Validation

- vBRDC125 cumulative regression contract: **125/125 passed**.
- Production Swift syntax parse: **65/65 files passed**.
- Backend runtime suites: **36/36 passed** (Alternate Audio Bridge 15, Alternate Audio Discovery 8, Backup Streaming 6, TorBox Usenet Search 7).
- App and Top Shelf version/plist consistency passed: `vBRDC125 / 1.0.828 / 828`.
- Changed Swift whitespace check passed.
- GitHub Actions/Xcode remains authoritative for the tvOS Release compile.
- Physical Apple TV remains authoritative for final visual verification of row-motion frame pacing and artwork handoff.
