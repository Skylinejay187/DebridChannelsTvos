# vBRDC124 Regression Lock Addendum

Future builds must preserve every earlier lock plus these contracts.

## UNITY / Live TV focus handoff

- The selected Live TV card must remain visually focused while real tvOS focus ownership moves to or from Live Controls or a covering catalog surface.
- Surface handoff ownership and Live Controls handoff ownership remain distinct so automatic tvOS focus reconciliation cannot release the visual pin early.
- Opening/closing Live Controls animates panel visibility only; focus preflight/rebinding must remain animation-free.
- Do not restore the old duplicate `DispatchQueue.main.asyncAfter` panel-focus retries or a broad `.animation(..., value: quickWindowVisible)` on the grid/panel hierarchy.
- Closing Live Controls must restore `tileFocus` to `selectedChannelID`, yield a frame, and only then release the visual pin.
- Catalog-to-Live focus bind remains after the reverse visual branch has settled.

## Live TV frame budget

- Category counts must use indexed browse data; do not filter the full provider channel array once per category during panel presentation.
- Current EPG program lookup remains cached to actual schedule boundaries and invalidated by guide publication.
- Per-channel lookup/current-program caches must prune identities removed by provider refresh.
- Live TV ImageIO decode waiters remain cancellation-aware and cancelled waiters must leave the queue immediately.
- Decoded artwork publication remains event-driven through the shared UNITY frame revision signal; do not restore private 35 ms publication polling.
- Small playback/Quick Guide/channel-logo surfaces remain display-bounded rather than decoding full source resolution.
- Failed/success artwork bookkeeping must not publish unchanged state.

## Preservation

- vBRDC123 Featured Cast and VOD Episode foreground-artwork locks remain intact.
- vBRDC121 Bluetooth VOD media-control recovery remains intact.
- MediaFlow/provider/playback/Sports behavior and catalog geometry/visual design remain unchanged.
