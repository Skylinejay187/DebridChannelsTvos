# Debrid Channels vBRDC121 — Bluetooth VOD Ownership Recovery

Release: **vBRDC121**  
Marketing version: **1.0.824**  
Apple build: **824**  
Built only from: **packaged vBRDC120**

## Physical-test regression

VOD Bluetooth/headset Play/Pause had worked after the vBRDC117 Now Playing recovery, but later physical testing reported that accessory Play/Pause no longer controlled the active movie/show.

The vBRDC117 bridge was still present in vBRDC120: VOD still registered MPRemoteCommandCenter Play/Pause/Toggle handlers, claimed an AVAudioSession playback/moviePlayback category, and published MPNowPlayingInfoCenter metadata. The fragile part was ownership lifetime: the claim was primarily made when the SwiftUI VOD presentation mounted. tvOS/audio-route lifecycle events can revoke or replace that media ownership after the initial claim even though the VOD presentation is still active.

## Correction

vBRDC121 keeps the existing vBRDC117 command bridge and adds event-driven ownership recovery only for the active VOD presentation:

- retain the latest authoritative Now Playing title, duration, elapsed time, and play state in the coordinator;
- reassert the same VOD AVAudioSession + Now Playing payload once the real VOD first frame is established;
- reassert after the app becomes active again;
- reassert after Bluetooth/audio route changes;
- reassert after an audio interruption ends;
- reassert after media services reset;
- re-enabling the existing Bluetooth Media Play/Pause setting reasserts the active VOD session immediately;
- no polling timer is added;
- no Live TV, trailer, catalog preview, or navigation surface can claim this Bluetooth bridge;
- the existing 180 ms SwiftUI/MPRemoteCommandCenter duplicate-event guard remains unchanged.

Apple documents that MPRemoteCommandCenter is the correct accessory command path and that audio sessions may be deactivated by interruption/suspension lifecycle events. vBRDC121 restores the same active VOD media ownership when those events end rather than assuming the original mount-time claim remains valid forever.

## Non-regression

All vBRDC119 performance/frame-budget work and the vBRDC120 compile corrections are retained. No artwork, animation, catalog, Live TV/Gracenote, MediaFlow, source/provider, resume, scrubber, subtitle/audio-track, Dynamic Wallpaper, Cast, or VOD visual behavior is intentionally changed.

GitHub Actions/Xcode remains the authoritative full tvOS Release compile. Physical Apple TV + the affected Bluetooth device remains the authoritative hardware transport test.
