# Performance Audit — vBRDC135

## High-impact findings corrected

1. **VOD resume checkpoint MainActor work** — normal five-second checkpoints still mutated/reconciled a resume dictionary of up to ~1200 identity aliases on the caller. Entire non-durable mutation + encode/write now runs on the utility writer queue. Durable saves serialize behind pending work.
2. **4K decoded-frame footprint** — 24 retained decoded 4K frames could create unnecessary VideoToolbox/pixel-buffer/texture pressure. 4K queue now uses 16 frames for ordinary cadence and 18 for high-frame-rate content.
3. **VOD display-link scheduling** — full-screen VOD now uses physical-output-paced CADisplayLink scheduling while the existing timestamp clock owns frame hold/advance. No frame interpolation is introduced.
4. **Bluetooth transport regression surface** — the visible preference could persist Off and prevent MPRemoteCommandCenter ownership. The preference UI/gate is removed; active VOD UUID ownership is always automatic and hidden.
5. **Live TV image decode bandwidth** — grid artwork decode/prefetch bucket reduced 768 -> 640.
6. **Catalog image decode bandwidth** — focused rail card 1280 -> 1024; tiny trailing posters 640 -> 384.

## Re-audited and intentionally retained

- VOD Up Next watchdog is adaptive (8s far from EOF, 2s final six minutes, 0.5s near intro/end) and provides required natural-end fallback.
- Skip Intro countdown runs only while its prompt is visible.
- Timeline metadata recovery is bounded and exits after metadata resolves.
- Hidden KSPlayer overlay publication remains suppressed by PlaybackKit OverlayBridge.
- VOD heavy chrome remains unmounted while hidden.
- Dynamic wallpaper remains pause-gated and bounded.
- Live TV EPG boundary work remains one-shot/schedule-boundary based rather than continuous polling.
- MediaFlow heartbeat remains playback-gated.

## No visual or routing changes

The optimization pass deliberately does not alter UI geometry, catalog motion style, Live TV ring shape, preview visual design, provider routing, source resolver order, MediaFlow wrapping, or playback feature behavior.
