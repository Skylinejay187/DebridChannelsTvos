# Debrid Channels vBRDC163 — Live TV Luxe Rework + Favorites Geometry Fix

Release: **vBRDC163**  
Marketing version: **1.0.866**  
Apple build: **866**  
Base: **packaged vBRDC162 only**

## Live TV visual rollback + second premium treatment

The vBRDC162 broadcast-deck visual experiment was removed before this pass. The giant rounded outer chassis, top signal rail, inset card border, top-left card marker, and boxed lower information shelf are gone.

The existing 4×3 paged Live TV navigation/focus engine remains unchanged. The replacement visual language is intentionally cleaner and more cinematic:

- edge-to-edge program artwork remains the dominant card surface;
- card metadata is integrated into the lower cinematic fade instead of sitting inside another rounded box;
- focused cards use a channel-accent/white perimeter with a restrained halo while retaining the user's configured focus-ring behavior;
- a small bottom signature line replaces the old card marker treatment;
- channel-number badges are smaller translucent accent capsules;
- the page receives only a very low-opacity ambient field, not an enclosing frame;
- header/category/page typography is rebuilt as a minimal broadcast rail with a fine accent trace;
- page position is a lightweight typographic indicator rather than a dark pill.

No new network requests, decoder surfaces, blur effects, focus owners, or recurring timers were added.

## Live TV requested behavior retained

- Grid Guide hint auto-hide remains **10 seconds**.
- Turning **Animated Live TV Header Logo** Off still means completely Off. No generic LIVE TV text/logo is drawn in its place.
- Existing page boundaries, double-press Guide behavior, channel selection, preview behavior, Gracenote/provider artwork loading, focus-ring settings, and card-layout settings remain intact.

## Favorites stretch correction

The supplied video exposed two independent Favorites presentation problems:

1. Favorites was using the generic catalog "fan" rail, which progressively squeezed trailing poster previews thinner and thinner across the screen. Favorites now opts into equal-width fixed preview posters while Home/Movies/Shows keep their existing rail geometry unchanged.
2. A Favorite without true landscape artwork could promote its portrait poster to the full-screen hero backdrop. Favorites now uses only actual `landscapeURL` artwork for the full-screen background; missing landscape art falls back to the existing neutral gradient. The full-screen image is also explicitly constrained to the Favorites viewport.

## vBRDC162 fixes preserved

- first-open VOD themed-logo / cast / Production & Ratings hydration hardening;
- generation-owned VOD metadata requests;
- universal local Find English Audio path;
- current-playing-copy audio candidate;
- no legacy compatible/incompatible gate for local alternate audio.

## Scope

- Production code changed only in `Sources/DebridChannelsTVOSApp.swift` plus release/version metadata.
- No Vendor/KSPNUVIO source changes.
- No backend changes.
- No provider, MediaFlow, Gracenote, resume, Bluetooth, VOD audio, or VOD hydration logic was removed/reworked in this pass.
