# vBRDC171 regression locks

- Fresh donor: vBRDC170 packaged ZIP only.
- Keep 4x3 Live TV paging and bottom-right page indicator.
- Keep vBRDC170 smooth focused-card spring handoff.
- Only one Live TV focus-ring renderer may be visible per focused card.
- Guide exit hint must never overlap preview video.
- Guide category control remains Guide-only; grid left panel remains grid-only.
- Dynamic wallpaper is Live TV grid only, not full Guide or app-wide.
- VOD adaptive bitrate/memory/low-seeder caching from vBRDC168 is preserved.
- Alternate Audio keeps original video mounted and uses local audio-only KSME.
- Favorites restore/durable snapshot identity is preserved.
- Sports direct-tune behavior is preserved.
- No mockup/image-generation assets are part of the build.
