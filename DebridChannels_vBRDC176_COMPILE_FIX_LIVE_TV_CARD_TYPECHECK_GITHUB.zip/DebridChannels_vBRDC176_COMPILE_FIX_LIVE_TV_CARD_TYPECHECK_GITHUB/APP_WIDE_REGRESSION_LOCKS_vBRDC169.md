# APP-WIDE REGRESSION LOCKS — vBRDC169

vBRDC169 is a narrow Live TV presentation correction built only from packaged vBRDC168.

Locked:
- Preserve vBRDC168 adaptive VOD cache behavior and source-health metadata exactly.
- Preserve the Live TV 4x3 page grid and its existing left-side tools panel.
- Guide category switching remains Guide-only, compact, and inline.
- Dynamic wallpaper belongs to the full Live TV surface only and must not pause on Live TV D-pad scrolling.
- Guide preview must show the complete broadcast frame rather than crop-to-fill.
- No feature removal, no VOD playback logic changes, no alternate-audio changes, no mockups.
