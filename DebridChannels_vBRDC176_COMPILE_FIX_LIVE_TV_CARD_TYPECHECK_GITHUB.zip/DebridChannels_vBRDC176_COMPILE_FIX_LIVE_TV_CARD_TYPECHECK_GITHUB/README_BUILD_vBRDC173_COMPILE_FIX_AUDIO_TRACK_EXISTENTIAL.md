# Debrid Channels vBRDC173 — Compile Fix: Alternate Audio Track Existential

- Release: vBRDC173
- Marketing version: 1.0.876
- Build: 876
- Donor: packaged vBRDC172 only

## Fix
GitHub Actions/Xcode 16.4 rejected the v172 call that attempted to pass an `any MediaPlayerTrack` existential directly to KSPlayer's `select(track: some MediaPlayerTrack)`. vBRDC173 opens the existential through a generic helper before invoking KSMEPlayer's normal track-selection path.

No Live TV, Guide, Favorites, Sports, adaptive VOD cache, source failover, UI, or other runtime behavior was intentionally changed.
