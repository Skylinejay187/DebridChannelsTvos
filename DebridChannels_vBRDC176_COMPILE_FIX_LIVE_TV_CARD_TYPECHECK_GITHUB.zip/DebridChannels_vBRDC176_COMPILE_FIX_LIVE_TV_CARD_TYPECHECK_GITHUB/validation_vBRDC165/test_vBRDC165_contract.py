from pathlib import Path
import plistlib, re, sys
root = Path(__file__).resolve().parents[1]
src = (root/'Sources/DebridChannelsTVOSApp.swift').read_text()
errors=[]
def req(cond,msg):
    if not cond: errors.append(msg)

# Release metadata
for rel in ['Sources/Info.plist','TopShelfExtension/Info.plist']:
    with open(root/rel,'rb') as f: d=plistlib.load(f)
    req(d.get('CFBundleShortVersionString')=='1.0.868', f'{rel} marketing version')
    req(str(d.get('CFBundleVersion'))=='868', f'{rel} build')
    req(d.get('DebridChannelsReleaseID')=='vBRDC165', f'{rel} release id')
yml=(root/'project.yml').read_text()
req(yml.count('MARKETING_VERSION: 1.0.868') >= 2, 'project marketing version both targets')
req(yml.count('CURRENT_PROJECT_VERSION: 868') >= 2, 'project build both targets')

# Live preview audio
req('routeHint: "live-guide-preview"' in src, 'Guide live preview route')
req('routeHint: "live-grid-focus-preview"' in src, 'Grid live preview route')
for hint in ['live-guide-preview','live-grid-focus-preview']:
    i=src.find(f'routeHint: "{hint}"')
    req(i>=0, f'{hint} exists')
    if i>=0:
        window=src[max(0,i-650):i+100]
        req('muteAudio: false' in window, f'{hint} unmuted')
        req('isLiveStream: true' in window, f'{hint} live stream mode')
req('SilentVideoBackground(url: streamURL, isMuted: false)' in src, 'Guide AV fallback unmuted')
req('SilentVideoBackground(url: url, isMuted: false)' in src, 'Grid AV fallback unmuted')
req('start one audible channel preview' in src, 'preview settings describes audio')

# Guide compact channel chip/dropdown
for token in ['guideCategoryChip','guideCategoryDropDown','openGuideCategoryMenu()','selectGuideCategory(_ category: String)','SELECT A GROUP • LEFT OPENS CHANNELS']:
    req(token in src, f'guide chip token {token}')
req(src.count('private func selectGuideCategory(_ category: String)') == 1, 'single category selector owner')
req('if showGuide {' in src and 'openGuideCategoryMenu()' in src, 'LEFT Guide route opens compact menu')
req('private let baseCategories = ["All", "My Favorites", "HD", "Favorites", "Sports", "Drama", "News", "Kids"]' in src, 'base channel groups preserved')

# Top menu size
for token in ['private enum TopMenuSizePreset','topMenuSizePresetV1','Top Menu Size:','topMenuSizeToggle']:
    req(token in src, f'top menu size token {token}')
for option in ['Extra Small','Small','Medium','Large','Extra Large']:
    req(option in src, f'top menu size option {option}')
req('topMenuSizePreset = "Medium"' in src, 'stable UI reset covers top menu size')
req('"topMenuSizePresetV1": TopMenuSizePreset.normalized(topMenuSizePreset)' in src, 'backup export covers size')

# Animated logo library
m=re.search(r'private enum LiveTVAnimatedHeaderLogoStyle \{\s*static let names = \[(.*?)\]', src, re.S)
req(m is not None, 'animated logo enum')
if m:
    names=re.findall(r'"([^"]+)"',m.group(1))
    req(len(names)==16, f'16 animated logo styles, found {len(names)}')
    for n in ['Prism Broadcast','Aurora Live','Chrome Pulse','Spectrum TV','Quantum Signal','Ember Air','Holo Channel','Electric Live']:
        req(n in names, f'new logo {n}')
req('accent: selectedChannel.accent' in src, 'header logo receives focused channel accent')
req('if liveTVAnimatedHeaderLogoEnabled {' in src, 'header logo Off still removes view completely')

# Wallpaper persistence
req('title: "Dynamic Wallpaper (App-Wide)"' in src, 'app-wide wallpaper settings title')
req('paused: false' in src[src.find('private struct LiveTVUnityDynamicWallpaperSurface'):src.find('struct LiveTVScreen')], 'wallpaper wrapper never pauses for navigation')
expected='dynamicMainGridWallpaperEnabled && store.playbackURL == nil'
req(expected in src, 'wallpaper render budget is all non-playback surfaces')
req('!unityAnimations.allows(.dynamicWallpaper)' not in src[src.find('private struct LiveTVUnityDynamicWallpaperSurface'):src.find('struct LiveTVScreen')], 'removed UNITY scroll pause gate')

if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS: vBRDC165 behavioral contract')
