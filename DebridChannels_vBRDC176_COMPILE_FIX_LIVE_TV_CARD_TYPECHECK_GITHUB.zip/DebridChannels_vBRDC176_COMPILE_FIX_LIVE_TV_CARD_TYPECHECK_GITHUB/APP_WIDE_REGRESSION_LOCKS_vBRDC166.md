# APP-WIDE REGRESSION LOCKS — vBRDC166

Donor/source of truth: packaged vBRDC165.

- No mockup or generated-image assets are part of this build.
- Keep Live TV preview audio audible in grid and full Guide.
- Keep 4x3 Live TV page geometry and deliberate page-edge navigation unchanged.
- Full Guide category switching is owned by the visible current-category selector/drop-down.
- Grid-only Live TV Tools rail must not replace the Guide category selector.
- Preserve vBRDC165 Top Menu Size, animated Live TV logos, and app-wide Dynamic Wallpaper behavior.
- Preserve vBRDC163 Favorites fixed geometry/backdrop containment.
- Preserve vBRDC162 VOD hydration and universal Alternate Audio changes.
