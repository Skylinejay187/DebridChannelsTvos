# vBRDC159 Regression Locks

## Must remain unchanged

- Live TV provider/bootstrap behavior: HDHomeRun, Channels DVR, M3U, Xtream, MediaFlow, XMLTV, Gracenote.
- Live TV 4×3 paging, Current/Spread Out layout setting, channel-number position setting, Guide navigation, previews, page indicator, animated header logos.
- Sports, VOD player engine selection, Bluetooth media controls, resume/source failover, debrid/provider behavior.
- Existing top-menu theme/navigation work.

## vBRDC159 contracts

- Search artwork-only hydration is a real metadata update.
- A known clearlogo can never be replaced by a later nil/empty artwork wave.
- VOD logo ownership survives Source Intelligence→player handoff and VOD chrome hide/show.
- Artwork cache follows TMDB/IMDb/TVDB/raw-id/title aliases.
- Portable Favorites V2 is authoritative for new protected backups; V1 remains restore-compatible fallback.
- Legacy favorite keys are reconstructable and migrate to canonical identities.
- Favorites normal entry is snapshot-first and does not observe/rescan all catalog rows during navigation.
- Favorites background image loading never receives video preview URLs.
