from pathlib import Path
import plistlib, re
root = Path(__file__).resolve().parents[1]
swift = (root/'Sources'/'DebridChannelsTVOSApp.swift').read_text()
app = plistlib.loads((root/'Sources'/'Info.plist').read_bytes())
top = plistlib.loads((root/'TopShelfExtension'/'Info.plist').read_bytes())
project = (root/'project.yml').read_text()
checks = []
def ck(name, cond):
    checks.append((name, bool(cond)))
    print(('PASS' if cond else 'FAIL') + ': ' + name)
ck('app release vBRDC166', app.get('DebridChannelsReleaseID') == 'vBRDC166')
ck('topshelf release vBRDC166', top.get('DebridChannelsReleaseID') == 'vBRDC166')
ck('app version 1.0.869', app.get('CFBundleShortVersionString') == '1.0.869')
ck('app build 869', app.get('CFBundleVersion') == '869')
ck('topshelf version/build', top.get('CFBundleShortVersionString') == '1.0.869' and top.get('CFBundleVersion') == '869')
ck('project version/build', project.count('MARKETING_VERSION: 1.0.869') >= 2 and project.count('CURRENT_PROJECT_VERSION: 869') >= 2)
ck('visible DVR category selector comment', 'vBRDC166: Channels-DVR-style category selector' in swift)
ck('category chip has current category label', 'Text(selectedCategory == "All" ? "All Channels" : selectedCategory)' in swift)
ck('category chip has down/up chevron', 'guideCategoryMenuVisible ? "chevron.up" : "chevron.down"' in swift)
ck('left focuses category selector', 'guideCategoryChipFocused = true' in swift and 'guideFocus = nil' in swift)
ck('select opens drop-down', 'openGuideCategoryMenu()' in swift)
ck('drop-down uses live categories', 'ForEach(Array(categories.enumerated()), id: \\.element)' in swift)
ck('category selection reprojects Guide', 'private func selectGuideCategory(_ category: String)' in swift and 'selectedCategory = category' in swift)
ck('old guide helper text removed', 'SELECT A GROUP • LEFT OPENS CHANNELS' not in swift)
ck('preview audio preservation marker', 'focused Live TV grid preview restores channel audio' in swift)
ck('dynamic wallpaper preservation marker', 'persistent app-wide non-playback wallpaper' in swift)
if not all(v for _, v in checks):
    raise SystemExit(1)
