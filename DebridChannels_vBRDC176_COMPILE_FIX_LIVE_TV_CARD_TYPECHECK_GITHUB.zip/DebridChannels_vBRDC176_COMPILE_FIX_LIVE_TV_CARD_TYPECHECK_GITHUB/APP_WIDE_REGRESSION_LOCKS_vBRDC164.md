# vBRDC164 Regression Locks

1. Build lineage remains packaged vBRDC163 only.
2. Live TV remains a fixed 4x3 paged grid with existing page-edge navigation.
3. The vBRDC164 card cleanup removes only the two decorative lower-left capsule lines; channel logo/program/footer content remains.
4. Full Guide LEFT opens the shared Guide Tools rail; Back/Menu exits full Guide immediately.
5. Guide Tools continues to expose My Favorites and all existing Live TV category/provider groups.
6. Closing Guide Tools restores the correct underlying focus owner (Guide vs grid).
7. VOD first-open hydration, themed-logo recovery, cast/Production & Ratings hydration, and universal local Alternate Audio behavior from vBRDC162/vBRDC163 remain untouched by this pass.
8. Favorites geometry/backdrop fixes from vBRDC163 remain untouched.
9. No mockup or generated-image asset is part of this build.
