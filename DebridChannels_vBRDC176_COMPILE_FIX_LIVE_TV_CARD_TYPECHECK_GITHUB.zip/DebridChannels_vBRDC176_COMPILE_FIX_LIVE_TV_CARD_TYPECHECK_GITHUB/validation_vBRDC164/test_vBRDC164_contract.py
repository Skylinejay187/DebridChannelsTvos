from pathlib import Path
import plistlib, re
ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT/'Sources/DebridChannelsTVOSApp.swift').read_text()
YML = (ROOT/'project.yml').read_text()

def ck(name, condition):
    if not condition:
        raise AssertionError(name)
    print('PASS', name)

for rel in ['Sources/Info.plist', 'TopShelfExtension/Info.plist']:
    with (ROOT/rel).open('rb') as f:
        d = plistlib.load(f)
    ck(rel+' release', d.get('DebridChannelsReleaseID') == 'vBRDC164')
    ck(rel+' marketing', d.get('CFBundleShortVersionString') == '1.0.867')
    ck(rel+' build', d.get('CFBundleVersion') == '867')

ck('project marketing', YML.count('MARKETING_VERSION: 1.0.867') >= 2)
ck('project build', YML.count('CURRENT_PROJECT_VERSION: 867') >= 2)
ck('decorative accent capsule removed', '.frame(width: isFocused ? 42 : 24, height: isFocused ? 2.5 : 1.5)' not in SRC)
ck('decorative white capsule removed', '.frame(width: 12, height: 1.5)' not in SRC[SRC.index('private struct LiveTVGridTileContent'):SRC.index('private struct LiveTVGridBroadcastChrome')])
ck('guide tools available while guide open', 'the same left-side Guide Tools rail is available from both' in SRC)
route = SRC[SRC.index('private func routeLiveSpecialMove'):SRC.index('private func advanceLiveTVGridPage')]
ck('quick panel routing precedes guide routing', route.index('if quickWindowVisible') < route.index('if showGuide'))
ck('guide left opens guide tools', 'if direction == .left, acceptSingleDpadStep()' in route and 'openQuickWindow()' in route)
close = SRC[SRC.index('private func closeQuickWindow'):SRC.index('private func scheduleQuickWindowHide')]
ck('guide focus restored after tools', 'guideFocus = selectedChannelID' in close and 'tileFocus = selectedChannelID' in close)
ck('guide hint documents tools', 'Guide Tools. Press Left. Exit Guide with Back or Menu' in SRC)
ck('retired guide left-twice instruction gone', 'press LEFT twice while the Guide is open' not in SRC and 'LEFT\\nTWICE' not in SRC)
ck('no generated mockup asset references', 'mockup' not in SRC.lower())
