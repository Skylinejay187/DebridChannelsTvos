# vBRDC176 — Compile Fix: Live TV Card Typecheck

Built only from packaged vBRDC175.

GitHub Actions v175 failed at `Sources/DebridChannelsTVOSApp.swift:48863` because Xcode 16.4 could not type-check the monolithic `LiveTVGridTileContent.body` expression in reasonable time.

v176 is compile-only:
- Splits the v175 Live TV tile body into dedicated card surface/layer/preview/progress/border/optical-edge/focus subviews.
- Preserves the v175 Live TV visual values, card information, focus ring, smooth motion, paging, Guide, preview, playback, Favorites, Sports, Alternate Audio and adaptive VOD cache behavior.
- No catalog source changes.
- No Vendor/KSPNUVIO changes.
