# vBRDC149 regression locks

1. All 32 current top-menu theme raw values remain available.
2. `TopMenuTabVisual` remains the production renderer; the v810/plain-tab renderer must not return.
3. Theme resolution must remain exact-first and theme changes must reconstruct the top-menu subtree.
4. Top-menu size may change only through the composition scale unless explicitly redesigning a theme.
5. Outside Settings, DOWN from the top menu returns to Live TV rather than opening the highlighted catalog branch.
6. Settings-origin top-menu DOWN retains highlighted-destination behavior and Settings focus recovery.
7. Live TV grid paging, Guide navigation, Gracenote/artwork recovery, previews, and playback behavior remain unchanged.
8. Animated Live TV header logo choices remain isolated to header presentation and may not own timers, provider state, or grid focus.
