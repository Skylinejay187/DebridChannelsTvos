# vBRDC160 Regression Locks

1. **Base provenance:** build only from packaged vBRDC159.
2. **Alternate Audio:** active UI action is local `Use This Audio`; it must not call backend bridge preparation or replace the primary video with bridge HLS.
3. **Primary video ownership:** current VOD URL/render surface remains primary. Only one-time AVPlayer -> KS migration is allowed if local alternate audio requires KSPNUVIO.
4. **Secondary audio:** KSMEPlayer direct, `videoDisable = true`, remote controls disabled, provider headers preserved.
5. **Track selection:** ffprobe absolute stream ID is selected through `KSOptions.wantedAudio` before audio decoder/output creation, with legacy array-index and English fallback compatibility.
6. **Handoff:** secondary output is silent until aligned/ready; primary audio is muted first, then secondary output is exposed.
7. **Sync controls:** +/-/reset update local secondary clock only. They must never prepare or rebuild an HLS bridge.
8. **Seek/play/pause:** main VOD clock is authoritative; secondary mirrors play/pause and resyncs on main seek/drift without seeking/replacing the primary video.
9. **Failure/restore:** local failure and Restore Original Audio restore primary audio without recreating or seeking the main video.
10. **Remote/Bluetooth:** no second KSPlayerLayer is created for alternate audio; primary movie retains Now Playing / remote command ownership.
11. **Live TV:** byte lock remains identical to vBRDC158/vBRDC159 implementation.
12. **Unrelated systems:** Search, Favorites, themed VOD logos, Sports, providers, Gracenote/XMLTV, Live TV navigation and playback are out of scope.
