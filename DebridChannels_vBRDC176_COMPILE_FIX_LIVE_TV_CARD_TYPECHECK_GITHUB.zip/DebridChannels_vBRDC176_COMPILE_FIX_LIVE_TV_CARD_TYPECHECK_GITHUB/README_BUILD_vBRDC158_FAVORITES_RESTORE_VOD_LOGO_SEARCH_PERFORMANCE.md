# vBRDC158 — Favorites Restore / VOD Logo / Search Performance Recovery

Release: vBRDC158  
Marketing version: 1.0.861  
Build: 861

Built only from packaged vBRDC157.

## Scope

1. Restore-code Favorites durability
   - Favorite snapshot backup is compacted before upload so cast/credit/franchise payloads cannot consume the backup size budget.
   - IDs, title/year/type, provider identity, poster, backdrop, clearlogo and preview remain preserved.
   - Snapshot writes merge with an existing richer record so an older Search shell cannot erase an already-resolved logo.
   - Existing profile backup codes auto-sync Favorites changes after a short debounce once the user has opted into profile backup.
   - Older ID-only restore codes trigger bounded immediate favorite rehydration after restore.
   - Favorites receives a restore-generation signal so an already-mounted surface refreshes immediately.

2. Search/Favorites VOD clearlogo retention
   - CatalogStore now exposes one authoritative presentation-artwork merge.
   - Playback launch, overlay redraw and metadata publication all reuse the same remembered poster/backdrop/logo identity.
   - A cast/credits metadata wave without a logo can no longer overwrite a previously known logo.

3. Favorites performance
   - Full-screen Favorites backdrop decode reduced from 3840 to 1920 pixels.
   - Backdrop URL changes are delayed 180 ms until focus settles, preserving the previous decoded frame during rapid navigation.
   - Catalog/card geometry, focus behavior and Favorites navigation remain unchanged.

4. Search performance
   - Search result artwork decode bucket reduced from 1024 to 768 for 360x202 cards.
   - Removed a duplicate implicit focus animation; FocusedSidewaysCardEffect remains the single visual animation owner.
   - Production-information prefetch waits 360 ms for focus to settle and uses the background-prefetch frame budget.
   - Search SceneStorage focus persistence is committed after focus settles instead of on every fly-by card.

## Regression lock

The complete LiveTVSourceModel through the pre-Favorites Live TV/grid implementation is byte-for-byte unchanged from vBRDC157. No HDHomeRun, MediaFlow, Channels DVR, M3U, Xtream, XMLTV, Gracenote, Live TV paging, Guide, preview or channel-number logic was modified.

## Validation

- vBRDC158 contract: 29/29 passed
- Swift frontend parse: 62/62 production Swift files, 0 failures
- Backend runtime suite: 36 passed + 2 subtests
- Sources/Info.plist, TopShelfExtension/Info.plist and project.yml parse successfully
