# vBRDC383R4 — Phase 1 Live Audio + Ambient Lifecycle

Patch-forward from vBRDC383R3 / vBRDC382 authoritative lineage. Version remains 1.0.1085 (build 1085).

- Ambient Classic/Cinematic/Heavy/Orbs/Deadlight view is now mounted only while the Live tab is actually selected and the scene is active, in addition to the existing Guide/search/detail/playback exclusions. Catalog branches therefore unmount the effect rather than leaving its TimelineView/render work alive behind them.
- Preview Mirror header Signal logo is not mounted when a catalog branch owns the selected tab.
- HDHomeRun Phase-1 diagnostics now record live audio-track-set changes. If Aether loses the advertised HDHomeRun audio-track set after video has reached first-frame readiness, the existing bounded live retune path is invoked. This is evidence-based recovery only; it does not claim to detect arbitrary acoustic silence.
- R3 provider-aware routing remains: HDHomeRun software/FFmpeg-first; FiOS/HLS native-HLS-first.
- No Phase 2 timeshift, VOD cache, subtitle, or trailer changes.

Physical Apple TV validation remains authoritative. Phase 1 is not complete until Live TV audio continuity is confirmed.
