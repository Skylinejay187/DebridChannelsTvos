# Debrid Channels v1146

**Marketing version:** 1.0.674  
**Build:** 674  
**Base:** packaged v1145 only  
**Backend:** v674 unchanged

This corrective build addresses three physical Apple TV findings from v1145:

1. automatic VOD resume could falsely confirm a synthetic KS startup clock and still play from 0:00;
2. Phase 15 Full Episode Browser custom controls could receive the tvOS white outer focus platter;
3. timeline LEFT/RIGHT showed the scrub target but required Select/center to actually seek.

v1146 opens automatic-resume KS sessions at an honest 0:00 clock, waits for a real PlaybackKit decoder clock, then performs and verifies an in-place absolute seek with bounded retries. KS decoder callbacks now persist resume progress every five seconds in addition to the final exit save.

All custom Phase 15 VOD browser/source/confirmation actions are no longer SwiftUI Buttons; they use focusable custom content and Select activation through `onTapGesture`, matching the platter-free VOD control pattern already proven in the app.

Timeline LEFT/RIGHT now automatically seeks after a 90 ms focus-settling debounce. Select is not required.

Local validation is source-level only. GitHub Actions/Xcode and physical Apple TV testing remain authoritative.
