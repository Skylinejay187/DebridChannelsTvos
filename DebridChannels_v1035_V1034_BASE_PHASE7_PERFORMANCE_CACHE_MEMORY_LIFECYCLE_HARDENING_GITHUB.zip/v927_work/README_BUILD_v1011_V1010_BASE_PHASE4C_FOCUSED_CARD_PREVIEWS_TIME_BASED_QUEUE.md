# Debrid Channels tvOS/iOS v1011

Base: `DebridChannels_v1010_V1009_BASE_PHASE4B_UNIFIED_FAST_SEARCH_GITHUB.zip`

Version: `1.0.539`
Build: `539`

## Phase 4C — Focused Card Previews

Added the optional **Settings → Appearance → Focused Card Previews** setting.

Default: Off

Behavior when enabled:

- Waits 1.5 seconds after card focus settles.
- Makes no preview request during rapid row/card navigation.
- Cancels the pending request and releases active preview playback immediately when focus moves.
- Uses one isolated `AVPlayer`/`AVPlayerLayer` preview surface.
- Never reuses KSPlayer or the main VOD, episode, trailer-popup, or Live TV player.
- Always mutes preview audio and also sets player volume to zero.
- Plays one 20-second segment with no continuous loop.
- Returns to the normal artwork backdrop when the segment ends.
- Stops and releases when Details, Search, app backgrounding, or full playback takes over.
- Requests a lightweight backend preview with `prefer4k=false`, `allow4k=false`, and `maxHeight=720`.
- Applies a 2.5 Mbps client preferred peak bitrate.
- Uses a memory-only focused-preview URL cache separate from the existing normal trailer cache.
- Leaves the existing normal Trailer button, popup, engine selection, and trailer cache unchanged.

## VOD decoded-frame queue replacement

Replaced the v1009/v1010 FPS-and-resolution fixed matrix with Alternative 1, the requested time-based strategy.

- Target temporal buffer: 0.5 seconds.
- Missing/invalid FPS fallback: 24 fps.
- 4K/UHD clamp: 12–20 frames.
- 1080p/FHD clamp: 16–30 frames.
- Below 1080p clamp: 16–40 frames.
- Live TV continues to call `super.videoFrameMaxCount(...)` unchanged.
- Diagnostic logging prints the chosen frame count, calculated seconds, FPS, and dimensions.

Representative outcomes:

- 4K 24 fps → 12 frames / 0.50 s
- 4K 30 fps → 15 frames / 0.50 s
- 4K 50/60 fps → 20-frame memory clamp
- 1080p 24/30 fps → 16-frame minimum clamp
- 1080p 50 fps → 25 frames / 0.50 s
- 1080p 60 fps → 30 frames / 0.50 s
- Below 1080p 24/30 fps → 16-frame minimum clamp
- Below 1080p 60 fps → 30 frames / 0.50 s

## Preserved

- v1010 Phase 4B unified Search behavior.
- v1009 Phase 4A row customization.
- Hidden official catalog endpoint isolation.
- Public regular backend and Owner Login.
- All-in-One Catalogs toggle, all built-in rows, row refresh, and personal catalog URLs.
- v999 subtitle renderer/glyph path.
- Audio/subtitle switching.
- Existing playback cadence, clock, first-frame, VideoToolbox, FFmpeg, and presentation policies outside the queue override.
- VOD overlay, normal trailers, Live TV/guide, Favorites, and Source Intelligence.

## Validation completed

- Every Swift source passed `swiftc -frontend -parse`.
- `Info.plist` parsed and reports version `1.0.539` / build `539`.
- `project.yml` parsed as YAML.
- Queue truth-table assertions passed.
- Focused-preview delay, cancellation hooks, mute, 20-second boundary, 720p cap, no-loop surface, and default-off setting assertions passed.
- `git diff --check` passed.
- Final ZIP compressed-data integrity and extraction round-trip are validated during packaging.

A full Apple tvOS SDK build is performed by GitHub Actions.
