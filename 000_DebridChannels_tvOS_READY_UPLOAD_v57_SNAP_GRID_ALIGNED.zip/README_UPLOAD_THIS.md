# DebridChannels tvOS v57 SNAP GRID ALIGNED

Universal workflow compatible. Top-left and bottom-left split cards use the exact same row heights as the right-side 4x2 poster grid. Search icon is isolated at far right.
