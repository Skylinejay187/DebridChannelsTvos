# Signal vBRDC261 — app-wide performance hardening

Baseline: vBRDC259 (accepted Aether 6.81 Live TV playback and accepted Live TV Grid presentation).

This build intentionally does NOT carry the rejected vBRDC260 Live TV re-layout, animation pausing, Settings delayed-panel remount, or focus-settle redesign.

Changes:
- Product display name becomes Signal while preserving bundle IDs, storage keys, backend/API contracts, and DebridChannels internal identifiers for migration safety.
- Top-left chrome wordmark becomes SIGNAL with the orange broadcast-wave treatment.
- VOD overlay removes the redundant manual Resume chip; automatic/durable resume is unchanged. That slot becomes Player Engine and opens the existing AetherEngine / KSPlayer selector.
- VOD overlay chips are modestly smaller without reintroducing scrolling.
- Live TV visual geometry/layout is inherited directly from vBRDC259.
- Source Intelligence rejects duplicate provider-status publications before touching its @Published array, and incremental In-S text publications are de-duplicated.
- Live TV focus prefetch is bounded to a smaller near-focus corridor; high-resolution program-art prefetch is limited to the closest cards. Visible card artwork behavior is unchanged.
- Settings category debounce is reduced conservatively from 240 ms to 140 ms, without v260's delayed heavy-panel remount.

Performance methodology follows Apple's current SwiftUI guidance: reduce long view-body work, eliminate unnecessary observable publications, keep heavyweight image/network work off the interactive frame, and preserve lazy collection identity. No visual-effect removal is used as a substitute for fixing work per frame.

No VOD cache or Live TV timeshift/DVR work is included. v259 Aether Live TV recovery ladder remains the playback foundation.
