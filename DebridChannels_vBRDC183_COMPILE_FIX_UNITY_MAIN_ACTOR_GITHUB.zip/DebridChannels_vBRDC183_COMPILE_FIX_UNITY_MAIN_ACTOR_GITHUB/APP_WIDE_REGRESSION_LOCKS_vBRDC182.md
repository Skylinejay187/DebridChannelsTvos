# vBRDC182 Regression Locks

- Donor and rollback point is packaged vBRDC180.
- Do not import v181 Guide theme-selector architecture.
- Catalog content/layout remains v180 behavior.
- Live TV cards retain v180's v161 exact visual donor appearance.
- Preserve v179/v180 Live TV All Channels / station / Up Next header additions.
- Preserve 4x3 paging and bottom-right PAGE indication.
- Preserve Guide preview and separate Exit/Back hint.
- Dynamic wallpaper remains Live TV Grid-only, not full Guide.
- Alternate Audio production files remain unchanged from v180.
- Adaptive VOD cache PlaybackKit remains unchanged from v180.
- KSPNUVIO fork remains unchanged.
- Persistent top navigation is one root host; do not reintroduce per-surface top-menu instances.
- UNITY palette is shared color infrastructure; surface layouts remain independently modifiable.
- Pure Black must not receive a forced blue/cyan background wash.
