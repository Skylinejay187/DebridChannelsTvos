DebridChannels tvOS v745_NATIVE_STYLE_VOD_OVERLAY_MPV_RT_ARTWORK2_5_FIX

- Rebuilt VOD chrome toward compact Apple-native overlay behavior.
- Preserved v742+ Libmpv.framework packaging/signing base from v744.
- MPV now reports runtime loadfile/render diagnostics and falls back only after an MPV attempt fails.
- Rotten Tomatoes display uses OMDb score as an RT badge when available.
- Artwork 2 and Artwork 5 Floating were tuned to keep Live TV grid visible while focused catalog artwork updates without stale reuse.
