# vBRDC362 — Preview Mirror Exit-Only Ghost Cleanup

Patch-forward from vBRDC361.

- Restores Preview Mirror chrome visibility while Movies/Shows catalogs are open.
- Keeps the vBRDC361 atomic catalog-exit compositor retirement so the outgoing catalog/dimmed dashboard cannot overlap the restored Live TV root.
- Does not require an Up/Down focus movement to clear a stale/ghosted frame.
- Preserves v360/v361 wall-clock sync, UP NEXT-only footer, VOD engine-chip removal, direct trailer previews, and 1-hour trailer cache.
- Version 1.0.1064 / build 1064.
