# vBRDC385R1 — Phase 3 VOD Disk Cache Settings + Scrubber Indicator

Base: vBRDC385 / 1.0.1087 / build 1087. Phase 3 correction only.

## Changes
- Adds VOD Player settings: Auto (Recommended), 1 GB, 2 GB, 3 GB, Unlimited (Not Recommended).
- Cache policy is passed only to Aether VOD sessions; Live TV/timeshift is unchanged.
- Uses Aether's disk-backed VOD race-ahead/prefetch architecture. Signal does not allocate the selected GB amount in RAM.
- GB choices are cache targets implemented through Aether's forward prefetch window. Exact resident bytes vary with source bitrate/container and remain subject to Aether's free-volume safety clamp.
- Auto preserves the vBRDC385 adaptive source-aware behavior.
- Unlimited requests Aether's maximum 2700-segment prefetch window but remains bounded by Aether storage safety.
- VOD scrubber cached-ahead range continues to use Aether's authoritative bufferedPosition and is now rendered as a more distinct cyan cache band/end marker.

## Regression locks
- vBRDC383R7 Live TV audio/video stability untouched.
- vBRDC384F3 Live TV timeshift behavior untouched.
- vBRDC385 subtitle and VOD amplification work preserved.
- No top-menu, logo, catalog-exit, navigation, or ambient lifecycle changes.

## Validation
- Swift parse: DebridChannelsTVOSApp.swift
- Swift parse: UniversalCodecSupport.swift
- Swift parse: PlaybackKitAetherSurface.swift
- Swift parse: packaged AetherPlaybackBridge.swift
- Packaged/dormant Aether bridge copies byte-identical
- Aether fetch/patch shell syntax validation
