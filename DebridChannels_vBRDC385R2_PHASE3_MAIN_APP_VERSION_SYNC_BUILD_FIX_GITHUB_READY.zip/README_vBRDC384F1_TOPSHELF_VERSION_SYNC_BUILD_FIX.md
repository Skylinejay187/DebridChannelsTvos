# vBRDC384F1 — Top Shelf Version Sync Build Fix

Base: vBRDC384 Phase 2 Live TV Timeshift.

GitHub Actions failure corrected:
- Main app MARKETING_VERSION remains 1.0.1086 / build 1086.
- DebridChannelsTopShelf project settings already specified 1.0.1086 / 1086.
- TopShelfExtension/Info.plist was stale at 1.0.1085 / 1085 and caused the post-build version validation script to fail.
- TopShelfExtension/Info.plist is now synchronized to 1.0.1086 / 1086.

No playback, timeshift, navigation, top-menu, logo, catalog, ambient, or R7 regression-lock code was changed.
