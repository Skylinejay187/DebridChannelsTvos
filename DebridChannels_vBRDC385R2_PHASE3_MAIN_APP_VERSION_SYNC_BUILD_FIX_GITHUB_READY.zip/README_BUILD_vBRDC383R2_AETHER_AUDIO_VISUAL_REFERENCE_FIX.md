# vBRDC383R2 — Phase 1 intermediate physical-device fix

Authoritative base: vBRDC383, itself patched only from vBRDC382 / 1.0.1084.
Version lineage remains Phase 1 / vBRDC383. Marketing/build stays 1.0.1085 / 1085 until Phase 1 is physically confirmed.

## Live audio
Physical Apple TV testing showed video can continue while Live TV audio becomes silent in both Preview and full-screen even without `audioDelivery == .droppedNoPipeline`.
For remote HLS, R2 therefore bypasses Aether's direct remote-HLS first rung and starts with `HLSLiveIngestReader`, preserving headers across master/media playlists, segments and keys. The existing bounded software-decode recovery remains the next rung. `.standard` live join and delayed presentation remain locked; `.fastZap` is not restored.

## Ambient visual correction
The v64/v66 source supplied by the user was inspected as visual reference only. R2 restores its proven construction principle: large heavily blurred overlapping ellipse/capsule smoke banks, slow 10-second drift and screen blending. Current v382/v383 UI ownership remains unchanged. Orbs/Deadlight is rebuilt from the same soft capsule language behind black glass, with no discrete dots/rings/wires and substantially lower visibility.

## Scope
No timeshift, no VOD cache, no UI redesign, no membership/catalog/Preview Mirror behavior changes. Phase 1 remains unconfirmed until physical Apple TV audio is continuous.
