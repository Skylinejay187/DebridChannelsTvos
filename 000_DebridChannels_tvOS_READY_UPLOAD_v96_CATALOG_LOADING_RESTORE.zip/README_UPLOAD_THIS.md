# Debrid Channels tvOS v96 Stremio Restore + Playback

Upload this ZIP to the GitHub repository root and run the included build workflow.

## What changed

- Adds optional `TVVLCKit` CocoaPods integration for libVLC-based tvOS playback fallback.
- Adds `UniversalCodecSupport.swift`.
- Routes MKV/DTS/TrueHD/Atmos/codec-edge-case looking streams to the TVVLCKit surface when the framework is available.
- Keeps AVFoundation as the fast Apple-native default for normal HLS/MP4/direct streams.
- Updates the GitHub Actions workflow to run `pod install --repo-update` when a Podfile exists and build the generated workspace.
- If CocoaPods/TVVLCKit cannot resolve, the workflow falls back to the normal Xcode project build with AVFoundation only.

## Build marker

`DEBRID_CHANNELS_TVOS_BUILD_V96_STREMIO_RESTORE_PLAYBACK`

## Important

Raw magnet/torrent playback still needs a modern torrent framework/service path. This build adds the codec player fallback package. Direct TorBox/debrid HTTP(S) stream URLs remain the recommended playable path.
