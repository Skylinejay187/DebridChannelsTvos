# Debrid Channels v1102 — Phase 5 Search Source Identity Fix

Base: **v1101 only**  
Marketing version: **1.0.630**  
Build: **630**

## Why Search showed posters but no links

The unified Search catalog was working. The failure occurred after opening a result:

1. A TMDB card could resolve an IMDb ID, but the hydration helper wrote it only into the temporary `id` field and left `imdbId` empty.
2. Search correctly kept the visible popup/card identity stable, which unintentionally discarded that temporary IMDb `id`.
3. Identifier-only hydration was ignored when artwork stayed the same.
4. Find Links and Play then queried providers using only the sparse TMDB/search identity, producing false zero-link results for addons that require IMDb/Cinemeta identity.

## Fix

- Store the resolved IMDb value in `MediaItem.imdbId`.
- Apply Search hydration when IMDb, TMDB, TVDB, addon identity, ID, or artwork improves.
- Use the existing identity-recovery resolver path for Search-origin movie/show **Find Links** and **Play**.
- Keep exact episode searches isolated from parent-title fallback.
- Preserve Search results inside Search, the Search card animation, popup restoration, and all Phase 0–5 behavior.

## Backend

**No backend update is required.** Continue using backend **v668**.

## Validation

- 45 Swift files parsed successfully.
- Standalone Search identity helper type-check passed.
- Search source identity contract passed 12/12 checks.
- App and Top Shelf plists validated.
- `project.yml` parsed and version/build values match both plists.
- No baseline files removed.
- Only the five expected app/project files changed.
- KSPlayer, trailer, Live TV, Stable Protection, and Alternate Audio files remain byte-identical to v1101.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV Search → Details → Find Links and Search → Play testing is required.
