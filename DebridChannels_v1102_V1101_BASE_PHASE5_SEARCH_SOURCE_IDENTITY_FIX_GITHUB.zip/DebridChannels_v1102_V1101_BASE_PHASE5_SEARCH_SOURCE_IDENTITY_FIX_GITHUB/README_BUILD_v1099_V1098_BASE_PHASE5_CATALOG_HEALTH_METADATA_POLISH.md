# Debrid Channels tvOS/iOS v1099

## Phase 5 — Catalog Health + queued VOD metadata polish

- Base: `DebridChannels_v1098_V1097_BASE_ALTERNATE_AUDIO_LIFECYCLE_STABILIZATION_GITHUB.zip`
- Marketing version: `1.0.627`
- Build: `627`
- Backend update required: **No**
- Compatible backend: continue using backend v668.

## Catalog Health

A new **Settings → Catalog Health** page reports:

- configured catalog providers using privacy-safe host labels;
- expected and currently loaded row counts;
- total poster count and poster count for every row;
- per-row pagination status;
- last successful refresh and last full-pagination refresh;
- failed, empty, and timed-out providers;
- failed pagination pages with row, page, and skip information;
- reload one row, reload all catalogs, and refresh the health snapshot;
- clear catalog cache without deleting accounts, provider configuration, favorites, watch progress, Live TV sources, or episode alerts.

Provider/page state updates only at existing catalog request boundaries. There is no polling loop and the diagnostics page does not invalidate catalog rails while closed. Failed refreshes continue to leave the last-known-good catalog visible.

## VOD and media-information cleanup

- Featured Cast only accepts valid HTTP/HTTPS profile images.
- Failed, missing, malformed, placeholder, silhouette, and image-less cast entries are omitted.
- No actor-name fallback tiles are created when artwork is unavailable.
- Season/episode text is removed from the VOD poster artwork.
- Season and episode remain visible in the information section.
- Episode air/release dates are shown in the media-information profile and VOD information stage.
- Future episode dates are explicitly labeled `UPCOMING`; current-day and past episodes are labeled `TODAY` and `AIRED`.

## Protected behavior

This pass does not change:

- Tapframe KSPNUVIO or `PlaybackKitKSPlayerSurface.swift`;
- Alternate Audio discovery, bridge, handoff, or lifecycle clients;
- trailer service/resolver files;
- Live TV guide cache or premium Live TV UI;
- Search-contained results, Favorites behavior, episode alerts, catalog focus policy, or focused-card pulse;
- backend routes or deployment files.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before v1099 becomes the next stable base.
