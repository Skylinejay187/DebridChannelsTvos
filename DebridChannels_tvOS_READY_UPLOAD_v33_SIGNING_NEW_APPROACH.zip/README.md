# Debrid Channels tvOS v33 Signing Approach

Upload this repo zip to GitHub and run:

00 Build tvOS IPA From Source ZIP

GitHub will create three separate downloadable artifacts:
1. 01-upload-this-to-signulous-v33
2. 02-backup-adhoc-v33
3. 03-backup-payload-folder-v33

Download artifact #1, extract it, and upload the IPA inside to Signulous.
Do not upload the GitHub artifact ZIP itself.
