# Signal F27 Apple TV Build/Test Candidate — 1.0.1133 (1133)

This is a complete GitHub/Xcode source tree, not a precompiled IPA or a verified tvOS build.

## Included
- AetherEngine FastZap for grid and Guide previews.
- Optional full-screen FastZap setting (Standard default) and trade-off warning.
- Up Next EOF/readiness/source-verification/buffer-safety patches; fixed 30-second trigger removed.
- AetherEngine cache-backed VOD scrub thumbnails when supported.
- F26 MediaFlow Light, timeshift, VOD cache, and other existing features preserved.

## Outstanding
Native AetherEngine byte prewarming is NOT integrated. The pinned AetherEngine 6.89.1 API needs verification. Up Next source discovery/preparation is improved, but this does not claim native byte prewarming.

## Build
Use the repository's existing GitHub Actions tvOS workflow or XcodeGen on macOS. Dependency preparation fetches AetherEngine and its namespaced FFmpeg stack. Linux cannot run the full Xcode/tvOS build.

## Apple TV regression tests
1. Grid/Guide preview first-frame timing and audio stability.
2. Full-screen Standard vs FastZap, timeshift and channel switching.
3. VOD thumbnail scrubbing on cached/uncached and single-connection sources.
4. Up Next EOF, cancellation, unavailable sources, and duplicate-player avoidance.
5. MediaFlow Light, HDHomeRun, catalog focus, resume, and playback stability.

If GitHub compilation fails, keep F26 installed and share the full build log.
