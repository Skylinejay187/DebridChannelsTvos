# vBRDC231 — MPVKit Primary Dependency Collision Fix

Version: 1.0.934 (934)

## Build error fixed
GitHub Actions failed during Swift Package resolution before compilation because KSPNUVIO depends on FFmpegKit while MPVKit ships its own FFmpeg targets with the same module/target names (`Libavcodec`, `Libavdevice`, `Libavfilter`, and others). Xcode 16.4 rejects both package graphs in the same target.

## Resolution
- MPVKit remains the production-primary playback engine.
- Removed the KSPlayer SwiftPM dependency from the app target.
- Removed the KSPNUVIO pre-generation fetch/patch step so FFmpegKit is not introduced into the package graph.
- Kept the KSPlayer implementation source behind `#if canImport(KSPlayer)` as dormant source only; it compiles out of this build.
- AVPlayer/TVVLCKit compatibility paths remain available if MPVKit cannot play a source.
- No Live TV Unity, Grid/List/EPG, instant-handoff, first-frame transition, MPV cache, time-shift, resume, Bluetooth/Now Playing, or source-failover behavior was intentionally changed.

## Root cause from logs_93587134590.zip
`xcodebuild -list` failed resolving packages with: multiple similar targets `Libavcodec`, `Libavdevice`, `Libavfilter` and 10 others in `ffmpegkit` and `mpvkit`.

## Validation
- Swift parse performed on application sources.
- project.yml contains MPVKit only in SwiftPM package graph.
- Version alignment checked for app and Top Shelf.
- ZIP integrity checked.
- Full Xcode/tvOS linking remains authoritative in GitHub Actions.
