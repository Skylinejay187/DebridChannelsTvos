Debrid Channels tvOS v44 - menu-clear portrait poster geometry, stable 1+8 layout, v14 signing/package structure preserved.
