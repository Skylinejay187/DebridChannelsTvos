import SwiftUI
import Foundation

struct MediaItem: Identifiable, Hashable {
    let id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String? = nil
    // v274: Preserve the Stremio JSON add-on identity that supplied this catalog item
    // so UI cards/details can show the corresponding add-on icon/source name.
    var addonName: String? = nil
    var addonIconURL: String? = nil
    var seasonNumber: Int? = nil
    var episodeNumber: Int? = nil
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StremioAddonIdentity: Hashable {
    var name: String
    var iconURL: String?
    var kind: String
}

struct StreamLink: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String?
    var quality: String
    var size: String
    var source: String
    var infoHash: String? = nil
    var fileIndex: Int? = nil
    var subtitleURLs: [String] = []
    var isExternalURL: Bool = false

    var isDirectPlayable: Bool {
        guard let url else { return false }
        if isExternalURL { return false }
        guard let components = URLComponents(string: url), let scheme = components.scheme?.lowercased(), scheme == "http" || scheme == "https" else { return false }
        let lower = url.lowercased()
        // v92: Debrid providers such as TorBox/Real-Debrid often return signed CDN URLs with no file extension.
        // Treat HTTP(S) stream.url as playable unless it is clearly a webpage/configuration/deep-link.
        if lower.hasPrefix("stremio://") || lower.hasPrefix("magnet:") { return false }
        if lower.contains("/configure") || lower.contains("youtube.com") || lower.contains("youtu.be") { return false }
        if lower.contains("/manifest.json") || lower.contains("/catalog/") || lower.contains("/meta/") { return false }
        if lower.contains("imdb.com/title") || lower.contains("themoviedb.org") { return false }
        return true
    }
}


struct AlternateAudioSource: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String
    var quality: String
    var source: String
    var confidence: String

    var displayTitle: String {
        let cleanQuality = quality.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanSource = source.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleanQuality.isEmpty { return "\(title) • \(cleanSource)" }
        return "\(title) • \(cleanQuality) • \(cleanSource)"
    }
}

struct StremioStreamResponse: Decodable {
    var streams: [StremioStream]?
}

struct StremioStream: Decodable {
    var title: String?
    var name: String?
    var url: String?
    var infoHash: String?
    var externalUrl: String?
    var fileIdx: Int?
    var behaviorHints: StremioBehaviorHints?
    var subtitles: [StremioSubtitle]?
}

struct StremioSubtitle: Decodable, Hashable {
    var id: String?
    var url: String?
    var lang: String?
    var language: String?
    var label: String?
}

struct StremioBehaviorHints: Decodable {
    var filename: String?
    var videoSize: Int64?
    var videoHash: String?
    var bingeGroup: String?
}

struct StremioManifest: Decodable {
    var name: String?
    var logo: String?
    var icon: String?
    var catalogs: [StremioCatalog]?
    var resources: [StremioResource]?
    var types: [String]?
    var idPrefixes: [String]?
}

struct StremioResource: Decodable, Hashable {
    var name: String?
    var types: [String]?
    var idPrefixes: [String]?

    enum CodingKeys: String, CodingKey {
        case name
        case types
        case idPrefixes
    }

    init(name: String? = nil, types: [String]? = nil, idPrefixes: [String]? = nil) {
        self.name = name
        self.types = types
        self.idPrefixes = idPrefixes
    }

    // Stremio manifests legally expose resources as either strings:
    //   "resources": ["catalog", "meta", "stream", "subtitles"]
    // or objects:
    //   { "name": "stream", "types": ["movie", "series"] }
    // The old decoder only accepted object form, which could break whole addon/catalog loading.
    init(from decoder: Decoder) throws {
        let single = try decoder.singleValueContainer()
        if let value = try? single.decode(String.self) {
            name = value
            types = nil
            idPrefixes = nil
            return
        }
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        types = try container.decodeIfPresent([String].self, forKey: .types)
        idPrefixes = try container.decodeIfPresent([String].self, forKey: .idPrefixes)
    }
}

struct StremioExtra: Decodable, Hashable {
    var name: String?
    var isRequired: Bool?
    var options: [String]?

    enum CodingKeys: String, CodingKey {
        case name
        case isRequired = "isRequired"
        case options
    }

    init(name: String? = nil, isRequired: Bool? = nil, options: [String]? = nil) {
        self.name = name
        self.isRequired = isRequired
        self.options = options
    }

    // Real Stremio addons do not all encode extras perfectly. Some send option values as
    // numbers/bools/nulls instead of strings. A strict decoder made the whole manifest fail.
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        name = try container.decodeIfPresent(String.self, forKey: .name)
        isRequired = try container.decodeIfPresent(Bool.self, forKey: .isRequired)
        if let strings = try? container.decodeIfPresent([String].self, forKey: .options) {
            options = strings
        } else if let values = try? container.decodeIfPresent([LossyJSONValue].self, forKey: .options) {
            options = values.compactMap { $0.stringValue }
        } else {
            options = nil
        }
    }
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
    var extra: [StremioExtra]?
    var extraSupported: [String]?
    var extraRequired: [String]?
}

struct StremioMetaResponse: Decodable {
    var meta: StremioMeta?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?

    enum CodingKeys: String, CodingKey { case metas }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        // Decode metas one by one so a single unusual Stremio item cannot break the whole catalog.
        if var nested = try? container.nestedUnkeyedContainer(forKey: .metas) {
            var decoded: [StremioMeta] = []
            while !nested.isAtEnd {
                if let meta = try? nested.decode(StremioMeta.self) {
                    decoded.append(meta)
                } else {
                    _ = try? nested.decode(LossySkipValue.self)
                }
            }
            metas = decoded
        } else {
            metas = nil
        }
    }
}

struct LossySkipValue: Decodable {}

struct StremioTrailer: Decodable {
    var source: String?
    var type: String?
    var title: String?
}

struct StremioVideo: Decodable {
    var id: String?
    var name: String?
    var url: String?
    var src: String?
    var source: String?
    var type: String?
    var title: String?
    var season: Int?
    var episode: Int?
    var overview: String?
    var description: String?
    var released: String?
    var thumbnail: String?
}

enum LossyJSONValue: Decodable, Hashable {
    case string(String)
    case int(Int)
    case double(Double)
    case bool(Bool)
    case null

    var stringValue: String? {
        switch self {
        case .string(let value): return value
        case .int(let value): return String(value)
        case .double(let value):
            if value.rounded() == value { return String(Int(value)) }
            return String(value)
        case .bool(let value): return String(value)
        case .null: return nil
        }
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if container.decodeNil() { self = .null; return }
        if let value = try? container.decode(String.self) { self = .string(value); return }
        if let value = try? container.decode(Int.self) { self = .int(value); return }
        if let value = try? container.decode(Double.self) { self = .double(value); return }
        if let value = try? container.decode(Bool.self) { self = .bool(value); return }
        self = .null
    }
}

struct StremioMeta: Decodable {
    var id: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
    var trailers: [StremioTrailer]?
    var videos: [StremioVideo]?
    var trailer: String?
    var preview: String?
    var previewVideo: String?

    enum CodingKeys: String, CodingKey {
        case id, name, type, poster, background, logo, description, releaseInfo, genres, imdbRating, trailers, videos, trailer, preview, previewVideo
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = StremioMeta.decodeString(container, .id)
        name = StremioMeta.decodeString(container, .name)
        type = StremioMeta.decodeString(container, .type)
        poster = StremioMeta.decodeString(container, .poster)
        background = StremioMeta.decodeString(container, .background)
        logo = StremioMeta.decodeString(container, .logo)
        description = StremioMeta.decodeString(container, .description)
        releaseInfo = StremioMeta.decodeString(container, .releaseInfo)
        imdbRating = StremioMeta.decodeString(container, .imdbRating)
        trailer = StremioMeta.decodeString(container, .trailer)
        preview = StremioMeta.decodeString(container, .preview)
        previewVideo = StremioMeta.decodeString(container, .previewVideo)

        if let genreArray = try? container.decodeIfPresent([String].self, forKey: .genres) {
            genres = genreArray
        } else if let singleGenre = try? container.decodeIfPresent(String.self, forKey: .genres) {
            genres = [singleGenre]
        } else if let mixedGenres = try? container.decodeIfPresent([LossyJSONValue].self, forKey: .genres) {
            genres = mixedGenres.compactMap { $0.stringValue }
        } else {
            genres = nil
        }

        // Trailer/video objects vary by addon. Do not let optional media decorations break the whole catalog row.
        trailers = (try? container.decodeIfPresent([StremioTrailer].self, forKey: .trailers)) ?? nil
        videos = (try? container.decodeIfPresent([StremioVideo].self, forKey: .videos)) ?? nil
    }

    private static func decodeString(_ container: KeyedDecodingContainer<CodingKeys>, _ key: CodingKeys) -> String? {
        if let value = try? container.decodeIfPresent(String.self, forKey: key) { return value }
        if let value = try? container.decodeIfPresent(Int.self, forKey: key) { return String(value) }
        if let value = try? container.decodeIfPresent(Double.self, forKey: key) {
            if value.rounded() == value { return String(Int(value)) }
            return String(value)
        }
        if let value = try? container.decodeIfPresent(Bool.self, forKey: key) { return String(value) }
        return nil
    }
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case live = "Live TV"
    case settings = "Settings"
    var id: String { rawValue }
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var selectedTab: AppTab = .live
    @Published var status: String = "Build v323: Xtream/M3U live-first loader with real channel batch commits and off-main Xtream JSON parsing."
    @Published var addonIdentities: [String: StremioAddonIdentity] = [:]
    @Published var menuFocusToken: Int = 0
    @Published var contentFocusToken: Int = 0
    @Published var topMenuFocusLocked: Bool = false
    @Published var liveQuickPanelOpen: Bool = false
    @Published var isLoading: Bool = false
    @Published var manifestURLs: [String] = []
    @Published var selectedDetail: MediaItem? = nil
    @Published var playbackURL: URL? = nil
    @Published var playbackItem: MediaItem? = nil
    @Published var playbackFallbackURLs: [URL] = []
    @Published var playbackSubtitleURLs: [URL] = []
    @Published var playbackLinkLabel: String = ""
    @Published var streamLinks: [StreamLink] = []
    @Published var alternateAudioSources: [AlternateAudioSource] = []
    @Published var selectedAlternateAudioSource: AlternateAudioSource? = nil
    @Published var alternateAudioSyncOffsetMS: Int = 0
    @Published var lastStreamMessage: String = ""
    @Published var detailBackStack: [MediaItem] = []
    @Published var searchActive: Bool = false

    private let manifestsKey = "stremioManifestURLs"
    private let coreMetadataManifestURL = "https://v3-cinemeta.strem.io/manifest.json"

    init() {
        let saved = UserDefaults.standard.stringArray(forKey: manifestsKey) ?? []
        if saved.isEmpty {
            manifestURLs = [coreMetadataManifestURL]
        } else {
            // v96 regression fix: stream-only addons like Torrentio/TorBox usually do not provide catalogs.
            // Keep Cinemeta metadata available so Home rows/detail items still have real imdb IDs to query streams with.
            var restored = saved
            if !restored.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
                restored.insert(coreMetadataManifestURL, at: 0)
            }
            manifestURLs = restored
            UserDefaults.standard.set(restored, forKey: manifestsKey)
        }
    }


    func searchResults(for query: String) -> [MediaItem] {
        let all = rows.flatMap { $0.items }
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return Array(all.prefix(25))
        }
        let q = trimmed.lowercased()
        var seen = Set<String>()
        let matches = all.filter { item in
            let haystack = [item.title, item.year, item.type, item.catalog, item.description, item.rating] + item.genres
            return haystack.joined(separator: " ").lowercased().contains(q)
        }
        return matches.filter { seen.insert($0.id).inserted }.prefix(40).map { $0 }
    }

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func directPreviewURL(for item: MediaItem) -> URL? {
        guard let preview = item.previewURL, let url = URL(string: preview) else { return nil }
        let lower = preview.lowercased()
        // Internal player needs a direct MP4/M3U8/MOV style URL. YouTube page IDs/links must be converted by backend.
        if lower.contains("youtube.com") || lower.contains("youtu.be") { return nil }
        return url
    }

    func findStreams(for item: MediaItem) async -> [StreamLink] {
        lastStreamMessage = "Searching every configured Stremio addon for \(item.title)…"
        streamLinks = []

        let urlSession = URLSession.shared
        let typeCandidates = streamTypeCandidates(for: item)
        let idCandidates = streamIDCandidates(for: item)
        var found: [StreamLink] = []
        var seenKeys = Set<String>()
        var attempts = 0
        var addonFailures: [String] = []

        // v310: Xtream Codes VOD/series support. This is additive only: it reads the
        // existing Xtream settings and exposes matching movie/episode URLs in the
        // same link picker as Stremio/debrid links. It does not touch Live TV guide loading.
        let xtreamLinks = await findXtreamVODLinks(for: item)
        for link in xtreamLinks {
            let key = "\(link.source)|\(link.url ?? link.title)"
            guard !seenKeys.contains(key) else { continue }
            seenKeys.insert(key)
            found.append(link)
        }
        if !found.isEmpty {
            streamLinks = sortedStreamLinks(found)
            lastStreamMessage = "Found \(streamLinks.count) Xtream link(s). Still scanning configured Stremio addons…"
        }

        for rawManifest in manifestURLs {
            let manifestCandidates = manifestURLCandidates(from: rawManifest)
            var manifestDecoded: StremioManifest? = nil
            var workingManifestURL: URL? = nil

            for candidate in manifestCandidates {
                guard let candidateURL = URL(string: candidate) else { continue }
                do {
                    let (data, response) = try await urlSession.data(from: candidateURL)
                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    manifestDecoded = try JSONDecoder().decode(StremioManifest.self, from: data)
                    let identityName = manifestDecoded?.name ?? candidateURL.host ?? "Stremio"
                    let identityIcon = Self.highest(manifestDecoded?.logo ?? manifestDecoded?.icon)
                    await MainActor.run {
                        self.addonIdentities[rawManifest] = StremioAddonIdentity(name: identityName, iconURL: identityIcon, kind: self.addonKind(from: manifestDecoded!))
                    }
                    workingManifestURL = candidateURL
                    break
                } catch {
                    continue
                }
            }

            guard let manifestURL = workingManifestURL else {
                addonFailures.append("Could not load manifest from \(rawManifest). Configure-page URLs must resolve to /manifest.json or a configured addon URL.")
                continue
            }

            let base = normalizedStremioBase(from: manifestURL.absoluteString)
            let sourceName = manifestDecoded?.name ?? manifestURL.host ?? "Stremio"
            let addonTypes = expandedStreamTypes(typeCandidates: typeCandidates, manifest: manifestDecoded)
            let addonIDs = idCandidates

            for type in addonTypes {
                for streamID in addonIDs {
                    guard let encodedID = streamID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let streamURL = URL(string: "\(base)/stream/\(type)/\(encodedID).json") else { continue }
                    attempts += 1
                    do {
                        let (data, response) = try await urlSession.data(from: streamURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioStreamResponse.self, from: data)
                        for stream in decoded.streams ?? [] {
                            let title = stream.title ?? stream.name ?? stream.behaviorHints?.filename ?? "Stream"
                            // Stremio convention: `url` is the playable URL when the addon has resolved it.
                            // `externalUrl` is usually a browser/page handoff, so keep it visible but do not treat it as guaranteed playback.
                            let playableURL = stream.url ?? stream.externalUrl
                            let isExternalOnly = (stream.url == nil && stream.externalUrl != nil)
                            let sizeText: String
                            if let bytes = stream.behaviorHints?.videoSize, bytes > 0 {
                                let gb = Double(bytes) / 1_073_741_824.0
                                sizeText = String(format: "%.1f GB", gb)
                            } else {
                                sizeText = parsedSizeText(from: title) ?? "Unknown size"
                            }
                            let quality = parsedQuality(from: title)
                            let key = "\(sourceName)|\(playableURL ?? stream.infoHash ?? title)|\(stream.fileIdx ?? -1)"
                            guard !seenKeys.contains(key) else { continue }
                            seenKeys.insert(key)
                            let subtitleURLs = (stream.subtitles ?? []).compactMap { sub -> String? in
                                guard let raw = sub.url?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
                                return raw
                            }
                            found.append(StreamLink(title: title, url: playableURL, quality: quality, size: sizeText, source: sourceName, infoHash: stream.infoHash, fileIndex: stream.fileIdx, subtitleURLs: subtitleURLs, isExternalURL: isExternalOnly))
                        }

                        if !found.isEmpty {
                            streamLinks = sortedStreamLinks(found)
                            lastStreamMessage = "Found \(streamLinks.count) link(s) so far. Still scanning all addons…"
                        }
                    } catch {
                        continue
                    }
                }
            }
        }

        let sorted = sortedStreamLinks(found)
        streamLinks = sorted
        if sorted.isEmpty {
            let failureHint = addonFailures.isEmpty ? "" : " \(addonFailures.prefix(2).joined(separator: " "))"
            lastStreamMessage = "No stream links found for \(item.title) after \(attempts) stream endpoint checks.\(failureHint) For Torrentio/TorBox, add the actual configured manifest URL, not only the configure webpage, and make sure the addon returns stream.url/direct links."
        } else {
            let playableCount = sorted.filter { $0.isDirectPlayable }.count
            lastStreamMessage = "Found \(sorted.count) total link(s), \(playableCount) direct-playable, for \(item.title) across all configured addons."
        }
        return sorted
    }

    private func manifestURLCandidates(from raw: String) -> [String] {
        // v96: Accept the real-world formats people paste from Stremio/Torrentio/TorBox:
        // - https://addon/config/manifest.json
        // - https://addon/configure
        // - https://addon/configure?...
        // - stremio://addon/config/manifest.json
        // - stremio://addon/configure
        // - stremio:///addon/config/manifest.json
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return [] }
        var candidates: [String] = []
        func add(_ value: String) {
            var trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { return }
            if trimmed.hasPrefix("stremio:///") { trimmed = "https://" + String(trimmed.dropFirst("stremio:///".count)) }
            if trimmed.hasPrefix("stremio://") { trimmed = "https://" + String(trimmed.dropFirst("stremio://".count)) }
            while trimmed.hasSuffix("/") { trimmed.removeLast() }
            guard !trimmed.isEmpty, !candidates.contains(trimmed) else { return }
            candidates.append(trimmed)
        }

        add(clean)

        let httpsClean: String
        if clean.hasPrefix("stremio:///") {
            httpsClean = "https://" + String(clean.dropFirst("stremio:///".count))
        } else if clean.hasPrefix("stremio://") {
            httpsClean = "https://" + String(clean.dropFirst("stremio://".count))
        } else {
            httpsClean = clean
        }
        let lower = httpsClean.lowercased()

        // If a configured manifest URL is embedded inside a copied text/link, extract it.
        if let range = httpsClean.range(of: #"https?://[^\s"'<>]+/manifest\.json"#, options: .regularExpression) {
            add(String(httpsClean[range]))
        }

        if lower.contains("/manifest.json?") || lower.contains("/manifest.json#") {
            if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
                add("\(scheme)://\(host)\(url.path)")
            }
        }

        if lower.hasSuffix("/manifest.json") {
            add(httpsClean)
        } else if lower.hasSuffix("/configure") {
            add(String(httpsClean.dropLast("/configure".count)) + "/manifest.json")
        } else if lower.contains("/configure?") || lower.contains("/configure#") {
            if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
                let pathWithoutConfigure = url.path.replacingOccurrences(of: "/configure", with: "")
                if !pathWithoutConfigure.isEmpty, pathWithoutConfigure != "/" {
                    add("\(scheme)://\(host)\(pathWithoutConfigure)/manifest.json")
                }
                add("\(scheme)://\(host)/manifest.json")
            }
        } else if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
            // If user pasted the configured addon base without manifest.json, try preserving its path first.
            if !url.path.isEmpty, url.path != "/" {
                add("\(scheme)://\(host)\(url.path)/manifest.json")
            }
            // Root addon fallback for links like https://torrentio.strem.fun/configure.
            add("\(scheme)://\(host)/manifest.json")
        }
        return candidates
    }

    private func normalizedStremioBase(from manifest: String) -> String {
        var base = manifest
        if base.lowercased().hasSuffix("/configure") { base.removeLast("/configure".count) }
        if base.hasSuffix("/manifest.json") { base.removeLast("/manifest.json".count) }
        if base.hasSuffix("manifest.json") { base.removeLast("manifest.json".count) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    private func catalogEndpointCandidates(base: URL, catalog: StremioCatalog) -> [URL] {
        // Stremio catalog endpoints are:
        //   /catalog/{type}/{id}.json
        //   /catalog/{type}/{id}/{extra}.json
        // where extra is optional but some addons require skip/search/genre. Try only protocol-valid forms.
        let baseString = base.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let type = catalog.type ?? "movie"
        let id = catalog.id ?? "popular"
        let encodedID = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? id
        let encodedType = type.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? type
        var extraCandidates: [String] = []

        func addExtra(_ extra: String?) {
            guard let extra else { return }
            let clean = extra.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty, !extraCandidates.contains(clean) else { return }
            extraCandidates.append(clean)
        }

        // Common Stremio extras. skip=0 is the safest first page fallback.
        addExtra("skip=0")
        addExtra("genre=popular")
        addExtra("search=")

        catalog.extraRequired?.forEach { required in
            if required.lowercased() == "skip" { addExtra("skip=0") }
            else if required.lowercased() == "genre" { addExtra("genre=popular") }
            else if required.lowercased() == "search" { addExtra("search=") }
        }
        catalog.extra?.forEach { extra in
            let name = extra.name?.lowercased()
            if name == "skip" { addExtra("skip=0") }
            else if name == "genre" { addExtra("genre=\((extra.options?.first ?? "popular"))") }
            else if name == "search" { addExtra("search=") }
        }

        var strings = ["\(baseString)/catalog/\(encodedType)/\(encodedID).json"]
        strings.append(contentsOf: extraCandidates.map { extra in
            let encodedExtra = extra.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? extra
            return "\(baseString)/catalog/\(encodedType)/\(encodedID)/\(encodedExtra).json"
        })

        var urls: [URL] = []
        for string in strings {
            if let url = URL(string: string), !urls.contains(url) { urls.append(url) }
        }
        return urls
    }

    private func addonKind(from manifest: StremioManifest) -> String {
        let hasCatalogs = !(manifest.catalogs ?? []).isEmpty
        let hasStream = (manifest.resources ?? []).contains { $0.name?.lowercased() == "stream" }
        if hasCatalogs && hasStream { return "catalog+stream" }
        if hasCatalogs { return "catalog" }
        if hasStream { return "stream-only" }
        return "metadata-only"
    }

    private func expandedStreamTypes(typeCandidates: [String], manifest: StremioManifest?) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !clean.isEmpty, !ordered.contains(clean) else { return }
            ordered.append(clean)
        }
        typeCandidates.forEach { add($0) }
        manifest?.types?.forEach { add($0) }
        manifest?.resources?.filter { $0.name?.lowercased() == "stream" }.forEach { resource in
            resource.types?.forEach { add($0) }
        }
        add("movie")
        add("series")
        return ordered
    }

    private func parsedQuality(from title: String) -> String {
        let lower = title.lowercased()
        if lower.contains("2160") || lower.contains("4k") || lower.contains("uhd") { return "4K" }
        if lower.contains("1080") { return "1080p" }
        if lower.contains("720") { return "720p" }
        if lower.contains("480") { return "480p" }
        return "Auto"
    }

    private func parsedSizeText(from title: String) -> String? {
        let pattern = #"(?i)(\d+(?:\.\d+)?)\s*(GB|MB)"#
        guard let regex = try? NSRegularExpression(pattern: pattern), let match = regex.firstMatch(in: title, range: NSRange(title.startIndex..., in: title)), let range = Range(match.range, in: title) else { return nil }
        return String(title[range])
    }

    private func findXtreamVODLinks(for item: MediaItem) async -> [StreamLink] {
        // v318: disabled. Xtream Codes is Live TV channels only for now.
        return []
    }

    private func normalizedXtreamServer(_ raw: String) -> String? {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if value.isEmpty { return nil }
        if !value.lowercased().hasPrefix("http://") && !value.lowercased().hasPrefix("https://") { value = "http://" + value }
        if value.lowercased().contains("/player_api.php") {
            value = value.replacingOccurrences(of: "/player_api.php", with: "", options: .caseInsensitive)
        }
        while value.hasSuffix("/") { value.removeLast() }
        guard URL(string: value) != nil else { return nil }
        return value
    }

    private func findXtreamMovieLinks(item: MediaItem, base: String, queryUser: String, queryPass: String, pathUser: String, pathPass: String) async -> [StreamLink] {
        // v318: disabled. Xtream Codes Movies/Shows are removed; Live TV channels only.
        return []
    }

    private func findXtreamSeriesLinks(item: MediaItem, base: String, queryUser: String, queryPass: String, pathUser: String, pathPass: String) async -> [StreamLink] {
        // v318: disabled. Xtream Codes Movies/Shows are removed; Live TV channels only.
        return []
    }

    private func fetchXtreamText(_ raw: String, maxBytes: Int) async -> String? {
        guard let url = URL(string: raw) else { return nil }
        do {
            if url.scheme?.lowercased() == "http" {
                let plain = try await PlainHTTPClient.fetchData(from: url, accept: "application/json,*/*", userAgent: "DebridChannels-tvOS/322", maxBytes: maxBytes, timeout: 45)
                guard (200...299).contains(plain.statusCode) else { return nil }
                return String(data: plain.data, encoding: .utf8)
            }
            let (data, response) = try await URLSession.shared.data(from: url)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            guard data.count <= maxBytes else { return nil }
            return String(data: data, encoding: .utf8)
        } catch {
            return nil
        }
    }

    private func bestXtreamMatches(in array: [[String: Any]], for item: MediaItem, nameKeys: [String]) -> [[String: Any]] {
        let target = normalizedTitleForMatching(item.title)
        let targetYear = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
        var scored: [(Int, [[String: Any]].Element)] = []
        for obj in array {
            let name = stringValue(obj, keys: nameKeys)
            let normalized = normalizedTitleForMatching(name)
            guard !normalized.isEmpty else { continue }
            var score = 0
            if normalized == target { score += 100 }
            if normalized.contains(target) || target.contains(normalized) { score += 45 }
            if !targetYear.isEmpty {
                let year = stringValue(obj, keys: ["year", "releaseDate", "releasedate"])
                if year.contains(targetYear) { score += 20 }
            }
            if score > 0 { scored.append((score, obj)) }
        }
        return scored.sorted { $0.0 > $1.0 }.map { $0.1 }
    }

    private func normalizedTitleForMatching(_ value: String) -> String {
        value.lowercased()
            .replacingOccurrences(of: "[^a-z0-9]+", with: " ", options: .regularExpression)
            .split(separator: " ")
            .joined(separator: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func cleanXtreamExtension(_ value: String, fallback: String) -> String {
        let clean = value.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ". /\n\r\t"))
        guard !clean.isEmpty, clean.range(of: "^[a-z0-9]+$", options: .regularExpression) != nil else { return fallback }
        return clean
    }

    private func stringValue(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let s = obj[key] as? String { return s.trimmingCharacters(in: .whitespacesAndNewlines) }
            if let n = obj[key] as? NSNumber { return n.stringValue }
            if let i = obj[key] as? Int { return String(i) }
        }
        return ""
    }

    private func intValue(_ obj: [String: Any], keys: [String]) -> Int {
        for key in keys {
            if let i = obj[key] as? Int { return i }
            if let n = obj[key] as? NSNumber { return n.intValue }
            if let s = obj[key] as? String, let i = Int(s.trimmingCharacters(in: .whitespacesAndNewlines)) { return i }
        }
        return 0
    }

    func findAlternateAudioSources(for item: MediaItem, currentURL: URL, preferredLanguage: String = "English") async -> [AlternateAudioSource] {
        await MainActor.run {
            alternateAudioSources = []
            selectedAlternateAudioSource = nil
        }
        let playable = streamLinks.filter { link in
            guard link.isDirectPlayable, let raw = link.url, let candidate = URL(string: raw) else { return false }
            return candidate.absoluteString != currentURL.absoluteString
        }
        let candidates = buildAlternateAudioCandidates(from: playable, preferredLanguage: preferredLanguage)
        await MainActor.run {
            alternateAudioSources = candidates
            if candidates.isEmpty {
                status = "No alternate playable copies with likely \(preferredLanguage) audio were found yet. Run Find Links first or add more providers."
            } else {
                status = "Found \(candidates.count) alternate audio candidate(s). Select one from Audio to keep the current video and use that copy as the audio source reference."
            }
        }
        return candidates
    }

    private func buildAlternateAudioCandidates(from links: [StreamLink], preferredLanguage: String) -> [AlternateAudioSource] {
        let lowerLanguage = preferredLanguage.lowercased()
        let languageTokens = [lowerLanguage, "english", " eng ", "[eng]", "(eng)", "multi", "dual", "aac", "ac3", "eac3", "dts"]
        var seen = Set<String>()
        let scored = links.compactMap { link -> (Int, AlternateAudioSource)? in
            guard let raw = link.url, !raw.isEmpty else { return nil }
            let combined = "\(link.title) \(link.quality) \(link.size) \(link.source)".lowercased()
            let languageScore = languageTokens.contains(where: { combined.contains($0.trimmingCharacters(in: .whitespacesAndNewlines)) || combined.contains($0) }) ? 0 : 2
            let qualityScore: Int
            if combined.contains("2160") || combined.contains("4k") || combined.contains("uhd") { qualityScore = 4 }
            else if combined.contains("1080") { qualityScore = 2 }
            else if combined.contains("720") { qualityScore = 1 }
            else { qualityScore = 3 }
            let confidence = languageScore == 0 ? "Likely \(preferredLanguage)" : "Playable copy — verify audio"
            let key = raw.lowercased()
            guard !seen.contains(key) else { return nil }
            seen.insert(key)
            return (languageScore * 10 + qualityScore, AlternateAudioSource(title: link.title, url: raw, quality: link.quality, source: link.source, confidence: confidence))
        }
        return scored.sorted { lhs, rhs in lhs.0 == rhs.0 ? lhs.1.title < rhs.1.title : lhs.0 < rhs.0 }.map(\.1).prefix(10).map { $0 }
    }

    func selectAlternateAudioSource(_ source: AlternateAudioSource?, for item: MediaItem) {
        selectedAlternateAudioSource = source
        alternateAudioSyncOffsetMS = storedAlternateAudioSyncOffset(for: item, source: source)
        if let source {
            status = "Alternate audio source selected: \(source.displayTitle). Use sync controls if the copy has a different intro/cut."
        } else {
            status = "Alternate audio source cleared. Playback is using the selected stream audio only."
        }
    }

    func adjustAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?, deltaMS: Int) {
        alternateAudioSyncOffsetMS += deltaMS
        saveAlternateAudioSyncOffset(for: item, source: source, offsetMS: alternateAudioSyncOffsetMS)
        status = "Alternate audio sync offset: \(alternateAudioSyncOffsetMS)ms."
    }

    func resetAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?) {
        alternateAudioSyncOffsetMS = 0
        saveAlternateAudioSyncOffset(for: item, source: source, offsetMS: 0)
        status = "Alternate audio sync reset to 0ms."
    }

    func storedAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?) -> Int {
        UserDefaults.standard.integer(forKey: alternateAudioSyncKey(for: item, source: source))
    }

    private func saveAlternateAudioSyncOffset(for item: MediaItem, source: AlternateAudioSource?, offsetMS: Int) {
        UserDefaults.standard.set(offsetMS, forKey: alternateAudioSyncKey(for: item, source: source))
    }

    private func alternateAudioSyncKey(for item: MediaItem, source: AlternateAudioSource?) -> String {
        let sourcePart = source?.url ?? "default"
        return "smartAltAudioSyncMS|\(item.id)|\(sourcePart.hashValue)"
    }

    private func sortedStreamLinks(_ links: [StreamLink]) -> [StreamLink] {
        let rank: [String: Int] = ["4K": 0, "1080p": 1, "720p": 2, "480p": 3, "Auto": 4]
        func nativePenalty(_ link: StreamLink) -> Int {
            guard let raw = link.url?.lowercased() else { return 9 }
            if raw.hasPrefix("magnet:") || link.infoHash != nil { return 8 }
            if link.isExternalURL { return 7 }
            if raw.contains(".m3u8") || raw.contains(".mp4") || raw.contains(".mov") || raw.contains(".m4v") { return 0 }
            if raw.contains(".mkv") || raw.contains("dts") || raw.contains("truehd") { return UniversalCodecSupport.vlcCompiledIn ? 1 : 4 }
            // Signed debrid/TorBox HTTP URLs often have no extension; keep them above magnet/browser links.
            return 2
        }
        return links.sorted { lhs, rhs in
            let lDirect = lhs.isDirectPlayable ? 0 : 1
            let rDirect = rhs.isDirectPlayable ? 0 : 1
            if lDirect != rDirect { return lDirect < rDirect }
            let lNative = nativePenalty(lhs)
            let rNative = nativePenalty(rhs)
            if lNative != rNative { return lNative < rNative }
            return (rank[lhs.quality] ?? 9) < (rank[rhs.quality] ?? 9)
        }
    }

    private func streamTypeCandidates(for item: MediaItem) -> [String] {
        let lower = item.type.lowercased()
        if lower.contains("series") || lower.contains("show") { return ["series", "movie"] }
        return ["movie", "series"]
    }

    private func streamIDCandidates(for item: MediaItem) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !ordered.contains(trimmed) else { return }
            ordered.append(trimmed)
        }

        add(item.id)
        if let colon = item.id.split(separator: ":").first { add(String(colon)) }
        if item.id.hasPrefix("tt") == false, let range = item.id.range(of: "tt[0-9]+", options: .regularExpression) {
            add(String(item.id[range]))
        }
        return ordered
    }

    func playableURLs(from links: [StreamLink], selected: StreamLink? = nil) -> [URL] {
        var urls: [URL] = []
        func add(_ raw: String?) {
            guard let url = Self.makePlayableURL(from: raw) else { return }
            if !urls.contains(url) { urls.append(url) }
        }
        add(selected?.isDirectPlayable == true ? selected?.url : nil)
        for link in links where link.isDirectPlayable { add(link.url) }
        return urls
    }

    static func makePlayableURL(from raw: String?) -> URL? {
        guard var value = raw?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        value = value.replacingOccurrences(of: " ", with: "%20")
        guard value.lowercased().hasPrefix("http") else { return nil }
        return URL(string: value)
    }

    func subtitleURLs(from link: StreamLink?) -> [URL] {
        (link?.subtitleURLs ?? []).compactMap { URL(string: $0) }
    }

    func playFirstDirectStream(for item: MediaItem) async {
        let links = await findStreams(for: item)
        if let direct = links.first(where: { $0.isDirectPlayable }), let url = Self.makePlayableURL(from: direct.url) {
            startPlayback(item: item, url: url, alternates: playableURLs(from: links, selected: direct), subtitles: subtitleURLs(from: direct), label: "Playing \(direct.quality) link for \(item.title). Adaptive fallback is armed across all direct links.")
        } else if let preview = directPreviewURL(for: item) {
            // v84 real-player test path: when a catalog has no direct movie links yet, PLAY still opens
            // the custom Debrid player with the direct preview/sample URL so the full VOD surface can be tested.
            startPlayback(item: item, url: preview, alternates: [], subtitles: [], label: "No resolved VOD link found, opening direct preview stream in the custom Debrid player for testing.")
        } else {
            let torrentCount = links.filter { $0.url?.lowercased().hasPrefix("magnet:") == true || $0.infoHash != nil }.count
            let externalCount = links.filter { $0.isExternalURL }.count
            status = links.isEmpty ? lastStreamMessage : "Links found, but none are direct-playable yet. \(torrentCount) torrent/infoHash and \(externalCount) browser/external link(s) need a configured debrid direct stream URL from the addon."
        }
    }

    func startPlayback(item: MediaItem, url: URL, alternates: [URL] = [], subtitles: [URL] = [], label: String) {
        playbackItem = item
        let ordered = ([url] + alternates).reduce(into: [URL]()) { acc, candidate in
            if !acc.contains(candidate) { acc.append(candidate) }
        }
        playbackFallbackURLs = ordered
        playbackSubtitleURLs = subtitles
        playbackLinkLabel = label
        playbackURL = url
        status = label
    }

    func advanceToNextPlaybackURL(after failedURL: URL) -> URL? {
        guard let index = playbackFallbackURLs.firstIndex(of: failedURL) else { return nil }
        let nextIndex = playbackFallbackURLs.index(after: index)
        guard playbackFallbackURLs.indices.contains(nextIndex) else { return nil }
        let next = playbackFallbackURLs[nextIndex]
        playbackURL = next
        status = "Current stream failed; retrying alternate \(nextIndex + 1) of \(playbackFallbackURLs.count)."
        return next
    }

    func closePlayer() {
        playbackURL = nil
        playbackItem = nil
        playbackFallbackURLs = []
        playbackSubtitleURLs = []
        playbackLinkLabel = ""
    }

    func openDetail(_ item: MediaItem, pushCurrent: Bool = false) {
        if pushCurrent, let current = selectedDetail {
            detailBackStack.append(current)
        } else if !pushCurrent {
            detailBackStack.removeAll()
        }
        selectedDetail = item
    }

    func closeDetail() {
        if let previous = detailBackStack.popLast() {
            selectedDetail = previous
        } else {
            selectedDetail = nil
        }
    }
    func addManifestURL(_ urlString: String) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, URL(string: clean) != nil else {
            status = "Enter a valid Stremio manifest URL before adding."
            return
        }
        let candidateSet = Set(manifestURLCandidates(from: clean))
        let alreadyExists = manifestURLs.contains { existing in
            existing == clean || !Set(manifestURLCandidates(from: existing)).isDisjoint(with: candidateSet)
        }
        guard !alreadyExists else {
            status = "That Stremio JSON/addon is already in your list."
            return
        }
        if !manifestURLs.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
            manifestURLs.insert(coreMetadataManifestURL, at: 0)
        }
        manifestURLs.append(clean)
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Added Stremio addon. Manifest/configure/stremio:// links normalize to /manifest.json; catalog/meta/stream/subtitles are handled separately."
    }

    func removeManifestURL(_ urlString: String) {
        manifestURLs.removeAll { $0 == urlString }
        if manifestURLs.isEmpty { manifestURLs = [coreMetadataManifestURL] }
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Removed Stremio JSON/addon."
    }

    func loadAllManifests() async {
        let urls = manifestURLs
        guard !urls.isEmpty else {
            status = "Add at least one Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }

        let previousRows = rows
        var mergedRows: [MediaRow] = []
        var loadedCatalogNames: [String] = []
        var streamOnlyNames: [String] = []
        var failedNames: [String] = []

        // v96 rule: stream-only addons can NEVER wipe or replace Home/catalog rows.
        // Catalog rows only change when at least one provider returns real metas.
        for url in urls {
            do {
                let result = try await fetchRows(from: url)
                switch result.kind {
                case "stream-only":
                    streamOnlyNames.append(result.name)
                default:
                    if result.rows.isEmpty {
                        failedNames.append("\(result.name): no catalog items")
                    } else {
                        mergedRows.append(contentsOf: result.rows)
                        loadedCatalogNames.append(result.name)
                    }
                }
            } catch {
                failedNames.append("\(url): \(error.localizedDescription)")
            }
        }

        if !mergedRows.isEmpty {
            rows = mergedRows
            let streamNote = streamOnlyNames.isEmpty ? "" : " Stream-only addons active for Find Links: \(streamOnlyNames.joined(separator: ", "))."
            status = "Loaded \(mergedRows.count) catalog row(s) from \(loadedCatalogNames.joined(separator: ", ")).\(streamNote)"
        } else {
            rows = previousRows.isEmpty ? Self.demoRows() : previousRows
            let streamNote = streamOnlyNames.isEmpty ? "" : " Stream-only addons still active for Find Links: \(streamOnlyNames.joined(separator: ", "))."
            let failNote = failedNames.isEmpty ? "" : " Catalog providers returned no rows or failed: \(failedNames.prefix(3).joined(separator: "; "))."
            status = "No catalog rows were replaced; keeping existing Home rows.\(streamNote)\(failNote) Add a real catalog manifest like Cinemeta for Home rows; Torrentio/TorBox are usually stream-only."
        }
    }

    private func fetchRows(from urlString: String) async throws -> (name: String, kind: String, rows: [MediaRow]) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidates = manifestURLCandidates(from: clean)
        var manifestURL: URL? = nil
        var manifestData: Data? = nil
        for candidate in candidates {
            guard let url = URL(string: candidate) else { continue }
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                manifestURL = url
                manifestData = data
                break
            } catch {
                continue
            }
        }
        guard let manifestURL, let manifestData else { throw URLError(.badURL) }
        let manifest = try JSONDecoder().decode(StremioManifest.self, from: manifestData)
        let base = URL(string: normalizedStremioBase(from: manifestURL.absoluteString)) ?? manifestURL.deletingLastPathComponent()
        let catalogs = (manifest.catalogs ?? []).prefix(12)
        let addonName = manifest.name ?? manifestURL.host ?? "Stremio"
        let addonIconURL = Self.highest(manifest.logo ?? manifest.icon)
        await MainActor.run {
            self.addonIdentities[urlString] = StremioAddonIdentity(name: addonName, iconURL: addonIconURL, kind: self.addonKind(from: manifest))
        }
        var builtRows: [MediaRow] = []
        if catalogs.isEmpty {
            // Stream-only addons such as Torrentio/TorBox are valid and should remain saved/active even though
            // they do not create Home rows. Their /stream endpoints are used from Find Links on Cinemeta items.
            return (manifest.name ?? manifestURL.host ?? "stream addon", addonKind(from: manifest), [])
        }
        for catalog in catalogs {
            let type = catalog.type ?? "movie"
            let id = catalog.id ?? "popular"
            var response: CatalogResponse? = nil
            for catalogURL in catalogEndpointCandidates(base: base, catalog: catalog) {
                do {
                    let (catalogData, httpResponse) = try await URLSession.shared.data(from: catalogURL)
                    if let http = httpResponse as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    response = try JSONDecoder().decode(CatalogResponse.self, from: catalogData)
                    break
                } catch {
                    continue
                }
            }
            if let response {
                let items = (response.metas ?? []).prefix(24).map { meta in
                    MediaItem(
                        id: meta.id ?? UUID().uuidString,
                        title: meta.name ?? "Untitled",
                        year: Self.firstYear(from: meta.releaseInfo),
                        type: meta.type ?? type,
                        catalog: catalog.name ?? id.capitalized,
                        description: meta.description ?? "No description available yet.",
                        genres: Array((meta.genres ?? [type.capitalized, "Cinema"]).prefix(3)),
                        rating: meta.imdbRating ?? "—",
                        posterURL: Self.highest(meta.poster),
                        landscapeURL: Self.highest(meta.background ?? meta.poster),
                        logoURL: Self.highest(meta.logo),
                        previewURL: Self.previewURL(from: meta),
                        addonName: addonName,
                        addonIconURL: addonIconURL,
                        seasonNumber: nil,
                        episodeNumber: nil
                    )
                }
                if !items.isEmpty {
                    builtRows.append(MediaRow(id: "\(type)-\(id)-\(manifest.name ?? "manifest")", title: catalog.name ?? id.capitalized, items: items))
                }
            }
        }
        return (manifest.name ?? "manifest", addonKind(from: manifest), builtRows)
    }


    func fetchSeriesEpisodes(for item: MediaItem) async -> [MediaItem] {
        let lowerType = item.type.lowercased()
        guard lowerType.contains("series") || lowerType.contains("show") else { return [] }
        status = "Loading seasons and episodes for \(item.title)…"
        let idCandidates = streamIDCandidates(for: item)
        var episodes: [MediaItem] = []
        var seen = Set<String>()

        for rawManifest in manifestURLs {
            for candidate in manifestURLCandidates(from: rawManifest) {
                guard let manifestURL = URL(string: candidate) else { continue }
                let base = normalizedStremioBase(from: manifestURL.absoluteString)
                for seriesID in idCandidates {
                    guard let encodedID = seriesID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let metaURL = URL(string: "\(base)/meta/series/\(encodedID).json") else { continue }
                    do {
                        let (data, response) = try await URLSession.shared.data(from: metaURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioMetaResponse.self, from: data)
                        let meta = decoded.meta
                        for video in meta?.videos ?? [] {
                            guard let videoID = video.id?.trimmingCharacters(in: .whitespacesAndNewlines), !videoID.isEmpty else { continue }
                            guard seen.insert(videoID).inserted else { continue }
                            let season = video.season ?? 1
                            let episode = video.episode ?? (episodes.filter { $0.seasonNumber == season }.count + 1)
                            let episodeTitle = video.title ?? video.name ?? "Episode \(episode)"
                            episodes.append(MediaItem(
                                id: videoID,
                                title: "\(item.title)  S\(String(format: "%02d", season))E\(String(format: "%02d", episode))  \(episodeTitle)",
                                year: item.year,
                                type: "series",
                                catalog: "Season \(season)",
                                description: video.overview ?? video.description ?? item.description,
                                genres: item.genres,
                                rating: item.rating,
                                posterURL: Self.highest(video.thumbnail ?? item.posterURL),
                                landscapeURL: Self.highest(item.landscapeURL ?? item.posterURL),
                                logoURL: item.logoURL,
                                previewURL: video.url ?? video.src ?? video.source,
                                addonName: item.addonName,
                                addonIconURL: item.addonIconURL,
                                seasonNumber: season,
                                episodeNumber: episode
                            ))
                        }
                        if !episodes.isEmpty {
                            let sorted = episodes.sorted { lhs, rhs in
                                if (lhs.seasonNumber ?? 0) != (rhs.seasonNumber ?? 0) { return (lhs.seasonNumber ?? 0) < (rhs.seasonNumber ?? 0) }
                                return (lhs.episodeNumber ?? 0) < (rhs.episodeNumber ?? 0)
                            }
                            status = "Loaded \(sorted.count) episode(s) for \(item.title)."
                            return sorted
                        }
                    } catch {
                        continue
                    }
                }
            }
        }
        status = "No episode list was returned for \(item.title). The selected metadata/addon must expose /meta/series/{id}.json videos."
        return []
    }

    func loadManifest(urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else {
            status = "Enter a valid Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let result = try await fetchRows(from: clean)
            if result.rows.isEmpty {
                status = result.kind == "stream-only" ? "Added stream-only addon \(result.name). It will work in Find Links but does not create Home rows." : "No catalog rows returned from \(result.name). Existing rows kept."
            } else {
                rows = result.rows
                status = "Loaded \(result.rows.count) rows from \(result.name)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo, text.count >= 4 else { return "2026" }
        return String(text.prefix(4))
    }

    static func previewURL(from meta: StremioMeta) -> String? {
        if let direct = meta.previewVideo, direct.hasPrefix("http") { return direct }
        if let direct = meta.preview, direct.hasPrefix("http") { return direct }
        if let direct = meta.trailer, direct.hasPrefix("http") { return direct }
        if let video = meta.videos?.first(where: { ($0.url ?? $0.src ?? $0.source ?? "").hasPrefix("http") }) {
            return video.url ?? video.src ?? video.source
        }
        // Some Stremio manifests expose YouTube trailer IDs; those are kept as metadata only
        // because Internal player needs a direct playable video URL.
        return nil
    }

    static func highest(_ url: String?) -> String? {
        guard var u = url, !u.isEmpty else { return nil }
        u = u.replacingOccurrences(of: "w92", with: "original")
        u = u.replacingOccurrences(of: "w154", with: "original")
        u = u.replacingOccurrences(of: "w186", with: "original")
        u = u.replacingOccurrences(of: "w342", with: "original")
        u = u.replacingOccurrences(of: "w500", with: "original")
        u = u.replacingOccurrences(of: "w780", with: "original")
        return u
    }

    static func demoRows() -> [MediaRow] {
        let items: [MediaItem] = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "movie", catalog: "Featured", description: "A temporary small-town sheriff uncovers a violent mystery after a bank robbery exposes a deeper conspiracy.", genres: ["Action", "Crime", "Thriller"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
            MediaItem(id: "apex", title: "APEX", year: "2026", type: "movie", catalog: "Featured", description: "A climber enters a hidden cave system and finds the rescue mission was never about saving him.", genres: ["Adventure", "Thriller"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
            MediaItem(id: "red", title: "RED SIGNAL", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators through a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "BLUE FALL", year: "2026", type: "movie", catalog: "Featured", description: "A detective wakes in a fractured digital city with one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "circle", title: "THE CIRCLE", year: "2026", type: "movie", catalog: "Featured", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "cinema", title: "CENTRAL CINEMA", year: "2026", type: "movie", catalog: "Featured", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "THE LOST PATH", year: "2026", type: "movie", catalog: "Featured", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "STORMLINE", year: "2026", type: "movie", catalog: "Featured", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "night", title: "NIGHT RUN", year: "2026", type: "movie", catalog: "Featured", description: "A driver with no name carries the wrong package across the city before sunrise.", genres: ["Action", "Neo-Noir"], rating: "7.4", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "harbor", title: "HARBOR BLACK", year: "2026", type: "series", catalog: "Featured", description: "A dockside murder opens a case that reaches every powerful family in the city.", genres: ["Series", "Crime"], rating: "7.6", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed())),
            MediaRow(id: "shows", title: "Shows", items: items.map { item in var copy = item; copy.type = "series"; return copy })
        ]
    }
}
