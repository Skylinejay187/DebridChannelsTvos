# Debrid Channels tvOS Build From ZIP

Upload this repo to GitHub. The workflow finds `source_zip/DebridChannelsTVOS_Source.zip`, extracts the real Xcode tvOS project, builds it unsigned, then uploads `DebridChannelsTVOS_unsigned.ipa` as an artifact.

This package fixes the previous error: `NO XCODE PROJECT FOUND` by including `DebridChannelsTVOS.xcodeproj` inside the source ZIP.
