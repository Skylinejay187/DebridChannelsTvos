set -eu
APP_PATH="$TARGET_BUILD_DIR/$WRAPPER_NAME"
FRAMEWORKS_DIR="$APP_PATH/Frameworks"
BRIDGE="$FRAMEWORKS_DIR/AetherPlaybackBridge.framework/AetherPlaybackBridge"
echo "Auditing Aether runtime closure in: $FRAMEWORKS_DIR"
if [ ! -x "$BRIDGE" ]; then
  echo "ERROR: AetherPlaybackBridge.framework is not embedded in the final app bundle." >&2
  find "$APP_PATH" -maxdepth 3 -type d -name '*.framework' -print || true
  exit 1
fi
APP_EXECUTABLE="$APP_PATH/$EXECUTABLE_NAME"
if otool -L "$APP_EXECUTABLE" | grep -Eq 'AetherPlaybackBridge|AetherLib'; then
  echo "ERROR: app executable eagerly links Aether. vBRDC251 requires runtime-only dlopen." >&2
  otool -L "$APP_EXECUTABLE" >&2
  exit 1
fi
audit_binary() {
  audit_bin="$1"
  deps_file="$TARGET_TEMP_DIR/aether-runtime-deps-$$.txt"
  otool -L "$audit_bin" | tail -n +2 | awk '{print $1}' > "$deps_file"
  while IFS= read -r dep; do
    case "$dep" in
      @rpath/Aether*.framework/*)
        name=$(printf '%s\n' "$dep" | sed -E 's#@rpath/([^/]+\.framework)/.*#\1#')
        target="$FRAMEWORKS_DIR/$name"
        if [ ! -d "$target" ]; then
          echo "ERROR: Missing runtime dependency $name required by $audit_bin" >&2
          rm -f "$deps_file"
          exit 1
        fi
        ;;
    esac
  done < "$deps_file"
  rm -f "$deps_file"
}
audit_binary "$BRIDGE"
for fw in "$FRAMEWORKS_DIR"/Aether*.framework; do
  [ -d "$fw" ] || continue
  name=$(basename "$fw" .framework)
  bin="$fw/$name"
  [ -f "$bin" ] || continue
  audit_binary "$bin"
done
echo "Aether runtime embed closure verified; app executable remains Aether-cold."
