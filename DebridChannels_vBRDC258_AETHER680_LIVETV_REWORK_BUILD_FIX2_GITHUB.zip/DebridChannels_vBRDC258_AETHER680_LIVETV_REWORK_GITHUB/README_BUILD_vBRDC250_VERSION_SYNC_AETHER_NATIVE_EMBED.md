# vBRDC250 — Version Sync + Aether Native Embed

Release: **vBRDC250**  
Marketing version: **1.0.953**  
Build: **953**

## Fix
GitHub Actions vBRDC249 reached the normal app build with the SwiftPM-native Aether bridge, then the existing V1041 production validation correctly stopped the build because `Sources/Info.plist` had build 952 while XcodeGen still emitted `CURRENT_PROJECT_VERSION = 951`.

This build synchronizes the version tuple everywhere the production validator checks it:

- project/global `MARKETING_VERSION = 1.0.953`
- project/global `CURRENT_PROJECT_VERSION = 953`
- Top Shelf target `MARKETING_VERSION = 1.0.953`
- Top Shelf target `CURRENT_PROJECT_VERSION = 953`
- app Info.plist `1.0.953 (953)` / `vBRDC250`
- Top Shelf Info.plist `1.0.953 (953)` / `vBRDC250`

The Aether/KSPlayer architecture is unchanged. The SwiftPM-native `AetherPlaybackBridge` embedding and POSIX runtime-closure audit from vBRDC249 are preserved.
