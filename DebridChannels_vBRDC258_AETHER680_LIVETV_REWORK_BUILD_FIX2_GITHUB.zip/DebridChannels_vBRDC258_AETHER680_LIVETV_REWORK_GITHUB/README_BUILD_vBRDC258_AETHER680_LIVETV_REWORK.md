# vBRDC258 — 1.0.961 (961)

## Purpose
Pre-timeshift stabilization. vBRDC257 proved that the old Aether 6.57 integration could play only a subset of Live TV channels. vBRDC258 replaces that incomplete live foundation with the current pinned AetherEngine 6.80.0 host contract before any DVR/timeshift code is added.

## Live TV changes
- Pin AetherEngine 6.80.0 (commit 89ef0c347a17180739d8ca7a1a1cfbb163135271).
- Preserve the isolated dynamic AetherPlaybackBridge and namespaced Aether FFmpeg dependency graph.
- Move Aether FFmpeg from 3.0.0 to namespaced 3.2.0, matching Aether 6.80's core requirement while keeping it isolated from KSPNUVIO/FFmpegKit.
- Use `.fastZap` for live loopback sessions.
- Use `nativeRemoteHLS` for HLS-looking Live TV URLs and keep Aether's ingest fallback enabled.
- Disable display-criteria switching for Live TV startup; VOD presentation isolation remains unchanged.
- Use `hasFirstFrameReadyForDisplay` for the Debrid Channels first-frame gate instead of the earlier `isSessionReady` signal.
- Subscribe to Aether's required `liveSourceReset` signal and perform a bounded same-channel retune before falling back.
- Observe Aether's unified `playbackPhase` for buffering/stall state and `videoRoute` for route diagnostics.
- Keep source-provided HTTP headers and the existing Debrid Channels Live TV request profile.

## Explicit non-goals
- No DVR/timeshift yet. Ordinary Aether Live TV must be reliable first.
- No VOD adaptive-cache implementation yet.
- No GitHub Actions build-speed optimization yet.
- Do not remove KSPlayer fallback.

## Regression locks
All v252-v257 navigation, resume, engine-selection, source identity, Live TV Grid/List/EPG, artwork, Now Playing/Bluetooth, sports direct-tune, and manual M3U contracts remain locked.
