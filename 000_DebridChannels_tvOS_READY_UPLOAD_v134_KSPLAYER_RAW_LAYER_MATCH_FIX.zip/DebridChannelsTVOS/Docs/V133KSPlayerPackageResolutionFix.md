# V133 KSPlayer Package Resolution Fix

Fixed GitHub Actions package resolution failure from v132.

Root cause: v132 referenced both KSPlayer and MPVKit. MPVKit also pulls FFmpegKit-style targets, creating duplicate SwiftPM target names such as FFmpegKit, Libavcodec, and Libavdevice. Xcode refused to resolve package dependencies.

Fix:
- Removed MPVKit SwiftPM dependency from project.yml.
- Kept KSPlayer as the primary internal player target.
- Kept TVVLCKit/VLC fallback embedding path.
- MPV remains guarded/disabled until a vendored non-conflicting tvOS libmpv package is provided.
- Preserved v73 visuals and v132 KSPlayer/VLC direction.
