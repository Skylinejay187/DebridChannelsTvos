# V127 MPV/FFmpeg + VLC Compiled Engines

- Keeps AVPlayer removed from the VOD internal render path.
- Keeps TVVLCKit/libVLC as the default internal engine under the Debrid Channels overlay.
- Adds MPVKit/libmpv/FFmpeg through SwiftPM as a second internal engine.
- Adds MPV button routing to select MPV/FFmpeg under the same overlay.
- Workflow resolves MPVKit package dependencies and refuses upload if MPVKit is not resolved.
- Workflow still vendors/embeds the official VideoLAN TVVLCKit tvOS arm64 framework.
- External Infuse/VLC/SenPlayer handoff remains available.
- v73 Home/detail visual baseline preserved.
