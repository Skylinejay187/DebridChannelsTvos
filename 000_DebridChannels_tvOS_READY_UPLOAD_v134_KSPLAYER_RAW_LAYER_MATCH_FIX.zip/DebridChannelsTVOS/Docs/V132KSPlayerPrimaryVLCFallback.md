# V132 KSPlayer Primary + VLC Fallback

- Built from the v129/v131 VLC-stable rollback base.
- Preserves v73 Home/detail visuals.
- Adds KSPlayer as the new primary internal VOD engine using Swift Package Manager.
- Keeps TVVLCKit/libVLC as the secondary fallback engine.
- Keeps MPV guarded/experimental so it cannot crash the app.
- Keeps external Infuse/VLC/SenPlayer handoff.
- Shared Debrid Channels Apple-style VOD overlay remains above the internal playback surface.

Notes:
- KSPlayer is GPL-licensed by default; for a closed-source/commercial distribution, obtain the author’s LGPL/commercial permission.
- Runtime validation is still required on Apple TV hardware for specific 4K/Dolby Vision/MKV samples.
