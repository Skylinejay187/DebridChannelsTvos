# v129 VLC First-Frame Surface Fix

- Fixes the issue where VLC internal playback could start audio before the TVVLCKit drawable was attached, causing black/no video until the user manually selected VLC.
- Adds a VLC surface reload token and reattaches the drawable on setup and manual VLC selection.
- Delays initial play slightly after drawable assignment so the tvOS UIView is attached before decoding starts.
- Keeps VLC as the default internal renderer and preserves the MPV crash guard from v128.
- Preserves compact media information panel sizing and v73 visual baseline.
