# V128 MPV crash guard + compact media info

- Prevents the MPV button from instantiating the unstable MPVKit render surface that was crashing on Apple TV.
- Keeps playback alive on VLC Internal and shows a clear status message instead of crashing.
- Reduces the media information card width, padding, and font sizes so Search Links and stream chips remain visible/reachable.
- Preserves v73 Home/detail visual baseline and existing VLC/external player paths.
