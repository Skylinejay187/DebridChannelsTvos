# V126 VLC-first / mpv-FFmpeg boundary

- Removed AVPlayer from the VOD internal player decision path.
- TVVLCKit/libVLC is now the primary internal playback surface under the Debrid Channels overlay.
- The former Apple/Native button is repurposed as an MPV status button; it reports that a compiled tvOS libmpv/FFmpeg package still needs to be vendored.
- External Infuse/VLC/SenPlayer handoff remains available.
- v73 Home/detail visuals are preserved.
