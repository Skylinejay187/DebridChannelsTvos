# v131 Rollback to v129 + MPV message fix

Base: v129 VLC first-frame surface fix.

Purpose:
- Roll back v130 GPU/hardware-decode preference changes because they caused no-video/audio skipping.
- Preserve the v129 VLC-first behavior that successfully displayed video after the VLC surface fix.
- Remove the long intrusive MPV/FFmpeg disabled warning from the VOD overlay.
- Keep MPV guarded so tapping it cannot crash the app; it now quietly keeps VLC Internal active and reports a shorter Settings/status message only.
- Preserve compact media info panel from v128 and v73 Home/detail visuals.
