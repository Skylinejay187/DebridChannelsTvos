# Debrid Channels tvOS v78

Rollback base: v73.

This build intentionally preserves the v73 home screen and media information layout.
Only additive/stabilizing changes were applied after v73:
- v78 build/settings markers.
- VOD overlay Debrid Channels logo removed.
- Existing v73 More Like This, manual Trailer, stream/VOD wiring, focused background, slow poster float, and multi-JSON stack preserved.
- No v77 layout rewrite included.

Upload this ZIP to the GitHub repo root and run the universal device-build workflow.
