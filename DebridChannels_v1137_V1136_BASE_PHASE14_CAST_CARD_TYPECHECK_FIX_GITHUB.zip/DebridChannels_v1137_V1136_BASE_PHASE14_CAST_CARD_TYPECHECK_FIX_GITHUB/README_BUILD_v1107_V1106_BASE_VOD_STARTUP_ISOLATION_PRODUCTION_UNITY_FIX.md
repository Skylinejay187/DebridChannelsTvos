# Debrid Channels tvOS/iOS v1107

## Base

Built only from v1106 (1.0.634 / build 634).

## Version

- Marketing version: 1.0.635
- Build: 635
- Backend update: not required
- Continue using backend v669

## Blocking VOD startup correction

v1106 started optional Production & Ratings TMDB work as soon as the VOD player view appeared. When the panel was enabled, that could start multiple metadata requests and mount cast/studio artwork while Source Intelligence handoff, network opening, KSPlayer setup, and first-frame presentation were still competing for resources.

v1107 isolates all decorative VOD work from playback startup:

- Production metadata no longer starts from the player `onAppear` path.
- Production metadata requires confirmed first-frame playback.
- The request waits another 1.5 seconds after first frame and runs at background task priority.
- Every callback rechecks the active playback presentation, title identity, panel state, and first-frame state before publishing.
- Repeated metadata hydration does not refetch an already loaded title in the same playback session.
- Cast portrait downloads and the cast takeover timer do not start until first frame is ready.
- The Production & Ratings panel is not mounted until first frame is ready.

The catalog/Search source resolver, Source Intelligence, playback URL handoff, KSPlayer surface, and backend are unchanged.

## Production & Ratings unity redesign

- Added a compact landscape movie/show image at the top of the right-side panel.
- Information now flows under the artwork in a lighter, more unified presentation that visually matches the left-side VOD information stage.
- Studio and network entries are deduplicated by normalized name.
- Only one primary studio/network logo is displayed, eliminating duplicate logos such as HBO appearing twice.
- Company names remain available beneath the header.
- Real available rating, advisory, budget, box office, runtime, status, critic, IMDb, country, and language facts remain supported.
- Missing fields collapse without blank gaps.

## Featured Cast

- Full-poster Featured Cast remains available.
- The original title poster remains visible before takeover.
- Cast rotation position remains player-owned and persists across overlay hide/show.
- Cast image loading and rotation now wait until stable first-frame playback so they cannot interfere with opening the stream.

## Protected systems

The following files were verified byte-identical to v1106:

- `Sources/CatalogStore.swift`
- `Sources/SourceIntelligenceManager.swift`
- `Sources/AlternateAudioDiscoveryClient.swift`
- `Sources/AlternateAudioBridgeClient.swift`
- `Sources/AlternateAudioCancellationClient.swift`
- `Sources/TrailerServiceManager.swift`
- `Sources/LiveTVGuideCacheManager.swift`
- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/StableFeatureGateManager.swift`

## Validation

- All Swift files passed syntax parsing.
- Both plists passed XML/property-list validation.
- Project and plist versions match 1.0.635 / 635.
- VOD startup isolation and Production & Ratings source contract passed.
- Protected playback/source-resolution files were compared byte-for-byte with v1106.
- Complete baseline hash comparison is included.
- Final archive was extracted and every packaged file hash was verified.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before v1107 becomes the next stable base.
