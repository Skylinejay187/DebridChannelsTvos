# Debrid Channels v1130 — v1129 Phase 10 Smart Info Compile Fix

- Marketing version: **1.0.658**
- Build: **658**
- Base: **packaged v1129 only**
- Backend: **v671 unchanged**
- Roadmap: **Phase 10 corrective replacement**; Phase 11 has not started.

## Why v1129 failed
GitHub Actions Xcode 16.4 reached the app target and stopped in `Sources/VODSmartInfo.swift` line 184 because the new Smart Info cast card used `.nonEmpty`, but that helper is declared `fileprivate` inside `AlternateAudioDiscoveryClient.swift`. Swift file-private access correctly prevents another source file from using it.

The earlier local type-check was insufficient because its stub accidentally declared a global `String.nonEmpty`, masking the access-control error.

## v1130 correction
Only the failing Smart Info expression is corrected. Role text is trimmed locally with `Optional.map`/`flatMap`; empty roles still fall back to `Featured cast member`. There is no shared extension and no change to Smart Info behavior.

Validation now type-checks `VODSmartInfo.swift` against stubs that deliberately do **not** provide `String.nonEmpty`, so this exact failure cannot be hidden again.

## Preservation
Phase 10 security/provider protection, Phase 9 bridge lifecycle, Up Next, Search/Favorites/failover UX, KSPlayer/KSPNUVIO, codec/rendering, Source Intelligence, Live TV, Featured Cast, Production & Ratings, resume/history, subtitle delay and episode alerts are preserved.

Backend **v671** remains the matching backend. No backend rebuild is required for this compile fix.

GitHub Actions remains the authoritative tvOS/Xcode compilation test. Physical Apple TV behavior is not claimed until tested.
