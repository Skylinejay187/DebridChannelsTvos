import Foundation

/// Persistent tvOS playback resume/history cache.
///
/// v1119 freeze correction: resume updates remain in a small in-memory dictionary and
/// are encoded/written on a serial utility queue. The player clock no longer JSON-encodes
/// the complete resume/history collection on the main thread every five seconds.
struct PlaybackResumeEntry: Codable, Hashable {
    var key: String
    var title: String
    var type: String
    var catalog: String
    var season: Int?
    var episode: Int?
    var seconds: Double
    var duration: Double
    var updatedAt: Date
    var artworkURL: String?
}

final class PlaybackResumeCacheManager {
    static let shared = PlaybackResumeCacheManager()

    private struct Payload: Codable {
        var entries: [String: PlaybackResumeEntry]
        var recents: [PlaybackResumeEntry]
    }

    private let legacyEntriesKey = "DebridChannels.v498.playbackResume.entries"
    private let legacyRecentsKey = "DebridChannels.v498.playbackResume.recents"
    private let minimumResumeSeconds: Double = 8
    private let completionThreshold: Double = 0.95
    private let maxEntries = 180
    private let maxRecents = 60
    private let lock = NSLock()
    private let writerQueue = DispatchQueue(label: "DebridChannels.PlaybackResumeCache.writer", qos: .utility)
    private var payload: Payload

    private static var storageFileURL: URL? {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first?
            .appendingPathComponent("DebridChannels", isDirectory: true)
            .appendingPathComponent("playback-resume-v1119.json")
    }

    private var fileURL: URL? { Self.storageFileURL }

    private init() {
        let initialFileURL = Self.storageFileURL
        if let initialFileURL,
           let data = try? Data(contentsOf: initialFileURL),
           let decoded = try? JSONDecoder().decode(Payload.self, from: data) {
            payload = decoded
            return
        }
        let defaults = UserDefaults.standard
        let legacyEntries: [String: PlaybackResumeEntry]
        if let data = defaults.data(forKey: legacyEntriesKey),
           let decoded = try? JSONDecoder().decode([String: PlaybackResumeEntry].self, from: data) {
            legacyEntries = decoded
        } else {
            legacyEntries = [:]
        }
        let legacyRecents: [PlaybackResumeEntry]
        if let data = defaults.data(forKey: legacyRecentsKey),
           let decoded = try? JSONDecoder().decode([PlaybackResumeEntry].self, from: data) {
            legacyRecents = decoded
        } else {
            legacyRecents = []
        }
        payload = Payload(entries: legacyEntries, recents: legacyRecents)
        if !legacyEntries.isEmpty || !legacyRecents.isEmpty {
            scheduleWrite(payload, removeLegacyAfterSuccess: true)
        }
    }

    func resumeEntry(for item: MediaItem) -> PlaybackResumeEntry? {
        let key = playbackKey(for: item)
        lock.lock()
        let entry = payload.entries[key]
        lock.unlock()
        guard let entry, entry.seconds >= minimumResumeSeconds else { return nil }
        if entry.duration > 0, entry.seconds / entry.duration >= completionThreshold {
            clear(for: item)
            return nil
        }
        return entry
    }

    func saveProgress(item: MediaItem, seconds: Double, duration: Double) {
        guard seconds.isFinite, seconds >= minimumResumeSeconds else { return }
        let normalizedDuration = duration.isFinite && duration > 0 ? duration : 0
        if normalizedDuration > 0, seconds / normalizedDuration >= completionThreshold {
            clear(for: item)
            return
        }

        let key = playbackKey(for: item)
        let entry = PlaybackResumeEntry(
            key: key,
            title: item.title,
            type: item.type,
            catalog: item.catalog,
            season: item.seasonNumber,
            episode: item.episodeNumber,
            seconds: seconds,
            duration: normalizedDuration,
            updatedAt: Date(),
            artworkURL: item.landscapeURL ?? item.posterURL
        )

        lock.lock()
        payload.entries[key] = entry
        if payload.entries.count > maxEntries {
            payload.entries = Dictionary(uniqueKeysWithValues: payload.entries.values
                .sorted { $0.updatedAt > $1.updatedAt }
                .prefix(maxEntries)
                .map { ($0.key, $0) })
        }
        payload.recents.removeAll { $0.key == key }
        payload.recents.insert(entry, at: 0)
        if payload.recents.count > maxRecents { payload.recents = Array(payload.recents.prefix(maxRecents)) }
        let snapshot = payload
        lock.unlock()
        scheduleWrite(snapshot)
    }

    func clear(for item: MediaItem) {
        let key = playbackKey(for: item)
        lock.lock()
        payload.entries.removeValue(forKey: key)
        payload.recents.removeAll { $0.key == key }
        let snapshot = payload
        lock.unlock()
        scheduleWrite(snapshot)
    }

    func recentEntries() -> [PlaybackResumeEntry] {
        lock.lock()
        let values = payload.recents.sorted { $0.updatedAt > $1.updatedAt }
        lock.unlock()
        return values
    }

    func playbackKey(for item: MediaItem) -> String {
        let season = item.seasonNumber
        let episode = item.episodeNumber
        let lowerType = item.type.lowercased()
        let isEpisode = season != nil || episode != nil || lowerType.contains("episode") || lowerType.contains("series") || lowerType.contains("show")

        if isEpisode {
            let showID = stableShowID(for: item)
            return "episode|\(showID)|s\(season ?? 0)|e\(episode ?? 0)"
        }

        if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) { return "movie|tmdb|\(tmdb)" }
        if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) { return "movie|imdb|\(imdb)" }
        return "movie|fallback|\(safe([item.catalog, item.title, item.year, item.id].joined(separator: "|")))"
    }

    private func stableShowID(for item: MediaItem) -> String {
        if let tmdb = tmdbID(in: item.id) ?? item.tmdbId.flatMap(tmdbIDFromLooseValue) { return "tmdb:\(tmdb)" }
        if let imdb = imdbID(in: item.id) ?? item.imdbId.flatMap(imdbIDFromLooseValue) { return "imdb:\(imdb)" }
        if let tvdb = item.tvdbId?.trimmingCharacters(in: .whitespacesAndNewlines), !tvdb.isEmpty { return "tvdb:\(tvdb)" }
        var raw = item.id
        if let range = raw.range(of: #"[:|/_-]s?\d{1,3}[:|/_-]e?\d{1,4}$"#, options: [.regularExpression, .caseInsensitive]) {
            raw.removeSubrange(range)
        } else if let range = raw.range(of: "season", options: .caseInsensitive) {
            raw = String(raw[..<range.lowerBound])
        }
        return "fallback:\(safe([item.catalog, item.title, item.year, raw].joined(separator: "|")))"
    }

    private func tmdbID(in value: String) -> String? {
        let lower = value.lowercased()
        guard lower.contains("tmdb") else { return nil }
        if let range = value.range(of: #"tmdb[:_/|-]?(?:movie|tv|show|series)?[:_/|-]?(\d+)"#, options: [.regularExpression, .caseInsensitive]) {
            let fragment = String(value[range])
            if let digits = fragment.range(of: #"\d+"#, options: .regularExpression) { return String(fragment[digits]) }
        }
        return nil
    }

    private func tmdbIDFromLooseValue(_ value: String) -> String? {
        value.range(of: #"\d+"#, options: .regularExpression).map { String(value[$0]) }
    }

    private func imdbID(in value: String) -> String? {
        if let range = value.range(of: #"tt\d{6,}"#, options: [.regularExpression, .caseInsensitive]) {
            return String(value[range]).lowercased()
        }
        return nil
    }

    private func imdbIDFromLooseValue(_ value: String) -> String? {
        imdbID(in: value)
    }

    private func safe(_ value: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? String(abs(trimmed.hashValue))
    }

    private func scheduleWrite(_ snapshot: Payload, removeLegacyAfterSuccess: Bool = false) {
        guard let fileURL else { return }
        writerQueue.async {
            do {
                try FileManager.default.createDirectory(at: fileURL.deletingLastPathComponent(), withIntermediateDirectories: true)
                let data = try JSONEncoder().encode(snapshot)
                try data.write(to: fileURL, options: [.atomic])
                if removeLegacyAfterSuccess {
                    UserDefaults.standard.removeObject(forKey: self.legacyEntriesKey)
                    UserDefaults.standard.removeObject(forKey: self.legacyRecentsKey)
                }
            } catch {
                // Resume memory must never interrupt playback.
            }
        }
    }
}
