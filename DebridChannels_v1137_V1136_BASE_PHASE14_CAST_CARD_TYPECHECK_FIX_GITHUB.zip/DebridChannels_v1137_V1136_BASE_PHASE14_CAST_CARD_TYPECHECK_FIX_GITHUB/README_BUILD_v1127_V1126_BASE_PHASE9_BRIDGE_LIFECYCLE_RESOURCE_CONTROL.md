# Debrid Channels tvOS/iOS v1127 — Phase 9 Bridge Lifecycle and Resource Control

- **Base:** packaged v1126 only
- **Marketing version:** 1.0.655
- **Build:** 655
- **Phase:** 9 — Bridge Lifecycle and Resource Control
- **App candidate:** v1127
- **Backend pairing:** Phase 9 requires the v670 bridge-lifecycle runtime update over the currently deployed v669 backend.
- **Rollback:** v1126 is the immediate Phase 9 rollback; v1120 remains the last previously identified stable rollback until newer physical testing is confirmed.

## Phase 9 app ownership

The app now tracks backend bridge UUIDs independently from the Phase 4 KSPlayer handoff UUID. It owns three narrow lifecycle slots: pending, active, and retiring. A replacement bridge may prepare while the current Alternate Audio bridge continues playing. The prior bridge is not released until the replacement reaches a genuine player clock, preventing an offset/source replacement from killing the bridge currently feeding KSPlayer.

Playback exit, Alternate Audio Off, Restore Original Audio, and failed/replaced handoffs release every owned bridge UUID plus the presentation-wide backend work. Discovery, Source Intelligence, the original playback URL, subtitle state, resume state, and KSPlayer session ownership remain unchanged.

The app-side bridge request/cancel schema advances to v2 and accepts the backend's `jobFingerprint`, `reusedExisting`, and `reuseKind` fields. Reuse is visible only in diagnostics/status text; it does not change the playback UI or automatically enable Alternate Audio.

## Phase 9 backend runtime

The bundled `BackendAlternateAudioBridgeRuntime` is advanced to the Phase 9 contract and should be integrated into backend v669 as the next backend candidate, v670. The update adds:

- Unique bridge UUID preservation and exact playback-presentation ownership.
- SHA-256 job fingerprints for deterministic duplicate detection.
- Deduplication of identical in-flight preparation requests.
- Safe reuse of completed HLS work only when media/source/stream/offset/classification and playback-presentation ownership all match.
- Startup and request-time recovery/reconciliation after backend restarts.
- Expired and abandoned-job cleanup.
- Presentation-wide cancellation.
- Global and per-presentation concurrency limits.
- Root/session storage budgets with completed-work eviction.
- Bounded FFmpeg thread count plus POSIX best-effort address-space, CPU-time, and file-descriptor limits.
- Last-access tracking for active HLS delivery.
- Existing short-lived TTL behavior.
- Video remains stream-copy (`-c:v copy`) for every bridge plan.

The full production backend v669 repository/archive was not present in the supplied app ZIP or connected GitHub repositories. Therefore the separately packaged v670 artifact is explicitly a **runtime patch**, not a falsely reconstructed full backend deployment. Apply it to the real v669 backend integration before Phase 9 physical testing.

## Preserved from v1126

The following protected systems are byte-identical to v1126: KSPlayer playback surfaces/foundation, Tapframe KSPNUVIO integration path, Universal Codec Support, Phase 6 automatic source failover, Source Intelligence, Alternate Audio discovery, trailers, Live TV guide cache/persistence, Production & Ratings metadata, Phase 7 playback memory, background resume/history persistence, catalog artwork cache, episode alerts, PlaybackStateManager, auxiliary playback, stable feature gates, security manager, Live TV memory audit, and settings focus manager.

The v1126 Live TV corrections remain: centered compact information panel, Top Quick Guide and Bottom Quick Guide only. The VOD Poster Themed Logo and Production & Ratings Logo controls remain. Navigation Sounds remain removed.

## Validation

- 46/46 Swift files parsed successfully.
- Both app plists and project version validate at 1.0.655 (655).
- Backend Python modules compile.
- 15/15 Phase 9 bridge-runtime unit tests pass.
- 24/24 Phase 9 source-contract checks pass.
- 20/20 protected systems are byte-identical to v1126.
- No original v1126 files were removed.
- Archive extraction and complete hash verification are performed after packaging.

GitHub Actions remains the authoritative Xcode/tvOS compile/link gate. Physical Apple TV testing is still required. Do not begin Phase 10 until the app and actual backend v670 integration pass their respective build/deployment tests and Phase 9 behavior is confirmed.
