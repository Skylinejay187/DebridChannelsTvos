# Debrid Channels v1126 — Live TV Guide Position Correction

- Marketing version: **1.0.654**
- Build: **654**
- Source base: **packaged v1125 only**
- Backend: **v669 unchanged**

## Corrections

The compact Live TV information/control overlay is now centered from the left and right sides instead of being anchored to the lower-left. At a 1920-point reference width, the 1180-point panel leaves 740 points, or 370 points per side. The SwiftUI container uses a centered bottom alignment plus symmetric horizontal padding so the midpoint remains stable across supported 16:9 output sizes.

The original upper Live TV guide presentation is restored and named **Top Quick Guide**. The newer v1125 lower guide remains available and is named **Bottom Quick Guide**. Live TV Playback Settings now contain only these two guide choices. The Full Guide playback setting and its player-dismissal return route were removed.

Both quick guides continue using the existing Gracenote snapshot, channel selection, and tune path. No Live TV playback engine, audio, guide cache, channel URL, KSPlayer, or backend behavior was changed.

## Preserved v1125 work

The VOD **Poster Themed Logo** and **Production & Ratings Logo** controls remain present and default Off. Navigation Sounds remain completely removed.

## Validation

- 48/48 Swift files passed syntax parsing.
- Both plists and project.yml validate as 1.0.654 (654).
- Only four original v1125 files changed.
- All other original files remained byte-identical.
- GitHub Actions remains the authoritative Xcode/tvOS compilation test.
- Physical Apple TV behavior is not claimed until user testing.
