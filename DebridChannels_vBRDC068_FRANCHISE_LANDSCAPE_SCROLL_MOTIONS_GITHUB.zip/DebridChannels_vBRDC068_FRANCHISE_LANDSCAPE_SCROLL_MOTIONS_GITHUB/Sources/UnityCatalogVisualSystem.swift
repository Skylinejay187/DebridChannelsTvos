import SwiftUI

// vBRDC068: presentation-only visual system for catalog/search/media-info surfaces.
// It deliberately does not own navigation, focus, playback, catalog geometry, or metadata.
// The goal is to make the existing UI feel like one coherent "Unity" surface without
// moving rows, replacing the Live TV root, or adding heavyweight image-processing work.
enum UnityMediaVisualAccent {
    private static let palette: [Color] = [
        Color(red: 0.22, green: 0.76, blue: 1.00),
        Color(red: 0.98, green: 0.50, blue: 0.20),
        Color(red: 0.60, green: 0.42, blue: 1.00),
        Color(red: 0.20, green: 0.88, blue: 0.72),
        Color(red: 1.00, green: 0.32, blue: 0.48),
        Color(red: 0.96, green: 0.76, blue: 0.22)
    ]

    static func accent(for item: MediaItem) -> Color {
        // Never use Swift's randomized Hashable seed for appearance. This stable scalar
        // signature keeps a title's subtle accent consistent between launches/devices.
        var signature: UInt64 = 1469598103934665603
        for scalar in "\(item.title)|\(item.year)|\(item.type)".unicodeScalars {
            signature ^= UInt64(scalar.value)
            signature &*= 1099511628211
        }
        return palette[Int(signature % UInt64(palette.count))]
    }
}

struct UnityCatalogCardChrome: View {
    let item: MediaItem
    let focused: Bool
    var cornerRadius: CGFloat = 24
    var compact: Bool = false

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(focused ? 0.075 : 0.025),
                            accent.opacity(focused ? 0.045 : 0.012),
                            Color.clear,
                            Color.black.opacity(focused ? 0.05 : 0.12)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )

            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .strokeBorder(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(focused ? 0.90 : 0.18),
                            accent.opacity(focused ? 0.78 : 0.18),
                            Color.white.opacity(focused ? 0.20 : 0.07)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: focused ? (compact ? 1.8 : 2.2) : 0.8
                )

            // One restrained specular sweep makes the cards feel like a physical glass
            // object. Static gradients are intentionally used instead of perpetual shaders.
            LinearGradient(
                colors: [Color.white.opacity(focused ? 0.13 : 0.035), Color.clear, Color.clear],
                startPoint: .topLeading,
                endPoint: .center
            )
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))

            // vBRDC067: the vBRDC066 top dash / status-dot / lower accent rail looked
            // like unexplained playback or cache indicators on physical Apple TV. They were
            // decorative only, so remove them and let the glass edge/specular treatment carry
            // the card identity without implying nonexistent state.
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct UnityCatalogHeroAura: View {
    let item: MediaItem
    var intensity: Double = 1.0

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }

    var body: some View {
        ZStack {
            RadialGradient(
                colors: [accent.opacity(0.14 * intensity), accent.opacity(0.035 * intensity), Color.clear],
                center: .leading,
                startRadius: 10,
                endRadius: 720
            )
            RadialGradient(
                colors: [Color.white.opacity(0.035 * intensity), Color.clear],
                center: .topLeading,
                startRadius: 0,
                endRadius: 520
            )
        }
        .blendMode(.screen)
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct UnityCompactFranchiseRibbon: View {
    let item: MediaItem
    let visibleItems: [MediaItem]
    let totalCount: Int
    let baseIndex: Int
    let focusedIndex: Int?

    private var accent: Color { UnityMediaVisualAccent.accent(for: item) }
    private var expanded: Bool { focusedIndex != nil }

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            collapsedRibbon

            if expanded {
                expandedShelf
                    .offset(y: -100)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                    .zIndex(4)
            }
        }
        .frame(width: 808, height: 66, alignment: .bottomLeading)
        .animation(.spring(response: 0.30, dampingFraction: 0.88), value: expanded)
        .accessibilityElement(children: .contain)
    }

    private var collapsedRibbon: some View {
        HStack(spacing: 13) {
            ZStack {
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .fill(accent.opacity(expanded ? 0.22 : 0.13))
                Image(systemName: "square.stack.3d.up.fill")
                    .font(.system(size: 18, weight: .black))
                    .foregroundStyle(Color.white.opacity(0.94))
            }
            .frame(width: 42, height: 42)

            VStack(alignment: .leading, spacing: 2) {
                Text("EXPLORE THE FRANCHISE")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(1.15)
                    .foregroundStyle(.white.opacity(0.94))
                    .lineLimit(1)
                Text(totalCount == 1 ? "1 linked title" : "\(totalCount) linked titles")
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.52))
                    .lineLimit(1)
            }

            Spacer(minLength: 8)

            HStack(spacing: -14) {
                ForEach(Array(visibleItems.prefix(4).enumerated()), id: \.element.id) { offset, franchiseItem in
                    ZStack {
                        Color.black.opacity(0.44)
                        if let landscape = franchiseItem.landscapeURL, !landscape.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            RemoteImageFit(url: landscape, mode: .fill, showPlaceholder: false)
                        } else {
                            RemoteImageFit(url: franchiseItem.posterURL, mode: .fit, showPlaceholder: false)
                                .padding(2)
                        }
                    }
                    .frame(width: 48, height: 29)
                    .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 7, style: .continuous)
                            .stroke(Color.white.opacity(0.22), lineWidth: 0.8)
                    )
                    .rotationEffect(.degrees(Double(offset - 1) * 1.8))
                    .zIndex(Double(10 - offset))
                }
            }
            .frame(width: 124, alignment: .trailing)

            Image(systemName: expanded ? "chevron.up" : "chevron.right")
                .font(.system(size: 12, weight: .black))
                .foregroundStyle(accent.opacity(0.92))
                .frame(width: 22)
        }
        .padding(.horizontal, 12)
        .frame(width: 808, height: 62)
        .background(
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.white.opacity(expanded ? 0.085 : 0.052), accent.opacity(expanded ? 0.080 : 0.030), Color.black.opacity(0.20)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 19, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(expanded ? 0.44 : 0.16), accent.opacity(expanded ? 0.58 : 0.18), Color.white.opacity(0.05)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: expanded ? 1.5 : 0.8
                )
        )
        .shadow(color: accent.opacity(expanded ? 0.18 : 0.04), radius: expanded ? 14 : 6, y: 4)
    }

    private var expandedShelf: some View {
        HStack(spacing: 10) {
            ForEach(Array(visibleItems.enumerated()), id: \.element.id) { offset, franchiseItem in
                let absoluteIndex = baseIndex + offset
                UnityFranchiseMiniCard(
                    item: franchiseItem,
                    selected: focusedIndex == absoluteIndex,
                    accent: accent
                )
            }
        }
        .padding(10)
        .frame(width: 808, height: 150, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(Color.black.opacity(0.40))
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [Color.white.opacity(0.34), accent.opacity(0.48), Color.white.opacity(0.06)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1.0
                )
        )
        .shadow(color: .black.opacity(0.58), radius: 24, y: 12)
        .shadow(color: accent.opacity(0.16), radius: 18, y: 4)
    }
}

private struct UnityFranchiseMiniCard: View {
    let item: MediaItem
    let selected: Bool
    let accent: Color

    private var hasLandscape: Bool {
        guard let landscape = item.landscapeURL else { return false }
        return !landscape.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private var hasLogo: Bool {
        guard let logo = item.logoURL else { return false }
        return !logo.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .bottomLeading) {
                Color.black.opacity(0.48)

                // vBRDC068: the franchise shelf is intentionally landscape-first. A real
                // landscape/backdrop fills the wide card; portrait art is only a fallback and
                // stays aspect-fit so it is never brutally cropped into landscape geometry.
                if hasLandscape {
                    RemoteImageFit(url: item.landscapeURL, mode: .fill, showPlaceholder: false)
                        .saturation(selected ? 1.06 : 0.94)
                        .contrast(1.03)
                } else {
                    RemoteImageFit(url: item.posterURL, mode: .fit, showPlaceholder: false)
                        .padding(4)
                        .saturation(selected ? 1.06 : 0.94)
                }

                LinearGradient(
                    colors: [Color.clear, Color.black.opacity(0.08), Color.black.opacity(0.72)],
                    startPoint: .top,
                    endPoint: .bottom
                )

                // Clearlogos are never used as crop-fill artwork. Give every logo a fixed
                // safe box and aspect-fit it so long/wide franchise marks remain complete.
                if hasLogo {
                    RemoteImageFit(url: item.logoURL, mode: .fit, showPlaceholder: false)
                        .frame(width: 96, height: 30, alignment: .leading)
                        .padding(.leading, 8)
                        .padding(.bottom, 7)
                }
            }
            .frame(width: 150, height: 84)
            .clipped()

            HStack(spacing: 5) {
                Text(item.title)
                    .font(.system(size: 10.5, weight: .black, design: .rounded))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(1)
                    .minimumScaleFactor(0.58)

                Spacer(minLength: 2)

                if !item.year.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Text(item.year)
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.52))
                        .lineLimit(1)
                }
            }
            .padding(.horizontal, 8)
            .frame(width: 150, height: 36)
            .background(Color.black.opacity(0.78))
        }
        .frame(width: 150, height: 120)
        .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .stroke(selected ? accent.opacity(0.96) : Color.white.opacity(0.10), lineWidth: selected ? 2.4 : 0.8)
        )
        .scaleEffect(selected ? 1.045 : 1.0)
        .shadow(color: selected ? accent.opacity(0.28) : .black.opacity(0.20), radius: selected ? 14 : 5, y: selected ? 6 : 2)
        .animation(.spring(response: 0.24, dampingFraction: 0.84), value: selected)
    }
}

// MARK: - Catalog row motion presets

/// vBRDC068: presentation-only horizontal catalog motion. These styles change only the
/// insertion/removal animation used when the selected catalog item changes. They never
/// own focus, mutate selectedIndex, move a row vertically, or change catalog geometry.
enum UnityCatalogRowMotionStyle {
    static let defaultName = "Classic Spring"
    static let names = [
        "Classic Spring",
        "Smooth Glide",
        "Cinematic Drift",
        "Elastic",
        "Quick Snap",
        "Soft Float",
        "Depth Shift",
        "Carousel Tilt",
        "Instant"
    ]

    static func animation(for name: String) -> Animation? {
        switch normalized(name) {
        case "smooth glide":
            return .easeInOut(duration: 0.30)
        case "cinematic drift":
            return .spring(response: 0.52, dampingFraction: 0.90)
        case "elastic":
            return .interpolatingSpring(stiffness: 205, damping: 18)
        case "quick snap":
            return .easeOut(duration: 0.17)
        case "soft float":
            return .spring(response: 0.46, dampingFraction: 0.82)
        case "depth shift":
            return .spring(response: 0.40, dampingFraction: 0.87)
        case "carousel tilt":
            return .spring(response: 0.44, dampingFraction: 0.82)
        case "instant":
            return nil
        default:
            // Byte-for-behavior equivalent timing to the pre-vBRDC068 catalog rail.
            return .spring(response: 0.42, dampingFraction: 0.84)
        }
    }

    static func transition(for name: String, direction: Int) -> AnyTransition {
        let d = CGFloat(direction == 0 ? 1 : direction)
        let insertion: AnyTransition
        let removal: AnyTransition

        switch normalized(name) {
        case "smooth glide":
            insertion = transform(x: 82 * d, y: 0, scale: 0.985, opacity: 0.10)
            removal = transform(x: -64 * d, y: 0, scale: 0.99, opacity: 0.10)
        case "cinematic drift":
            insertion = transform(x: 108 * d, y: 9, scale: 0.955, angleY: -4.5 * Double(d), opacity: 0.05)
            removal = transform(x: -72 * d, y: -4, scale: 0.975, angleY: 3.0 * Double(d), opacity: 0.05)
        case "elastic":
            insertion = transform(x: 148 * d, y: 0, scale: 0.91, angleY: -7.0 * Double(d), opacity: 0.02)
            removal = transform(x: -94 * d, y: 0, scale: 0.95, angleY: 5.0 * Double(d), opacity: 0.02)
        case "quick snap":
            insertion = transform(x: 44 * d, y: 0, scale: 0.995, opacity: 0.38)
            removal = transform(x: -32 * d, y: 0, scale: 0.995, opacity: 0.28)
        case "soft float":
            insertion = transform(x: 70 * d, y: 18, scale: 0.965, angleZ: 0.55 * Double(d), opacity: 0.08)
            removal = transform(x: -54 * d, y: -12, scale: 0.98, angleZ: -0.35 * Double(d), opacity: 0.08)
        case "depth shift":
            insertion = transform(x: 56 * d, y: 0, scale: 0.875, angleY: -10.0 * Double(d), opacity: 0.06)
            removal = transform(x: -42 * d, y: 0, scale: 1.04, angleY: 7.0 * Double(d), opacity: 0.04)
        case "carousel tilt":
            insertion = transform(x: 104 * d, y: 0, scale: 0.93, angleY: -14.0 * Double(d), opacity: 0.04)
            removal = transform(x: -74 * d, y: 0, scale: 0.96, angleY: 11.0 * Double(d), opacity: 0.04)
        case "instant":
            return .identity
        default:
            // Classic Spring preserves the familiar pre-setting move/opacity behavior,
            // while respecting the direction the user actually moved.
            insertion = .move(edge: direction < 0 ? .leading : .trailing).combined(with: .opacity)
            removal = .move(edge: direction < 0 ? .trailing : .leading).combined(with: .opacity)
        }
        return .asymmetric(insertion: insertion, removal: removal)
    }

    static func subtitle(for name: String) -> String {
        switch normalized(name) {
        case "smooth glide": return "clean, even side-to-side glide"
        case "cinematic drift": return "slower premium drift with light depth"
        case "elastic": return "springier travel with a stronger arrival"
        case "quick snap": return "fast, crisp catalog movement"
        case "soft float": return "gentle lift while cards move"
        case "depth shift": return "cards move through foreground depth"
        case "carousel tilt": return "angled carousel-style travel"
        case "instant": return "no horizontal transition animation"
        default: return "original Debrid Channels spring motion"
        }
    }

    private static func normalized(_ name: String) -> String {
        names.contains(name) ? name.lowercased() : defaultName.lowercased()
    }

    private static func transform(
        x: CGFloat,
        y: CGFloat,
        scale: CGFloat,
        angleY: Double = 0,
        angleZ: Double = 0,
        opacity: Double
    ) -> AnyTransition {
        .modifier(
            active: UnityCatalogRowMotionTransitionModifier(
                x: x,
                y: y,
                scale: scale,
                angleY: angleY,
                angleZ: angleZ,
                opacity: opacity
            ),
            identity: UnityCatalogRowMotionTransitionModifier(
                x: 0,
                y: 0,
                scale: 1,
                angleY: 0,
                angleZ: 0,
                opacity: 1
            )
        )
    }
}

private struct UnityCatalogRowMotionTransitionModifier: ViewModifier {
    let x: CGFloat
    let y: CGFloat
    let scale: CGFloat
    let angleY: Double
    let angleZ: Double
    let opacity: Double

    func body(content: Content) -> some View {
        content
            .scaleEffect(scale)
            .rotation3DEffect(.degrees(angleY), axis: (x: 0, y: 1, z: 0), perspective: 0.58)
            .rotationEffect(.degrees(angleZ))
            .offset(x: x, y: y)
            .opacity(opacity)
    }
}

struct CatalogRowMotionPicker: View {
    @Binding var selectedStyle: String
    @FocusState private var focusedStyle: String?
    private let columns = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(UnityCatalogRowMotionStyle.names, id: \.self) { style in
                let isFocused = focusedStyle == style
                Button {
                    selectedStyle = style
                    UserDefaults.standard.set(style, forKey: "catalogRowScrollingAnimationPreset")
                    UserDefaults.standard.synchronize()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: selectedStyle == style ? "checkmark.circle.fill" : "rectangle.3.group.fill")
                            .font(.system(size: 15, weight: .black))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(style)
                                .font(.system(size: 14.5, weight: .black, design: .rounded))
                                .lineLimit(1)
                            Text(UnityCatalogRowMotionStyle.subtitle(for: style))
                                .font(.system(size: 9.5, weight: .heavy, design: .rounded))
                                .foregroundStyle(selectedStyle == style ? Color.black.opacity(0.62) : Color.white.opacity(0.52))
                                .lineLimit(1)
                                .minimumScaleFactor(0.72)
                        }
                        Spacer(minLength: 0)
                    }
                    .foregroundStyle((selectedStyle == style || isFocused) ? Color.black : Color.white)
                    .padding(.horizontal, 12)
                    .frame(height: 58)
                    .background(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .fill(selectedStyle == style ? Color.cyan.opacity(0.92) : (isFocused ? Color.orange.opacity(0.82) : Color.white.opacity(0.085)))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 15, style: .continuous)
                            .stroke((selectedStyle == style || isFocused) ? Color.white.opacity(0.90) : Color.white.opacity(0.10), lineWidth: (selectedStyle == style || isFocused) ? 2 : 1)
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .contentShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                }
                .buttonStyle(.plain)
                .focused($focusedStyle, equals: style)
                .modifier(SettingsRoundedFocusVisual(cornerRadius: 15))
            }
        }
        .padding(.top, 4)
    }
}
