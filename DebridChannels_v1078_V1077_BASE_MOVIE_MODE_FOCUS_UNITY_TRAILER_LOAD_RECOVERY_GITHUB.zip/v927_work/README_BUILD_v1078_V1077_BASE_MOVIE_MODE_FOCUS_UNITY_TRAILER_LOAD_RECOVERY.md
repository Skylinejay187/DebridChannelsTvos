# Debrid Channels v1078

Base: v1077
Version: 1.0.606 (606)

## Scope

- Movie Mode opens directly on the first card of the first Home catalog row.
- The bottom navigation remains visible but is removed from the focus graph until explicitly requested.
- LEFT from the first catalog card or DOWN from the final catalog row transfers focus to the bottom navigation.
- Back from content transfers focus to the bottom navigation; a later second Back closes Movie Mode browsing and returns to the VOD overlay.
- Nested tvOS Back handlers are debounced so one press cannot both focus the menu and close the browser.
- Settings participates in the same Movie Mode Back contract.
- The production Live TV grid remains visually unchanged and uses a clear Movie Mode background so the active VOD remains visible behind it.
- Catalog previews and metadata are allowed to run while Movie Mode browsing is layered over an active VOD.
- Opening a built-in trailer from Movie Mode pauses the active VOD and closing/failing the trailer restores its previous play state.
- Trailer resolution now attempts the durable audio-verified remux contract first, then a backward-compatible complete mux contract. Both paths stage the complete file locally and validate video/audio coverage before KSPlayer opens it.
- Full-width catalog rail behavior from v1075 remains preserved.

## Validation performed in this environment

- Swift syntax parsing for all app and Top Shelf Swift sources.
- Both Info.plists parsed and matched version/build 1.0.606 (606).
- project.yml parsed as YAML and its project versions matched.
- Included trailer backend helper passed Python compilation.
- Source-level invariants for Movie Mode focus, Live TV transparency, VOD trailer pause/resume, and trailer compatibility fallback were checked.
- Final archive extraction and SHA-256 file comparison are recorded in VALIDATION_RESULTS_v1078.json.

GitHub Actions/Xcode and Apple TV testing remain the authoritative compile and runtime validation.
