# vBRDC397 Phase 6 — Resume / Trakt / History

Source based on vBRDC397 Phase 6 Resume Dedup ZIP; preserves VOD Artwork 4 Hero 2 fix.

## Implemented in this lineage
- One poster per title in local and Trakt Continue Watching shelves, preserving the first/newest supplied episode.
- Local hidden Resume identities normalize episode suffixes.
- Additional yearless movie identity alias for hidden Resume cards, so a Trakt movie lacking release-year metadata does not reappear after local removal.
- Local removal remains separate from destructive Trakt history deletion.
- Trakt shelves retain cached content on transient network failures; explicit disconnect clears account shelves.
- vBRDC397 / app 1.0.1110 / build 1110 synchronized in project, app and Top Shelf metadata.

## Validation limitations
- Swift frontend parsing performed on modified file; not a full Apple-platform typecheck.
- ZIP integrity verified.
- No Xcode/tvOS simulator or Apple TV runtime available here. Full cross-device Trakt account synchronization, watch-history delete semantics, long-press behavior, and catalog regressions remain device-validation requirements.
- This is a source candidate, not a certified full Phase 6 release.
