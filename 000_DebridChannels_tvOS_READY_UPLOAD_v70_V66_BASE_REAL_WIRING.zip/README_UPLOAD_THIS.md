# Debrid Channels tvOS v70

Upload this repo package contents to GitHub and run the included workflow.

Build marker: Build v70 V66 BASE + REAL WIRING

This package preserves the v66 renderer base and v14-style signing-safe packaging while adding:
- persistent right-side poster motion
- focused artwork/video home background layering
- 3-second preview trigger using playable preview URLs when metadata provides them
- multi-JSON saved list with add/clear/load-all behavior
