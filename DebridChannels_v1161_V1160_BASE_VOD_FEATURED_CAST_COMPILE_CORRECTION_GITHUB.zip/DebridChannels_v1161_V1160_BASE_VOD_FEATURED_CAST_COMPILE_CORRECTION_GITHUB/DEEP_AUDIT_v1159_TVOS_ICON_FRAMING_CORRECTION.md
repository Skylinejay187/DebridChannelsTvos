# v1159 tvOS App Icon Framing Correction Audit

Base: packaged v1158 only. Backend: v674 unchanged.

## Physical Apple TV finding

The v1158 launcher icon compiled, but the selected square artwork was first kept as a 4:3 inset composition and then placed inside the required 5:3 tvOS launcher canvas. On Apple TV this produced a visible rounded-square image inside the system launcher tile, making the new icon look much smaller than neighboring apps.

## Correction

The exact user-selected master from v1158 remains unchanged at `Resources/DebridChannelsAppIconMaster_v1158.png`. v1159 does not redraw or regenerate the artwork. The tvOS launcher variants now use a direct 5:3 crop from the master and fill the complete 400x240 / 1280x768 launcher canvases. There is no 4:3 inset and no blurred side-extension layer. The crop is intentionally centered lower enough to keep the DEBRID CHANNELS lettering and orange glow line while retaining the antenna/TV identity.

Canonical `AppIcon.brandassets` Back layers and all legacy landscape launcher fallbacks are synchronized to the same corrected 5:3 framing. Middle/Front parallax layers remain unchanged and transparent. Top Shelf artwork, loading screen, and in-app Home branding remain untouched.

## Runtime preservation

No Swift source file is modified from v1158. Therefore v1157 VOD overlay themes and all v1156/v1155 playback, wallpaper, navigation, resume, Sports, Source Intelligence, and catalog behavior remain unchanged.

## Version

- Marketing version: 1.0.687
- Build: 687
- Backend: v674 unchanged

GitHub Actions/Xcode `actool` and physical Apple TV remain authoritative for the final launcher presentation.
