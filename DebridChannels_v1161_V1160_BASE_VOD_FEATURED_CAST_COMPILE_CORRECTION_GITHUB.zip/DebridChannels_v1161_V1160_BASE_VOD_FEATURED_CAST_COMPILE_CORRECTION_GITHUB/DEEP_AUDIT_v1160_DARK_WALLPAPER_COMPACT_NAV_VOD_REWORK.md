# v1160 Deep Visual Audit — Dark Wallpaper / Compact Navigation / VOD Theme Rework

**Base:** packaged v1159 only  
**Marketing:** 1.0.688  
**Build:** 688  
**Backend:** v674 unchanged

## Scope

This is a visual-only corrective pass on the v1159 runtime line. It addresses three physical Apple TV observations: several top-menu theme families were materially wider/larger than the compact production geometry; the Dynamic Live Wallpaper library needed more genuinely dark themes; and the non-Original VOD overlay themes introduced in v1157 were too opaque/tall and covered too much video.

## VOD theme redesign

The v1159 **Original** VOD overlay is protected exactly. `vodOriginalBottomChromeLayer` and `PlayerControlButton.originalBody` compare byte-for-byte with v1159.

The seven non-Original themes keep their existing preference names for upgrade compatibility but are visually rebuilt:

- **Pro** — compact translucent technical deck with thin blue edge light.
- **Cinema** — open theatrical composition with a transparent lower fade and single warm hairline.
- **Media Center** — compact Kodi-inspired OSD rail with a narrow left status accent; no opaque full-height slab.
- **Studio** — low-profile broadcast HUD with restrained glass and status geometry.
- **Minimal** — content-first presentation with almost no container chrome.
- **Noir** — transparent monochrome strip with fine upper/lower hairlines.
- **Prestige** — dark transparent theater deck with warm metallic linework.

The v1157/v1159 full-content theme shell is no longer painted as a large dark rounded rectangle. Theme surfaces are now visualized only as a compact bottom deck (78 points collapsed / 118 points expanded), while the metadata remains floating over the video. Themed controls are reduced from roughly 72-point artwork / 112-point cells to a compact ~58-point artwork / 86-point cell system. Themed metadata typography is also tightened. The non-Original full-screen backdrop now uses a restrained lower-screen fade rather than near-opaque black coverage.

Design references used during this correction included Apple tvOS material guidance, Kodi Estuary's documented transparent OSD approach, Kodi's skin-dependent OSD model, and Infuse 8's contemporary player-control redesign. The implementation is original Debrid Channels SwiftUI and does not copy another product's assets or layout.

## Top menu compact sizing correction

All visual families remain available, but oversized families are normalized to the compact navigation discipline already proven by the earlier letters-only fix. Changes include smaller family-specific spacing, reduced new-theme font sizes, reduced internal padding/minimum widths, and a lower focus scale (1.030 instead of 1.045 for non-Minimal families). Minimal / letters-only retains its known-good v1130-derived geometry.

This keeps Search and the clock isolated from the navigation rail while preserving each theme family's actual visual identity.

## Dark Dynamic Live Wallpaper expansion

The wallpaper library expands from **36 to 48 themes**. The 12 new dark themes are:

- Black Velvet Smoke
- Obsidian Spotlight
- Midnight Smoke
- Charcoal Haze
- Dark Theater
- OLED Cinema
- Shadow Projector
- Night Broadcast
- Black Glass Signal
- Dark Studio
- Noir Lounge
- Deep Space Black

These themes use the existing v1156/v1155 asynchronous Canvas renderer and existing primitives. No new live blur stacks, Timeline engines, image decoders, or background tasks are introduced. Compatibility / Balanced / High Performance remain 8 / 15 / 30 fps. Wallpaper continues animating while browsing the uncovered Live TV grid and fully suspends when playback, guides, details, quick panels, Search, or another app section owns the screen.

## Protected runtime systems

The following v1159 playback/source functions are byte-for-byte unchanged:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`
- `startPlayerClock`
- `sourceSelectedPlaybackItem`

Protected files including PlaybackResumeCache, AutomaticSourceFailoverManager, PerTitlePlaybackMemory, UniversalCodecSupport, PlaybackKit core, Phase15FinalIntegration, SportsCenterViewModel, TrailerServiceManager, CatalogStore, and SourceIntelligenceManager remain byte-identical to v1159.

The corrected v1159 app-icon assets are also untouched.

## Local validation

- Swift parse: **54/54** files passed.
- Static/preservation contract: **60/60** checks passed.
- Main app and Top Shelf plists parse successfully.
- Marketing/build versions agree at **1.0.688 / 688**.
- Before adding v1160 audit artifacts, only four inherited files differed from v1159: `DebridChannelsTVOSApp.swift`, the two Info.plists, and `project.yml`.

GitHub Actions/Xcode is authoritative for full tvOS type-checking and asset compilation; physical Apple TV testing is authoritative for final visual scale/focus review.
