# v1146 Deep Audit — Resume, tvOS Focus Platter, Live Scrubbing

Base: packaged v1145 only  
App: v1146 / marketing 1.0.674 / build 674  
Backend: v674 unchanged

## 1. Automatic resume root cause

v1145 queued the correct persisted resume timestamp but also assigned that value to `ksStartTimeSeconds` before KSPlayer surface construction. `PlaybackKitKSPlayerSurface.Coordinator.resetClockGateForNewSource(startTime:)` initializes `currentPlaybackSeconds` from that startup value, and the coordinator can publish it during KSPlayer readiness before the decoder's raw clock proves the engine actually reached that position.

That allowed the VOD resume verifier to see the target value and falsely mark automatic resume as confirmed while the actual decoder could still be starting at 0:00.

v1146 removes that ambiguity:

- automatic resume opens the KS surface with `ksStartTimeSeconds = 0`;
- the target remains pending but is not used to seed the player clock;
- KS confirmation reads PlaybackKit's session clock, never the optimistic local UI clock;
- the first seek is not sent until the real clock has advanced;
- confirmation is illegal until at least one actual in-place seek has been issued;
- up to three bounded in-place absolute seek attempts are allowed if an early demuxer seek is swallowed;
- the saved target remains available as a manual fallback if the decoder never confirms it.

The KSPlayer engine implementation itself is unchanged.

## 2. Resume persistence durability

The existing `startPlayerClock()` helper intentionally exits after KSPlayer reaches first frame. That meant it no longer performed the historical five-second resume-save bookkeeping for the rest of a KS playback session. A normal teardown still attempted a final save, but relying on exit alone made progress less durable and made any ownership/lifecycle race more costly.

v1146 saves from the real KS decoder clock callback instead. The existing resume helper still throttles writes to once every five seconds and `PlaybackResumeCacheManager` still performs JSON writes on its utility writer queue. On normal exit, the existing forced final save remains in place.

`PlaybackResumeCache.swift` remains byte-identical to v1145.

## 3. Full Episode Browser white outer focus platter

The Phase 15 episode browser used SwiftUI `Button` for episode cards, season chips, Close, source rows, source Cancel, and switch-confirmation actions. The main app already contains the v927 finding that tvOS can install a large rectangular focus background around a `Button` even when `.buttonStyle(.plain)` and `.focusEffectDisabled()` are applied.

v1146 converts every custom action in `Phase15FinalIntegration.swift` to the app's proven platter-free pattern:

- the custom-shaped view itself is `.focusable(...)`;
- `@FocusState` still drives the existing orange/custom focused appearance;
- Select activation is handled with `.onTapGesture`;
- accessibility button traits are retained;
- no runtime `Button` declaration remains in the Phase 15 custom VOD overlays.

The whole-app audit also hardens `TransparentTVFocusVisual` and `SettingsRoundedFocusVisual` so Button-backed legacy controls that intentionally remain buttons use `SportsNoPlatterButtonStyle` instead of falling back to `.plain`. The top Search icon, onboarding actions, Favorites remove action, and Favorite Live TV card were also moved to focusable custom-action rendering where appropriate.

## 4. Timeline scrub behavior

v1145 intentionally made LEFT/RIGHT preview-only and required Select/center to commit. v1146 removes that second step.

- LEFT/RIGHT updates the `SCRUB TO` time immediately;
- a 90 ms debounce allows tvOS to finish its directional focus transaction;
- the last preview target is then automatically sent as an absolute player seek;
- rapid repeated LEFT/RIGHT presses coalesce to the latest target instead of flooding KSPlayer;
- Select is no longer required; if pressed during the tiny debounce it simply commits the already-visible target immediately;
- focus is reasserted on the timeline after the seek so the old focus-drop regression does not return.

## Locked/unmodified systems

The following core files remain byte-identical to packaged v1145:

- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/PlaybackKit/PlaybackController.swift`
- `Sources/PlaybackResumeCache.swift`
- `Sources/CatalogStore.swift`
- `Sources/TrailerService.swift`

No backend change is required.
