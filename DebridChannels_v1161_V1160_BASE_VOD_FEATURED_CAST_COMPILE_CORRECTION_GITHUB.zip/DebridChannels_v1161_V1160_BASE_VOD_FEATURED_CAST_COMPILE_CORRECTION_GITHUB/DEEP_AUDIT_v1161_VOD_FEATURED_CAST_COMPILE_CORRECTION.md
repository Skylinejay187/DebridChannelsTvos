# v1161 — VOD Featured Cast Compile Correction

Base: packaged v1160 only  
Marketing version: 1.0.689  
Build: 689  
Backend: v674 unchanged

## GitHub Actions failure
The v1160 GitHub Actions log (`logs_86162907552.zip`) failed at `EmitSwiftModule` with exactly three errors, all the same missing type:

- `DebridChannelsTVOSApp.swift:16473:50` — cannot find type `VODFeaturedCastPresentationMode` in scope
- `DebridChannelsTVOSApp.swift:23270:39` — cannot find type `VODFeaturedCastPresentationMode` in scope
- `DebridChannelsTVOSApp.swift:24024:15` — cannot find type `VODFeaturedCastPresentationMode` in scope

No other build-stopping compiler errors were present in the supplied log.

## Root cause
During the v1160 VOD theme visual rewrite, the pre-existing `VODFeaturedCastPresentationMode` enum was inadvertently removed from `DebridChannelsTVOSApp.swift` while its call sites remained.

## Correction
v1161 restores the enum verbatim from v1159 immediately before `VODPlayerScreen`:

- `off`
- `compactOverlay`
- `fullPoster`
- exact `displayName`
- exact `next` cycling behavior

No VOD theme geometry, overlay rendering, Featured Cast behavior, playback logic, resume behavior, source selection, Sports routing, wallpaper engine, app icon, or top-menu visual code is changed.

## Preservation
The v1160 visual pass remains intact:
- 48 dynamic wallpapers including the 12 darker presets
- compact normalized top-menu sizing
- rebuilt translucent non-Original VOD themes
- Original VOD theme preserved
- corrected v1159 launcher icon
- v1154+ movie Find Links resume identity and Sports live routing
- automatic LEFT/RIGHT scrubber behavior

GitHub Actions / Xcode remains authoritative for full tvOS compilation.
