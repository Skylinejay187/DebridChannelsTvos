# v1150 Deep Audit — Resume Durability, VOD Discovery Removal, True Appearance Themes

## Base discipline
v1150 is modified only from packaged v1149. Packaged v1130 is comparison-only for the automatic-resume path because the user identified it as a known-working resume build.

## Resume investigation

### Known-good donor comparison
The v1149 line already had the v1130 resume jump restored. Static extraction confirms these functions are still exactly identical to v1130:

1. `scheduleAutomaticResumeAfterSurfaceStart`
2. `switchToKSPlayerEngine`
3. `seekAbsolute`
4. `startPlayerClock`

`applyAutomaticResumeIfAvailable` is donor-identical in v1150 after removing the one intentional persistence-floor assignment.

This ruled out another rewrite of the resume seek as the appropriate next fix.

### Persistence failure exposed by force-closing
`PlaybackResumeCacheManager` stores progress in an in-memory payload and asynchronously writes `Application Support/DebridChannels/playback-resume-v1119.json`. The production KSPlayer callback fed the real playback clock into PlaybackKit, but did not checkpoint the resume cache from that authoritative decoder clock. The normal player clock path also stops its periodic synthetic work after stable KSPlayer first frame. As a result, the freshest position could depend heavily on VOD teardown. Process background/termination can occur without a reliable view teardown window, which explains the observed pattern: current timeline looks correct, then relaunch shows the old/zero position.

### v1150 durability correction
- KSPlayer `onPlaybackTimeUpdate` now calls the existing throttled `saveResumePositionIfNeeded()` after ingesting the real clock.
- Resume saves remain asynchronous during normal playback to avoid blocking decode/UI work.
- `PlaybackResumeCacheManager.saveProgress`/`clear` accept an opt-in synchronous mode.
- `flushSynchronously()` snapshots the latest in-memory payload and serializes through the same writer queue, so all older queued writes drain first and the newest snapshot is written last.
- VOD scene inactive/background and player teardown call a forced durable save + synchronous flush.
- Atomic JSON writes remain enabled.

### Startup overwrite protection
The working v1130 resume mechanism performs a resume-only KSPlayer reload/start-time seek. A replacement surface can briefly report `0:00` before the seek/start time lands. Because v1150 now checkpoints the real decoder clock, it adds `resumePersistenceFloorSeconds`:

- When a saved resume target is queued, that value becomes the floor.
- Clock values more than four seconds below the target are ignored for persistence while the resume is pending.
- Once the real clock reaches the target neighborhood, the floor clears and normal five-second saving resumes.

This prevents the durability fix itself from destroying the good checkpoint during startup.

## Scrubber preservation
The user confirmed automatic scrubbing works and asked that it not be changed. Exact function extraction/hashing confirms both:

- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`

are byte-identical to packaged v1149. The 90 ms automatic seek debounce remains.

## VOD top-right recommendation/trivia removal
The old Smart Info/Discovery feature was not merely hidden. v1150 removes:

- the overlay renderer
- VOD Smart Info state and tasks
- start/stop/rotation functions
- player settings option and activation route
- `vodSmartInfoPanelModeV1` AppStorage/default/security registration
- memory-pressure hook
- `Sources/VODSmartInfo.swift`
- project.yml source entry

No runtime/settings references to the removed feature remain.

## Appearance redesign
The earlier Appearance expansion still reused one top-menu composition for nearly every choice. v1150 introduces `TopMenuVisualFamily` and `TopMenuTabVisual` so theme selection can materially change structure and spatial language rather than only color.

There are 10 renderer families and 22 named themes. Examples:

- **Icon Dock:** circular symbol dock with labels beneath
- **Floating Tiles:** independent elevated navigation tiles
- **Cinema Marquee:** wide tracked uppercase labels between marquee rules
- **Studio Ribbon:** leading accent rail + icon + label
- **Segmented Control:** compact icon/label capsules
- **Compact Icons:** circular icon-first navigation
- **Neon Line:** typography-first bar with a thin luminous selection line
- **Monochrome:** hard black/white blocks
- **Poster Tabs:** compact card tabs with NOW VIEWING/BROWSE secondary labels

Top-menu accent choices increase to 41. Shared popup/top-menu typography increases to 66 presets, including additional real system font-family mappings. The selected typography kerning is applied in the top-menu renderer.

## Preservation checks
Byte-identical to v1149:

- `PlaybackKitFoundation.swift`
- `PlaybackKitKSPlayerSurface.swift`
- `UniversalCodecSupport.swift`
- `AutomaticSourceFailoverManager.swift`
- `PerTitlePlaybackMemory.swift`
- `CatalogStore.swift`
- `TrailerServiceManager.swift`
- `SportsCenterViewModel.swift`
- `Phase15FinalIntegration.swift`

The v1149 Connected Popup artwork correction and Sports live-channel direct-tune route remain present.

## Validation
- 54/54 Swift files parse with `swiftc -parse`.
- 88/88 static/preservation contracts pass.
- Both plists parse as valid property lists and report 1.0.678 / 678.
- project.yml parses and carries 1.0.678 / 678 for app and Top Shelf.
- GitHub Actions/Xcode remains the authoritative compiler/build test.
