# Debrid Channels v1152 — Compact Minimal Top Menu + Live Wallpaper Performance

Base: packaged v1151 only  
Donor/reference: packaged v1130 only for original top-menu geometry  
Marketing version: 1.0.680  
Build: 680  
Backend: v674 unchanged

## 1. Top-menu stretching root cause

The letters-only/minimal top-menu family in v1151 used an unconstrained SwiftUI `Rectangle` as its underline. Because that Rectangle lived inside each tab's `VStack`, and the tabs lived inside the main navigation `HStack`, the underline was horizontally flexible. SwiftUI therefore allowed each tab to consume excess width, making the menu expand across almost the entire screen and collide with the Search/clock region.

The v1130 menu did not have this behavior. Its underline was a fixed-width Capsule and its menu geometry was compact/intrinsic.

v1152 restores the v1130 geometry **only for the letters-only/minimal family** while keeping all v1150/v1151 visual theme families and font/color selections:

- spacing: 42 pt
- text size: 25 pt (selected font family still applies)
- horizontal padding: 12 pt normal / 22 pt focused
- vertical padding: 7 pt normal / 9 pt focused
- underline: 54 pt, Settings 64 pt
- focused scale: 1.018
- no flexible underline view

This restores Search/clock reachability and the compact visual width shown by the older working menu without rolling back the other new top-menu themes.

## 2. Dynamic wallpaper performance root cause

v1151 rendered four very large SwiftUI Ellipses with 72-point live blur at 15 fps. Each frame required multiple large offscreen blur passes. On current Apple TV hardware those effects can compete with focus/card compositing during rapid grid navigation.

v1152 keeps the moving smoke/mist concept but changes the rendering strategy:

- one asynchronous SwiftUI `Canvas`
- 3 radial-gradient smoke fields instead of 4 live-blurred Ellipse view trees
- no 72-point live blur passes
- 8 fps animation cadence (appropriate for deliberately slow smoke motion)
- while the user is actively moving through the Live TV grid, wallpaper animation is temporarily paused
- animation automatically resumes 360 ms after navigation settles
- selected-channel changes also arm the performance pause, so native tvOS focus movement gets the same protection
- Full Guide remains wallpaper-free exactly as in v1151

This prioritizes remote/focus/grid responsiveness on current Apple TV models while keeping the wallpaper visibly alive when navigation settles. Faster future hardware benefits automatically, but the current rendering path no longer depends on brute-force GPU headroom.

## 3. Protected behavior

No resume, playback, Sports, connected-popup, Phase 15, or scrubber behavior was changed in this pass.

The following v1151 functions are byte-for-byte unchanged:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `startPlayerClock`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`

The following files are byte-identical to v1151:

- `Sources/PlaybackResumeCache.swift`
- `Sources/AutomaticSourceFailoverManager.swift`
- `Sources/PerTitlePlaybackMemory.swift`
- `Sources/UniversalCodecSupport.swift`
- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `Sources/PlaybackKit/PlaybackKitFoundation.swift`
- `Sources/Phase15FinalIntegration.swift`
- `Sources/CatalogStore.swift`
- `Sources/TrailerServiceManager.swift`
- `Sources/SportsCenterViewModel.swift`

## 4. Files changed from v1151

Only:

- `Sources/DebridChannelsTVOSApp.swift`
- `Sources/Info.plist`
- `TopShelfExtension/Info.plist`
- `project.yml`

Plus v1152 validation/audit files added to the package.

## 5. Local validation

- 54/54 Swift files passed `swiftc -frontend -parse`
- 37/37 static/preservation contracts passed
- v1130 menu geometry donor comparison passed 12/12 checks
- both Info.plists passed `plutil -lint`
- app/TopShelf/project versions are 1.0.680 / 680

GitHub Actions/Xcode remains the authoritative tvOS typecheck/compile test, followed by physical Apple TV testing.
