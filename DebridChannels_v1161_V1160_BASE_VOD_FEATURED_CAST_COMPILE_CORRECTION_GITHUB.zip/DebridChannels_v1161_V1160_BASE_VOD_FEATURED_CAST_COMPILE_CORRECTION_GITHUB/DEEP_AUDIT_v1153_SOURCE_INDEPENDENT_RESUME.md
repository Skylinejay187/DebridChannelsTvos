# v1153 Deep Audit — Source-Independent Resume + Episode Remaining Time

Base: packaged v1152 only  
Marketing version: 1.0.681  
Build: 681  
Backend: v674 unchanged

## Physical-test symptom
A title resumed correctly when opened through the normal Play path, but could restart from 0 after the user chose Find Links and selected another/higher-quality source. Shows also needed the exact saved progress/time remaining surfaced on episode cards.

## Root cause
The resume timestamp was already source-URL independent, but it was not fully resolver-identity independent. The connected Find Links path upgrades `sourceSearchItem` through `resolverReadyStreamItem(...)` before playback. That hydration can change which metadata identity is considered strongest (for example an original IMDb/fallback identity gains a TMDB identity). `PlaybackResumeCache.playbackKey(for:)` intentionally prefers TMDB before IMDb. Therefore the same movie/episode could be saved under one key and reopened through Find Links under another key.

This explains why normal Play could resume while a manually selected source did not: the seek code was receiving no saved entry for the hydrated item.

## v1153 correction
`PlaybackResumeCacheManager` now treats all known identities for one logical title as aliases:

- Movie: current canonical key, TMDB, IMDb, TVDB when available, plus guarded normalized title/year identity.
- Episode: exact season/episode combined with TMDB, IMDb, TVDB, stripped/raw show identity, plus guarded normalized series-title/year identity.
- Existing pre-v1153 single-key entries remain readable through a fallback legacy identity matcher.
- Every new checkpoint is published under all known aliases for that logical movie or exact S/E episode.
- Clearing/completion removes all aliases for that same logical item.
- `playbackKey(for:)` itself is unchanged, so existing per-title track-preference keys are not redefined.

## Functional identity tests
A standalone typechecked Swift harness verified:

1. Save movie at 25:00 using IMDb-only identity -> hydrated TMDB+IMDb item reads 25:00.
2. Save hydrated movie at 35:00 -> original IMDb-only item reads 35:00.
3. Save exact S2E5 at 15:00 using IMDb episode identity -> hydrated TMDB+IMDb S2E5 reads 15:00.
4. Save hydrated S2E5 at 20:00 -> original S2E5 reads 20:00.
5. A simulated pre-v1153 fallback-only movie entry is recovered after TMDB hydration.
6. A simulated pre-v1153 fallback-only S3E7 entry is recovered after TMDB hydration.

## Visible resume information
- Movie connected popup: progress bar now also shows `RESUME <time> • <time remaining> LEFT`.
- Embedded Find Links / Source Intelligence: shows resume position and remaining time for the currently resolved item.
- Season/episode preview cards: exact episode displays time remaining.
- Phase 15 Full Episode Browser cards: exact episode displays time remaining.

## Explicitly preserved
The actual v1152 playback/seek implementation was not changed. The following functions are byte-for-byte identical to v1152:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`
- `startPlayerClock`

`CatalogStore.startPlayback`, Find Links resolver behavior, source ranking, automatic source failover, KSPlayer/PlaybackKit, live wallpaper optimization, top-menu geometry, Sports direct-tune, and Connected Popup Background Artwork are otherwise preserved.

## Intended physical Apple TV test
1. Play a movie to ~25 minutes and exit.
2. Reopen with normal Play and verify resume.
3. Exit again, choose Find Links, select a different/higher-quality provider/source, and verify playback still starts at the same saved movie position.
4. Repeat with an exact TV episode.
5. Confirm the episode card shows its own remaining time before opening Find Links.
6. Let the episode progress further, exit, choose another link, and verify the newer timestamp follows the episode across sources.
