# v1151 Main Grid Background / Pulse / Live Wallpaper Audit

Base: packaged v1150 only. Backend: v674 unchanged.
Marketing version: 1.0.679. Build: 679.

## Main Grid Background
The previous Artwork/Hero Live TV themes explicitly returned `Color.black` from `LiveTVScreen.liveBackground(...)` whenever the guide was closed. v1151 removes that forced-black fallback. Appearance now has an independent `mainGridBackgroundPreset` used by Artwork/Hero themes when returning to the main TV grid.

18 base choices are included: Midnight Graphite, Pure Black, Deep Navy, Ocean Blue, Steel Blue, Slate, Charcoal, Forest, Deep Teal, Emerald Night, Royal Purple, Plum, Burgundy, Deep Red, Espresso, Warm Bronze, Soft Graphite, and Cinema Blue.

## Dynamic Live Wallpaper
A separate On/Off setting, `dynamicMainGridWallpaperEnabled`, controls a lightweight animated smoke/mist layer. It is excluded from the Full Guide and playback. Motion updates at 15 fps because the smoke movement is intentionally slow and does not need display-refresh cadence.

Wallpaper styles: Cinematic Smoke, Blue Nebula, Purple Haze, Emerald Mist, Ember Smoke, Aurora Fog.

## Focused Card Pulse
`focusedCardPulseAnimationEnabled` defaults Off. The setting gates only the existing slow repeating 1.5% breathing scale pulse. Search-style focus arrival/downward bounce and sideways presentation are unchanged.

## Preservation
The v1150 resume/autostart and scrubber functions are exact matches after this pass: `applyAutomaticResumeIfAvailable`, `scheduleAutomaticResumeAfterSurfaceStart`, `saveResumePositionIfNeeded`, `switchToKSPlayerEngine`, `seekAbsolute`, `startPlayerClock`, `scrubTimelineAndSeek`, and `commitTimelineScrubIfNeeded`.

PlaybackResumeCache, AutomaticSourceFailoverManager, PerTitlePlaybackMemory, UniversalCodecSupport, PlaybackKit core, Phase15FinalIntegration, CatalogStore, TrailerServiceManager, and SportsCenterViewModel are byte-identical to v1150. v1149 Sports direct tune and Connected Popup Background Artwork remain preserved.

## Validation
- Swift frontend parse: 54/54 files.
- Static/preservation contracts: 46/46 passed.
- Only five inherited files changed: DebridChannelsTVOSApp.swift, ReleaseCandidateSecurityManager.swift, project.yml, app Info.plist, Top Shelf Info.plist.
- GitHub Actions/Xcode and physical Apple TV remain authoritative for full tvOS compilation/runtime behavior.
