Debrid Channels tvOS v39 4K-fit 1+8 layout. Upload this whole ZIP to GitHub. Workflow builds a Signulous-friendly unsigned IPA using the v14-compatible packaging structure.
