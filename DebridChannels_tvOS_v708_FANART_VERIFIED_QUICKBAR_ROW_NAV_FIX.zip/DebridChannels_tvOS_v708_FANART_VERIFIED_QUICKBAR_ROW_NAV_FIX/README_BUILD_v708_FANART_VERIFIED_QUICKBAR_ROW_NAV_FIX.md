# v708 Fanart Verified Quickbar Row Nav Fix

- Verified and extended the actual catalog artwork path instead of adding a parallel path.
- Preserved Fanart.tv and TMDB keys from Settings: `fanartTvApiKey` and `tmdbApiKey`.
- Catalog metadata now carries `tmdbId`, `imdbId`, and `tvdbId` when providers expose those fields.
- Fanart resolution now uses explicit IDs, parsed TMDB IDs, IMDb/TMDB `/find`, then title/year TMDB search before calling Fanart.tv.
- Focused item logging reports selected artwork provider per hero/logo/poster.
- Movies/Shows quick panel shows one active row, next-row text only, Up/Down row movement, Left/Right item movement.
- Quick panel container is fully transparent with no outline; only the focused card has a ring.
