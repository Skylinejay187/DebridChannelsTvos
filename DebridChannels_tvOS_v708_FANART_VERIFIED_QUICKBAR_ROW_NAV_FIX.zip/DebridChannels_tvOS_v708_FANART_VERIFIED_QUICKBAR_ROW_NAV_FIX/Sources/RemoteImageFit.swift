import SwiftUI
import UIKit

/// Central artwork URL upgrader used before every image request.
/// v703: Premium decode path. Do not let SwiftUI/URLCache reuse low-res image entries,
/// and do not downsample artwork before the view displays it. TMDB gets /original/;
/// provider/Cinemeta/Stremio URLs stay intact so signed URLs and catalog art do not break.
enum PremiumArtworkURL {
    static func upgraded(_ input: String?) -> String? {
        guard var raw = input?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://") {
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }

        if raw.contains("image.tmdb.org/t/p/") {
            let tmdbSizes = ["/w45/", "/w92/", "/w154/", "/w185/", "/w300/", "/w342/", "/w500/", "/h632/", "/w780/", "/w1280/", "/original/"]
            for size in tmdbSizes where raw.contains(size) {
                raw = raw.replacingOccurrences(of: size, with: "/original/")
            }
            for size in ["w45", "w92", "w154", "w185", "w300", "w342", "w500", "h632", "w780", "w1280"] {
                raw = raw.replacingOccurrences(of: "/t/p/\(size)", with: "/t/p/original")
            }
        }

        return raw
    }

    static func url(_ input: String?) -> URL? {
        guard let raw = upgraded(input), !raw.isEmpty else { return nil }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }
}

@MainActor
final class PremiumRemoteImageLoader: ObservableObject {
    @Published var image: UIImage?
    @Published var failed = false

    private static let memoryCache = NSCache<NSURL, UIImage>()
    private var task: URLSessionDataTask?
    private var currentURL: URL?

    func load(_ url: URL?) {
        guard let url else {
            cancel()
            image = nil
            failed = false
            currentURL = nil
            return
        }
        if currentURL == url, image != nil || failed { return }
        currentURL = url
        failed = false

        if let cached = Self.memoryCache.object(forKey: url as NSURL) {
            image = cached
            return
        }

        image = nil
        task?.cancel()

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 24
        request.setValue("image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS-PremiumArtwork/1.0", forHTTPHeaderField: "User-Agent")

        task = URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard error == nil, let data, !data.isEmpty else {
                DispatchQueue.main.async { self?.failed = true }
                return
            }
            // UIImage(data:) preserves the source bitmap instead of requesting a thumbnail-sized decode.
            guard let decoded = UIImage(data: data, scale: UIScreen.main.scale) ?? UIImage(data: data) else {
                DispatchQueue.main.async { self?.failed = true }
                return
            }
            DispatchQueue.main.async {
                guard self?.currentURL == url else { return }
                Self.memoryCache.setObject(decoded, forKey: url as NSURL)
                self?.image = decoded
                self?.failed = false
            }
        }
        task?.resume()
    }

    func cancel() {
        task?.cancel()
        task = nil
    }

    deinit { task?.cancel() }
}

struct RemoteImageFit: View {
    enum Mode { case fill, fit }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true

    @StateObject private var loader = PremiumRemoteImageLoader()

    private var resolvedURL: URL? {
        PremiumArtworkURL.url(url)
    }

    var body: some View {
        Group {
            if let image = loader.image {
                Image(uiImage: image)
                    .resizable()
                    .interpolation(.high)
                    .antialiased(true)
                    .aspectRatio(contentMode: mode == .fill ? .fill : .fit)
            } else {
                placeholder(showSpinner: !loader.failed && resolvedURL != nil)
            }
        }
        .clipped()
        .onAppear { loader.load(resolvedURL) }
        .onChange(of: resolvedURL) { newValue in loader.load(newValue) }
        .onDisappear { loader.cancel() }
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            if showPlaceholder {
                LinearGradient(colors: [.black.opacity(0.92), .gray.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                if showSpinner {
                    ProgressView().scaleEffect(0.78).opacity(0.30)
                }
            } else {
                Color.clear
            }
        }
    }
}
