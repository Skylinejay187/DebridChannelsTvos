Debrid Channels tvOS v593 — Smaller Comic Trailer Popup

Base: v592 trailer no-auto-replay build.

Scope:
- Trailer popup presentation only.
- Live TV, guide, sports, VOD playback, memberships, source intelligence, backup/restore untouched.

Changes:
- Trailer popup reduced about 30% from the earlier oversized card.
- Trailer presentation now uses a movie/comic speech-bubble card shape.
- Video remains inside the popup card and keeps the AVPlayer smooth path.
- Halftone comic accent overlay added lightly without blocking the video.
- YouTube auto-open block preserved.
