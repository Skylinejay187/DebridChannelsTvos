Debrid Channels tvOS v594 — Trailer Comic Bubble Tail Anchor

Scope:
- Trailer popup visual polish only.
- Keeps v593 smaller comic/movie trailer popup size.
- Moves comic bubble tail to the lower-left side so the trailer popup appears to come out of the selected poster/card area.
- Keeps trailer video fitted inside the bubble body.
- No backend change.
- Live TV, guide, sports, playback engines outside trailer popup, membership, backup/restore, and source systems untouched.

Notes:
- This build preserves the v591/v592/v593 AVPlayer trailer path and YouTube auto-open block.
- Xcode/tvOS compilation cannot be run inside this Linux sandbox.
