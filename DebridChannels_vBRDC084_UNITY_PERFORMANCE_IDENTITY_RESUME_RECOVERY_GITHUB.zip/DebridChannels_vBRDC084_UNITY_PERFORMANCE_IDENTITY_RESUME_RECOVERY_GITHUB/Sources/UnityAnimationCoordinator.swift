import Foundation
import Combine

/// vBRDC080 — Code Name: UNITY
///
/// Process-wide animation arbitration for Debrid Channels. Animated surfaces no longer
/// independently decide when to pause/restart. Each visual system asks for a named feature
/// permit and the coordinator applies one compatibility policy across the app.
///
/// Important policy:
/// - Source Intelligence *searching* is non-exclusive. Focus pulse + focused-card preview
///   remain alive and never restart just because the links panel opens or updates.
/// - Opening an actual source, resolving the Play action, trailer playback, or full-screen
///   playback is exclusive. Auxiliary/ambient animation lanes yield before decoder handoff.
/// - Global Search, Settings, Guide, and inactive scene ownership prevent hidden catalog
///   animation work, but do not mutate the user's saved animation preferences.
final class UnityAnimationCoordinator: ObservableObject {
    static let shared = UnityAnimationCoordinator()

    enum Feature: String, CaseIterable {
        case dynamicWallpaper
        case catalogFocusArrival
        case catalogPulse
        case catalogPreview
        case catalogRowMotion
        case detailTransition
        case detailConnector
        case sourceIntelligenceMotion
        case liveTVMotion
        case guideMotion
        case sportsMotion
        case tickerMotion
        case overlayChrome
        case playbackChrome
        case alertMotion
    }

    struct GlobalContext: Equatable {
        var sceneActive: Bool = true
        var globalSearchActive: Bool = false
        var settingsActive: Bool = false
        var detailActive: Bool = false
        var fullScreenPlaybackActive: Bool = false
    }

    @Published private(set) var revision: UInt64 = 0
    private(set) var context = GlobalContext()

    private(set) var sourceSearchActive: Bool = false
    private(set) var sourceOpeningActive: Bool = false
    private(set) var trailerExclusiveActive: Bool = false
    private(set) var guideActive: Bool = false
    private(set) var surfaceHandoffActive: Bool = false

    private init() {}

    func synchronizeGlobal(
        sceneActive: Bool,
        globalSearchActive: Bool,
        settingsActive: Bool,
        detailActive: Bool,
        fullScreenPlaybackActive: Bool
    ) {
        let next = GlobalContext(
            sceneActive: sceneActive,
            globalSearchActive: globalSearchActive,
            settingsActive: settingsActive,
            detailActive: detailActive,
            fullScreenPlaybackActive: fullScreenPlaybackActive
        )
        guard next != context else { return }
        context = next
        bump()
    }

    /// Source Intelligence search is deliberately distinct from source opening.
    /// Searching is compatible with catalog pulse/preview; opening a real stream is not.
    func setSourceIntelligence(searching: Bool, opening: Bool) {
        guard searching != sourceSearchActive || opening != sourceOpeningActive else { return }
        sourceSearchActive = searching
        sourceOpeningActive = opening
        bump()
    }

    func setTrailerExclusiveActive(_ active: Bool) {
        guard active != trailerExclusiveActive else { return }
        trailerExclusiveActive = active
        bump()
    }

    func setGuideActive(_ active: Bool) {
        guard active != guideActive else { return }
        guideActive = active
        bump()
    }

    /// vBRDC081: cross-surface navigation receives an exclusive, very short handoff window.
    /// This prevents the outgoing and incoming heavy animation trees from compositing at once.
    /// It does not alter any saved animation setting; permits resume after focus ownership settles.
    func setSurfaceHandoffActive(_ active: Bool) {
        guard active != surfaceHandoffActive else { return }
        surfaceHandoffActive = active
        bump()
    }

    func resetTransientOwnership() {
        let changed = sourceSearchActive || sourceOpeningActive || trailerExclusiveActive || guideActive || surfaceHandoffActive
        sourceSearchActive = false
        sourceOpeningActive = false
        trailerExclusiveActive = false
        guideActive = false
        surfaceHandoffActive = false
        if changed { bump() }
    }

    func allows(_ feature: Feature) -> Bool {
        guard context.sceneActive else { return false }

        // vBRDC081: a tab/surface handoff gets one exclusive compositor/focus window.
        // Alerts and static overlay chrome may remain, but perpetual/card/video-adjacent
        // animation cannot run simultaneously in outgoing and incoming trees.
        if surfaceHandoffActive {
            return feature == .overlayChrome || feature == .alertMotion
        }

        // Full-screen playback owns frame/decoder budget. Only player chrome and the
        // already-approved alert lane may animate on top of it.
        if context.fullScreenPlaybackActive {
            return feature == .playbackChrome || feature == .alertMotion
        }

        // Built-in full trailer owns the same decoder lane before/while it is mounted.
        if trailerExclusiveActive {
            return feature == .playbackChrome || feature == .overlayChrome || feature == .alertMotion
        }

        // Selecting/opening a real link is a decoder handoff. Stop ambient/auxiliary
        // movement before playback begins, not while the user is merely searching.
        if sourceOpeningActive {
            return feature == .overlayChrome || feature == .alertMotion
        }

        switch feature {
        case .dynamicWallpaper:
            return !context.globalSearchActive
                && !context.settingsActive
                && !context.detailActive
                && !guideActive
                && !sourceSearchActive

        case .catalogPreview, .catalogPulse:
            // The core vBRDC080 compatibility rule: detail + Source Intelligence search
            // can coexist with the exact already-running focused preview/pulse.
            return !context.globalSearchActive
                && !context.settingsActive
                && !guideActive

        case .catalogFocusArrival, .catalogRowMotion:
            // Navigation motion is catalog-local. Details may remain mounted over the
            // catalog but no hidden row transition should be started from another surface.
            return !context.globalSearchActive
                && !context.settingsActive
                && !guideActive
                && !context.detailActive

        case .detailTransition, .detailConnector:
            return context.detailActive && !context.globalSearchActive

        case .sourceIntelligenceMotion:
            return context.detailActive && !context.globalSearchActive

        case .liveTVMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive

        case .guideMotion:
            return guideActive && !context.globalSearchActive && !context.settingsActive

        case .sportsMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive

        case .tickerMotion:
            return !context.globalSearchActive && !context.settingsActive && !context.detailActive && !guideActive

        case .overlayChrome:
            return true

        case .playbackChrome:
            return false

        case .alertMotion:
            return true
        }
    }

    /// Stable diagnostic string used by tests/logs without exposing internal view state.
    var diagnosticSummary: String {
        "scene=\(context.sceneActive ? "active" : "inactive") search=\(context.globalSearchActive) detail=\(context.detailActive) sourceSearch=\(sourceSearchActive) sourceOpening=\(sourceOpeningActive) trailer=\(trailerExclusiveActive) playback=\(context.fullScreenPlaybackActive) guide=\(guideActive) handoff=\(surfaceHandoffActive)"
    }

    private func bump() {
        revision &+= 1
        print("[UNITY Animation] revision=\(revision) \(diagnosticSummary)")
    }
}
