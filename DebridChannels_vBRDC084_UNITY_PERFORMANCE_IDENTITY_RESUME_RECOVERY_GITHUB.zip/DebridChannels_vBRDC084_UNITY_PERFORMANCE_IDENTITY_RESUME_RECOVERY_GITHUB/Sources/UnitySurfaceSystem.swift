import Foundation

// vBRDC059 — Code Name: Unity
//
// Unity is the app's presentation contract, not a visual theme. Live TV is the
// persistent root canvas for the connected browsing branches. Home, Movies,
// Shows, and Sports are branches that temporarily own focus/content while the
// same Live TV surface remains mounted beneath them. Theme selection may change
// appearance, but it must never change which navigation tree owns the surface.
//
// Full-screen playback, Search, Settings, Membership, and Favorites retain their
// dedicated visual roots, but as of vBRDC081 they are no longer outside UNITY lifecycle
// ownership: UnitySurfaceLifecycleCoordinator arbitrates entry/exit resource handoff while
// this type continues to describe only which visual root remains mounted.
enum UnitySurfaceSystem {
    static let codeName = "Unity"
    static let displayCodeName = "UNITY"

    enum SurfaceRole: String {
        case liveRoot
        case catalogBranch
        case sportsBranch
        case dedicatedSurface
    }

    static func role(for tab: AppTab) -> SurfaceRole {
        switch tab {
        case .live:
            return .liveRoot
        case .home, .movies, .shows:
            return .catalogBranch
        case .sports:
            return .sportsBranch
        case .favorites, .membership, .settings:
            return .dedicatedSurface
        }
    }

    static func keepsLiveTVRootMounted(for tab: AppTab) -> Bool {
        switch role(for: tab) {
        case .liveRoot, .catalogBranch, .sportsBranch:
            return true
        case .dedicatedSurface:
            return false
        }
    }

    static func catalogBranchActive(for tab: AppTab) -> Bool {
        role(for: tab) == .catalogBranch
    }

    static func quickPanelBranchActive(for tab: AppTab) -> Bool {
        switch role(for: tab) {
        case .catalogBranch, .sportsBranch:
            return true
        case .liveRoot, .dedicatedSurface:
            return false
        }
    }

    static func backDestination(from tab: AppTab) -> AppTab {
        switch role(for: tab) {
        case .catalogBranch, .sportsBranch:
            return .live
        case .liveRoot, .dedicatedSurface:
            return tab
        }
    }
}
