# Debrid Channels tvOS v24

Ready-to-upload GitHub repo ZIP. The workflow extracts the embedded source ZIP and builds an unsigned tvOS IPA artifact.

## v24 fixes
- Adds missing RemoteImageFit.swift to fix v23 compile failure.
- Preserves row scroll/focus behavior.
- Preserves image fit/card crop fixes.
- Preserves settings reachability.
- Keeps RD/Torbox unwired for now.
