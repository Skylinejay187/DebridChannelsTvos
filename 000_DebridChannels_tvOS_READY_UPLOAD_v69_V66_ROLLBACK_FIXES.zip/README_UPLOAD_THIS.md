Debrid Channels tvOS v69 - V66 Rollback + Approved Fixes

Upload this repository package contents to GitHub and run the included universal tvOS device-build workflow.

Expected Settings marker:
Build v69 V66 ROLLBACK + FIXES

Notes:
- Based on the stable v66 renderer/motion base.
- Adds visible smoke, 3-second preview trigger foundation, focused artwork background, poster logo pulse reset, right-side poster motion, and multi-JSON add/clear behavior.
- Detail page remains sharp/clean.
- Uses device SDK appletvos, not simulator.
