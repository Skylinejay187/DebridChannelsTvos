# Debrid Channels tvOS v50 TRUE SPLIT ACTIVE

Upload this whole repository ZIP to GitHub. Run the included workflow.

Artifact IPA: `DebridChannelsTVOS_v50_UPLOAD_THIS_IPA.ipa`

Build marker: Settings shows `Build v50 TRUE SPLIT ACTIVE`, and the log marker is `DEBRID_CHANNELS_TVOS_BUILD_V50_TRUE_SPLIT_ACTIVE`.

Packaging preserves the v14 Signulous-compatible structure.
