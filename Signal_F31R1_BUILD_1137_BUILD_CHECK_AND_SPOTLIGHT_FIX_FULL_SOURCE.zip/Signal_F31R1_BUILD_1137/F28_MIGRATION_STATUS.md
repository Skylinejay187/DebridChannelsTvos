# Signal F28 1134 migration verification (2026-10-20)

Base: F26; engine target: upstream AetherEngine tag 7.44.0.

## Implemented and checked in this source snapshot
- Build-prep fetch pins the 7.44.0 tag and stages source before swapping vendor trees.
- Signal decoded PCM gain port is inserted into upstream AudioDecoder and SoftwarePlaybackHost before swapping.
- Active software-decoder gain is stored on the host and inherited by a replacement audio decoder on track changes.
- Removed the bridge’s 900 ms delayed gain-reapply task after audio-track selection; gain now reapplies synchronously and persists on decoder replacement.
- Prior vendor tree retained in .build-cache/aether-f28-previous; reruns do not silently clobber backup.
- AetherPlaybackKit manifest uses Swift tools 6.1, tvOS 18.
- `bash -n Scripts/fetch_aether_f28_744.sh` passes.
- `swiftc -frontend -parse` for both bridge source files passes.
- `swift package dump-package` for Vendor/AetherPlaybackKit passes.

## NOT VERIFIED / NOT RELEASE-READY
- Environment lacks Apple Xcode/tvOS SDK; full xcodebuild not run.
- Vendor/AetherEngine includes placeholder, not the upstream full checkout.
- 7.44.0 bridge compilation/linkage, TV playback, gain continuity, background video restoration, Live TV exit lag, FastZap, scrub thumbnails, EPG performance, and Up Next handoff are not validated here.
- This snapshot must not be represented as a complete F28 GitHub-ready build.

## Additional installer verification (current stage)
- Registered rollback/cleanup trap before the network checkout and PCM patching, not only before the vendor swap.
- Tested a failed network checkout in an isolated scratch tree: prior engine sentinel preserved; partial clone directory removed.
- Preflight additionally requires Swift tools 6.1 manifest and both bridge source copies.
- `bash -n` installer check and Python preflight syntax check passed; unpatched local placeholder correctly rejected.
