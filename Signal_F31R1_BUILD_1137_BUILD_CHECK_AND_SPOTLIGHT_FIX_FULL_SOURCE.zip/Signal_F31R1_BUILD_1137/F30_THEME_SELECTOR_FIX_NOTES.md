# F30 selector compile repair

Explicitly types the theme list and closure elements to prevent Swift array inference failures. Based on the uploaded F30 typed-list source, not the mismatched theme-case names in the supplied build logs. Does not add F31 layouts or replace the old theme engine. Full Xcode build still required.
