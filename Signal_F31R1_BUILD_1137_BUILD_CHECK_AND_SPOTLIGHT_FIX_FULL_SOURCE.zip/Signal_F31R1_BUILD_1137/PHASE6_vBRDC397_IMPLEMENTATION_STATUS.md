# vBRDC397 Phase 6 — source implementation status

Base: vBRDC397 version-synchronized package, incorporating the v396 VOD catalog Hero 2 fix.

Implemented in this package:
- Continue Watching shelves now deduplicate entries by stable movie/show identity at the final row publication boundary, keeping the first (provider newest-first) episode and its season/episode metadata.
- Resume hide identity normalization accepts spaced episode labels (S01 E02, 01 x 02), preventing a removed show's poster from returning under an episode-suffixed title.
- Existing Siri Remote long-press action dialog, local-only Continue Watching removal, explicit Trakt history deletion confirmation, and Trakt external-ID safety guard retained.
- App / Top Shelf version metadata retained at vBRDC397, 1.0.1110 / build 1110.

Validation: Swift frontend syntax parse of modified sources succeeded. No macOS Xcode build or tvOS device verification was possible here.

Not complete or verified: comprehensive Resume/Trakt/history synchronization correctness, cloud deletion effects across devices, all catalog interactions, regression/device testing. This is not a finished Phase 6 release.
