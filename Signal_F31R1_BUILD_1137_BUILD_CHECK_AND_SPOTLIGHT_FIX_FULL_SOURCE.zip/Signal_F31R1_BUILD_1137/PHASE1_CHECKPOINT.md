# Signal F29 Phase 1 — checkpoint A

Implemented in this checkpoint:
- Remote seek-back and seek-forward now set the same preview target used by manual timeline scrubbing, allowing the existing remote Aether thumbnail notification pipeline to run.
- Spotlight Settings theme cycling now selects the next theme and switches to Single Panel instead of silently changing the enabled-theme list while displaying the old panel.
- Single Panel selection is no longer silently replaced by Trakt Pulse when its provider content is unavailable; unavailable data may still result in an empty panel.
- Preserves previous scrub-follow thumbnail and VOD information fade changes.

Still unresolved (NOT claimed fixed):
- Continuous VOD cache-progress updates: the bridge already polls Aether clock at 2Hz, but actual bufferedPosition can remain stale; needs engine-side telemetry investigation, not synthetic progress.
- Remote thumbnail availability outside cached video remains dependent on Aether's extraction/seekable source support.
- Black-screen foreground recovery, Live TV startup/FastZap, and broader performance phases.

Validation: Swift syntax parse and ZIP integrity only; no macOS/Xcode compile or Apple TV runtime verification.
Branch: signal/f28-test only. Do not merge main.
