# Phase 3 Pass 1 — Duplicate Live TV teardown guard

Source: Phase 2 Pass 4 thumbnail rollback checkpoint.

## Implemented
- Avoid repeating `teardownPlayer()` in the Live TV `onDisappear` callback when `requestPlayerDismissal()` has already completed ordered teardown.
- Preserve transient Live TV cleanup and memory-audit marker.
- Preserve all prior VOD, thumbnail, FastZap, backup confirmation and branding behavior.

## Not yet verified or fixed
- Accumulating Live TV exit lag, background return black screen, retained Aether render hosts, startup/FastZap performance.
- This is a narrowly scoped lifecycle correction, not the complete Phase 3 repair.

Validation: Swift frontend parse and bridge parity; no Xcode/device execution.
