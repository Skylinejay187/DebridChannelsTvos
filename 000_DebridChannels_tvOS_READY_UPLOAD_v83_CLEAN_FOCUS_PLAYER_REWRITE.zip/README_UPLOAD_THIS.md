# Debrid Channels tvOS v83 — Clean Focus + Player Rewrite

Upload this ZIP to a new GitHub repository or replace the previous ZIP in the repo, then run the included GitHub Actions workflow.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V83_CLEAN_FOCUS_PLAYER_REWRITE`

What changed in v83:
- Preserved the approved v73 Home layout and v73 media information geometry.
- Deleted/replaced the heavy old animated background pass that was causing lag.
- Added a lighter cinematic full-screen background effect with the same style but fewer animated layers.
- Removed the parent focus trap that was stealing DPAD movement away from media-info children.
- Expanded focus/click routing for Play, Trailer, Find Links, Close, Search Links, stream chips, More Like This cards, and the persistent top menu.
- Added visible focus styling to stream-link chips and More Like This cards.
- Kept the custom AVPlayerLayer VOD surface and Debrid Channels overlay path.
- Broadened direct stream recognition for common direct HTTP/HLS file paths.

Codec note:
The player is built around a custom AVPlayerLayer surface so Apple’s stock overlay does not appear. tvOS codec support is still limited by Apple’s native decoder unless a future libVLC/FFmpeg-style player core is added. This build keeps the player core modular so that a VLC/libVLC core can be added later without redesigning the v73 UI.
