# Debrid Channels tvOS v621

Base: v620_RESUME_SOURCE_LIVE_DIAGNOSTICS

Scoped fixes:
- Search result cards no longer expand outside the search grid slot.
- TMDB/Cinemeta Search Details now upgrades to resolver-ready metadata before Source Intelligence scans configured Stremio addons.
- Last successful VOD source/link is started immediately when Play is pressed, restoring fast external player handoff and preserving smaller/source choices.
- Added foreground tvOS notification delegate so Test/New Episode banners can show while app is open.
- Added app launch/resume followed-show alert scanner using loaded catalog/Stremio episode metadata and duplicate-alert suppression.
- Added small Details Stage polish: +5% backdrop visibility and slightly higher TV show layout.

Untouched:
- VOD display matching path.
- Membership.
- Sports.
- Trailer backend.
- Backup/restore.
