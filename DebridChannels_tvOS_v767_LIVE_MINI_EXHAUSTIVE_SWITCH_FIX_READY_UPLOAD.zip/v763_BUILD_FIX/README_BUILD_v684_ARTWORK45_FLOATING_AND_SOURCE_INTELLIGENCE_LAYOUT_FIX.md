# Debrid Channels tvOS v684 — Artwork 4/5 Floating + Source Intelligence Layout Fix

Base: v683 Artwork 5 Floating Quick Panel Theme Build Fix

Changes:
- Artwork 4 Hero 2 now also uses a fully transparent/floating Movies/Shows/Streaming Catalog quick panel.
- Artwork 4 Hero 2 and Artwork 5 Floating now share the same subject/object pop layer math:
  - same backdrop opacity/saturation/contrast family
  - same hero-depth layer path
  - two extra subtle subject/object pop layers
- Artwork 5 Floating remains a transparent/floating quick-panel theme.
- Source Intelligence panel height increased and row height tightened so the 5th highlighted link stays inside the panel.
- Source Intelligence right-side art changed to landscape/fit mode where landscape artwork is available; poster fallback no longer zoom-crops.
- Internal Player settings reminder is now more visible and explicitly tells users to enable Apple TV Match Dynamic Range and Match Frame Rate.
- Preserved v683 build fix, v682 AVPlayer default VOD, and v681 seek fix.

Verification:
- swiftc -parse passed across Sources/*.swift.
