# Debrid Channels tvOS v573 — Cast Fit, Wordmark Color/Layout, Exact Episode Links

## Scope
- Updated global top-left wordmark treatment to match the requested stacked DEBRID / CHANNELS layout more closely.
- CHANNELS now uses an orange-to-red treatment.
- Movie popup cast rail now uses compact fitted cards so the cast row stays inside the movie popup instead of clipping at the right edge.
- TV episode card click stream searches now remain episode-exact.

## Episode source fix
- Episode rows no longer fall back to the parent show id when building Stremio stream IDs.
- Episode stream results are filtered when returned titles clearly identify a different S/E episode.
- Source Intelligence itself is untouched; only the item/id passed into it and result filtering were tightened.

## Preserved
- Source Intelligence layout and focus behavior.
- Trailer flow.
- Playback behavior.
- TV show episode rail visuals.
- Top poster metadata bar.
- Hero popup layout.
