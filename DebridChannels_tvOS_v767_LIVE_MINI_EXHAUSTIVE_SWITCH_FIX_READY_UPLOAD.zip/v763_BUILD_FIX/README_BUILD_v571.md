# Debrid Channels tvOS v571 HERO POPUP FINAL POLISH

Scope locked to the approved final Hero Popup polish pass.

Changes:
- Removed the visible popup outline/stroke so the hero sheet blends into the background rows/channels.
- Flattened Play/Trailer/YouTube/Find Links/Close chips to a single-surface style with no inner capsule/inline outline.
- Flattened utility chips to avoid double outline stacking.
- TV show popup no longer shows Find Links or Episodes action chips; episode cards are now the direct route into Source Intelligence.
- Movie popup still keeps Find Links.
- TV show episode rail fit math adjusted inside the existing expanded popup height so episode preview cards are not clipped at the bottom.
- Top bar poster now shows continue-watching remaining time/progress when resume data exists.
- Source Intelligence, trailers, playback, top metadata metrics, episode still images, and Live TV behavior preserved.

Verification:
- Swift parse check passed across Sources/*.swift.
