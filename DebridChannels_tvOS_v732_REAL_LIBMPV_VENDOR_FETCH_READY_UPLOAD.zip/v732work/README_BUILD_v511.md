# Debrid Channels tvOS v511 — Compact Source Search + Theater Polish Next Phase

- Replaced the Search Links text chip in popup/source rows with compact search + link icons.
- Kept range/status text under the compact chip so large result windows remain understandable.
- Preserved v510 critic score cards, v509 theater visuals, playback, search, and settings behavior.
- Next phase target: Theater Mode v3 with cleaner poster-progress stack, source-quality rail, and Media DNA grouping.
