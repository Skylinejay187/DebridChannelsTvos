Debrid Channels tvOS v584

Scope: membership timing/tier entitlement polish only.

Changes:
- Changed local fresh-install trial bootstrap from temporary 10 minutes to production 24 hours.
- Updated trial countdown/status wording to 24-hour trial.
- Trial still survives app restarts and still locks out when expired.
- Paid Supporter/Continue Support remains one-year entitlement through backend expiresAt.
- Lifetime/Full Unlock clears the local timer and has no expiration timer.
- Restore Membership preserves device-limit handling and device-manager path.

Device tiers confirmed in backend:
- Trial: 1 device.
- Supporter / Continue Support: 2 devices.
- Lifetime / Full Unlock: 3 devices.
- Owner/Admin: configurable owner device limit.

Preserved: Live TV, guide, sports, popup redesign, Source Intelligence, backups, trailers, playback.
