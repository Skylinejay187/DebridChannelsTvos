# v723 AVPlayer Auto KSPlayer Fallback Single Row Chips

Base: latest working ZIP, v722_FRESH_AVPLAYER_VOD_OVERLAY_REBUILD_AND_ARTWORK_FLASH_FIX.

Changes:
- VOD remains AVPlayer by default.
- AVPlayer unsupported container/codec preparation failures auto-fallback once to KSPlayer.
- Fallback preserves the selected stream URL and current/resume time.
- Non-blocking toast: `Switching player for compatibility...`
- Diagnostics report AVPlayer before fallback, KSPlayer after fallback, and fallback reason `AVPlayer unsupported container/codec`.
- KSPlayer seek path continues to receive absolute seek commands from remote skip and timeline scrub.
- VOD overlay chips are rebuilt into one horizontal row: Resume, Back 30, Play/Pause, Forward 30, AVPlayer, KSPlayer, Audio, Subtitles, External Player, Zoom, Settings, plus MPV when compiled.
- Up/down focus zones are info/cast, timeline, and chip row.
- Resume save/clear behavior remains: save every 5 seconds, clear after 95% watched.
- MPV foundation added under compile guards: `PlayerEngine.mpv`, MPV wrapper detection, settings placeholder when available, and diagnostics labels for `libmpv/ffmpeg` and `libass`.

Preserved:
- Media info, cast wall, poster.
- v718 quick panel focus ownership.
- v702 row geometry.
- Catalog loading stability.
- Live TV focused progress.
- Trailers, membership, backend, and sports.

Local verification:
- Static checks confirm old split-row overlay symbols and stale KSPlayer-primary diagnostics are not present in active packaged source.
- Swift compile was not run because the local environment does not have the Swift toolchain installed.
