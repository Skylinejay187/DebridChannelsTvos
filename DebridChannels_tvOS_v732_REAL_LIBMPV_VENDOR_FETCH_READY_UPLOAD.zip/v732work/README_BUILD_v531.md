# Debrid Channels tvOS v531 — Popup Backdrop Balance Polish

Base: v530 Live TV overlay logo-only build.

Changes:
- Increased popup backdrop artwork visibility slightly without letting it overpower text.
- Tuned backdrop opacity, saturation, contrast, and blur for a clearer cinematic background.
- Added layered side/bottom vignettes to protect cast, metadata, action chips, and source rows.
- Kept Dynamic Information Bar compact.
- Preserved playback/search/settings/Home Grid themes/Live TV themes behavior.
