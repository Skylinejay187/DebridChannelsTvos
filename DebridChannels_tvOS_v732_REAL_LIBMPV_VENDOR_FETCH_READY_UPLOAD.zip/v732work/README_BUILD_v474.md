# Debrid Channels tvOS v474

- Live TV missing program/Gracenote artwork now tries backend provider artwork first using TVDB/Fanart/TMDB provider keys.
- If provider artwork is unavailable, Live TV falls back to the channel/provider icon as poster, then generated card.
- Trailer polling keeps prefer4k=true instead of downgrading cache polling to 1080p fast mode.
- Preserves v470+ search fixes, v472 popup/about polish, and v473 fallback behavior.
