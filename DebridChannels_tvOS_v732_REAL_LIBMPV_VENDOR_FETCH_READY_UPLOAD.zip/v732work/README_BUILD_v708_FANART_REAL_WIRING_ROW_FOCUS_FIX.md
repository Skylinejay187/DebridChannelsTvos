# v708_FANART_REAL_WIRING_ROW_FOCUS_FIX

This build was created from the current uploaded v707 ZIP only.

Main fixes:
- Real Fanart.tv lookup wiring for catalog artwork, including catalog IDs and title/year fallback.
- Fanart-first artwork mapping for hero/background, logo, and poster.
- Focused-item debug logging for selected artwork provider.
- Movies/Shows quick panel row navigation: Up/Down between rows, Left/Right within the active row.
- Transparent quick panel container with card-only focus ring.
- Removed orange advisory accent line.

Verification performed in source:
- Fanart.tv API request path exists in `Sources/CatalogStore.swift`.
- Catalog metadata IDs are preserved into `MediaItem`.
- Selected artwork provider can report `Fanart` when the focused URL is from Fanart.tv.
- Quick panel move handlers keep focus inside catalog rows and do not clamp to the first row.

Compile note:
- No Swift/Xcode toolchain is available in this container, so source-level verification and packaging were completed here, but a local tvOS compile could not be run.
