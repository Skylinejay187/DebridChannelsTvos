# Debrid Channels tvOS v693 — Build-Stable VOD Focus/Seek Fix

Base: v692 Compile-Safe Live Progress + VOD Seek Fix

Fixes:
- Removed the Live TV grid progress overlay added in v690/v691/v692 because Release/WMO tvOS builds kept failing without a clear Swift diagnostic.
- Kept the rest of the recent fixes:
  - v689 tvOS seek/overlay mitigation
  - v688 MediaFusion/HDMI/advisory fixes
  - VOD cache off by default
  - Source Intelligence provider additions
- Fixed VOD chips/focus:
  - Timeline is not part of horizontal chip focus order.
  - Timeline does not bind as a SwiftUI focusable control.
  - Other VOD chips remain selectable.
- Fixed VOD timeline seek behavior:
  - Up/Down enters timeline scrub mode.
  - Left/Right scrubs while active.
  - Select commits the seek.
  - After seek, focus returns to Play/Pause so the rest of the chips are usable.

Note:
- Live TV card progress is removed from this build for stability. It should be re-attempted later as a separate lightweight drawing layer after a clean Release build is confirmed.

Verification:
- swiftc -parse passed across Sources/*.swift.
