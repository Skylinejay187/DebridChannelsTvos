# Debrid Channels tvOS v559 — Real Wiring Pass for v558

This pass focuses on actual reachable controls and wiring instead of placeholder/foundation claims.

## Popup wiring
- Popup Favorite and Follow Show are now part of the manual DPAD focus path.
- DOWN from the primary action row reaches Add Favorite / Follow Show.
- LEFT/RIGHT moves between Add Favorite and Follow Show.
- SELECT triggers the active action.
- Touch/click still works on those chips.

## Sports wiring preserved
- Sports M3U cards preserve stream URLs.
- Sports event cards keep Watch Live / Open Highlight / More Info action states.
- Ticker remains expanded beyond NFL with ESPN/TheSportsDB feed paths and all-sports fallbacks.

## Protected areas
- Trailer resolver path untouched.
- Cast/link resolver path untouched.
- Xtream/M3U sports auto-routing remains disabled/backlogged.
