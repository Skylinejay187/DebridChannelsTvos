# DebridChannels tvOS v670

Scope: Restore VOD Cast Wall metadata binding while preserving all v669 Source Intelligence and real-track fixes.

Changes:
- VOD playback item creation now preserves already-loaded selected-detail cast metadata before playback starts.
- Cast Wall keeps real cast member ordering from details metadata.
- Cast Wall uses real cast names and profile image URLs when available.
- Initials remain fallback only when a cast member has no profile image URL.
- Cast Wall filters blank names without changing playback surface, player item, overlay routing, Live TV, trailers, or Source Intelligence link logic.

Preserved from v669:
- Source Intelligence "Opening stream..." loading state.
- Duplicate source activation guard while loading.
- Real AVAsset audio/subtitle track probing and VOD overlay track menus.
- Subtitles Off support.
- Settings reminder for Apple TV Match Dynamic Range and Match Frame Rate.
