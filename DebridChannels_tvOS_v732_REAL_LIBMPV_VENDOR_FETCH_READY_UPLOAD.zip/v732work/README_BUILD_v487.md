# Debrid Channels tvOS v487

Final hero/popup polish pass:
- Hero banner now uses cinematic left/bottom fade instead of global brightening.
- Backdrop is slightly zoomed out and lowered while still filling the banner.
- Recommendation row shows one more card and uses equal card math across the popup width.
- Related poster cards are standardized with cleaner rounding.
- Related poster focus uses a blue ring/glow.
- Popup typography hierarchy refined for metadata, description, and cast labels.
- No playback, trailer, Live TV, guide, onboarding, membership, backend, or search changes.
