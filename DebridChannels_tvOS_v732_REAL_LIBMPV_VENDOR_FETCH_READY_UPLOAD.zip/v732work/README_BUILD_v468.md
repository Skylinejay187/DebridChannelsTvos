# Debrid Channels tvOS v468

Focused popup details polish pass.

Changes:
- Added movie/show popup Cast and Director credit display when metadata providers expose credits.
- Hydrates selected detail credits from Stremio/Cinemeta-style /meta endpoints when needed.
- Removed the visible "More Like This" section title text.
- Removed text overlays from the More Like This poster cards for a cleaner poster-only row.
- Made More Like This posters smaller/cleaner to create room for credits without crowding the popup.

Preserved:
- v467 catalog final sort / Cinemeta fallback behavior.
- v464-v466 search card rebuild and catalog priority controls.
- Playback, link resolver, onboarding, membership, devices, Live TV, guide, favorites, Cloudflare, and backend behavior.
