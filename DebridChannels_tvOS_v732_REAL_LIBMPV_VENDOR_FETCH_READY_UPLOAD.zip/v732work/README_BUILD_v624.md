# Debrid Channels tvOS v624

Base: DebridChannels_tvOS_v623_TMDB_EXTERNAL_SEARCH_FIX_READY_UPLOAD
Backend target: v1.8.15.76

Scope locked to the v624 continuation reference.

Changes:
- Live TV diagnostics expanded with codec hints, audio channel hints, sample-rate hints, scan type, and A/V drift estimate fields.
- CBS/TVE affiliate detection added to the Live TV path only, surfacing CBS remux timing guard status and CBS/VLC timing guard messaging without touching VOD.
- Advisory badge redesigned as a floating glass capsule with no outline and no warning icon while preserving dynamic advisory/rating text.
- Global Search restored to all catalog sources: TMDB, local rows, Cinemeta, configured Stremio catalogs, and embedded provider catalogs.
- Catalog-addon search now rejects endpoint responses that do not match the typed query, preventing full catalog dumping.
- TMDB search/default/fallback/franchise poster and backdrop URLs now request original quality assets where TMDB paths are available.
- Franchise row keeps logo-first behavior; TMDB movie logo URLs now use original quality assets when available.

Preserved / not modified:
- Membership, owner unlock, trial logic.
- Sports section.
- Trailer/KinoCheck system.
- Channels DVR / TVE branch features.
- Backup / restore.
- VOD playback, resume playback, frame-rate matching, cache path, and external player opening status.
- Full-screen Details Stage, flash fix, Source Intelligence stability, and focus restore.

Verification:
- Swift parse check completed with existing Linux parse warning in UniversalCodecSupport.swift around async asset load indentation only; no v624 syntax errors reported.
