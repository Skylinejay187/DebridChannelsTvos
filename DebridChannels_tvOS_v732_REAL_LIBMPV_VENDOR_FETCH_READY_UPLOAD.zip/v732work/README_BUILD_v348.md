# Debrid Channels tvOS v348

Focus fix build. Upload this ZIP to GitHub and run the existing workflow.

Key fixes: VOD overlay chips now scroll into view during DPAD navigation; direct trailer popups play with audio; Live Preview caption/text remains removed.
