# Debrid Channels tvOS v486 — Final Hero Polish, Poster Row, Typography Pass

Focused production-polish rebuild from v485.

Changes:
- Hero banner artwork zoomed out slightly while still filling the full banner.
- Hero backdrop focal point lowered again so faces/key artwork are more visible.
- Popup hero backdrop now prefers higher-quality provider/TMDB artwork when available.
- Reduced excessive banner darkening so artwork appears clearer.
- Added one more recommendation poster slot to complete the bottom row.
- Refined portrait recommendation card shape, fill behavior, spacing, and corners.
- Improved popup typography: stronger metadata styling, better description spacing, cleaner cast labels, and improved hierarchy.

Preserved:
- Navigation/focus model.
- Playback and trailers.
- Live TV, guide, onboarding, membership, backend, catalog/search behavior.

Validation:
- Swift parse check passed.
