# Debrid Channels tvOS v490

Popup font system + v489 compile fix pass.

Changes:
- Fixed v489 Swift type-check timeout by breaking MediaInfoPopup body into smaller subviews.
- Added Settings → Appearance → Popup Font.
- Added a large built-in popup typography pack using Apple/system-safe font families and style presets.
- Added live preview for popup font selection.
- Popup font applies only to movie/show popup metadata, descriptions, cast labels, and header metadata chips.
- Preserved compact logo/metadata top bar from v489.
- Preserved search trailer prefetch fix from v489.
- No playback, trailer resolver, Live TV, guide, onboarding, membership, backend, or catalog-ordering changes.

Verification:
- Swift parse check passed with `swiftc -parse Sources/DebridChannelsTVOSApp.swift`.
