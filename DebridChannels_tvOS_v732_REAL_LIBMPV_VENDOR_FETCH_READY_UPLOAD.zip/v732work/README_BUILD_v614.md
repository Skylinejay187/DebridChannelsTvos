# Debrid Channels tvOS v614 — Details Stage Flash + Source Hint Cleanup

Base: v613 Details Stage experiment on top of the confirmed v612 playback/display-match path.

Changes:
- Kept v612/v613 playback, display matching, Live TV setting, and Details Stage layout.
- Darkened/clamped the Details Stage artwork from the first rendered frame to prevent the brief full-bright poster flash during open animation.
- Preserved the left-to-right cinematic poster fade.
- Removed the small “Press Find Links to open Source Intelligence” helper message from the movie Details Stage.
- Source Intelligence still opens normally from Find Links.

Rollback: v613 if the new stage clamp feels too dark; v612 if the full Details Stage experiment is rolled back entirely.
