# v722 Fresh AVPlayer VOD Overlay Rebuild and Artwork Flash Fix

Base: v720 ZIP only.

Changes:
- Streaming Catalog background artwork is keyed by focused media ID plus artwork URL, with neutral placeholder behavior instead of previous artwork reuse.
- Media Information clears selected detail state before presenting the committed selected model, and detail artwork remains keyed to the selected media.
- VOD defaults to AVPlayer unless KSPlayer is explicitly selected by the VOD engine setting.
- VOD diagnostics/logging now report AVPlayer when AVPlayer is active:
  `[VOD ENGINE] selected=AVPlayer instantiated=AVPlayer diagnostics=AVPlayer`
- VOD overlay focus is rebuilt into video, timeline, action chips, and options zones.
- Timeline and video-zone left/right seek through AVPlayer with `seek(to:toleranceBefore:toleranceAfter:)`.
- Resume progress is saved every 5 seconds and cleared after 95% watched.

Preserved:
- Quick panel focus ownership.
- v702 row geometry.
- Catalog loading behavior.
- Season 0 hidden behavior.
- Live TV progress/focus.
- Trailers, membership, backend, and sports areas.

Local verification:
- Static source search confirmed no active stale old overlay symbols or hardcoded KSPlayer-primary diagnostics in packaged source.
- Swift compile was not run because this environment does not have the Swift toolchain installed.
