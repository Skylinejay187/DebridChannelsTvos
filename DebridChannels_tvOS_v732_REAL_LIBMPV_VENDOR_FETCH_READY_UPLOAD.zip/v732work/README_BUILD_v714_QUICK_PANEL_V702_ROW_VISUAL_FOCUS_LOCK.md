# v714 QUICK PANEL V702 ROW VISUAL + FOCUS LOCK

Base: v713 compile fix / v712 current branch.
Reference: v702 first-row Streaming Catalog visual geometry.

Changes:
- Restored v702 preview card sizing math for Streaming Catalog rails.
- Restored v702 focused card image behavior: full-bleed landscape fill instead of blur+fit stack.
- Kept current one-row-at-a-time quick panel shell and next-row category text context.
- Strengthened quick-panel focus locking so UP/DOWN row movement does not visually jump to the top menu first.
- Did not modify catalog loading/settings restore logic, advisory styling, VOD, trailers, Live TV, membership, sports, Source Intelligence, or backend.
