# v712_V711_UI_V702_CATALOG_CORE_MERGE

Base: v711_TMDB_PRIMARY_STABLE_CATALOG_LAYOUT_FIX.

Reference used: v702_PREMIUM_POSTER_PIPELINE_FIX, limited to Streaming Catalog loading/publishing and TMDB/Stremio artwork behavior.

Changes:
- Restored v702-style Stremio manifest loading and row publishing in `CatalogStore.loadAllManifests()`.
- Restored TMDB default shelf merge before catalog rows are published.
- Removed Fanart from the active Streaming Catalog/TMDB logo resolver path.
- Disabled background catalog artwork enrichment for this build so Fanart/TMDB enrichment cannot rewrite or block Stremio catalog rows.
- Kept v711 quick-panel visual styling, one-row-at-a-time catalog view, next-row title context, Up/Down row navigation, and details focus restore behavior.
- Adjusted quick-panel row math so all rows reserve the same row slot as the first row and keep explicit bottom clearance for focus ring/glow/shadow.

Verification notes:
- Source inspection confirms `tmdbMovieLogoURL` now starts with the TMDB images endpoint and no longer calls Fanart.
- Source inspection confirms `loadAllManifests()` loops through saved manifests and publishes prioritized rows after merging TMDB default shelves, matching the v702 publishing model.
- Source inspection confirms `startCatalogArtworkEnrichment` is a no-op for v712.
- Local Swift compile could not be run in this environment because `swiftc` and `xcodebuild` are not installed.
