# Debrid Channels tvOS v617

Base: v616_FRANCHISE_COLLECTION_FOCUS_RESTORE

Changes:
- Details Stage artwork visibility increased about 20%.
- Added pre-dim/staged backdrop fade-in to prevent the full-bright artwork flash on entry.
- Kept v616 collection-only franchise behavior and exact shelf/card focus restore.
- Playback/display matching paths unchanged.
