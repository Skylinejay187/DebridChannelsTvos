# Debrid Channels tvOS v685 Build Fix

Fix:
- Added missing `.timeline` case to PlayerControlButton icon switch.
- Preserved Apple TV style VOD seeking changes from v685.

Verification:
- swiftc -parse passed across Sources/*.swift.
