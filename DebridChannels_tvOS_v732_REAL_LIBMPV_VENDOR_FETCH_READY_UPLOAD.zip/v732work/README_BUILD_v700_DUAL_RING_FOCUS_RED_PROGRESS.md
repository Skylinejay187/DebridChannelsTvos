# v700 Dual Ring Focus + Red Progress

Scoped visual patch on top of v699.

- Live TV focused-card program progress line is now red with a subtle red glow.
- Live TV focused grid card now uses a white outer focus ring.
- Existing cyan/blue focus accent is preserved as the inner ring/glow.
- Focused-only progress behavior from v698 remains intact.
- Premium artwork quality work from v699 remains intact.
- No VOD, Source Intelligence, Trailers, Membership, Backend, Sports, or Settings layout changes.
