# Debrid Channels tvOS v565 — Source Intelligence Overlay Repair

Focus: repair Find Links UI wiring from v564.

Changes:
- Trailer action remains separate from Find Links and does not start normal movie/show source scanning.
- Find Links now opens a full Source Intelligence overlay instead of squeezing a tiny preview strip into the main popup.
- Main popup stays clean; Source Intelligence is a separate readable panel.
- Actual source rows are visible, selectable, and use the existing stream focus path.
- Source rows display quality, provider, size, codec, HDR/DV, audio, subtitles, language when detected, direct-play/resolve status, and warning state when confident.
- MENU/BACK closes the Source Intelligence overlay first before closing the media popup.
- Existing trailer/cast/link resolver paths were preserved.
