# Debrid Channels tvOS v482

Hero details popup redesign compile fix.

- Fixes v481 Swift build error from missing popup metadata state in DetailPage scope.
- Preserves v481 hero details UI work.
