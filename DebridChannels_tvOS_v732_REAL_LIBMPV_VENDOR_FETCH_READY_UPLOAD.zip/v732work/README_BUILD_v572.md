# Debrid Channels tvOS v572 — Global Chrome Wordmark

Base: v571_HERO_POPUP_FINAL_POLISH

Changes:
- Added permanent DEBRID / CHANNELS stacked wordmark to the absolute top-left app chrome.
- DEBRID is white, CHANNELS is orange.
- Wordmark is non-focusable and does not affect menu navigation.
- Preserved top menu layout, playback, Source Intelligence, hero popup, episodes, Live TV, and settings behavior.

Validation:
- Swift parse check passed for Sources/DebridChannelsTVOSApp.swift.
