# Debrid Channels tvOS v681 VOD Seek Controls Fix

Base: v680_SOURCE_INTELLIGENCE_OPENING_STREAM_DV_METADATA_FIX

Fix:
- Restores VOD Back 30 / Forward 30 behavior for the internal KSPlayer path.
- Uses the proven reload + startPlayTime seek path for VOD KSPlayer seeks, because some tvOS KSPlayer builds ignore best-effort reflective relative seek calls while the custom overlay is active.
- Keeps Live TV seek behavior unchanged.
- Improves AVPlayer seek completion to keep currentSeconds/status/play state synchronized.

Scope:
- VOD seek controls only.
- No Source Intelligence logic changes.
- No backend changes.
- No membership, artwork, alerts, settings, trailers, Sports, or Live TV playback logic changes.
