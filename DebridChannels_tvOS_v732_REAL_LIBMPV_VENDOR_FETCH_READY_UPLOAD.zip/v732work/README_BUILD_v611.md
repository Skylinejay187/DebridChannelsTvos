# Debrid Channels tvOS v611 — V597 Player + VOD/Live Display Match Controls

Base: v610 / v597 player-overlay path.

Changes:
- Kept v597 playback and VOD overlay behavior.
- Kept explicit VOD display-match coordinator from v610.
- Added user setting: Match Live TV Display.
- Live TV display match is OFF by default and only activates when the user enables it.
- Live TV display match uses a 2-second debounce to prevent HDMI handshakes during channel surfing.
- Live TV frame-rate normalization added for interlaced-style reporting:
  - 25fps -> 50Hz
  - 30fps -> 60Hz
  - 29.97fps -> 59.94Hz
- Display criteria resets when leaving playback.

Do not touch:
- Membership
- Sports
- Trailers
- Channels DVR / TVE branch
- Backend
