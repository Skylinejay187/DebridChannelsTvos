# Debrid Channels tvOS v397

Rollback base: v395.

Purpose:
- Restore v395 Live TV grid focus styling with the extra white focused card ring.
- Fix visible build marker still showing v392.
- Improve trailer prepare flow so the app waits/polls the backend cache/single-flight lane for playbackUrl instead of immediately stopping at "still preparing."

No unrelated UI/playback systems were changed.
