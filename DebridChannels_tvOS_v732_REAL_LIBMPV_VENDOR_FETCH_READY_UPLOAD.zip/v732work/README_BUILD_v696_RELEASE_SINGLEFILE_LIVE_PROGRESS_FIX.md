# Debrid Channels tvOS v696 — Release Single-File Compile Live Progress Fix

Base: v695 Project YAML Live Progress Build Fix

Fix:
- v695 reached Xcode compilation with `LiveTVProgramProgressLine.swift` included, but Release/WMO failed without a useful Swift diagnostic.
- This is consistent with the large SwiftUI app file hitting Swift whole-module optimization/frontend limits.
- Changed only the app target Release compile mode:
  - `SWIFT_COMPILATION_MODE: singlefile`
  - `SWIFT_OPTIMIZATION_LEVEL: -O`
- This keeps Release optimization but avoids whole-module frontend failure.

Preserved:
- Live TV grid progress bars:
  - focused card brighter/thicker
  - other cards faint/subtle
  - 30-second refresh tick
  - Settings toggle
- VOD seek/focus fixes.
- MediaFusion/HDMI/advisory fixes.

Verification:
- swiftc -parse passed across Sources/*.swift.
