# v713 V702 Row Geometry + Focus + Catalog Stability

Base: v712 V711 UI / V702 catalog merge.
Reference: v702 premium poster pipeline.

Changes:
- Restored v702 first-row Streaming Catalog geometry as the universal row height.
- Raised/expanded the one-row panel to v702 height logic so focused cards, metadata, focus glow, and bottom glass are not cut off.
- Locked quick-panel Up/Down focus inside Streaming Catalog rows so UP on row 1 does not jump to the top menu.
- Kept one-row-visible layout and next-row category text context.
- Disabled Fanart from the Streaming Catalog startup/load path.
- Restored v702-style direct Stremio catalog fetching instead of timeout-wrapped catalog endpoint calls.
- Preserved v711 advisory styling and unrelated VOD/Live TV/Trailer/Membership/Sports fixes.
