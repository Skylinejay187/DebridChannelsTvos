# v483 Hero Popup Layout Fix

- Taller cinematic header to prevent backdrop/face artwork from being cut off.
- Popup moved lower so the top edge is visible and no longer collides with the header.
- Removed heavy full border, kept only a subtle top glass edge/shadow for readability.
- Header artwork brightened and gradients softened.
- TMDB title+year fallback added for catalog/Cinemeta items without TMDB/IMDb IDs so budget/revenue/runtime/studio can populate when a TMDB key is present.
- No playback, trailer resolver, search, membership, Live TV, guide, or backend changes.
