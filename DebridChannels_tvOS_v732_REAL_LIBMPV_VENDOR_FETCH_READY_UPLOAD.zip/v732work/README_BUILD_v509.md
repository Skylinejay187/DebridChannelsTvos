# Debrid Channels tvOS v509 — Dynamic Theater Polish + Media DNA Visual Pass

Base: v508_BUILD_FIX_DYNAMIC_THEATER_VISUALS_READY_UPLOAD

## Scope
- Continue from v508 only.
- Preserve playback/search/settings behavior.
- Add safe visual polish layers without changing player engine selection or provider search rules.

## Added
- Media DNA strip in the VOD overlay.
- Theater Intelligence row under cache/progress.
- More premium source/cache/engine/resume status cards.
- Extra visual context for resume-ready and source-quality state.
- Kept the top logo/banner pulse removed; soft glow remains only.

## Validation
- Swift parser check passed across all source files.
