# v570 Compile Fix 2

Fixes GitHub Actions/Xcode build error:
- `extra argument 'height' in call` at `ManualDetailButton`

Change:
- Replaced invalid combined SwiftUI frame call `.frame(minWidth: buttonWidth, height: buttonHeight)` with chained `.frame(minWidth:)` and `.frame(height:)`.

Preserved:
- v570 top bar portrait poster artwork
- v569 hero popup polish/navigation fixes
- Source Intelligence behavior
- playback/trailer/episode flows
