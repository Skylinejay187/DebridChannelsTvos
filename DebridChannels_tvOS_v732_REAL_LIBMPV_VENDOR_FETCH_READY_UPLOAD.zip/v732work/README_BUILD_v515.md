Debrid Channels tvOS v515 — Premium Browse Taller Popup Layout

Base: v514_PREMIUM_BROWSE_BACKDROP_CAST_POLISH_READY_UPLOAD

Changes:
- Kept Theater Mode retired.
- Extended the Premium Browse popup lower so it can overlap the movie/show quick panel area without becoming a full-screen page.
- Widened the popup and main info column for better breathing room.
- Increased poster stack size while preserving Continue Watching progress.
- Added a subtle bottom discovery deck separator/fade for Media DNA and related titles.
- Expanded Source Intelligence cards and Media DNA cards to use the wider popup.
- Allowed descriptions to use up to 3 lines in the taller layout.
- Preserved playback, resume, search, settings, Cast Wall, Dynamic Information Bar, and existing focus routing.

Validation:
- Swift parse check passed for Sources/DebridChannelsTVOSApp.swift.
