# v702 Premium Poster Pipeline Fix

Scoped build on top of v701.

## Changed
- TMDB artwork now resolves to `/t/p/original` at both model and render layers.
- Direct AsyncImage artwork paths now use the same premium resolver as RemoteImageFit.
- Provider/Stremio/Cinemeta URLs are preserved exactly to avoid broken poster loading.
- Removed unsafe generic query-size rewrites that could invalidate signed CDN URLs.
- Cast profile images also use TMDB original.

## Preserved
- v701 subtle focus ring fix.
- Focused-only red Live TV program progress.
- VOD playback and seek/focus fixes.
- Source Intelligence, Trailers, Membership, Backend, Sports, and Settings layout.
