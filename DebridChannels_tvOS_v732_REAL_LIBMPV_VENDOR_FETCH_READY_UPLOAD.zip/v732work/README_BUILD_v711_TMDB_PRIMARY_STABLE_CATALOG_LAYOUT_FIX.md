# v711_TMDB_PRIMARY_STABLE_CATALOG_LAYOUT_FIX

Stability/layout build from the latest v710 compile-fix ZIP.

Fixes:
- TMDB /original is primary for catalog artwork upgrades.
- Fanart is disabled for v711 startup/catalog paths.
- Catalog rows still publish before artwork enrichment.
- Streaming Catalog cards are sized from available panel height so focus ring/shadow and card bottom fit.

No VOD, trailers, Source Intelligence, Membership, Live TV, Sports, or backend changes.
