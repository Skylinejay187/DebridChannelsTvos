# Debrid Channels tvOS v525

## Live TV Grid Background Themes
- Added a separate Live TV Grid Background Theme setting.
- Preserved existing Home Grid Theme behavior for Movies/Shows quick grid cards.
- New Live TV themes apply only to Live TV grid/guide background surfaces.
- Added Classic Dark, Channels Glass, Frosted Guide, Pure Black, Midnight Blue, Cinema Gold, Neon Edge, and Carbon OLED.

## Stability Preservation
- No VOD/player/search/popup behavior rewiring.
- Swift parse check passed.
