# v701 Focus Ring + Artwork Loading Fix

Scoped fixes on top of v700:
- Live TV grid focus ring reduced to a subtle white outer outline only.
- Removed the added inner cyan/blue ring from Live TV grid cards so it no longer blocks the red progress line.
- Kept focused-only red Live TV EPG progress line from v700.
- Fixed poster loading regression from v699/v700 by removing unsafe Stremio/Cinemeta `/poster/` and `/background/` URL rewrites.
- Kept safe TMDB size upgrades to `/original/` and safe query quality/size upgrades.

Preserved:
- VOD playback / seek / focus fixes
- Source Intelligence
- Trailers
- Membership
- Backend
- Sports
- Settings layout
