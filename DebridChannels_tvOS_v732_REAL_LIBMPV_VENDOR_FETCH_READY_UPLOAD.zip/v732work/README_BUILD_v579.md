# Debrid Channels tvOS v579 BACKEND PROFILE BACKUP

Scope:
- Removed iCloud backup/restore UI from Settings.
- Added backend profile backup/restore/clear UI using reusable backup code.
- Backup code stays visible/saved on the Apple TV for refresh/clear/reuse.
- Restore accepts the same code on another Apple TV.
- Profile payload includes existing settings/source/provider/player/layout/follow data already captured by the app backup payload.
- Playback, trailers, Source Intelligence, Live TV, popup visuals, and episode filtering were not rewired.

Backend required:
- Requires backend v1.8.15.66 profile-backup endpoints:
  - POST /api/profile/backup
  - GET /api/profile/restore/:code
  - DELETE /api/profile/clear/:code
  - GET /api/profile/status/:code
