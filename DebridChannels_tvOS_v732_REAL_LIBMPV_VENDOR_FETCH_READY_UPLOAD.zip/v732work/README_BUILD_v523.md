Debrid Channels tvOS v523

Focus:
- Popup containment fix after v522 testing.
- VOD overlay cleanup: no Theater Mode dialogue / no extra intelligence status card row.

Changes:
- Source chip rail is capped and paged inside the popup instead of overflowing right edge.
- Bottom related poster rail is capped, resized, clipped, and padded inside the rounded popup.
- Explore More / Media DNA area uses safer widths so the right edge is visible.
- Removed VOD Theater Mode strip from playback overlay.
- Removed VOD bottom intelligence status cards (Source / Cache / Engine / Progress / Mood).
- Preserved normal VOD controls, progress bar, cache progress, player engines, audio/subtitle chips, search, settings, and Live TV behavior.

Validation:
- swiftc -parse passed across all Swift sources.
