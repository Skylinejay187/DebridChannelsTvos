# Debrid Channels tvOS v508 — Build Fix + Dynamic Theater Visual Pass

Base: v507_RESUME_BUILD_FIX_PREMIUM_VISUALS

## Build fix
- Fixed the v507/v506 compiler failure in `UniversalCodecSupport.swift` by supplying the new `seekIsAbsolute` argument to the TVVLCKit surface call.
- Confirmed Swift parser passes for `DebridChannelsTVOSApp.swift` and `UniversalCodecSupport.swift`.

## Playback/resume preservation
- Kept the v507 resume seek path intact.
- No changes to automatic/manual resume cache logic beyond preserving the build fix.

## Premium visual additions
- Removed pulse from the top poster/banner logo; glow remains static/soft.
- Added Dynamic Theater Mode strip in the VOD overlay.
- Added ambient artwork/genre glow behind the VOD overlay.
- Added source quality badge: Direct Play / HD Direct / 4K Direct / Cache Ready.
- Added cache state badge beside playback engine badges.
- Added VOD Cast Wall panel on the right side of the overlay while preserving poster visibility.
- Kept chips and controls wide/visible from v502+.

## Stability rule
- No backend changes.
- No search behavior changes.
- No Live TV navigation changes.
