# Debrid Channels tvOS v541 — Xtream/M3U Production Rollback + Native EPG Hardening

## Purpose
Production-stabilize Live TV imports after Sports auto-routing regressions.

## Changes
- Removed automatic Xtream/M3U sports routing from the production path.
- Xtream Codes accounts now import normally into Live TV again regardless of old Sports Only/Both saved mode values.
- Xtream Live TV no longer skips accounts marked Sports Only from previous builds.
- Restored full Xtream channel import cap to large-lineup behavior instead of the 900-channel safety cap.
- Added Xtream XMLTV-first EPG loading using the provider-native `xmltv.php?username=&password=` path before falling back to per-stream `get_short_epg` / `get_simple_data_table`.
- Raised M3U/Xtream fetch limits and timeouts for large providers.
- If Xtream EPG is missing, cards now show a clear “No Xtream EPG returned yet” placeholder instead of reusing stale/fake program data.
- Sports Hub remains separate from IPTV while routing/group assignment is backlogged.
- Xtream organizer is now a preview/status screen only, not a routing action screen.

## Notes
Reference behavior was compared against the Android direct IPTV loader pattern and the xTeVe/Threadfin style separation of playlist import + XMLTV guide mapping.
