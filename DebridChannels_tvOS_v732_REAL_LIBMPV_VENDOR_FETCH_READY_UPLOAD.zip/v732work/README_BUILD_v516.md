Debrid Channels tvOS v516 — Premium Browse Media DNA Explorer + Actor Foundation

Base:
- Continued from v515_PREMIUM_BROWSE_TALLER_POPUP_READY_UPLOAD only.
- Theater Mode remains retired.
- No playback engine replacement.

Changes:
- Upgraded Media DNA section into a clearer Explorer-style deck.
- Added grouped cards for Same Cast, Director, Studio, and Theme.
- Added actor/cast foundation through the existing Cast Wall metadata path.
- Kept the taller popup layout from v515.
- Preserved playback, search, settings, resume/cache behavior, and VOD controls.

Validation:
- Swift parser check passed across Sources/*.swift.
