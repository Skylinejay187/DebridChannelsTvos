# Debrid Channels tvOS v552 — Follow Center Verified Alerts Foundation

This build adds the Follow Center direction without changing the core trailer/cast/link resolver paths.

## Added
- Follow Center foundation for TV show tracking.
- First-run onboarding page explaining verified new-episode alerts.
- Home alert architecture direction: only alert when online source data confirms a new episode airing today.
- TVMaze-first episode verification contract through backend v1.8.15.62.
- TMDB remains optional for artwork/details enrichment when the user supplies a key.
- Settings concept preserved: verified alerts only, no fake data.

## Verification rules
- Alerts must include confirmed show title, season/episode when available, air date, and source.
- If the backend cannot verify an episode, the app must stay quiet.
- Home should show dismiss/search/view actions only for verified alert cards.

## Protected paths
- Trailer playback resolver path untouched.
- Cast popup path untouched.
- Stream link resolver path untouched.
- Xtream/M3U sports auto-routing remains backlogged.
