Debrid Channels tvOS v481 - Hero Details Popup Redesign

Changes:
- Reworked popup header into larger second-style cinematic hero layout.
- Header image is taller, brighter, and clearer so faces/artwork remain visible.
- Popup is positioned below the hero header instead of being cut off by the strip.
- Header uses themed logo only; removed extra plain text title.
- Added TMDB-backed budget/revenue/runtime/studio metadata when TMDB key and matching details are available.
- Missing metadata is hidden instead of showing placeholders.
- Kept popup icon chips and single-line Find Links behavior from v480.

No backend, trailer resolver, search/catalog, membership, Live TV, guide, or device management changes.
