# Debrid Channels tvOS v574_iCloud_BACKUP_RESTORE

Scope locked to iCloud Backup & Restore only.

Added:
- Settings → iCloud Backup & Restore card.
- Backup to iCloud action using NSUbiquitousKeyValueStore.
- Restore from iCloud action for the same Apple ID.
- Last backup/status display.
- Profile payload includes provider/catalog URLs, Live TV sources, Xtream/M3U/XMLTV fields, backend/TMDB/Fanart/TVDB keys, sports preferences, player defaults, layout/font presets, and Follow Center alert switches.

Preserved:
- Source Intelligence untouched.
- Playback/trailer behavior untouched.
- Live TV behavior untouched.
- Hero popup/episode behavior untouched.
- v573 cast/wordmark/episode exact-search work preserved.

Validation:
- swiftc -parse passed for Sources/DebridChannelsTVOSApp.swift.
