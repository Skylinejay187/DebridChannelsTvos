# Debrid Channels tvOS v687 — Advisory + Cache + MediaFusion + Resume Fix

Base: v686 Timeline Select + Artwork 5 Balance Fix

Changes:
- Advisory/top-bar advisor is always visible while media info bar is open; no auto-dismiss timer.
- Advisor now shows richer icon-aware facts:
  - Rotten Tomatoes / IMDb from OMDb when OMDB_API_KEY is available
  - local/TMDB rating fallback
  - certification/content/intense-scene hints from rating/genres
  - runtime/source/resume/quality facts
- Advisor banner now uses real-looking per-fact icons instead of a plain warning-only chip.
- VOD cache is off by default (`vodCacheLimitGB = 0`).
- VOD direct streams from selected hosted source unless user enables temporary cache.
- Player settings panel adds Cache Off / 5GB / 10GB / Unlimited.
- Main Settings > VOD Player adds VOD cache controls.
- Setup path no longer starts cache when cache is Off.
- Cache progress row is hidden when cache is Off.
- Resume button focus order adjusted so Resume remains reachable before the timeline.
- Source Intelligence / MediaFusion provider search retries once when the first pass returns no links, reducing the need to back out and press Find Links again.

Verification:
- swiftc -parse passed across Sources/*.swift.
