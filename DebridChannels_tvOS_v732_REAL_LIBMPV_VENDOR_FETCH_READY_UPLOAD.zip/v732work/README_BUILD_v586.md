# Debrid Channels tvOS v586 — Pair-Code Stripe Auto Unlock

Scope: Membership screen/QR checkout only. Live TV, guide, sports, trailers, playback, source intelligence, backups, and catalog logic were not changed.

Changes:
- Membership QR checkout now displays the returned Pair Code.
- Checkout status text explains that the Apple TV is linked by pair code.
- While the checkout QR is open, the app periodically checks membership status by device ID so it can unlock after Stripe confirms payment.
- After closing the QR, the app refreshes membership status again.
- Restore Membership by Stripe email remains visible and remains the backup recovery path.

Expected flow:
1. User selects Supporter or Lifetime.
2. App requests checkout from backend with device ID and device name.
3. Backend returns Stripe URL + pair code.
4. User scans QR and pays.
5. Backend webhook ties payment to pair code/device ID.
6. App detects active membership by device ID and unlocks.

Requires backend v1.8.15.69 or newer for automatic device-only unlock after payment.
