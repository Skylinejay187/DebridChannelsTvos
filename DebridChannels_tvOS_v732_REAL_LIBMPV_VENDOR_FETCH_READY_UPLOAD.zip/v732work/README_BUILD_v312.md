Debrid Channels tvOS v312 - Smart Alternate Audio v1

Base: v311_XTREAM_SETTINGS_SAVE_LOGIN_FIX.

Implemented carefully:
- Adds Smart Alternate Audio v1 for Movies/Shows.
- Adds player control: Find English Audio.
- Scans existing playable stream links for other copies likely to contain English audio.
- Lets user select an alternate audio source reference without replacing the current good video URL.
- Adds manual sync controls: -250ms, +250ms, Reset, Clear.
- Saves sync offset per title/source in UserDefaults.

Preserved:
- v311 Xtream Settings Save/Login flow.
- v310 Xtream VOD/Series link support.
- v309 KSPlayer/session guide behavior.
- 12-hour / 43200 Live TV guide cap.

Notes:
- v1 is manual-assisted and non-destructive. It does not remux or modify files.
- The selected alternate source is tracked and routed into the player surface state as the external audio reference.
- Engine-specific true external-audio attachment remains guarded so KSPlayer version differences do not crash playback.
