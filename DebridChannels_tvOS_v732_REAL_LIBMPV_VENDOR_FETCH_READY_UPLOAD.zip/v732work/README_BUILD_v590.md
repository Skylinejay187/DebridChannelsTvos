# Debrid Channels tvOS v590 — Trailer Smooth AVPlayer Popup Fit

Base: v589_TRAILER_AVPLAYER_NO_YOUTUBE_AUTO_OPEN

Scope:
- Trailer popup playback only.
- Live TV untouched.
- Guide untouched.
- Sports untouched.
- VOD/internal playback untouched.
- Backend unchanged from v1.8.15.74.

Changes:
- Rebuilt trailer popup AVPlayer surface around a stable AVPlayerLayer identity.
- Removed mute/control-state player recreation by keeping the trailer surface id stable.
- Added async AVURLAsset key loading before AVPlayerItem handoff: tracks, duration, playable.
- Switched trailer AVPlayer buffering to `automaticallyWaitsToMinimizeStalling = true`.
- Uses normal `player.play()` after asset preparation instead of repeated immediate kick behavior.
- Sets AVPlayerLayer contents scale to screen scale for better display sync.
- Sets trailer AVPlayerLayer gravity to `.resizeAspectFill` so trailers fill the popup card cleanly.
- Keeps regular Trailer action blocked from opening YouTube/external apps.

Expected result:
- Smoother trailer frame pacing.
- Trailer video fills the popup instead of appearing undersized/partial-screen inside the card.
- Lower SwiftUI redraw/focus churn during trailer playback.
