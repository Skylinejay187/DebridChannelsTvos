# DebridChannels tvOS v671

Scope: Source Intelligence provider picker, loading visibility, and per-link real track metadata.

Changes:
- Source Intelligence keeps the v669 "Opening stream..." internal-player loading overlay and duplicate activation guard.
- Added a provider picker for All Providers, MediaFusion, Torrentio, Comet, Debrido, Torbox, and other detected providers.
- Provider searches can be scoped to the selected addon/provider without changing playback engines.
- Provider request status is visible as searching, returned links, no links, failed, or timeout.
- MediaFusion no-link cases show "No links found from MediaFusion. Try All Providers." instead of failing silently.
- Real audio/subtitle probing now queues all visible provider-filter links in the background with per provider/URL/file keys.
- Link cards show "checking tracks..." while their own stream probe is pending.
- Track results are cached per link identity during the session and are not reused across unrelated links.

Preserved:
- v669 real VOD audio/subtitle overlay track menus and subtitles Off support.
- v669 VOD overlay/player stability and volume behavior.
- v669 Match Dynamic Range / Match Frame Rate settings reminder.
- v670 VOD Cast Wall restored real cast names/images.
