# Debrid Channels tvOS v691 — Live Progress Build + VOD Focus/Seek Fix

Base: v690 Live TV Grid Subtle Program Progress Build Fix

Fixes:
- Fixed v690 build error:
  - Added missing LiveTVScreen `liveTVGridProgramProgressEnabled` AppStorage.
  - Added missing `LiveTVGridProgramProgressLine` struct.
  - Replaced ambiguous SwiftUI shorthand with explicit Edge.Set / Alignment / UnitPoint where needed.
- Fixed VOD chips becoming hard to select:
  - Removed the timeline from the horizontal chip order.
  - Removed SwiftUI focusable/focused binding from the non-button timeline bar.
  - Timeline is now entered by Up/Down only and no longer traps Left/Right chip navigation.
- Fixed seek behavior regression:
  - Timeline scrubbing still works when timeline mode is active.
  - Select commits timeline seek when scrubbing.
  - Exiting timeline returns to Play/Pause so other VOD chips remain reachable.
- Preserved:
  - v690 subtle Live TV card progress line.
  - v689 tvOS seek/overlay mitigation.
  - v688 MediaFusion/HDMI/advisory fixes.

Verification:
- swiftc -parse passed across Sources/*.swift.
