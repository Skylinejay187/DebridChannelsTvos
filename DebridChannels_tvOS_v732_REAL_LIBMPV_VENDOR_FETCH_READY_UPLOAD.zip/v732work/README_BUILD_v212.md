# v212 Grid OS Compile Fix

Fixes v211 GitHub Actions compile error: missing DetailPoster in MediaInfoPopup.
