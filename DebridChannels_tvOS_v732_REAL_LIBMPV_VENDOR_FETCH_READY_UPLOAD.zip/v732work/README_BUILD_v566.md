# DebridChannels tvOS v566 Rebuild

Focused repair build:
- Stremio-addon trailer scanning disabled for now.
- Trailer Provider settings UI removed.
- Trailer button uses trailer-only resolver path and no longer triggers movie/show stream scanning.
- Source Intelligence overlay shows 6 links per page.
- UP/DOWN moves through source rows.
- LEFT/RIGHT pages source results.
- 4K/highest quality links remain prioritized by source metadata/sort order.
- Back closes Source Intelligence before leaving the popup.
- No Sports auto-routing changes.
