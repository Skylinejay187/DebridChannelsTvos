# Debrid Channels tvOS v520

Final Premium Browse phase pass.

## Added
- Home Grid Theme selector in Settings > Home / Popup Style.
- Theme presets: Classic Glow, Apple Glass, Frosted 3D, Pure Black, Midnight Blue, Cinema Gold, Neon Edge, Carbon OLED.
- Theme effects apply to movie/show/search poster cards only.
- Final Discovery Polish pass keeps Theater Mode retired.

## Preserved
- Playback behavior.
- Search behavior.
- Live TV behavior.
- Settings structure.
- Premium Browse popup layout from v515-v519.

## Validation
- Swift parse check passed.
