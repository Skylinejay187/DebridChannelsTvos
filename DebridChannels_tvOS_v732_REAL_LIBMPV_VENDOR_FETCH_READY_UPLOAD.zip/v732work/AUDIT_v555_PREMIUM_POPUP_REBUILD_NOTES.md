# v555 Premium Popup Rebuild Notes

- Preserved approved backdrop visibility (~38%) and did not add a large duplicate logo.
- Upgraded popup with premium glass rim, layered lighting, softer depth shadows, and refined selected-button focus treatment.
- Added popup-level Favorites and Follow Show utility chips using local AppStorage.
- Added verified-alert/status chips for followed shows and episode watcher integration.
- Improved Live TV smart program info language to reflect verified EPG → TMDB/TVMaze matching.
- Kept trailer/cast/link resolver paths untouched.
