# Debrid Channels tvOS v610 — v597 Player + Explicit tvOS Display Match

Base: v609 / v597 player path.

Scope:
- Keep v597 KSPlayer VOD player and overlay behavior.
- Do not touch membership, sports, trailers, TVE, backup/restore, or backend.
- Preserve top information bar alignment from v609.
- Add tvOS AVDisplayManager preferredDisplayCriteria handling for full-screen VOD only.

Playback changes:
- Full-screen VOD now asks the key UIWindow AVDisplayManager to use the active AVAsset preferredDisplayCriteria before KSPlayer render starts.
- After AVAsset track loading, if asset criteria are available they are re-applied from the loaded asset.
- On tvOS 17+, when asset criteria are not available but video track format information is available, AVDisplayCriteria(refreshRate:formatDescription:) is applied using the real video track nominalFrameRate and CMFormatDescription.
- Display criteria are reset to nil when the KSPlayer VOD surface dismantles, returning Apple TV UI to the normal system mode.

Expected Apple TV behavior:
- With Match Frame Rate and Match Dynamic Range enabled in tvOS settings, the TV should switch when full-screen VOD starts if the display supports the mode.
- This does not force matching when the user disables those tvOS settings.
- This is scoped away from trailers, Live TV preview, and background surfaces to avoid disruptive mode switching.

Notes:
- v597 playback path remains intact.
- No VOD overlay rewrite.
- No cache experiment.
- No MPV/VLC experiment.
