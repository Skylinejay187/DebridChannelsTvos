Debrid Channels tvOS v528 — Clean Premium Popup Core Only

Base: v527 POPUP_BOTTOM_SUMMARY_COMPACT_INFO

Changes:
- Removed the entire bottom summary/filler section from the Premium Browse popup.
- Rebalanced popup height and padding so the core content has more breathing room.
- Expanded description and cast area slightly.
- Kept Dynamic Info bar compact.
- Preserved source intelligence and source rail.
- Preserved playback/search/settings/Home Grid themes/Live TV themes behavior.

Validation:
- Swift parse check passed with: swiftc -parse Sources/*.swift
