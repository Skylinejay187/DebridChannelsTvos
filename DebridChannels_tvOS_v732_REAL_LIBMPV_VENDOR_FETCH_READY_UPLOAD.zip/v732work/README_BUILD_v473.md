# Debrid Channels tvOS v473

Focused pass:
- Live TV grid now falls back to channel/provider icons as the poster surface when Gracenote/program artwork is missing.
- If no icon exists, grid uses a generated branded logo/title card instead of an empty black gradient.
- Trailer resolve requests now ask backend for 4K/2160p first, then 1080p, then 720p fallback.
- Preserved v472 popup/about/panel polish and all search/catalog fixes.

Untouched:
- Playback controls
- Membership / Stripe
- Device management
- Search cards and catalog priority
- Onboarding
- Live TV navigation / guide focus
- Cloudflare public URL integration
