# Debrid Channels tvOS v584 Compile Fix

Fixes GitHub Actions compile error in `trialDisplayText`:

- Replaced invalid Swift call on Int: `remaining.truncatingRemainder(dividingBy: 3600)`
- Correct Int modulo expression is now: `(remaining % 3600) / 60`

No membership behavior changed from v584:
- 24-hour trial remains active
- Continue Support remains 1-year timer
- Lifetime/full unlock remains no-expiration
- Device caps remain backend-controlled
- Live TV / guide / sports / playback untouched
