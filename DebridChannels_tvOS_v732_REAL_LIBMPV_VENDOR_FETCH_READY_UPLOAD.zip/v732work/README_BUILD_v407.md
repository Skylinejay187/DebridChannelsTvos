# Debrid Channels tvOS v408

v399 rollback-base VOD runtime/duration fallback fix.

Use this build to test movie/show overlay time accuracy when the player/proxy reports duration as 0:00.
