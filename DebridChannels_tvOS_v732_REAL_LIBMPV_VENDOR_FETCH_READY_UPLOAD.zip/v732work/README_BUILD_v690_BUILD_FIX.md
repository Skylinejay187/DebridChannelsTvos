# Debrid Channels tvOS v690 Build Fix

Fixes:
- Fixed SwiftUI `.bottom` inference in the Live TV grid progress overlay.
- Removed unavailable tvOS AVPlayerViewController properties:
  - `preventsDisplaySleepDuringVideoPlayback`
  - `updatesNowPlayingInfoCenter`
- Preserved v690 subtle Live TV grid program progress feature.
- Preserved v689 seek/overlay fixes except unavailable AVPlayerViewController property calls.

Verification:
- swiftc -parse passed across Sources/*.swift.
