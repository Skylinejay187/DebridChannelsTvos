# v574 iCloud Backup/Restore Compile Fix

Fixed the tvOS build failure from uploaded logs_73838526827.zip.

Root cause:
- SettingsFocus gained iCloudBackupNow / iCloudRestoreNow, but routeSettings(_:) switches were not updated exhaustively.

Fix:
- Added iCloud backup/restore focus routes for left/right/up/down settings navigation.
- Backup and restore buttons are now reachable by DPAD.
- No changes to playback, Source Intelligence, trailers, Live TV, popup, episode, or provider logic.
