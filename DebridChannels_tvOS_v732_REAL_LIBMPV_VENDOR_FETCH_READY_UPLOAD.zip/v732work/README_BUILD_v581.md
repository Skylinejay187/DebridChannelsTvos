# Debrid Channels tvOS v581 — VOD Regression Fix

Focused regression pass after v580.

## Fixed
- Removed remaining-time badge from the VOD overlay poster.
- Kept remaining/continue progress only on the top media information bar poster.
- Made top media information poster a regular portrait poster without outline/glow frame.
- Removed orange/gold ambient tint from the VOD overlay background.
- Replaced warm/orange VOD ambient glow with neutral black/white glass shading.
- Prevented plain HTTP streams from being routed through the temporary cache/proxy; cache now bypasses HTTP and leaves playback on the original URL.
- Kept playback URL direct/untouched for KSPlayer/VLC to avoid MediaFusion open-stream hangs caused by cache/proxy interference.
- Opening Audio/Subtitles/Episodes/Settings panels no longer wraps in playerAction, so panel focus does not poke playback.
- Audio chip now falls back to Default instead of misleading “No tracks” when the engine does not expose track groups.
- Membership test status now displays a countdown like “9m 12s remaining” instead of raw ISO timestamp.

## Preserved
- Backend profile backup code flow from v579/v580.
- Streaming Catalog + Stremio backup payload support from v580.
- TMDB/catalog link path from v580.
- Live TV, trailers, popup layout, Source Intelligence UI.
