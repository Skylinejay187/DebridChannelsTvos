# Debrid Channels tvOS v518

Premium Browse Mode continuation from v517.

## Included
- Kept Theater Mode retired.
- Added Studio Hub / Franchise / Universe / Discovery foundation row.
- Polished Media DNA discovery deck hierarchy.
- Preserved v515 taller popup and v516/v517 discovery foundations.
- Preserved playback/search/settings behavior.
- Swift parse check passed.
