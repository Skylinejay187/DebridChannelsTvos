# Debrid Channels tvOS v497

Production stability + VOD overlay modernization pass.

Included:
- Live TV left guide/tools panel now opens with Force Refresh Guide focused at the top.
- Force Refresh no longer requires scrolling through all categories.
- Search addon/TMDB async requests are debounced more conservatively to reduce typing lag.
- Search/detail/VOD metadata fallback fills missing Stremio/Cinemeta artwork and descriptions from TMDB when a user key exists; TMDB remains optional.
- VOD overlay refreshed: cleaner poster treatment, no duplicate text title/logo, better metadata hierarchy, modern progress/cache display, icon chips.
- Physical Apple TV Play/Pause button now toggles playback directly instead of opening/selecting overlay controls.
- KSPlayer direct-start behavior preserved: stream starts immediately while cache warms in background.

Not touched:
- Backend
- Live TV guide behavior
- Search link resolver
- Membership/devices
- Onboarding
- Trailer resolver
