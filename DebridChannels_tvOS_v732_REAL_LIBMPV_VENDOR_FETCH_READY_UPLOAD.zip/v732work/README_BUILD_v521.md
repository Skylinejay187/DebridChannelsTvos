Debrid Channels tvOS v521 - Premium Popup Fit / Discovery Removal

Changes:
- Popup height/position adjusted to remain fully visible top-to-bottom.
- Removed Discovery Mode / extra discovery path rows from the popup.
- Kept Explore More with Media DNA + related items only.
- Reduced bottom deck height and spacing so layout fits cleanly.
- No playback/search/settings rewiring.
