# v716 V702 Row Geometry + Focus Correction

Base: v715/current project.
Reference: v702 row/focus behavior.

Changes:
- Restored v702 Streaming Catalog rail geometry math while keeping the one-row-only presentation.
- Focused row card uses v702 390x220 geometry and v702 rail height placement.
- Active row pager is bottom-aligned inside the original v702 quick panel height instead of being pushed upward by compressed pager math.
- Removed the sticky top-menu focus lock introduced in later builds.
- Restored v702-style boundary behavior: UP from the first catalog row can return to the top menu; UP/DOWN inside rows changes catalog rows without the menu bounce.
- Kept ghost-row preview removed.
- Did not touch catalog loading, artwork resolver, VOD, trailers, Live TV, membership, sports, backend, or Source Intelligence.
