# v703 Premium Artwork Decode Cache Fix

Scope kept to artwork presentation pipeline and existing v701/v702 visual fixes.

Changes:
- Replaced AsyncImage-only path in RemoteImageFit with premium data-loader decode using UIImage(data:).
- Forces TMDB artwork URLs to /original while preserving provider/Cinemeta/Stremio signed URLs.
- Bypasses stale URLCache entries for image fetches so previous lower-quality cached responses do not carry forward.
- Keeps in-memory full-image cache per resolved URL during the app session.
- Raises hero/background artwork opacity and contrast so full-quality artwork is not visually dulled by the overlay.
- Preserves v701 subtle Live TV focus ring and v702 red focused-only progress behavior.

Untouched:
- VOD playback
- Source Intelligence
- Trailers
- Membership
- Backend
- Sports
- Settings layout
