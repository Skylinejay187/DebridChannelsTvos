# Debrid Channels tvOS v582

- Enforced global membership lockout after the 10-minute test trial expires.
- Only Membership remains usable while locked; Restore Membership and owner 7-tap unlock remain accessible.
- Owner admin unlock clears the lock on that device.
- Top media information bar now uses a black transparent/glass-style strip.
- Top portrait poster resized/lowered to avoid top crop and stays clean with no outline.
- VOD overlay/player behavior preserved from v581; no playback URL rewrite changes.
