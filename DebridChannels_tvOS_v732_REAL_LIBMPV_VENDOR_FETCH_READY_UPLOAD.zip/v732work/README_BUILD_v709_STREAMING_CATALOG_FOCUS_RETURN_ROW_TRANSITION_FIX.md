# v709_STREAMING_CATALOG_FOCUS_RETURN_ROW_TRANSITION_FIX

Built from v708 and scoped to Streaming Catalog focus/navigation only.

Fixes:
- Up/Down stays inside catalog rows and moves between rows.
- Down from row 1 moves to row 2.
- Up from row 2 moves to row 1.
- Row changes use a short vertical pager transition, then return to one-row-only visibility.
- Opening details from a card stores the exact source card and restores focus there after Back.

Compile note:
- No Swift/Xcode toolchain is available in this container, so packaging and source verification were completed here, but a local tvOS compile could not be run.
