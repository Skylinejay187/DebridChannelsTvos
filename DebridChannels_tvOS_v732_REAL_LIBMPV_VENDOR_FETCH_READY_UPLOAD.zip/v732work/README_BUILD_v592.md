# Debrid Channels tvOS v592 — Trailer No Auto Replay / End Guard

Base: v591_TRAILER_DEEP_SMOOTH_AVPLAYER

Scope:
- Trailer popup only.
- Live TV, guide, VOD playback, sports, membership, and backend settings untouched.

Fixes:
- Trailer AVPlayer no longer auto-loops/restarts at `AVPlayerItemDidPlayToEndTime`.
- Resume watchdog now ignores normal end-of-trailer pause/rate=0.
- Preserves v591 deep smooth AVPlayer background loading and popup fit.

Why:
- Some trailers appeared to stop or replay halfway after the HLS/smooth-player pass.
- The end observer was intentionally restarting the player, which is wrong for normal trailer playback.
