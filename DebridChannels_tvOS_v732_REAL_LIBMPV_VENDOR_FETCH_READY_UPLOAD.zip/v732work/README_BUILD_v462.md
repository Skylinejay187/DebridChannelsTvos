# Debrid Channels tvOS v462

Focused fix only: Search/Details link picker state reset.

Changes:
- Clears old stream links immediately when opening a different movie/show detail.
- Clears alternate audio candidate state with link results to prevent stale provider data.
- Prevents older async link searches from writing results after user navigates to another item.
- Clears link state when closing details or returning through the detail back stack.

Preserved:
- Playback, onboarding, membership, Stripe, devices, favorites, Cloudflare, Live TV, guide, and backend behavior unchanged.
