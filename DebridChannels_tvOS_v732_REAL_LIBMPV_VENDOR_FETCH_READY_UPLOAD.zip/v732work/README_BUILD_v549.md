# Debrid Channels tvOS v549

Focus of this build:
- Sports becomes a full-screen scrollable hub instead of fighting the top-menu focus trap.
- Sports opens at the top every time and shows a left-edge Back hint.
- Sports rows remain vertically scrollable and horizontal rails remain reachable, including Sports Channels.
- Added all-sports Highlights rail foundation, not just wrestling.
- Favorite teams get priority cards for future roster/schedule/player data.
- Wrestling remains included: WWE, AEW, TNA, NJPW.
- Favorites tab is catalog movies/shows only and uses a quick-panel style rail.
- Favorites storage key delimiter fixed so saved movie/show favorites can reopen properly.
- Favorites quick panel includes Remove from Favorites.
- Live TV channel favorites remain separate in Live TV -> My Favorites.
- Manual Add to Sports channel path remains; Xtream/M3U automatic sports routing remains backlogged.
