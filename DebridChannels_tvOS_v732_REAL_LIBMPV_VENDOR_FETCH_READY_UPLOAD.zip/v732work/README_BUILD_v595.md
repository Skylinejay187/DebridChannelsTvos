# Debrid Channels tvOS v595

Scope:
- Restored trailer popup visual/playback path from v592.
- No backend trailer changes; use backend v1.8.15.76 for current trailer testing.
- Applied comic/movie bubble styling only to movie/show information popup.
- Movie/show popup is visually smaller and keeps a black-glass premium style.
- Bubble tail is on the upper-left side of the info panel, aimed toward the upper-right side of the selected poster/card.
- No halftone/dotted texture.

Protected areas untouched: Live TV, guide, sports, playback backend, Stremio/catalog backups.
