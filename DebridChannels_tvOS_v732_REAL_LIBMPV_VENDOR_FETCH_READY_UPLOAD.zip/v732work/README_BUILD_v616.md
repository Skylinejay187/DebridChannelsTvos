# Debrid Channels tvOS v616 — Franchise Collection + Focus Restore Fix

Base: v615 / v614 Details Stage visual path with v612 playback/display matching preserved.

Changes:
- Explore the Franchise now appears only when TMDB confirms the movie belongs to a real collection/franchise.
- Removed same-genre/popular fallback from the franchise shelf.
- Franchise cards no longer display plain text movie titles over the artwork.
- Closing movie/show Details Stage restores the exact quick-panel shelf row and focused card when possible.

Untouched:
- v612 playback/display matching path.
- TV show compact cast/episode layout.
- Membership, sports, trailers, backup/restore, TVE/Channels branch.
