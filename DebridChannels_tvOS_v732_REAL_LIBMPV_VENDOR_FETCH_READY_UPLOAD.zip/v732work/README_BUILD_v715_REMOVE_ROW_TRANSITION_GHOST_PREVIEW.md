# v715_REMOVE_ROW_TRANSITION_GHOST_PREVIEW

Scope:
- Removed Streaming Catalog Up/Down row pager ghost/peek animation.
- Row changes now swap the active row without animating outgoing/incoming rows.
- Current row posters remain the only visible row after every row index change.
- Next row category text context remains.

Preserved:
- v714 v702-style row visuals.
- Quick-panel focus lock behavior.
- Current catalog loading/artwork stability.
- VOD, trailers, Source Intelligence, Membership, Live TV, Sports, backend untouched.

Technical notes:
- `GridOSCatalogOverlay.catalogRail` row transition changed to identity.
- Active row index update now uses a transaction with animations disabled.
- No behavior change to Left/Right poster navigation.
