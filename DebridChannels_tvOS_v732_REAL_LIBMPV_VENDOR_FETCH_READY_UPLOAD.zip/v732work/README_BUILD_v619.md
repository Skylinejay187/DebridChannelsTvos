# Debrid Channels tvOS v619

Base: v618_FRANCHISE_LOGOS_FLASH_VISIBILITY_READY_UPLOAD

Changes:
- Details Stage content column moved left for a fuller full-screen layout.
- Logo size intentionally unchanged.
- Movie/show text, chip width, and cast/season layout given slightly more breathing room without enlarging episode cards.
- Added Live TV-only diagnostics overlay for CBS/Fox timing investigation.
- VOD playback/display matching untouched.
- Franchise/logo/detail-stage fixes from v618 preserved.
