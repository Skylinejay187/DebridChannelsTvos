# Debrid Channels tvOS v260

VOD overlay options pass. KSPlayer remains the default direct-start engine. Audio/Subtitles/Episodes/Settings now use native tvOS dropdown menus so secondary options are selectable without fighting the custom overlay focus engine.
