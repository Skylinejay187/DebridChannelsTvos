# v527 Popup Bottom Summary + Compact Dynamic Info Fix

Base: v526 Dynamic Showcase Area.

Changes:
- Replaced the large artwork showcase with a compact non-focusable bottom summary shelf.
- Avoids duplicate artwork since the popup background already carries the cinematic backdrop.
- Dynamic Information Bar shortened and sized down so it no longer stretches across the whole description area.
- Continue Watching remains available in the bottom shelf when resume data exists.
- Preserved source rail, popup containment, Live TV themes, VOD overlay cleanup, playback/search/settings behavior.
- Swift parse check passed.
