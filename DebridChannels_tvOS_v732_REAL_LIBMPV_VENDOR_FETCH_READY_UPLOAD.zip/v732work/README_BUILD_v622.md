# Debrid Channels tvOS v622

Base: v621_SEARCH_ALERT_CBS_READY_UPLOAD

Compile fix:
- Fixed tvOS build error from using unavailable `UNMutableNotificationContent.title/body/sound` APIs in `CatalogStore.swift`.
- Kept app-open/resume followed-show scanner path.
- Kept Search poster lock, Stremio Source Intelligence routing, faster external-player handoff, CBS diagnostics, Details Stage changes, and VOD playback untouched.

Note:
- On tvOS, local notification content APIs are limited; this build keeps verified alert hits logged and keeps tvOS-safe in-app alert presentation path intact.
