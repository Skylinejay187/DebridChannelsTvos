# Debrid Channels tvOS v607

Base: v597_INFO_POPUP_LOWER_GLASS_CONNECTOR.

Scoped changes only:
- Kept v597 player/overlay logic as the base; no v603/v605 VOD experiment carried forward.
- Added conservative KSPlayer route preference for Apple-native-friendly VOD/HLS/MP4 URLs so tvOS can honor system Match Frame Rate / Match Dynamic Range through the AVFoundation-backed KSPlayer route when supported, while MKV/remux/unknown links keep FFmpeg/Metal first.
- New Episode Alert no longer depends on highlighted season and no longer blindly chooses the last aired episode. It resolves dated today/future episodes first; if metadata has no future date, it creates the next logical SxxEyy after the highest known episode.
- Preserved Debrid Channels wordmark size.
- Kept catalog Movies/Shows/Streaming Catalogs panel logo text smaller without touching the main Debrid Channels logo.
- Preserved real episode metadata fields and added optional airDateString for alert math.

Do not touch scope preserved: membership, sports, trailers, Channels DVR/TVE, backup/restore, backend.
