# Debrid Channels tvOS v569 HERO_POPUP_POLISH_NAV_FIX

Scope-locked polish pass on top of v568 compile fix.

Changes:
- Movie hero popup safe-width math tightened so the panel content fits evenly left/right and does not clip at the edges.
- Popup shell outline softened; hard bordered box look replaced with a softer hero-sheet highlight so background channels/rows remain visually blended behind it.
- Action chips redesigned as premium rounded hero controls with stronger selected state and softer glass inactive state.
- TV show navigation now allows DOWN from the utility/follow/test row directly into Season tabs and then Episode cards; Episodes chip remains a shortcut only.
- LEFT from first episode returns to selected Season tab instead of jumping back to the Episodes chip.
- Episode cards now prefer real episode thumbnail/still art from metadata for poster, landscape, and preview image fields instead of repeating the parent show backdrop.

Preserved:
- Source Intelligence overlay and data layout untouched.
- Top metadata/stat bar untouched.
- Trailer, YouTube, Find Links, Favorites, Follow, Test Alert behavior preserved.
- v568 TV show sizing/layout preserved because it visually tested well.

Verification:
- swiftc -parse passed for all Swift source files.
