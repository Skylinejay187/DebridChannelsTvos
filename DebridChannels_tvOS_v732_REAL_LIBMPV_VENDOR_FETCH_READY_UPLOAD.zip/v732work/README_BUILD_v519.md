# Debrid Channels tvOS v519

Premium Browse Mode continuation from v518.

## Included
- Kept Theater Mode retired.
- Added Discovery Path Summary row above Studio/Franchise foundation.
- Added Next Step / Cast Path / Creator Path / Studio Path / Matches cards.
- Preserved v515 taller popup, v516 Media DNA Explorer, v517 Actor foundation, and v518 Studio/Franchise foundation.
- Preserved playback/search/settings behavior.
- Swift parse check passed.
