# Debrid Channels tvOS v464

Search card component rebuild pass.

- Rebuilt Movies & Shows search results so they are no longer native SwiftUI tvOS Buttons.
- Search media cards are now custom focusable views using FocusState + onTapGesture.
- This avoids the system white outer focus platter entirely instead of trying to hide it.
- Increased card sizing and spacing for a more premium search grid.
- Kept the gold shaped artwork focus ring.
- Preserved v463 unlimited catalog rows and unlimited row items.
- No playback, link resolver, onboarding, membership, Live TV, guide, favorites, Cloudflare, or backend behavior changed.
