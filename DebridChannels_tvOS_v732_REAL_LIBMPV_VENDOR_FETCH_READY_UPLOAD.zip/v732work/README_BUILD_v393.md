# Debrid Channels tvOS v393

Built from the uploaded v392 stable base.

Fixes the current Search regression only: Search result media is hydrated into resolver-ready catalog/IMDb/Cinemeta metadata before opening Details, so pressing **Search Links** from Search-opened movies/shows uses the same stream resolver path as normal rows.

Also includes a backend handoff helper for trailer yt-dlp cookies + optional JS runtime + 1080p/4K selection. The app-side trailer request now asks existing backend endpoints for `prefer4k=true&minHeight=1080&allow4k=true` while preserving the current trailer popup/player behavior.
