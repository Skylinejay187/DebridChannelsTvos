# Debrid Channels tvOS v697 — Force Single-File Project Settings

Base: v696 Release Single-File Live Progress Fix

Fix:
- v696 target-only Release setting did not apply; xcodebuild logs still showed `-whole-module-optimization`.
- Added single-file compile settings at both project and target levels:
  - project base `SWIFT_COMPILATION_MODE: singlefile`
  - project Release config `SWIFT_COMPILATION_MODE: singlefile`
  - target Release config `SWIFT_COMPILATION_MODE: singlefile`
  - defensive `SWIFT_WHOLE_MODULE_OPTIMIZATION: NO`
- This should stop the silent Release/WMO Swift frontend failure while preserving optimization level `-O`.

Preserved:
- Live TV grid progress bars:
  - focused card brighter/thicker
  - other cards faint/subtle
  - 30-second refresh tick
  - Settings toggle
- VOD seek/focus fixes.
- MediaFusion/HDMI/advisory fixes.

Verification:
- swiftc -parse passed across Sources/*.swift.
