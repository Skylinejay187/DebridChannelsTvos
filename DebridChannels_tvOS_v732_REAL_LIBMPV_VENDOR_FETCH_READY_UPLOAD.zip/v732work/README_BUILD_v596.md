# Debrid Channels tvOS v596 — Professional Info Popup Card Connector

Scope:
- Restores movie/show information popup closer to original size; only slightly smaller than the prior full card.
- Removes cartoon/comic speech-bubble tail and halftone styling.
- Adds a subtle premium glass connector/beam from the focused bottom poster/card area into the movie/show information popup so it feels like the panel grows out of the selected card.
- Keeps the full popup content visible: logo, plot, metadata, cast, and actions.
- Trailer popup is untouched/restored from the working trailer path.
- Backend untouched. Continue using backend v1.8.15.76 for current trailer testing.

Protected areas untouched:
- Live TV
- Guide
- Sports
- Playback/VOD player
- Backend backup/restore
- Membership logic
