# Debrid Channels tvOS v583

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V583_MEMBERSHIP_LOCKOUT_TOPBAR_GLASS`

Base:
`v582_MEMBERSHIP_LOCK_TOPBAR_FIX`

## v583 scope
- Membership bootstrap rebuilt for the 10-minute test trial.
- Fresh v583 inactive installs no longer reuse stale expired trial data preserved by tvOS/UserDefaults.
- Trial countdown is local, live, persistent across restart, and expires into full lockout.
- Locked app exposes Membership/Restore/owner unlock only.
- Top media information bar rebuilt as black transparent glass matching the bottom quick-panel language.
- Header poster lowered and switched to clean fit mode so portrait art is not cropped from the top.
- Remaining-time badge remains only on the top header poster.

## Protected areas left untouched
Live TV, guide, sports, popup redesign, Source Intelligence, backend backup/restore, Stremio backup, catalog backup, trailers, and playback logic.
