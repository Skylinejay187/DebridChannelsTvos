# Debrid Channels tvOS v408

VOD overlay-only patch from v399 rollback line:
- Remove rating badge from VOD overlay mini-poster only.
- Stabilize pause/play by de-duplicating KSPlayer play/pause commands.
- Keep runtime fallback and -30/+30 seek work.
