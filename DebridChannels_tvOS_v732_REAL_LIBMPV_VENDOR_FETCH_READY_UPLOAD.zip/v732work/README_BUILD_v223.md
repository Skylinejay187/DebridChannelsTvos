# Debrid Channels tvOS v223

Upload this ZIP to GitHub the same way as the prior v220/v221/v222 ready-upload packages.

## Fixes
- Removes only the duplicate `Movies` item from the Live TV grid category row.
- Keeps the top main menu `Movies` item.
- Makes Force Refresh Guide hidden off-screen by default.
- Opens Force Refresh Guide only when pressing LEFT from the first Live TV grid card.
- Redesigns Force Refresh Guide with higher contrast/readability.
- Carries forward v222 poster URL hardening for Movies/TV Shows.
