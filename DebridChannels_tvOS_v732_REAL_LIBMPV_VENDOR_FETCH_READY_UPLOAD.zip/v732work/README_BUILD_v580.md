# Debrid Channels tvOS v580_TMDb_LINKS_REAL_TRACKS_BACKUP_FIX

Careful fix build from v579 compile-fix.

Included:
- TMDB/catalog link path preserved and app build markers updated.
- VOD overlay no longer presents fake static audio/subtitle choices as the primary source of truth.
- Audio panel lists real audio tracks exposed by the active media asset.
- Subtitle panel lists real embedded/external subtitle tracks exposed by the active media asset.
- Added explicit Subtitles Off behavior that deselects AVPlayer legible tracks when available and keeps subtitle state Off by default.
- Removed gold/right-side tint from VOD advisory overlay treatment.
- Backend profile backup payload now includes Streaming Catalogs and Stremio addon manifest order/config.
- Restore now writes `stremioManifestURLs` back into UserDefaults and the in-memory CatalogStore manifest list.
- Temporary membership test window is 10 minutes through backend env/default; revert `MEMBERSHIP_TRIAL_HOURS` to 24 for production.

Preserved:
- Live TV behavior.
- Trailer behavior.
- Popup layout.
- Source Intelligence UI.
- Backend backup code flow.
