# Debrid Channels tvOS v682 — AVPlayer Default VOD + Source Intelligence Fix

Base: v681 VOD Seek Controls Fix

Changes:
- Restored AVPlayer as the default VOD internal player.
- Kept KSPlayer as selectable fallback for VOD.
- Added VOD Internal Player setting: AVPlayer Default / KSPlayer Default.
- AVPlayer path uses tvOS AVFoundation route so Match Frame Rate / Match Dynamic Range can be honored by tvOS settings.
- Source Intelligence internal playback now delays launch briefly so the Opening Stream overlay renders immediately.
- Source Intelligence provider chips now show only detected/installed/active providers plus All Providers.
- Source Intelligence panel no longer draws an extra movie backdrop inside the overlay.
- Source Intelligence link/detail layout widened so links and side detail panel stay inside the box.
- Removed production Settings "Restore Demo Rows" button UI.
- Removed filmstrip artwork placeholder; catalog cards keep a clean dark placeholder/spinner instead.
- Preserved v681 VOD Back 30 / Forward 30 KSPlayer seek reload/start-time fix.
- English audio is preferred when real AVPlayer track groups expose an English option.
- Subtitles default to Off while remaining selectable.

Compile check:
- swiftc -parse passed across Sources/*.swift.
