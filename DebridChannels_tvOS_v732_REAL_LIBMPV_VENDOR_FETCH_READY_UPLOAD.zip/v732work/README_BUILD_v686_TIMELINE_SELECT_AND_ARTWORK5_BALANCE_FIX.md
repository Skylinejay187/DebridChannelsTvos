# Debrid Channels tvOS v686 — Timeline Select + Artwork 5 Balance Fix

Base: v685 Apple TV Style VOD Seeking Fix Build Fix

Fixes:
- Timeline seek now commits directly when the timeline is focused or scrubbing and Select/OK is pressed.
- Removed the SwiftUI Button wrapper around the timeline bar to stop tvOS focus from turning all VOD chips white.
- Timeline remains a focusable bar, but Select is handled by the player overlay command path.
- Artwork 5 Floating visibility toned down one step:
  - lower backdrop opacity/saturation/contrast
  - lighter subject-pop overlay strength
  - keeps floating quick panel but balances better with Live TV grid cards behind it.
- Artwork 4 Hero 2 remains stronger than Artwork 5.

Preserved:
- v685 in-place seek/no reload logic
- v684 Artwork 4/5 floating behavior
- v682 AVPlayer default VOD
- v681 seek intent

Verification:
- swiftc -parse passed across Sources/*.swift.
