Debrid Channels tvOS v506

Focus: Regression fix only.

Changes:
- Fixed automatic resume so the displayed saved time is no longer just a stale progress label.
- Fresh VOD startup now resets the visible clock to 0 before applying resume.
- Resume chip restored: it sends an absolute KSPlayer seek to the saved position.
- Automatic resume no longer waits on the local isPlaying flag before sending the first seek request.
- Normal 30-second seek remains relative so manual fast-forward/rewind keeps the v504 black-surface fix.
- TMDB Search popup hydration now preserves visible movie/show metadata, cast, description, rating, poster, backdrop, and logo.
- Hydration only changes resolver identity/catalog/addon fields used by Search Links.

Validation:
- Swift parser check passed across source files.
