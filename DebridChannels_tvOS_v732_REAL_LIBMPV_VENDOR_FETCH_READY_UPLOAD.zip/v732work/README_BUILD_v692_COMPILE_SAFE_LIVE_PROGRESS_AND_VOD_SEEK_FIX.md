# Debrid Channels tvOS v692 — Compile-Safe Live Progress + VOD Seek/Focus Fix

Base: v691 Live Progress Build + VOD Focus/Seek Fix

Fixes:
- Replaced the custom Live TV progress SwiftUI struct with a simple inline progress line to avoid Release/WMO frontend build failure.
- Fixed explicit Edge.Set/Alignment usage for the Live TV progress overlay.
- Kept Live TV card progress feature and Settings toggle.
- VOD chip focus:
  - Timeline is no longer part of the horizontal chip order.
  - Timeline does not bind as a SwiftUI focusable control.
  - Left/Right chip navigation remains on chips.
- VOD seeking:
  - Up/Down enters timeline scrub mode.
  - Left/Right scrubs while timeline mode is active.
  - Select commits the seek.
  - Seek completion returns focus to Play/Pause so the rest of the chips remain selectable.

Verification:
- swiftc -parse passed across Sources/*.swift.
