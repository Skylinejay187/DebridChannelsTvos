# Debrid Channels tvOS v589 — Trailer AVPlayer + No YouTube Auto-Open

Focused trailer popup patch after v586.

## Fixed
- Regular Trailer loading no longer opens YouTube or external apps automatically.
- Automatic fallback no longer calls UIApplication.open for YouTube.
- Trailer popup remains AVPlayer-only and isolated from VOD/Live TV/guide playback.
- Trailer AVPlayer user agent updated for v589.
- Trailer video gravity changed to aspect-fit to avoid cropping/glitchy popup playback.

## Preserved
- Live TV untouched.
- Guide untouched.
- Sports untouched.
- VOD playback untouched.
- Membership flow untouched.
- Backend backup/restore untouched.
