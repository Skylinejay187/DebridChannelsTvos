# DebridChannels tvOS v672

Scope: Top-bar advisor banner redesign and top-bar media information layout options.

Changes:
- Replaced the static top-right viewer advisory badge with a passive top-left advisor banner.
- Advisor banner uses existing known metadata only, slides in without focus, and auto-dismisses after about 10 seconds.
- Advisor banner is session-scoped per selected media item and does not create focusable controls or full-screen dimming.
- Added Top Bar Media Info Layout setting with Center, Left, and SportsCenter Ticker options.
- Center preserves the v655 centered top media info layout.
- Left starts the same media info content closer to the left with safe padding.
- SportsCenter Ticker rotates available top-bar facts and auto-hides after completing the cycle.
- Removed the visible Close chip from the media information/details action rows.
- Back/Menu still closes the media information overlay.
- Artwork Live TV Grid Background themes now return the normal Live TV grid to clean black when the Streaming Catalog panel is closed.
- Artwork backdrops remain active inside the Streaming Catalog panel.

Preserved:
- Source Intelligence provider picker and real track metadata from v671.
- VOD Cast Wall restore from v670.
- VOD playback engine, Live TV playback, trailers, Sports, Search, artwork theme settings, and details layout outside the requested action-row/top-bar cleanup.
