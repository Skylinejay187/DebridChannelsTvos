# Debrid Channels tvOS v351

Ready-to-upload source ZIP build based on uploaded v350.

Changes:
- Wires trailer button to existing backend trailer resolver endpoints.
- Supports `trailer.playbackUrl`, `previewUrl`, `playbackUrl`, and `videoUrl` fallback responses.
- Keeps trailer playback limited to direct MP4/HLS URLs in the existing trailer popup.
- Fixes VOD overlay DPAD routing: bottom chips use Left/Right only; opened submenus use Up/Down only.
- Keeps Live TV quick guide on Up/Down only during Live TV playback.

No new backend trailer system was built.
