# v570 compile fix

Fixes the GitHub Actions build failure where `ManualDetailButton.body` timed out SwiftUI type checking around line 3600.

Changes:
- Broke the redesigned hero action chip view into smaller computed properties.
- Extracted `ManualDetailButtonContent` subview.
- Preserved v570 top-bar portrait poster behavior.
- Preserved Source Intelligence, playback, trailers, episode behavior, and v569 hero popup polish.
