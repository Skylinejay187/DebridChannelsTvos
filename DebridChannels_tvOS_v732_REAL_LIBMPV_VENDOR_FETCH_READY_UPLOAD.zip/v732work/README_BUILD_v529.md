Debrid Channels tvOS v529 - Popup Offset + VOD Overlay Cleanup

Changes:
- Moved Premium Browse popup panel lower on screen.
- Removed compact popup search/link chip because Find Links already exists.
- VOD overlay title now uses themed logo rendering instead of plain text.
- Removed VOD Media DNA chip strip (Media DNA / Character Driven / Resume Ready).
- Shifted VOD Cast Wall slightly right.
- Preserved playback/search/settings/theme behavior.
