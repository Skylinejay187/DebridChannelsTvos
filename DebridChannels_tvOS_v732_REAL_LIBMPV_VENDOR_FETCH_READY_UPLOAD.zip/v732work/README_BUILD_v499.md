# Debrid Channels tvOS v499

Targeted stability patch on top of v498 build fix.

Included:
- Fixed Live TV left panel double-highlight: Force Refresh remains focus index 0, categories now start at focus index 1.
- Search opens faster: cached Live TV only on search open, no source refresh from Search screen.
- Search feels more instant: local rows + Live TV render immediately, TMDB runs first as artwork/metadata boost, add-on network search delayed/deferred.
- Resume crash guard: avoids injecting KSPlayer startPlayTime before stream duration is known; resume entry stays armed and backup chip remains available.

Not a broad redesign pass. The Settings screenshot-style section-card navigation is queued as the next careful UI pass so it does not get rushed into this crash/focus/search patch.
