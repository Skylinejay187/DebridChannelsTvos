# v484 HERO BANNER POPUP FIT FIX

- Shifted hero/banner artwork downward so faces and artwork are more visible.
- Increased header frame to preserve cinematic artwork instead of a cropped strip.
- Moved popup lower with breathing room below the banner.
- Reduced popup internal heights so poster, cast, buttons, and related row fit fully.
- Kept icon chips, single-line Find Links, and TMDB-backed metadata behavior.
