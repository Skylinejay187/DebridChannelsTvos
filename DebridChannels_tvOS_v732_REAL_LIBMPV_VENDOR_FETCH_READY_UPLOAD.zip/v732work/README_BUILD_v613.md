# Debrid Channels tvOS v613 — Full Screen Details Stage Experiment

Base: v612 confirmed playback/display-match compile fix.

Changes:
- Converted movie/show information popup into a full-width Details Stage below the top metadata bar.
- Backdrop/poster artwork now fills the full screen area under the top bar, left-to-right and down to the bottom.
- Preserved the existing artwork fade/gradient style so text remains readable.
- Removed hard popup border and connector tail for this experiment.
- Restored top metadata bar to black transparent glass.
- Kept v597 player/overlay logic and v612 display matching work intact.

Rollback note:
- This is a visual experiment only. If the Details Stage does not feel right, roll back to v612/v609 popup layout while keeping playback fixes.
