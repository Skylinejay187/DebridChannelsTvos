# Debrid Channels tvOS v612 — Display Match Compile Fix

Base: v611 / v597 player-overlay path.

Fixes in this build:
- Fixed `AVAsset.preferredDisplayCriteria` compile usage for the current tvOS SDK where it is non-optional.
- Removed the failing `Double` refresh-rate fallback path that caused `AVDisplayCriteria(refreshRate:)` Float compile errors.
- Kept v597 KSPlayer player/overlay behavior.
- Kept explicit VOD display matching through `AVDisplayManager.preferredDisplayCriteria`.
- Kept optional Match Live TV Display setting with debounce behavior.
- Kept popup top information bar placement from v609.
- Kept next-upcoming-episode alert logic.

Not touched:
- Membership
- Sports
- Trailer system
- Channels DVR / TVE branch
- Backend / backup restore
