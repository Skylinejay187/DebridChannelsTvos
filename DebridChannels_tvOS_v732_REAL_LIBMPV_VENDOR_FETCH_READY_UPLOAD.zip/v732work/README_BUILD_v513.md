Debrid Channels tvOS v513 — Premium Browse Mode Poster Stack + Source Intelligence

Base: v512_DYNAMIC_INFORMATION_BAR_READY_UPLOAD

Changes:
- Theater Mode remains retired / not expanded.
- Added Premium Browse poster stack in the popup:
  - poster glow preserved
  - Continue Watching label
  - remaining time
  - watched progress bar
- Added Source Intelligence rail above the source chips:
  - Best Quality
  - Start Mode / Direct Play status
  - Size
  - Found link count
- Added Media DNA v2 grouping row:
  - Similar
  - Same Cast
  - Director
  - Studio
  - Theme
- Preserved Dynamic Information Bar, compact search+link chip, critic cards, metadata popup, playback, resume, search and settings behavior.

Validation:
- swiftc -parse Sources/*.swift passed.
