# Debrid Channels tvOS v510 — Popup Critic Scores Polish

Built from v509.

Changes:
- Replaced the duplicated popup metadata line (year/type/genre/rating) with critic-style score cards.
- Added Tomato, Critics, and Audience score pills in the circled popup area.
- Kept the existing header metadata chips, cast row, theater visuals, and playback behavior unchanged.
- Used the existing rating value as a safe fallback until a real external Rotten Tomatoes/critic feed is wired.
- Swift parse check passed.
