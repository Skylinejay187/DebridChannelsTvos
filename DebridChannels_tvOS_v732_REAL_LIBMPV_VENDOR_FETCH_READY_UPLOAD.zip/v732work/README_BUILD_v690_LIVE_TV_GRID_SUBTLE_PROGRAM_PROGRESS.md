# Debrid Channels tvOS v690 — Live TV Grid Subtle Program Progress

Base: v689 tvOS Match Content Seek/Overlay Fix

Changes:
- Added a subtle now-playing progress line to Live TV grid cards.
- Progress uses real EPG start/end Date values through LiveProgram.liveProgress.
- Progress bar only appears when the current program has valid real timing.
- The line is intentionally quiet:
  - 2px when not focused
  - 4px with slight glow when focused
  - low opacity so it blends into the card footer
- Added Settings > Live TV toggle:
  - Live TV Card Progress Bar
- Does not affect full guide, playback, VOD, Sports, trailers, Source Intelligence, or backend.

Verification:
- swiftc -parse passed across Sources/*.swift.
