Debrid Channels tvOS v493 — Popup Spacing, Cast Persistence, Left Panel Theme, Top Menu Appearance

Changes:
- Moved movie/show popup down while keeping size stable.
- Added more spacing between cast row and action chips.
- Episode selection now preserves show-level cast/cast images if episode-specific cast is missing.
- Added Appearance settings for Top Menu Theme and Top Menu Font.
- Added pill/glass top menu theme support while preserving default behavior.
- Freshened Live TV left guide/tools panel styling only.
- No playback, trailer, search, membership, guide mechanics, backend, or catalog changes.

Parse check: swiftc -parse Sources/*.swift passed.
