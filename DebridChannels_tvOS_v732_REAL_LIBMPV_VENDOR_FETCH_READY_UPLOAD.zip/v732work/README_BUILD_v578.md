# Debrid Channels tvOS v578_iCloud_REAL_SYNC_FIX

Scope locked to iCloud reliability and Source Intelligence positioning.

Changes:
- iCloud backup now writes JSON Data directly to one shared key: DebridChannels.ProfileBackup.v1.
- Restore reads the same shared key and falls back to legacy v574/v575 base64 key only for migration.
- Backup/restore/clear call NSUbiquitousKeyValueStore.synchronize().
- Added visible diagnostics: shared key, payload size, sync status, current/legacy/missing key state.
- Added didChangeExternallyNotification listener to detect backups arriving from another Apple TV.
- Added tvOS iCloud KVS entitlement file and CODE_SIGN_ENTITLEMENTS entry.
- Source Intelligence overlay moved lower so the top media info bar remains visible.

Preserved:
- Episode/search logic from v577.
- Playback, trailers, popup layout, Live TV, sports, and Source Intelligence UI behavior.
