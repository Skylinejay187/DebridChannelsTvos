# Debrid Channels tvOS v579 Backend Profile Backup Compile Fix

Fixes the tvOS build error from the backend profile backup pass.

## Cause
`SettingsFocus` gained a new `backupCode` focus target, but four manual Settings DPAD `switch focused` blocks were not exhaustive.

## Fix
Added `backupCode` handling to Settings right/left/up/down routing.

## Scope
- Compile fix only.
- Backend profile backup UI preserved.
- iCloud backup remains removed.
- Playback, Source Intelligence, Live TV, trailers, and popup behavior untouched.
