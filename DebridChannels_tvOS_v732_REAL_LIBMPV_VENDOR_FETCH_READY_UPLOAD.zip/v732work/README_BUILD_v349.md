# Debrid Channels tvOS v350

Universal Search v1 + Live TV grid pop animation upgrade.
