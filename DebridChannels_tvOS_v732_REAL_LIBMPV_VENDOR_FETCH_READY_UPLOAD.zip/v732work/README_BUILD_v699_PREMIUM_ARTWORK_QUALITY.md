# Debrid Channels tvOS v699 — Premium Artwork Quality Pass

Base: v698 focused-only Live TV progress compile fix.

Changes:
- Added a central render-time artwork URL upgrader in `RemoteImageFit`.
- All existing poster/backdrop/image surfaces now request highest available provider artwork before AsyncImage loads.
- TMDB sizes upgraded to `/original/` including w45/w92/w154/w185/w300/w342/w500/h632/w780/w1280.
- Stremio/Cinemeta/proxy image URLs get best-effort high-quality query upgrades for width/height/quality.
- Existing CatalogStore `highest(_:)` was expanded to the same larger TMDB size set.

Scope preserved:
- v698 focused-only Live TV progress behavior kept.
- No VOD playback, Source Intelligence, trailer, membership, backend, sports, or settings layout changes.
