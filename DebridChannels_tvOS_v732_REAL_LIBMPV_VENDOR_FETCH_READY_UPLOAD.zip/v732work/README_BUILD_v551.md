# Debrid Channels tvOS v551

Focus: visual polish and sports/live information wiring without disturbing core trailer/cast/link paths.

Included:
- Movie/show popup duplicate metadata chip strip removed.
- Popup panel styling refreshed with a cleaner gradient border and less cramped action area.
- First-time setup now includes Guide Tools instructions for the left Live TV tools panel.
- Live TV playback overlay now surfaces smart program text from EPG/description/category metadata when available.
- Sports manually-added channels now attempt to play directly from the Sports section.
- Sports highlight/event cards now expose visible action chips and status messaging instead of empty chips.
- Sports command center, PPV/events, sports-only M3U, highlights, and Favorites quick-panel foundations preserved.
- Xtream/M3U sports auto-routing remains backlogged/disabled.
