# Debrid Channels tvOS v498

Automatic Resume Playback + Playback Stability pass from v497.

Use the same upload/build flow as v497. This package preserves the existing Signulous-compatible project structure and adds only the v498 playback resume cache/source wiring.
