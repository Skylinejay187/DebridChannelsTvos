# Debrid Channels tvOS v667 - Artwork 3 Detail Visibility and Artwork 4 Hero Fullscreen

Build name: DebridChannels_tvOS_v667_ARTWORK3_DETAIL_VISIBILITY_AND_ARTWORK4_HERO_FULLSCREEN

Base: latest working tvOS source from v666 Trailer Cleanup Restore Normal Tuning.

Scope:
- Artwork 3 Hero visibility polish.
- Added Artwork 4 Hero 2 to Live TV Grid Background settings.

Artwork 3 Hero:
- Kept text, logos, card sizes, focus rings, catalog panel transparency, and readability masks unchanged.
- Increased focused catalog artwork visibility slightly.
- Increased artwork saturation/contrast slightly for better face, character, clothing, and object definition.
- Reduced the catalog hero ghost blur from 16 to 11 only inside the Home/Movies/TV Shows catalog overlay.
- Favorites keeps the existing ghost layer defaults.

Artwork 4 Hero 2:
- Added `Artwork 4 Hero 2` as a Live TV Grid Background theme.
- Applies only while browsing the Home / Movies / TV Shows streaming catalog overlay.
- Hides the underlying Live TV grid surface only while that catalog overlay is active.
- Uses a clean, highly visible focused artwork background with lighter masks.
- Keeps the streaming catalog panel on the same transparent/glass treatment as Artwork 2.
- Does not affect Live TV guide, full guide, playback, Favorites, Settings, Sports, Details/media information, Search, Source Intelligence, or trailer popup.

Preserved:
- Backend files were not modified.
- Catalog logic was not modified.
- Trailer, Live TV playback, and VOD playback settings were not modified.
