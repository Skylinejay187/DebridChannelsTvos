# Debrid Channels tvOS v354

Source-audited correction for overlay DPAD ownership and trailer resolver diagnostics.

- VOD/Live chip strip is one linear Left/Right rail.
- Open chip panels use Up/Down and quick guide cannot steal them.
- Live TV quick guide opens with Up/Down, browses only with Left/Right, and hides with Up/Down.
- Trailer button uses existing backend resolver endpoints only and expects a direct playable MP4/HLS/MOV-style URL.
