# Debrid Channels tvOS v512 — Dynamic Information Bar

Built from v511.

Changes:
- Added Dynamic Information Bar under popup critic cards.
- Rotates Tomato / Critics / Audience / Source / Director or Cast / Mood cards with subtle fades.
- Upgraded top-right advisory badge compact state to rotate advisory + score highlights.
- Kept Search+Link compact chip and v511 theater/playback behavior unchanged.
- No playback engine rewiring in this pass.
