Debrid Channels tvOS v466

Focused build-error repair for v465 catalog priority controls.

Fix:
- Broke the CatalogPriorityButton SwiftUI expression into smaller computed subviews/properties.
- Resolves Xcode type-check timeout at DebridChannelsTVOSApp.swift:6389.

Preserved:
- v465 catalog priority ordering controls.
- v464 rebuilt Search cards.
- Unlimited catalog rows/items.
- Playback, membership, devices, Live TV, guide, favorites, Cloudflare, and backend unchanged.
