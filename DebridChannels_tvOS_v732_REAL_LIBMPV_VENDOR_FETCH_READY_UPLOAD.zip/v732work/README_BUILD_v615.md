# Debrid Channels tvOS v615 — Movie Credits / Franchise Stage Polish

Base: v614 Details Stage Flash/Hint Fix

Changes:
- Movies only: upgraded cast row into a larger Credits showcase with bigger circular headshots, larger names, and role text.
- TV shows: left the compact cast + seasons/episodes layout intact so episodes are not pushed off-screen.
- Movies only: added an Explore the Franchise stage row using available related/linked catalog items. Cards are clickable through the existing related-item focus path.
- Preserved v612/v614 playback and explicit display matching code.
- Did not change membership, sports, trailers backend, backup/restore, or TV show episode layout.

Trailer note:
- Trailer playback remains AVPlayer popup path in this build. KSPlayer/VLC trailer testing should be a separate controlled pass after the Details Stage polish is verified.
