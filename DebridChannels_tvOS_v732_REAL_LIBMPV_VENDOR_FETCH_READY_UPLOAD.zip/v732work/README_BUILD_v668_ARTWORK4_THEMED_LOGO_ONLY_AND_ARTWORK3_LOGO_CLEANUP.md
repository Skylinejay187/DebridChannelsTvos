# DebridChannels tvOS v668

Scope: Artwork 4 Hero 2 themed logo only, plus Artwork 3 Hero ghost cleanup.

Changes:
- Artwork 4 Hero 2 now shows one focused-card themed logo layer above the Streaming Catalogs panel.
- The logo layer uses the already-loaded MediaItem `logoURL` from TMDB/Cinemeta/Stremio catalog data; it does not add fetches or change catalog loading.
- When no logo URL exists, Artwork 4 Hero 2 falls back to title text only.
- Removed the Artwork 3 enlarged ghost/logo shadow layer from the Streaming Catalogs overlay.
- Removed the matching watermark-style ghost layer from the favorites quick panel.

Not changed:
- Backend, AI dashboard, membership, alerts, catalog loading, trailers, playback, Sports, Search, Source Intelligence, and details/media information screens.
- Artwork 4 Hero 2 still hides the underlying Live TV grid cards through the existing top-level overlay gate.
