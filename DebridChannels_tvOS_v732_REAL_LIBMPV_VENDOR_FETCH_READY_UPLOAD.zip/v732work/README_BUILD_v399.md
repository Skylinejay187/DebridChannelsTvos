# Debrid Channels tvOS v399

Trailer long-wait cacheOnly companion app patch for backend v1.8.15.5.

Use with backend_v1.8.15.5_TRAILER_CACHEONLY_LONG_WAIT_FIX.zip.
