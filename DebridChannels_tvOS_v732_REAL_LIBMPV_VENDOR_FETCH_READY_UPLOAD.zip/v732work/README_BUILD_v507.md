# Debrid Channels tvOS v507 — Build Fix + Resume/TMDB + Premium Visual Pass

Base: v506

## Fixes
- Fixed v506 build compiler failures:
  - UniversalVideoSurface argument order.
  - KSPlayer preview missing `seekIsAbsolute` parameter.
  - SwiftUI `Group` generic inference failure in UniversalCodecSupport.
- Restored resume behavior so automatic/manual Resume performs a real KSPlayer jump instead of only updating the time label.
- Kept manual fast-forward/rewind on the in-place seek path to avoid black/stopped KSPlayer surface regressions.
- Preserved TMDB search popup metadata behavior from v506.

## Visual additions
- Added Continue Watching progress/resume badges on search cards and VOD poster cards.
- Added premium popup metadata strip with year/rating/genre/resume/source chips.
- Kept effects lightweight: no smoke/fog, no heavy animation, no navigation rewrites.

## Validation
- Swift parser check passed over all Sources/*.swift.
