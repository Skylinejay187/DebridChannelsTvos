Debrid Channels tvOS v444

Built from v443 isolated trailer safe-fix base.

Changes:
- Live TV grid bottom black reserve removed by extending grid scroll viewport to the bottom edge.
- Card size and row spacing preserved.
- VOD playback, Live TV playback, trailer isolation, Stripe/membership foundation preserved.
