# Debrid Channels tvOS v623

Base: v622 compile fix.

Fixes:
- TMDB search Source Intelligence stays open after links resolve.
- TMDB search details/franchise state is preserved by keeping selected detail identity stable while resolver metadata is used only for link lookup.
- Search posters are locked to card size and fit inside the card instead of expanding/cropping awkwardly.
- External-player default opens directly from selected Source Intelligence link with an immediate Opening status, without routing through the internal/all-player screen.
- VOD playback/display matching untouched.
