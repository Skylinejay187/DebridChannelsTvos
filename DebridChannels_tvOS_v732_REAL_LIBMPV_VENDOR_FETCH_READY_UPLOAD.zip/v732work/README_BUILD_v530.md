Debrid Channels tvOS v530 — Live TV Overlay Logo-Only Cleanup

Base: v529 popup offset/VOD overlay cleanup

Changes:
- Removed Live TV playback overlay channel-title rendering from the main header path.
- Live TV playback overlay now presents the channel logo only, without the extra outlined/channel-name title treatment.
- Program details remain available in the overlay body where appropriate.
- Preserved VOD themed logo behavior, popup cleanup, source rail, settings, Home Grid themes, and Live TV grid background themes.

Validation:
- Swift parse check passed for Sources/*.swift.
