# Debrid Channels tvOS v666 - Trailer Cleanup Restore Normal Tuning

Build name: DebridChannels_tvOS_v666_TRAILER_CLEANUP_RESTORE_NORMAL_TUNING

Base: latest working tvOS source from v662 Artwork 3 Hero Cleanup.

Scope:
- Trailer popup visual/player cleanup only.
- Removed the trailer diagnostics strip from the popup.
- Removed the trailer diagnostics query flag from trailer resolve requests.
- Restored the soft orange/blue glow and cinema sweep behind the trailer popup.
- Restored normal lightweight trailer AVPlayer tuning:
  - 2 second forward buffer.
  - immediate play start.
  - no delayed player build/start gate.
  - no 8 second trailer-only buffer.
  - no forced 1080p trailer cap.
- Removed the slow prepared-trailer polling loop that could leave the popup feeling sluggish.

Preserved:
- Backend files were not modified.
- VOD player settings were not modified.
- Live TV player settings were not modified.
- AI dashboard, membership, alerts, catalogs, Sports, Search, Favorites, and artwork themes were not modified.
