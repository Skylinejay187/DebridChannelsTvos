Debrid Channels tvOS v533

Sports Hub Xtream Mode + Score Ticker Foundation

Changes:
- Added Xtream import mode selection: Full TV, Sports Only, or Both.
- Sports-only Xtream accounts are saved with mode metadata and hidden from the normal Live TV grid refresh path.
- Sports section now includes a score ticker foundation scoped only to Sports.
- Added favorite-team settings/foundation, defaulting to Dallas Cowboys.
- Added favorite team focus rail in Sports Hub.
- Added Sports Sources settings card for import mode, ticker toggle, and favorite teams.
- Preserved v532 Live TV overlay cleanup and Sports Hub foundation.
- Preserved playback/search/settings/popup behavior.

Validation:
- Swift parse check passed across Sources/*.swift.
