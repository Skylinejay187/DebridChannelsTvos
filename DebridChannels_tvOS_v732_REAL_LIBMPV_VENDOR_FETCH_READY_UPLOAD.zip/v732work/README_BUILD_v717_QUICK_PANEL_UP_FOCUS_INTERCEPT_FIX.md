# v717_QUICK_PANEL_UP_FOCUS_INTERCEPT_FIX

Base: v716_V702_ROW_GEOMETRY_FOCUS_CORRECTION

Scope:
- Quick panel / Streaming Catalog row focus routing only.

Fixes:
- UP/DOWN inside the Movies/Shows/Streaming quick panel now stays inside the catalog row system.
- Boundary UP no longer sends focus to the top menu and then bounces back to the quick panel.
- Removed sticky global top-menu lock during Details restore/open so the top menu remains reachable when the quick panel is not active.
- Preserved v716/v714 row visuals, one-row presentation, no ghost row transition, catalog loading/artwork behavior, VOD, trailers, Live TV, membership, sports, and Source Intelligence.
