# Debrid Channels tvOS v297

This build continues from v296 and fixes the remaining AppIcon / Assets.car pipeline problem.

## What changed

- `Resources/Assets.xcassets` is now attached to the XcodeGen target as a resource, not a source file.
- GitHub Actions now regenerates a clean `.xcodeproj`, validates `Assets.xcassets` is present in the project, builds Release for `appletvos`, and hard-fails unless `Assets.car` exists in the final `.app`.
- The workflow runs `xcrun assetutil --info` and checks for `AppIcon` and `DebridChannelsHomeIcon`.
- Loading view now displays `DebridChannelsLoadingScreen` from the compiled asset catalog, with `DebridChannelsHomeIcon` still shown in the loading card.
- Live TV preview box trailing gap was tightened to `0` so it anchors closer to the upper-right safe-area edge.

## Artifact names from GitHub Actions

- `DebridChannelsTVOS_v297_APPICON_ASSETSCAR_RESOURCE_PHASE_FIX.ipa`
- `DebridChannelsTVOS_v297_READY_UPLOAD_REPO_SOURCE.zip`

## Required pass condition

The GitHub Actions log must show:

```bash
test -f "$APP_PATH/Assets.car"
xcrun assetutil --info "$APP_PATH/Assets.car"
```

and the validation step must not fail.
