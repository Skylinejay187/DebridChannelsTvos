Debrid Channels tvOS v454 — Release Polish / Search / Onboarding

Changes:
- Search remains Stremio/Cinemeta/catalog-first and no longer presents TMDB as required.
- TMDB is treated as optional metadata enhancement only.
- Added first-run comic-style onboarding prompts with arrows/callouts.
- Added replay setup option in Settings.
- Removed visible build/version status from normal Settings.
- Removed Quick Navigation developer panel from normal Settings.
- Replaced normal artwork key panel with a clean consumer-facing Artwork & Details status.
- About section now contains polished product messaging.
- Kept membership/device management/favorites/playback paths from v453.
