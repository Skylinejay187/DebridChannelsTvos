# Debrid Channels tvOS v609

Base: v608/v597 player branch.

Changes:
- Restored popup top information bar to left-origin layout.
- Moved advisory badge higher at mid-right to match the good reference.
- Kept v597 VOD overlay/player behavior.
- Broadened KSPlayer native-first routing so signed Debrid/CDN links can use KSAVPlayer first when not clearly MKV/remux/unsupported. This is the path tvOS can use for Match Frame Rate / Match Dynamic Range; KSMEPlayer remains fallback.

Untouched:
- Membership
- Sports
- Trailers
- TVE / Channels DVR
- Backend
