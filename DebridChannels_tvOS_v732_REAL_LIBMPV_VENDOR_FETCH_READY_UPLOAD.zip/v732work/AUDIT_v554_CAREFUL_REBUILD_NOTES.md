# v554 Careful Rebuild Notes

Scope locked to the issues reported after v553:

- Added visible Follow Center settings controls instead of hidden/automatic-only behavior.
- Sports-only M3U event cards now preserve their stream URLs and can launch playback directly from Sports.
- Sports highlight cards now preserve public highlight URLs when providers return them and can open those highlight pages; placeholder cards explicitly report when no public playback URL is available.
- Sports cards now distinguish Watch Live, Open Highlight, Highlight Info, and More Info.
- Kept normal Xtream/M3U sports auto-routing disabled/backlogged.
- Kept trailer/cast/link resolver paths untouched.
- Kept Live TV and Sports-only M3U isolated.

Acceptance checks:
1. Settings -> Follow Center is visible.
2. Sports-only M3U card Select starts playback if the M3U entry has a stream URL.
3. Public ScoreBat highlight card Select opens highlight URL when returned.
4. Non-playable sports cards do not pretend playback exists.
