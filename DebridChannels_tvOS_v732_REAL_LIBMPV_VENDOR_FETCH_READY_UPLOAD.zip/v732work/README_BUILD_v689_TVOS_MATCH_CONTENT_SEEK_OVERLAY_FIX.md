# Debrid Channels tvOS v689 — tvOS Match Content Seek/Overlay Fix

Base: v688 MediaFusion + HDMI + Advisory Fix

Changes:
- AVPlayerViewController now explicitly sets `preventsDisplaySleepDuringVideoPlayback = true`.
- AVPlayerViewController disables `updatesNowPlayingInfoCenter` for custom playback UI when available.
- Added VOD player seeking state so the UI knows when trick-play/seeking is active.
- AVPlayer seeks now:
  - cancel pending seeks before the next seek
  - use tolerant in-place seeks for smoother tvOS behavior
  - do not recreate the player item
  - hold controls visible until seek completes
- KSPlayer fallback seeks set a temporary seeking state but still avoid reload/recreate during normal seeks.
- VOD overlay is rasterized while visible, while panel is open, during scrubbing, and during active seek to reduce alpha-blending/HDR overlay glitches.
- VOD controls panel background is less ultra-transparent while video is playing to reduce GPU compositing over HDR/DV content.
- Preserves v688 MediaFusion, Source Intelligence provider, HDMI guard, and advisory fixes.

Note:
- The provided snippet mentioned `seekingWaitsForVideoFrameProcessing`; tvOS AVPlayerItem exposes `seekingWaitsForVideoCompositionRendering`, so v689 uses the supported AVFoundation property and an explicit `isSeekingInPlayer` state.

Verification:
- swiftc -parse passed across Sources/*.swift.
