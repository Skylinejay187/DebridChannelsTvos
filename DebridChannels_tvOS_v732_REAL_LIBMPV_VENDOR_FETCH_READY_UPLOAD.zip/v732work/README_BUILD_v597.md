# Debrid Channels tvOS v597 — Info Popup Placement + Visible Glass Connector

Built from v596 with trailer popup/back-end behavior untouched.

Changes:
- Moved movie/show info popup lower so it no longer touches or crowds the top metadata bar.
- Kept popup close to original size, only slightly reduced.
- Made the professional glass connector visible by drawing it outside the clipped panel.
- Connector is subtle glass/projection style from the focused bottom poster/card area, not a cartoon tail.
- No halftone dots, no comic speech bubble, no trailer popup changes.
- Backend remains v1.8.15.76 for trailer testing.
