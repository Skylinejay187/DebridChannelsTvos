# Debrid Channels tvOS v683 Build Fix

Base: v683 Artwork 5 Floating Quick Panel Theme

Fix:
- Fixed Release/Xcode compile error caused by adding VOD player focus cases without updating legacy Settings routeSettings exhaustive switches.
- Added vodEngineAVPlayer / vodEngineKSPlayer handling for right/left/down/up legacy focus routes.
- Preserved Artwork 5 Floating, Cinema Gold removal, v682 AVPlayer default VOD, Source Intelligence fixes, and v681 seek fix.

Verification:
- swiftc -parse passed across Sources/*.swift.
