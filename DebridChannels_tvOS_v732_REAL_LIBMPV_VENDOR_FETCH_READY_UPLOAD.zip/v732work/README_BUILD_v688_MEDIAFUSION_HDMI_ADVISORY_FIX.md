# Debrid Channels tvOS v688 — MediaFusion + HDMI + Advisory Fix

Base: v687 Advisory + Cache + MediaFusion + Resume Fix

Changes:
- MediaFusion stream endpoint handling is more patient:
  - manifest timeout extended for MediaFusion
  - stream timeout extended for MediaFusion
  - MediaFusion stream endpoint retries once after a short delay
  - timeout status now clearly says MediaFusion slow endpoint timed out after extended wait
- Source Intelligence provider chips now restore built-in provider chips:
  - Cinemeta
  - Streaming Catalogs
  while still showing active/detected installed addons.
- HDMI Match Content double-switch mitigation:
  - KSPlayer display matching is disabled for VOD so tvOS does not handshake repeatedly during VOD seek/start.
  - AVPlayer waits for readyToPlay before play() to reduce pre-start/final-item HDMI handshakes.
  - AVPlayer manual selection does not rebuild the player if the same URL is already active.
- Advisory banner:
  - removed sideways ADVISOR text
  - advisory stays visible while top media info bar is visible
  - adds visible Rotten Tomatoes category/fact fallback when OMDb data is not available
  - keeps real Rotten Tomatoes/IMDb path through OMDb when OMDB_API_KEY is configured
  - keeps icon-based advisory facts.

Verification:
- swiftc -parse passed across Sources/*.swift.
