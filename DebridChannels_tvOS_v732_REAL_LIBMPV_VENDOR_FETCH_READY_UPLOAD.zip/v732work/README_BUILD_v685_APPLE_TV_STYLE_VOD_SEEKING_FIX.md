# Debrid Channels tvOS v685 — Apple TV Style VOD Seeking Fix

Base: v684 Artwork 4/5 Floating + Source Intelligence Layout Fix

Changes:
- Added a focusable VOD timeline/time bar.
- Press Up/Down from the VOD controls to focus the timeline.
- When the timeline is focused:
  - Left/Right scrubs backward/forward along the timeline.
  - Select commits the seek.
  - Up/Down exits back to regular playback controls.
- Back 30 / Forward 30 and timeline seeks now avoid player reload/recreate during normal VOD seek.
- KSPlayer fallback no longer uses reload/start-time for normal skip/seek, preventing repeated HDMI Match Frame Rate / Match Dynamic Range handshakes.
- Resume still uses the guaranteed startup seek path.
- AVPlayer seeks use tolerant in-place seek for smoother Apple TV style behavior.
- VOD time bar shows preview progress while scrubbing.
- Preserved v684 Artwork 4/5 floating fixes, v683 build fix, v682 AVPlayer default VOD, and v681 seek fix intent.

Verification:
- swiftc -parse passed across Sources/*.swift.
