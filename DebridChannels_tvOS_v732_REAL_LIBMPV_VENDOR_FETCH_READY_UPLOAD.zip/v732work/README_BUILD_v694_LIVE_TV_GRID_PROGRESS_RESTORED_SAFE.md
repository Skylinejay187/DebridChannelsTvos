# Debrid Channels tvOS v694 — Live TV Grid Progress Restored Safely

Base: v693 Build-Stable VOD Focus/Seek Fix

Changes:
- Restored subtle Live TV grid program progress bars.
- Implemented progress bar in a separate tiny Swift file:
  - `Sources/LiveTVProgramProgressLine.swift`
  This avoids adding another heavy SwiftUI view into the already-large app source file.
- Progress behavior:
  - Appears only when the current EPG program has real start/end Date values.
  - Unfocused cards show a very faint 2px line.
  - Focused card shows a brighter 4px cyan line.
  - Uses existing `LiveProgram.liveProgress`.
- Added a 30-second Live TV progress tick so the bars update while browsing.
- Restored Settings > Live TV toggle:
  - `Live TV Card Progress Bar`
- Preserved VOD fixes:
  - Timeline is not in horizontal chip order.
  - VOD chips remain selectable.
  - Up/Down enters timeline scrub mode.
  - Left/Right scrubs.
  - Select commits seek and returns focus to Play/Pause.

Verification:
- swiftc -parse passed across Sources/*.swift.
