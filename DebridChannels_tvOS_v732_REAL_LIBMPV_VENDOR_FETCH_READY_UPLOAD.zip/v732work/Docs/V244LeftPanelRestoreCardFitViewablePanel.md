# V244 Left Panel Restore + Card Fit + Viewable Panel

Base: v243 LEFT_PANEL_EDGE_PANEL_BACKDROP_FILL_FIX.

Changes:
- Restored forced-left side panel behavior so first LEFT from the first tile in any Live TV grid row arms the edge and keeps tile focus; second LEFT opens the hidden side panel.
- Added focus reassertion after the first LEFT so tvOS cannot escape to the top menu and disable the side-panel action.
- Kept the existing left panel contents/categories and Force Refresh Guide behavior.
- Updated build marker to v244.
- Made Live TV grid artwork fill its grid card instead of letterboxing.
- Made Movies/Shows panel more viewable by increasing panel rail space and enlarging focused/preview cards.
- Kept focused-card backdrop behavior; no random poster rotation and no smoke/ambient effect restoration.

Preserved:
- Poster loading fixes.
- Playback behavior.
- Guide preview audio/single-stream behavior.
- v228-style performance baseline.
