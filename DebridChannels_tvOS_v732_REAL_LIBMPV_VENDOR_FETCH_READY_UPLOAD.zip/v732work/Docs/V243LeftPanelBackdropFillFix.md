# v243 Left Panel Edge + Backdrop Fill Fix

Careful targeted rebuild from v242.

- Fixed Movies/Shows panel focused artwork so it fills the panel background using clear high-quality fill cropping instead of appearing as a centered fitted image.
- Added grid-tile-level DPAD move handling so forced-left side-panel behavior can trigger while a first card owns focus.
- First LEFT from first card in any row arms the edge and keeps focus on that card.
- Second LEFT opens the hidden left panel.
- Preserved left panel categories, Force Refresh Guide, poster loading, playback, guide preview, no smoke effects, and no random poster rotation.
