# v234 Effect Deletion Audit

Base: v233 effect rollback build.

Purpose:
- Remove the background smoke/ambient/effect system from the active app code instead of only hiding it.
- Preserve v233 behavior otherwise, including focused-card wallpaper in Movies/Shows panel, poster loading fixes, focus containment, guide preview audio, and single-stream preview behavior.

Deleted from active Swift source:
- CinematicAmbientBackground
- AmbientEffectsLayer
- SmokeLayer
- DenseSmokeLayer
- ExtraVisibleSmokeLayer
- FocusedSmokeOverlay
- LightweightCinematicBackground
- Timeline-driven smoke/fog animation layer

Replaced with:
- StaticAppBackground: a non-animated dark static background.

Updated active surfaces:
- Settings uses StaticAppBackground.
- Live TV background uses StaticAppBackground plus the existing simple channel accent/gradient only.
- Media detail popup no longer mounts the removed cinematic/effect layer.
- Movies/Shows panel keeps focused-card backdrop, but does not use the removed animated effect stack.
