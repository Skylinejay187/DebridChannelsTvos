# V233 Effect Rollback Audit

Base: v232 focused-card panel backdrop fix.

Rollback scope: visual/effect layer only.

Kept from current branch:
- focused-card wallpaper inside Movies/Shows panel
- no random rotating poster panel background
- poster loading recovery
- overlay/focus containment fixes
- guide preview audio/single-stream behavior
- large-lineup guide work

Rolled back toward v228 style:
- removed premium cinematic depth modifier stack
- removed extra frosted/duplicate effect surface on media popup
- restored lightweight ambient background behavior
- reduced heavy cyan bloom/shadow layers
- restored simpler SafeCardScrollMotion scale/shadow behavior

Goal: recover app/video performance while preserving latest functional changes.
