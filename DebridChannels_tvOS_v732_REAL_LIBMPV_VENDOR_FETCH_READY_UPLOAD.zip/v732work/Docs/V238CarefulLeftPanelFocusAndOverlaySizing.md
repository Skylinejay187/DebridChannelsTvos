# v238 Careful Left Panel Focus + Overlay Sizing Pass

Base: v237 compile-fix branch.

Changes:
- Fixed left grid/category panel focus routing by no longer swallowing UP/DOWN while the panel is open.
- Added a real vertical scroll area for the hidden left panel category list.
- Kept LEFT/RIGHT as panel-close gestures.
- Kept the panel hidden by default and opened only from the first card in a row.
- Made the combined left panel compact instead of full-height.
- Force Refresh Guide now re-runs the configured Live TV guide refresh and restores the grid to All/first channel after refresh.
- Reduced Movies/Shows overlay height slightly while allowing the focused landscape card more measured space so expansion does not clip.

Preserved:
- Smoke/ambient effects remain deleted.
- Random poster background remains removed.
- Focused-card panel backdrop remains the source for Movies/Shows.
- Poster loading, playback, guide preview, and v228-style performance baseline remain preserved.
