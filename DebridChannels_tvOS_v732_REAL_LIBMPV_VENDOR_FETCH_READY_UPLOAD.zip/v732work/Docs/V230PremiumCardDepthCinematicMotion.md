# v230 Premium Card Depth / Cinematic Motion Pass

Built from v229. This pass keeps the v229 main-background fix while adding a deeper visual system for the Grid OS and Movies/Shows overlay.

Implemented:
- PremiumCardDepthMotion shared modifier for card pop, edge light, bloom, shadow elevation, brightness, saturation, and subtle 3D tilt.
- CinematicDepthSurface shared modifier for frosted/translucent popup and panel surfaces.
- Stronger animated smoke/fog presence in lightweight cinematic background surfaces.
- Live TV background now has stronger ambient/smoke depth and focus-reactive channel accent glow without reintroducing random movie/show poster artwork to the main grid background.
- Movies/Shows quick panel retains the random poster backdrop behavior inside the panel only.
- Focused Movies/Shows slot cards now use the premium card-depth pass instead of only scale/shadow.
- Live TV grid cards now use the same premium depth modifier for a stronger “cards floating off the glass” effect.

Preserved from prior builds:
- v222/v223/v229 poster URL recovery.
- Top Movies tab remains in the main menu.
- The extra Movies item remains removed from the Live TV category row.
- Force Refresh Guide panel remains hidden until LEFT from the first grid card.
- Guide preview single-stream/debounce behavior and audio remains preserved.
- Overlay focus containment remains preserved.
