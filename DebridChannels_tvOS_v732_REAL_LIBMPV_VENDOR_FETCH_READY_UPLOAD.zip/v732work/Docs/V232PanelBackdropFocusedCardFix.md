# v232 Panel Backdrop Focused Card Fix

Careful cleanup from v231.

Changes:
- Removed timed random poster rotation from Movies/Shows quick panel.
- Movies/Shows panel backdrop is now driven by the currently focused slot card.
- Panel is no longer transparent over the Live TV grid.
- Removed the background poster id/transition/scale behavior that caused expand-then-shrink flashes.
- Reduced panel scroll height to prevent the surface from feeling too tall.
- Increased row measurement and removed extra focused-card scale so the focused landscape card stays inside bounds and does not clip.
- Preserved poster loading, focus containment, Live TV preview audio, single-stream preview behavior, and prior compile fixes.
