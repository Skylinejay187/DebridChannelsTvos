# v245 Workflow Routing Fix

The uploaded build log was not a Swift/tvOS compile failure. GitHub ran an Android APK ZIP workflow (`build-apk-from-zip`) against the tvOS package and rejected it because it was looking for `settings.gradle` and `app/build.gradle`.

This package keeps the v244 source and adds/updates a tvOS macOS workflow, including a compatibility workflow at `.github/workflows/build-apk-from-zip.yml` so replacing the old Android workflow path will route to the tvOS IPA build instead.

No UI behavior changes were made in this package.
