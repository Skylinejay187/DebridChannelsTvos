# V242 Careful Fix Audit

Base: v241/v240 lineage.

Fixes:
- Updated visible/logcat build markers to v242.
- Restored side panel category contents while preserving forced-left behavior.
- LEFT from first card arms edge first; second LEFT opens panel without debounce blocking.
- Left panel focuses selected category when opened so items are selectable/clickable.
- Force Refresh Guide remains in the same panel and keeps its refresh action.
- Movies/Shows panel height increased from the too-low v241 value while staying below the earlier oversized panel.
- Focused-card panel background uses fit mode, clear/non-blurred display, and no random rotation.
- Movie/show focused and preview cards use fit mode inside fixed frames to avoid uneven cropping/clipping.

Preserved:
- No smoke/ambient effects restored.
- No random poster backdrop restored.
- Playback/preview/poster loading/focus containment changes preserved.
