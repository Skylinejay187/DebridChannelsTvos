# V225 Live Preview Single Stream + Focus Stability Audit

Base: v224 Live Ambient + Overlay Focus Containment.

Changes:
- Preserved v222/v223 poster URL recovery and v224 overlay focus containment.
- Kept Movies in the top main menu and kept Movies removed from the Live TV category row.
- Kept Live TV cinematic ambient/smoke background active.
- Rebuilt the silent preview player lifecycle so AVPlayer instances are paused, detached, and cleaned up when the preview URL changes or the view is removed.
- Added guide-preview debounce/warmup so scrolling through guide rows does not immediately open a new stream for every focused row.
- Live preview now only starts while the full guide preview area is active; the Live TV grid itself does not silently launch multiple preview streams.
- The preview window shows a safe placeholder while waiting for the user to settle on a guide row, then starts one selected preview stream.

Reason:
Channels DVR status showed many remux/transcode sessions because rapid focus changes could create preview player instances faster than old instances were released. V225 adds a single-stream preview lifecycle and delayed preview activation.
