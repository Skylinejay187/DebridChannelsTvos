# v239 Forced Left Panel + Panel Height Audit

Base: v238 LEFT_PANEL_SCROLL_FORCE_REFRESH_PANEL_SIZE_FIX

Changes made carefully for the requested correction:

- Removed the visible category-control content from the left utility panel path; the hidden panel is now focused on Force Refresh Guide only.
- Left utility panel does not open on the first LEFT edge movement.
- LEFT behavior now mirrors the full-guide RIGHT behavior:
  - first LEFT from the first card in any row arms the left edge only;
  - second intentional LEFT opens the hidden panel.
- Force Refresh Guide remains inside the hidden panel and still calls `liveModel.forceRefreshGuide()`.
- Movies/Shows panel height was reduced to match the shorter screenshot target.
- Movies/Shows panel focused-card backdrop remains driven by the focused card, with no blur and no random rotating poster background.
- Smoke/ambient effects remain removed.
- Poster loading, playback, guide preview behavior, and v228-style performance baseline are preserved.

No intentional playback/player pipeline changes were made in this pass.
