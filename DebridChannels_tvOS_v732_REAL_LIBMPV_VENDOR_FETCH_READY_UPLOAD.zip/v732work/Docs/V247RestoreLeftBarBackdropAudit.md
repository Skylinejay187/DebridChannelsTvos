# v247 Restore Left Bar + Backdrop Audit

Base: v246 tvOS workflow replacement/source state.

Changes:
- Restored the hidden left bar behavior with categories plus Force Refresh Guide.
- Preserved forced-left behavior: first LEFT from a first-column grid card arms the edge; second LEFT opens the left bar.
- Added selected-channel fallback so left-edge detection still works when tvOS drops tile focus briefly.
- Reasserted tile focus after the first LEFT so the panel does not become disabled.
- Made Movies/Shows panel use the focused card artwork as a clear fill wallpaper.
- Increased Movies/Shows panel viewing height moderately and kept random poster rotation/smoke effects removed.
- Adjusted Live TV grid artwork to fill the full card with footer metadata overlaid, avoiding centered/non-filled posters.

Preserved:
- Top menu behavior.
- Playback pipeline.
- Single-stream guide preview/audio behavior.
- Poster URL recovery helpers.
- v228-style non-smoke performance baseline.
