# v226 Performance / Focus / Preview Audit

Base: v225 Live Preview Single Stream Fix.

Changes:
- Live guide preview uses audible preview playback instead of muted background preview.
- Preview remains debounced and single-stream from v225.
- Live grid/guide rendering is virtual-windowed so very large channel lists do not instantiate every row/card at once.
- Grid artwork loading is restricted to the focused channel neighborhood to reduce network/image pressure on large lineups.
- Movies/Shows overlay gets a rotating ambient poster backdrop every 10 seconds using existing catalog artwork.
- Top menu and Movies/Shows shelf are disabled from focus while MediaInfoPopup is open.
- MediaInfoPopup aggressively reclaims focus until Back/Menu closes it.
