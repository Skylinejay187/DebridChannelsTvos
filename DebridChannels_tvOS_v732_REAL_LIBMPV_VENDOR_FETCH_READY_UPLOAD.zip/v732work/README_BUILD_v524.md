Debrid Channels tvOS v524
- Removed bottom poster rail from Premium Browse popup.
- Kept Explore More / Media DNA summary cards only.
- Prevented DPAD focus from moving into the removed poster rail.
- Preserved source rail, popup containment, VOD overlay cleanup, home grid themes, playback/search/settings behavior.
