# Debrid Channels tvOS v500

Targeted build on top of v499.

## Included
- Search narrowed to TMDB + Cinemeta only.
- Search no longer shows Live TV results or scans every configured addon.
- Cinemeta search uses a limited Cinemeta-only catalog query for speed.
- Settings redesigned into tvOS-style grouped cards with category rows.
- Viewer Advisory badge polished to remove the bright white tvOS card look and improve gold/orange text visibility.
- Build marker updated to v500.

## Notes
- Existing working playback, resume cache, Live TV grid/guide, and VOD detail behavior are preserved.
- Poster fallback remains additive: TMDB/Cinemeta are now prioritized in Search to reduce missing artwork caused by random addon catalog cards.
