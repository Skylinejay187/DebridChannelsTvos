# Debrid Channels tvOS v503 — Instant Search Popup + Advisory Focus Fix

Base: v502_VOD_OVERLAY_WIDE_CHIPS

Changes:
- Search result selection now opens the movie/show popup immediately.
- Slow resolver metadata hydration now runs in the background after the popup opens.
- Trailer prewarm/resolution no longer starts automatically when details open.
- Trailer resolving starts only when Trailer/YouTube is selected.
- Viewer Advisory badge is no longer a focusable Button, preventing the tvOS white focus/platter card from appearing around it during link searches.
- Build marker updated to v503.

Validation:
- swiftc -parse passed for all Swift source files.
