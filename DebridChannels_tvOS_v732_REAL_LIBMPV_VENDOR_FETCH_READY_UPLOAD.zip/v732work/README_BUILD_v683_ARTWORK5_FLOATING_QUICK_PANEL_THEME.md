# Debrid Channels tvOS v683 — Artwork 5 Floating Quick Panel Theme

Base: v682 AVPlayer Default VOD + Source Intelligence Fix

Changes:
- Added new Live TV Grid Background theme: Artwork 5 Floating.
- Artwork 5 uses the Artwork 3 Hero subject-pop/depth treatment for the focused poster/backdrop.
- Artwork 5 makes the Movies/Shows/Streaming Catalog quick panel shell fully transparent.
- In Artwork 5, catalog cards appear to float with no visible black/glass panel behind them.
- Removed Cinema Gold from theme lists.
- Preserved Artwork 3 Hero and Artwork 4 Hero 2 behavior.
- Preserved v682 AVPlayer/default VOD and Source Intelligence fixes.

Compile check:
- swiftc -parse passed across Sources/*.swift.
