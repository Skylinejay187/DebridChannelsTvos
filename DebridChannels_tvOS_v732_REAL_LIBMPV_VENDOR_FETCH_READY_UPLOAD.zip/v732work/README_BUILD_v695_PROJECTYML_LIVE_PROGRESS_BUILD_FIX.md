# Debrid Channels tvOS v695 — Project YAML Live Progress Build Fix

Base: v694 Live TV Grid Progress Restored Safe

Fix:
- v694 added `Sources/LiveTVProgramProgressLine.swift`, but `project.yml` uses an explicit source file list.
- The new Swift file was not listed in `project.yml`, so Xcode did not compile it in Release.
- Added:
  - `Sources/LiveTVProgramProgressLine.swift`
  to the `DebridChannelsTVOS` target source list.

Preserved:
- Live TV grid progress bars:
  - focused card brighter/thicker
  - other cards faint/subtle
  - 30-second refresh tick
  - Settings toggle
- VOD seek/focus fixes.

Verification:
- swiftc -parse passed across Sources/*.swift.
