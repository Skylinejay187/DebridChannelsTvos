# Debrid Channels tvOS v575_iCloud_CLEAR_AND_SOURCE_SPEED_FIX

Careful scope-locked rebuild from v574 compile-fix base.

## Added
- Settings → iCloud Backup & Restore → Clear iCloud Backup.
- Clear deletes only the iCloud backup blob/date from NSUbiquitousKeyValueStore and leaves local settings untouched.

## Fixed
- Restored faster Source Intelligence loading with bounded manifest/stream request timeouts.
- Episode card searches now use exact episode IDs first.
- Multi-season shows fall back to parent-series stream endpoints only with strict S/E title matching, preventing neighboring episode links from appearing.
- Movie searches keep the normal broad fast path and are no longer forced through episode-only filtering.

## Preserved
- Source Intelligence UI.
- Playback/trailer behavior.
- Live TV behavior.
- Hero popup visuals and episode rail layout.

## Verification
- Swift parse check passed with `swiftc -parse Sources/*.swift`.
