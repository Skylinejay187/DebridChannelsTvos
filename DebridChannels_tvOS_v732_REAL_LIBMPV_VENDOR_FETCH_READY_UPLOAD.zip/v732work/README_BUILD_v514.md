Debrid Channels tvOS v514 — Premium Browse Backdrop + Cast Wall Polish

Base:
- Continued from v513_PREMIUM_BROWSE_POSTER_SOURCE_DNA.
- Theater Mode remains retired.
- No player replacement and no playback engine rewiring.

Changes:
- Added expanded cinematic backdrop treatment behind the popup panel when landscape artwork exists.
- Enlarged and spaced the cast wall for a cleaner premium browse look.
- Reduced duplicate small metadata chip count so the popup breathes more.
- Kept Continue Watching poster stack, Source Intelligence, Media DNA v2, and Dynamic Information Bar from prior builds.

Stability:
- Playback/search/settings paths preserved.
- Swift parser check passed across Sources/*.swift.
