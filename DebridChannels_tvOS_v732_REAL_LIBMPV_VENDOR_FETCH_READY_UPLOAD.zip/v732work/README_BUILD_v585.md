# Debrid Channels tvOS v585 — Membership Device Allowance Copy

Scope: UI copy/card update only.

Changes:
- Membership screen now clearly explains device allowances:
  - Trial: 1 device
  - Supporter / Continue Support: 2 devices for one year
  - Lifetime / Full Unlock: 3 devices with no timer
- Supporter and Lifetime cards now include visible device-count badges.
- Checkout helper text repeats the tier/device limits before payment.

Preserved:
- v584 24-hour trial logic
- Supporter 1-year timer
- Lifetime no-timer logic
- Existing backend device cap enforcement
- Owner unlock
- Live TV, guide, sports, playback, trailers, backup systems untouched

Build note:
- Source package only; Xcode/tvOS compile cannot be run in this Linux sandbox.
