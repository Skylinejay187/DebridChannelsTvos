# Debrid Channels tvOS v475

Focused trailer playback fix only.

- Keeps Kino/yt-dlp/backend remux-cache HQ trailer path.
- Trailer popup now passes HTTP headers to AVURLAsset.
- AVPlayer no longer waits for readyToPlay before issuing initial play.
- Disables trailer AVPlayer stall-wait mode for verified MP4 remux-cache URLs.
- Adds spaced rescue play kicks for loading-but-not-starting trailer cases.
- Does not touch Live TV, guide, search, catalog priority, membership, devices, favorites, or backend.
