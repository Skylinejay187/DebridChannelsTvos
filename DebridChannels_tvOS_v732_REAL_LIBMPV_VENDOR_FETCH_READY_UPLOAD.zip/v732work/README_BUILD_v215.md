# Debrid Channels tvOS v215 — Grid OS Video Cleanup

Built from the v212 Grid OS experiment with a slower cleanup pass focused on the video issues:

- Live TV grid remains the main operating surface.
- Legacy top menu is removed from the Grid OS surface.
- Unified left Grid OS rail provides All, Live TV, Movies, TV Shows, Search, Settings, and content filters.
- Left rail auto-hides and reappears from LEFT navigation.
- Grid expands when the rail hides.
- Catalog overlays remain layered on top of the live grid.
- Media info popup flow remains preserved.
- Guide remains an expanded secondary mode.
- Build marker updated to v215.
