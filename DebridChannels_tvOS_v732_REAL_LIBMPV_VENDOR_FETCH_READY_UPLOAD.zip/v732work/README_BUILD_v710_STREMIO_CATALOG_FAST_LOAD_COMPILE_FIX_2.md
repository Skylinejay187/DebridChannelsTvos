# v710_STREMIO_CATALOG_FAST_LOAD_COMPILE_FIX_2

Compile-only follow-up.

Fix:
- Changed `.clipped(false)` to `.clipped(antialiased: false)`.

No behavior changes intended.
