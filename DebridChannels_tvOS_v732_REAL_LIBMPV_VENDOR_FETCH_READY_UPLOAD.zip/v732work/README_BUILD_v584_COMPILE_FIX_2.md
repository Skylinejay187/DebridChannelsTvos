# Debrid Channels tvOS v584 Compile Fix 2

Base: `DebridChannels_tvOS_v584_COMPILE_FIX_READY_UPLOAD`

## Fix
The GitHub/Xcode build log still reported Swift floating-point `%` compile errors in playback remaining-time helpers.

Patched all Double-based remaining-time calculations to use:

`remaining.truncatingRemainder(dividingBy: 3600)`

Kept the membership/trial display helper on integer `%` because that value is already converted to `Int`.

## Scope preserved
- Membership 24-hour trial logic preserved
- Supporter 1-year tier preserved
- Lifetime/no-timer tier preserved
- Device cap messaging preserved
- Live TV untouched
- Guide untouched
- Sports untouched
- Playback behavior untouched except compile-safe formatting helpers
