# Debrid Channels tvOS v620 — Resume Bar + Last Source + Live Diagnostics Expansion

Base: v619_DETAILS_STAGE_LEFT_LIVE_DIAGNOSTICS

Changes:
- Added Details Stage resume progress bar under Play when saved progress exists.
- Play now prefers the last successfully selected direct source/link for that movie/episode when that link is still available after resolving.
- Saved selected stream source whenever a user launches a direct link from Source Intelligence.
- Increased Details Stage backdrop/poster visibility by another 5%.
- Moved show Details Stage content slightly upward to protect the episode cards from bottom clipping.
- Expanded Live TV diagnostics with video/audio/scan/drift placeholder fields for CBS/Fox comparison.

Untouched:
- VOD playback/display matching path.
- Membership.
- Sports.
- Trailer system.
- Backend.
