# Debrid Channels tvOS v488

Compact Header + Live TV Theme Polish

Changes:
- Restored movie/show popup header to compact top-bar style.
- Kept backdrop/logo/metadata visible while using less vertical space.
- Related row now supports one more visible poster with equal card math.
- Related poster cards standardized with blue focus ring/glow.
- Live TV grid, left guide tools panel, and guide hero received visual-only polish.
- No playback, trailers, search, membership, onboarding, backend, or navigation logic changes.

Validation:
- Swift parse check passed.
