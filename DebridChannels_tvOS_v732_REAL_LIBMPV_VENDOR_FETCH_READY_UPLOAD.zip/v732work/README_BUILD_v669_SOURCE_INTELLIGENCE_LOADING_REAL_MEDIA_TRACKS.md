# DebridChannels tvOS v669

Scope: Source Intelligence loading state, real media track display for selected streams, VOD audio/subtitle metadata, and a Settings reminder for smoother VOD internal playback.

Changes:
- Source Intelligence now shows an immediate "Opening stream..." overlay with the selected provider/source name for internal-player source activation.
- Duplicate Source Intelligence link activation is blocked while a stream is opening.
- Opening state clears on playback handoff, back/cancel, or external-player callback.
- Source Intelligence cards/details use async AVFoundation media-selection probes for real audio and subtitle metadata when a direct stream exposes it.
- Unavailable real metadata displays as Audio: Unknown and Subtitles: None detected.
- VOD audio/subtitle menus now use normalized real track labels from AVAsset audible/legible media-selection groups, with subtitles Off preserved as a first-class option.
- Last selected VOD audio/subtitle labels are saved per media item when real tracks are available.
- Added Settings text reminder: "Tip: For the smoothest internal-player VOD playback, enable Match Dynamic Range and Match Frame Rate in Apple TV Settings."

Not changed:
- Backend AI dashboard, membership, alerts, catalog artwork themes, Artwork 3/4 visuals, trailers, Live TV playback, Sports, Search, and details/media information layout.
