# v720_MEDIA_INFO_ARTWORK_STATE_RESET

Base: v719_POSTER_RT_SEASON0_FIX.

Changes:
- Media Information popup now gets a fresh SwiftUI identity per media item and artwork URL.
- Details Stage backdrop image is keyed by media id + backdrop URL.
- Top media-info portrait poster is keyed by media id + poster URL.
- RemoteImageFit now tags displayed images with the active URL and refuses to render stale bitmaps when SwiftUI reuses an image view.
- RemoteImageFit clears old image/imageURL immediately before cache/network lookup for a new URL.

Preserved:
- v718 quick-panel focus ownership fix.
- v702 row geometry behavior.
- v719 Season 0 filtering and Rotten Tomatoes placeholder removal.
- Catalog loading/artwork stability.
- VOD, trailers, Live TV, membership, backend, sports untouched.
