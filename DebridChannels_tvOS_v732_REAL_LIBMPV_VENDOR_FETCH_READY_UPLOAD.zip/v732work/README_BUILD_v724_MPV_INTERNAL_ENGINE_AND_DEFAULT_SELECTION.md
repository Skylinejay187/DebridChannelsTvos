# v724 MPV Internal Engine And Default Selection

Base: `v723_AVPLAYER_AUTO_KSPLAYER_FALLBACK_SINGLE_ROW_CHIPS`

Changes:
- Adds `MPVPlayerViewModel`, `MPVRenderView`, and `MPVVideoPlayer` scaffolding for a real internal MPV route.
- Keeps AVPlayer as the default VOD engine unless the user selects KSPlayer or MPV.
- Adds Settings support for `AVPlayer`, `KSPlayer`, and `MPV` as the default VOD engine.
- If `MPVKit` is not compiled in, the MPV default option is marked unavailable and VOD falls back to AVPlayer.
- AVPlayer unsupported-container/codec failures now auto-fallback to KSPlayer or MPV based on compiled availability and stored preference.
- Diagnostics report MPV as `Active Engine: MPV`, `Decoder: libmpv/ffmpeg`, `Subtitle Renderer: libass`, `Playback Renderer: CAMetalLayer`.

Notes:
- No MPV binary/framework was present in this workspace at implementation time, so project dependency wiring for a real `MPVKit.framework` or `.xcframework` could not be added here.
- The MPV integration is compile-guarded and runtime-probed. Once a compatible MPV wrapper is added to the project, the v724 engine path becomes available without changing AVPlayer or KSPlayer defaults.
- Local Apple build tools were not available in this environment, so `xcodegen`/`xcodebuild` verification could not be run.
