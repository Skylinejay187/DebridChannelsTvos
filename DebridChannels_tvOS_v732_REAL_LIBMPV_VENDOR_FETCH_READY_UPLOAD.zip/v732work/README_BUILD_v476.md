Debrid Channels tvOS v476 - Trailer AVPlayer Compile Fix

- Fixed v475 compile failure by importing AVFoundation explicitly.
- Replaced AVURLAssetHTTPHeaderFieldsKey symbol with string asset option key for tvOS compiler compatibility.
- Kept the trailer playback rescue/start behavior from v475.
- No backend, search, membership, Live TV, guide, favorites, catalog, or onboarding changes.
