# Debrid Channels tvOS v570 — Top Bar Poster Artwork Polish

Scope locked to the media information header only.

Changes:
- Replaced duplicate clearlogo in the top media information bar with compact portrait poster artwork.
- Kept the large clearlogo inside the hero popup as the main identity element.
- Poster prefers item.posterURL first for highest-quality portrait artwork, with landscape fallback only if no poster exists.
- Added premium rounded poster frame, soft highlight, and shadow treatment.
- Preserved all metric chips: budget, revenue, runtime, release, studio, rating, genre / show metadata.
- Preserved Source Intelligence, playback, trailer, popup navigation, seasons, episodes, and Live TV background behavior.

Validation:
- Swift source patch applied only to PopupExtendedMetadataHeader and new HeaderPosterArtwork view.
- No Source Intelligence or playback wiring changed.
