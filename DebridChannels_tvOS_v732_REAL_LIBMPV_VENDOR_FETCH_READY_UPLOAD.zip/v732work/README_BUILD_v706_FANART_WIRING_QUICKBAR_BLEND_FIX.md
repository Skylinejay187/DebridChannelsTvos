# v706 Fanart Wiring + Quickbar Blend Fix

Scoped fixes:
- Catalog rows now resolve Cinemeta/Stremio IMDb/TMDB ids through TMDB and then apply Fanart.tv artwork when a Fanart key is set.
- Fanart is no longer limited to TMDB-created rows only.
- Movies/Shows/Home quick catalog overlay keeps the clean single-active-row presentation while restoring Up/Down row navigation.
- Focused quick-card artwork uses a fit-over-blur composition to avoid the zoomed/cropped look.
- Floating quick panel now has a subtle premium bottom glass blend so title/metadata/cards blend into hero art.

Preserved:
- Live TV focused-only red progress bar and focus-ring fixes.
- VOD playback, trailers, Source Intelligence, membership, sports, backend behavior, and settings layout.
