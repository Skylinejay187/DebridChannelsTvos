# v398 trailer resolver correction

The user log showed repeated yt-dlp jobs for the same title even after v395. The app-side lock was keyed by provider/catalog item ID, so the same movie from different identities bypassed the lock.

Required behavior:
- normalize trailer lock/cache keys by title + year + type
- initial request uses fast 1080p only
- polling must be cacheOnly=true and must never trigger another yt-dlp job
- backend raw yt-dlp entry points should also share a process-level single-flight map by the same normalized key

Expected log after fix:
- one `yt-dlp search start` for `Obsession 2026 official trailer`
- duplicates should log cache/single-flight wait/reuse, not another extract
- no `prefer4k: true` during initial trailer popup load
