# v395 Trailer Single-Flight Backend Handoff

The provided log showed repeated yt-dlp `search start` and `extract start` lines for the same title. v395 adds a process-local single-flight guard so the first request owns the yt-dlp job and duplicate requests wait for the cache result.

Expected backend behavior after integrating this helper:

- First request for a trailer key starts one yt-dlp job.
- Duplicate requests for the same title/year/type do not start another yt-dlp job.
- Waiting duplicates return the cached `playbackUrl` after the owner finishes.
- 4K should not run during initial popup open; use 1080p/cache-first for fast startup.

The tvOS app now sends:

- `singleFlight=true`
- `prefer4k=false`
- `maxHeight=1080`
- `reuseCache=true`
- User-Agent: `DebridChannels-tvOS/395 TrailerResolver-SingleFlight`
