# v394 Trailer Fast Cache Patch

This patch is intentionally limited to trailer startup latency.

What changed:
- App asks backend for cached/fast 1080p playback first instead of forcing 4K first.
- App stores successful trailer playback URLs locally by title/year/type/id so reopening the same trailer is instant.
- Backend helper now includes a small JSON resolve cache and returns cached playback URLs before running yt-dlp again.
- yt-dlp selector prefers muxed MP4/1080p first to avoid slow split video/audio remux for every popup.
- 4K is still possible as fallback, but not allowed to block the first trailer popup.

What was not touched:
- Rows
- Search Links resolver wiring
- VOD overlay timing
- Trailer popup cinema animation
- Premium icons / Top Shelf assets
- Live TV
- AVPlayer/player systems
