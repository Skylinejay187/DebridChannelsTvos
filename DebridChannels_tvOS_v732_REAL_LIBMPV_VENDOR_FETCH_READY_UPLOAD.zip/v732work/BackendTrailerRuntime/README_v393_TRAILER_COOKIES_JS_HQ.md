# v393 backend trailer runtime handoff

This v392-based tvOS package does not contain the full backend tree, so backend changes are provided as a drop-in helper under `BackendTrailerRuntime/`.

Backend target behavior:
- use `yt-dlp` with the backend's existing `cookies.txt` path when YouTube requires cookies;
- allow optional Node/JS runtime support for YouTube signature/player extraction;
- prefer 4K trailers when available, otherwise 1080p+, otherwise best available;
- keep returning a single backend-remuxed `playbackUrl` / `previewUrl` for tvOS.

The tvOS resolver request now sends `prefer4k=true&minHeight=1080&allow4k=true` to the existing trailer endpoints. The popup/player path itself was not replaced.
