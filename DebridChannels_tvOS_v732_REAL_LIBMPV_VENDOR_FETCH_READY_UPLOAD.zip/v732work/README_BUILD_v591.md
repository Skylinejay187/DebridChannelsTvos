# Debrid Channels tvOS v591 — Trailer Deep Smooth AVPlayer Popup

Base: v590_TRAILER_SMOOTH_AVPLAYER_POPUP_FIT

Scope: Trailer popup only.

Changes:
- Trailer popup keeps AVPlayer, but now builds AVURLAsset, AVPlayerItem, and AVPlayer on a dedicated background queue.
- Preloads tracks/playable/duration off the main thread before attaching to the layer.
- Uses AVURLAssetPreferPreciseDurationAndTimingKey=false for faster trailer startup.
- Sets automaticallyWaitsToMinimizeStalling=true.
- Sets preferredForwardBufferDuration=4 seconds.
- Sets preferredPeakBitRate=12 Mbps for smoother trailer playback.
- Sets preferredMaximumResolution=1080p for trailer popup stability.
- Sets audioTimePitchAlgorithm=.timeDomain.
- Uses playImmediately(atRate: 1.0) once ready.
- Stabilizes AVPlayerLayer: opaque, async drawing, disabled layer actions, aspect-fill popup fit.
- Keeps YouTube auto-open block from v589.

Preserved:
- Live TV untouched.
- Guide untouched.
- VOD playback untouched.
- Backend membership untouched.
- Trailer UI/popup layout preserved except smoother player internals.

Note:
- This sandbox cannot run Xcode/tvOS compile. Source packaging only.
