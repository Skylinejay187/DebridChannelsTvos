# v710_STREMIO_CATALOG_FAST_LOAD_FIX

Built from the current v709 ZIP only.

Main change:
- Streaming Catalog rows publish first from cached/direct Stremio data.
- Fanart/TMDB artwork upgrades happen afterward in bounded background work.
- Slow or failing premium artwork no longer blocks row visibility.

Verification note:
- Source inspection confirms `fetchRows(from:)` now appends base Stremio `MediaItem`s directly and no longer awaits Fanart before returning rows.
- No Swift/Xcode toolchain is available in this container, so a local tvOS compile could not be run.
