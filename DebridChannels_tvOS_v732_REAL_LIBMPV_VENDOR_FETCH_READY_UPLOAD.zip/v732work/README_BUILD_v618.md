# Debrid Channels tvOS v618

Base: v617 Details Stage visibility/flash fix.

Scoped changes:
- Details Stage backdrop visibility increased another ~20% while preserving the left/right fade and readability glass.
- Added a stronger pre-dim entry guard so the backdrop cannot show as a full-bright raw frame before the cinematic overlays settle.
- Franchise collection cards are now logo-focused: year/rating metadata removed from the cards.
- TMDB collection parts now attempt to hydrate themed movie logos from the TMDB movie images endpoint when a TMDB key is available.

Untouched:
- v612/v617 playback and display matching path.
- Live TV matching setting.
- Membership, sports, trailers, backup/restore, TVE branch.
