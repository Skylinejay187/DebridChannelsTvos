# Debrid Channels tvOS v577 — Exact Episode Filter + Source Panel Clearance

Scope kept intentionally narrow from v576 base.

## Fixed
- Source Intelligence episode filtering now rejects season-wide pack results such as `S01` when the selected episode is `S01E01`.
- Exact episode matches still accept common forms like `S01E01`, `1x01`, `Season 1 Episode 1`, and equivalent dotted/underscore forms.
- Generic results from exact episode endpoints can still appear only when they do not explicitly identify a different episode/season pack.
- Source Intelligence overlay is moved lower and slightly reduced vertically so the top portrait poster, media info chips, and advisory badge remain visible while links are displayed.
- Top-left Debrid Channels wordmark is reduced 50% overall.

## Verified static checks
- Swift parse check passed with `swiftc -parse Sources/*.swift`.
- iCloud backup/restore/clear code path remains present from v574/v575 and was not rewired in this build.

## Preserved
- Source Intelligence UI style and pagination.
- Fast movie search path from v576.
- Exact episode endpoint-only search path.
- Playback, trailers, Live TV, popup layout, sports, iCloud backup/restore behavior.
