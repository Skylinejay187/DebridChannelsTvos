# v718_QUICK_PANEL_FOCUS_OWNERSHIP_FIX

Scope: quick Movies/Shows/Home catalog panel focus ownership only.

Fix:
- Keeps the top menu visible, but removes it from focus/hit testing while the Home/Movies/TV Shows catalog quick panel is active.
- This prevents tvOS from resolving every UP press to the top menu before the catalog row handler can move between rows.
- Normal top menu focus/hit testing is restored when the quick panel is closed or when another section owns the screen.

Preserved:
- v715/v716 row visuals and no ghost preview.
- Current catalog stability and artwork loading.
- VOD, trailers, Source Intelligence, Membership, Live TV, Sports, Settings layout.
