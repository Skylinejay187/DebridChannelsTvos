# Debrid Channels tvOS v698 — Focused-Only Live TV Progress

Base: v697 / latest after v697.

## Scope
- Live TV grid program progress now renders only on the focused grid card.
- Unfocused Live TV cards render no progress bar at all.
- Focused card progress remains a subtle 4px bottom-edge line using EPG start/end timing.
- Low cyan glow is limited to the focused card progress fill.
- Existing 30-second Live TV progress tick is preserved.
- Existing Settings toggle `Live TV Card Progress Bar` is preserved.

## Not touched
- VOD playback and VOD seek/focus logic.
- Source Intelligence.
- Trailers.
- Membership.
- Backend.
- Sports.
- Settings layout.
