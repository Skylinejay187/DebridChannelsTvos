# Debrid Channels tvOS v563

Careful wiring/metadata build.

- Trailer button scans all configured Stremio stream addons for trailer/teaser/preview stream rows before backend fallbacks.
- Supports varied trailer title patterns like [TRAILER 1], trailer-1-1080p, official-trailer, teaser, and preview.
- Find Links chips now show richer provider/quality/size/audio/subtitle/codec/HDR/language-warning data.
- Selected stream playback status includes audio/subtitle/source details from the chosen link metadata.
- Live TV playback item now carries current EPG program title/time/description/artwork into the player overlay when available.
- Smart Program Info avoids generic TVMaze placeholder text when EPG data exists.
- Existing trailer/cast/link resolver paths are preserved.
