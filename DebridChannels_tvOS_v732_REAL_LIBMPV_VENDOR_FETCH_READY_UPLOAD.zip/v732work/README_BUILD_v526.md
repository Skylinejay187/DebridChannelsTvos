# v526 Dynamic Showcase Area

- Removed the bottom Explore More / Media DNA card strip from the popup.
- Added a non-focusable Dynamic Showcase Area at the bottom of the popup.
- Showcase uses resume data when available: Continue Watching, time remaining, watched percentage, and progress bar.
- Falls back to Featured Scene / cinematic artwork when there is no resume entry.
- Uses landscape artwork first, poster fallback second, and gradient fallback last.
- Preserved source rail, popup bounds, Live TV grid themes, playback, search, settings, and normal VOD overlay behavior.
