Debrid Channels tvOS v485

Focused popup polish/focus fix:
- Removed duplicate themed logo from popup detail section.
- Banner crop shifted down to improve visible artwork/faces.
- Popup internals reduced to avoid bottom clipping.
- Detail close restores focus to quick-panel content instead of top menu.
