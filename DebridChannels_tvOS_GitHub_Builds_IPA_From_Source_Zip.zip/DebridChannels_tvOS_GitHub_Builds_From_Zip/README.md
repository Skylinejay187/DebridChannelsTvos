# Debrid Channels tvOS — GitHub Builds IPA From ZIP

This repo layout matches the Android-style workflow: GitHub keeps the app project as a ZIP, then the workflow extracts that ZIP and builds the unsigned tvOS IPA artifact.

## What to upload to GitHub

Upload the contents of this folder to one GitHub repository:

```text
.github/workflows/build-tvos-ipa-from-zip.yml
source_zip/DebridChannelsTVOS_Source.zip
README.md
```

## How it works

```text
GitHub repo
  └── source_zip/DebridChannelsTVOS_Source.zip
        ↓
GitHub Actions extracts ZIP
        ↓
xcodebuild builds tvOS app
        ↓
Workflow packages Payload/*.app into .ipa
        ↓
Download artifact: DebridChannels-tvOS-Unsigned-IPA
```

## How to run

1. Create a GitHub repo.
2. Upload everything from this folder.
3. Open the **Actions** tab.
4. Run **Build Debrid Channels tvOS IPA From Source ZIP**.
5. Download the artifact named **DebridChannels-tvOS-Unsigned-IPA**.
6. Sign/sideload the IPA with your own Apple TV signing method.

## Notes

- This workflow intentionally does not handle signing.
- The produced IPA is unsigned.
- Replace `source_zip/DebridChannelsTVOS_Source.zip` later with newer tvOS source zips to rebuild newer versions.
