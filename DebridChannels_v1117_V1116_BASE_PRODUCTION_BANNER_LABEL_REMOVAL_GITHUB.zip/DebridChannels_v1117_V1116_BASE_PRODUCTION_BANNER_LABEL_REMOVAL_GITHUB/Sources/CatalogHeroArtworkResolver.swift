import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// v1116: Artwork 4 / Hero 2 resolves one highest-quality landscape asset before
/// publishing the focused hero. The existing backend v669 already exposes the
/// multi-provider artwork pool, so this remains an app-only correction.
actor CatalogHeroArtworkResolver {
    static let shared = CatalogHeroArtworkResolver()

    private struct ArtworkVariant: Decodable, Hashable {
        let url: String
        let source: String?
        let width: Int?
        let height: Int?
    }

    private struct ArtworkPool: Decodable {
        let backdrops: [ArtworkVariant]?
        let landscape: [ArtworkVariant]?
    }

    private struct SelectedArtwork: Decodable {
        let backdrop: String?
        let landscape: String?
    }

    private struct ResolveResponse: Decodable {
        let ok: Bool?
        let selectedArtwork: SelectedArtwork?
        let artworkPool: ArtworkPool?
    }

    private struct CacheEntry: Codable {
        let url: String
        let storedAt: Date
    }

    private static let cacheDefaultsKey = "v1116Artwork4Hero2BestArtworkCache"
    private static let cacheLifetime: TimeInterval = 7 * 24 * 60 * 60
    private var memoryCache: [String: CacheEntry] = [:]
    private var loadedPersistentCache = false
    private var inFlight: [String: Task<String?, Never>] = [:]

    func bestHeroURL(for item: MediaItem, backendBaseURL: String) async -> String? {
        let identity = Self.identityKey(for: item)
        loadPersistentCacheIfNeeded()
        if let cached = memoryCache[identity], Date().timeIntervalSince(cached.storedAt) < Self.cacheLifetime {
            return PremiumArtworkURL.upgraded(cached.url)
        }

        if let existing = inFlight[identity] {
            return await existing.value
        }

        let task = Task<String?, Never> {
            let resolved = await Self.resolve(item: item, backendBaseURL: backendBaseURL)
            return PremiumArtworkURL.upgraded(resolved)
        }
        inFlight[identity] = task
        let result = await task.value
        inFlight[identity] = nil

        if let result, !result.isEmpty {
            memoryCache[identity] = CacheEntry(url: result, storedAt: Date())
            persistCache()
        }
        return result
    }

    private func loadPersistentCacheIfNeeded() {
        guard !loadedPersistentCache else { return }
        loadedPersistentCache = true
        guard let data = UserDefaults.standard.data(forKey: Self.cacheDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: CacheEntry].self, from: data) else { return }
        let cutoff = Date().addingTimeInterval(-Self.cacheLifetime)
        memoryCache = decoded.filter { $0.value.storedAt >= cutoff }
    }

    private func persistCache() {
        let cutoff = Date().addingTimeInterval(-Self.cacheLifetime)
        memoryCache = memoryCache.filter { $0.value.storedAt >= cutoff }
        guard let data = try? JSONEncoder().encode(memoryCache) else { return }
        UserDefaults.standard.set(data, forKey: Self.cacheDefaultsKey)
    }

    private static func resolve(item: MediaItem, backendBaseURL: String) async -> String? {
        let cleanBase = backendBaseURL.trimmingCharacters(in: .whitespacesAndNewlines).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard !cleanBase.isEmpty,
              var components = URLComponents(string: cleanBase + "/api/artwork/resolve") else {
            return fallbackURL(for: item)
        }

        let normalizedType = item.type.lowercased().contains("series") || item.type.lowercased().contains("show") || item.type.lowercased() == "tv" ? "tv" : "movie"
        var query: [URLQueryItem] = [
            URLQueryItem(name: "title", value: item.title),
            URLQueryItem(name: "type", value: normalizedType),
            URLQueryItem(name: "proxyImages", value: "0")
        ]
        if let imdb = clean(item.imdbId) { query.append(URLQueryItem(name: "imdbId", value: imdb)) }
        if let tmdb = clean(item.tmdbId) { query.append(URLQueryItem(name: "tmdbId", value: tmdb)) }
        if let tvdb = clean(item.tvdbId) { query.append(URLQueryItem(name: "tvdbId", value: tvdb)) }
        components.queryItems = query
        guard let url = components.url else { return fallbackURL(for: item) }

        do {
            var request = URLRequest(url: url, timeoutInterval: 5.5)
            request.cachePolicy = .reloadRevalidatingCacheData
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("DebridChannels-tvOS/1116 Artwork4Hero2Quality", forHTTPHeaderField: "User-Agent")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                return fallbackURL(for: item)
            }
            let decoded = try JSONDecoder().decode(ResolveResponse.self, from: data)
            let variants = deduplicated((decoded.artworkPool?.backdrops ?? []) + (decoded.artworkPool?.landscape ?? []))
                .filter(isLandscapeCandidate)
            if let best = variants.max(by: { qualityScore($0) < qualityScore($1) }) {
                return best.url
            }
            return clean(decoded.selectedArtwork?.backdrop)
                ?? clean(decoded.selectedArtwork?.landscape)
                ?? fallbackURL(for: item)
        } catch {
            return fallbackURL(for: item)
        }
    }

    private static func identityKey(for item: MediaItem) -> String {
        let type = item.type.lowercased()
        if let imdb = clean(item.imdbId) { return "imdb|\(imdb)|\(type)" }
        if let tmdb = clean(item.tmdbId) { return "tmdb|\(tmdb)|\(type)" }
        if let tvdb = clean(item.tvdbId) { return "tvdb|\(tvdb)|\(type)" }
        return "title|\(item.title.lowercased())|\(item.year)|\(type)"
    }

    private static func fallbackURL(for item: MediaItem) -> String? {
        PremiumArtworkURL.upgraded(item.landscapeURL ?? item.previewURL ?? item.posterURL)
    }

    private static func clean(_ value: String?) -> String? {
        let trimmed = value?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return trimmed.isEmpty ? nil : trimmed
    }

    private static func deduplicated(_ variants: [ArtworkVariant]) -> [ArtworkVariant] {
        var seen = Set<String>()
        return variants.filter {
            let normalized = PremiumArtworkURL.upgraded($0.url) ?? $0.url
            return !normalized.isEmpty && seen.insert(normalized).inserted
        }
    }

    private static func isLandscapeCandidate(_ variant: ArtworkVariant) -> Bool {
        let width = variant.width ?? 0
        let height = variant.height ?? 0
        if width > 0, height > 0 {
            return Double(width) / Double(height) >= 1.35 && width >= 1280
        }
        let lower = variant.url.lowercased()
        return !lower.contains("poster") && !lower.contains("logo") && !lower.contains("banner")
    }

    private static func qualityScore(_ variant: ArtworkVariant) -> Int64 {
        let width = max(variant.width ?? 0, 0)
        let height = max(variant.height ?? 0, 0)
        let source = (variant.source ?? "").lowercased()

        // Exact dimensions are authoritative. True 4K receives a decisive priority,
        // followed by QHD and full-HD. Providers that do not expose dimensions receive
        // a conservative 1080p estimate rather than outranking a verified 4K asset.
        let estimatedWidth: Int
        let estimatedHeight: Int
        if width > 0, height > 0 {
            estimatedWidth = width
            estimatedHeight = height
        } else if source.contains("fanart") || source.contains("tvdb") {
            estimatedWidth = 1920
            estimatedHeight = 1080
        } else {
            estimatedWidth = 1600
            estimatedHeight = 900
        }

        let pixels = Int64(estimatedWidth) * Int64(estimatedHeight)
        let resolutionTier: Int64
        if estimatedWidth >= 3840 || estimatedHeight >= 2160 {
            resolutionTier = 4_000_000_000_000
        } else if estimatedWidth >= 2560 || estimatedHeight >= 1440 {
            resolutionTier = 3_000_000_000_000
        } else if estimatedWidth >= 1920 || estimatedHeight >= 1080 {
            resolutionTier = 2_000_000_000_000
        } else {
            resolutionTier = 1_000_000_000_000
        }

        let providerBonus: Int64
        if source.contains("fanart") { providerBonus = 30_000_000 }
        else if source.contains("tvdb") { providerBonus = 20_000_000 }
        else if source.contains("tmdb") { providerBonus = 10_000_000 }
        else { providerBonus = 0 }
        return resolutionTier + pixels + providerBonus
    }
}
