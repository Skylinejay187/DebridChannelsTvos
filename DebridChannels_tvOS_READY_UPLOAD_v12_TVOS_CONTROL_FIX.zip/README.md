# Debrid Channels tvOS v12
Ready-to-upload GitHub repo package. Workflow extracts the embedded source ZIP, generates Xcode project with XcodeGen, builds unsigned tvOS app, and uploads IPA artifact.
