# vBRDC388R3K1F1 — Kingfisher ImageResource Compile Fix

Narrow compile-only correction from vBRDC388R3K1.

- Qualifies all new Kingfisher resource references in `Sources/RemoteImageFit.swift` as `Kingfisher.ImageResource` to resolve the Xcode/DeveloperToolsSupport `ImageResource` ambiguity.
- Preserves the Kingfisher 8.11.0 artwork pipeline and R3 single-active-surface runtime ownership.
- No playback, Live TV, timeshift, VOD cache, trailer, ambient, navigation, or UI behavior changes.
- Version: 1.0.1099 (1099), release: vBRDC388R3K1F1.
