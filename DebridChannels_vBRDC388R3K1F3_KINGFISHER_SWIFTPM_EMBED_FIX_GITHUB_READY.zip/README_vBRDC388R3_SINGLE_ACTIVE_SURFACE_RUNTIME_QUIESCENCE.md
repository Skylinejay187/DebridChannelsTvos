# vBRDC388R3 — Single Active Surface Runtime Quiescence

Base: vBRDC388R2. Version 1.0.1096 (1096).

## Purpose
Give the foreground Signal surface the runtime budget while retaining UNITY state for instant return. Covered surfaces remain resident where required, but recurring animation/background publication is denied.

## Trailer exclusive priority fix
`UnityFrameRuntime.permits` now evaluates trailer/source-opening ownership before retained VOD playback ownership. A trailer launched over paused VOD can legitimately have both flags true; previously the playback branch won and still permitted playback-artwork work under the trailer. Trailer ownership now permits only trailer playback chrome, alerts, and persistence lanes.

## Surface animation ownership
`UnityAnimationCoordinator` now carries the authoritative `UnityAppCore.effectiveSurface` in its global context and gates recurring feature motion to its owning foreground surface. Catalog motion cannot run under Live TV; Live/Guide motion cannot run under Catalogs; Sports motion cannot run outside Sports; Detail/Source Intelligence motion cannot run outside Detail; playback chrome is limited to playback/trailer ownership.

## Regression locks
- R2 trailer display matching remains disabled.
- R1 VOD foreground artwork first-presentation behavior remains intact.
- R2-approved ambient visuals are not redesigned.
- Persistent UNITY state/focus is retained; quiescence does not destroy covered surfaces.
- VOD session is preserved/paused beneath a trailer for exact resume.
