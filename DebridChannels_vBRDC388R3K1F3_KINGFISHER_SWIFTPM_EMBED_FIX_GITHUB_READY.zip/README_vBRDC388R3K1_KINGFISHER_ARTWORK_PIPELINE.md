# vBRDC388R3K1 — Kingfisher Artwork Pipeline

Base: vBRDC388R3F1 (1.0.1097 / 1097)
Release: vBRDC388R3K1 (1.0.1098 / 1098)

## Purpose
Replace Signal's custom remote artwork transport/cache lifecycle with Kingfisher while preserving Signal's existing UI, artwork URL selection, Unity single-active-surface ownership, playback publication gates, decode budgets, and presentation behavior.

## Dependency
- Kingfisher 8.11.0, pinned exactly through Swift Package Manager.
- Kingfisher is added only to the main tvOS application target.

## Architecture
- `RemoteImageFit` and existing Signal call sites remain intact.
- `PremiumRemoteImageLoader` remains Signal's surface/publication adapter so R3 quiescence remains authoritative.
- Remote retrieval, request cancellation, memory/disk cache retrieval, request reuse, and image processing are delegated to `KingfisherManager`.
- Existing Signal `LoadKey` identities are supplied as Kingfisher cache keys.
- Existing max-pixel budgets map to Kingfisher `DownsamplingImageProcessor`.
- Existing Signal direct-origin fallback remains bounded to one fallback attempt.
- Signal's `UnityFrameRuntime` still decides when decoded artwork may publish.
- Trailer exclusivity remains unchanged; VOD artwork does not gain permission while a trailer owns the runtime.

## Why Kingfisher 8.11.0
The current 8.11.0 release includes fixes for concurrent cancellation/download startup, disk-cache initialization races, and retrieval/fallback synchronization. These are directly relevant to Signal's first-presentation artwork failure class.

## Regression locks
No changes to Aether playback, Live R7 audio/video behavior, Live timeshift, VOD cache, trailer cadence/display-match policy, R2 ambient appearance, top-menu/navigation behavior, or R3 single-active-surface quiescence.

## Physical acceptance test
Cold launch -> VOD -> first overlay opening. Verify title/logo, Spotlight Related on Trakt, Watch/Stream, Cast Explorer first opening, several cast members, Episodes first opening, S1 -> S2 -> S1. No close/reopen or pause/unpause should be required for artwork to appear.
