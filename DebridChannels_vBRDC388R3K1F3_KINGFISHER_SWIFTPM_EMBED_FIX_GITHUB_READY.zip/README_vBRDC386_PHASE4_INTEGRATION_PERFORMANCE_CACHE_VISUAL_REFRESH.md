# vBRDC386 — Phase 4 Integration / Performance / Stress

Version: 1.0.1088 (1088)
Base: vBRDC385R2 / 1.0.1087 (1087)

## Physical regression locks preserved
- vBRDC383R7 Aether Live audio/video stability
- vBRDC384F3 Live TV timeshift behavior
- vBRDC385 Phase 3 VOD disk-cache profiles, subtitle active-cue correction, VOD amplification
- R3 navigation / top-menu / Signal-logo behavior
- Existing ambient lifecycle behavior; no ambient visual redesign in this build

## Phase 4 correction included
### VOD cache-ahead scrubber refresh
Physical Apple TV testing confirmed VOD disk caching and automatic storage cleanup are functioning, but the cache-ahead visualization could remain stale until Play/Pause caused another presentation update.

This build does NOT redesign or replace the working VOD cache.

Changes:
1. Aether bridge retains its normal `engine.clock.$bufferedPosition` subscription.
2. For VOD sessions only, a low-frequency 2 Hz read of Aether's authoritative `engine.clock.bufferedPosition` republishes cache progress when the producer advances while presentation is paused/stationary.
3. Existing `publishBufferNotification` movement/cadence coalescing remains in place, so unchanged values do not cause decoder-rate SwiftUI updates.
4. When VOD chrome becomes visible, Signal immediately mirrors the latest raw authoritative buffered endpoint into the scrubber state.
5. Live TV is excluded from this VOD poll and keeps the physically confirmed timeshift path unchanged.
6. Session-owned Combine cancellation tears the poll down with the Aether playback session.

## Phase 4 physical validation matrix
- Auto / 1 GB / 2 GB / 3 GB / Unlimited VOD cache modes
- Cache bar advances while playing
- Cache bar advances while paused without requiring Play/Pause
- Opening controls immediately shows the latest cached endpoint
- Exit VOD and verify session/cache cleanup remains unchanged
- 30–60 minute VOD wall-clock comparison
- Pause/resume and manual seeks
- Catalog exit/re-entry and resume checkpoint
- Background/foreground
- Source failover
- Audio-track and subtitle changes
- Amplification Off/+3/+6/+9/+12 dB
- Local-vs-Trakt resume arbitration
- Movie + episode + long-title testing
- Live TV audio/video/timeshift regression test

## Deferred dedicated phase
GPU Animation + Live TV Scrolling Performance remains a separate later phase: GPU-first Classic Smoke/ambient work, compositor-friendly Live grid scrolling, suspension of decorative renderers during preview/Live/VOD/trailer playback, and app-wide animation performance profiling.
