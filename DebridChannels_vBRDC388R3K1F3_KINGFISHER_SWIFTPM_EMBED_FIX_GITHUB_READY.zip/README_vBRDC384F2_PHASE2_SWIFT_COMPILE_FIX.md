# vBRDC384F2 — Phase 2 Swift Compile Fix

Base: vBRDC384F1 / 1.0.1086 / build 1086.

GitHub Actions log `99724929013` reached app Swift compilation and exposed two direct Phase 2 integration errors in `DebridChannelsTVOSApp.swift`:

1. `UniversalVideoSurface` memberwise initializer argument order: `aetherGoLiveSerial` is declared before `ksStartTimeSeconds`, but the call site supplied it later. F2 moves the argument to its declared position; behavior is unchanged.
2. `PlayerControl` gained `.goLive`, but `PlayerControlButton.iconName` did not handle the new enum case. F2 adds the Go Live icon mapping.

The `.overlay(alignment: .bottom)` and `.animation(.easeInOut...)` diagnostics were cascading type-inference errors from the malformed initializer expression, so no UI behavior was rewritten to address them.

No Aether routing, R7 audio/video stability, timeshift semantics, top-menu, logo, catalog exit/navigation, ambient lifecycle, VOD, or Top Shelf behavior was changed.
