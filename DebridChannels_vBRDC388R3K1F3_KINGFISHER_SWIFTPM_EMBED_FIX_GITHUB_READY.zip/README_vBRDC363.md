# vBRDC365 — Preview Mirror Persistent Root Restore

Build: 1.0.1068 (1065)

Physical-device issue addressed: closing a Home/Movies/Shows catalog from Live TV Preview Mirror could leave the catalog-era shell/background visible over a black/dynamic-wallpaper state until DOWN forced navigation back to Live TV.

Fix:
- Preview Mirror Back from a catalog now returns UnityAppCore/store navigation to `.live` in the same dismissal transaction.
- The persistent LiveTVScreen remains mounted throughout.
- Only the catalog presentation is dismissed; the base dashboard is never torn down/reconstructed.
- Root's existing Preview Mirror atomic compositor retirement removes the outgoing catalog layer without a crossfade/ghost copy.
- Top navigation focus is requested back on the Live TV destination; no synthetic DOWN event is used.
- Golden/non-Preview-Mirror catalog dismissal behavior is unchanged.

Preserved from v362: direct Nuvio/native focused previews, 1-hour trailer cache, Preview Mirror wall-clock synchronization, UP NEXT-only footer, VOD engine chip removal.
