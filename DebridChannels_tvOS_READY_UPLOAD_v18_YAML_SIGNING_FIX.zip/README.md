# Debrid Channels tvOS v18
Ready-to-upload GitHub repo package. Upload this ZIP to GitHub and run the included workflow.
