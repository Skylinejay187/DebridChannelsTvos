import Foundation
import UIKit
import AudioToolbox
import QuartzCore

/// One restrained navigation cue for genuine application focus movement.
///
/// v1122 keeps the single Navigation Sound manager introduced in v1120 and the
/// focus filtering corrected in v1121, but replaces AVAudioPlayer delivery with
/// preloaded System Sound Services. System Sound Services is designed for short
/// UI cues on tvOS/iOS, does not require a player object to be driven from a
/// private run loop, and never changes KSPlayer, media volume, or system volume.
final class NavigationSoundManager: NSObject {
    static let shared = NavigationSoundManager()
    static let enabledDefaultsKey = "navigationSoundEffectsEnabled"

    enum PlaybackContext: Hashable {
        case vodOrLive
        case trailer
    }

    private var focusObserver: NSObjectProtocol?
    private var playbackSuppressions: Set<PlaybackContext> = []
    private var lastTransitionSignature: String?
    private var lastTransitionAt: CFTimeInterval = 0
    private var lastPlayedAt: CFTimeInterval = 0
    private var focusSilencedUntil: CFTimeInterval = 0

    // The bundled sound is 84 ms. A 120 ms gate prevents overlap and harsh
    // machine-gun repetition while preserving normal deliberate movement.
    private let minimumPlaybackInterval: CFTimeInterval = 0.120
    private let duplicateTransitionInterval: CFTimeInterval = 0.180
    private let postPlaybackRestorationSilence: CFTimeInterval = 0.450

    // All resource lookup and SystemSoundID creation happen once on this queue.
    // Focus callbacks never read/decode the file or allocate a new audio object.
    private let soundQueue = DispatchQueue(
        label: "com.channelsdebrid.navigation-sound.system-sound",
        qos: .userInteractive
    )
    private var soundID: SystemSoundID = 0
    private var soundLoadAttempted = false

    private override init() {
        super.init()
    }

    static var isEnabled: Bool {
        let defaults = UserDefaults.standard
        guard defaults.object(forKey: enabledDefaultsKey) != nil else { return true }
        return defaults.bool(forKey: enabledDefaultsKey)
    }

    @MainActor
    func start() {
        guard focusObserver == nil else { return }
        focusSilencedUntil = CACurrentMediaTime() + 0.350
        preloadSound()
        focusObserver = NotificationCenter.default.addObserver(
            forName: UIFocusSystem.didUpdateNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            Task { @MainActor in
                self?.handleFocusUpdate(notification)
            }
        }
    }

    /// Existing playback hook, context-aware so dismissing a trailer cannot
    /// unsuppress an active VOD or Live TV presentation.
    @MainActor
    func setPlaybackSuppressed(
        _ suppressed: Bool,
        context: PlaybackContext = .vodOrLive
    ) {
        let wasSuppressed = !playbackSuppressions.isEmpty
        if suppressed {
            playbackSuppressions.insert(context)
        } else {
            playbackSuppressions.remove(context)
        }

        if suppressed {
            resetFocusFilter(silenceFor: 0)
        } else if wasSuppressed && playbackSuppressions.isEmpty {
            resetFocusFilter(silenceFor: postPlaybackRestorationSilence)
        }
    }

    /// AppStorage owns persistence. Enabling only preloads and remains silent;
    /// disabling rejects future events without touching any media audio state.
    @MainActor
    func settingDidChange(isEnabled: Bool) {
        resetFocusFilter(silenceFor: 0.250)
        if isEnabled { preloadSound() }
    }

    @MainActor
    private func handleFocusUpdate(_ notification: Notification) {
        let now = CACurrentMediaTime()
        guard Self.isEnabled,
              playbackSuppressions.isEmpty,
              !VODExclusivePlaybackGate.isActive,
              UIApplication.shared.applicationState == .active,
              now >= focusSilencedUntil,
              let context = notification.userInfo?[UIFocusSystem.focusUpdateContextUserInfoKey] as? UIFocusUpdateContext,
              let previousItem = context.previouslyFocusedItem,
              let nextItem = context.nextFocusedItem else { return }

        let previousID = stableFocusIdentity(for: previousItem)
        let nextID = stableFocusIdentity(for: nextItem)
        guard previousID != nextID else { return }

        // UIKit frequently preserves a directional heading for direct focus
        // engine moves. Several existing Debrid Channels SwiftUI routes receive
        // a real onMoveCommand and then assign FocusState synchronously, which can
        // legitimately report an empty heading. Stable identity, startup/playback
        // silence windows, duplicate rejection, and rate limiting remain the
        // authoritative filters for those genuine user-driven moves.
        let signature = previousID + "->" + nextID
        if signature == lastTransitionSignature,
           now - lastTransitionAt < duplicateTransitionInterval {
            return
        }

        lastTransitionSignature = signature
        lastTransitionAt = now

        guard now - lastPlayedAt >= minimumPlaybackInterval else { return }
        lastPlayedAt = now
        playPreparedSound()
    }

    @MainActor
    private func resetFocusFilter(silenceFor interval: CFTimeInterval) {
        lastTransitionSignature = nil
        lastTransitionAt = 0
        lastPlayedAt = 0
        focusSilencedUntil = CACurrentMediaTime() + interval
    }

    @MainActor
    private func stableFocusIdentity(for item: UIFocusItem) -> String {
        let object = item as AnyObject
        let typeName = String(reflecting: type(of: object))

        if let view = item as? UIView {
            let identifier = normalizedIdentityComponent(view.accessibilityIdentifier)
            let label = normalizedIdentityComponent(view.accessibilityLabel)
            let semantic = identifier.isEmpty ? label : identifier
            let frame = view.window == nil ? view.frame : view.convert(view.bounds, to: nil)
            let geometry = [frame.midX, frame.midY, frame.width, frame.height]
                .map { String(Int(($0 / 4.0).rounded())) }
                .joined(separator: ",")

            if !semantic.isEmpty {
                return "\(typeName)|\(semantic)|\(geometry)"
            }
        }

        let pointer = UInt(bitPattern: Unmanaged.passUnretained(object).toOpaque())
        return "\(typeName)|object:\(String(pointer, radix: 16))"
    }

    private func normalizedIdentityComponent(_ value: String?) -> String {
        guard let value else { return "" }
        let compact = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "|", with: "/")
        return String(compact.prefix(96))
    }

    private func preloadSound() {
        soundQueue.async { [weak self] in
            self?.prepareSystemSoundOnQueueIfNeeded()
        }
    }

    private func playPreparedSound() {
        soundQueue.async { [weak self] in
            guard let self else { return }
            self.prepareSystemSoundOnQueueIfNeeded()
            guard self.soundID != 0 else { return }
            AudioServicesPlaySystemSound(self.soundID)
        }
    }

    /// Runs only on soundQueue. Missing/corrupt assets fail silently once and
    /// never cause repeated resource/decode work during navigation.
    private func prepareSystemSoundOnQueueIfNeeded() {
        guard soundID == 0, !soundLoadAttempted else { return }
        soundLoadAttempted = true

        guard let url = navigationSoundURL() else { return }
        var createdSoundID: SystemSoundID = 0
        guard AudioServicesCreateSystemSoundID(url as CFURL, &createdSoundID) == kAudioServicesNoError,
              createdSoundID != 0 else { return }

        // The in-app Navigation Sounds toggle is the source of truth. Mark this
        // custom cue as non-UI for System Sound Services so an unrelated tvOS
        // global sound-effects preference cannot silently defeat an enabled app
        // setting. This does not alter system volume or any media audio session.
        var uiSoundFlag: UInt32 = 0
        withUnsafePointer(to: &createdSoundID) { soundPointer in
            withUnsafePointer(to: &uiSoundFlag) { flagPointer in
                _ = AudioServicesSetProperty(
                    kAudioServicesPropertyIsUISound,
                    UInt32(MemoryLayout<SystemSoundID>.size),
                    soundPointer,
                    UInt32(MemoryLayout<UInt32>.size),
                    flagPointer
                )
            }
        }

        soundID = createdSoundID
    }

    /// XcodeGen normally flattens file resources, but the nested fallback keeps
    /// delivery reliable if a generated project preserves the Resources folder.
    private func navigationSoundURL() -> URL? {
        if let direct = Bundle.main.url(
            forResource: "NavigationFocusSoftTick",
            withExtension: "wav"
        ) {
            return direct
        }
        if let nested = Bundle.main.url(
            forResource: "NavigationFocusSoftTick",
            withExtension: "wav",
            subdirectory: "Resources"
        ) {
            return nested
        }
        guard let resourceRoot = Bundle.main.resourceURL else { return nil }
        let nested = resourceRoot
            .appendingPathComponent("Resources", isDirectory: true)
            .appendingPathComponent("NavigationFocusSoftTick.wav", isDirectory: false)
        return FileManager.default.fileExists(atPath: nested.path) ? nested : nil
    }
}
