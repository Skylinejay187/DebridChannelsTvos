# Debrid Channels v1122 — Navigation Sounds Audible Delivery Correction

- Candidate: v1122
- Marketing version: 1.0.650
- Build: 650
- Source base: packaged v1121 Navigation Sounds Correction candidate only
- Rollback: v1120 until GitHub Actions and physical Apple TV testing pass
- Backend: v669 unchanged
- Phase 8: paused

## Why v1121 was rejected

Physical Apple TV testing reported no audible navigation sound. Direct inspection found three runtime delivery risks in v1121:

1. The focus observer rejected every update whose `UIFocusUpdateContext.focusHeading` was empty. Existing Debrid Channels SwiftUI routes often receive a real remote `onMoveCommand` and then assign `FocusState`, so a genuine user-driven move can arrive with an empty heading.
2. The short cue was started through `AVAudioPlayer` from a private dispatch queue. v1122 uses the tvOS/iOS System Sound Services path intended for short application sounds and caches one `SystemSoundID`.
3. The v1121 waveform measured approximately -19.6 dBFS peak before its 0.50 player-volume multiplier, making it easy to perceive as silence on a television. v1122 replaces it under the same filename with an original warm 84 ms cue at approximately -8 dBFS peak and -20 dBFS RMS.

These are direct code/audio-profile findings. Physical-device confirmation still belongs to the user’s next Apple TV test.

## Corrections

- Retains the single existing `NavigationSoundManager`; no duplicate manager was introduced.
- Removes the empty-heading hard rejection while retaining stable focus identities, initial-focus rejection, unchanged-ID rejection, duplicate-transition rejection, 120 ms rate limiting, app-active gating, VOD-exclusive gating, context-aware VOD/Live and trailer suppression, and post-playback restoration silence.
- Replaces `AVAudioPlayer` with one preloaded `SystemSoundID` using AudioToolbox System Sound Services.
- Explicitly adds `Resources/NavigationFocusSoftTick.wav` to the XcodeGen resources list and excludes it from the broader directory entry to prevent duplicate membership.
- Supports both flattened bundle lookup and a preserved `Resources/` subdirectory.
- Keeps the existing `navigationSoundEffectsEnabled` preference key and Settings control.
- Turning the setting On only preloads; it does not preview the sound.
- Missing/corrupt asset handling remains silent and non-fatal.
- Does not configure `AVAudioSession`, change media/system volume, touch KSPlayer, add network requests, or require backend work.

## Protected systems

PlaybackKit/KSPlayer, automatic source failover, Source Intelligence, Alternate Audio, trailer resolution, Live TV guide cache/playback support, Production & Ratings metadata, CatalogStore, resume/history persistence, per-title playback memory, episode alerts, and artwork caching are byte-identical to packaged v1121.

## Local validation

- 49/49 Swift source files parsed successfully.
- Both application plists validate at 1.0.650 (650).
- Single manager and existing preference key verified.
- Explicit sound-resource membership and dual bundle lookup verified.
- Focus deduplication simulation passed.
- Rate-limit/asset-duration overlap checks passed.
- Playback-silence policy checks passed.
- Missing/corrupt asset failure checks passed.
- Protected-file hash comparison passed.
- Final archive extraction and complete packaged-file hashes are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Do not claim the navigation sound is physically fixed until this candidate is installed and tested on Apple TV.
