import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
import TVServices

/// v981: immediate, view-only Apple TV Top Shelf.
///
/// The provider returns bundled movie/show poster metadata synchronously so tvOS
/// never falls back to the old static logo while waiting for a network request.
/// A lightweight background refresh updates the cache for a later Home Screen
/// reload. Items intentionally have no display or playback action.
final class ContentProvider: TVTopShelfContentProvider {
    private struct CatalogResponse: Codable {
        let metas: [CatalogMeta]
    }

    private struct CatalogMeta: Codable, Hashable {
        let id: String
        let type: String?
        let name: String
        let poster: String?
        let background: String?
        let description: String?
    }

    private final class CatalogAccumulator: @unchecked Sendable {
        private let lock = NSLock()
        private var values: [CatalogMeta] = []

        func append(_ metas: [CatalogMeta]) {
            lock.lock()
            values.append(contentsOf: metas)
            lock.unlock()
        }

        func snapshot() -> [CatalogMeta] {
            lock.lock()
            defer { lock.unlock() }
            return values
        }
    }

    private let endpoints = [
        URL(string: "https://v3-cinemeta.strem.io/catalog/movie/top.json")!,
        URL(string: "https://v3-cinemeta.strem.io/catalog/series/top.json")!
    ]

    private let cacheName = "signal-top-shelf-vBRDC327.json"
    private let maximumItems = 18

    override func loadTopShelfContent(completionHandler: @escaping (TVTopShelfContent?) -> Void) {
        let cached = normalizedItems(readCache())
        let bundled = normalizedItems(readBundledSeed())
        let immediate = cached.isEmpty ? bundled : cached

        // Return immediately. Waiting for URLSession here caused tvOS to display
        // the static logo fallback before the extension completed.
        completionHandler(immediate.isEmpty ? nil : makeContent(from: immediate))

        // Best-effort refresh for the next provider load. This never blocks the
        // current Top Shelf presentation.
        fetchCatalogs { [weak self] fetched in
            guard let self else { return }
            let refreshed = self.normalizedItems(fetched)
            guard !refreshed.isEmpty else { return }
            let previousIDs = Set(cached.map { "\($0.type ?? "")|\($0.id)" })
            let refreshedIDs = Set(refreshed.map { "\($0.type ?? "")|\($0.id)" })
            self.writeCache(refreshed)
            if previousIDs != refreshedIDs {
                TVTopShelfContentProvider.topShelfContentDidChange()
            }
        }
    }

    private func readBundledSeed() -> [CatalogMeta] {
        guard let url = Bundle.main.url(forResource: "SeedCatalog", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let metas = try? JSONDecoder().decode([CatalogMeta].self, from: data) else {
            return []
        }
        return metas
    }

    private func fetchCatalogs(completion: @escaping ([CatalogMeta]) -> Void) {
        let group = DispatchGroup()
        let accumulator = CatalogAccumulator()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 4
        configuration.timeoutIntervalForResource = 6
        configuration.requestCachePolicy = .reloadRevalidatingCacheData
        let session = URLSession(configuration: configuration)

        for endpoint in endpoints {
            group.enter()
            var request = URLRequest(url: endpoint)
            request.timeoutInterval = 4
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            session.dataTask(with: request) { data, response, _ in
                defer { group.leave() }
                guard let http = response as? HTTPURLResponse,
                      (200...299).contains(http.statusCode),
                      let data,
                      let result = try? JSONDecoder().decode(CatalogResponse.self, from: data) else {
                    return
                }
                accumulator.append(result.metas)
            }.resume()
        }

        group.notify(queue: .main) {
            session.finishTasksAndInvalidate()
            completion(accumulator.snapshot())
        }
    }

    private func normalizedItems(_ input: [CatalogMeta]) -> [CatalogMeta] {
        var seen = Set<String>()
        let valid = input.filter { meta in
            guard !meta.id.isEmpty,
                  !meta.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                  let poster = meta.poster, !poster.isEmpty,
                  let url = URL(string: upgradedPosterURL(poster)),
                  let scheme = url.scheme?.lowercased(),
                  scheme == "https" else {
                return false
            }
            return seen.insert("\(meta.type ?? "unknown")|\(meta.id)").inserted
        }

        let day = Int(Date().timeIntervalSince1970 / 86_400)
        return valid.sorted {
            stableRank("\(day)|\($0.type ?? "")|\($0.id)") <
            stableRank("\(day)|\($1.type ?? "")|\($1.id)")
        }
        .prefix(maximumItems)
        .map { $0 }
    }

    private func makeContent(from metas: [CatalogMeta]) -> TVTopShelfSectionedContent {
        // vBRDC300: return to portrait cards. A full-screen carousel without a custom
        // Signal metadata/logo composition looked like a bare wallpaper, while the
        // portrait shelf communicates clearly what each item is before selection.
        let items: [TVTopShelfSectionedItem] = metas.map { meta in
            let item = TVTopShelfSectionedItem(identifier: "debrid-watchable-\(meta.type ?? "media")-\(meta.id)")
            item.title = meta.name
            item.imageShape = .poster
            if let poster = meta.poster,
               let posterURL = URL(string: upgradedPosterURL(poster)) {
                item.setImageURL(posterURL, for: .screenScale1x)
                item.setImageURL(posterURL, for: .screenScale2x)
            }
            return item
        }

        let collection = TVTopShelfItemCollection(items: items)
        collection.title = "Watchable Today"
        return TVTopShelfSectionedContent(sections: [collection])
    }

    private func upgradedPosterURL(_ raw: String) -> String {
        raw
            .replacingOccurrences(of: "http://", with: "https://", options: .caseInsensitive)
            .replacingOccurrences(of: "/w92/", with: "/original/")
            .replacingOccurrences(of: "/w154/", with: "/original/")
            .replacingOccurrences(of: "/w185/", with: "/original/")
            .replacingOccurrences(of: "/w300/", with: "/original/")
            .replacingOccurrences(of: "/w342/", with: "/original/")
            .replacingOccurrences(of: "/w500/", with: "/original/")
            .replacingOccurrences(of: "/w780/", with: "/original/")
    }

    private func stableRank(_ value: String) -> UInt64 {
        var hash: UInt64 = 14_695_981_039_346_656_037
        for byte in value.utf8 {
            hash ^= UInt64(byte)
            hash &*= 1_099_511_628_211
        }
        return hash
    }

    private func cacheURL() -> URL? {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first?
            .appendingPathComponent(cacheName, isDirectory: false)
    }

    private func writeCache(_ metas: [CatalogMeta]) {
        guard let url = cacheURL(), let data = try? JSONEncoder().encode(metas) else { return }
        try? data.write(to: url, options: .atomic)
    }

    private func readCache() -> [CatalogMeta] {
        guard let url = cacheURL(),
              let data = try? Data(contentsOf: url),
              let metas = try? JSONDecoder().decode([CatalogMeta].self, from: data) else {
            return []
        }
        return metas
    }
}
