# vBRDC329 — Focused-Card Coherency + Wallpaper Decoder Recovery
Version 1.0.1031 (1031)

Based exclusively on the supplied vBRDC328 package, preserving the v328 opt-in diagnostics and v327 playback lifecycle.

- Corrected `FixedSlotFocusedCatalogCard` semantic equality to include its externally supplied layout, glow, preview identity, logo/title, row, and playback-publication inputs. Retains `.equatable()` to avoid unrelated store-driven redraws.
- Fixed animated wallpaper decode-task cleanup on invalid/empty image sources. Generation and URL guards prevent an old task from clearing a newer owner's task.
- No changes to wallpaper resolution, frame cadence, playback engines, navigation, or Guide behavior.
- tvOS/Xcode build and on-device Instruments performance validation remain required; neither can be performed by the available Linux environment.
