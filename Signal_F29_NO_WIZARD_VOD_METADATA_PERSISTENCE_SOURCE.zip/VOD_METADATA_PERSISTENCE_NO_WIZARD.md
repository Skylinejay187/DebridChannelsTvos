# Signal F29 — Wizard removed / VOD metadata persistence

- Removed Find Signal / Acquisition Wizard, root first-run routing, Settings auto-offer, wizard UI, setup drafts, import workflow, and Smart Restore wizard sheet.
- Preserved native Settings provider editors, membership enforcement, and existing backup/restore settings and engine.
- VOD playback metadata now publishes to the playback-session-owned state even when the controls overlay is hidden; opening/closing chrome no longer gates the data update.
- VOD rendering/animations remain view-scoped; no hidden overlay is kept continuously mounted.
- Playback session identity and cancellation guards remain in place.
- Checks: Swift frontend parse, F28 preflight (74 files), remote thumbnail gate passed locally.
- Full Xcode tvOS compilation and Apple TV testing NOT performed. Do not install until GitHub Actions compiles successfully.
