# Debrid Channels vBRDC212 — Instant Source Intelligence + Catalog Force Load

Release: vBRDC212  
Marketing version: 1.0.915  
Build: 915  
Donor/source of truth: packaged vBRDC211 source only.

## Goal

Remove app-owned serialization and long failure waits from Find Links / Play, and make catalog recovery publish usable rows as early as possible without changing the visible catalog design, player engines, source ranking policy, or the vBRDC211 system-media/Trakt fixes.

## Source Intelligence latency fixes

- Provider manifests now race in **sliding bounded parallelism** (up to 12 provider lanes). A completed lane is immediately refilled; a dead provider can no longer hold a later healthy provider behind a fixed batch barrier.
- The dedicated Source Intelligence URLSession is foreground/fail-fast: 8 s request timeout, 15 s resource timeout, `waitsForConnectivity = false`, and 16 HTTP/1.1 connections per host.
- Stream results publish **provider-by-provider in completion order**. The first provider returning usable links updates the visible Source Intelligence list immediately while slower providers continue.
- Find Links focus moves into the first stream as soon as the first result arrives; the user no longer waits for every configured addon before the first source is selectable.
- Search-result identity hydration now runs beside source discovery rather than before it. If the existing item identity works, hydration is cancelled; if not, the stronger identity is normally already ready for the fallback wave.
- In-S identity hydration is also shared as one parallel task rather than blocking ordinary addon discovery.
- Manifest `resources`, `types`, and `idPrefixes` are honored before a `/stream/...` request is emitted, preventing known-impossible endpoint calls.
- Pasted Stremio `/configure` pages are converted to their manifest candidates first; the app no longer burns the first network turn downloading an HTML configure page and trying to decode it as JSON.
- Movie searches no longer also query series endpoints and series searches no longer also query movie endpoints.
- A provider stops probing alternate type/ID aliases after a valid endpoint has already returned usable ranked links, preventing duplicate network work.
- Foreground provider budgets are bounded to 4–6 s for manifest resolution and 6–8 s for streams instead of allowing MediaFusion/other slow providers to dominate the entire search for tens of seconds.
- Source links have a bounded 4-minute **process-memory** cache; addon manifests have a bounded 15-minute memory cache. Reopening the same title/episode can show prior usable results on the first actor turn while a fresh provider wave updates them. No debrid/source links are persisted to disk.
- Recovery identity amplification is capped to three identities instead of up to six complete provider scans.
- PLAY starts the real player from the first ranked direct source Source Intelligence publishes; it no longer needs the full source wave to finish before starting playback.

## Catalog force-load / first-paint fixes

- Explicit Reload now **supersedes an already-running catalog generation** instead of waiting behind the request the user is trying to recover from.
- First catalog paint and explicit forced recovery bypass the durable frame-transition publication wait; that gate remains only when a stable catalog is already visible and a background swap can safely wait.
- Official catalog manifest/batch requests are foreground/fail-fast with one attempt (4.5 s manifest, 8 s batch) rather than stacked retries that could reach roughly a minute.
- If the official batch endpoint is unavailable, per-row first-page fallback runs in bounded parallel waves (12 official / 6 personal) rather than walking dozens of catalogs serially.
- Catalog recovery uses a dedicated URLSession with 16 per-host connections and no connectivity waiting, so the 12-lane official fallback is not silently collapsed back to the system shared-session connection limit.
- Manual Reload first requests the fast visible catalog and then performs long-shelf pagination in a background pass.
- Catalog recovery retry cadence starts at 1 s / 3 s / 8 s before backing off, so a transient first-launch miss is retried quickly.
- Durable cached catalog rows remain the first fallback and are never cleared merely because a fresh request fails.

## Preserved behavior

- Source ranking, provider labels, request headers, subtitles, alternate/fallback playback URLs, direct/debrid resolution semantics, and TorBox Usenet isolation remain intact.
- KSPlayer/VLC remain the real playback engines.
- vBRDC211 `MPNowPlayingSession`, Bluetooth/system media commands, Now Playing diagnostics, Trakt resync confirmation, and restore-code automatic Trakt resync remain in place.
- Movie / TV Show catalog type boundaries and existing visual layout are unchanged.

## Validation

GitHub Actions / Xcode with the tvOS SDK remains the authoritative full SDK compile. This package includes static regression contracts and Swift parser validation; physical source-provider timing still depends on the configured addon/debrid services and network.
