# vBRDC228 — Vertical Gracenote List + Guide Toggle Only

Build: **1.0.931 (931)**

Scope is intentionally limited to the unified Live TV presentation introduced in vBRDC225.

## Changes

- **Grid** remains the current 4 × 3 / 12-card horizontal page presentation.
- **List** is now the same current four-column Gracenote channel-card grid, but uses the older continuous vertical-scroll blueprint from the user-provided v987 build.
- List is presented as one continuous page from the first channel to the last while retaining the bounded 96-card focus/artwork corridor for tvOS performance.
- List uses the same current `liveTile` card, Gracenote program art, focus ring/motion, channel number placement, preview behavior, Favorites/Sports long-press actions, wallpaper, categories and playback behavior as Grid.
- LEFT/RIGHT remains normal four-column navigation in List. The existing deliberate Live Controls edge is available only from the first column.
- Playback return in List restores the exact channel through the vertical `ScrollViewReader` before rebinding focus.
- The old bottom-row/double-DOWN path to Guide has been removed. DOWN on Grid row 3 now stays on the focused channel.
- The old Guide glow/hint below Grid has been removed. **EPG is entered only through the unified Grid → List → EPG mode chip.**
- Grid page indicator remains unchanged.

No backend changes are required. Continue using backend v698.
