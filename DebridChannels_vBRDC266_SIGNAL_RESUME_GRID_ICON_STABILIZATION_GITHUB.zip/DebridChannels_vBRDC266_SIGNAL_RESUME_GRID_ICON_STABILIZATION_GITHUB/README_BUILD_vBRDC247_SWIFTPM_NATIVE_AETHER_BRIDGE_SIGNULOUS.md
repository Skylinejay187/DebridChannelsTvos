# vBRDC247 — SwiftPM-native Aether bridge / Signulous compatibility

Release: vBRDC247
Version: 1.0.950 (950)

## Why this build exists
vBRDC246 proved the Aether runtime itself is viable on tvOS because the same build installs via ATVLoadly, but Signulous rejects the re-signed app with an integrity verification failure. The remaining non-standard part of the bundle was the custom post-build injection of Aether's nine runtime frameworks.

## v247 correction
- `AetherPlaybackBridge` is now a local SwiftPM package product.
- The bridge package owns the local AetherEngine package transitively.
- AetherEngine continues to use namespaced FFmpegBuild 3.0.0 and LibDovi 2.1.0.
- The app depends only on `AetherPlaybackBridge`; it never imports AetherEngine or AetherLib modules directly.
- Removed the custom post-build copying of AetherLib*.framework into the app bundle.
- SwiftPM/Xcode now owns linking and embedding of the complete transitive binary framework graph, producing a standard re-signable application layout.
- KSPlayer remains on FFmpegKit 6.1.3 independently.

Playback behavior is intentionally unchanged from v246.
