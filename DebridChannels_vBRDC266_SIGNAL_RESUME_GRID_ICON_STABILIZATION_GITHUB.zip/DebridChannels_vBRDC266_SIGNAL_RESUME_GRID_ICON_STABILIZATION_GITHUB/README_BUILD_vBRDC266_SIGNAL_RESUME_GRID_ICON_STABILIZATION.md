# vBRDC266 — Signal resume / Live TV grid / icon stabilization

Version: 1.0.969 (969)

Priority corrections from v265 runtime testing:

- tvOS AppIcon uses the exact approved Signal artwork from v265, but removes the large outer black letterbox so the art fills the 5:3 Apple TV icon canvas like the former Debrid Channels icon. The 400x240 and 1280x768 brand-stack back layers and both raw fallback icon paths are synchronized; middle/front layers remain transparent.
- Durable VOD resume is again engine-independent. The saved checkpoint now seeds the shared internal-player `startTimeSeconds` path for both AetherEngine and KSPlayer, with the existing bounded seek reconciliation retained as backup.
- Manual Aether <-> KS engine handoff remains separate from durable resume and continues from the captured current-session decoder clock. Opening/focusing Player Engine remains playback-neutral and same-engine selection is a no-op.
- Live TV artwork prefetch waits 180 ms after rapid focus motion before starting background work, reducing cancel/recreate churn during fast Siri Remote scrolling. Visible program art is decoded/prefetched at a bounded 512 px working size; channel logos retain their existing high-quality 320 px lane.
- Top-menu focus scale feedback remains intact but settles in 100 ms instead of holding a longer 160 ms compositor animation during fast horizontal navigation.
- Accepted Aether 6.81 Live TV recovery ladder is unchanged. No VOD cache/timeshift implementation is included.

Validation performed in this package:
- all Swift files: `swiftc -parse`
- app + Top Shelf plists: `plutil -lint`
- project.yml: YAML parse
- version IDs synchronized to vBRDC266 / 1.0.969 / 969
- raw 1280x768 icon fallback pair byte-identical

GitHub/Xcode build and physical Apple TV runtime remain authoritative.
