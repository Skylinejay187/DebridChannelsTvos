# Debrid Channels vBRDC242 — Aether dynamic bridge isolation

Release: **vBRDC242**  
Version: **1.0.945 (945)**

## Build-error root cause fixed
vBRDC241 correctly restored KSPlayer to its native FFmpegKit 6.1.3 ABI and moved Aether to the 6.57.0 namespaced-FFmpeg coexistence release. GitHub then reached DebridChannelsTVOS module emission and exposed the remaining boundary problem: the app target itself depended on both engines, so Clang imported both generations of FFmpeg C declarations while emitting the one app Swift module. The resulting ODR failures included `AVBufferSrcParameters`, `AVColorSpace`, `AVChannel`, and color-enum definition mismatches.

## vBRDC242 architecture
- `DebridChannelsTVOS` depends on **KSPlayer** and **AetherPlaybackBridge** only.
- `AetherPlaybackBridge` is a **dynamic tvOS framework target**.
- The bridge uses `@_implementationOnly import AetherEngine` and exposes only Foundation/UIKit/Swift closure types.
- `AetherEngine` + `AetherFFmpegBuild 3.0.0` compile/link behind that dynamic framework boundary.
- KSPNUVIO keeps its original FFmpegKit 6.1.3 graph in the app target.
- No app source imports `AetherEngine` or any `AetherLibav*` module.

This follows AetherEngine 6.57.0's documented coexistence model for applications that keep a second FFmpeg-backed player.

## Regression locks preserved
Aether remains primary with KSPlayer fallback. Existing Debrid Channels ownership is unchanged for resume/progress, zero-delay prepared-source handoff, Now Playing/Bluetooth, source failover, playback chrome, Live TV unity, and the Live TV upward focus-to-Home correction.
