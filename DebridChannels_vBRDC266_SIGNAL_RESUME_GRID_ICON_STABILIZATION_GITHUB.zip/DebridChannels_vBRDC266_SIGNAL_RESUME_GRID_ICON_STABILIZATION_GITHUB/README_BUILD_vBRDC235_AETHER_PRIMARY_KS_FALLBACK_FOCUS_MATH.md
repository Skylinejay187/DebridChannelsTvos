# Debrid Channels vBRDC235 — Aether Primary / KS Fallback / Live TV Focus Math

Version: 1.0.938 (938)
Base: vBRDC234 / 1.0.937 (937)

## AetherEngine primary playback
- Adds AetherEngine as an SPM dependency (minimum 6.30.1 within the compatible 6.x line).
- Adds `PlaybackKitAetherSurface.swift` as the Aether renderer/transport adapter.
- AetherEngine is the primary internal renderer for VOD and automatic Live TV playback.
- KSPlayer remains the first compatibility fallback.
- An Aether failure hands the same selected source to KSPlayer at the current VOD position before existing source failover is allowed to move to another source.
- Debrid Channels remains the owner of resume/progress, PlaybackController clock snapshots, Now Playing/Bluetooth metadata, automatic source failover, overlay state, and Up Next behavior.
- Aether reuses the existing internal transport serials for play/pause and seeks so the overlay/Bluetooth command path is not forked.
- Local Alternate Audio remains KSPlayer-owned and automatically moves that presentation to KSPlayer rather than breaking the feature.
- Adds AetherEngine to both the VOD Player settings and the in-playback engine panel.

## Live TV upward focus fix
- Keeps card row detection page-local and computes the row explicitly from `localIndex / columnCount`.
- Up from the first channel row still traverses the Live TV header/mode-chip focus graph.
- When Live TV yields into the persistent top navigation, focus enters at Home while Live TV remains the selected content tab.
- This separates content selection from focus location and removes the snap back to the already-selected Live TV chip.

## Preserved from vBRDC234
- Nuvio-style zero-delay prepared-source handoff.
- PlaybackLaunchBenchmark target-membership build fix.
- Existing VOD overlay, progress/resume, Trakt flow, Now Playing/Bluetooth ownership, previews, source failover and Live TV unity tree.

## Validation performed in this package environment
- All app + Top Shelf Swift files pass `swiftc -parse` (one pre-existing KSPlayer indentation warning remains).
- `project.yml` parses as YAML and includes the Aether package/product and Aether surface source.
- Main app and Top Shelf plist versions match 1.0.938 / 938.
- Full tvOS/Xcode/SPM compilation must still be performed by GitHub Actions/Xcode because this Linux packaging environment does not contain Xcode/tvOS SDKs.
