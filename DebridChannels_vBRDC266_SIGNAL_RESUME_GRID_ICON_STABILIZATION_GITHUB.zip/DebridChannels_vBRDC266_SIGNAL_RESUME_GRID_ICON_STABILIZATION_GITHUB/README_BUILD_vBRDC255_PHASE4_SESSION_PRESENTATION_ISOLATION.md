# vBRDC255 — Phase 4 Session / Presentation Isolation

Version: 1.0.958 (958)
Release: vBRDC255
Baseline: successfully built vBRDC254 Phase 3 Playback State / Clock Isolation.

Scope is intentionally Phase 4 only. The existing Live TV Guide / Source Intelligence / app-wide hitching remains deferred to the Phase 5 performance pass. GitHub Actions build-speed optimization remains deferred until all phases/feature work are finished.

Phase 4 hardening in this candidate:
- Preserves AetherEngine as primary and KSPlayer as fallback/alternative for VOD and Live TV.
- Keeps the Aether runtime behind the signed SwiftPM dynamic bridge; no MPVKit and no manual DerivedData framework injection.
- Makes the Aether UIKit presentation host an opaque-black, clipped presentation island with no outer shadow/filter/compositing effect, targeting the reported bright gray/white halo and elevated-black rectangle around Aether video.
- Prevents Aether from initiating system display-mode/dynamic-range matching while SwiftUI VOD chrome/artwork is composited over the session. This targets the Aether-only poster/artwork color shift. KSPlayer display matching is unchanged.
- Leaves renderer-internal Metal/video layers owned by Aether; the app only hardens the outer host boundary.
- Reasserts deterministic black presentation during Aether teardown/source transitions to avoid stale renderer luminance leaking through the overlay.
- Preserves the single app-owned Now Playing / Bluetooth Play-Pause lane and existing session clock/first-frame/buffering ownership from Phase 3.
- Preserves manual engine-switch transient-state clearing and persistent long-term resume behavior.
- Preserves Live TV Aether selection so later Aether-native rolling timeshift can be built on the same engine/session path. No timeshift buffer is added in Phase 4.

Phase boundary note:
- Phase 5 remains responsible for codec/container compatibility, VideoToolbox/hardware decode behavior, HDR/Dolby Vision/color-space correctness, frame-rate presentation, difficult-stream fallback decisions, and the dedicated performance/hitching pass.
- Aether-native Live TV timeshift remains post-Phase-5 feature work after the playback/render foundation is hardened.
