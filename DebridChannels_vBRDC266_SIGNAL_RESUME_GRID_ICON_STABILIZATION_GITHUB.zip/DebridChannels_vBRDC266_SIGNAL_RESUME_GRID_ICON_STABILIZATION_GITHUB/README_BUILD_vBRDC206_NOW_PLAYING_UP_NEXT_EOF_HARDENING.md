# Debrid Channels vBRDC206 — System Now Playing + Up Next EOF Hardening

Release: vBRDC206
Version: 1.0.909
Build: 909
Donor/source of truth: vBRDC205 packaged ZIP only.

## System Now Playing
- Added one central DebridNowPlayingManager that owns MPNowPlayingInfoCenter publication.
- Existing VOD MPRemoteCommandCenter/Bluetooth Play/Pause bridge remains intact.
- Movies publish title, year/movie context, duration, position and play/pause rate.
- Episodes publish parsed episode title, parent series name, SxxExx identity, duration, position and play/pause rate.
- Live TV publishes current programme title, channel name, channel/category context, current programme elapsed/duration when EPG timing exists, and marks the stream live.
- Live programme metadata refreshes at the existing EPG boundary; no new polling clock was added.
- Presentation UUID ownership prevents a departing player generation from clearing or overwriting a newer episode/channel.

## End-of-episode / Up Next hardening
- Natural EOF is classified before isPlaying is set false, so EOF no longer enters the normal user-pause persistence path.
- Natural EOF is idempotent across KSPlayer completion, AVPlayer completion and the app-side EOF watchdog.
- The pause observer no longer performs synchronous resume flush, catalog-row rebuild, metadata fan-out, or Trakt pause work during a natural episode handoff.
- AVPlayer `.waitingToPlayAtSpecifiedRate` is treated as buffering, not Pause.
- The fallback EOF watchdog now waits until the clock is effectively at EOF instead of firing ~1.25 seconds early.
- Up Next provider work remains buffer-aware before EOF; low-buffer playback yields to the current decoder and can resolve after EOF instead.
- EOF provider retries are backoff-limited (2s / 4s / 8s) instead of being relaunched by the 500 ms watchdog.
- Decorative next-episode Production/intro work no longer starts from the outgoing episode at EOF.
- When a playable next episode is committed, all outgoing Up Next tasks are cancelled before CatalogStore publishes the replacement player.
- Trakt stop scrobble remains immediate, but the two cloud playback-list GETs are deferred until after the incoming episode has a stable decoder.
- If Up Next was dismissed or no next episode exists, natural completion still uses the lightweight EOF path and restores normal controls.

## Validation
- 68/68 Swift files syntax-parse.
- 9/9 vBRDC206 targeted regression contracts pass.
- 67 app Swift source files + 1 Top Shelf Swift source file present.
- Main app and Top Shelf report vBRDC206 / 1.0.909 / 909.
- project.yml parses successfully.
- Approved Assets.xcassets are byte-identical to vBRDC205.
