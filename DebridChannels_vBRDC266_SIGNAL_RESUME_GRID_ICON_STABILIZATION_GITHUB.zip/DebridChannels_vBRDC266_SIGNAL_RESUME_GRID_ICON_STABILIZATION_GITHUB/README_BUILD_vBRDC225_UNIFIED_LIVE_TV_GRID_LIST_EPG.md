# Debrid Channels vBRDC225 — Unified Live TV Grid / List / EPG

Version: 1.0.928 (928)
Release: vBRDC225

## Changes
- Added one Live TV presentation chip that cycles **Grid → List → EPG → Grid**.
- Grid, List and EPG now render from the same persistent `LiveTVSourceModel`; changing presentation does not refresh/reload the lineup or guide.
- Added a virtualized traditional vertical List renderer with channel logo, channel identity, current program, progress and next program.
- Preserves selected channel/category while changing presentation.
- EPG reuses the existing full Guide and preview pipeline rather than creating a second guide subsystem.
- The mode control remains available inside EPG as an overlay without disturbing the timeline/station-column math.
- Existing bottom-row double-DOWN Guide shortcut remains as an alternate path.
- Existing grid paging, focus preview, channel long-press actions, categories, Live Controls rail, dynamic wallpaper and playback paths remain intact.
- List mode uses the same bounded 96-channel virtual corridor and prefetch pipeline instead of mounting an unlimited focus tree.
- Presentation changes use lightweight opacity handoff only; no provider reload and no whole-lineup reconstruction.

Backend companion: v697 remains unchanged.
