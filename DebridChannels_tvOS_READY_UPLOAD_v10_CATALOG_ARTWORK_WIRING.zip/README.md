# Debrid Channels tvOS Upload Package v10
Upload this repo zip to GitHub. Run `00 Build tvOS IPA From Source ZIP`.

This version starts real catalog/artwork wiring while leaving Real Debrid/Torbox off for now.
