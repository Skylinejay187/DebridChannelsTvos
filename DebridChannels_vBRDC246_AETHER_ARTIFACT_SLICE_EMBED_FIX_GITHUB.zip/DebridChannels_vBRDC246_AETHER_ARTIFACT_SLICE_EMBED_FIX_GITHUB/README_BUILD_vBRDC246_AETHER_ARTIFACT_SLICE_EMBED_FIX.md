# Debrid Channels vBRDC246 — Aether SwiftPM artifact-slice embed fix

Release: **vBRDC246**
Version: **1.0.949 (949)**

This build fixes the vBRDC245 post-build failure where Xcode 16.4 successfully linked `AetherPlaybackBridge.framework` against the Aether dynamic FFmpeg frameworks, but the post-build phase assumed those binary frameworks would still exist under `Build/Products/Release-appletvos/PackageFrameworks`.

The resolver now:

- Uses `PackageFrameworks` when Xcode still exposes the linked framework there.
- Otherwise resolves the persistent binary-target XCFramework under `DerivedData/SourcePackages (including checkouts/artifacts)`.
- Selects only a physical tvOS device framework slice and rejects simulator candidates.
- Embeds all nine Aether runtime frameworks into the app bundle.
- Keeps Dovi linked statically as `-ldovi` through the bridge.
- Audits the bridge and every embedded Aether framework with `otool -L` and fails the GitHub build if any `@rpath/Aether*.framework` dependency is absent.

No playback behavior was intentionally changed. Aether primary, KSPlayer fallback, Nuvio-style prepared-source handoff, resume/progress, Now Playing/Bluetooth ownership, failover, previews, and Live TV focus behavior are preserved.
