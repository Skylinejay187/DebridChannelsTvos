import Foundation

// DEBRID_CHANNELS_TVOS_BUILD_V84_CLEAN_ARCHITECTURE_REWRITE
// v84 cleanup rule:
// 1. v73 Home/detail geometry remains the baseline.
// 2. Active detail background no longer uses the old heavy smoke/timeline stack.
// 3. Detail screen uses one manual DPAD focus graph for Play, Trailer, Find Links, Close,
//    Search Links, stream chips, and More Like This cards.
// 4. VOD playback stays on a custom AVPlayerLayer surface, not SwiftUI VideoPlayer.
// 5. Codec strategy is modular: AVFoundation primary now; VLC/FFmpeg fallback can be added
//    behind the same player boundary later without redesigning the overlay.
