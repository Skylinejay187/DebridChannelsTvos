# Debrid Channels tvOS v84 Clean Architecture Rewrite

Upload this ZIP to GitHub and run the included workflow.

Preserved frozen visual baseline:
- v73 Home layout
- v73 media/detail geometry
- Signulous-compatible unsigned IPA structure

v84 changes:
- Deleted the active laggy background effect path and replaced it with a single UIKit/CALayer cinematic layer.
- Added a manual DPAD focus graph for the media information screen.
- Play, Trailer, Find Links, Close, Search Links, stream chips, More Like This, and top-menu handoff are explicitly routed.
- Kept custom AVPlayerLayer VOD surface with Debrid Channels overlay.
- Added a real player test fallback: if no resolved VOD stream exists but a direct preview/sample URL exists, Play opens it in the custom VOD player.
- Added module boundary notes for future VLC/FFmpeg codec fallback.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V84_CLEAN_ARCHITECTURE_REWRITE`
