# Debrid Channels tvOS v349

Universal Search v1 + Live TV grid pop animation upgrade.
