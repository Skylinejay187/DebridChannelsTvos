# Debrid Channels tvOS v97 Stremio API Contract Restore

Upload this ZIP to the GitHub repository root and run the included build workflow.

## What changed

- Restores Stremio addon loading around the real Stremio endpoint contract:
  - `/manifest.json`
  - `/catalog/{type}/{id}.json`
  - `/catalog/{type}/{id}/{extra}.json`
  - `/meta/{type}/{id}.json` support boundary
  - `/stream/{type}/{id}.json`
  - `/subtitles/{type}/{id}/{extra}.json` support boundary
- Fixes manifest decoding for addons whose `resources` array uses string form such as `["catalog", "meta", "stream"]` instead of object form.
- Keeps catalog providers and stream-only providers separated so Torrentio/TorBox-style addons cannot wipe Home rows.
- Improves catalog endpoint fallback using Stremio-valid extra paths such as `skip=0`, `genre=popular`, and `search=`.
- Keeps v94/v95/v96 player fallback path and v73 visual baseline.

## Build marker

`DEBRID_CHANNELS_TVOS_BUILD_V103_CAREFUL_VOD_FOCUS_REBUILD`

## Important

Torrentio/TorBox stream-only addons usually do not add Home catalog rows. They should stay active for Find Links while Cinemeta or another catalog-capable addon supplies movie/show rows and IMDb IDs.


V99: Fixes CatalogStore StremioResource CodingKeys compile error while preserving v97 Stremio API contract restore.


## v101
Fixed Stremio catalog rows failing with 'data could not be read because it is not in the correct format' by making manifest extras and catalog metas decode tolerant of real-world Stremio JSON field variations.


## v103
Careful VOD focus rebuild. Native tvOS white button plates are removed from the VOD overlay controls; custom focusable controls and a player-action debounce are used instead.
