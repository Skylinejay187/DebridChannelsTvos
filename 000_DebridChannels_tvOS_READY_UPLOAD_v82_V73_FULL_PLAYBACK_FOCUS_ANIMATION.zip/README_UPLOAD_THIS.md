Debrid Channels tvOS v82 — V73 Full Playback + Focus + Animation Rewire

Upload this ZIP to GitHub as-is. The included GitHub Actions workflow builds the unsigned tvOS IPA from the ZIP contents.

Base preserved:
- v73 approved Home visual/layout baseline
- v73 approved media information/detail visual/layout baseline
- v80/v81 real-app wiring branch used as source base

What changed in v82:
- Full custom AVPlayerLayer VOD surface remains in place so Apple's original/native overlay does not appear.
- Added real stream handoff path from Play / Find Links / stream chip into AVPlayer.
- Added real player states: loading, playback error display, current time, duration, real progress bar, play/pause, -10/+10 seeking, close, and auto-hide controls.
- Added working zoom toggle between fit and fill.
- Added audio/subtitle media-selection cycling when the stream exposes AVPlayer-readable tracks.
- Kept Episode/Settings buttons wired as selectable controls instead of dead buttons.
- Raised the persistent top menu above the detail screen and added a top visibility scrim so it stays readable in the same position as the approved hero section.
- Added focus sections for detail buttons, stream links, More Like This, player controls, and persistent top menu routing.
- Added full-screen ambient motion layer on media detail so the background movement travels around the screen instead of staying mostly in the middle.
- Updated build/log marker: DEBRID_CHANNELS_TVOS_BUILD_V82_V73_FULL_PLAYBACK_FOCUS_ANIMATION

Important:
- Home layout was not redesigned.
- Detail/media information layout was not redesigned.
- This build is additive wiring only: player capability, click/focus routing, menu visibility, and full-screen ambient motion.
