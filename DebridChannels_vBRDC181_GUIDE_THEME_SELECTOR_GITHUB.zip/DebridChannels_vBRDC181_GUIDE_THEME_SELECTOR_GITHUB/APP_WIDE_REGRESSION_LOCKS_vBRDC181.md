# vBRDC181 Regression Locks

- v180 Live TV card appearance remains unchanged.
- v179/v180 Live TV header, All Channels/Up Next content, paging, page indicator, focus behavior, and logo hardening remain unchanged.
- Guide preview and Exit/Back hint remain unchanged.
- Guide presentation geometry remains unchanged from v180.
- New Guide Theme control affects Guide color/theme presentation only.
- "Follow Live TV Grid" mirrors the Live TV Grid Background setting.
- CatalogStore, KSPNUVIO, PlaybackKit Alternate Audio, Favorites, Sports, and adaptive VOD cache behavior remain unchanged.
