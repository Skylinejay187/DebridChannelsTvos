# Debrid Channels vBRDC181 — Guide Theme Selector

Marketing version: 1.0.884  
Apple build: 884

Built only from packaged vBRDC180.

## Change

Adds an independent **Live TV Guide Theme** control under Appearance.

- Default: **Follow Live TV Grid** — Guide mirrors the existing Live TV Grid Background theme.
- Or pin Guide independently to any existing Live TV theme preset.
- Pure Black remains neutral black/white.
- Grid theme and Guide theme can now be changed independently.
- Guide theme persists through profile backup/restore and Stable UI reset.

## Preserved

No Live TV card visual changes, Guide geometry changes, preview changes, paging changes, catalog changes, playback changes, Alternate Audio changes, Favorites changes, Sports changes, or adaptive VOD cache changes were made in this release.
