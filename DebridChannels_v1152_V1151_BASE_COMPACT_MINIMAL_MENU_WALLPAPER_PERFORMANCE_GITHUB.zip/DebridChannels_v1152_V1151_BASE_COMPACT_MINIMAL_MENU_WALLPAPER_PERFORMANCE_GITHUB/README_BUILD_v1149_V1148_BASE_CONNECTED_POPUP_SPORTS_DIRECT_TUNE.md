# Debrid Channels v1149

v1149 is a surgical corrective build from packaged v1148.

- Marketing version: 1.0.677
- Build: 677
- Backend: v674 unchanged

Corrections:

1. Appearance → Connected Popup Background Artwork now produces clearly visible contained movie/show artwork when enabled and no popup artwork when disabled.
2. Sports live-channel cards bypass VOD Media Information and tune immediately on Select or Play/Pause.
3. The working v1148 automatic scrubber is untouched.
4. The v1130-derived v1148 automatic resume implementation is untouched.

See `DEEP_AUDIT_v1149_CONNECTED_POPUP_SPORTS_DIRECT_TUNE.md` and `Validation_v1149/` for details.
