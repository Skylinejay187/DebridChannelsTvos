# v1145 Resume + Scrubber Contract

- Source base is packaged v1144 only.
- Saved resume storage is not rewritten; `PlaybackResumeCache.swift` remains byte-identical to v1144.
- Restore the stronger v1138 startup timing model on the current Phase 15 line: prime KSPlayer with the saved start timestamp before surface creation, wait for a genuine advancing clock or first-frame readiness, confirm if the real clock is already within ±5 seconds, otherwise issue one in-place absolute corrective seek.
- Automatic/manual resume must not increment the KSPlayer surface reload token.
- Normal user seeking remains preview-first and commits once with Select/Up/Down.
- LEFT/RIGHT while the timeline owns focus must immediately show the selected target time, remaining time, and preview percentage before Select is pressed.
- Live TV, Source Intelligence, Alternate Audio, player engine wrappers, PlaybackKit implementation, resume storage, and backend v674 remain unchanged.
