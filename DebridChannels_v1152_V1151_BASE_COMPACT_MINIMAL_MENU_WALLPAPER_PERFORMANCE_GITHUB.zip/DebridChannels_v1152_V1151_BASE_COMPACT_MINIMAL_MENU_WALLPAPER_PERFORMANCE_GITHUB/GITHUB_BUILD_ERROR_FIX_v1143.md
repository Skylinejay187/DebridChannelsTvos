# v1143 GitHub Build Error Correction

Source base: packaged v1142 only.

The uploaded GitHub Actions log contains **two distinct app-target compile blockers**. The repeated CatalogStore diagnostics are the same source error emitted by multiple compile jobs, not many unrelated failures.

1. `Sources/CatalogStore.swift:9162` — `MediaItem.id` is declared `let`, but the v1141 full-season correction attempted `seriesItem.id = ...`. v1143 no longer mutates the immutable identity. It builds a parent-series lookup copy with the normalized parent ID while leaving the playing episode object untouched.
2. `Sources/DebridChannelsTVOSApp.swift:23208` — Xcode timed out type-checking the enlarged `V1134CastCreditCard.body`. v1143 decomposes the card into small typed child views and explicit `AnyView` compiler boundaries for visual, focus and accessibility stages. The app-owned orange focus treatment, selection callback and accessibility behavior remain.

The KSPNUVIO actor-isolation and AVFoundation deprecation entries in the log are warnings, not the build-stopping errors.

Version: 1.0.671 / build 671. Backend remains v674.
