# Debrid Channels vBRDC153 — Live TV Bootstrap Transport Recovery

- Base: packaged **vBRDC152** only
- Marketing version: **1.0.856**
- Apple build: **856**
- Release ID: **vBRDC153**

## Physical-device report

vBRDC152 still remained on the built-in demo lineup and showed the Live TV loading spinner instead of publishing the configured real channels.

## Root cause addressed

vBRDC152 fixed the *publication order* (real lineup before guide enrichment), but that cannot help when the lineup bootstrap response never makes it through the transport layer.

When MediaFlow is configured on an `http://` address, the Live TV `fetchText` path previously forced the already-routed bootstrap request through `PlainHTTPClient`. That helper is deliberately a minimal raw HTTP/1.1 compatibility client. It handles basic/chunked responses, but it does not provide URLSession's normal redirect and response-content-decoding behavior. A MediaFlow/API/M3U response that depends on those normal HTTP behaviors can therefore return no parseable lineup even though the MediaFlow route itself is valid.

The old source probing could amplify that failure: Channels DVR could stack multiple long M3U/device retries, external XMLTV could sit in front of a valid Xtream lineup, and a true zero-provider result could still wait on later frame/guide work before releasing the spinner.

## vBRDC153 correction

1. **URLSession-first bootstrap transport for HTTP and HTTPS**
   - The configured MediaFlow route is still used exactly as before.
   - `URLSession` is now the primary transport for both `http://` and `https://` bootstrap requests.
   - This restores normal redirect, chunking/content-decoding, and response-framing behavior.
   - `PlainHTTPClient` remains only as a final compatibility fallback for a failed plain-HTTP URLSession request.
   - Both paths request identity encoding where appropriate.

2. **MediaFlow policy preserved**
   - MediaFlow OFF: original direct provider request remains.
   - MediaFlow ON: ordinary Live TV bootstrap remains on `/proxy/stream`.
   - XMLTV/Gracenote remains `/proxy/epg` first with `/proxy/stream` compatibility fallback.
   - Invalid enabled MediaFlow configuration still fails closed.
   - Final Live TV playback/preview routing is unchanged.

3. **Bounded provider probes**
   - Explicit HDHomeRun remains first when configured.
   - Channels DVR now tries canonical M3U, aggregate `ANY` JSON, then only bounded compatibility fallbacks.
   - Named-device fallback is capped instead of walking an unbounded device list.
   - HDHomeRun manual alternatives stop at the first real lineup.
   - Xtream API and M3U fallback probes use bounded single attempts.

4. **Every lineup gets a chance before standalone guide work**
   - M3U and Xtream lineups are attempted before external XMLTV enrichment.
   - A dead external XMLTV URL can no longer delay a valid Xtream lineup.
   - Xtream XMLTV is deferred until after Xtream channels have already been published.

5. **No indefinite zero-channel spinner**
   - If every configured provider truly returns zero channels, the model now exits the loading state immediately with the accumulated provider status rather than waiting on guide/frame publication work.

## Preserved unchanged

- vBRDC151 Live TV channel-number setting: Top Right / Bottom Right / Off.
- vBRDC150 subtle bottom-right page-position presentation.
- vBRDC149 top-menu theme engine and Live TV animated header-logo choices.
- vBRDC143–146 paged 4×3 Live TV grid, double-edge paging, Guide entry/exit, Guide hints, focused preview behavior, and focus styling.
- vBRDC142 post-VOD Live TV artwork rehydration.
- Gracenote/XMLTV data remains an enrichment layer after real channel identity is available.
- VOD, Sports, Favorites, Search, playback, Bluetooth, debrid/Usenet, Source Intelligence, and catalog visual logic.

## Validation

- vBRDC153 targeted contract: **35/35 PASS**
- Production Swift syntax parse: **64/64 PASS**
- Backend regression: **36 passed + 2 subtests**
- Plist/project version validation: PASS
- Donor diff: only Live TV bootstrap transport/provider source, raw HTTP fallback helper, and release metadata changed among existing vBRDC152 files.

GitHub Actions/Xcode remains the authoritative tvOS compile, and a physical Apple TV using the user's actual MediaFlow/provider configuration remains the authoritative runtime test.
