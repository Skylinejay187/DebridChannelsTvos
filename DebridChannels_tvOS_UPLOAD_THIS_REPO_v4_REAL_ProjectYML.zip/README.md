Upload this repo package contents to GitHub. The workflow builds the IPA from source_zip/DebridChannelsTVOS_Source.zip.
