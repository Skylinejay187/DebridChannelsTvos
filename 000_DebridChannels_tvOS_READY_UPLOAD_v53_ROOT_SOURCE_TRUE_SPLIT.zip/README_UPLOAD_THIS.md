V53 ROOT SOURCE PACKAGE

This package is intentionally NOT nested inside source_zip.
If your old workflow scans ZIP files, upload this ZIP with its 000_ filename so it is extracted first.
If replacing repository contents, extract this ZIP and upload the DebridChannelsTVOS folder plus .github workflow.
Settings must show: Build v53 TRUE SPLIT ACTIVE ROOT SOURCE.
