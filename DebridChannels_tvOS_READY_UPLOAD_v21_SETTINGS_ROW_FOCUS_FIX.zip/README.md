Debrid Channels tvOS v21

Ready-to-upload GitHub package.
GitHub Actions builds an unsigned tvOS IPA from the embedded source ZIP.

v21 fixes:
- Settings menu remains visible/reachable
- Settings buttons use tvOS-safe clickable Button(.plain)
- Catalog load buttons reachable
- Row raised slightly
- Unfocused cards dim until focused
- Focus remains custom blue glow, no default white card focus box
