# vBRDC349 — Settings-Only Permanent Expanded Canvas

Base: **vBRDC348 / 1.0.1050 (1050)**, preserving the production Preview Mirror dashboard and the v347 long-session lifecycle fixes it inherits. This candidate changes Settings layout geometry only, not the Live TV grid.

Settings now always uses the exact preexisting Expanded App Canvas dimensions and offsets: root 1880×1010, left/top inset 24/66; title and category strip width 1810; settings pane width 1770; inner scrolling panel 1710×670. It behaves the same with the global Expanded App Canvas switch On **or** Off. No new preference, mode or on-appear global toggle was introduced.

The existing Expanded App Canvas switch remains, retains its `appCanvasExpandedV1` key, and continues controlling the other screens (including Live TV). Its description now makes the independent Settings behavior explicit. The user’s persisted switch value, settings backup/restore, card geometry, Preview Mirror, Gracenote and backend are untouched.

Validation: source syntax parsing and static isolation regression checks and ZIP integrity are required before shipping. Full Xcode/tvOS compilation and on-device layout/focus verification must still be performed; Swift parser success alone does not prove a successful Xcode build.

App version: **1.0.1051**, build **1051**.
