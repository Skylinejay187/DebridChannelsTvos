# Stage 20 — Restore Preflight Validation

Based on Stage 19 source. Before applying any local UserDefaults values from a backend restore, sanitize and reject empty/incompatible, excessive-key-count, or non-property-list-compatible settings and credential vault payloads. The restore UI explicitly reports rejection with existing local settings preserved.

This is not transactional restore or automatic rollback. An error after writes begin may still leave partial changes. Full tvOS compilation and runtime testing have not been performed. Existing optional Settings first-run invitation remains; automatic post-entitlement wizard presentation is not yet implemented. Do not install as a tested release.

Swift frontend syntax parsing performed on main app source. GitHub Actions tvOS build remains pending.
