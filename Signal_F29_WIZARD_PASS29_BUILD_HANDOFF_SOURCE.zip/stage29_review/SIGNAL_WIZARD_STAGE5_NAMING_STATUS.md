# Stage 5 — Find Signal settings naming

- Renamed the Settings wizard launcher from **Setup Signal** to **Find Signal**.
- Added an adjacent **Restore Signal** launcher that opens the existing Smart Restore experience.
- Renamed the wizard's restore selection to **Restore Signal**.
- Preserved the welcome headline **Let's Find Your Signal**.
- Did not modify membership gating, playback, restore engine behavior, or backend logic.
- Swift frontend parse passed. Full tvOS compilation and device testing not performed.
- This is a naming/navigation checkpoint, not a complete acquisition wizard.
