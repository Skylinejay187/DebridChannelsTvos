import SwiftUI
import Foundation

struct MediaItem: Identifiable, Hashable {
    let id: String
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String? = nil
}

struct MediaRow: Identifiable, Hashable {
    let id: String
    var title: String
    var items: [MediaItem]
}

struct StreamLink: Identifiable, Hashable {
    let id = UUID()
    var title: String
    var url: String?
    var quality: String
    var size: String
    var source: String
    var infoHash: String? = nil
    var fileIndex: Int? = nil
    var subtitleURLs: [String] = []

    var isDirectPlayable: Bool {
        guard let url else { return false }
        guard let components = URLComponents(string: url), let scheme = components.scheme?.lowercased(), scheme == "http" || scheme == "https" else { return false }
        let lower = url.lowercased()
        // v92: Debrid providers such as TorBox/Real-Debrid often return signed CDN URLs with no file extension.
        // Treat HTTP(S) stream.url as playable unless it is clearly a webpage/configuration/deep-link.
        if lower.hasPrefix("stremio://") || lower.hasPrefix("magnet:") { return false }
        if lower.contains("/configure") || lower.contains("youtube.com") || lower.contains("youtu.be") { return false }
        if lower.contains("imdb.com/title") || lower.contains("themoviedb.org") { return false }
        return true
    }
}

struct StremioStreamResponse: Decodable {
    var streams: [StremioStream]?
}

struct StremioStream: Decodable {
    var title: String?
    var name: String?
    var url: String?
    var infoHash: String?
    var externalUrl: String?
    var fileIdx: Int?
    var behaviorHints: StremioBehaviorHints?
    var subtitles: [StremioSubtitle]?
}

struct StremioSubtitle: Decodable, Hashable {
    var id: String?
    var url: String?
    var lang: String?
    var language: String?
    var label: String?
}

struct StremioBehaviorHints: Decodable {
    var filename: String?
    var videoSize: Int64?
    var videoHash: String?
    var bingeGroup: String?
}

struct StremioManifest: Decodable {
    var name: String?
    var catalogs: [StremioCatalog]?
    var resources: [StremioResource]?
    var types: [String]?
    var idPrefixes: [String]?
}

struct StremioResource: Decodable, Hashable {
    var name: String?
    var types: [String]?
    var idPrefixes: [String]?
}

struct StremioCatalog: Decodable, Hashable {
    var type: String?
    var id: String?
    var name: String?
}

struct CatalogResponse: Decodable {
    var metas: [StremioMeta]?
}

struct StremioTrailer: Decodable {
    var source: String?
    var type: String?
    var title: String?
}

struct StremioVideo: Decodable {
    var url: String?
    var src: String?
    var source: String?
    var type: String?
    var title: String?
}

struct StremioMeta: Decodable {
    var id: String?
    var name: String?
    var type: String?
    var poster: String?
    var background: String?
    var logo: String?
    var description: String?
    var releaseInfo: String?
    var genres: [String]?
    var imdbRating: String?
    var trailers: [StremioTrailer]?
    var videos: [StremioVideo]?
    var trailer: String?
    var preview: String?
    var previewVideo: String?
}

enum AppTab: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case live = "Live TV"
    case settings = "Settings"
    var id: String { rawValue }
}

@MainActor
final class CatalogStore: ObservableObject {
    @Published var rows: [MediaRow] = CatalogStore.demoRows()
    @Published var selectedTab: AppTab = .home
    @Published var status: String = "Build v95 STREMIO RESTORE: robust manifest/configure/stremio:// normalization, streaming-only addon support, and direct-link playback preservation."
    @Published var menuFocusToken: Int = 0
    @Published var isLoading: Bool = false
    @Published var manifestURLs: [String] = []
    @Published var selectedDetail: MediaItem? = nil
    @Published var playbackURL: URL? = nil
    @Published var playbackItem: MediaItem? = nil
    @Published var playbackFallbackURLs: [URL] = []
    @Published var playbackSubtitleURLs: [URL] = []
    @Published var playbackLinkLabel: String = ""
    @Published var streamLinks: [StreamLink] = []
    @Published var lastStreamMessage: String = ""
    @Published var detailBackStack: [MediaItem] = []

    private let manifestsKey = "stremioManifestURLs"
    private let coreMetadataManifestURL = "https://v3-cinemeta.strem.io/manifest.json"

    init() {
        let saved = UserDefaults.standard.stringArray(forKey: manifestsKey) ?? []
        if saved.isEmpty {
            manifestURLs = [coreMetadataManifestURL]
        } else {
            // v95 regression fix: stream-only addons like Torrentio/TorBox usually do not provide catalogs.
            // Keep Cinemeta metadata available so Home rows/detail items still have real imdb IDs to query streams with.
            var restored = saved
            if !restored.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
                restored.insert(coreMetadataManifestURL, at: 0)
            }
            manifestURLs = restored
            UserDefaults.standard.set(restored, forKey: manifestsKey)
        }
    }

    func resetDemo() {
        rows = Self.demoRows()
        status = "Demo rows restored."
    }

    func directPreviewURL(for item: MediaItem) -> URL? {
        guard let preview = item.previewURL, let url = URL(string: preview) else { return nil }
        let lower = preview.lowercased()
        // AVPlayer needs a direct MP4/M3U8/MOV style URL. YouTube page IDs/links must be converted by backend.
        if lower.contains("youtube.com") || lower.contains("youtu.be") { return nil }
        return url
    }

    func findStreams(for item: MediaItem) async -> [StreamLink] {
        lastStreamMessage = "Searching every configured Stremio addon for \(item.title)…"
        streamLinks = []

        let urlSession = URLSession.shared
        let typeCandidates = streamTypeCandidates(for: item)
        let idCandidates = streamIDCandidates(for: item)
        var found: [StreamLink] = []
        var seenKeys = Set<String>()
        var attempts = 0
        var addonFailures: [String] = []

        for rawManifest in manifestURLs {
            let manifestCandidates = manifestURLCandidates(from: rawManifest)
            var manifestDecoded: StremioManifest? = nil
            var workingManifestURL: URL? = nil

            for candidate in manifestCandidates {
                guard let candidateURL = URL(string: candidate) else { continue }
                do {
                    let (data, response) = try await urlSession.data(from: candidateURL)
                    if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                    manifestDecoded = try JSONDecoder().decode(StremioManifest.self, from: data)
                    workingManifestURL = candidateURL
                    break
                } catch {
                    continue
                }
            }

            guard let manifestURL = workingManifestURL else {
                addonFailures.append("Could not load manifest from \(rawManifest). Configure-page URLs must resolve to /manifest.json or a configured addon URL.")
                continue
            }

            let base = normalizedStremioBase(from: manifestURL.absoluteString)
            let sourceName = manifestDecoded?.name ?? manifestURL.host ?? "Stremio"
            let addonTypes = expandedStreamTypes(typeCandidates: typeCandidates, manifest: manifestDecoded)
            let addonIDs = idCandidates

            for type in addonTypes {
                for streamID in addonIDs {
                    guard let encodedID = streamID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                          let streamURL = URL(string: "\(base)/stream/\(type)/\(encodedID).json") else { continue }
                    attempts += 1
                    do {
                        let (data, response) = try await urlSession.data(from: streamURL)
                        if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                        let decoded = try JSONDecoder().decode(StremioStreamResponse.self, from: data)
                        for stream in decoded.streams ?? [] {
                            let title = stream.title ?? stream.name ?? stream.behaviorHints?.filename ?? "Stream"
                            // Stremio convention: `url` is the playable URL when the addon has resolved it.
                            // `externalUrl` is usually a browser/page handoff, so keep it visible but do not treat it as guaranteed playback.
                            let playableURL = stream.url ?? stream.externalUrl
                            let sizeText: String
                            if let bytes = stream.behaviorHints?.videoSize, bytes > 0 {
                                let gb = Double(bytes) / 1_073_741_824.0
                                sizeText = String(format: "%.1f GB", gb)
                            } else {
                                sizeText = parsedSizeText(from: title) ?? "Unknown size"
                            }
                            let quality = parsedQuality(from: title)
                            let key = "\(sourceName)|\(playableURL ?? stream.infoHash ?? title)|\(stream.fileIdx ?? -1)"
                            guard !seenKeys.contains(key) else { continue }
                            seenKeys.insert(key)
                            let subtitleURLs = (stream.subtitles ?? []).compactMap { sub -> String? in
                                guard let raw = sub.url?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
                                return raw
                            }
                            found.append(StreamLink(title: title, url: playableURL, quality: quality, size: sizeText, source: sourceName, infoHash: stream.infoHash, fileIndex: stream.fileIdx, subtitleURLs: subtitleURLs))
                        }

                        if !found.isEmpty {
                            streamLinks = sortedStreamLinks(found)
                            lastStreamMessage = "Found \(streamLinks.count) link(s) so far. Still scanning all addons…"
                        }
                    } catch {
                        continue
                    }
                }
            }
        }

        let sorted = sortedStreamLinks(found)
        streamLinks = sorted
        if sorted.isEmpty {
            let failureHint = addonFailures.isEmpty ? "" : " \(addonFailures.prefix(2).joined(separator: " "))"
            lastStreamMessage = "No stream links found for \(item.title) after \(attempts) stream endpoint checks.\(failureHint) For Torrentio/TorBox, add the actual configured manifest URL, not only the configure webpage, and make sure the addon returns stream.url/direct links."
        } else {
            let playableCount = sorted.filter { $0.isDirectPlayable }.count
            lastStreamMessage = "Found \(sorted.count) total link(s), \(playableCount) direct-playable, for \(item.title) across all configured addons."
        }
        return sorted
    }

    private func manifestURLCandidates(from raw: String) -> [String] {
        // v95: Accept the real-world formats people paste from Stremio/Torrentio/TorBox:
        // - https://addon/config/manifest.json
        // - https://addon/configure
        // - https://addon/configure?...
        // - stremio://addon/config/manifest.json
        // - stremio://addon/configure
        // - stremio:///addon/config/manifest.json
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return [] }
        var candidates: [String] = []
        func add(_ value: String) {
            var trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { return }
            if trimmed.hasPrefix("stremio:///") { trimmed = "https://" + String(trimmed.dropFirst("stremio:///".count)) }
            if trimmed.hasPrefix("stremio://") { trimmed = "https://" + String(trimmed.dropFirst("stremio://".count)) }
            while trimmed.hasSuffix("/") { trimmed.removeLast() }
            guard !trimmed.isEmpty, !candidates.contains(trimmed) else { return }
            candidates.append(trimmed)
        }

        add(clean)

        let httpsClean: String
        if clean.hasPrefix("stremio:///") {
            httpsClean = "https://" + String(clean.dropFirst("stremio:///".count))
        } else if clean.hasPrefix("stremio://") {
            httpsClean = "https://" + String(clean.dropFirst("stremio://".count))
        } else {
            httpsClean = clean
        }
        let lower = httpsClean.lowercased()

        // If a configured manifest URL is embedded inside a copied text/link, extract it.
        if let range = httpsClean.range(of: #"https?://[^\s"'<>]+/manifest\.json"#, options: .regularExpression) {
            add(String(httpsClean[range]))
        }

        if lower.hasSuffix("/manifest.json") {
            add(httpsClean)
        } else if lower.hasSuffix("/configure") {
            add(String(httpsClean.dropLast("/configure".count)) + "/manifest.json")
        } else if lower.contains("/configure?") || lower.contains("/configure#") {
            if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
                let pathWithoutConfigure = url.path.replacingOccurrences(of: "/configure", with: "")
                if !pathWithoutConfigure.isEmpty, pathWithoutConfigure != "/" {
                    add("\(scheme)://\(host)\(pathWithoutConfigure)/manifest.json")
                }
                add("\(scheme)://\(host)/manifest.json")
            }
        } else if let url = URL(string: httpsClean), let scheme = url.scheme, let host = url.host {
            // If user pasted the configured addon base without manifest.json, try preserving its path first.
            if !url.path.isEmpty, url.path != "/" {
                add("\(scheme)://\(host)\(url.path)/manifest.json")
            }
            // Root addon fallback for links like https://torrentio.strem.fun/configure.
            add("\(scheme)://\(host)/manifest.json")
        }
        return candidates
    }

    private func normalizedStremioBase(from manifest: String) -> String {
        var base = manifest
        if base.lowercased().hasSuffix("/configure") { base.removeLast("/configure".count) }
        if base.hasSuffix("/manifest.json") { base.removeLast("/manifest.json".count) }
        if base.hasSuffix("manifest.json") { base.removeLast("manifest.json".count) }
        while base.hasSuffix("/") { base.removeLast() }
        return base
    }

    private func expandedStreamTypes(typeCandidates: [String], manifest: StremioManifest?) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            guard !clean.isEmpty, !ordered.contains(clean) else { return }
            ordered.append(clean)
        }
        typeCandidates.forEach { add($0) }
        manifest?.types?.forEach { add($0) }
        manifest?.resources?.filter { $0.name == "stream" }.forEach { resource in
            resource.types?.forEach { add($0) }
        }
        add("movie")
        add("series")
        return ordered
    }

    private func parsedQuality(from title: String) -> String {
        let lower = title.lowercased()
        if lower.contains("2160") || lower.contains("4k") || lower.contains("uhd") { return "4K" }
        if lower.contains("1080") { return "1080p" }
        if lower.contains("720") { return "720p" }
        if lower.contains("480") { return "480p" }
        return "Auto"
    }

    private func parsedSizeText(from title: String) -> String? {
        let pattern = #"(?i)(\d+(?:\.\d+)?)\s*(GB|MB)"#
        guard let regex = try? NSRegularExpression(pattern: pattern), let match = regex.firstMatch(in: title, range: NSRange(title.startIndex..., in: title)), let range = Range(match.range, in: title) else { return nil }
        return String(title[range])
    }

    private func sortedStreamLinks(_ links: [StreamLink]) -> [StreamLink] {
        let rank: [String: Int] = ["4K": 0, "1080p": 1, "720p": 2, "480p": 3, "Auto": 4]
        return links.sorted { lhs, rhs in
            let lDirect = lhs.isDirectPlayable ? 0 : 1
            let rDirect = rhs.isDirectPlayable ? 0 : 1
            if lDirect != rDirect { return lDirect < rDirect }
            return (rank[lhs.quality] ?? 9) < (rank[rhs.quality] ?? 9)
        }
    }

    private func streamTypeCandidates(for item: MediaItem) -> [String] {
        let lower = item.type.lowercased()
        if lower.contains("series") || lower.contains("show") { return ["series", "movie"] }
        return ["movie", "series"]
    }

    private func streamIDCandidates(for item: MediaItem) -> [String] {
        var ordered: [String] = []
        func add(_ value: String?) {
            guard let value else { return }
            let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty, !ordered.contains(trimmed) else { return }
            ordered.append(trimmed)
        }

        add(item.id)
        if let colon = item.id.split(separator: ":").first { add(String(colon)) }
        if item.id.hasPrefix("tt") == false, let range = item.id.range(of: "tt[0-9]+", options: .regularExpression) {
            add(String(item.id[range]))
        }
        return ordered
    }

    func playableURLs(from links: [StreamLink], selected: StreamLink? = nil) -> [URL] {
        var urls: [URL] = []
        func add(_ raw: String?) {
            guard let raw, let url = URL(string: raw), raw.lowercased().hasPrefix("http") else { return }
            if !urls.contains(url) { urls.append(url) }
        }
        add(selected?.url)
        for link in links where link.isDirectPlayable { add(link.url) }
        return urls
    }

    func subtitleURLs(from link: StreamLink?) -> [URL] {
        (link?.subtitleURLs ?? []).compactMap { URL(string: $0) }
    }

    func playFirstDirectStream(for item: MediaItem) async {
        let links = await findStreams(for: item)
        if let direct = links.first(where: { $0.isDirectPlayable }), let raw = direct.url, let url = URL(string: raw) {
            startPlayback(item: item, url: url, alternates: playableURLs(from: links, selected: direct), subtitles: subtitleURLs(from: direct), label: "Playing \(direct.quality) link for \(item.title). Adaptive fallback is armed across all direct links.")
        } else if let preview = directPreviewURL(for: item) {
            // v84 real-player test path: when a catalog has no direct movie links yet, PLAY still opens
            // the custom Debrid player with the direct preview/sample URL so the full VOD surface can be tested.
            startPlayback(item: item, url: preview, alternates: [], subtitles: [], label: "No resolved VOD link found, opening direct preview stream in the custom Debrid player for testing.")
        } else {
            let torrentCount = links.filter { $0.url?.lowercased().hasPrefix("magnet:") == true || $0.infoHash != nil }.count
            status = links.isEmpty ? lastStreamMessage : "Links found, but none are direct-playable yet. \(torrentCount) torrent/infoHash link(s) need a torrent/debrid engine; tvOS AVFoundation cannot open magnet streams directly."
        }
    }

    func startPlayback(item: MediaItem, url: URL, alternates: [URL] = [], subtitles: [URL] = [], label: String) {
        playbackItem = item
        let ordered = ([url] + alternates).reduce(into: [URL]()) { acc, candidate in
            if !acc.contains(candidate) { acc.append(candidate) }
        }
        playbackFallbackURLs = ordered
        playbackSubtitleURLs = subtitles
        playbackLinkLabel = label
        playbackURL = url
        status = label
    }

    func advanceToNextPlaybackURL(after failedURL: URL) -> URL? {
        guard let index = playbackFallbackURLs.firstIndex(of: failedURL) else { return nil }
        let nextIndex = playbackFallbackURLs.index(after: index)
        guard playbackFallbackURLs.indices.contains(nextIndex) else { return nil }
        let next = playbackFallbackURLs[nextIndex]
        playbackURL = next
        status = "Current stream failed; retrying alternate \(nextIndex + 1) of \(playbackFallbackURLs.count)."
        return next
    }

    func closePlayer() {
        playbackURL = nil
        playbackItem = nil
        playbackFallbackURLs = []
        playbackSubtitleURLs = []
        playbackLinkLabel = ""
    }

    func openDetail(_ item: MediaItem, pushCurrent: Bool = false) {
        if pushCurrent, let current = selectedDetail {
            detailBackStack.append(current)
        } else if !pushCurrent {
            detailBackStack.removeAll()
        }
        selectedDetail = item
    }

    func closeDetail() {
        if let previous = detailBackStack.popLast() {
            selectedDetail = previous
        } else {
            selectedDetail = nil
        }
    }
    func addManifestURL(_ urlString: String) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty, URL(string: clean) != nil else {
            status = "Enter a valid Stremio manifest URL before adding."
            return
        }
        let candidateSet = Set(manifestURLCandidates(from: clean))
        let alreadyExists = manifestURLs.contains { existing in
            existing == clean || !Set(manifestURLCandidates(from: existing)).isDisjoint(with: candidateSet)
        }
        guard !alreadyExists else {
            status = "That Stremio JSON/addon is already in your list."
            return
        }
        if !manifestURLs.contains(where: { $0.lowercased().contains("v3-cinemeta.strem.io") }) {
            manifestURLs.insert(coreMetadataManifestURL, at: 0)
        }
        manifestURLs.append(clean)
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Added Stremio addon. Configure/stremio:// links will be normalized automatically. Stream-only addons stay active for links even when they do not add Home rows."
    }

    func removeManifestURL(_ urlString: String) {
        manifestURLs.removeAll { $0 == urlString }
        if manifestURLs.isEmpty { manifestURLs = [coreMetadataManifestURL] }
        UserDefaults.standard.set(manifestURLs, forKey: manifestsKey)
        status = "Removed Stremio JSON/addon."
    }

    func loadAllManifests() async {
        let urls = manifestURLs
        guard !urls.isEmpty else {
            status = "Add at least one Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }

        var mergedRows: [MediaRow] = []
        var loadedNames: [String] = []
        var streamOnlyNames: [String] = []
        var skipped: [String] = []
        for url in urls {
            do {
                let result = try await fetchRows(from: url)
                if result.rows.isEmpty {
                    streamOnlyNames.append(result.name)
                } else {
                    mergedRows.append(contentsOf: result.rows)
                }
                loadedNames.append(result.name)
            } catch {
                skipped.append(error.localizedDescription)
            }
        }
        if mergedRows.isEmpty {
            status = streamOnlyNames.isEmpty
                ? "No catalog rows returned from saved Stremio JSON list. Demo rows kept. Skipped: \(skipped.prefix(2).joined(separator: ", "))"
                : "Loaded stream-only addon(s): \(streamOnlyNames.joined(separator: ", ")). No catalog rows were provided, so demo/Home rows were kept. Add/keep Cinemeta for browsable rows."
        } else {
            rows = mergedRows
            let streamNote = streamOnlyNames.isEmpty ? "" : " Stream-only active: \(streamOnlyNames.joined(separator: ", "))."
            status = "Loaded \(mergedRows.count) rows from \(loadedNames.joined(separator: ", ")).\(streamNote)"
        }
    }

    private func fetchRows(from urlString: String) async throws -> (name: String, rows: [MediaRow]) {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidates = manifestURLCandidates(from: clean)
        var manifestURL: URL? = nil
        var manifestData: Data? = nil
        for candidate in candidates {
            guard let url = URL(string: candidate) else { continue }
            do {
                let (data, response) = try await URLSession.shared.data(from: url)
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { continue }
                manifestURL = url
                manifestData = data
                break
            } catch {
                continue
            }
        }
        guard let manifestURL, let manifestData else { throw URLError(.badURL) }
        let manifest = try JSONDecoder().decode(StremioManifest.self, from: manifestData)
        let base = URL(string: normalizedStremioBase(from: manifestURL.absoluteString)) ?? manifestURL.deletingLastPathComponent()
        let catalogs = (manifest.catalogs ?? []).prefix(12)
        var builtRows: [MediaRow] = []
        if catalogs.isEmpty {
            // Stream-only addons such as Torrentio/TorBox are valid and should remain saved/active even though
            // they do not create Home rows. Their /stream endpoints are used from Find Links on Cinemeta items.
            return (manifest.name ?? manifestURL.host ?? "stream addon", [])
        }
        for catalog in catalogs {
            let type = catalog.type ?? "movie"
            let id = catalog.id ?? "popular"
            let catalogURL = base.appending(path: "catalog").appending(path: type).appending(path: id + ".json")
            do {
                let (catalogData, _) = try await URLSession.shared.data(from: catalogURL)
                let response = try JSONDecoder().decode(CatalogResponse.self, from: catalogData)
                let items = (response.metas ?? []).prefix(24).map { meta in
                    MediaItem(
                        id: meta.id ?? UUID().uuidString,
                        title: meta.name ?? "Untitled",
                        year: Self.firstYear(from: meta.releaseInfo),
                        type: meta.type ?? type,
                        catalog: catalog.name ?? id.capitalized,
                        description: meta.description ?? "No description available yet.",
                        genres: Array((meta.genres ?? [type.capitalized, "Cinema"]).prefix(3)),
                        rating: meta.imdbRating ?? "—",
                        posterURL: Self.highest(meta.poster),
                        landscapeURL: Self.highest(meta.background ?? meta.poster),
                        logoURL: Self.highest(meta.logo),
                        previewURL: Self.previewURL(from: meta)
                    )
                }
                if !items.isEmpty {
                    builtRows.append(MediaRow(id: "\(type)-\(id)-\(manifest.name ?? "manifest")", title: catalog.name ?? id.capitalized, items: items))
                }
            } catch {
                continue
            }
        }
        return (manifest.name ?? "manifest", builtRows)
    }


    func loadManifest(urlString: String) async {
        let clean = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else {
            status = "Enter a valid Stremio manifest URL."
            return
        }
        isLoading = true
        defer { isLoading = false }
        do {
            let result = try await fetchRows(from: clean)
            if result.rows.isEmpty {
                status = "No catalog rows returned. Demo rows kept."
            } else {
                rows = result.rows
                status = "Loaded \(result.rows.count) rows from \(result.name)."
            }
        } catch {
            status = "Catalog load failed: \(error.localizedDescription)"
        }
    }

    static func firstYear(from releaseInfo: String?) -> String {
        guard let text = releaseInfo, text.count >= 4 else { return "2026" }
        return String(text.prefix(4))
    }

    static func previewURL(from meta: StremioMeta) -> String? {
        if let direct = meta.previewVideo, direct.hasPrefix("http") { return direct }
        if let direct = meta.preview, direct.hasPrefix("http") { return direct }
        if let direct = meta.trailer, direct.hasPrefix("http") { return direct }
        if let video = meta.videos?.first(where: { ($0.url ?? $0.src ?? $0.source ?? "").hasPrefix("http") }) {
            return video.url ?? video.src ?? video.source
        }
        // Some Stremio manifests expose YouTube trailer IDs; those are kept as metadata only
        // because AVPlayer needs a direct playable video URL.
        return nil
    }

    static func highest(_ url: String?) -> String? {
        guard var u = url, !u.isEmpty else { return nil }
        u = u.replacingOccurrences(of: "w92", with: "original")
        u = u.replacingOccurrences(of: "w154", with: "original")
        u = u.replacingOccurrences(of: "w185", with: "original")
        u = u.replacingOccurrences(of: "w342", with: "original")
        u = u.replacingOccurrences(of: "w500", with: "original")
        u = u.replacingOccurrences(of: "w780", with: "original")
        return u
    }

    static func demoRows() -> [MediaRow] {
        let items: [MediaItem] = [
            MediaItem(id: "normal", title: "NORMAL", year: "2026", type: "movie", catalog: "Featured", description: "A temporary small-town sheriff uncovers a violent mystery after a bank robbery exposes a deeper conspiracy.", genres: ["Action", "Crime", "Thriller"], rating: "6.9", posterURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
            MediaItem(id: "apex", title: "APEX", year: "2026", type: "movie", catalog: "Featured", description: "A climber enters a hidden cave system and finds the rescue mission was never about saving him.", genres: ["Adventure", "Thriller"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=2200&q=95", logoURL: nil, previewURL: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
            MediaItem(id: "red", title: "RED SIGNAL", year: "2026", type: "movie", catalog: "Featured", description: "A clue hidden in plain sight sends two investigators through a dangerous city conspiracy.", genres: ["Mystery", "Drama"], rating: "7.1", posterURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "blue", title: "BLUE FALL", year: "2026", type: "movie", catalog: "Featured", description: "A detective wakes in a fractured digital city with one night to solve his own case.", genres: ["Sci-Fi", "Crime"], rating: "6.8", posterURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "circle", title: "THE CIRCLE", year: "2026", type: "movie", catalog: "Featured", description: "Five strangers are invited to a private meeting that changes the balance of power overnight.", genres: ["Crime", "Drama"], rating: "7.0", posterURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1529333166437-7750a6dd5a70?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "cinema", title: "CENTRAL CINEMA", year: "2026", type: "movie", catalog: "Featured", description: "An old theater becomes the center of a mystery when the screen starts showing tomorrow.", genres: ["Mystery", "Fantasy"], rating: "6.5", posterURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "forest", title: "THE LOST PATH", year: "2026", type: "movie", catalog: "Featured", description: "A missing trail leads a rescue team to a valley that should not exist.", genres: ["Adventure", "Drama"], rating: "7.2", posterURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "storm", title: "STORMLINE", year: "2026", type: "movie", catalog: "Featured", description: "A storm chaser discovers the storm is following people, not weather patterns.", genres: ["Thriller", "Sci-Fi"], rating: "6.7", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "night", title: "NIGHT RUN", year: "2026", type: "movie", catalog: "Featured", description: "A driver with no name carries the wrong package across the city before sunrise.", genres: ["Action", "Neo-Noir"], rating: "7.4", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=2200&q=95", logoURL: nil),
            MediaItem(id: "harbor", title: "HARBOR BLACK", year: "2026", type: "series", catalog: "Featured", description: "A dockside murder opens a case that reaches every powerful family in the city.", genres: ["Series", "Crime"], rating: "7.6", posterURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=95", landscapeURL: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=2200&q=95", logoURL: nil)
        ]
        return [
            MediaRow(id: "featured", title: "Featured Cinema", items: items),
            MediaRow(id: "continue", title: "Continue Watching", items: Array(items.reversed())),
            MediaRow(id: "shows", title: "Shows", items: items.map { item in var copy = item; copy.type = "series"; return copy })
        ]
    }
}
