# Debrid Channels tvOS v31

Ready-to-upload GitHub repo package. GitHub Actions builds tvOS IPA artifacts from the embedded source ZIP.

After the action finishes, download and extract the artifact ZIP. Try the ad-hoc Signulous IPA first.
