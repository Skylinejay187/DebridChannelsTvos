# Debrid Channels tvOS v25

Ready-to-upload GitHub package. The workflow extracts the embedded source ZIP, generates the Xcode project with XcodeGen, builds unsigned tvOS app, and uploads an IPA artifact.

v25 fixes:
- Removed tvOS-unavailable GroupBox usage.
- Preserved RemoteImageFit helper.
- Card artwork fits inside cards.
- Unfocused cards dim.
- Focused cards blue glow and auto-scroll.
- Settings panels are tvOS-safe and reachable.
- Stremio/Cinemeta catalog row loading remains wired.
