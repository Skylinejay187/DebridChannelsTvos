Debrid Channels tvOS v469 — Popup Cast Face Cards + Full More Like This Row

Focused popup-only update:
- Replaced text-only cast line in the movie/show popup with horizontal actor face cards.
- Cast cards show actor headshot when TMDB credits images are available, actor name, and optional role.
- If no headshot metadata is available, cast cards fall back to clean initials instead of breaking layout.
- Kept director/cast text fallback when providers only return text credits.
- Expanded More Like This to fill the popup width with more smaller poster cards.
- Kept More Like This title hidden and poster text overlays removed.

Preserved:
- Search card rebuild/no native platter
- Catalog priority ordering/final sort
- Unlimited catalog rows/items
- Playback, onboarding, membership, devices, Live TV, guide, favorites, Cloudflare, backend
