# v210 MEDIA INFO POPUP

Replaces separate media information navigation with a modal popup overlay. Keeps the current screen behind it, preserves top menu stability, restores exact row/card context on close, and keeps trailer as a second popup layer path.
