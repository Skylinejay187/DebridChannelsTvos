# Debrid Channels tvOS v472

Focused visual/layout polish pass.

## Changed
- Movie/show information popup glass is more transparent.
- Popup keeps localized contrast/gradient behind text while allowing more background visibility.
- Cast face cards are slightly smaller for spacing.
- More Like This/related posters remain clean and fill farther across the popup.
- Movies/TV Shows catalog overlay uses more horizontal width, especially on the left side, so rails feel fuller.
- About Debrid Channels now clearly states that the app does not host, store, upload, redistribute, or provide content; content comes from user-configured sources/services.
- About page remains credited as Created by Issac.

## Preserved
Playback, Search, link resolver, catalog priority, onboarding, membership, devices, Live TV, guide, favorites, Cloudflare/backend integration.
