Debrid Channels tvOS v502 — VOD Overlay Wide Chip Safe-Area Pass

Base: v501_REAL_SETTINGS_TWO_COLUMN_RESTORE_READY_UPLOAD

Changes:
- Expanded the VOD player overlay horizontally so controls can use more of the TV width.
- Raised the control rail away from the bottom edge so chips are not cut off.
- Reduced excessive trailing spacer on the chip rail so right-side controls remain visible/reachable.
- Widened progress/runtime/cache rows to match the larger overlay.
- Preserved v501 real settings restore, TMDB/Cinemeta search scope, resume playback cache, and existing playback engine wiring.

Validation:
- Lightweight source sanity check passed.
