# v209 BLACK_GLASS_GUIDE_BUTTONS

Guide, Force Refresh Guide, and Press RIGHT for full guide buttons now use dark translucent black-glass styling with white text.
