Debrid Channels tvOS v532 — Live TV Overlay Cleanup + Sports Hub Foundation

Built from v531/v530 lineage.

Changes:
- Removed the large Live TV playback poster/logo card from the overlay.
- Live TV playback overlay now starts with the compact channel logo only, no boxed title/name treatment.
- Added Smart Program Info foundation inside the Live TV overlay cast/info panel:
  - Program Info for live shows/movies.
  - Live Match placeholder for sports-style EPG titles.
  - Ready for future TMDB/Cinemeta program matching and live sports score provider data.
- Added Sports top-menu section foundation.
- Sports Hub filters detected sports channels from existing M3U/Xtream/Channels DVR catalog rows.
- Added Sports rows/cards foundation for Live Now, Today, Sources, Scores.
- Added user-source/plugin-ready messaging without built-in unauthorized scraping.
- Preserved popup, VOD overlay, search, settings, Home Grid themes, Live TV themes.

Validation:
- swiftc -parse passed over Sources/*.swift.
