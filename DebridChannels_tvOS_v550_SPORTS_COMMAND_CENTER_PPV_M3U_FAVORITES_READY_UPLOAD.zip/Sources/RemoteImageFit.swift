import SwiftUI

struct RemoteImageFit: View {
    enum Mode { case fill, fit }
    let url: String?
    var mode: Mode = .fill

    private var resolvedURL: URL? {
        guard var raw = url?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else { return nil }
        if raw.hasPrefix("//") { raw = "https:" + raw }
        if raw.hasPrefix("http://") {
            // tvOS may refuse non-ATS HTTP artwork depending on provider/app transport settings.
            // Try the secure equivalent first for common image hosts.
            raw = raw.replacingOccurrences(of: "http://", with: "https://")
        }
        if let direct = URL(string: raw), direct.scheme != nil { return direct }
        if let encoded = raw.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: encoded), url.scheme != nil { return url }
        return nil
    }

    var body: some View {
        Group {
            if let resolvedURL {
                AsyncImage(url: resolvedURL) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .interpolation(.high)
                            .antialiased(true)
                            .aspectRatio(contentMode: mode == .fill ? .fill : .fit)
                    case .empty:
                        placeholder(showSpinner: true)
                    case .failure:
                        placeholder(showSpinner: false)
                    @unknown default:
                        placeholder(showSpinner: false)
                    }
                }
            } else {
                placeholder(showSpinner: false)
            }
        }
        .clipped()
    }

    private func placeholder(showSpinner: Bool) -> some View {
        ZStack {
            LinearGradient(colors: [.black, .gray.opacity(0.30)], startPoint: .topLeading, endPoint: .bottomTrailing)
            if showSpinner {
                ProgressView().scaleEffect(1.1)
            } else {
                Image(systemName: "film.stack")
                    .font(.system(size: 52, weight: .bold))
                    .foregroundStyle(.white.opacity(0.30))
            }
        }
    }
}
