import Foundation

/// Persistent tvOS playback resume/history cache.
///
/// v498 scope:
/// - Stable movie keys: TMDB ID, IMDb ID, then catalog/title fallback.
/// - Stable episode keys: ShowID + Season + Episode.
/// - Save progress every 5 seconds from the active VOD player clock.
/// - Ignore tiny resumes under the threshold and clear items watched past 95%.
/// - Keep a compact recent playback list for future Continue Watching/backup UI.
struct PlaybackResumeEntry: Codable, Hashable {
    var key: String
    var title: String
    var type: String
    var catalog: String
    var season: Int?
    var episode: Int?
    var seconds: Double
    var duration: Double
    var updatedAt: Date
    var artworkURL: String?
}

final class PlaybackResumeCacheManager {
    static let shared = PlaybackResumeCacheManager()

    private let entriesKey = "DebridChannels.v498.playbackResume.entries"
    private let recentsKey = "DebridChannels.v498.playbackResume.recents"
    private let minimumResumeSeconds: Double = 8
    private let completionThreshold: Double = 0.95
    private let maxEntries = 180
    private let maxRecents = 60

    private init() {}

    func resumeEntry(for item: MediaItem) -> PlaybackResumeEntry? {
        let key = playbackKey(for: item)
        guard let entry = allEntries()[key] else { return nil }
        guard entry.seconds >= minimumResumeSeconds else { return nil }
        if entry.duration > 0, entry.seconds / entry.duration >= completionThreshold {
            clear(for: item)
            return nil
        }
        return entry
    }

    func saveProgress(item: MediaItem, seconds: Double, duration: Double) {
        guard seconds.isFinite, seconds >= minimumResumeSeconds else { return }
        let normalizedDuration = duration.isFinite && duration > 0 ? duration : 0
        if normalizedDuration > 0, seconds / normalizedDuration >= completionThreshold {
            clear(for: item)
            return
        }

        let key = playbackKey(for: item)
        let entry = PlaybackResumeEntry(
            key: key,
            title: item.title,
            type: item.type,
            catalog: item.catalog,
            season: item.seasonNumber,
            episode: item.episodeNumber,
            seconds: seconds,
            duration: normalizedDuration,
            updatedAt: Date(),
            artworkURL: item.landscapeURL ?? item.posterURL
        )

        var entries = allEntries()
        entries[key] = entry
        if entries.count > maxEntries {
            let keep = entries.values.sorted { $0.updatedAt > $1.updatedAt }.prefix(maxEntries)
            entries = Dictionary(uniqueKeysWithValues: keep.map { ($0.key, $0) })
        }
        write(entries, key: entriesKey)

        var recents = recentEntries().filter { $0.key != key }
        recents.insert(entry, at: 0)
        if recents.count > maxRecents { recents = Array(recents.prefix(maxRecents)) }
        writeArray(recents, key: recentsKey)
    }

    func clear(for item: MediaItem) {
        let key = playbackKey(for: item)
        var entries = allEntries()
        entries.removeValue(forKey: key)
        write(entries, key: entriesKey)
        let recents = recentEntries().filter { $0.key != key }
        writeArray(recents, key: recentsKey)
    }

    func recentEntries() -> [PlaybackResumeEntry] {
        readArray(key: recentsKey).sorted { $0.updatedAt > $1.updatedAt }
    }

    func playbackKey(for item: MediaItem) -> String {
        let season = item.seasonNumber
        let episode = item.episodeNumber
        let lowerType = item.type.lowercased()
        let isEpisode = season != nil || episode != nil || lowerType.contains("episode") || lowerType.contains("series") || lowerType.contains("show")

        if isEpisode {
            let showID = stableShowID(for: item)
            return "episode|\(showID)|s\(season ?? 0)|e\(episode ?? 0)"
        }

        if let tmdb = tmdbID(in: item.id) { return "movie|tmdb|\(tmdb)" }
        if let imdb = imdbID(in: item.id) { return "movie|imdb|\(imdb)" }
        return "movie|fallback|\(safe([item.catalog, item.title, item.year, item.id].joined(separator: "|")))"
    }

    private func stableShowID(for item: MediaItem) -> String {
        if let tmdb = tmdbID(in: item.id) { return "tmdb:\(tmdb)" }
        if let imdb = imdbID(in: item.id) { return "imdb:\(imdb)" }
        var raw = item.id
        if let season = item.seasonNumber, let range = raw.range(of: "season", options: .caseInsensitive) {
            raw = String(raw[..<range.lowerBound])
        }
        return "fallback:\(safe([item.catalog, item.title, item.year, raw].joined(separator: "|")))"
    }

    private func tmdbID(in value: String) -> String? {
        let lower = value.lowercased()
        guard lower.contains("tmdb") else { return nil }
        if let range = value.range(of: #"tmdb[:_/|-]?(?:movie|tv|show|series)?[:_/|-]?(\d+)"#, options: [.regularExpression, .caseInsensitive]) {
            let fragment = String(value[range])
            if let digits = fragment.range(of: #"\d+"#, options: .regularExpression) { return String(fragment[digits]) }
        }
        return nil
    }

    private func imdbID(in value: String) -> String? {
        if let range = value.range(of: #"tt\d{6,}"#, options: [.regularExpression, .caseInsensitive]) {
            return String(value[range]).lowercased()
        }
        return nil
    }

    private func safe(_ value: String) -> String {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? String(abs(trimmed.hashValue))
    }

    private func allEntries() -> [String: PlaybackResumeEntry] {
        readDictionary(key: entriesKey)
    }

    private func readDictionary(key: String) -> [String: PlaybackResumeEntry] {
        guard let data = UserDefaults.standard.data(forKey: key), let decoded = try? JSONDecoder().decode([String: PlaybackResumeEntry].self, from: data) else { return [:] }
        return decoded
    }

    private func readArray(key: String) -> [PlaybackResumeEntry] {
        guard let data = UserDefaults.standard.data(forKey: key), let decoded = try? JSONDecoder().decode([PlaybackResumeEntry].self, from: data) else { return [] }
        return decoded
    }

    private func write(_ entries: [String: PlaybackResumeEntry], key: String) {
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: key) }
    }

    private func writeArray(_ entries: [PlaybackResumeEntry], key: String) {
        if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: key) }
    }
}
