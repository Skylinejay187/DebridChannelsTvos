import Foundation

/// Step 11 architecture cleanup: centralizes new-episode alert timing,
/// schedule formatting, developer-test alert construction, and report decoration.
///
/// This manager intentionally does not own UI focus or presentation so the existing
/// tvOS banner / popup behavior remains unchanged. RootView still renders the overlay;
/// this type keeps alert policy/state calculations in one place for the wider migration.
enum NewEpisodeAlertsManager {
    static let nextCheckedAtDefaultsKey = "newEpisodeAlertNextCheckedAt"
    static let lastCheckedAtDefaultsKey = "newEpisodeAlertLastCheckedAt"
    static let scanFrequencyDefaultsKey = "newEpisodeAlertScanFrequencyMinutes"

    static func selectedScanFrequencyRawValue() -> String {
        UserDefaults.standard.string(forKey: scanFrequencyDefaultsKey) ?? NewEpisodeAlertScanFrequency.ten.rawValue
    }

    static func selectedScanFrequencySeconds() -> Int {
        let raw = selectedScanFrequencyRawValue()
        let frequency = NewEpisodeAlertScanFrequency(rawValue: raw) ?? .ten
        return Int(episodeAlertIntervalSeconds(for: frequency))
    }

    static func initialHeartbeatDelay(now: Date, storedNext: Date?, intervalSeconds: Int, runImmediateScan: Bool) -> TimeInterval {
        guard !runImmediateScan else { return 0 }
        guard let storedNext else { return TimeInterval(intervalSeconds) }
        let remaining = storedNext.timeIntervalSince(now)
        guard remaining > 0 else { return 0 }
        return min(remaining, TimeInterval(intervalSeconds))
    }

    static func sleepNanoseconds(for seconds: TimeInterval) -> UInt64 {
        UInt64(max(0, seconds) * 1_000_000_000)
    }

    static let scheduleFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter
    }()

    static func decorateScanReport(
        _ report: inout NewEpisodeAlertScanReport,
        periodicScannerEnabled: Bool,
        scanIntervalSeconds: TimeInterval,
        selectedScanFrequency: NewEpisodeAlertScanFrequency,
        selectedScanFrequencyRawValue: String,
        activeHeartbeatIntervalSeconds: Int,
        heartbeatTaskActive: Bool,
        heartbeatGeneration: Int,
        lastHeartbeatFiredAt: Date?,
        nextHeartbeatScanAt: Date?,
        lastScanReason: String,
        duplicateHeartbeatPreventedCount: Int,
        alertStyleDisplayName: String,
        bannerSideDisplayName: String,
        alertThemeDisplayName: String,
        bannerDurationSeconds: Int,
        lastRealScanAt: Date?,
        scanAlreadyRunning: Bool,
        displayedThisCycleCount: Int,
        remainingQueueCount: Int
    ) {
        report.periodicScannerEnabled = periodicScannerEnabled
        report.scanIntervalMinutes = Int(scanIntervalSeconds / 60)
        report.scanFrequencyTestMode = selectedScanFrequency == .oneMinuteTest
        report.selectedScanFrequencyRawValue = selectedScanFrequencyRawValue
        report.selectedScanFrequencySeconds = selectedScanFrequencySeconds()
        report.activeHeartbeatIntervalSeconds = activeHeartbeatIntervalSeconds
        report.heartbeatTaskActive = heartbeatTaskActive
        report.heartbeatGeneration = heartbeatGeneration
        report.lastHeartbeatFiredTime = lastHeartbeatFiredAt.map(scheduleFormatter.string(from:)) ?? "None"
        report.nextScheduledScanTime = nextHeartbeatScanAt.map(scheduleFormatter.string(from:)) ?? "None"
        report.lastScanReason = lastScanReason
        report.duplicateHeartbeatPreventedCount = duplicateHeartbeatPreventedCount
        report.alertStyleSetting = alertStyleDisplayName
        report.bannerSideSetting = bannerSideDisplayName
        report.alertThemeSetting = alertThemeDisplayName
        report.bannerDurationSeconds = bannerDurationSeconds
        report.lastScanTime = lastRealScanAt.map(scheduleFormatter.string(from:)) ?? "None"
        if let lastRealScanAt {
            report.nextScanEstimate = scheduleFormatter.string(from: lastRealScanAt.addingTimeInterval(scanIntervalSeconds))
        } else {
            report.nextScanEstimate = periodicScannerEnabled ? "Pending first scan" : "None"
        }
        report.scanAlreadyRunning = scanAlreadyRunning
        report.displayedThisCycleCount = displayedThisCycleCount
        report.remainingQueueCount = remainingQueueCount
    }

    static func makeDeveloperAlert(now: Date = Date()) -> NewEpisodeAlertHit {
        let show = MediaItem(
            id: "developer-new-episode-alert-show",
            title: "Developer Alert Test",
            year: "2026",
            type: "series",
            catalog: "Follow Center",
            description: "Temporary developer-only test alert generated from Follow Center.",
            genres: ["Debug", "New Episode"],
            rating: "",
            posterURL: "",
            landscapeURL: nil,
            logoURL: nil,
            previewURL: nil
        )
        let episode = MediaItem(
            id: "developer-new-episode-alert-episode-\(Int(now.timeIntervalSince1970))",
            title: "Real Overlay Path Test",
            year: "2026",
            type: "episode",
            catalog: "Follow Center",
            description: "This temporary alert uses the same root overlay state as scanner-detected new episode alerts.",
            genres: ["Debug", "New Episode"],
            rating: "",
            posterURL: "",
            landscapeURL: nil,
            logoURL: nil,
            previewURL: nil,
            seasonNumber: 1,
            episodeNumber: 1,
            airDateString: Self.iso8601DayString(from: now)
        )
        return NewEpisodeAlertHit(
            alertKey: "developerEpisodeAlertTest::\(episode.id)",
            show: show,
            episode: episode
        )
    }
    private static func iso8601DayString(from date: Date) -> String {
        let formatter = ISO8601DateFormatter()
        return String(formatter.string(from: date).prefix(10))
    }
}
