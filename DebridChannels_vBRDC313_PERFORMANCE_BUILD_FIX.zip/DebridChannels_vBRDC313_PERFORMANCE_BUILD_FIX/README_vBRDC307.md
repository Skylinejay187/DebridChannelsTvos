# vBRDC307 — Performance Architecture Pass

Base: vBRDC306 (locked lineage from vBRDC303)
Version: 1.0.1010 (1010)

Implemented:
- Real Apple TV CADisplayLink performance probe with optional Settings > General Performance HUD:
  refresh Hz, measured FPS, hitch count, worst frame time.
- Expanded Canvas catalog row moved 12 pt left from v306 while retaining focus overscan.
- Guide category -> Right focus graph made deterministic: focused category is authoritative,
  destination channel receives focus before category rail collapses, and the mode chip is
  explicitly excluded from the handoff.
- Guide exit is a hard lifecycle boundary: generation invalidation plus cancellation of
  preview warmup/focus-preview/focus-handoff work so rapid enter/exit cannot leave stale work.
- Main catalog hero/backdrop decode ceiling reduced from 3840 to 2048 px (playback browse
  1920 -> 1600) to cut decoded-image memory/bandwidth while remaining above the logical
  1920-wide tvOS UI canvas.
- Existing v306 async task owners, focus-settled metadata prefetch, one-row catalog pager,
  hidden-surface GPU suppression, player teardown, trailer AVPlayerLayer path, and v305
  AttributeGraph crash hardening are preserved rather than duplicated.
- Release identity synchronized to vBRDC307 in app and Top Shelf Info.plists and cache key.

Performance principle:
Focus movement owns the frame. Expensive artwork/metadata/player work must settle, cancel,
or become stale rather than competing with Siri Remote navigation.
