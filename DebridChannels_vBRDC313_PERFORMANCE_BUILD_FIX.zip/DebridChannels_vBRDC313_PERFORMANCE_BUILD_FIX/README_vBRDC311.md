# vBRDC311 — Build Number Synchronization Fix
Version: 1.0.1013 (1013)

GitHub CI reached the app build validation gate and reported:
Info.plist build 1013 does not match Xcode CURRENT_PROJECT_VERSION 1012.

Fix:
- Synchronizes project.yml CURRENT_PROJECT_VERSION to 1013.
- Preserves all v310 Guide focus-math and v309 performance changes.
- No trailer/player behavior changes.
