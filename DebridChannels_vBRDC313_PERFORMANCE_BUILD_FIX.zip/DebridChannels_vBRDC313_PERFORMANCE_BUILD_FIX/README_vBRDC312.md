# vBRDC312 — Comprehensive UI Performance Pass
Version 1.0.1014 (1014)

Based on v311 and driven by real Apple TV evidence:
- tvOS volume/control-center overlays become glitchy when catalog/live previews are active
- disabling those previews reduces the lag
- VOD and Live TV full playback remain much smoother

Preserved:
- v310 Guide Right/collapse focus math
- v309 hidden-catalog dormancy
- approved trailer playback behavior and quality
- VOD/Live TV playback architecture

Changes:
1. Navigation-aware scheduler: background/heavy catalog work yields while focus is moving.
2. Catalog row-revision rebuilds defer until navigation settles rather than rebuilding during movement.
3. Longer focus-settle windows for expensive enrichment/preview work.
4. Generation ownership for catalog/live-preview work so callbacks from abandoned surfaces cannot publish later.
5. Guide exit invalidates old Guide/live-preview generations.
6. Artwork decode concurrency corrected from v311's over-serialized 1 to 2; HTTP fanout moderately restored.
7. Central Unity navigation activity now feeds the scheduler.
8. Existing hidden catalog surface still genuinely goes dormant when not presented.
9. Performance HUD plumbing includes heavy-work lane support for deeper follow-up attribution.

This keeps previews enabled; the goal is to make their background work cooperative rather than remove them.

Validation performed: swiftc frontend parse of all Sources Swift files and version-metadata synchronization.
This is not a full Xcode/tvOS semantic build.
