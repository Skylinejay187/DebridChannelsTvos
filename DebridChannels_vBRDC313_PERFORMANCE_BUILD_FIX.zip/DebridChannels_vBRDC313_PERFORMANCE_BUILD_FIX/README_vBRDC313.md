# vBRDC313 — Performance Pass Build Fix
Version: 1.0.1015 (1015)

GitHub/Xcode semantic build errors fixed:
- UnityAnimationCoordinator.swift: synchronous nonisolated registerNavigationActivity
  directly called @MainActor SignalUIWorkScheduler.
- UnityFrameRuntime.swift: same actor-isolation violation.

Fix:
- Both scheduler notifications now hop explicitly to MainActor.
- All v312 performance architecture, preview scheduling, generation ownership,
  Guide fixes, playback architecture, and trailer behavior are preserved.

Validation here:
- swiftc frontend parse across all Sources Swift files.
- version metadata synchronized.
This is not a full Xcode/tvOS build.
