# Debrid Channels v1013 — Focused Card Inline Preview Fix

Base: `DebridChannels_v1012_V1011_BASE_LIVETV_VIDEO_RENDER_RESTORE_VOD_24_24_16_QUEUE_GITHUB.zip`

Version: `1.0.541`
Build: `541`

## Purpose

Correct Phase 4C preview placement. The optional focused-card preview now plays only inside the currently focused landscape card. It no longer replaces or overlays the full catalog background/backdrop.

## Behavior

- Keeps **Focused Card Previews** off by default.
- Preserves the existing approximately 1.5-second settled-focus delay.
- Preserves the isolated, always-muted `AVPlayer` preview player.
- Preserves the single 20-second playback segment and no-loop behavior.
- Clips the preview to the focused card's exact rounded bounds.
- Keeps the card's title/logo gradient and focus ring above the preview.
- Cancels and dismantles the preview immediately when focus moves.
- Returns to the card artwork after the segment ends.
- Removes the full-screen/background preview presentation path entirely.

## Preserved from v1012

- Live TV render-mount startup fix.
- Static VOD decoded-frame queue: 4K `24`, 1080p `24`, below 1080p `16`.
- Live TV upstream adaptive decoded-frame queue.
- Unified Phase 4B Search.
- Phase 4A row customization.
- Existing trailers, VOD playback, subtitles, audio switching, Live TV guide, favorites, Source Intelligence, and catalog endpoints.

## Changed files

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/Info.plist`
3. `README_BUILD_v1013_V1012_BASE_FOCUSED_CARD_INLINE_PREVIEW_FIX.md`
4. `AUDIT_v1013_CHANGED_FILES.txt`

## Validation

- All Swift sources passed `swiftc -frontend -parse`.
- `Info.plist` and `project.yml` parsed successfully.
- Static checks confirm no `FocusedCardPreviewSurface` remains in the catalog background path.
- Static checks confirm the preview surface is mounted only inside `FixedSlotFocusedCatalogCard`.
- PlaybackKit is byte-for-byte unchanged from v1012.
- Full Apple SDK compilation remains the GitHub Actions validation step.
