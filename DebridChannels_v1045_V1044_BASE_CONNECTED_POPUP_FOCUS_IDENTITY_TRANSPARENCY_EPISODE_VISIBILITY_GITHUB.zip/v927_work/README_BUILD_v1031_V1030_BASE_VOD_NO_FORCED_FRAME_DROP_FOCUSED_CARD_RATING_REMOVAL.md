# Debrid Channels v1031

Base: v1030

## Scope

This build makes two narrow changes before Phase 5.

### 1. VOD fast-scene graphics test

The custom VOD cadence path no longer discards a decoded frame after a persistent late streak.

The previous branch returned `.dropNextFrame` when the queue was healthy but the video clock remained late for three decisions. Overall playback could remain smooth while that single forced discard appeared as a brief visual discontinuity during fast or high-motion scenes.

v1031 preserves the existing lateness thresholds and diagnostics, but always returns `.next`. The diagnostic now reports that the late streak was detected and the drop was suppressed.

Unchanged:

- 4K VOD decoded queue: 24
- 1080p VOD decoded queue: 24
- Below-1080p VOD decoded queue: 16
- Live TV uses upstream queue behavior
- Early hold window and soft late window
- KSPlayer, FFmpeg, VideoToolbox, buffering, first-frame logic, audio, subtitles, trailers, and VOD overlay

### 2. Focused catalog card rating removal

The focused catalog card no longer repeats the item rating beneath its themed logo.

The focused card now shows only the available year and catalog name. Ratings remain in the large themed hero information section.

Focused-card previews continue hiding and restoring the card logo/metadata exactly as before.

## Version

- Marketing version: 1.0.559
- Build: 559
