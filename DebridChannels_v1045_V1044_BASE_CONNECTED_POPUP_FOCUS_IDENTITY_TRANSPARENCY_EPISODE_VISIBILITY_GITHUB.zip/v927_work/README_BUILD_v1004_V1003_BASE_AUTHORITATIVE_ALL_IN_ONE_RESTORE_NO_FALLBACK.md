# Debrid Channels v1004

Base: v1003.

## Changes
- Makes the All-in-One Catalogs toggle authoritative for launch, cache restore, backend restore-code import, Home rows, and universal search.
- When enabled, only the Debrid Channels all-in-one manifest and its device cache may create visible catalog rows.
- TMDB remains metadata/artwork enrichment only and never creates generic rows.
- Cinemeta and personal catalogs remain saved but are not browsed while All-in-One is enabled.
- Restoring a profile cannot remove or demote the local all-in-one manifest while the toggle is enabled.
- Invalidates the prior mixed-row cache.
- Preserves all Phase 2 themed general/provider/genre rows and the v1003 4K 24-frame queue.

No PlaybackKit, subtitle, trailer, Live TV, VOD overlay, or Source Intelligence behavior was changed.
