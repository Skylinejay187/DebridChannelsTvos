# Debrid Channels v1037 — Phase 9 Production Qualification and VOD Metadata Polish

Base: v1036 Phase 8 Release Candidate

Version: 1.0.565
Build: 565

## Scope

Phase 9 freezes the completed catalog, playback, security, and lifecycle work for production qualification. The only user-facing presentation change is a focused polish pass on the existing VOD information block.

## VOD information polish

- Year now appears in a compact themed glass badge with a calendar symbol.
- Numeric rating now appears in a matching themed star badge.
- Badge accent is selected from the movie/show genre family while keeping a dark tvOS-safe background.
- Missing, zero, or unavailable year/rating values hide cleanly.
- The duplicate `Rating` meta chip was removed.
- Type and catalog/season chips remain in their established positions.
- Genre metadata and the synopsis now use built-in cinematic serif system typography with improved spacing and contrast.
- Poster, themed logo, cast wall, status chips, timeline, and control geometry remain unchanged.
- No custom font files were added.

## Production regression audit

The passive production audit was updated for the current release gates:

- Catalog recovery/security
- Canonical catalog identity and metadata
- Cache/memory/lifecycle behavior
- VOD playback and overlay
- Live TV and guide
- Audio/subtitles/trailers/previews
- Unified Search and Source Intelligence
- Settings and focus navigation
- Upgrade and credential security
- Production/rollback packaging

## Preserved

No changes were made to:

- PlaybackKit or KSPlayer
- VOD decoded-frame queue `24 / 24 / 16`
- Live TV upstream decoded queue and first-frame gate
- Fast-scene forced-frame-drop suppression
- VOD seek behavior, scrubber, overlay focus, or cast-wall lifecycle
- Audio or subtitle switching
- Trailer playback
- Focused-card previews and cache
- Phase 5 protected catalog recovery/security
- Phase 6 canonical identity and deduplication
- Phase 7 performance/cache/memory/lifecycle hardening
- Phase 8 backup, restore, migration, redaction, and endpoint security

## Validation performed in this packaging environment

- Parsed all 38 Swift files with the Swift frontend.
- Parsed both app and Top Shelf plists.
- Parsed `project.yml` as YAML.
- Confirmed app/extension/XcodeGen version parity at 1.0.565 (565).
- Passed 38 Phase 9 static regression assertions.
- Confirmed nine critical playback/catalog/security files are byte-for-byte identical to v1036.
- Confirmed the large app-file diff is confined to the existing VOD information stage.
- ZIP compressed-data and extraction round-trip checks are required before delivery.

## Authoritative remaining checks

GitHub Actions remains the authoritative tvOS SDK compile/archive test. Physical Apple TV testing remains required for VOD/HDR playback, Live TV, remote focus, clean install, upgrade, Top Shelf, and App Store signing behavior.
