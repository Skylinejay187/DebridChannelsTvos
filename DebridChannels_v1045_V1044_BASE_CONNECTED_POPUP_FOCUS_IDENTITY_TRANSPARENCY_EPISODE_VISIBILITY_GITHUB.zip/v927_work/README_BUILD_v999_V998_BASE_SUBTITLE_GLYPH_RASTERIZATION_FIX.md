# Debrid Channels v999 — v998 Base, Subtitle Glyph Rasterization Fix

## Scope

This build locks v998 as the base and changes only the PlaybackKit-owned text subtitle renderer. Embedded/external subtitle discovery, selection, timing, bitmap subtitles, playback, cadence, metadata, lifecycle, Live TV, and catalog behavior remain unchanged.

## Screenshot-confirmed issue

The v998 renderer applied a thick negative attributed-string stroke (`NSStrokeWidth = -4`) plus an attributed shadow. On thin/curved glyphs the black stroke intruded into the white fill, producing visible horizontal cuts or doubled inner edges, especially on `e`, `a`, `o`, commas, and apostrophes.

## Fix

- Removes the thick attributed-string stroke entirely.
- Removes inherited ASS/SSA visual decoration before UIKit drawing so source stroke, shadow, underline, and app styling cannot stack.
- Rebuilds the visible cue from its decoded text while preserving line breaks.
- Uses a medium-weight native system font at the existing 58-point tvOS size.
- Uses a small UILabel-layer shadow for contrast without drawing through glyph interiors.
- Pins text drawing to the display scale, disables layer rasterization, and keeps edge antialiasing enabled.
- Keeps the same subtitle position, width, timing, Off behavior, external subtitle parser, and bitmap subtitle renderer.

## Preserved

- v998 real subtitle renderer bridge.
- Embedded and external subtitle selection separation.
- Subtitle-only switching without video seek/restart.
- v997/v996 compile, metadata, loading, and timeline fixes.
- v993 HEVC/HDR decoder trap patch.
- `asynchronousDecompression = false` for main VOD.
- `syncDecodeVideo = false` and `syncDecodeAudio = false`.
- v990 cadence refinements and v992 catalog lifecycle recovery.
- Existing queues, buffers, Source Intelligence limits, fallback count, VOD overlay, Live TV, trailers, and catalog layout.

## Version

- App: 1.0.527 (527)
- Top Shelf extension: 1.0.527 (527)
