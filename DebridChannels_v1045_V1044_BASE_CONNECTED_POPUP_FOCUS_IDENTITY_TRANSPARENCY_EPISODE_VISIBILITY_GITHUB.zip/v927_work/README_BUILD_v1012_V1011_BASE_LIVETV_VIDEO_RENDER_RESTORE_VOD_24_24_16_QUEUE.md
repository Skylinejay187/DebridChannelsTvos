# Debrid Channels v1012 — Live TV Video Render Restore + VOD 24/24/16 Queue

## Base
Built directly from:

`DebridChannels_v1011_V1010_BASE_PHASE4C_FOCUSED_CARD_PREVIEWS_TIME_BASED_QUEUE_GITHUB.zip`

## User-reported problems
- Live TV could play audio while the full-screen video surface remained black.
- The v1011 time-based VOD decoded-frame queue did not feel right during movie playback.

## VOD decoded-frame queue restored
Only the VOD queue override was changed:

- 4K / UHD: 24 frames
- 1080p / FHD: 24 frames
- Below 1080p: 16 frames
- Live TV: unchanged upstream `super.videoFrameMaxCount(...)` behavior

The queue diagnostic continues to print the real queue, FPS, and natural dimensions.

## Live TV video render fix
The KSPlayer Live TV path now:

1. Creates the live KSPlayer layer without constructor autoplay.
2. Mounts the existing KSPlayer render view before the existing explicit play command whenever the view is immediately available.
3. Performs one ready-state mount safeguard when KSPlayer exposes its render view later.
4. Keeps the same player/layer and does not introduce a second decoder, player, seek, reload, or polling loop.

This addresses the audio-only failure mode where decoding/audio can start before the tvOS render view is attached.

## Preserved
- Phase 4A row customization
- Phase 4B unified Search
- Phase 4C focused-card previews
- v999 subtitle renderer and glyph fix
- Audio/subtitle switching
- VOD overlay and clock behavior
- Trailers
- Live TV guide, source loading, quick guide, and focus restoration
- Favorites and Source Intelligence
- Public catalog endpoint and hidden built-in catalog isolation
- All 83 built-in rows and personal catalog behavior

## Version
- CFBundleShortVersionString: 1.0.540
- CFBundleVersion: 540

## Validation
- Changed Swift source passed `swiftc -frontend -parse`.
- All project Swift sources passed syntax parsing.
- `Info.plist` passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- Static assertions confirmed VOD 24/24/16 and upstream Live TV queue behavior.
- Static assertions confirmed Live TV constructor autoplay is disabled while trailer constructor autoplay remains unchanged.
- ZIP integrity and extraction round-trip validation completed.

The authoritative Apple SDK compile remains the GitHub Actions workflow.
