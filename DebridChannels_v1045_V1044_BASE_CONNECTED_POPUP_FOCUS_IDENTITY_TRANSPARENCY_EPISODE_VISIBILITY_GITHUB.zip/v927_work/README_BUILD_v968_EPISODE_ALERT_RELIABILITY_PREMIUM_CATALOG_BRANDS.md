# Debrid Channels v968
## Episode Alert Reliability Engine + Premium Catalog Branding

Base: v967, which preserves the locked v966 golden playback baseline.

## Playback lock
No PlaybackKit, KSPlayer profile, VOD overlay, cast wall, display matching, VOD exclusive-mode, or playback lifecycle source was changed.

## Alert reliability audit findings

1. The scheduler previously kept only a loose next-date value and had no durable scan-health journal.
2. Metadata failures were indistinguishable from a successful scan with no new episodes.
3. Failed scans waited the full selected interval instead of retrying.
4. A queued alert existed only in SwiftUI memory and could disappear on app termination.
5. An alert was marked presented before SwiftUI confirmed the banner/popup appeared.
6. Cancellation during app suspension could be caught as a normal URL error and continue through more providers.
7. Every scan hydrated through broad add-on search before trying the followed snapshot's existing resolver identity.
8. The configured 150-show prefix contradicted the intended scan-all-followed-shows behavior.
9. The VOD-exclusive artwork gate could block alert poster loading during playback.

## Reliability engine changes

- Persisted schedule state: frequency, absolute next deadline, last attempt, last success, outcome, consecutive failures.
- One absolute-deadline heartbeat loop; no duplicate immediate frequency-change scans.
- App resume honors remaining time and catches up only when overdue.
- Failed metadata scans retry after 60, 120, and 300 seconds, then return to the selected interval.
- One-minute test mode completes only after a conclusive scan; failures keep test mode active.
- Pending alert queue persists across relaunches and deduplicates by alert key.
- Alert progress is advanced only from the banner/popup onAppear confirmation path.
- Delivery journal removes a pending alert before marking it presented, preferring a possible repeat over permanent loss.
- Alert metadata path tries the stored followed-show identity first and hydrates only as fallback.
- 12-second per-request timeout added to episode metadata endpoints.
- Cooperative cancellation added through alert metadata and configured-add-on loops.
- Every followed show is scanned; no 150-show prefix.
- Alert-only AsyncImage poster path bypasses non-alert VOD artwork suspension.
- Scanner verification overlay now shows success/partial/failure outcome, snapshots, metadata failures, retry failure count, and persistent queue count.

## Catalog branding

- Rebuilt ProviderBrandMark without changing catalog rail geometry, paging, focus, or DPAD behavior.
- Premium gradient badge + wordmark treatment for TMDB, Cinemeta, major providers, and generic rows.
- TMDB now uses a dedicated cyan/green TM/DB badge and THE MOVIE DATABASE eyebrow.
- Generic rows receive generated monograms and CURATED CATALOG branding instead of the plain SF Symbol + text treatment.
- Configured add-ons use their real addon icon when available.

## Validation

- All active Swift files parsed.
- Alert scheduler/journal/pending-queue Swift harness passed.
- project.yml parsed; all 32 source paths exist.
- PlaybackKit files unchanged from v967/v966 lineage.
- ZIP integrity verified after packaging.
