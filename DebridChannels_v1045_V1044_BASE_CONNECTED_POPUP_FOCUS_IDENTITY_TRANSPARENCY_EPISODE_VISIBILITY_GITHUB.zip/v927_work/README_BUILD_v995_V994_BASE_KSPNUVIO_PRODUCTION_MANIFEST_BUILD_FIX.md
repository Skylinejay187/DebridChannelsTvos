# Debrid Channels v995 — KSPNUVIO Production Manifest Build Fix

Base: v994.

## GitHub build failure fixed

The v994 sparse checkout correctly avoided the macOS Unicode extraction error,
but retained the upstream `KSPlayerTests` target while intentionally omitting the
`Tests` directory. SwiftPM then mis-resolved the local package and failed with:

```
target at Vendor/KSPNUVIO/Sources contains mixed language source files
```

v995 keeps the exact pinned KSPNUVIO revision and decoder safety patch, then
replaces the fetched manifest with a production-only manifest that:

- Explicitly maps `KSPlayer` to `Sources/KSPlayer`.
- Explicitly maps `DisplayCriteria` to `Sources/DisplayCriteria`.
- Preserves the FFmpegKit 6.1.3 dependency.
- Preserves the Metal shader resource.
- Removes the unused test target from the vendored production package.

No playback, cadence, buffer, lifecycle, catalog, Live TV, or resolver settings
were changed from v994/v993.

Version: 1.0.523 (523).
