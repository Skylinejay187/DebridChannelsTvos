# Debrid Channels v1027 — v1020 Base

## Scope

This build is a focused VOD-control repair made directly from v1020 before Phase 5.
It does not include any of the v1021-v1026 Media Information presentation experiments.

## VOD seek feedback

- Back 30 seconds now displays a temporary glass badge on the left side of the video.
- Forward 60 seconds now displays the corresponding badge on the right side.
- The feedback appears for the Back/Forward control chips, hidden-control remote seeks, and timeline Left/Right preview movements.
- The badge is noninteractive and dismisses automatically after approximately one second.
- Live TV is excluded.

## Scrubber focus repair

Root cause: the timeline performed a real player seek for every Left/Right press while tvOS was resolving directional focus. The seek/render state update could cause the focused timeline to be discarded and focus to resolve into the chip rail. The entire bottom chrome was also unnecessarily marked as a focus destination.

New behavior:

1. Focus the blue-dot timeline and press Select to enter scrub mode.
2. Left moves the preview by 30 seconds backward.
3. Right moves the preview by 60 seconds forward.
4. The dot and preview position update without issuing a player seek.
5. Select commits the selected position.
6. Up or Down commits the pending position before leaving the timeline.
7. Timeline focus is reasserted after the preview redraw.
8. The bottom chrome container is no longer focusable; only the actual timeline and control buttons are focus destinations.

## Preserved

- PlaybackKit and KSPlayer are byte-for-byte unchanged from v1020.
- Live TV and its working first-frame/loading gate are unchanged.
- VOD decoded-frame queues remain 24 / 24 / 16.
- FFmpeg, VideoToolbox, cadence, first-frame logic, audio, subtitles, trailers, Search, catalogs, Source Intelligence, previews, and preview caching are unchanged.
- The existing VOD layout and control-chip design are unchanged.

## Version

- Marketing version: 1.0.555
- Build: 555

## Validation

- All Swift sources passed Swift frontend syntax parsing.
- Info.plist passed plutil validation.
- project.yml passed YAML parsing.
- Static assertions confirmed timeline Left/Right is preview-only and the seek feedback is present.
- PlaybackKit matched v1020 byte-for-byte.
- The final archive passed ZIP integrity and extraction round-trip validation.

A full tvOS SDK build must still run through GitHub Actions.
