# Debrid Channels tvOS v1005 — Poster Guarantee Client Filter

Base: v1004.

## Changes

- Invalidates the previous all-in-one row cache namespace.
- Rejects catalog metas that do not contain a concrete poster URL.
- Uses the cached poster as the landscape fallback only when no backdrop is supplied.
- Accepts Phase 2.7 catalog API-proxied artwork URLs at `/assets/...`.
- Preserves all-in-one authoritative restore/toggle behavior and the 83-row catalog design.

## Preserved

- KSPlayer / PlaybackKit, subtitle bridge and glyph rendering.
- 4K and 1080p decoded-frame queue at 24; lower resolutions at 16.
- Cadence, trailers, VOD overlay, Live TV, Source Intelligence and catalog lifecycle recovery.
