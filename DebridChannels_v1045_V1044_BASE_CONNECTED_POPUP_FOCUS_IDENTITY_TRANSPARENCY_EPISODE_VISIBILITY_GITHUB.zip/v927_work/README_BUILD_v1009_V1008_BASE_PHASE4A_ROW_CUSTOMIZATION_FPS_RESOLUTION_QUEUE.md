# Debrid Channels v1009 — Phase 4A

Base: `DebridChannels_v1008_V1007_BASE_PUBLIC_HIDDEN_CATALOG_ENDPOINT_4K25_GITHUB.zip`

## Phase 4A

- Added **Settings → Streaming Catalogs → Customize All-in-One Catalogs**.
- Built-in rows can be turned on/off through a text-only list.
- Built-in rows can be moved up/down without rendering posters in the customization screen.
- **Reset Official Order** restores the row order supplied by the current official manifest.
- **Apply Changes** persists only hidden row IDs and custom row order, closes the customization screen, then refreshes the normal catalog.
- No catalog payload is copied or saved by the customization feature; only lightweight row ID/title descriptors are held for the settings list.
- The built-in manifest remains internal and never appears in Saved JSON URLs.
- Personal catalog URLs remain preserved and become the browsing source when All-in-One Catalogs is disabled.

## Decoded-frame queue replacement

The previous fixed VOD queue was replaced with the requested FPS- and resolution-aware override:

- 4K 50/60 fps: 20
- 4K below 50 fps: 15
- 1080p 50/60 fps: 30
- 1080p below 50 fps: 24
- Below 1080p 50/60 fps: 30
- Below 1080p below 50 fps: 20

Live TV continues to call the upstream `super.videoFrameMaxCount(...)` behavior. The diagnostic prints the actual queue, FPS, and natural dimensions through Swift interpolation.

## Preserved

- v999 subtitle renderer and glyph behavior.
- Existing cadence, clock, first-frame, audio/subtitle switching, buffers, trailers, Live TV, guide, VOD overlay, Favorites, and Source Intelligence behavior.
- Public regular backend and hidden built-in catalog endpoint behavior from v1008.
- All-in-One toggle, automatic catalog refresh, poster guarantee, Cinemeta metadata fallback, text-only catalog headers, Owner Login, and personal catalog URLs.

## Version

- Marketing version: `1.0.537`
- Build: `537`
