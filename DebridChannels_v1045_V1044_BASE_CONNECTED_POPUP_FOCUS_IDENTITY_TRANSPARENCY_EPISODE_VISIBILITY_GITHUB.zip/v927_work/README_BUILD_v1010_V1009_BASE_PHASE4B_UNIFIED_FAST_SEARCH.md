# Debrid Channels tvOS/iOS v1010 — Phase 4B Unified Fast Search

Base: `DebridChannels_v1009_V1008_BASE_PHASE4A_ROW_CUSTOMIZATION_FPS_RESOLUTION_QUEUE_GITHUB.zip`

Version: `1.0.538`
Build: `538`

## Phase 4B scope

- Replaced the Global Search screen's separate progressive add-on and TMDB tasks with one cancellation-owned unified search task.
- Publishes local official catalog matches immediately before the network debounce.
- Uses an exact 250 ms typing debounce and cancels the previous task whenever the query changes.
- Searches one flattened, memory-only built-in index captured before Phase 4A row visibility filtering, so hidden official rows remain searchable.
- Uses one official database/batch request instead of searching all 83 official rows separately.
- Queries Cinemeta movie/show search and configured TMDB search concurrently with the official database request.
- Deduplicates in this order: IMDb identity, external IDs, then exact normalized title + year.
- Preserves local/catalog results as the preferred identity and artwork source; lower-priority metadata providers only fill missing fields.
- Drops every result without a valid poster URL.
- Keeps Cinemeta and TMDB inside one Search Results grid as metadata/search providers; neither is added as a visible catalog row.
- Keeps a memory-only 90-second recent-search cache, capped at 12 queries.
- All-in-One detail hydration now uses the same single official database path instead of a row-by-row scan.
- Personal catalog rows remain locally searchable and active when All-in-One Catalogs is disabled.

## Preserved from v1009

- Exact FPS/resolution-aware decoded-frame queue override and upstream Live TV queue behavior.
- Phase 4A lightweight built-in row visibility/order customization.
- Hidden official catalog endpoint isolation and the existing All-in-One Catalogs toggle.
- v999 subtitle renderer/glyph behavior, playback cadence/first-frame behavior, audio/subtitle switching, VOD overlay, trailers, Live TV/guide, Favorites, Source Intelligence, poster guarantee, automatic row refresh, Cinemeta fallback, Owner Login, and personal catalog URLs.

## Validation performed

- Swift frontend syntax parse for both modified Swift files.
- Static assertions for 250 ms debounce, single-task cancellation, local-first publication, concurrent provider calls, hidden-row indexing, deduplication order, poster filtering, and removal of the old 83-row Search call path.
- Property-list validation and version/build verification.
- YAML parse of `project.yml`.
- Confirmed PlaybackKit/KSPlayer source is byte-identical to v1009.
- ZIP compressed-data integrity and extraction round-trip validation.

A full Apple SDK `xcodebuild` is not available in the Linux packaging environment. GitHub Actions remains the authoritative tvOS/iOS compile/archive test.
