# Debrid Channels v1043 — Connected Media Information Popup + 30-Second Previews

Base: v1042 full-profile backup/restore regression fix  
Version: 1.0.571  
Build: 571

## Purpose

Replace the full-screen catalog Details Stage with a right-side contextual popup that remains visually connected to the exact focused catalog card. The Home/Movies/Shows catalog and existing left-side hero information stay visible, avoiding duplicated title and synopsis content.

## Connected popup behavior

- Captures the exact focused catalog card frame before opening details.
- Draws a curved, glowing line from that card toward the popup.
- Animates the line and popup together using a short fade/spring entrance.
- Keeps the top navigation visible but noninteractive while the popup owns focus.
- Restores the existing card/detail focus behavior when the popup closes.
- Uses runtime identifier `V1043ConnectedMediaInformationPopup` for physical-device verification.

## Popup content

The popup intentionally does not repeat the left-side title/logo/synopsis presentation.

It contains:

- Alternate landscape/background artwork inside the popup.
- Portrait poster.
- Borderless Apple-style production facts with SF Symbols:
  - Year
  - Rating
  - Runtime
  - Budget and revenue for movies
  - Seasons and episodes for shows
  - Studio/network
  - Director and genres
- Play, Trailer, YouTube, and Source Intelligence chips.
- Add Favorite.
- Add Alerts / Alerts On for series.
- Compact cast row.
- Compact season and episode navigation for series.
- Existing Source Intelligence, trailer popup, playback, favorite, alert, and episode actions.

## Focused-card previews

- Preview playback limit increased from 20 seconds to 30 seconds.
- Existing 1.5-second settled-focus delay remains.
- Preview remains muted, no-loop, 720p/2.5 Mbps capped, and isolated from KSPlayer.
- Progressive disk staging now waits 32 seconds so it cannot overlap the active 30-second preview.

## Backup/restore protection

The v1042 full-profile backup/restore implementation is preserved:

- `BackendProfileBackupClient.swift` is byte-for-byte unchanged.
- `ReleaseCandidateSecurityManager.swift` is byte-for-byte unchanged.
- The Settings backup/restore implementation block in `DebridChannelsTVOSApp.swift` is byte-for-byte unchanged.
- Live TV source data, M3U/XMLTV, provider credentials, debrid keys, and metadata API keys remain in the v3 full-profile backup.

## Playback protection

No changes were made to:

- PlaybackKit / KSPlayer
- VOD decoded-frame queue 24 / 24 / 16
- Live TV playback and first-frame gate
- VOD overlay, scrubber, Back 30, Forward 60
- Audio/subtitle switching
- Trailers or Source Intelligence resolver logic
- Catalog identity, row recovery, or cast hydration logic

## Local validation

- All 39 Swift files passed `swiftc -frontend -parse`.
- Backup client and security manager passed standalone Swift type checking.
- Main app and Top Shelf plist validation passed.
- `project.yml` parsed successfully.
- Connected-popup and preview-duration assertions passed.
- Critical playback and backup files match v1042 byte-for-byte.

GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate.
