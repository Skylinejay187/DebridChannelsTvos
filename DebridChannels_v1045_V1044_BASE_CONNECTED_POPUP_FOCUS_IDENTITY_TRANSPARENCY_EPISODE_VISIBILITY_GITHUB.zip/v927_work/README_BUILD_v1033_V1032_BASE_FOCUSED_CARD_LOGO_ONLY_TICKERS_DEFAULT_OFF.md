# Debrid Channels v1033 — Focused Card Logo Only + Release Tickers Default Off

Base: v1032
Version: 1.0.561
Build: 561

## Scope

This correction build keeps the complete v1032 Phase 5 catalog reliability/recovery/security layer and changes only two presentation/default issues reported during Apple TV testing.

## Focused catalog cards

- Removes the catalog row name and year metadata line from inside the focused card.
- The focused card now shows only the selected movie/show themed logo over its artwork.
- The full rating, year, runtime, genres, and other information remain in the large hero information area.
- Focus ring, card dimensions, artwork, preview playback, themed logo hiding during previews, and focus restoration are unchanged.

## Movie/show and sports ticker defaults

- Sports Score Ticker remains Off by default.
- Movies & Shows Release Ticker is now Off by default instead of On.
- Adds a one-time v1033 release-default migration that turns both global tickers Off on existing test installs as well as fresh installs.
- Users can turn either ticker back On manually in Settings after the migration.
- Saved settings backup/restore behavior is unchanged.

## Why the row name appeared

v1031 removed the duplicate rating from the focused card but retained a small metadata line containing `year + item.catalog`. The `item.catalog` value is the catalog row title, which caused labels such as “Trending Movies” to appear inside the selected card. v1033 removes that metadata line entirely.

## Preserved

- v1032 Phase 5 protected catalog snapshots, validation, rollback, retry, preference migration, and endpoint redaction.
- Live TV and guide.
- PlaybackKit and KSPlayer.
- VOD queue 24 / 24 / 16.
- VOD overlay, seek feedback, and scrubber focus.
- Fast-scene forced-frame-drop removal.
- Audio/subtitle switching and subtitle glyph renderer.
- Trailers, focused-card previews/cache, unified Search, Source Intelligence, Favorites, alerts, and personal catalogs.

## Validation performed

- Swift frontend syntax parsing for every app Swift source.
- Info.plist and project.yml parsing.
- Static assertions for logo-only focused cards and both ticker defaults.
- Exact changed-file comparison against v1032.
- ZIP compressed-data integrity and extraction round-trip verification.

GitHub Actions remains the authoritative Apple tvOS SDK compilation test.
