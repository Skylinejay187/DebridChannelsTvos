# Debrid Channels v1006

Base: v1005.

Changes:
- Removes every symbol/icon/badge rendered beside catalog row names. Row headers are text-only.
- Invalidates the previous row-presentation cache so restored symbol metadata cannot reappear.
- Supports Phase 2.8 server metadata/artwork completed through invisible Cinemeta fallback.
- Keeps the all-in-one catalog toggle and authoritative catalog restore behavior.
- Keeps 4K and 1080p decoded-frame queues at 24; lower resolutions remain 16.

Protected systems unchanged:
- PlaybackKit / KSPlayer cadence and decoder path
- Subtitle renderer and glyph fix
- Trailers
- VOD overlay
- Live TV and guide
- Source Intelligence
