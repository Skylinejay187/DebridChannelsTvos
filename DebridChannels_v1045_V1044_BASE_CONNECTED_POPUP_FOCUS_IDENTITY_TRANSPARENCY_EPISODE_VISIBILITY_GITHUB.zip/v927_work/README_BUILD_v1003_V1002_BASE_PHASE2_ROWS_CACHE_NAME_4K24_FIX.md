# Debrid Channels v1003 — Phase 2 Row Publication + Clean Names + 4K 24-Frame Queue

Built from v1002.

- Changes 4K/2160p decoded-frame queue from 16 to 24.
- Keeps 1080p at 24 and lower resolutions at 16.
- Invalidates the stale Phase 1 two-row device cache.
- Removes the legacy `Debrid Channels ` prefix from all-in-one row titles before display.
- Preserves themed row presentation metadata from the server.
- No other PlaybackKit, subtitle, trailer, Live TV, Source Intelligence, or VOD layout changes.
