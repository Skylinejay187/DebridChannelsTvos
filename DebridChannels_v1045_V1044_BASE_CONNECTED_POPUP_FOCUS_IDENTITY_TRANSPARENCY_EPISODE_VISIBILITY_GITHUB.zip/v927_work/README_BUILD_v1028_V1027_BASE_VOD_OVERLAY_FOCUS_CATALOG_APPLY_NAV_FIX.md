# Debrid Channels v1028

Base: v1027 (itself built directly from v1020)

Version: 1.0.556
Build: 556

## Scope

This is a focused regression repair before Phase 5. It changes only the VOD overlay focus-owner behavior and the All-in-One Catalog customization focus routes.

## VOD overlay activation repair

v1027 removed the focusable parent from the complete VOD bottom chrome so the timeline could retain focus during preview scrubbing. That was correct for the visible scrubber, but after auto-hide it left normal VOD playback with no focusable destination. tvOS therefore stopped delivering directional/select commands and the controls could not be reopened.

v1028 adds a transparent focus canvas only while all of the following are true:

- playback is VOD, not Live TV
- the VOD controls are hidden
- no VOD option panel is open

When the controls return, that canvas disappears and the real timeline/buttons own focus. The full bottom chrome remains non-focusable, so the v1027 scrubber focus repair is retained.

## Catalog customization navigation repair

The customization screen now has explicit focus identities for every visibility, Move Up, Move Down, Apply, Reset, and Cancel button.

- Left from the first On/Off button enters the footer action area.
- Down from any control in the final catalog row enters the footer action area.
- After edits, Apply Changes is the destination.
- Before edits, Reset Official Order is used because Apply is disabled.
- Up from the footer returns to the final row.
- Footer Left/Right navigation is deterministic.

## Preserved

- v1027 seek-feedback badges
- preview-only timeline movement and Select-to-commit scrubbing
- PlaybackKit, KSPlayer, Live TV, VOD queue 24/24/16
- FFmpeg, VideoToolbox, cadence, first-frame, audio, subtitle and trailer behavior
- Phase 4 Search, previews, row customization persistence and catalog endpoints
