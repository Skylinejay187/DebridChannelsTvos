# Debrid Channels v1044 — VOD Control Drawer and Bottom-Flush Overlay

Base: v1043 Connected Media Information Popup + 30-second focused previews

Version: 1.0.572
Build: 572

## Purpose

v1044 removes the permanent VOD action-chip rail from the normal playback overlay. Resume, Restart, Play/Pause, Back 30, Forward 60, Audio, Subtitles, Episodes, Player Engine, External Player, and Settings remain available inside a single expandable control drawer.

The collapsed overlay retains only a compact chevron handle below the timeline. Because the 134-point chip shelf is no longer always present, the poster, media information, cast wall, status rail, and scrubber naturally settle lower toward the bottom edge.

## Control behavior

- Hidden by Default is the new default.
- The collapsed chevron opens the control shelf.
- Up from the focused scrubber opens the shelf immediately.
- Down from the focused scrubber moves to the chevron.
- Down or Back while the shelf is expanded collapses it and returns focus to the scrubber.
- The physical Play/Pause button continues to pause or resume playback directly.
- Left/Right scrubber preview and Select-to-commit behavior remain intact.
- Live TV retains its existing control rail and navigation behavior.

## Settings

Settings → VOD Player → VOD Control Shelf now provides:

- Hidden by Default
- Always Visible
- Remember Last State
- Auto-hide after 5 seconds
- Auto-hide after 10 seconds
- Never auto-hide
- Black-Glass Shelf appearance
- Floating Controls appearance

## Backup and restore

The three new preferences are included in the full profile restore-code payload and allowlist:

- vodControlShelfMode
- vodControlShelfAutoHideSeconds
- vodControlShelfLastExpanded

Existing Live TV URLs, M3U/XMLTV data, Xtream credentials, metadata API keys, debrid keys, Source Intelligence settings, catalogs, favorites, and alerts remain part of the v1042+ full profile backup.

## Preserved

- v1043 connected Media Information popup
- 30-second focused-card previews and 32-second disk-stage delay
- V1041 Apple TV VOD information stage
- KSPlayer and PlaybackKit
- VOD decoded-frame queue 24 / 24 / 16
- Live TV first-frame behavior
- Scrubber visuals and seek logic
- Audio and subtitle switching
- Resume and restart implementation
- Trailer playback
- Source Intelligence
- Catalog recovery and cast hydration
- Full-profile backup behavior

## Validation

- 39 Swift source files passed `swiftc -frontend -parse`.
- ReleaseCandidateSecurityManager passed standalone Swift type checking.
- Executable backup-policy test confirmed the three drawer settings survive sanitization while an internal debug key is rejected.
- 39 targeted Phase v1044 source assertions passed.
- Main app and Top Shelf plists passed `plutil -lint`.
- `project.yml` passed YAML parsing and release-version checks.
- GitHub Actions remains the authoritative Apple tvOS SDK compile/archive test.
