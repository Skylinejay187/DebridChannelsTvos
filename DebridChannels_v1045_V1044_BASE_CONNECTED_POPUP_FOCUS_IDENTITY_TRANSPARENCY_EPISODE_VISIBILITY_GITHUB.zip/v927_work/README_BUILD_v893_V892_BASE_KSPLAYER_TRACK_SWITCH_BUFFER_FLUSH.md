# v893 — v892 base — KSPlayer real track switch buffer flush

- Keeps v892 real KSPlayer embedded audio/subtitle discovery and concrete track selection.
- On an explicit user audio/subtitle selection only, re-selects the concrete KSPlayer track and seeks to the exact current playback position to flush already-buffered packets.
- Does not flush during normal SwiftUI refreshes, metadata discovery, or playback-time updates.
- Keeps AVPlayer, MPV, Live TV, grid, guide, VOD layout, focus, and playback routing unchanged.
- KSPlayer subtitle rendering remains enabled through the existing FFPlayer format options (`subtitles=1`, `sn=1`).
