# Debrid Channels tvOS/iOS v1040

## Phase 10 — Catalog rows, cast hydration, and cinematic VOD stabilization

- Base: v1039
- Marketing version: 1.0.568
- Build: 568
- Base ZIP SHA-256: `0ddd9029d18771c30dc28f07cd86215eb47db6a7ac766605da27e2e40f2688a2`

## Official catalog-row reliability

v1040 fixes the state where only part of the All-in-One catalog appeared and repeatedly switching the setting Off/On was needed to recover the remaining rows.

- Re-enabling All-in-One restores the fuller verified protected snapshot immediately while the network refresh verifies it.
- Duplicate refresh callers now coalesce only after the active refresh actually publishes a valid result.
- A failed, canceled, or partial refresh no longer marks itself as successfully completed and suppresses the next retry.
- An interrupted background refresh is remembered and retried when the app becomes active.
- Foreground recovery compares visible official rows with the complete descriptor set after honoring intentionally hidden rows.
- Fresh official data is reconciled with the fuller current/rollback protected snapshot.
- A row still declared by the current manifest is restored from the protected snapshot when the network response omits it.
- A severely truncated row reuses its verified snapshot copy rather than replacing a healthy row with only a few cards.
- Rows no longer declared by the current manifest are not resurrected.
- Canonical identity, poster validation, row customization, hidden-row Search, and protected atomic snapshot promotion remain in force.

## Cast hydration reliability

v1040 fixes cast data that sometimes remained absent until the app was force-closed.

- Description/artwork-only metadata cache entries are no longer treated as complete cast results.
- Cached metadata is merged immediately, but cast providers continue running until cast is available.
- Franchise/collection metadata no longer terminates credit hydration by itself.
- The active VOD overlay performs up to three bounded metadata passes with short backoff while cast is missing.
- Delayed cast publication remains tied to the same active playback URL and media identity.
- No catalog rows or player surfaces are remounted by cast hydration.

## Active VOD information redesign

The v1038 Year and Rating pills were removed completely.

The active non-Live VOD overlay now uses an editorial cinema treatment:

- A genre-colored luminous cue and thin gradient rule establish the title theme.
- `AvenirNextCondensed-Heavy` and `AvenirNextCondensed-DemiBold` provide a compact film-credit hierarchy.
- Year, rating, and episode information are borderless editorial facts separated by fine vertical rules.
- Rating uses a small luminous star without a pill, capsule, card, or rounded background.
- Genres use tracked uppercase typography.
- The synopsis is presented as **THE STORY** using the built-in Baskerville family with a large themed opening quote.
- Poster, themed logo, cast wall, timeline, status row, and playback controls retain their established screen positions.
- No external font files were added.

## Preserved unchanged

- PlaybackKit and KSPlayer implementation
- VOD decoded-frame queue `24 / 24 / 16`
- Fast-scene frame-drop suppression
- Live TV first-frame/loading behavior
- VOD scrubber, Back 30, Forward 60, resume, and pause/play behavior
- Embedded audio and subtitle switching
- Trailer and focused-card preview players
- Source Intelligence resolver/ranking
- Search provider behavior
- Phase 5 security/recovery, Phase 6 identity, Phase 7 lifecycle, and Phase 8 security configuration

## Validation completed

- Parsed all 38 Swift files with `swiftc -frontend -parse`.
- Parsed both app and Top Shelf property lists.
- Parsed `project.yml` as YAML.
- Confirmed app, extension, and XcodeGen version/build parity at `1.0.568 (568)`.
- Passed the targeted static Phase 10 assertions.
- Confirmed the active VOD call site references only `V1040VODCinematicInformationStage`.
- Confirmed the old Year/Rating pill component is absent.
- Confirmed PlaybackKit, Live TV playback surface, preview player, trailer service, and Source Intelligence files are byte-for-byte unchanged from v1039.
- ZIP compressed-data integrity passed.
- Extraction round trip matched all 958 files exactly.

GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate. Physical Apple TV testing remains required for network timing, focus-engine behavior, font rendering, and final VOD visual qualification.
