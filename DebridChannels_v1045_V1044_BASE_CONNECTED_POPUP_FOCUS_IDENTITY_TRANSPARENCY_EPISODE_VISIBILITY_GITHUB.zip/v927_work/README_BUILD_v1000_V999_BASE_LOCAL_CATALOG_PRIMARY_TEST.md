# Debrid Channels v1000 — v999 Base, Local Catalog Primary Test

## Locked base

This build starts directly from v999. The working PlaybackKit/KSPNUVIO playback path, cadence tuning, subtitle engine bridge, subtitle glyph rasterization fix, VOD overlay, trailers, Live TV, Source Intelligence, metadata recovery, and catalog lifecycle recovery are unchanged.

## Local catalog integration

Primary local manifest:

- `http://192.168.100.55:8484/manifest.json`

Local cached artwork remains supplied by the catalog API/MinIO URLs, normally:

- `http://192.168.100.55:9490/debrid-catalog/...`

The local manifest is seeded at the top of the existing Streaming Catalogs list without deleting user-configured JSON addons. Cinemeta is moved to the end as an emergency metadata fallback.

## Runtime priority

1. Live Debrid Channels Catalog server
2. Device-cached Debrid Channels rows
3. Other configured catalog addons
4. TMDB emergency shelves
5. Cinemeta emergency fallback

When the Debrid Channels catalog returns valid rows, normal Home/Movies/Shows loading does not merge Cinemeta or TMDB default shelves into the primary catalog.

## Search

- Universal Search queries the primary catalog first.
- Cached primary search results can be used when the NAS is temporarily unavailable.
- Cinemeta search is held back unless the primary catalog returns no usable result.
- Adds support for catalog servers that implement Stremio search with query parameters:
  - `/catalog/{type}/{id}.json?search=...&skip=0`
- Retains the existing Stremio path-extra search form for other addons.

## Local networking and artwork

- Adds the tvOS local-network usage description.
- Keeps ATS local-network/HTTP support.
- Fixes the premium artwork URL upgrader so RFC1918, localhost, and `.local` HTTP image URLs are not incorrectly changed to HTTPS.
- Public non-local HTTP artwork URLs continue to upgrade to HTTPS.

## Failure handling

- Local manifest request timeout: 3 seconds.
- Local catalog row request timeout: 5 seconds.
- If the NAS is unavailable after a successful prior load, the app keeps the compact device-cached Debrid Channels rows.
- If no device cache exists, the existing TMDB and Cinemeta fallback paths remain available.

## Future Cloudflare switch

The existing Streaming Catalogs settings remain the migration path. Add the future HTTPS manifest, move it above the local URL, and run Load All Catalogs. When the HTTPS Debrid Channels catalog succeeds, the app skips the private LAN test manifest.

## Version

- App: 1.0.528 (528)
- Top Shelf extension: 1.0.528 (528)
