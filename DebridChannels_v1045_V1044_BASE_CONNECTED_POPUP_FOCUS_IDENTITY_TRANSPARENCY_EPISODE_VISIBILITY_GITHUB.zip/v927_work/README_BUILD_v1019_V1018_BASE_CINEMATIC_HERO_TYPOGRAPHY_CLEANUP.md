# Debrid Channels v1019 — Cinematic Hero Typography Cleanup

Base: `DebridChannels_v1018_V1017_BASE_PREVIEW_OVERLAY_HIDE_FULL_HERO_SYNOPSIS_GITHUB.zip`

Version: `1.0.547`
Build: `547`

## Scope

This build changes only the large artwork-theme hero information styling requested from the v1018 screenshot.

### Removed

- Removed the vertical accent line from the left side of the full movie/show synopsis.
- Removed the capsule/pill fill, outline, highlight, and wide internal padding around the year/runtime/type/genre metadata.

### New cinematic typography

- The metadata is now presented as a clean, unboxed studio-credit-style line.
- Metadata uses a cinematic serif system design with wider tracking and restrained dot separators.
- The complete synopsis uses a matching editorial serif design, lighter weight, increased line spacing, and a subtle text shadow for readability over artwork.
- The existing full-description behavior remains intact; no three-line truncation was restored.
- The large themed logo position and metadata contents remain unchanged.

## Playback and feature preservation

No changes were made to:

- Live TV first-frame/loading-screen repair from v1016
- The current loading-screen appearance
- PlaybackKit, KSPlayer, FFmpeg, VideoToolbox, cadence, clock, audio, or subtitles
- VOD decoded-frame queues (24 / 24 / 16)
- Trailer playback or focused-card preview playback
- Focused-card preview logo/rating hide-and-restore behavior
- Preview disk caching or auxiliary-player handoff
- CatalogStore, Phase 4A customization, Phase 4B Search, Favorites, Source Intelligence, or guide behavior
- Hero metadata loading/cache behavior

## Changed files

1. `Sources/DebridChannelsTVOSApp.swift`
2. `Sources/Info.plist`
3. `README_BUILD_v1019_V1018_BASE_CINEMATIC_HERO_TYPOGRAPHY_CLEANUP.md`
4. `AUDIT_v1019_CHANGED_FILES.txt`

## Validation

- All Swift source files passed Swift frontend syntax parsing.
- `Sources/Info.plist` passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- Static assertions confirmed the synopsis accent line and metadata capsule styling are absent.
- Critical playback, resolver, preview, and hero-metadata-cache files remain byte-for-byte identical to v1018.
- The final ZIP passed compressed-data integrity and extraction round-trip comparison.

GitHub Actions remains the authoritative full tvOS/iOS SDK compilation environment.
