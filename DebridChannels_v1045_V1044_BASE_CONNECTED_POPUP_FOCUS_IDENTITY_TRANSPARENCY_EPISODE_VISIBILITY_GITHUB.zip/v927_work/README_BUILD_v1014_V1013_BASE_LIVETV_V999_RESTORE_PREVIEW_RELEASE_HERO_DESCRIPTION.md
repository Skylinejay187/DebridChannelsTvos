# Debrid Channels tvOS/iOS v1014

Base: `DebridChannels_v1013_V1012_BASE_FOCUSED_CARD_INLINE_PREVIEW_FIX_GITHUB.zip`

Version: `1.0.542`
Build: `542`

## Live TV video restoration

Compared the current PlaybackKit Live TV construction path directly against the user-supplied working v999 archive.

Restored the proven v999 behavior exactly for Live TV startup:

- Live TV and trailers use KSPlayer constructor autoplay.
- Full-screen VOD continues to mount first and then receive the existing explicit play command.
- Removed the v1012 late render-view installation experiment.
- Removed the v1012 Live-TV-only coordinator state and ready-state render remount.
- No Live TV decoder, FFmpeg, VideoToolbox, audio, buffer, guide, display-match, or stream-selection settings were changed.

## Focused preview playback release fix

The catalog overlay intentionally stays rendered behind full playback, so `onDisappear` did not reliably dismantle the focused-card preview player. An active muted preview could therefore remain alive while Live TV or VOD opened.

v1014 now releases the isolated preview player when either:

- VOD-exclusive playback resolution begins, or
- `store.playbackURL` becomes non-nil.

After playback closes, the optional preview can schedule normally again. Preview placement remains inside the focused card only.

## Artwork hero description

For Artwork hero background themes only, the focused movie/show description now appears directly beneath the large themed hero logo.

- The focused-card logo is unchanged.
- No metadata chips, provider icons, or extra badges were added.
- Description is limited to three lines.
- Empty and `No description available yet.` values remain hidden.

## Preserved

- VOD decoded-frame queue remains 24 / 24 / 16.
- Live TV decoded-frame queue remains upstream `super` behavior.
- v999 subtitle renderer and glyph fix.
- Phase 4A row customization.
- Phase 4B unified Search.
- Focused-card inline preview timing, mute, 20-second limit, and quality cap.
- Existing trailer behavior.
- VOD overlay, audio/subtitle switching, Favorites, Source Intelligence, guide, public catalog endpoint, personal catalogs, and All-in-One Catalogs.

## Validation

- All Swift source files passed `swiftc -parse`.
- `Info.plist` parsed and reports version 1.0.542 / build 542.
- `project.yml` passed YAML parsing.
- Static assertions confirmed the v999 Live TV constructor sequence.
- Static assertions confirmed preview release hooks and hero-description placement.
- Archive compressed-data integrity and extraction round-trip validation completed.

A full tvOS SDK build remains the GitHub Actions validation step.
