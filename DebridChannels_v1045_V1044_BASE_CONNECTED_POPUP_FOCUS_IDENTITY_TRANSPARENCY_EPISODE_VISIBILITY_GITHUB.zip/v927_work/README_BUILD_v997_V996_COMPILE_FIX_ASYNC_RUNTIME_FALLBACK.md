# Debrid Channels v997

Base: v996

## Compile fix
- Replaced the invalid `await` expression inside the nil-coalescing autoclosure in the VOD runtime metadata lookup.
- TMDB runtime remains the first source.
- OMDb runtime is awaited only when TMDB returns no usable duration.
- No playback, metadata, timeline, catalog, resolver, buffer, Live TV, or presentation behavior was otherwise changed.

Version: 1.0.525 (525)
