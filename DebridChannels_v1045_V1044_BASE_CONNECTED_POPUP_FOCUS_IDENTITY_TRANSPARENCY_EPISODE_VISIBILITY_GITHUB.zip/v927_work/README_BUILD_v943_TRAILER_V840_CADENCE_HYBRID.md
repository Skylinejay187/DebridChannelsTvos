# v943 — Trailer v840 Cadence Hybrid

Base: v942.

Trailer playback now uses the same cadence profile as VOD movies/episodes:
- preferredForwardBufferDuration = 45
- maxBufferDuration = 90
- asynchronousDecompression = true

Retained for trailers and VOD:
- decoder threads = auto
- decoder thread_type = slice
- decoder skip_loop_filter = none
- reorder_queue_size = 1024
- buffer_size = 8 MiB
- analyzeduration = 10000000
- probesize = 15000000

Live TV behavior remains unchanged.
