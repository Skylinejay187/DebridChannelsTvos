# Debrid Channels v1016 — Live TV First-Frame Gate Restore

Base: v1015.
Reference: v987, the last user-confirmed build with working full-screen Live TV video.

Version: `1.0.544`
Build: `544`

## Root cause found by v987 → v999/v1015 comparison

The Live TV decoder was not the primary failure. KSPlayer could open the stream and play audio, but SwiftUI deliberately kept the video surface at opacity zero until `isFirstFrameReady` became true.

v987 released that gate through its startup clock fallback. v996 replaced the synthetic startup clock with a deadline-based first-frame gate, but two later conditions prevented Live TV from ever releasing it:

1. `resetFirstFrameGate()` armed a 1.8-second Live TV deadline, then `setupPlayer()` immediately cleared `vodBootstrapDeadline` before `startPlayerClock()` could use it.
2. The KSPlayer time callback began with `guard !isLivePlayback else { return }`, so every real Live TV clock callback was discarded.

Result: audio played normally while the actual video render surface remained hidden at opacity zero behind the loading screen.

## v1016 repair

- Keeps the current premium loading-screen design and `VODLoadingBackdrop` implementation unchanged.
- Releases the Live TV first-frame gate as soon as the active KSPlayer session publishes its real playback clock callback.
- Preserves the bounded 1.8-second Live TV startup deadline as a fallback when the callback is delayed.
- Removes v1015's extra root-level 400 ms `presentedPlaybackURL` mount delay and restores direct full-screen player mounting from `store.playbackURL`, matching the stable v987 presentation order.
- Keeps synchronous auxiliary preview teardown in `CatalogStore.startPlayback`; no focused preview player is allowed to remain active when full playback begins.

## Preserved unchanged

- Current loading-screen artwork and typography.
- PlaybackKit and KSPlayer implementation.
- VOD decoded-frame queues: 4K 24, 1080p 24, below 1080p 16.
- Live TV upstream `super.videoFrameMaxCount` behavior.
- FFmpeg, VideoToolbox, display matching, cadence, buffers, audio, subtitles, and renderer settings.
- Trailer service and trailer player behavior.
- Phase 4A catalog customization.
- Phase 4B unified Search.
- Phase 4C inline focused-card previews and preview disk cache.
- Hero artwork descriptions, VOD overlay, guide, Favorites, and Source Intelligence.

## Validation

- All Swift source files passed Swift frontend syntax parsing.
- `Info.plist` and `project.yml` parsed successfully.
- Static assertions verified both Live TV gate release paths:
  - real KSPlayer clock callback;
  - bounded 1.8-second deadline fallback.
- `VODLoadingBackdrop` is text-identical to v1015.
- PlaybackKit, TrailerServiceManager, preview cache, and auxiliary coordinator are byte-for-byte unchanged from v1015.
- Archive integrity and extraction round-trip validation are performed before delivery.

GitHub Actions remains the authoritative tvOS SDK compilation and device runtime test.
