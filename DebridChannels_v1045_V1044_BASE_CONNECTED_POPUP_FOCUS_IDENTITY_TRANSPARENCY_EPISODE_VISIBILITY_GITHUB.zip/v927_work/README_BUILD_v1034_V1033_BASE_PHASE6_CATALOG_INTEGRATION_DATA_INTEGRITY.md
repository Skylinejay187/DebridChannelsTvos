# Debrid Channels v1034 — Phase 6 Catalog Integration and Data Integrity

Base: v1033
Version: 1.0.562
Build: 562

## Scope

Phase 6 unifies catalog identity and metadata behavior across Home, Movies, Shows, Search, Favorites/alerts, details, playback metadata, protected snapshots, row refreshes, and focus restoration. Playback and presentation tuning are intentionally unchanged.

## Canonical media identity

Every catalog item now exposes the same ordered identity authority:

1. IMDb ID
2. TMDB/TVDB external ID
3. Exact provider media ID
4. Exact normalized title + release year

Movie and series types remain isolated. Episode identities also include season/episode coordinates, preventing a parent show or neighboring episode from sharing metadata or cache state.

Strong identifier conflicts are authoritative: two items with different IMDb, TMDB, or TVDB IDs are not merged merely because their titles and years match.

## Row normalization and poster guarantee

Before rows are published or protected:

- IDs and external identifiers are normalized and inferred from provider IDs when possible.
- Whitespace is removed from artwork and preview URLs.
- A valid landscape image can safely fill a missing poster slot.
- Items without a valid poster are excluded.
- Duplicate items in one row are merged without replacing the higher-priority item.
- Duplicate row IDs are merged deterministically while preserving first-row presentation priority.

The Phase 5 last-known-good snapshot is now canonicalized before atomic promotion and again before display.

## Unified Search consistency

Local rows, hidden official rows, the official database endpoint, Cinemeta, and TMDB now use the same canonical identity rules. Provider priority remains local official data first. Conflicting external IDs cannot be collapsed through title/year fallback.

Recent merged Search results are invalidated when the catalog identity set refreshes, while the rebuilt local index remains immediately available.

Search-detail hydration now preserves IMDb, TMDB, and TVDB IDs instead of accidentally dropping them while keeping the visible details ID stable.

## Metadata race protection

Detail credit/metadata hydration is tied to the detail-open generation as well as canonical identity. A delayed task for a previously selected title can no longer attach cast, artwork, description, or IDs to the newly focused title.

VOD metadata caching now uses the same canonical media identity instead of a separate concatenated key.

## Exact focus restoration

Catalog-origin details store both the raw item ID and a canonical item snapshot. After catalog refresh, provider fallback, playback, details, or Source Intelligence closes, focus restores to the same movie/show even if its raw provider ID changed.

## Preserved

No changes were made to PlaybackKit, KSPlayer, Live TV, decoded-frame queues, cadence, first-frame behavior, VOD overlay/scrubber, trailers, focused-card preview player/cache, Source Intelligence ranking/resolver, hero metadata presentation, ticker defaults, audio, subtitles, or project configuration.
