# Debrid Channels v993 — v992 Base, FFmpeg Decoded-Frame Cadence + HEVC Trap Patch

Base: v992 (including catalog lifecycle/focus recovery).

## Playback change

- Main VOD `asynchronousDecompression` restored to `false`.
- `syncDecodeVideo` remains `false`.
- `syncDecodeAudio` remains `false`.
- Hardware decoding remains enabled.
- v990 refined motion clock, decoded-frame queues, buffer policy, source fallback cap,
  first-frame release, and display matching are unchanged.

## Root crash repair

The supplied v990 IPS was a deterministic `SIGTRAP` in
`FFmpegDecode.decodeFrame(from:completionHandler:)`. The faulting decoder path contains
trapping Swift unsigned-integer conversions for HEVC/HDR side-data rationals. Valid or
malformed metadata can contain negative or oversized numerators.

v993 uses XcodeGen `preGenCommand` to fetch the exact audited KSPNUVIO revision
`69a73e5e22184c6db254eb2919f81768afb57a81`, verifies the original package and decoder
Git blob IDs, and patches only `FFmpegDecode.swift` before project generation:

- Clamp HDR mastering-display, content-light, and ambient metadata conversions.
- Correct the blue-primary X component lookup.
- Bound unregistered SEI string reads to the side-data payload.
- Clamp closed-caption side-data size conversion.
- Stop dereferencing unused unvalidated Dolby Vision/HDR side-data payloads.

This retains the decoded AVFrame timestamp path preferred for slow-scene cadence while
removing the HEVC metadata trap that forced v991 to asynchronous decompression.

Version: 1.0.521 (521)
