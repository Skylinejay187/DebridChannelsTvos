# Debrid Channels v1036 — Phase 8 Release-Candidate Security, Configuration, and Upgrade Validation

Base: v1035 Phase 7

Version: 1.0.564
Build: 564

## Scope

This phase freezes playback and catalog behavior while hardening release configuration, upgrade migration, diagnostics, profile backup/restore, Top Shelf networking, and build-time version validation.

## Release configuration

- Main app and Top Shelf extension now share version 1.0.564 and build 564.
- XcodeGen declares matching MARKETING_VERSION and CURRENT_PROJECT_VERSION for both targets.
- Release builds enable dead-code stripping, product stripping, and disable testability.
- A build-time validation script fails the GitHub build if app/extension versions diverge, the legacy internal IP reappears in the app plist, or TLS 1.0 exceptions return.
- The Top Shelf extension now uses HTTPS-only catalog and poster URLs and no longer opts out of App Transport Security.
- Redundant per-IP/TLS 1.0 exceptions were removed from the main app plist. Broad media/local-network transport support remains because Debrid Channels accepts user-configured IPTV, DVR, tuner, and local-network sources.
- The local-network privacy description now describes tuners, DVRs, IPTV sources, and media devices rather than internal catalog infrastructure.

## Upgrade migration

- Removes legacy official-catalog endpoints from saved user catalog lists.
- Restores Cinemeta as the visible metadata catalog when needed.
- Migrates the exact legacy private backend address to the public HTTPS backend.
- Preserves personal catalog order and other user preferences.
- Runs before CatalogStore reads persisted manifests.

## Credential and diagnostics security

- Playback and backend diagnostic snapshots redact passwords, usernames, tokens, API keys, debrid identifiers, URL user-info, and hidden official-catalog addresses.
- Backend profile backup schema is upgraded to `DebridChannelsProfileBackup.v2`.
- Provider keys, passwords, private Live TV URLs, local DVR/tuner addresses, and credential-bearing addon manifests remain local to the Apple TV.
- Restore uses an explicit allowlist instead of writing arbitrary server-provided keys into UserDefaults.
- Older v1 backups remain readable, but sensitive values from them are deliberately not restored.
- Backup/restore UI now clearly explains the local-only credential policy.

## Preserved

No changes were made to PlaybackKit, KSPlayer, the 24/24/16 VOD queue, Live TV first-frame behavior, VOD controls, scrubber behavior, trailers, subtitles, audio switching, focused-card previews, Source Intelligence ranking/playback, Phase 5 protected catalog recovery, Phase 6 canonical identity, or Phase 7 lifecycle/cache behavior.

## Validation

- All Swift source files passed frontend syntax parsing.
- ReleaseCandidateSecurityManager passed standalone type checking and executable migration/redaction tests.
- Main and Top Shelf plists passed parsing and version parity checks.
- project.yml passed YAML parsing.
- Static profile-backup assertions confirm credential-bearing fields are absent from the v2 payload.
- Critical playback files are byte-for-byte unchanged from v1035.
- ZIP integrity and extraction round-trip validation are required before delivery.

## Deliberate release behavior

The main tvOS target still permits arbitrary media/network loads because the app supports user-supplied HTTP IPTV, XMLTV, M3U, HDHomeRun, Channels DVR, and local-network endpoints. The Top Shelf extension does not require that exception and is HTTPS-only.

GitHub Actions remains the authoritative tvOS SDK compile, archive, signing, and packaging validation.
