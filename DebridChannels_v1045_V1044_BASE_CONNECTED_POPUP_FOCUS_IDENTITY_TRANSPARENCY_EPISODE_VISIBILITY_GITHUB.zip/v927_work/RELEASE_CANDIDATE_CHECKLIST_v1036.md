# v1036 Release-Candidate Checklist

## Automated checks completed

- [x] Main app version/build set to 1.0.564 (564)
- [x] Top Shelf extension version/build set to 1.0.564 (564)
- [x] XcodeGen target versions match plist versions
- [x] Top Shelf network access restricted to HTTPS
- [x] Legacy TLS 1.0 and explicit private-IP plist exceptions removed
- [x] Local-network privacy description is consumer-facing
- [x] Hidden official catalog removed from saved-manifest migration
- [x] Legacy private backend migrates to public HTTPS backend
- [x] Diagnostic URL/token redaction tests pass
- [x] Backend backup v2 excludes credentials and private source URLs
- [x] Backend restore uses an explicit settings allowlist
- [x] Swift syntax parsing passes
- [x] Plist and YAML parsing passes
- [x] Critical playback files remain unchanged

## Device/GitHub checks required

- [ ] GitHub Actions tvOS Release compile succeeds
- [ ] Generated app and Top Shelf extension versions match in archive
- [ ] Clean install reaches onboarding and loads official catalogs
- [ ] Upgrade from v1035 preserves Favorites, history, alerts, personal catalogs, and row customization
- [ ] Existing v1 backup restores safe preferences and requests credential re-entry
- [ ] New v2 backup restores on a second Apple TV
- [ ] Personal credential-bearing addon URLs remain local and are not restored from backend
- [ ] Top Shelf posters load after install/update
- [ ] Owner Login uses the public backend and remains hidden for regular users
- [ ] Live TV, VOD, trailers, subtitles, audio, Search, previews, and Source Intelligence pass smoke testing

## Known limitations before Phase 9

- App Store Connect validation and signing cannot run in the Linux packaging environment.
- User-configured HTTP/local media sources require broad ATS permission in the main app.
- Credentials and private source URLs intentionally require re-entry on a new device.
- Full clean-install and upgrade verification requires physical Apple TV testing.
