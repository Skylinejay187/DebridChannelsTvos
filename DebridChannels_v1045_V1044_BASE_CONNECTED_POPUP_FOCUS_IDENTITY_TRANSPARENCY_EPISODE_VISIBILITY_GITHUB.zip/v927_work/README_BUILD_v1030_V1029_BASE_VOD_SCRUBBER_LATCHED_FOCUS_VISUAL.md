# Debrid Channels v1030

Base: v1029

## Scope

This build fixes only the VOD scrubber's persistent visual focus confirmation.

The v1029 scrubber remained functionally selected and accepted LEFT/RIGHT commands, but tvOS could briefly clear or reassign the SwiftUI FocusState during directional input. The progress view's enlarged white dot, blue halo, and brighter rail were tied only to that transient focus zone, so the confirmation could flash and disappear while scrubbing still worked.

v1030 treats the scrubber as visually focused whenever the VOD controls are visible and any of these are true:

- the focus zone is the timeline;
- the focused control is the timeline; or
- a timeline scrub session is active.

The focus appearance remains latched until the user commits or exits the scrubber, the controls close, or another panel opens.

## Preserved

- LEFT/RIGHT preview-only timeline movement
- SELECT seek commit
- UP/DOWN commit and leave behavior
- VOD overlay reopening fix
- Back 30 / Forward 60 feedback
- Catalog customization Apply navigation
- PlaybackKit, KSPlayer, Live TV, VOD queue, cadence, trailers, subtitles, audio, Search, previews, and catalog services

## Version

- Marketing version: 1.0.558
- Build: 558
