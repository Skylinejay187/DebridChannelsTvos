# Debrid Channels v1008

Base: v1007.

## Changes

- Replaces the hidden in-home NAS manifest endpoint with the verified public HTTPS endpoint:
  - `https://catalog.skylinejay187.it.com/manifest.json`
- Keeps the official All-in-One catalog out of Saved JSON URLs and all removable catalog UI.
- Keeps the All-in-One Catalogs On/Off toggle as the only user-facing control.
- Filters the old NAS endpoint, temporary `api.skylinejay187.it.com` endpoint, and current public endpoint from restored user catalog lists.
- Invalidates the prior hidden-catalog row cache so the public manifest and public artwork URLs load immediately.

## Preserved

- 4K decoded-frame queue remains 25.
- 1080p remains 24; lower resolutions remain 16.
- Phase 2.9 automatic row refresh and full-row maintenance.
- Cinemeta invisible metadata/artwork fallback.
- Poster guarantee and text-only row headers.
- Playback cadence, subtitle renderer, trailers, Live TV, Source Intelligence, VOD overlay, and catalog lifecycle recovery.
