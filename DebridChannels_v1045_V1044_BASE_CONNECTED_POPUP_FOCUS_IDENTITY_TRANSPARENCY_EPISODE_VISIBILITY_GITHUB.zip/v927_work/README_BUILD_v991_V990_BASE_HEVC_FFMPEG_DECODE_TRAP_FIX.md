# Debrid Channels v991 — v990 Base HEVC FFmpeg Decode Trap Fix

## Base

- Built directly from v990, which is itself based on v987.
- Keeps the v990 motion-phase cadence refinement unchanged.

## Crash evidence

The supplied tvOS IPS (`DebridChannelsTVOS-2026-07-24-042621.ips`) reports:

- `EXC_BREAKPOINT / SIGTRAP`
- Faulting thread: `KSPlayer_vide`
- Top frame: `FFmpegDecode.decodeFrame(from:completionHandler:)`
- Active codec worker: FFmpeg HEVC decoder

This is a deterministic decoder-path trap, not a Jetsam/memory termination and not the v990 presentation clock.

## Fix

Main VOD now uses KSPNUVIO's custom asynchronous VideoToolbox decompression path for supported hardware codecs. This bypasses the unsafe FFmpeg software-frame HDR side-data conversion path that trapped on the reported HEVC link.

## Preserved exactly from v990

- v990 refined non-destructive VOD clock recovery
- syncDecodeVideo = false
- syncDecodeAudio = false
- hardwareDecode = true
- isSecondOpen = false
- decoder threads = auto
- 4K decoded queue = 16
- 1080p decoded queue = 24
- lower-resolution decoded queue = 16
- high-memory VOD buffer = 3 / 30 seconds
- selected source plus three fallbacks
- Source Intelligence 25 / 50 visible results
- automatic first-frame release
- KSPNUVIO pinned revision remains unchanged

## Version

- App / Top Shelf: 1.0.519 (519)
