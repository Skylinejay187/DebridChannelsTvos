# Debrid Channels v967 — Episode Alert Scheduler & Identity Audit

Base: v966 locked golden playback baseline.

## Scope

Notification/Follow Center only. No KSPlayer, PlaybackKit, VOD overlay, cast wall,
frame queue, display matching, Live TV playback, or VOD exclusive-mode changes.

## Root causes fixed

1. Frequency changes used `runImmediateScan: true`, so selecting 5 minutes or
   1 Minute Test Mode scanned immediately instead of waiting.
2. Follow-list changes did not restart the heartbeat from the time the show was
   added or removed.
3. Launch/resume/catalog completion could ignore a valid future scheduled deadline
   and scan early.
4. One-minute mode used a second delayed reset task, producing inconsistent
   one-minute/two-minute behavior and sometimes remaining enabled after a hit.
5. Follow Center saved canonical catalog-independent keys while the scanner looked
   for legacy `id::catalog::type` keys. Newly followed shows could be invisible.
6. Stored duplicate-progress values included the old show-key prefix, so comparing
   legacy and canonical progress strings could suppress or repeat alerts incorrectly.

## v967 behavior

- Selecting 1/5/10/30 minutes starts a fresh countdown from the selection time.
- Adding/removing a followed show starts a fresh countdown using the selected interval.
- A future persisted deadline is honored after app resume or catalog completion.
- An overdue persisted deadline performs an immediate catch-up scan.
- 1 Minute Test Mode runs one scanner pass after 60 seconds, then returns to 10 minutes.
- Existing legacy followed shows and duplicate state migrate during normal scans.
- Old and new Follow Center identities are recognized by both UI and scanner.
- Manual "Test New Episode Alert" remains an immediate presentation-only test.
- "Verify New Episode Scanner" remains available for scanner diagnostics.

## Validation

- All active Swift sources parse with `swiftc -parse`.
- `project.yml` parses and all declared source paths exist.
- PlaybackKit and VOD overlay source files are byte-identical to v966.
- Archive integrity verified with `unzip -t`.
