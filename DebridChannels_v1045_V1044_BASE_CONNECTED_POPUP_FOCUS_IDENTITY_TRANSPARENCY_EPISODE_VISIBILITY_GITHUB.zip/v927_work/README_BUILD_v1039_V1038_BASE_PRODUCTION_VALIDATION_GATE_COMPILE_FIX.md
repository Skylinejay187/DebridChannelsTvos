# Debrid Channels tvOS/iOS v1039

## Production validation gate compile fix

- Base: v1038
- Marketing version: 1.0.567
- Build: 567

## GitHub failure diagnosis

The v1038 Swift compilation did not report an app-source compiler error. Xcode stopped in the pre-build phase named `V1037 Production configuration validation`.

v1038 correctly declared version `1.0.566` and build `566`, but the validation script still required the older v1037 values `1.0.565` and `565`. The shell `test` command returned status 1 without printing a useful explanation, causing `xcodebuild` to exit with code 65.

## Fix

The production validation gate now:

- verifies app and Top Shelf version parity;
- verifies app and Top Shelf build parity;
- compares plist values with Xcode's active `MARKETING_VERSION` and `CURRENT_PROJECT_VERSION` environment values instead of a hardcoded release number;
- prints an explicit error before exiting when a check fails;
- continues checking for the legacy private endpoint and TLS 1.0 exceptions.

This removes the same failure mode from future normal build-number bumps.

## Preserved

The v1038 active VOD metadata-stage correction is retained unchanged. PlaybackKit, KSPlayer, Live TV, the VOD decoded-frame queue, seek/scrubber behavior, subtitles, audio, trailers, previews, catalogs, Search, Source Intelligence, and release security behavior were not modified.

## Validation completed

- Parsed all 38 Swift files with the Swift frontend.
- Parsed both app and Top Shelf property lists.
- Parsed `project.yml` as YAML.
- Confirmed version/build parity at 1.0.567 (567).
- Confirmed the validation script uses Xcode build settings rather than stale hardcoded values.
- Confirmed no legacy private endpoint or TLS 1.0 exception exists in the app plist.
- ZIP compressed-data integrity and extraction round trip passed.

GitHub Actions remains the authoritative Apple tvOS SDK compile/archive test.
