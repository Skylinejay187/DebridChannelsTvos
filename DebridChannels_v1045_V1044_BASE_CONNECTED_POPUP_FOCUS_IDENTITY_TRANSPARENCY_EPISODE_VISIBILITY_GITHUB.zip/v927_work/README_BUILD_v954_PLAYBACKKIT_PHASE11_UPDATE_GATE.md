# v954 PlaybackKit Phase 11 — SwiftUI Update Gate

Built from the corrected v953 Phase 10 archive.

## Change

KSPlayerVideoSurface now records an Equatable snapshot of stable playback inputs. SwiftUI may recreate callback closures or invalidate the representable while the overlay, clock, focus, or metadata changes; those callback references are refreshed, but unchanged playback inputs return before entering `configure(...)`.

Commands that still reach KSPlayer immediately:

- URL or reload replacement
- play/pause transitions
- seek serial changes
- audio/subtitle track serial changes
- mute/content mode/external-audio changes
- display/hardware profile changes

## Safety boundary

No FFmpeg, VideoToolbox, buffer, decoder, first-frame, track-selection, Live TV, or overlay visual settings were changed.
