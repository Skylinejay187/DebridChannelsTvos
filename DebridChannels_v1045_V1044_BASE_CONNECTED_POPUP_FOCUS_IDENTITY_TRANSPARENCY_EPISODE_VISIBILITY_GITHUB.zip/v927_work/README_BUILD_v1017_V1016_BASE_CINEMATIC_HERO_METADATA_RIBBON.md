# Debrid Channels tvOS/iOS v1017

Base: `DebridChannels_v1016_V1015_BASE_LIVETV_FIRST_FRAME_GATE_V987_RESTORE_GITHUB.zip`

Version: `1.0.545`
Build: `545`

## Scope

This build keeps v1016 as the locked playback base and changes only the catalog Artwork/Pure Black hero information presentation.

### Cinematic hero metadata ribbon

The large themed logo remains centered in the hero information region. A single restrained metadata ribbon now appears beneath it with available values in this order:

- release year
- runtime
- media type
- season count for shows
- up to two genres

Rating is intentionally excluded because it already appears on the focused card.

Movies format runtime as `1H 54M`. Shows format episode duration as `45M EPISODES`. The metadata ribbon uses one subtle glass capsule rather than multiple individual chips.

### Synopsis hierarchy

The synopsis remains below the large themed logo and is limited to three lines. It now has a subtle editorial accent rule, stronger spacing, and improved contrast while preserving the existing artwork and card layout.

### Lightweight metadata hydration

Runtime, missing year, TMDB genres, and show season count are loaded only after focus remains settled for approximately 650 ms. The lookup:

- uses the existing user-configured TMDB API key
- resolves by TMDB ID, IMDb ID, then exact title/year fallback
- uses URL cache semantics
- keeps an in-memory six-hour result cache
- coalesces duplicate in-flight requests
- cancels UI application when focus moves
- does not begin during rapid scrolling
- stops when Search, Details, Live TV, VOD, trailer playback, or app backgrounding takes over

Local catalog year/type/genres render immediately, so the hero does not wait for the network.

## Playback preservation

No Live TV first-frame/loading-gate logic was changed. No PlaybackKit, KSPlayer, FFmpeg, VideoToolbox, frame queue, cadence, subtitle, audio, trailer, focused-preview, guide, or resolver setting was changed.

The v1016 Live TV repair remains the active playback behavior.
