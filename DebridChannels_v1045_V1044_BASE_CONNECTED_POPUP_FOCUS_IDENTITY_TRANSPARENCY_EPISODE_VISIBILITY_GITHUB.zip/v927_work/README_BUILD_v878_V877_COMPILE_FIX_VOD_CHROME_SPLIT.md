# DebridChannels v878 — v877 Compile Fix

Base: v877

Fix only:
- Split the oversized VOD bottom chrome SwiftUI expression into smaller computed subviews.
- This fixes the compiler timeout: `the compiler is unable to type-check this expression in reasonable time` at `vodBottomChromeLayer`.

No visual redesign changes were made beyond preserving v877's intended VOD overlay/cast/chip/progress work.
No Live TV grid, Guide, playback engine, catalog, or focus logic changes.
