# Debrid Channels v1032 — Phase 5 Catalog Reliability, Recovery, and Security

Base: v1031
Version: 1.0.560
Build: 560

## Scope

This build is limited to the final-release Phase 5 catalog/public-service reliability layer. Playback, Live TV, KSPlayer, VOD cadence/queues, subtitles, audio, trailers, focused previews, Search behavior, hero presentation, and VOD controls are unchanged.

## Implemented

- Adds a complete, versioned last-known-good snapshot of the official All-in-One catalog in Application Support.
- Stores every official row before local visibility/order preferences are applied, so hidden rows remain available to unified Search during an outage.
- Uses atomic file replacement and keeps the previous verified snapshot as a rollback copy.
- Rejects malformed, duplicate, posterless, unexpectedly small, or severely incomplete official catalog responses before they can replace the working snapshot.
- Prefers the protected snapshot over the compact UserDefaults startup cache.
- Restores the previous protected snapshot automatically if the current snapshot is corrupt or incompatible.
- Adds bounded retry/backoff for the official manifest, batch rows, and standard catalog endpoints.
- Caps catalog response and snapshot sizes to protect against malformed oversized data.
- Validates official manifest identity and restricts advertised Search/Batch endpoints to the trusted official host or legacy local host.
- Migrates saved hidden-row IDs and custom order when row IDs change but official row titles remain the same.
- Appends newly published rows to the saved order without losing existing customization.
- Removes stale/unknown customization IDs during migration.
- Prevents raw hidden official endpoint values from appearing in user-facing failure status or catalog-refresh logs.
- Discards incompatible compact caches instead of allowing decode failures to revive stale data.
- Keeps personal catalogs independent and untouched when All-in-One Catalogs is disabled.

## Recovery behavior

1. Start with the full protected snapshot when available.
2. Refresh the official service in the background.
3. Validate the manifest and complete row payload.
4. Promote the new snapshot atomically only after validation.
5. If the service is unavailable or returns partial/malformed data, retain and display the protected snapshot.
6. If the current snapshot is corrupt, restore the previous verified copy.

## Validation performed

- Swift frontend syntax parsing for every app Swift source.
- Info.plist parsing and version/build verification.
- project.yml YAML parsing.
- Static assertions for snapshot schema, atomic promotion, previous-snapshot rollback, response-size guards, retry/backoff, official endpoint trust checks, row completeness validation, preference migration, and hidden-endpoint redaction.
- Exact changed-file comparison against v1031.
- ZIP compressed-data integrity and extraction round-trip verification.

GitHub Actions remains the authoritative Apple tvOS SDK compilation test.
