# Debrid Channels v1029

Base: v1028
Version: 1.0.557
Build: 557

## Scope

This build changes only the VOD scrubber focus presentation.

When the timeline owns focus, the white scrubber thumb now:

- expands from 18 pt to 30 pt;
- gains a 44 pt blue focus halo;
- gains a white confirmation ring and stronger glow;
- slightly thickens and brightens the progress rail;
- animates into the focused state without changing seek behavior.

When focus leaves, the thumb and progress rail return to their normal compact appearance.

The v1027/v1028 two-step scrubber behavior is unchanged: Left/Right previews the position and Select commits the seek. VOD overlay reopening and Catalog customization focus routing remain unchanged.

No PlaybackKit, KSPlayer, Live TV, VOD decoder, cadence, audio, subtitle, trailer, Search, preview, or catalog service settings were changed.
