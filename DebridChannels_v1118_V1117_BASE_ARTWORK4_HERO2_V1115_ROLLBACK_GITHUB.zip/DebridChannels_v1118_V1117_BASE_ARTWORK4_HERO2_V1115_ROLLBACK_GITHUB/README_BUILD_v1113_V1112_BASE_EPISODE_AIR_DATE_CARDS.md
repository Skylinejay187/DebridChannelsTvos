# Debrid Channels v1113 — Episode Air Date Cards

Base: v1112 only  
Marketing version: 1.0.641  
Build: 641  
Backend: no update required; continue using backend v669

## Changes

- Added the exact episode air/release date directly to every episode card in the season picker.
- Upcoming episodes show `UPCOMING • <date>` with a calendar/clock icon.
- Episodes airing today show `TODAY • <date>`.
- Released episodes show `AIRED • <date>`.
- The focused episode information text now includes the same verified date beside the season and episode number.
- Dates are sourced only from the episode's real `airDateString` / `episodeDateStrings` metadata. Missing dates remain hidden; the app does not substitute the device date or synopsis text.
- The shared episode-card renderer covers both the connected main media-information popup and the manual season/episode picker.

## Preserved

- Production & Ratings panel from v1112.
- Featured Cast presentation modes.
- Catalog/Search source resolution.
- KSPlayer and Tapframe KSPNUVIO.
- Alternate Audio, trailers, Live TV, Catalog Health, Favorites, and episode-alert scanning.

## Validation

- 46 Swift files parsed successfully.
- Episode-date presentation test passed for past, today, future, and missing dates.
- Episode-card source contract passed 12/12 checks.
- App and Top Shelf plists validate at 1.0.641 / 641.
- Project versions match the plists.
- Complete baseline and archive extraction comparisons are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV review remains required.
