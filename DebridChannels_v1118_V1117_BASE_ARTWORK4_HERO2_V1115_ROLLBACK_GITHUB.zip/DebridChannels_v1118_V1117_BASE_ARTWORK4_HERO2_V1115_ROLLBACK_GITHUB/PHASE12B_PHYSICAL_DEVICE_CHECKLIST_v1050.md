# v1050 Phase 12B Physical Apple TV Checklist

## In-place update

1. Keep v1049 installed and configured.
2. Install v1050 over v1049 using the same signing certificate/profile.
3. Confirm the existing app is upgraded rather than duplicated.
4. Confirm Favorites, alerts, catalog customization, personal catalogs, Live TV sources, credentials, popup preferences, and VOD settings remain.

## Built-in catalog

1. Leave All-in-One Catalogs enabled and cold-launch the app.
2. Confirm cached/provisional rows appear before the network refresh completes.
3. Background and foreground the app during loading.
4. Interrupt Wi-Fi, reopen the app, and confirm cached rows remain.
5. Restore Wi-Fi and confirm row count grows/reconciles without toggling All-in-One.
6. Confirm all 83 official descriptors eventually load.
7. Turn All-in-One off and confirm personal catalogs remain available.
8. Turn it back on and confirm the official cache appears immediately.

## VOD

1. Confirm current local time is beneath the poster on the left.
2. Confirm Featured Cast is alone on the right.
3. Confirm Up opens the control drawer without seeking.
4. Confirm Left/Right deliberately scrubs when the timeline is engaged.
5. Confirm audio, subtitles, resume, restart, Back 30, Forward 60, and episode selection.

## Remaining regression

- Connected popup identity/focus
- Popup Artwork and Transparent modes
- Cast hydration without force-close
- Search, Favorites, alerts, Source Intelligence
- Live TV guide and playback
- Backup creation, refresh, restore, and clear
