# v1052 Physical Apple TV In-Place Upgrade Checklist

## Install path

1. Keep v1051 installed and configured.
2. Build/sign v1052 with the same Apple Developer team, certificate, provisioning profile, and bundle identifiers.
3. Install v1052 over v1051 without deleting the app.
4. Confirm tvOS treats the package as an update rather than a separate application.

## Data preservation

Verify these remain after the update:

- All-in-One Catalog toggle, hidden rows, and custom order
- Personal catalogs
- Favorites, followed shows, alerts, and history
- M3U/XMLTV, Xtream, Channels DVR, and HDHomeRun settings
- Source Intelligence settings and API/debrid credentials
- Popup artwork preference and VOD Control Drawer settings
- Backup/restore code configuration
- Catalog protected/provisional caches

## Presentation checks

- Open a movie: the popup shows the large circular Credits row with names and roles.
- Open a series: the compact cast row and three-card episode rail remain unchanged.
- Start VOD: Featured Cast uses the new accent-lit theme and stays alone on the right.
- Confirm the current time is at the end of the left Source/format rail and is not beneath the poster.

## Regression checks

- Built-in catalogs appear and continue recovery in the background.
- Popup artwork stays clipped inside the popup.
- Overlay-hidden Left/Right performs Back 30/Forward 60.
- Collapsed controls keep the scrubber inactive.
- Expanded controls allow deliberate scrub preview/commit.
- Audio, subtitles, trailers, Source Intelligence, Live TV, and guide remain functional.

A signing or bundle-identifier mismatch can prevent an in-place update even when the source configuration is unchanged.
