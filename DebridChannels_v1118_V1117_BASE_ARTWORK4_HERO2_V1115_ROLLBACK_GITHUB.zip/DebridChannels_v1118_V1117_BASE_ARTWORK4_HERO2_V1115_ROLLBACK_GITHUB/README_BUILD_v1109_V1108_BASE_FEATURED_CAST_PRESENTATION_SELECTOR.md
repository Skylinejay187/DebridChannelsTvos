# Debrid Channels v1109 — Featured Cast Presentation Selector

## Source lineage

- Base: `DebridChannels_v1108_V1107_BASE_PRODUCTION_ARTWORK_ROTATION_TITLE_LOGO_GITHUB.zip`
- Marketing version: `1.0.637`
- Build: `637`
- Backend: continue using backend v669; no backend update is required for this pass.

## Scope

This is a focused VOD presentation pass. It replaces the earlier Featured Cast On/Off control with one three-state selector inside the existing VOD Playback Settings panel:

1. **Off** — the original movie/show portrait poster remains untouched.
2. **Compact Overlay** — the original portrait poster remains visible and a restrained lower-poster cast strip shows the active cast portrait, name, role/character, and position.
3. **Full Poster** — preserves the v1108 behavior: the title poster appears for four seconds, then crossfades to a full-poster cast portrait with name and role.

The same player-owned cast index is used by Compact Overlay and Full Poster. Rotation remains exactly seven seconds, pauses while the VOD overlay is hidden, and resumes from the same cast member when the overlay returns.

## Safe migration

The new selector uses `vodFeaturedCastPresentationModeV1`. When that key has not yet been written, v1109 honors the previous `vodFeaturedCastPosterTakeoverEnabled` value:

- Previous On → Full Poster
- Previous Off → Off

Selecting a mode writes the new value. The legacy value is retained only as a downgrade-safe compatibility fallback.

## Protected systems

This pass does not alter Production & Ratings, its seven-second artwork rotation, catalog/Search source resolution, Source Intelligence, KSPlayer, Alternate Audio, trailers, Live TV, Catalog Health, Favorites, episode alerts, or Stable Protection.

## Validation performed

- Swift syntax parsing for all 46 Swift files
- Three-state selector standalone Swift type-check and execution
- 19-source-contract checks
- 10 protected system files compared byte-for-byte with v1108
- App and Top Shelf plist parsing
- XcodeGen project version validation
- Project YAML parsing
- Full baseline file-hash comparison
- Final ZIP extraction and CRC verification

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before promoting v1109 over v1108.
