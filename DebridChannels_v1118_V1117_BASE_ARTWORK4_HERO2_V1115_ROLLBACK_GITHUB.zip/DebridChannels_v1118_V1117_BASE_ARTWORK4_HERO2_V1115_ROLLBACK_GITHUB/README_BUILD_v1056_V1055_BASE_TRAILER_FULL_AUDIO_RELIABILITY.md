# Debrid Channels v1056 — Trailer Full-Audio Reliability

Base: v1055 (1.0.583 / 583)  
Release: v1056 (1.0.584 / 584)

## Confirmed failure paths

Two independent trailer-only paths could make sound stop while the picture continued:

1. `PlaybackKitKSPlayerSurface` kept scheduling trailer startup work after the trailer had
   already started. Routine SwiftUI updates created more delayed `play` / `resume` / `start`
   chains. Those delayed closures also rescanned and reselected the audio track and reapplied
   volume. On an active FFmpeg-backed trailer, that could reopen or detach the audio pipeline
   several seconds into playback.
2. The app accepted and persisted a backend remux URL immediately. A remux-cache URL can become
   visible before its MP4 writer has completely finalized. Opening that growing file lets video
   continue from available packets while the audio track can reach the premature end stored in
   the incomplete file. The previous cache key then allowed the same bad URL to be reused.

The included backend helper also had a format-ranking weakness: a higher-resolution video-only
format could outrank a lower-resolution progressive format containing both video and audio.
It could publish the video URL as `playbackUrl` while reporting `needsRemux=true`.

## v1056 correction

1. Trailer detection is explicit through a `trailer-popup` route identity, so signed or opaque
   remux URLs still receive the trailer-only protection.
2. Startup rescue is tied to the exact KSPlayer layer, exact URL, and a trailer generation.
   Delayed work from a dismissed or replaced trailer cannot touch the current player.
3. Rescue stops permanently as soon as the real trailer clock advances beyond startup.
4. Routine SwiftUI updates no longer create new delayed command chains.
5. The dangerous reflective `start` selector was removed. Only the one-time initial
   `play` / `resume` nudge remains, followed by guarded `play` assertions before clock advance.
6. Automatic English-audio selection is disabled for trailer files because the backend is
   required to supply one already-muxed playback file. Main movies and episodes retain their
   existing audio-track behavior.
7. Resolver requests now explicitly require muxed audio and a complete result.
8. JSON responses marked `needsRemux`, `remuxPending`, or equivalent cannot expose a raw
   video-only URL as playable media. Only a finalized remux-cache URL is accepted.
9. Before a remux-cache file is opened, the app waits for its `Content-Length` to remain stable
   across three successful HEAD probes. Backends without HEAD support still receive a short
   settling window rather than immediate playback.
10. The persistent trailer URL cache was versioned to v1056, discarding prior incomplete URLs.
11. The drop-in backend helper now always prefers a muxed progressive format. When only split
    streams exist, it returns `videoUrl` plus `audioUrl`, leaves `playbackUrl` empty, marks
    `needsRemux=true`, and refuses to cache that unresolved split as playable.

## Preserved

- v1055 catalog completeness watchdog and manual Debrid Channels catalog reload
- v1054 VOD session/render-surface ownership and connector geometry
- v1053 TVMaze-first episode alert reliability
- KSPlayer/KSPNUVIO as the trailer and VOD engine
- trailer popup appearance, controls, cinema animation, and normal mute button
- VOD audio/subtitle selection behavior
- Live TV, Source Intelligence, catalogs, favorites, search, and Top Shelf

## Physical-device checks

1. Open a trailer longer than one minute and allow it to play without touching the remote.
   Confirm audio remains present through the final frame.
2. Repeat with at least three titles so both progressive and backend-remuxed sources are covered.
3. Close one trailer during startup and immediately open another. Confirm the old trailer never
   resumes or interrupts the new trailer's sound.
4. Toggle Mute and Unmute once. Confirm sound resumes and remains through the rest of the trailer.
5. Reopen the same trailer and confirm the new v1056 cache does not reuse a previous broken URL.
6. Confirm movies, episodes, Live TV, and focused-card muted previews retain existing behavior.

## Validation

- all 39 Swift source files pass `swiftc -parse`
- backend helper passes `python3 -m py_compile`
- synthetic format tests prove muxed 720p outranks video-only 1080p and split formats are marked
  for remux without a playable URL
- app and Top Shelf plists parse successfully
- `project.yml` parses as YAML
- app, extension, and project versions match 1.0.584 (584)
- static assertions cover generation-scoped startup, no reflective `start`, no trailer audio
  reselection, complete-remux settling, cache invalidation, and unresolved-split rejection

GitHub Actions remains the authoritative tvOS SDK compile/archive gate. Physical Apple TV playback
is the final confirmation because the repository does not include an Apple tvOS runtime here.
