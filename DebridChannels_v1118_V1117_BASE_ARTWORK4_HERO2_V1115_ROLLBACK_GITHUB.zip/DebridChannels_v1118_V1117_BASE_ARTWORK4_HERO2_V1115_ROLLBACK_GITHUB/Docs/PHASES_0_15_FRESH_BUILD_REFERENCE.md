# Debrid Channels tvOS/iOS — Phases 0–15 Fresh Build Reference

## Starting base and build discipline

- Use verified v1089 only as the Phase 0 base.
- Keep v1084 archived as the older trailer-stable emergency fallback.
- Do not rebuild from an older ZIP or stack unrelated experimental branches.
- Every phase uses the immediately previous successful phase as its base.
- Do not combine multiple risky phases into one build.
- Produce a separate GitHub workflow ZIP and increment marketing/build versions for every phase.
- Run Swift parsing, plist validation, project-version validation, archive extraction, and complete file-hash comparison.
- GitHub Actions is the authoritative Xcode/tvOS compilation test.

## Locked requirements

- Keep KSPlayer on the Tapframe KSPNUVIO fork; never replace KSPlayer.
- Do not add Movie Mode code.
- Do not redesign existing Home, Movies, Shows, Search, Favorites, Live TV, Source Intelligence, or VOD interfaces unless the active phase explicitly requires it.
- Preserve the working trailer resolver, always-running episode alerts, full-width catalog rows, Search-contained results, centered Favorites details without a connector line, v1087 source-switch clock/session fixes, and the v1089 Search-style catalog focus animation.

## Phase sequence

### Phase 0 — Stable baseline protection and focus cleanup

Lock v1089 after testing; add versioned experimental flags defaulting Off, safe migrations, stable UI reset without deleting user/service data, original-playback preservation, and emergency experimental playback rollback. Remove oversized system focus platters from shared onboarding chips. Standard catalog rows must enter at card one during normal vertical navigation while exact popup/playback return restores the launching card. Search, Favorites, and Live TV remain specialized and unchanged.

### Phase 1 — Playback Health panel

Add a hidden low-overhead VOD diagnostic panel showing session/generation identity, provider/file, codecs, resolution, HDR/Dolby Vision, frame rate, hardware decoding, buffering, dropped/delayed frames, A/V clock difference, selected tracks, first-frame state, source-handoff state, Alternate Audio state, and trailer-resolver state without invalidating the full overlay.

### Phase 2 — Alternate Audio discovery

Use backend ffprobe and real stream metadata. Detect language/title/disposition, exclude commentary/descriptive audio by default, scan all enabled Source Intelligence providers, verify exact title/season/episode identity, compare timing/frame rate/edition/chapters/release metadata, use sampled video fingerprints where practical, and classify Exact Match, Offset Match, Drift Correctable, Possible Match, or Incompatible. Do not alter playback.

### Phase 3 — Alternate Audio Bridge

Create a short-lived backend bridge that keeps selected high-quality video, uses compatible English audio, never re-encodes video, prefers audio stream-copy, re-encodes audio only when required, emits one temporary HLS URL, enforces exact movie/episode ownership, and retains the original source for immediate restoration.

### Phase 4 — KSPlayer handoff and synchronization

Connect bridge output to the session-owned KSPlayer handoff while preserving timestamp, play/pause state, and subtitle selection. Reject stale player generations, prevent old sessions from affecting the active one, wire −250 ms/+250 ms/Reset, add Restore Original Audio, persist exact-title/episode selection and offset, and keep seeking/background/exit reliable.

### Phase 5 — Catalog Health section

Add Settings diagnostics for configured providers, expected/loaded rows, poster counts, pagination, refresh timestamps, provider/page failures and timeouts, one-row/all-catalog reload, and cache clearing that preserves accounts, favorites, and progress.

### Phase 6 — Automatic source failover

Before stable first-frame playback only, try the next compatible Source Intelligence ranked link and show a brief notice. Never silently switch after stable playback begins. Cancel/rebuild Alternate Audio as needed and preserve episode identity/resume position.

### Phase 7 — Per-title playback memory

Remember embedded audio language, Alternate Audio candidate/offset, subtitle language/state/delay, provider/source/quality preferences, and resume timestamp. Show-level language suggestions are allowed; external audio/offset and resume remain episode-specific.

### Phase 8 — Up Next episode intelligence

Near episode end, show compact next-episode title/artwork/runtime/air date/cast/advisory, ranked-source and Alternate Audio readiness, Play Next, and countdown cancel. Pre-resolve without disrupting current playback.

### Phase 9 — Bridge lifecycle and resource control

Use unique playback bridge UUIDs, cancel stale work, clean temporary assets, deduplicate jobs, enforce CPU/memory/storage/concurrency limits, recover after backend restarts, prevent abandoned jobs, and safely reuse valid completed work.

### Phase 10 — Security and provider protection

Never expose provider tokens. Use short-lived signed URLs, accept only Debrid Channels-resolved links, block filesystem/localhost/private-network proxy abuse, validate URLs/redirects/sizes/types, enforce rate/session ownership, redact logs, and reject expired/reused credentials.

### Phase 11 — Performance and codec compatibility

Test and optimize the required resolution/HDR/video/audio/container/transport matrix, slow providers, seek latency, segment speed, Apple TV HD, and Apple TV 4K. Video must always remain stream-copied.

### Phase 12 — Diagnostics and recovery

Expand Playback Health with bridge stage/percentage, original and alternate sources, stream index, match class, offset/drift, copy/re-encode state, rejection reason, privacy-safe report, Retry Bridge, Try Another Audio, Restore Original Audio, and failed-handoff history.

### Phase 13 — Staged rollout and release gate

Support Internal Testing, Beta, and Stable. Keep Alternate Audio flagged until proven, migrate/discard obsolete placeholder state, add a kill switch, restore original playback after unrecoverable failures, run the acceptance matrix, and save rollback ZIPs before promotion.

### Phase 14 — Accessibility and UX polish

Add VoiceOver labels, clear focus order, remote-navigation tests, non-color match indicators, match-class explanations, localization-ready strings, readable preparation/failure copy, first-use Alternate Audio explanation, and no oversized Apple focus platters on custom chips.

### Phase 15 — Final integration, regression testing, and production lock

Run the complete user-specified system matrix across normal VOD, source/episode handoffs, clocks, pause/resume/seeking, embedded/alternate audio, subtitles, resume, failover, Up Next, trailers, episode alerts during VOD, Search/Favorites/catalog focus behavior, guide/Live TV, relaunch, backend restart, and rollback. Promote only approved features, remove obsolete placeholder code, keep risky switches, produce the final production ZIP/audit, record the stable rollback version, and do not begin unrelated work until physical Apple TV testing passes.

## Current gate

Phase 0 is v1090 (1.0.618 / 618), built only from v1089. Phase 1 is blocked until v1090 passes GitHub Actions and physical Apple TV testing.
