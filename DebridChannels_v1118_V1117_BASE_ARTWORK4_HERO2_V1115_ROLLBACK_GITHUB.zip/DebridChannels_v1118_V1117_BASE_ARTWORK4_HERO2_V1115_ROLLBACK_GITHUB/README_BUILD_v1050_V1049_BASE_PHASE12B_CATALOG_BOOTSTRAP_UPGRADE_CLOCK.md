# Debrid Channels v1050 — Phase 12B Catalog Bootstrap, Upgrade, and VOD Clock Correction

Base: v1049
Version: 1.0.578
Build: 578

## Blocking catalog issue corrected

The Phase 12A recovery logic still had two startup failure modes:

1. A protected snapshot was decoded successfully and then passed through a second heuristic source-name filter. If the official manifest display name changed from the exact legacy wording, valid cached rows could be discarded before first render.
2. The first-install validator required all 83 rows before it would publish anything. A healthy but temporarily incomplete batch therefore left the UI empty even though dozens of valid rows were ready.

v1050 corrects both conditions.

### Official source identity

- Any Debrid Channels-owned catalog display name is now recognized, not only the exact phrase `Debrid Channels Catalog`.
- A protected official snapshot is trusted by its Application Support location, schema, and source marker and is not re-filtered on launch.
- While the All-in-One toggle is enabled, rows from the single hidden browsing endpoint are treated as authoritative official rows.
- The All-in-One toggle remains fully supported. Turning it off still returns the app to personal catalogs.

### Progressive first-load recovery

- A complete 83-row response remains the only result promoted into the protected current/rollback snapshot.
- A healthy provisional response can be displayed immediately rather than leaving Home empty.
- Provisional rows are persisted in a separate Application Support snapshot.
- The provisional file never replaces or downgrades the complete protected snapshot.
- Background recovery continues with the existing 4/10/20/45/90/180/300-second backoff until all 83 official rows are verified.
- Once the full set arrives, it atomically replaces the provisional file and retains current/previous rollback protection.

## In-place upgrade preservation

The main app and Top Shelf bundle identifiers, app group configuration, entitlements, signing configuration paths, and UserDefaults keys are unchanged from v1049. Installing with the same signing identity/profile is therefore designed to update in place without deleting app data.

Preserved upgrade data includes catalogs, hidden-row order, personal manifests, Favorites, alerts, playback history, Live TV sources, M3U/XMLTV/Xtream settings, Source Intelligence, API/debrid keys, popup preferences, and VOD Control Drawer settings.

Physical Apple TV installation remains the authoritative signing and in-place upgrade proof.

## VOD clock placement

- The current local time was removed from the right end of the playback status rail.
- It is now placed directly beneath the VOD poster on the left side.
- Featured Cast remains isolated on the right with no clock or unrelated status below it.

## Unchanged systems

- KSPlayer / PlaybackKit
- VOD decoded queue 24 / 24 / 16
- Live TV playback and first-frame behavior
- VOD scrubber and control drawer
- Audio/subtitle switching
- Trailers and 30-second focused previews
- Source Intelligence
- Backup/restore policy and full-profile keys
- Connected Media Information popup
- Popup background Artwork/Transparent toggle
- Cast hydration and episode navigation

## Local validation

- 39 Swift files passed `swiftc -frontend -parse`.
- Main and Top Shelf plists passed `plutil -lint`.
- `project.yml` passed YAML parsing.
- Version/build parity passed: 1.0.578 / 578.
- Main and Top Shelf bundle identifiers match v1049.
- Eight critical playback/service/security files match v1049 byte-for-byte.
- Static catalog-source, provisional-cache, retry, toggle, and VOD-clock assertions passed.
- GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate.
