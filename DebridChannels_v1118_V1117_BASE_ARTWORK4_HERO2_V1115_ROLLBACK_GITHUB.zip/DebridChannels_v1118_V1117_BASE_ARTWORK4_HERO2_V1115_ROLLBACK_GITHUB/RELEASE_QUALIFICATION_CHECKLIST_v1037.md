# v1037 Production Qualification Checklist

## Automated packaging checks

- [x] Main app version/build is 1.0.565 (565)
- [x] Top Shelf extension version/build matches
- [x] XcodeGen version/build settings match both plists
- [x] Build-time version guard updated to v1037
- [x] All 38 Swift files pass frontend syntax parsing
- [x] App and extension plists pass validation
- [x] `project.yml` passes YAML parsing
- [x] 38 Phase 9 static regression checks pass
- [x] VOD Year and Rating badges are present
- [x] Duplicate VOD rating chip is removed
- [x] VOD synopsis and genre metadata use system serif typography
- [x] VOD poster/logo/cast/timeline/control anchors are unchanged
- [x] VOD decoded-frame queue remains 24 / 24 / 16
- [x] Live TV continues using the upstream queue
- [x] Forced fast-scene `.dropNextFrame` remains removed
- [x] Phase 5 protected snapshot/recovery remains present
- [x] Phase 6 canonical identity remains present
- [x] Phase 7 bounded preview cache/lifecycle hardening remains present
- [x] Phase 8 backup v2 and restore allowlist remain present
- [x] Critical playback/catalog/security files match v1036 byte-for-byte
- [x] Production ZIP integrity and extraction round trip pass
- [x] Rollback ZIP integrity passes

## GitHub Actions gate

- [ ] tvOS Release compile succeeds
- [ ] Top Shelf extension compiles and embeds
- [ ] Signed archive reports version 1.0.565 (565)
- [ ] IPA/artifact installs on the target Apple TV

## Physical Apple TV smoke test

- [ ] Clean install reaches onboarding and loads official catalogs
- [ ] Upgrade from v1036 preserves Favorites, history, alerts, personal catalogs, and row order
- [ ] Official-catalog outage uses the protected snapshot
- [ ] Hidden rows remain searchable
- [ ] Personal catalogs return when All-in-One is disabled
- [ ] Movie VOD starts and displays the polished Year/Rating/description block
- [ ] Episode VOD starts and displays the correct show/episode metadata
- [ ] 4K, 1080p, and lower-resolution VOD remain smooth
- [ ] Fast scenes do not exhibit the previously forced-frame-drop glitch
- [ ] Resume, Restart, Back 30, Forward 60, and scrubber commit work
- [ ] Scrubber focus visual remains latched and borderless
- [ ] Audio switching works
- [ ] Embedded/external subtitles render correctly
- [ ] Trailer playback remains smooth
- [ ] Focused-card previews remain muted, cached, and isolated
- [ ] Live TV presents video and audio together
- [ ] Live TV guide returns focus to the exact channel
- [ ] Unified Search is local-first, cancellable, poster-filtered, and deduplicated
- [ ] Source Intelligence resolves, ranks, pages, and opens the selected link
- [ ] Catalog customization Apply/Reset/Cancel remain reachable
- [ ] Sports and Movies/Shows tickers are Off by default
- [ ] Top Shelf content loads after clean install and upgrade
- [ ] Background/foreground and memory-pressure behavior remain stable

## Publication gate

- [ ] No unresolved crash
- [ ] No blank-video or audio-only regression
- [ ] No data-loss or upgrade regression
- [ ] No focus trap or unreachable control
- [ ] No exposed hidden catalog endpoint or credential-bearing diagnostic
- [ ] App Store Connect validation and signing complete
