# Debrid Channels v1095 — Phase 2 Alternate Audio discovery

- Base: v1094 only
- Marketing version: 1.0.623
- Build: 623
- Scope: Phase 2 discovery only

## What changed

The old filename-token Alternate Audio placeholder was replaced by an asynchronous backend discovery request. The tvOS app sends the current resolved playback URL and up to 50 already-resolved Source Intelligence candidates to `POST /api/alternate-audio/discover`.

The included backend runtime uses real `ffprobe` stream metadata to:

- read audio language tags, titles, codecs, and dispositions;
- exclude commentary and descriptive audio by default;
- verify exact movie/year or television season/episode ownership;
- compare duration, start time, frame rate, edition, chapter count, and release metadata;
- optionally compare three sampled video fingerprints when practical;
- classify every inspected candidate as Exact Match, Offset Match, Drift Correctable, Possible Match, or Incompatible.

The first press of **Enable & Scan English Audio** explicitly enables only the versioned Phase 2 discovery flags. The feature remains off by default after a clean install or Restore Stable UI Defaults.

## Playback safety

Phase 2 does not change the active playback URL, player generation, audio output, play/pause state, subtitles, or timestamp. Selecting a discovery candidate only records the choice and sync offset. Engine-facing external-audio arguments remain forced to `nil`/`0` until the separate Phase 4 handoff flag is enabled.

## Backend handoff

`BackendAlternateAudioRuntime/alternate_audio_discovery_runtime.py` must be installed on the Debrid Channels backend and registered on the production FastAPI app. The app build alone does not deploy the backend endpoint.

Backend requirements:

- `ffprobe` and `ffmpeg` on `PATH`;
- existing backend authentication around the new endpoint;
- registration instructions in `BackendAlternateAudioRuntime/README_PHASE2_ALTERNATE_AUDIO_DISCOVERY.md`.

## Protected v1094 behavior

- Tapframe KSPNUVIO remains unchanged.
- PlaybackKit KSPlayer surface remains byte-identical to v1094.
- v1073 eager trailer runtime and trailer manager remain byte-identical to v1094.
- Phase 0 stable-protection manager remains byte-identical to v1094.
- v1094 premium Live TV overlay, Quick Guide, Gracenote persistence, and catalog pulse are not redesigned in this phase.
- No Movie Mode code was added.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing and a backend endpoint test are required before Phase 3.
