# Debrid Channels v1045

## Base

- Base archive: `DebridChannels_v1044_V1043_BASE_VOD_CONTROL_DRAWER_BOTTOM_FLUSH_GITHUB.zip`
- Marketing version: `1.0.573`
- Build: `573`

## Scope

v1045 is a narrow connected Media Information popup correction. It does not modify PlaybackKit, KSPlayer, Live TV playback, catalog loading, backup/restore, preview playback duration, trailers, or Source Intelligence.

## Corrections

### Selected card remains visually focused

Opening the connected popup no longer lets the catalog card collapse when tvOS transfers real focus into the popup. The exact source row/index and canonical media identity now keep the clicked card enlarged, ringed, elevated, and connected until the popup closes. The focused-card preview itself is stopped while details are open.

### Left hero uses the exact clicked title

The catalog hero now prefers `CatalogStore.selectedDetail` while the popup is open. This prevents a transient FocusState reset from replacing the clicked title with row-zero/first-row artwork, logo, metadata, or synopsis.

### Fully transparent popup surface

The global popup dim curtain, opaque black panel, material layer, rounded panel frame, border, shadow and alternate landscape poster backdrop were removed. The catalog or Live TV cards behind the popup remain visible. The requested portrait poster in the production-information top bar remains.

### Episode focus always remains visible

The connected popup displays two episode cards. Its navigation window now also uses a two-card page size. Moving left or right advances the visible window immediately, so every focused episode remains on-screen through the entire season.

## Preserved

- Connected card-to-popup line and animation
- Popup actions, cast and production information
- Portrait poster in the popup top information bar
- 30-second focused-card previews
- VOD Control Drawer
- Full-profile backup and restore
- Catalog-row recovery and cast hydration
- KSPlayer and VOD queue `24 / 24 / 16`
- Live TV first-frame behavior
- Audio, subtitles, scrubber, trailers and Source Intelligence

## Local validation

- 39 Swift files passed `swiftc -frontend -parse`
- Main app and Top Shelf plists passed `plutil -lint`
- `project.yml` passed YAML parsing
- 12 targeted v1045 source assertions passed
- 9 critical playback/catalog/backup/service files match v1044 byte-for-byte
- Archive integrity and extraction round-trip validation are recorded in `VALIDATION_RESULTS_v1045.json`

GitHub Actions remains the authoritative Apple tvOS SDK compile/archive gate.
