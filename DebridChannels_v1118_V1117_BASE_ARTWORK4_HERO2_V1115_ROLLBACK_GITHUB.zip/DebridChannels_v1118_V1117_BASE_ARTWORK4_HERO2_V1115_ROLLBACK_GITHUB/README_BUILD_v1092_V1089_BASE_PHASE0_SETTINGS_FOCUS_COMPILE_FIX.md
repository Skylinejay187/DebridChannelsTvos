# Debrid Channels v1092 — Phase 0 Settings-Focus Compile Fix

Base: verified v1089 source line  
Marketing version: 1.0.620  
Build: 620  
Scope: Phase 0 only; Phase 1 has not begun

## GitHub Actions failure corrected

The v1091 GitHub Actions run failed while compiling `DebridChannelsTVOSApp.swift`. Phase 0 added three `SettingsFocus` cases for the new Stable Protection controls, but the four directional `routeSettings` switches were not updated to handle them. Xcode correctly reported four non-exhaustive switch errors at the right, left, down, and up routing branches.

v1092 adds explicit routing for:

- `restoreStableUIDefaults`
- `emergencyPlaybackRollback`
- `replayOnboarding`

Left and right remain inert for these vertically stacked controls. Down moves from Restore Stable UI Defaults to Emergency Disable Experimental Playback and then Replay First-Time Setup. Up reverses that order and returns from the first control to the Settings category rail.

A standalone Swift type-check was generated from the exact `SettingsFocus` declaration and exact `routeSettings` implementation. It passed, proving all four switches are exhaustive. The unrelated duplicate-pattern warnings already present in the settings router remain warnings only.

## Search-style catalog focus correction retained

- The focused catalog card remains continuously in its existing sideways/perspective presentation.
- A separate `-18` to `0` spring produces the downward arrival bounce seen in Search.
- The card is never reset to a straight/head-on state.
- Favorites keeps `animateFocusArrival=false` and receives no new bounce.
- Search itself remains byte-for-byte identical to verified v1089.
- Exact popup/playback restoration functions remain byte-for-byte identical to verified v1089.

## Phase 0 protections retained

- All versioned experimental feature flags default Off and invalid values fail closed.
- Safe feature-setting migration remains active.
- Restore Stable UI Defaults uses an allowlist and preserves accounts, providers, favorites, watch progress, Live TV sources, and episode alerts.
- The original playback URL is preserved for experimental handoff rollback.
- Stale experimental playback generations are rejected.
- Emergency rollback disables experimental playback and restores the original source when available.
- Shared onboarding chips suppress the oversized system focus platter while preserving their custom visuals and remote navigation.
- Normal vertical entry into standard catalog rows starts at the first card; popup and playback returns still restore the exact launching card.

## Preserved locked systems

- Tapframe KSPNUVIO KSPlayer fork.
- No Movie Mode code.
- Working trailer resolver and complete trailer-audio path.
- Always-running episode-alert scanning.
- Full-width catalog rows.
- Search results remain inside Search.
- Centered Favorites details with no Favorites connector line.
- v1087 source-switch clock/session fixes.

## Release gate

GitHub Actions remains the authoritative Xcode/tvOS compilation test. v1092 must build successfully and pass physical Apple TV testing before Phase 1 begins.
