# Debrid Channels v1065

Base: v1064  
Marketing version: 1.0.593  
Build: 593

## Focused-card preview continuity

- Keeps the exact focused-card AVPlayer instance alive when the media-information popup opens.
- Uses a stable catalog row + canonical media identity instead of hydrated detail artwork as the preview key.
- Prevents the preview from being removed and recreated when the popup receives focus.
- Built-in trailer opening no longer releases the muted focused-card preview; the preview continues until its natural 30-second/end-of-item completion.
- Full VOD and Live TV still retain their existing decoder-safety cleanup path.

## Popup and Source Intelligence line cleanup

- Removes the colored vertical accent line inside the transparent media-information popup.
- Removes the short Find Links-to-Source Intelligence connector.
- Keeps the main focused-card-to-media-popup connector unchanged.

## Source Intelligence presentation

- Keeps Source Intelligence embedded in the 75%-transparent satellite panel.
- Restores the previous ranked hierarchy with a large Top Recommended Link / Best on This Page card.
- Shows match confidence, provider, quality, HDR, cache state, language, audio, file size, and direct/resolve status.
- Keeps the existing provider filtering, five-link page window, UP/DOWN navigation, LEFT/RIGHT paging, selection, and playback handoff logic unchanged.
