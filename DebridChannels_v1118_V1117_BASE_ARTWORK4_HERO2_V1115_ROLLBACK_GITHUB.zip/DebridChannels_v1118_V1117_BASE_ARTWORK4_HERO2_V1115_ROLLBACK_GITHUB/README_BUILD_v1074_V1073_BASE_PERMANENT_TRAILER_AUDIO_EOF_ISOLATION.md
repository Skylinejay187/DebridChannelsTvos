# Debrid Channels tvOS v1074

Base: v1073
Version: 1.0.602
Build: 602

## Objective

Permanently stop built-in trailer audio from ending while trailer video continues.
The external YouTube chip/app launcher remains removed. YouTube may still be used invisibly by the backend resolver.

## Root causes corrected

1. **Transient trailer media was treated as final playback media.**
   Signed extractor/progressive URLs and backend remux URLs could be handed directly to KSPlayer. A URL containing audio is not proof that the complete audio stream reaches the video endpoint.

2. **The focused-card preview could tear down AVFoundation during trailer playback.**
   v1065 intentionally kept the muted preview active beneath the trailer. At its natural 30-second stop, SwiftUI removed the preview representable and called `replaceCurrentItem(nil)`. That AVPlayer teardown occurred while the independent KSPlayer trailer audio pipeline was active.

## v1074 repair

### Durable trailer file boundary

- Requests a forced local backend remux with audio-EOF verification and atomic finalization.
- Invalidates the v1064 trailer URL cache namespace.
- Never opens a transient remote trailer URL directly in KSPlayer.
- Downloads the complete mux into the app Caches directory first.
- Writes to a temporary `.part.mp4` file.
- Requires a real video track and a real audio track.
- Verifies the local audio track endpoint reaches the video/asset endpoint within 1.25 seconds.
- Atomically renames the verified file into the durable trailer cache.
- KSPlayer receives only the immutable local `file://` URL.
- Keeps the eight most recent completed trailer files and removes older cache entries.

### Focused preview isolation

- Disables automatic audible media selection on the focused-card AVPlayer.
- Explicitly deselects its audible media group when ready.
- At the natural 30-second stop, the preview fades back to artwork but its dormant player item remains mounted.
- The AVPlayer item is cleaned up only on a real focus/scene/full-playback transition, not in the middle of trailer playback.

### Backend runtime hardening

- A muxed extractor URL is no longer considered durable solely because it reports an audio codec.
- Only post-write, audio-duration-verified outputs are cacheable.
- Split and progressive finalization normalizes audio timestamps with `aresample=async=1:first_pts=0` and pads audio to the full video duration.
- Final payloads declare verified EOF and atomic finalization.

## Preserved

- Built-in KSPlayer trailer popup and controls.
- External YouTube chip/app launcher remains removed.
- Focused-card preview still plays continuously through popup and trailer interactions until its normal one-shot stop.
- v1073 connector timing, action-chip glow, and Settings cleanup.
- v1072 Source Intelligence and multi-provider logic.
- VOD, Live TV, catalogs, alerts, search, favorites, and Top Shelf behavior.

## Validation boundary

- Swift source syntax parsing passes.
- Python backend helper compilation and synthetic durability tests pass.
- App and Top Shelf plists parse and match 1.0.602 (602).
- project.yml parses and matches the same version/build.
- GitHub Actions/Xcode remains the authoritative tvOS compilation gate.
- Physical Apple TV testing remains required for the real backend/trailer combination.
