# Debrid Channels v990 — v987 Motion Phase + Cadence Refinement

Base: v987 only. No v988 or v989 playback settings are carried forward. App/Top Shelf build: 1.0.518 (518).

## Main VOD refinements

- Retains v987 hardware decoding, `asynchronousDecompression = false`, synchronous video/audio decode disabled, `isSecondOpen = false`, decoder threads `auto`, and the custom non-destructive VOD clock policy.
- Retains the memory-safe decoded-frame queues: 4K = 16, 1080p = 24, lower resolutions = 16.
- Tightens the v987 late-video tolerance from six frame intervals to 2.5 frame intervals (70 ms floor), preventing a 23.976/24 fps stream from walking through as much as 250 ms of late frames.
- Requires three persistent late decisions before one corrective frame drop.
- Adds a time-based corrective-drop cooldown of at least three frame intervals / 100 ms.
- Continues to prohibit ordinary cadence recovery from flushing the decoded queue, dropping a GOP, or seeking.
- Changes the early-frame hold boundary from 0.50 to 0.35 frame intervals, reducing unnecessary previous-frame repeats while keeping presentation within the current frame window.

## tvOS display-link phase

- When tvOS Match Content is enabled for full-screen VOD, KSPNUVIO's rounded preferred-frame request is disabled so CADisplayLink follows the physically matched display cadence directly.
- This avoids converting 23.976 to an explicit 24 fps request or 29.97 to 30 fps after tvOS has already matched the output.
- When Match Content is disabled, KSPNUVIO preferred-frame scheduling remains enabled.

## UI isolation

- The internal KSPlayer clock still updates on every callback.
- SwiftUI-facing playback-time publication is reduced to once per second unless a state change or a real two-second-or-greater jump occurs, reducing main-thread invalidation during video presentation.

## Preserved from v987/v985

- Source Intelligence 25/50 visible results.
- Selected source plus three playback fallbacks.
- High-memory 2160p/remux 3-second preferred and 30-second maximum buffer.
- Playback-session memory-pressure journal.
- Automatic first-frame release and emergency same-position recovery.
- Audio/subtitle behavior, VOD overlay, trailers, Live TV, catalogs, guide, and focus behavior.
- KSPNUVIO pinned revision `69a73e5e22184c6db254eb2919f81768afb57a81`.
