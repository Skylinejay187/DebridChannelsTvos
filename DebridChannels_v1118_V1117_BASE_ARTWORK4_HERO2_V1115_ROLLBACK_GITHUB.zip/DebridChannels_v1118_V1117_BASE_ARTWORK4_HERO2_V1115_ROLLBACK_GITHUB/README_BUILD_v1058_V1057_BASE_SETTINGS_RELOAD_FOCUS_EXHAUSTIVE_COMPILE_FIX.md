# Debrid Channels tvOS v1058

Release: v1058 (1.0.586 / 586)
Base: v1057

## Build fix

GitHub Actions failed while compiling `DebridChannelsTVOSApp.swift` because the `SettingsFocus` enum gained `reloadDebridChannelsCatalogs`, but four legacy manual DPAD routing switches were not updated to handle the new case. Swift therefore rejected each switch as non-exhaustive.

This release adds `reloadDebridChannelsCatalogs` to the inert/native-focus group in all four directional switches (`right`, `left`, `down`, and `up`). The settings screen already delegates DPAD movement to the tvOS native focus engine, so this preserves existing behavior while restoring compile completeness.

No trailer, connector-line, catalog loading, VOD handoff, episode-alert, Live TV, or playback logic was changed.

## Versions

- Main app: 1.0.586 (586)
- Top Shelf extension: 1.0.586 (586)
- XcodeGen project: 1.0.586 (586)
