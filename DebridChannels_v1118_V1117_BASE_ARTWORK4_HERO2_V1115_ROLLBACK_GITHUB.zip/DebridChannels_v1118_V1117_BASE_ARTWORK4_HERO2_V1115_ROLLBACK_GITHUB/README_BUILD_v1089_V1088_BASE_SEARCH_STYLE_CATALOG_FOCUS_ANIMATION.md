# Debrid Channels v1089 — Search-Style Catalog Focus Animation

Base: v1088
Version: 1.0.617 (617)

## Change

- Reuses the existing Search card focus presentation for Home, Movies, Shows, and other animated fixed-slot catalog rails.
- Every newly selected catalog item now replays the same spring/perspective focus arrival instead of remaining permanently in an already-focused state.
- Keeps the production fixed-slot row navigation, full-width poster fan, previews, focus ownership, popup routing, and row geometry unchanged.
- Favorites continues to respect its intentionally disabled rail-animation mode.
- Search itself is unchanged.

## Implementation detail

Search cards naturally animate because each individual card toggles `isFocused`. The fixed-slot catalog rail replaces the selected item inside one view whose `focused` value remains true. v1089 adds an item-arrival focus state that performs a non-animated reset followed by the same `FocusedSidewaysCardEffect` and spring used by Search.

## Validation

- Swift syntax parsing completed for all app and Top Shelf Swift files.
- Plists and project version markers validated.
- Archive extraction and full-file SHA-256 comparison completed.
- GitHub Actions remains the authoritative Xcode/tvOS compile and physical Apple TV behavior test.
