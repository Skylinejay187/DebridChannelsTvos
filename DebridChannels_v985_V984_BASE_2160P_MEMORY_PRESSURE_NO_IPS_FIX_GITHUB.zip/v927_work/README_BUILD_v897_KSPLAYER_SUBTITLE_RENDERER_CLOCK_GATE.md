# v897 — v896 KSPlayer subtitle renderer + playback clock gate

Base: v896 / v895 lineage.

Scope only: KSPlayer VOD embedded subtitles and KSPlayer VOD playback-time reporting.

- Keeps the proven v896 active-player audio track apply path unchanged.
- Explicitly keeps KSPlayer embedded subtitle decoding enabled.
- Finds KSPlayer's real detached subtitle/caption renderer on the active KSPlayerLayer/FFPlayer object graph and mounts that same renderer above the video surface, below the existing SwiftUI VOD overlay.
- Re-checks the active layer after readiness because KSPlayer may create the renderer lazily.
- Freezes user-visible current/remaining time during the one-shot decoder flush so FFPlayer demux-clock movement cannot make the movie appear to keep playing while video output is stalled.
- No Live TV, grid, guide, VOD layout, focus, scrolling, or chip design changes.
