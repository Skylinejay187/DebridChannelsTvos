# v979 — View-Only Movie/Show Top Shelf + tvOS Long-Press Compile Fix

Base: v978.

## Top Shelf

- Adds a real `TVTopShelfContentProvider` app extension.
- Replaces the static blurry logo whenever dynamic content is available.
- Fetches Cinemeta popular movie and series catalogs.
- Shows one horizontally browsable poster shelf titled **Watchable Today**.
- Combines movies and shows and rotates the ordering once per day.
- Supplies high-resolution poster URLs for both 1x and 2x display traits.
- No play action, details action, deep link, or app navigation is assigned in this version.
- Keeps a tiny JSON cache so the last successful shelf can survive a temporary catalog outage.
- Does not download or process poster images inside the extension.

## Build fix

Replaces the unavailable tvOS overload:

`onLongPressGesture(minimumDuration:maximumDistance:pressing:perform:)`

with the supported tvOS long-press overload. The channel action menu opens when the gesture is recognized while Select remains held, and the matching tap is suppressed.

## Locked behavior

PlaybackKit, VOD Exclusive Mode, VOD overlay, cast wall, the 32/24/16 VOD decoded-frame queue, Live TV stock queue, episode alerts, catalog scrolling, and Live TV focus restoration were not changed.
