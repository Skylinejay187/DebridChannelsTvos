# Debrid Channels v970

Base: v969

## Episode alert scheduler audit

The v967/v968 scheduler calculated intervals correctly but could fail to start on cold launch. RootView commonly evaluated before production entitlement completed, saw `membershipLocked == true`, stopped the heartbeat, and had no authoritative restart when entitlement later became valid. Manually changing the frequency worked because the AppStorage change restarted the heartbeat.

v970 fixes the lifecycle, persistence, and rearm paths:

- New installs default to a 5-minute alert interval. v970 also performs a one-time migration to 5 minutes so older builds that silently inherited the former 10-minute default begin from the requested default.
- Cold launch starts one fresh selected-interval countdown after the scene is active and entitlement is valid.
- Entitlement becoming eligible explicitly activates the scheduler.
- A scene resume preserves a future deadline and catches up only when overdue.
- Frequency, followed-show, and alert-enable changes use one fresh-countdown rearm path.
- Rearm requests remain latched if the scene or entitlement is temporarily unavailable.
- Catalog bootstrap no longer cancels and replaces an already-running alert countdown.
- v968's unreliable persisted deadline is not migrated; useful scan health history is retained.
- One-minute test mode returns to the 5-minute default after a conclusive scan.
- Console diagnostics print the reason, selected interval, delay, and absolute deadline whenever the scheduler arms.

Pending alert persistence, metadata retry policy, identity migration, duplicate suppression, delivery confirmation, VOD alert presentation, and episode-alert-only poster loading from v968 remain unchanged.

## Catalog row headers

The v968 premium badge treatment was removed. Catalog headers are restored to text-only presentation:

- Exact provider/row title text retained.
- Original provider text sizing, weight, kerning, color, and shadow retained.
- No icon or remote addon logo.
- No monogram.
- No capsule/pill.
- No secondary eyebrow line.
- No underline or divider.
- No row geometry, scrolling, paging, focus, card, or artwork changes.

## Playback

v969 playback is unchanged, including the 60/32/24 decoded-frame queue experiment, Flixor VOD profile, VOD Exclusive Mode, overlay, cast wall, frame-rate matching, and dynamic-range matching.
