# Debrid Channels v977 — Live TV Phase 5

Built directly on v976.

## Fixes

### Exact card return
- Captures the channel that actually launched playback.
- Retains lightweight stable identity fields: stream URL, tvg-id, number, name and source.
- Restores by played channel first, not a stale focus binding.
- Starts restoration when the rebuilt Live TV screen mounts, so a close token emitted before mount cannot be missed.
- Keeps the snapshot until the exact target remains focused across layout turns.

### Quick Guide Gracenote
- Keeps one current guide program per channel during full-screen playback.
- Restores current title, start/end time, description and program artwork.
- Does not retain the full multi-hour EPG dictionary in the player.
- Releases the compact snapshot when Live TV playback exits.

### Long-press channel actions
- Removes the native tvOS context-menu preview from Live TV grid/guide channels.
- Uses a stable black-glass action panel for Favorites and Sports.
- Freezes the source card's visual focus while the panel is open.
- Restores focus to the same card when the action panel closes.

## Preserved
- v976 full-screen Live TV canvas focus owner.
- v975 Live TV memory cleanup and diagnostics.
- VOD 32/24/16 decoded-frame queue.
- VOD Exclusive Mode, VOD overlay and cast wall.
- Episode alerts and catalog headers.
