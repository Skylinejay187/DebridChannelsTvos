# Debrid Channels v960 — VOD Decoder Threads + Frame Queue

Base: v959 VOD decoded-frame queue and clock pill build.

## Main VOD changes only
- Preserve the v959 decoded-frame queue: 32 frames for 4K, 24 for 1080p, 16 below HD.
- Keep hardware decoding enabled.
- Keep asynchronous decompression enabled.
- Explicitly keep synchronous video and audio decode disabled.
- Keep video adaptability enabled.
- Change FFmpeg decoder thread count from `auto` to `0` (all available decoder cores).
- Remove forced `thread_type = slice` so FFmpeg chooses its normal threading mode.
- Add one startup diagnostic line reporting the effective main-VOD decoder policy.

## Preserved
- Trailer decoder profile remains `threads=auto`, `thread_type=slice`.
- Live TV decoder profile remains unchanged.
- v957 play assertion and emergency first-frame recovery remain unchanged.
- v959 VOD AM/PM clock pill placement and styling remain unchanged.
- No FFmpeg demux, network, probe, cache, VideoToolbox pixel-format, overlay, track, or display-match changes.
