# Debrid Channels v976 — Live TV Full-Screen Focus Owner

## Base
Built directly from:

`DebridChannels_v975_PHASE4_LIVETV_MEMORY_AUDIT_CLEANUP_GITHUB.zip`

## Problem fixed
After selecting a Live TV channel, the root correctly removed the heavy Live TV grid to reduce memory. The full-screen player then immediately hid its controls, but its KSPlayer video surface was intentionally non-focusable. Although `playerCanvasFocused` existed, it was not attached to a view. tvOS therefore had no focusable destination and dropped remote focus as soon as playback opened.

## Fix
- Added a transparent, full-screen Live TV canvas focus host.
- The host is active only while Live TV controls and option panels are hidden.
- Claims focus after the player has mounted and reasserts it after the next layout turn.
- Keeps focus during loading, first-frame transition, normal playback, and the Live TV Quick Guide.
- Hands focus to player controls when chrome opens.
- Reclaims focus when controls or a panel close.
- Cancels and releases the focus task when the player disappears.
- Added focused diagnostics under `[LiveTVFocus][v976]`.

## Preserved
- v975 Live TV memory cleanup and lightweight grid restoration.
- VOD playback pipeline.
- VOD decoded-frame queue: 4K 32 / 1080p 24 / below 1080p 16.
- Live TV stock adaptive decoded-frame queue.
- VOD Exclusive Mode, overlay, cast wall, alerts, and catalog UI.

## Validation
- All Swift source files parse successfully.
- Only `Sources/DebridChannelsTVOSApp.swift` changed in executable source.
- Existing unrelated indentation warning in `PlaybackKitKSPlayerSurface.swift` remains unchanged.
- `project.yml` parses successfully.
