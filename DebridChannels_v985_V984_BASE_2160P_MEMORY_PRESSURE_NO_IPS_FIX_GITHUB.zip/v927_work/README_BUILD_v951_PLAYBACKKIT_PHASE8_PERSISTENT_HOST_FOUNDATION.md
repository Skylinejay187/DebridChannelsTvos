# v951 PlaybackKit Phase 8 — Persistent Host Foundation

Base: confirmed-working v950 Phase 7.

This phase adds one session-owned `PlaybackPersistentRenderHostView` retained by `PlaybackRenderHost` for the lifetime of non-Live-TV playback.

Safety boundary:
- The host is not inserted into the visible view hierarchy.
- It does not adopt or reparent `KSContainerView`.
- It does not add/remove subviews or move CALayers.
- It does not resize, hide, focus, configure, create, or destroy KSPlayer.
- `UniversalCodecSupport.swift`, `updateUIView`, decoder, buffering, first-frame behavior, and Live TV remain unchanged.
