# Debrid Channels v936 — Tapframe Defaults + Source Intelligence Recovery

Base: v935, with the failed VOD `syncDecodeVideo` experiment removed.

Kept:
- Tapframe KSPNUVIO as the locked KSPlayer dependency.
- v930 playback/render-host integration.
- v935 Source Intelligence recovery and forced fallback population.
- Favorites isolation and VOD dock settings.

Removed:
- `options.syncDecodeVideo = isVODStylePlayback`

No other playback, decoder, buffering, clock, hardware, audio, subtitle, seeking, Live TV, or UI behavior was changed.
