# v896 — KSPlayer active track apply + subtitle renderer fix

Base: v895 exactly.

Scope intentionally limited to `Sources/UniversalCodecSupport.swift` KSPlayer VOD path.

## Fixed
- Copies the newly selected audio/subtitle indexes into the active KSPlayer coordinator before applying them.
- Applies selection to `layer.player`, the actual active FFPlayer-backed player instance.
- Keeps an explicit selection pending if tracks are not exposed yet, then applies it at `readyToPlay`.
- Performs one same-position decoder/output flush only after a real explicit track change.
- Flush preserves timestamp and restores the prior play/pause state.
- Keeps KSPlayer's decoded subtitle/caption/text renderer visible and promoted above the video surface while the custom VOD overlay remains above the representable.
- Re-promotes subtitle renderer during layout/late KSPlayer setup without polling, repeated seeks, or player replacement.

## Not changed
- Live TV
- Grid
- Guide
- Playback source selection
- VOD layout/chips
- Focus/scrolling

The Floating Dock Centered chip redesign is intentionally deferred until this KSPlayer audio/subtitle fix is confirmed working, per request.
