# Debrid Channels v974 — Phase 3 Live TV Deterministic Rebuild + 32/24/16 Queue

Built directly from v973 Phase 2.

## Live TV Phase 3
- Cancels Live TV refresh, focus-restore, guide-hint, preview warmup, and obsolete artwork prefetch work before full-screen channel playback.
- Keeps only the lightweight store-owned Phase 2 snapshot while the heavy Live TV grid is removed.
- Rebuilds the saved category and virtualized channel window before requesting focus.
- Uses one cancellable staged restoration task instead of competing fixed-delay focus requests.
- Verifies that the target card exists in the rendered virtual window before assigning tvOS focus.
- Recenters the virtual window once when provider ordering changed.
- Restores grid/guide focus, reasserts it after layout, then consumes the snapshot.

## Decoded-frame queue
- 4K: 32
- 1080p: 24
- Below 1080p: 16
- Live TV remains on KSPlayer stock adaptive behavior.

## Preserved
- VOD player architecture and Flixor profile except the explicitly requested queue values.
- VOD Exclusive Mode.
- VOD overlay and cast wall.
- Episode alert system.
- Catalog UI.
- Live TV card layout, guide layout, and normal DPAD navigation.
