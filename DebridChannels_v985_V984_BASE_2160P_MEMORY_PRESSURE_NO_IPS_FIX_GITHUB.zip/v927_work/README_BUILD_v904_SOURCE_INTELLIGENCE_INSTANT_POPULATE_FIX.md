# v904 — Source Intelligence Instant Populate Fix

Base: v903 / v902 / v898-safe lineage.

Scope:
- Fixes the Source Intelligence link list population delay, not the player-open preflight.
- Preserves v898/v902 KSPlayer audio path and existing subtitle/time work.
- Does not touch Live TV, grid, guide, VOD layout, focus, scrolling, or chip design.

Changes:
- Removed eager Real-Debrid infoHash/magnet resolving from the Find Links population loop.
- Stremio addon streams now populate immediately from returned stream.url/externalUrl/infoHash metadata.
- Debrid-only infoHash streams are resolved only when the user selects that source.
- This avoids serial addMagnet/selectFiles/torrentInfo/unrestrict calls for every returned stream before the list appears.

Why:
- Other apps show the addon-returned stream list quickly and resolve only the chosen source.
- Debrid Channels was doing debrid API work during list construction, causing the entire Source Intelligence panel to feel slow.
