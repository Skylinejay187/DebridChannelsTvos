# DebridChannels v818 — Artwork 3 Hero Logo Ambient Wall Only

Base: `DebridChannels_v817_COMET_TORRENTIO_WIRING_FIX.zip`

Scope locked to Artwork 3 Hero only.

Changes:
- Artwork 3 Hero no longer renders the focused title's large backdrop as the hero background.
- Artwork 3 Hero keeps the existing large logo/title layer in place.
- Artwork 3 Hero now uses a very dim ambient content wall behind the logo so the catalog/live-style grid remains subtly visible without competing with the logo.
- Existing rows, row brightness, geometry, focus, navigation, playback, addons, advisory, sports, Live TV, membership, and all other themes are untouched.

Do not use this build as a general UI redesign; it is a single-theme visual refinement only.
