# DebridChannels v861

Base: DebridChannels v857.

Scope:
- VOD overlay only.
- No Live TV grid, Guide, scrolling, focus-return, artwork cache, or performance pipeline changes.

Changes:
- Repositioned VOD information stage so poster/logo/info start at the same left edge as the timeline start time.
- Repositioned Cast Wall to bottom-trailing of the VOD info stage so its right edge aligns with the timeline/end-time side and sits closer to the progress bar.
- Added a VOD overlay chip: `Hardware Auto / Force On / Force Off` cycle.
- Hardware chip updates `vodHardwareAccelerationMode` from inside playback and reopens the active engine immediately, preserving current playback time where supported.

Validation:
- Confirmed only one `TheaterAmbientArtworkGlow` declaration.
- Confirmed only one `VODTheaterModeStrip` declaration.
- Confirmed Swift brace balance by source scan.
- tvOS Xcode build must be run in GitHub/Xcode environment.
