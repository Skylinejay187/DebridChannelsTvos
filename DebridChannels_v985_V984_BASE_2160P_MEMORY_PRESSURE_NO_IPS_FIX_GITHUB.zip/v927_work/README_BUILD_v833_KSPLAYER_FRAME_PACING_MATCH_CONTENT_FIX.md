# DebridChannels v833 — KSPlayer Frame Pacing + Match Content Crash Guard

Baseline: v832 SOURCE_INTELLIGENCE_EXIT_FOCUS_FIX.

Scope locked:
- Preserved v831 KSPlayer buffering/cache-ahead settings.
- Reduced hidden-controls playback clock updates from once per second to periodic bookkeeping so SwiftUI chrome does not re-render every second during smooth KSPlayer playback.
- Kept resume/progress saving active while playback controls are hidden.
- Added a tvOS Match Frame Rate / Dynamic Range crash guard by avoiding KSAVPlayer-first VOD startup during normal KSPlayer playback.
- Kept KSMEPlayer as the stable primary KSPlayer VOD route while leaving KSAVPlayer as a secondary compatibility route for native-compatible streams.

No Source Intelligence, Link Cache, Favorites, Membership, Live TV guide, or UI redesign changes.
