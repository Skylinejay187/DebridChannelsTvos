# DebridChannels v840 — Trailer v832 Playback Logic on v839 Base

Base: `DebridChannels_v839_CAST_WALL_OVERLAY_POLISH.zip`

Imported only from v832:
- KSPlayer trailer playback buffer/probe/format option profile from `UniversalCodecSupport.swift`
- Trailer-specific FFmpeg options restored:
  - trailer forward buffer 8s / max buffer 12s
  - trailer cache 1500
  - trailer analyzeduration 1000000
  - trailer probesize 262144
  - trailer max_delay 100000
  - trailer `+genpts`
  - trailer removes `flags` low-delay override

Preserved from v839:
- Cast Wall overlay polish
- Poster/cast UI changes
- v838 real catalog startup fix
- v835 alert hardening
- v833/v834 VOD playback behavior for movies/shows
- Source Intelligence, backend, navigation, focus, membership, Live TV unchanged

Scope:
- Only trailer KSPlayer playback logic was changed.
