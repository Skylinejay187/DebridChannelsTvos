# Debrid Channels v978

Base: v977 Phase 5

## Live TV fixes

### Exact off-screen card return
- Adds a ScrollViewReader restoration stage before FocusState is applied.
- Rebuilds the saved virtual channel window.
- Scrolls the LazyVGrid to the exact played channel with animations disabled.
- Waits for the target card to be materialized before requesting focus.
- Retains the restore snapshot until focus stabilizes on the exact channel.
- Fixes the previous behavior where only cards already visible near the top row restored reliably.

### Hold-to-open channel actions
- Starts an explicit hold timer as soon as Select is pressed.
- Opens the action panel while Select is still held.
- Suppresses the release tap so a long press cannot accidentally launch playback.
- Ignores the same held Select release on the newly focused first action, preventing accidental favorite activation.
- Cancels hold work when the press ends or the screen disappears.

### Focus chip shape
- Disables the native tvOS focus platter on action buttons.
- Clips the focused state, hit shape, and compositing layer to the same rounded chip geometry.
- Removes the oversized rectangular white focus card around the action row.

## Preserved
- v976 full-screen Live TV focus owner
- v977 compact Gracenote current-program Quick Guide snapshot
- Live TV memory cleanup and lightweight grid teardown
- VOD Exclusive Mode and VOD overlay
- VOD decoded-frame queue: 32 / 24 / 16
- Live TV KSPlayer stock adaptive queue
- Episode alerts and catalog headers
