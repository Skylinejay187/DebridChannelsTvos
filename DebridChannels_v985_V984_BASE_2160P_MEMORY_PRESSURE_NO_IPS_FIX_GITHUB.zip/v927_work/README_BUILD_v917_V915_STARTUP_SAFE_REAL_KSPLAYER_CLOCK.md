# Debrid Channels v917

Base: v915 (v906 startup/player lifecycle + v840 stable KSPlayer layout)

- Restores and preserves v915's working first-frame/loading overlay release path.
- Does not use KSPlayer time callbacks to dismiss the loading overlay.
- Wires the existing real KSPlayer playback-time callback only after the video surface is already released.
- Stops synthetic SwiftUI time mutation after first-frame readiness, removing recurring playback-time UI work without trapping playback behind the loading screen.
- Leaves audio/subtitle selection, player/resource lifecycle, Live TV, grid, guide, focus, scrolling, and VOD layout unchanged.
