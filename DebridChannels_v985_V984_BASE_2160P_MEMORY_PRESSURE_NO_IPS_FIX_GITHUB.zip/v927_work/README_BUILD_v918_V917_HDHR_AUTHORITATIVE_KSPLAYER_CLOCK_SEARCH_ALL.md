# Debrid Channels v918

Base: v917 (v915/v906 stable playback lineage)

Changes:
- HDHomeRun/Gracenote refresh generation guard prevents stale raw lineup/cache tasks from overwriting the successful guide/artwork snapshot.
- Successful HDHomeRun guide data is authoritative and re-merged before the final commit.
- KSPlayer visible progress uses the real playback callback only while playback chrome is visible; hidden playback performs no recurring SwiftUI time mutation or resume persistence.
- First-frame/loading-screen release remains independent from the clock callback.
- Universal Search queries every configured catalog in bounded parallel batches (up to six) and publishes cached/progressive results immediately.

Untouched:
- Live TV card/grid/guide layout and focus
- KSPlayer container/resource startup lifecycle
- Audio/subtitle selection behavior
- VOD layout/chip design
