DebridChannels v862 — v857 Base / VOD Alignment + Settings Hardware Fix

Base:
- DebridChannels_v857_V856_BASE_PREFETCH_CANCEL_PERFORMANCE.zip

Reason:
- v861 failed build because the overlay-added PlayerControl.hardware case was not included in every PlayerControl switch.
- Hardware acceleration controls already exist in Settings, so the VOD overlay chip was removed instead of expanding player focus logic.

Changes:
- Kept v857 Live TV grid, Guide, focus return, scrolling, artwork performance path unchanged.
- Kept hardware acceleration selection in Settings: Auto / Force On / Force Off.
- Removed VOD overlay Hardware chip and PlayerControl.hardware path to avoid focus enum/switch build risk.
- Kept VOD overlay alignment pass: poster/logo/info moved left toward the first time label; Cast Wall aligned to trailing edge of the timeline/end-time region and lowered closer to the bar.

Do not use:
- v858 Equatable body throttle.
- v859 precomputed inputs.
- v861 overlay hardware chip.
