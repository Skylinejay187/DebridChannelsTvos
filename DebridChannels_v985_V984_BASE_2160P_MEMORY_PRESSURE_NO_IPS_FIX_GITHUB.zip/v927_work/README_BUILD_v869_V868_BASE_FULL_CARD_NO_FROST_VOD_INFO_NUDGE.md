# DebridChannels v869 — v868 Base Full Card Artwork / VOD Info Nudge

Base: v868

Changes:
- Live TV Full Card Artwork setting now uses a completely separate non-frosted render path.
- Full Card Artwork draws one full-card image surface using aspect-fit so the complete artwork is visible and not cropped.
- No frosted side panels or blurred glass/backdrop are used in Full Card Artwork mode.
- Frosted Edges mode remains unchanged.
- VOD poster/logo/info group nudged right by 54pt so it no longer hugs the left screen edge.
- Cast Wall remains independently aligned to the right/timeline end.

Not changed:
- Live TV card geometry, text overlay, focus rings, scrolling, Guide, playback return, hardware settings, VOD controls, trailer overlay.
