# v877 - V876 Base VOD Elegant Cast Wall, Premium Chips, Compact Progress

Base: v876.

VOD overlay only:
- Redesigned Cast Wall into a lighter transparent glass card with subtle white edge/glow.
- Redesigned bottom controls with a more premium black/white glass focus treatment.
- Reduced VOD timeline width so it no longer spans nearly the whole screen.
- Kept white scrubber dot and pure black played progress.
- Kept poster/info alignment anchored to the progress bar start.

No Live TV grid, Guide, playback engine, source loading, settings, or catalog logic changed.
