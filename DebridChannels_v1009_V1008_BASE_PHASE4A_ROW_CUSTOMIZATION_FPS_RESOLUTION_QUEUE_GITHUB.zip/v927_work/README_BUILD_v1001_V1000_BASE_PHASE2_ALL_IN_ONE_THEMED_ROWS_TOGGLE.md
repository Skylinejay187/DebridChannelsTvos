# Debrid Channels v1001 — v1000 Base / Phase 2 All-in-One Themed Rows + Opt-Out

Base: v1000, preserving the complete v999 playback/subtitle pipeline.

## App changes only

- Added dynamic Phase 2 row-theme metadata decoding.
- Added one-request `/api/catalog-rows` batch loading for large all-in-one manifests.
- Preserves clean server row names such as `New Releases`, `4K Showcase`, and provider/genre titles.
- Supports themed row accent colors, symbols, short names, optional logo URLs, provider badges, and backgrounds.
- Added `All-in-One Catalogs` setting, enabled by default.
- When disabled, the app ignores the Debrid Channels catalog server and uses the person's other saved catalog URLs.
- Disabling does not remove the manifest URL, server data, or personal catalogs.
- Private LAN HTTP catalog and artwork URLs remain allowed for in-home testing.

## Unchanged

PlaybackKit, KSPlayer, subtitles, subtitle glyph rendering, cadence, trailers, VOD overlay, Live TV, guide, Source Intelligence, metadata timeline recovery, and catalog lifecycle recovery.
