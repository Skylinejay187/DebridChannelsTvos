# Debrid Channels v994 — v993 Base KSPNUVIO Unicode Extraction Build Fix

## GitHub Actions failure fixed

The v993 pre-generation step downloaded the pinned KSPNUVIO source as a ZIP and used macOS `unzip`. The archive contains a documentation filename that the runner could not materialize, causing `unzip` exit code 50 before XcodeGen or Swift compilation.

## v994 correction

- Keeps the exact pinned revision `69a73e5e22184c6db254eb2919f81768afb57a81`.
- Replaces codeload ZIP extraction with a sparse Git checkout.
- Checks out only `Package.swift` and `Sources/`; `Documents/` is never created.
- Preserves the audited FFmpegDecode HDR/SEI safety patch.
- Preserves all v993/v992/v990 playback, lifecycle, cadence, queue, buffer, resolver and UI behavior.

Version: 1.0.522 (522).
