# Debrid Channels v992 — v991 Base Catalog Interactivity & Lifecycle Recovery

Base: v991 (v990 cadence refinement + HEVC asynchronous VideoToolbox crash fix).

## Fixed
- Catalog rows could be visible but unresponsive after closing VOD.
- Catalog focus could be lost after tvOS inactivity/background/screen saver, while the top menu remained disabled.

## Changes
1. VOD gate/artwork exclusivity ends before `playbackURL` publishes nil.
2. VOD dismissal now tears down PlaybackController/KSPlayer while the player screen still owns the hierarchy, then returns to catalogs after a render turn.
3. Root scene activation and playback exit run an idempotent catalog-interactivity reconciliation.
4. Catalog quick-panel focus restoration is task-owned, cancelable, retried after mount, and rearmed on scene activation.
5. Stale VOD gate state self-heals only when no playback URL is active.

## Preserved
- v991 asynchronous VideoToolbox main-VOD decoder crash fix.
- v990 refined motion clock, queue sizes, display matching, memory protections, fallback limit, Source Intelligence 25/50, VOD overlay, Live TV, guide, favorites, catalogs and artwork quality.

Version: 1.0.520 (520)
