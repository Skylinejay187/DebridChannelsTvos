# Debrid Channels v996

Base: v995

## Scope

- Removes internal player-engine names, provisional playback time, and cache diagnostics from the full-screen VOD loading message.
- Adds a player-owned metadata hydration path that remains active while catalog rendering is suspended for VOD Exclusive Mode.
- Retries one incomplete metadata response after a short bounded delay instead of leaving permanent placeholders.
- Uses layered metadata fallback: current detail/playback item, Cinemeta/Stremio metadata, TMDB artwork/overview/credits when configured.
- Treats episode media as series metadata instead of movie metadata.
- Removes the old fake current-year fallback when release metadata has no valid year.
- Reuses the same metadata authority for details and VOD overlay presentation.
- Adds direct TMDB-ID metadata lookup before title search.
- Adds movie runtime, exact TV episode runtime, series runtime fallback, and OMDb runtime fallback.
- Makes PlaybackKit's session clock the authoritative KSPlayer VOD timeline.
- Re-arms the authoritative clock when the startup/track decoder flush actually completes, even when KSPlayer omits a second ready callback.
- Removes synthetic KSPlayer current-time advancement from the startup fallback.
- Uses the authoritative session clock for elapsed, remaining, progress, seeking, and resume saving.
- Cancels metadata and timeline recovery tasks during player teardown.

## Preserved

- v993 patched synchronous FFmpeg decoded-frame path.
- v990 cadence refinements.
- v992 catalog lifecycle/focus recovery.
- v985 memory limits and selected source plus three fallback limit.
- Live TV and trailer playback profiles.

Version: 1.0.524 (524)
