# v971 — Live TV Persistent Grid Focus Return Fix

Base: v970.

## Root cause

The v963 VOD-exclusive root teardown was keyed to any non-nil playback URL. Live TV
therefore unmounted `LiveTVScreen` when a channel opened, destroying the SwiftUI
`@FocusState`, selected category/channel, and virtualized grid window. The close-player
restore token could fire before the newly-created grid existed.

## Fix

The static quiet-mode root is now selected only while
`store.vodExclusivePlaybackActive` is true. Movies and episodes retain the complete
VOD-exclusive teardown. Live TV keeps its existing grid instance mounted but disabled
behind the full-screen player, so focus restoration occurs on the same view identity.

No PlaybackKit, VOD profile, alert scheduler, catalog header, overlay, cast wall, Live
TV card layout, guide navigation, or channel playback code was changed.
