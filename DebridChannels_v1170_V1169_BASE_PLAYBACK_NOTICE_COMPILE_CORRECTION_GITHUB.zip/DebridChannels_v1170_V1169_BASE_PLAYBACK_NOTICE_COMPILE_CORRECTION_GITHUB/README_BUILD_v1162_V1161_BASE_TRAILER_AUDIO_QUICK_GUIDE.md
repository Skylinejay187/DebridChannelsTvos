# Debrid Channels tvOS v1162

Base: v1161 only  
Version: 1.0.690 / 690  
Backend: v674 unchanged

Corrective scope:
- trailer-only finalized remux-cache/audio-EOF boundary
- playback Quick Guide category/Favorites support
- full-frame Gracenote artwork and professional Quick Guide typography

GitHub Actions/Xcode and physical Apple TV testing remain authoritative.
