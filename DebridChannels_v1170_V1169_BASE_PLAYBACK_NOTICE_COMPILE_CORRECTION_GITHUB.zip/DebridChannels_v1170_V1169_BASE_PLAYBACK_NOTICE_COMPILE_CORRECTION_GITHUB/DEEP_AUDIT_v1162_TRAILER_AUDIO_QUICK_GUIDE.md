# Debrid Channels v1162 Deep Audit

Base: packaged v1161 only  
Marketing version: 1.0.690  
Build: 690  
Backend: v674 unchanged

## Trailer audio root cause

The current CatalogStore still contains the v1093 donor comment stating that the v1073 eager trailer path intentionally does not wait for the later durable full-file/audio-EOF staging and that mid-trailer audio cutoff remained an accepted temporary limitation. The player-side preview/audio-isolation fixes from v1056/v1074 are still present, so the remaining hole is at the trailer media boundary rather than the movie/episode player.

v1162 keeps direct already-muxed progressive trailer URLs on the proven fast path. Backend remux-cache MP4s now: wait for stable size, download fully to the app Caches directory, retain an .mp4 extension during validation, require real video+audio tracks, require audio coverage >=98% and ending no more than 1.25s before the video/asset endpoint, atomically publish the verified local file, retain eight recent finalized trailers, and invalidate the older app/backend trailer cache namespace with v1162.

PlaybackKitKSPlayerSurface.swift is unchanged.

## Live TV playback Quick Guide

The in-playback Quick Guide previously always exposed the entire snapshot. It now mirrors the same category model as the Live TV grid: All, My Favorites, HD, Favorites, Sports, Drama, News, Kids, plus provider categories discovered in the active lineup. LEFT/RIGHT changes channel; UP/DOWN changes category; Select tunes; Back closes. The selected category persists through a Quick Guide channel handoff.

My Favorites uses the same myFavoriteChannelIds AppStorage key as the Live TV grid.

## Gracenote presentation

Program artwork in Quick Guide cards now uses aspect-fill full-card rendering instead of scaled-to-fit inset rendering. The selected-channel detail also uses full program artwork when Gracenote provides it, falling back to the channel logo. Program/channel/time typography is rebuilt with Avenir Next / Avenir Next Condensed hierarchy and tighter tracking.

## Preservation

No changes to PlaybackKit, resume cache, automatic failover, per-title memory, Phase 15, SportsCenterViewModel, TrailerServiceManager, wallpaper, VOD themes, app icon, or backend runtime. The working VOD scrubber and automatic-resume functions remain unchanged.
