# Debrid Channels v1161

- Base: v1160 only
- Marketing version: 1.0.689
- Build: 689
- Backend: v674 unchanged
- Purpose: compile-only correction for the missing `VODFeaturedCastPresentationMode` type.

This package restores only the enum accidentally removed during v1160's VOD overlay theme rework. Runtime behavior and v1160 visual changes are otherwise preserved.
