# Debrid Channels v1163
Marketing version 1.0.691 — build 691.

Icon-only corrective release from v1162. Uses the user-selected retro-TV icon master without crop or stretch and composes it correctly inside the required tvOS 5:3 launcher canvases.
