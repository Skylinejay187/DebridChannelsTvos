# v1166 Live TV Now/Next Timeline Audit

Base: packaged v1165 only  
Marketing version: 1.0.694  
Build: 694  
Backend: v674 unchanged

## Goal
Keep Live TV schedule metadata authoritative and synchronized across the main grid, playback overlay, and playback Quick Guide even before DVR/timeshift is implemented.

## Root timing issue
`LiveTVSourceModel.currentProgram(for:)` still returned `programs(for: channel).first`. Full guide arrays can contain multiple real-timed rows, so "first row" is not a reliable definition of what is airing now. Playback Quick Guide already had a separate current/next windowing path, leaving multiple UI surfaces capable of disagreeing around program boundaries.

## Corrections
- `LiveProgram` now exposes clock-based progress, remaining seconds, start countdown, and `isAiring(at:)` helpers.
- `LiveTVSourceModel.currentProgram(for:at:)` resolves the real row satisfying `start <= now < end` instead of assuming row zero.
- `LiveTVSourceModel.nextProgram(for:after:at:)` resolves the next scheduled row independently.
- Main Live TV grid re-evaluates current/next ownership every 5 seconds; only the focused card runs a 1-second visible countdown.
- Focused Live TV cards display current time remaining plus the next program title/start/countdown when available.
- Live TV playback chrome now displays a 1-second current-program timeline/progress bar and an UP NEXT preview card.
- UP NEXT preview uses Gracenote/program artwork with aspect-fill when available; otherwise it falls back to a clean text/icon treatment.
- Playback Quick Guide selected-channel details use the same timeline and UP NEXT preview.
- Playback Quick Guide snapshot rebinding now checks the selected/tuned channel every 5 seconds so current/next ownership advances promptly without network reloads.

## Performance boundaries
- No 1-second timer was added to the whole Live TV grid hierarchy.
- Main grid ownership updates use the existing single timer, changed from 30 seconds to 5 seconds with tolerance.
- 1-second TimelineView updates exist only in visible focused-card/playback/Quick-Guide metadata surfaces.
- No wallpaper, playback decoder, Source Intelligence, Sports, VOD, or resume behavior changed.

## Preservation
The following v1165 playback/source functions are byte-for-byte unchanged:
- applyAutomaticResumeIfAvailable
- scheduleAutomaticResumeAfterSurfaceStart
- saveResumePositionIfNeeded
- switchToKSPlayerEngine
- seekAbsolute
- scrubTimelineAndSeek
- commitTimelineScrubIfNeeded
- startPlayerClock
- sourceSelectedPlaybackItem

Only four inherited files changed: DebridChannelsTVOSApp.swift plus the two plists and project.yml for versioning.
