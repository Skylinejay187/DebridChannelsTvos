# Debrid Channels tvOS — v1129 Phase 10 + Smart Info

- Candidate: v1129
- Marketing version: 1.0.657
- Build: 657
- Source base: supplied packaged v1128 only
- Paired backend: v671 (`1.8.15.81-v671-phase10-security-provider-protection`)
- Roadmap phase: Phase 10 — Security and Provider Protection
- Rollback: v1128 until GitHub Actions and physical Apple TV testing pass
- Phase 11 codec/performance work is not included in this candidate.
- Navigation Sounds remain abandoned and are not present.

## Phase 10 app-side security

The Alternate Audio bridge client now accepts only Phase 10 bridge responses that explicitly declare signed playback and carry a short-lived credential bound to the exact playback-presentation UUID. The app validates the signed URL contains `dc_pid`, `dc_exp`, `dc_nonce`, and `dc_sig`, rejects a mismatched presentation identity, and rejects already-expired credentials before handing the HLS URL to the existing session-owned handoff path.

No KSPlayer, Tapframe KSPNUVIO, Phase 6 automatic failover, Source Intelligence ranking, codec/render path, player clock, or Alternate Audio runtime/FFmpeg bridge implementation was redesigned in this pass.

## Top Right Smart Info panel

The VOD overlay gains one decorative top-right panel with these modes:

- Off
- Trivia
- Related Titles
- Cast Spotlight
- Series Info
- Auto (default)

Auto priority is Verified Trivia → Series Intelligence → Cast Spotlight → Related Titles → hidden when no trustworthy data exists.

Trivia is generated only from verified structured facts. When the user's TMDB key and a TMDB identity are available, the service first uses TMDB's exact external-ID relationship to obtain a Wikidata ID; otherwise it uses a conservative exact title/type/year Wikidata search. Fact wording is generated locally from structured Wikidata claims rather than copied from third-party prose. Related Titles uses the user's existing TMDB key.

### Playback isolation contract

Smart Info is decorative overlay work only:

- no work at player bootstrap;
- requires a genuine stable first frame;
- requires the VOD controls overlay to be visible;
- does not run while another VOD panel is open;
- hides immediately and cancels outstanding work when the overlay hides;
- resumes from cached cards when the overlay returns;
- waits 450 ms after the eligible visible overlay before enrichment begins;
- rotates cached cards every 9 seconds only while eligible;
- rejects stale results by playback-presentation UUID and exact item identity;
- uses a bounded per-title/mode cache;
- has no KSPlayer, playback clock, source handoff, audio session, seek, or backend dependency.

## Files intentionally changed

- `Sources/AlternateAudioBridgeClient.swift` — Phase 10 signed bridge response enforcement.
- `Sources/DebridChannelsTVOSApp.swift` — Smart Info mode, lifecycle, panel presentation, and VOD settings control.
- `Sources/VODSmartInfo.swift` — new isolated Smart Info data/cache service.
- `Sources/StableFeatureGateManager.swift` — stable default for Smart Info Auto mode.
- `Sources/ReleaseCandidateSecurityManager.swift` — preserves Smart Info preference in safe settings backup.
- `project.yml` — v1129 version and Smart Info source membership.
- `Sources/Info.plist` and `TopShelfExtension/Info.plist` — 1.0.657 (657).

## Local validation

- 47/47 Swift files pass `swiftc -frontend -parse`.
- Foundation-only type-check passes for `VODSmartInfo.swift` and `AlternateAudioBridgeClient.swift` using isolated contract stubs.
- Both plists and project.yml validate at 1.0.657 / 657.
- Smart Info overlay-isolation contract passes.
- Phase 10 signed bridge app contract passes.
- Protected app systems are byte-identical to the supplied v1128 baseline, including KSPNUVIO, PlaybackKit, UniversalCodecSupport, Source Intelligence, automatic failover, trailer, Live TV guide, Production & Ratings metadata, CatalogStore, resume/memory, and episode alerts.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV behavior is not claimed until user testing.
