# Debrid Channels v1169 — VOD Theme Architecture Rebuild

**Marketing version:** 1.0.697  
**Build:** 697  
**Base:** packaged v1168 only  
**Backend:** v674 unchanged

## Physical Apple TV finding

The non-Original VOD themes still looked like recolors of one shared overlay. The screenshot from physical Apple TV testing made the architectural cause visible: every non-Original preset was wrapped by the same `VODOverlayThemeShell` lower-screen deck and mostly reordered the same four blocks. A different accent, corner radius, or font could not make those themes feel genuinely different while they shared the same full-width bottom skeleton.

## Design references used

The rebuild follows three useful principles from current media-player UI references:

- Apple tvOS materials are most useful when they separate foreground controls from video while allowing the moving picture to remain visually present.
- Kodi explicitly treats player OSD presentation as skin-dependent, and its Estuary customization guidance supports dark transparent OSD surfaces rather than requiring one fixed opaque layout.
- Infuse keeps the most common playback actions quickly accessible instead of making all metadata one dominant opaque surface.

These references were used as design principles only; Debrid Channels keeps its own information set and playback controls.

## Original theme — locked

`vodOriginalBottomChromeLayer` is byte-for-byte identical to v1168.

`PlayerControlButton.originalBody` is byte-for-byte identical to v1168.

Original therefore remains the exact existing production overlay the user already approved.

## Architectural correction

### Removed

The non-Original `VODOverlayThemeShell` no longer paints a 78/118-point shared bottom deck, border, accent line, or shared slab.

The old `compactDeckHeight` architecture is removed completely.

The seven non-Original presets no longer share a grouped `VStack` layout with only block ordering differences.

### Common behavior retained

The shell still owns only safe shared behavior:

- controls visibility
- hit testing
- disabled state while a panel is active
- focus section
- rasterization state
- show/hide animation
- control-shelf expansion animation

No playback state machine was duplicated.

## Rebuilt themes

### Pro — Floating Technical HUD

- Metadata lives in a dedicated translucent technical-glass island.
- Playback telemetry lives in a separate right-side island.
- Timeline floats independently below.
- Controls are detached from both information surfaces.
- No full-width bottom surface.

### Cinema — Open Editorial Cinema

- Metadata floats directly over the film rather than inside a card.
- Editorial spacing and the warm premiere line provide structure.
- Playback facts remain visible but unboxed.
- Timeline and controls are detached at the lower edge.
- Designed for maximum picture visibility.

### Media Center — Side OSD

- Kodi-inspired left-side information column.
- Strong narrow accent rail establishes hierarchy.
- Playback facts live inside the side OSD.
- Timeline and controls are a separate lower rail, not a shared background deck.

### Studio — Broadcast Split HUD

- Metadata monitor on the left.
- Telemetry module on the right.
- Controls occupy their own smaller studio module.
- Timeline remains independent below the modules.
- The composition resembles a broadcast control surface rather than the Original overlay.

### Minimal — Chrome-Free

- No cards or background slabs.
- Metadata, facts, timeline, and controls float directly over video.
- Reduced visual opacity keeps the picture dominant.

### Noir — Editorial Monochrome Split

- Movie information becomes a monochrome editorial column.
- Telemetry occupies an independent square-corner information card.
- Timeline and controls are separate and monochrome.
- No connecting bottom container.

### Prestige — Theater Cards

- Metadata uses a warm dark theater card.
- Telemetry uses a separate gold-trimmed plaque.
- A thin premiere line separates the independent timeline/control region.
- No universal bottom slab.

## Settings preview correction

The VOD Overlay Theme preview no longer shows one generic mock overlay with different colors. Each preset now has a miniature representation of its real geometry: side OSD, split HUD, open cinema, chrome-free, floating islands, etc.

## Information preservation

Every non-Original theme continues to expose the same functional information set used by the production overlay:

- title/media information
- description and metadata
- production/ratings content already provided by the media stage
- cast presentation
- position
- remaining time
- progress
- cache state
- source
- current time
- scrubber/timeline
- playback controls and control drawer

The new layouts recompose those existing sources; they do not replace them with a second metadata implementation.

## Protected playback/source systems

The following v1168 functions are byte-for-byte unchanged:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`
- `startPlayerClock`
- `sourceSelectedPlaybackItem`

All Swift files other than `DebridChannelsTVOSApp.swift` remain byte-for-byte identical to v1168.

## Validation

- 54/54 Swift source files pass `swiftc -frontend -parse`.
- Original VOD overlay block exact-match check: PASS.
- Original VOD control button exact-match check: PASS.
- Nine protected playback/source/scrubber functions exact-match check: PASS.
- Old shared `compactDeckHeight` architecture absent: PASS.
- Seven independent theme layout helpers present: PASS.
- App and Top Shelf versions: 1.0.697 / 697.
- Backend remains v674.

GitHub Actions/Xcode and physical Apple TV testing remain authoritative for full SwiftUI type checking and runtime visual review.
