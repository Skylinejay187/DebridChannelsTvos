# Debrid Channels v1134 — Phase 13 Release Gate + Cast Explorer

## Lineage

- Candidate: **v1134**
- Marketing version: **1.0.662**
- Build: **662**
- Source base: **packaged v1133 only**
- Backend: **v674 unchanged** (`d941567bf33def5daf471c9deb7455a9105472ce9389279cdfbe6cca1c4edddc`)
- Rollback app: **v1133** (`ddc122e349d52f3f98a2980f2e64a5dbd4e422cf1f59523d38662d351e5bc9b7`)

No backend endpoint or backend source change is required for this phase. Cast Explorer uses the user's configured TMDB credential for person/credit data and optional open Wikidata structured facts directly from the app. Phase 10 security, Phase 11 compatibility, Phase 12 diagnostics, and v1133 long-session stability remain preserved.

## Phase 13 — staged rollout and release gate

v1134 adds one app-owned `Phase13RolloutManager` with three explicit rollout states:

- Internal Testing
- Beta
- Stable

A development candidate initializes to **Internal Testing** and never promotes itself to Stable. The manager does not auto-enable experimental playback features.

The Phase 13 emergency playback kill switch is fail-closed. When enabled it disables versioned experimental playback flags and records the rollback reason/date without deleting accounts, favorites, watch progress, provider configuration, Live TV sources, or episode-alert state. The existing VOD failure path still restores the immutable original source; Phase 13 additionally records unrecoverable Alternate Audio handoff failures for release gating.

The existing Settings stable-protection area now displays the rollout lane. `Emergency Disable Experimental Playback` arms the persistent Phase 13 kill switch. `Restore Stable UI Defaults` clears that kill switch and retains the existing non-destructive stable-default behavior.

## Cast Explorer

Cast Explorer is included in Phase 13 as requested because Phase 13 itself does not rewrite the player engine.

The active Featured Cast poster/banner becomes selectable only when a real cast member is visibly presented. Selecting the cast presentation opens a dedicated person page over VOD.

Cast Explorer can display:

- profile image
- biography
- birth date / age
- birthplace
- known-for department
- TMDB popularity
- known-for credits
- movies
- TV shows
- upcoming projects
- character/role information
- open Wikidata occupation facts
- citizenship
- education
- awards
- reported net worth when Wikidata contains a verified USD `P2218` value

Debrid Channels does **not** calculate or invent net worth. Non-USD Wikidata values are not relabeled as dollars. A same-name Wikidata result is rejected when its birth year conflicts with the TMDB birthday.

TMDB's stable person ID is now retained from the existing credits response. Name search is only a fallback when old/cached cast metadata lacks that person ID.

## Playback isolation

Cast Explorer is user-invoked only:

- no person lookup happens when VOD starts
- no person lookup happens because a cast portrait rotates
- first-frame playback must already be ready
- VOD controls must be visible before Cast Explorer can open
- opening Cast Explorer pauses/cancels decorative Smart Info/review/Production enrichment work
- overlay auto-hide is suspended while Cast Explorer owns focus
- DPAD commands are not routed into seek/player controls while Cast Explorer is open
- closing Cast Explorer cancels its outstanding task and releases decorative decoded artwork
- the person-result cache stores metadata only, is capped at 24 entries, and expires after seven days
- no KSPlayer, AVPlayer, playback clock, source handoff, subtitle, audio-session, Source Intelligence, or backend calls were added to Cast Explorer

## Stability preservation

The Phase 11 playback/codec files and v1133 memory-management implementation remain byte-identical. Cast Explorer's remote images therefore use the already-bounded VOD artwork budget established in v1133 instead of creating a new unbounded image cache.

## Local validation

- Swift parser: all packaged Swift sources passed
- `CastExplorerService.swift`: standalone Swift type-check passed with app-model stubs
- `Phase13RolloutManager.swift` + `StableFeatureGateManager.swift`: Swift type-check passed
- Phase 13 runtime contract: migration, Internal Testing default, kill switch, experimental-feature disable, rollback reason, channel transition all passed
- both Info.plists validate at 1.0.662 / 662
- project.yml validates and explicitly includes both new Swift files
- 19 protected playback/catalog-support systems are byte-identical to v1133
- Navigation Sounds remain absent
- complete archive extraction/hash verification is performed after packaging

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV behavior is not claimed until the user tests v1134.

## Release path

After v1134 passes GitHub Actions and physical Apple TV testing:

1. Phase 14 — Accessibility & UX polish (Cast Explorer no longer needs to be introduced there; Phase 14 can focus on polish/accessibility).
2. Phase 15 — final integration, full regression matrix, Stable promotion, production lock, final rollback record, and release package.
