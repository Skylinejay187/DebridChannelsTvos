# Debrid Channels v1132 — Phase 12 Diagnostics & Recovery + Top-Right Discovery Replacement

- Base: packaged v1131 only
- Marketing version: 1.0.660
- Build: 660
- Backend pair: v674 (`1.8.15.84-v674-phase12-diagnostics-recovery`)
- Roadmap: Phase 12 — Diagnostics & Recovery

## Phase 12
Playback Health remains snapshot-only and now surfaces Alternate Audio bridge preparation stage/percentage, privacy-safe original/alternate source labels, selected stream index, match classification, offset, drift correction, video/audio mode, candidate rejection reason, and a short in-session failed-handoff history. Recovery controls add Retry Bridge, Try Another Audio, and Restore Original Audio.

Backend diagnostics are requested only when Playback Health opens or the user manually refreshes it. There is no continuous polling and no new playback-loop observer.

## Top-right discovery replacement
The prior six-mode Smart Info experiment is removed. The existing preference key is retained only for safe migration/persistence. The visible setting has exactly three states:

1. Off — default
2. Other Show Recommendations
3. Did You Know

Recommendations combine the user's configured TMDB recommendation/similar relationships, deduplicate results, and exclude the currently playing title. Did You Know uses keyless Wikidata structured facts plus already-hydrated exact-title metadata; it generates short original wording rather than copying article prose.

The discovery panel remains decorative and playback-isolated: it waits for genuine first frame, starts only while the VOD overlay is visible and no VOD panel is open, cancels enrichment/rotation when the overlay hides, reuses cached results, and does not touch KSPlayer, clocks, seeking, source handoff, subtitles, audio sessions, or player construction.

## Preserved systems
KSPlayer/Tapframe KSPNUVIO, Phase 11 codec compatibility, automatic source failover, Source Intelligence, per-title playback memory, resume/history, trailers, Live TV guide/cache/playback, Production & Ratings, Featured Cast, and episode alerts are preserved. Thirteen protected implementation files were verified byte-identical to v1131.

## Validation
- 49/49 Swift sources parsed.
- VODSmartInfo service type-checked with a strict model stub.
- AlternateAudioBridgeClient and AlternateAudioDiagnosticsClient type-checked independently.
- 16/16 discovery/Phase 12 app contract checks passed.
- 13/13 protected app files byte-identical to v1131.
- Both application plists and project.yml validate as 1.0.660 / 660.

GitHub Actions remains the authoritative Xcode/tvOS compiler. Physical Apple TV behavior is not claimed until tested.
