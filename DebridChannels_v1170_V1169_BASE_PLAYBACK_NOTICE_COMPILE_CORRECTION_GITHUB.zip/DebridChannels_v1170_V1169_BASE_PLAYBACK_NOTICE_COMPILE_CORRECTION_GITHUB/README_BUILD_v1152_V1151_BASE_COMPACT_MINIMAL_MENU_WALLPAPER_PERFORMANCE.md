# v1152 (1.0.680 / 680)

Built only from packaged v1151. Packaged v1130 is used only to restore the original compact geometry of the letters-only/minimal top menu. Other v1150/v1151 top-menu themes remain intact.

This build also replaces the expensive 15 fps / four 72-point-blurred SwiftUI smoke blobs with an asynchronous 8 fps Canvas and pauses wallpaper redraws during active Live TV grid navigation. Resume/autostart and the working automatic LEFT/RIGHT VOD scrubber are intentionally untouched.
