# Debrid Channels v1160

**Marketing:** 1.0.688  
**Build:** 688  
**Base:** packaged v1159 only  
**Backend:** v674 unchanged

Visual correction release: 12 additional dark Dynamic Live Wallpaper themes (48 total), compact sizing normalization across the top-menu theme families, and a complete redesign of all seven non-Original VOD overlay themes into smaller transparent/low-profile compositions. The Original VOD theme remains exact v1159 production behavior and visual geometry. Playback/resume/source/Sports/scrubber systems are preserved.

Run the GitHub workflow as the authoritative Xcode/tvOS compile test, then verify on physical Apple TV.
