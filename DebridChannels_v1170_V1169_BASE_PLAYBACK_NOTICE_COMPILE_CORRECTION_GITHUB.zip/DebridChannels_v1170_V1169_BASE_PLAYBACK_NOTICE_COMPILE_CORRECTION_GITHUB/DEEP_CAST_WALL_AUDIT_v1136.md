# v1136 Deep Cast Wall / Cast Explorer Audit

The restart-from-v1135 audit found multiple independent causes that could make Cast Wall behavior appear delayed or recover only after waiting:

1. **Transient-view initial hold** — the full-poster 4-second title hold was local to the Cast Wall view and could restart after overlay remount.
2. **Always-connected timer source** — rotation used an autoconnected Timer publisher even when the overlay was not eligible to present cast. The view filtered events afterward rather than owning/cancelling rotation lifecycle directly.
3. **No explicit Cast focus zone** — the VOD router knew only video/timeline/chips. Moving upward toward Cast left tvOS to reconcile the focusable cast surface with the existing control ScrollView, creating the reported focus/scroll confusion.
4. **Parent Select leakage** — the VOD parent could interpret Select while cast was focused and push focus back toward controls.
5. **Play/Pause leakage during Cast Explorer** — DPAD was isolated, but the parent Siri Remote Play/Pause handler could still resume the underlying video.
6. **VOD Cast Explorer had no pause ownership** — opening Cast Explorer did not record/pause/resume the active playback state as requested.
7. **Media Information cast rows were presentation-only** — the cast could be seen but not navigated into Cast Explorer.
8. **Filmography truncation** — Movies/TV/Upcoming were arbitrarily capped even though Cast Explorer is a dedicated person screen.
9. **Family facts absent** — the existing open-data enrichment did not request documented spouse/partner/children/parents/siblings.

All nine paths are addressed in v1136. No audio-amplification/DSP work was added; that remains isolated to Phase 15.
