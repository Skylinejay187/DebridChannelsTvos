# Debrid Channels v1145 — Resume / Timeline Scrubber Correction

**Marketing version:** 1.0.673  
**Build:** 673  
**Base:** packaged v1144 only  
**Backend:** v674 unchanged

## Why v1145

Physical Apple TV testing of v1144 showed automatic resume still starting from the beginning. The same playback screen also exposed a related timeline-state symptom: LEFT/RIGHT changed the scrub preview, but the selected timestamp was not visibly presented until Select committed the seek.

## Automatic resume correction

v1145 removes the v1144 startup-resume KSPlayer surface reload and restores the stronger timing contract documented in v1138, applied surgically to the v1144 Phase 15 base. The saved resume target now primes `ksStartTimeSeconds` before the initial KSPlayer surface is created. A bounded confirmation task waits for an advancing player clock or first-frame readiness. If the real clock is already within five seconds of the saved target, resume is confirmed without another seek. Otherwise exactly one in-place absolute corrective seek is issued through the existing KSPlayer seek serial. A ready KSPlayer surface is never recreated merely to resume.

The Resume chip remains available as a manual fallback until the authoritative player clock confirms the automatic target. Resume storage itself is unchanged.

## Timeline scrubber correction

The preview-only scrub architecture is retained so repeated LEFT/RIGHT presses do not hammer the decoder with real seeks. However, the UI now follows the preview state immediately: the playback fact changes from `POSITION` to `SCRUB TO`, the target timestamp/remaining/progress values update live, and the timeline shows current preview and total time while focused. Select/Up/Down commits the preview once.

## Preserved systems

`PlaybackKitKSPlayerSurface.swift`, `PlaybackKitFoundation.swift`, `UniversalCodecSupport.swift`, `PlaybackResumeCache.swift`, per-title playback memory, automatic source failover, Source Intelligence, CatalogStore, and TrailerService remain byte-identical to v1144. No backend change is required.

## Validation boundary

Local Swift parsing passes for all 53 Swift files and the static resume/scrubber policy checks pass. GitHub Actions/Xcode and physical Apple TV testing remain authoritative for runtime behavior.
