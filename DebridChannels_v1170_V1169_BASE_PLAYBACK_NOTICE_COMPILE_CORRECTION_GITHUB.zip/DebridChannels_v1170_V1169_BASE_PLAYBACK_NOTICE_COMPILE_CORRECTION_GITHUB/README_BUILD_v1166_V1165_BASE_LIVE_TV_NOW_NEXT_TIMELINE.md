# Debrid Channels v1166

Build from packaged v1165 only.

Physical Apple TV checks:
1. Focus a Live TV card with real EPG timing and confirm the remaining-time countdown updates.
2. Leave focus on a card across a program boundary and confirm current/next ownership advances promptly.
3. Start Live TV playback, open controls, and confirm current range, time remaining, progress line, and UP NEXT preview are shown.
4. Open Quick Guide and confirm selected-channel current/next information matches the main guide/playback overlay.
5. Confirm UP NEXT artwork fills its preview when Gracenote artwork exists and falls back to text when it does not.
