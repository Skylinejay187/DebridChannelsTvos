# Debrid Channels tvOS/iOS v1104

## Base and scope

- Base: v1103 only.
- Marketing version: 1.0.632.
- Build: 632.
- Backend update: not required; continue using backend v669.
- Scope: surgical VOD Featured Cast restoration, exact episode air-date presentation, and compact review-score badges.

## Featured Cast restoration

- Restores the active `V841DynamicCastWall` renderer byte-for-byte from v1096.
- Restores the original rich cast list and name-only fallback.
- Removes v1097+ failed-image filtering from the active VOD Featured Cast stage.
- Keeps the spotlight index in `VODPlayerScreen`, so hiding/unmounting VOD chrome no longer restarts the cast rotation at member 1.
- No further cast redesign or filtering is included.

## Episode dates

- VOD and the connected media-information profile now resolve the exact selected season/episode date.
- TMDB exact episode metadata is preferred: `/tv/{id}/season/{season}/episode/{episode}`.
- TVMaze exact season/episode lookup is the key-free fallback.
- Synopsis text and the device's current date are no longer accepted as episode-date metadata.
- Past episodes display `AIRED • <date>`.
- Future episodes display `UPCOMING • <date>`.
- A genuine episode airing today may display `TODAY • <date>`; the date must come from exact episode metadata.

## Review-score badges

- Removes the fixed 255-point episode-date width that created the large date-to-rating gap.
- Adds the requested exact icons:
  - 🍅 Critics: real Rotten Tomatoes score from the existing OMDb integration when available.
  - 🍿 IMDb: the real community rating already supplied for the title.
- No score is fabricated. Missing badges collapse without leaving blank space.

## Protected systems

- The nine core catalog/Search source-resolution functions remain byte-identical to v1103.
- Catalog Health scrolling remains unchanged from v1103.
- Backend v669 source-resolution isolation remains unchanged.
- KSPlayer/Tapframe KSPNUVIO, Alternate Audio, trailers, Live TV, Search, Favorites, episode alerts, and focus behavior were not modified.

## Local validation

- All Swift source files passed syntax parsing.
- Both plists and project versions validated as 1.0.632 / 632.
- project.yml parsed as valid YAML.
- Bundled Python runtimes passed `py_compile`.
- Featured Cast/date/review contract passed 13/13 checks.
- Source resolver preservation contract passed for all nine protected functions.
- Episode-date test confirmed an aired 2018 episode does not become the 2026 device date, a future episode remains UPCOMING, and synopsis date text is ignored.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV validation is required.
