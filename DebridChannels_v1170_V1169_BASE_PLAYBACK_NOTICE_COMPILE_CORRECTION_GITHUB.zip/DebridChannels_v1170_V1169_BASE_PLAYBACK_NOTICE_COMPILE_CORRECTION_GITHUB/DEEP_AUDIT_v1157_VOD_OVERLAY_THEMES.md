# v1157 Deep Audit — VOD Overlay Themes

## Scope boundary

The source base is packaged v1156 only. v1157 is a visual VOD-overlay theme pass. No older build is used as a playback donor and no backend change is required.

## Why this is a theme system rather than a recolor system

The current v1156 overlay is already a user-approved production design, so it is preserved as **Original**. New choices are implemented as separate presentation families that can reorder the same information groups, reshape the bottom surface, change control geometry, alter typography hierarchy, and apply different artwork/backdrop treatments.

### Theme families

**Original**
- Exact v1156 bottom chrome.
- Existing circular control art and focus behavior.
- Existing genre/accent behavior and metadata hierarchy.

**Pro**
- Layered rounded technical glass.
- Cool blue accent and technical-status-first hierarchy.
- Squared/rounded premium control tiles.

**Cinema**
- Edge-to-edge theatrical fade rather than a heavy floating card.
- Warm cinema accent.
- Editorial serif information treatment.
- Thin theatrical highlight rather than a boxed border.

**Media Center**
- Dense, highly legible OSD slab.
- Strong left accent rail and separator structure.
- Rectangular direct-action controls.
- Inspired by the information-density philosophy common to Kodi/media-center skins, without reproducing a specific skin.

**Studio**
- Broadcast/control-room glass geometry.
- Structured cool accent rails and status-light details.
- Rounded broadcast control tiles.

**Minimal**
- Removes most container furniture.
- Prioritizes content, title, timeline and controls over decorative framing.
- Bare icon controls with a compact selection underline.

**Noir**
- Monochrome rendering and restrained white hairlines.
- Compact dark geometry.
- Editorial serif typography.

**Prestige**
- Warm dark theater palette with metallic-gold accents.
- Deep rounded presentation and subtle layered border/shadow treatment.
- Luxury editorial typography hierarchy.

## Runtime architecture

`VODOverlayThemePreset` is a lightweight persisted enum. `VODOverlayThemeShell` owns presentation geometry for non-Original themes. `VODOverlayThemeBackdrop` owns non-interactive thematic backdrop treatment. `PlayerControlButton` keeps an explicit Original branch and uses theme-specific artwork only for non-Original themes.

This avoids creating a second player/overlay state machine. All themes consume the same existing VOD state, actions, focus bindings, progress data, status chips, timeline, control drawer, episode/source/audio/subtitle panels and PlaybackKit state.

## Original preservation

The original v1156 `vodBottomChromeLayer` body is byte-identical to v1157 `vodOriginalBottomChromeLayer` after normalizing only the property name. This is validated automatically.

The Original `PlayerControlButton` branch retains the production visual constants from v1156: 68×68 circular art, selected 1.08 scale, 108×112 control cell, existing gradient/stroke/shadow values, rounded 13/11 point labels, and platter-free custom focus activation.

## Settings integration

`vodOverlayThemePresetV1` is:

- read by the VOD player and control art;
- exposed in the existing VOD Settings section;
- represented by an on-screen preview;
- backed up by settings export;
- validated during settings restore;
- reset to Original by stable UI defaults.

Eight Settings focus destinations were added for the eight explicit selectors. Existing Settings focus routing remains in the same architecture.

## Playback preservation

No intended changes are made to:

- automatic resume/autostart;
- source-independent movie Find Links resume identity;
- durable resume persistence;
- LEFT/RIGHT automatic scrub seek;
- player engine switching;
- PlaybackKit/KSPlayer core;
- Source Intelligence behavior;
- alternate audio behavior;
- Sports direct tune/cleanup;
- Live TV wallpaper behavior/performance modes;
- Phase 15 Full Episode Browser behavior.

The protected functions and files are compared directly to packaged v1156 during validation.

## Validation authority

Local Linux validation can parse Swift and verify static contracts/hashes, but cannot replace the Xcode tvOS compiler/runtime. GitHub Actions/Xcode is the authoritative compile check, followed by physical Apple TV validation for focus, geometry, performance and playback interaction.
