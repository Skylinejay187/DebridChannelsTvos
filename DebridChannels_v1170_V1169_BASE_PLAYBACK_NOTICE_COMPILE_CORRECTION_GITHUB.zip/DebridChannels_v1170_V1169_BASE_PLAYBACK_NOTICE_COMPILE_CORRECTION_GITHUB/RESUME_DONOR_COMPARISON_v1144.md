# v1144 Automatic Resume Donor Comparison

## Source discipline

- **v1144 source base:** packaged v1143 only.
- **v1133 role:** donor/reference only for the last physically known-working automatic-resume behavior.
- No v1133 catalog, UI, playback engine, Source Intelligence, Phase 15, or backend tree was used as the v1144 base.
- `PlaybackResumeCache.swift` was already byte-identical between v1133 and v1143 and remains unchanged.

## Restored resume logic

The following functions in v1144 match v1133 exactly:

- `applyAutomaticResumeIfAvailable()`
- `scheduleAutomaticResumeAfterSurfaceStart()`
- `forceResumeFromSavedPosition()`
- `seekAbsolute(...)`
- `saveResumePositionIfNeeded(...)`
- `resumeStorageKey()`

The critical behavior restored is the v1133 one-time startup resume path: the VOD surface opens normally at 0, the saved target is queued, then the first bounded delayed resume attempt sets `ksStartTimeSeconds`, sends the absolute seek, and increments `ksSurfaceToken` **once for startup resume only**. Normal user seeks do not recreate KSPlayer.

This reverses the later confirmed-clock strategy that could remain at 0:00 while waiting for a clock that had not yet advanced to the saved position.

## Kept from current Phase 15

Volume amplification remains an in-place `audioFilters` update and does not use the resume surface-refresh path. Cast/episode source switching, isolated source discovery, current Source Intelligence ownership, and Phase 15 UI remain on the v1143 lineage.
