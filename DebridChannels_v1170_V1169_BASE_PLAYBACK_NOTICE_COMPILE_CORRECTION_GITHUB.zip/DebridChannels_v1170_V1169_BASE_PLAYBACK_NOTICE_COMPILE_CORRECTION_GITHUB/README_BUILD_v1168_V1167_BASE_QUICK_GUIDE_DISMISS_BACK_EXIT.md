# v1168 Build Notes

Build from packaged v1167 only.

- Version: 1.0.696 (696)
- Backend: v674 unchanged
- Live TV Quick Guide auto-dismisses after 10 seconds inactivity.
- Back closes Quick Guide without exiting playback.
- New optional `Press Back Twice to Exit` setting in Live TV playback Settings beside Top/Bottom Quick Guide options.
- Double-Back window: 2 seconds.
- Resume, scrubber, trailer, Sports, VOD themes, wallpaper, icon, and PlaybackKit preserved.
