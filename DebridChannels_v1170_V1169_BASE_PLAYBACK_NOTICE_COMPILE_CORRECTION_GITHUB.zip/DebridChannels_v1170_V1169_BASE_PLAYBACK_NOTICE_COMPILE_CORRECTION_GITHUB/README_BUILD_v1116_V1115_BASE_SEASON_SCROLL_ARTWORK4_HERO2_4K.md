# Debrid Channels v1116 — Long Season Scroll + Artwork 4 Hero 2 Quality Fix

Base: v1115 only  
Version: 1.0.644  
Build: 644

## Long-season correction
- Both season selectors now enumerate every season instead of rendering only the first 6/10.
- Horizontal ScrollViewReader tracking keeps the focused/selected season centered and visible.
- Episode loading, selection indexes, and navigation remain unchanged.

## Artwork 4 / Hero 2 correction
- Uses backend v669's existing `/api/artwork/resolve` multi-provider pool.
- Ranks valid landscape artwork by verified dimensions with true 4K priority.
- Considers TMDB, Fanart.tv, and TVDB candidates and caches the chosen URL for seven days.
- Suppresses the lower-quality catalog backdrop while resolution is pending, preventing the old click-to-upgrade flash.
- Keeps the originating catalog identity stable while Details hydrates richer IDs.

## Backend
No backend update is required. Continue using backend v669 with artwork provider keys configured.
