# Debrid Channels v1156 — Continuous Live Wallpaper + Professional Navigation + Settings Control Center

**Base:** packaged v1155 only  
**Marketing version:** 1.0.684  
**Build:** 684  
**Backend:** v674 unchanged  

## Scope

v1156 is a presentation/performance correction built only from v1155. It intentionally leaves the playback/resume/source-selection/Sports stack unchanged while correcting the Live TV wallpaper focus behavior and expanding Appearance/Settings with genuinely different visual compositions.

## 1. Live TV wallpaper no longer freezes on every focus change

### v1155 root cause
v1155 preserved the v1152 navigation-yield optimization by calling `noteWallpaperNavigationActivity()` from both Live TV move-command handling and selected-channel focus changes. That toggled `wallpaperMotionPausedForNavigation` and restarted it after a delay. With a dynamic background visible, every card-to-card focus move therefore produced a visible stop/start cadence.

### v1156 correction
- Removed the navigation activity pauser and delayed resume task.
- Removed all focus/move-command calls that paused wallpaper motion.
- The wallpaper Timeline receives `paused == false` while the uncovered Live TV grid owns the render budget.
- Changing focused channel/card does **not** participate in render ownership.
- Existing async Canvas rendering remains intact.

### Hard suspension boundary retained
Wallpaper rendering is still completely unmounted/suspended when any of the following takes ownership:
- video playback / selected live channel playback,
- Media Information/detail presentation,
- Search,
- Live TV quick panel,
- Full Guide,
- channel action panel,
- Home, Movies, TV Shows, Sports, Favorites, Settings, or any non-Live-TV section.

Thus continuous motion is allowed only while browsing the uncovered Live TV grid; playback and the rest of the app receive zero animated-wallpaper Timeline/Canvas work.

## 2. Performance modes preserved

The existing v1155 performance architecture remains:
- **Compatibility:** 8 fps, conservative Canvas detail, no animated blur stacks.
- **Balanced:** 15 fps, moderate Canvas detail.
- **High Performance:** 30 fps, richer Canvas detail for faster/newer Apple TV hardware.

The mode only controls the dynamic wallpaper rendering budget. It does not cap playback/UI frame rate and does not change hardware video decoding.

## 3. Dynamic wallpaper expansion — 36 total themes

The 20 v1155 themes remain, including **Spotlight Smoke**. v1156 adds 16 more professional movie/broadcast visual directions:

- Silver Screen
- Movie Palace
- Premiere Carpet
- Film Reel Light
- Projection Booth
- Broadcast Glass
- Channel Matrix
- Signal Horizon
- Studio Grid
- News Desk
- Stadium Lights
- Scoreboard Glow
- Skyline Cinema
- Prism Waves
- Cosmic Theater
- Midnight Lounge

New Canvas primitives include curtain glow, film-frame light, broadcast matrices/grids, scoreboard ticks, skyline silhouettes, prism wave ribbons, and orbit rings. They share the same asynchronous Canvas renderer and do not reintroduce large live SwiftUI blur/material stacks.

## 4. Professional top navigation expansion — 32 total themes

v1156 adds 10 themes across four new **geometry families**, not color-only variants:

### Liquid Island family
- Liquid Glass Pro
- Crystal Navigation
- Obsidian Glass

Floating icon wells, layered translucent navigation islands, selected-state dot, restrained edge treatment.

### Studio Chrome family
- Studio Chrome
- Graphite Studio
- Executive Minimal

Architectural top/bottom hairlines, studio-console geometry, restrained metallic/glass treatment.

### Broadcast Deck family
- Broadcast Deck
- Network Console

Two-level broadcast labeling, vertical accent marker, network-control-room composition.

### Modern Pills family
- Modern Capsules
- Cinema Capsules

Compact modern capsules with controlled icon appearance and selected-state indicator.

All earlier themes and the restored compact letters-only geometry remain available.

## 5. Typography expansion — 74 total presets

Eight additional shared Popup/Top Menu typography directions:
- Pro Display
- Glass Display
- Studio Sans
- Executive Sans
- Network Condensed
- Cinema Editorial
- Gallery Serif
- Modern Grotesk

These map to system-installed tvOS font families/system designs; no font files are bundled.

## 6. Settings visual overhaul

The Settings section now uses a static **Control Center** visual system:
- static async Canvas backdrop (no TimelineView / no continuous animation),
- dark navy/black depth with subtle category-colored light fields,
- new `DEBRID CHANNELS / CONTROL CENTER` header and active-category chip,
- category-specific icon/accent treatment,
- redesigned Settings category cards while preserving their exact 238×86 geometry required by the existing focus manager,
- redesigned section panels with controlled glass gradients and accent hairlines,
- redesigned common Settings action buttons with a restrained cyan focus edge, white focused surface, and compact leading accent marker.

The focus-routing architecture and `SettingsStateFocusManager.swift` are unchanged.

## 7. Design research direction

The visual direction was informed by current tvOS design guidance emphasizing navigation/control layers that remain distinct from content, restrained use of material/depth, and clear focused hierarchy. Contemporary TV-app navigation patterns were also reviewed, including persistent/simple top navigation. These references were used as design principles only; v1156 does not copy another product's assets or layout.

## 8. Protected systems

The following v1155 functions were compared byte-for-byte and remain exact:
- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`
- `startPlayerClock`
- `sourceSelectedPlaybackItem`
- `openSelected`

The following core files are byte-identical to v1155:
- `CatalogStore.swift`
- `PlaybackResumeCache.swift`
- `AutomaticSourceFailoverManager.swift`
- `PerTitlePlaybackMemory.swift`
- `UniversalCodecSupport.swift`
- `PlaybackKitFoundation.swift`
- `PlaybackKitKSPlayerSurface.swift`
- `Phase15FinalIntegration.swift`
- `SportsCenterViewModel.swift`
- `TrailerServiceManager.swift`
- `SourceIntelligenceManager.swift`
- `SettingsStateFocusManager.swift`

Only four inherited files changed before v1156 audit metadata was added:
- `Sources/DebridChannelsTVOSApp.swift`
- `Sources/Info.plist`
- `TopShelfExtension/Info.plist`
- `project.yml`

## 9. Local validation

- Swift syntax parse: **52/52 Swift files passed**.
- Static/preservation contracts: **69/69 passed**.
- Version/plist/project checks passed.
- Protected playback/resume/Sports/source functions passed exact comparison.
- Core locked-file SHA-256 comparisons passed.
- Final archive extraction/hash verification is generated during packaging.

GitHub Actions/Xcode remains the authoritative full tvOS compilation check, followed by physical Apple TV testing.
