# v1133 Deep Stability Audit

## Confirmed pressure sources
- Process-wide decoded artwork cache: previously 220 MB / 420 entries.
- Up to 10 speculative full-resolution image prefetches before this correction.
- Catalog decoded artwork retained across VOD entry even though the catalog render tree is removed during VOD.
- Decorative VOD image cache could refill during playback and survive until later lifecycle cleanup.
- Several process-lifetime metadata caches lacked explicit bounds.
- Production/review enrichment could begin after first frame even after the visible VOD overlay was gone.

## Deeper areas inspected
- Root catalog/VOD mount behavior
- PlaybackKit active session teardown
- KSPlayer render-host release paths
- AVPlayer end/time observers
- NotificationCenter observer pairing
- stored Swift `Task` cancellation paths
- detached tasks
- VODExclusiveWorkRegistry
- image/network task registries
- Live TV guide/session snapshots
- trailer resolver cache
- advisory/ratings caches
- Discovery cache
- background scene lifecycle
- memory-warning lifecycle
- recurring SwiftUI timers

## Conclusions
The strongest concrete issue is memory pressure caused by full-resolution decoded artwork retention and speculative/decorative work competing with the video decoder, plus smaller unbounded cache growth over long sessions. No obvious persistent KSPlayer instance leak was established by static inspection, so the player/codec stack is intentionally left untouched.

Physical validation should repeat browse -> VOD -> exit cycles and use `[ReleaseStability][v1133]` log lines to verify that memory returns toward a plateau after each close rather than climbing monotonically.
