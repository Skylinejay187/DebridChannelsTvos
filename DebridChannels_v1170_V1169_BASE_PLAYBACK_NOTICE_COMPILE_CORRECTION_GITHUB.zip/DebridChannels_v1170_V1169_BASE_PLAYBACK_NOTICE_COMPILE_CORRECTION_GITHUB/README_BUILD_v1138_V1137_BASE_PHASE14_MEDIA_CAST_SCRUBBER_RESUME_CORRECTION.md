# Debrid Channels v1138 — Phase 14 Media Cast / Scrubber / Resume Correction

## Build identity
- Candidate: v1138
- Marketing version: 1.0.666
- Build: 666
- Source base: packaged v1137 only
- Backend: v674 unchanged
- Roadmap phase: Phase 14 corrective pass

## Physical issues corrected

### Media Information → Cast Explorer
v1137 drew a selected cast card but the cards were passive SwiftUI presentation views. The parent canvas carried the actual focus, which meant the Apple TV Select click could be swallowed before a cast card became an actionable control.

v1138 keeps the existing visual cards but wraps the active Media Information cast rows in native tvOS Buttons with their own FocusState. The existing directional router remains authoritative and requests native focus for exactly the selected cast member. Select now invokes the same Cast Explorer service already used by VOD.

### VOD scrubber versus Cast Wall
v1137 left the Featured Cast surface focusable whenever cast data was available. That allowed the tvOS focus engine to choose Cast geometrically even when the parent VOD router intended to enter the timeline scrubber.

v1138 gates native Cast focus with the explicit VOD focus zone. The Cast Wall is focusable only when `focusedZone == .cast`. The intended path is therefore deterministic:

`controls/chips → timeline scrubber → Cast Wall`

and Cast Down returns to the timeline. Cast cycling remains automatic and unchanged.

### Automatic resume from last position
The resume-storage and history files were not changed by Phase 14, and the core v1135 resume functions were still present. The weakness was timing: the correction task could issue an automatic seek before KSPlayer had a usable frame/clock and immediately mark it applied.

v1138 primes KSPlayer's initial start time with the saved resume timestamp. The correction task then waits for a genuine frame/clock. If the clock is already near the saved timestamp it confirms resume without another seek. Otherwise it sends one corrective absolute seek only after the surface is alive. A ready KSPlayer surface is not recreated merely to apply resume.

## Preserved behavior
- VOD Cast Explorer still pauses playback while open and resumes only if playback was previously playing.
- Cast Wall cycles through all image-backed cast members and preserves its player-owned spotlight index.
- KSPlayer / Tapframe KSPNUVIO remain installed and hardware decoding remains forced.
- Phase 11 codec compatibility is unchanged.
- Phase 12 diagnostics/recovery is unchanged.
- Phase 13 release gate is unchanged.
- Playback resume/history persistence implementation remains unchanged; only the active VOD resume application timing was hardened.
- Backend v674 is unchanged.
- Audio amplification remains deferred to Phase 15.

## Validation boundary
Local Swift syntax parsing and structural regression checks are provided. GitHub Actions remains the authoritative Xcode/tvOS compiler test, and physical Apple TV behavior is not claimed until user testing.
