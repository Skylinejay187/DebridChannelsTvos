# Debrid Channels tvOS/iOS v1119

## Phase 7 — Per-title Playback Memory + slight-freeze correction

- **Base:** v1118 only
- **Marketing version:** 1.0.647
- **Build:** 647
- **Backend:** no update required; continue using backend v669

## Phase 7 behavior

### Per-title and per-episode memory

- Remembers the preferred embedded audio language/track.
- Remembers subtitle language and enabled/disabled state.
- Television audio/subtitle preferences are suggested at show level, so the next episode can reuse the same language choice.
- Remembers subtitle delay with −250 ms, +250 ms, and Reset controls. Subtitle delay remains exact-title/exact-episode scoped.
- Remembers the last selected provider, source signature, and source-quality preference for the exact movie or episode.
- Auto Play and the connected Source Intelligence list prioritize an exact remembered source when it still exists. Provider/quality fallback is limited to choices already inside the top five ranked results so Source Intelligence ranking remains authoritative.
- Existing Alternate Audio candidate and offset persistence remains exact movie/episode scoped.
- Existing resume timestamps remain exact movie/episode scoped.

### Slight-freeze correction

The previous resume cache encoded and wrote the complete resume/history payload synchronously from the player-clock save path every five seconds. v1119 keeps the latest values in memory and moves JSON encoding plus atomic file writes to a serial utility queue. Legacy v498 UserDefaults resume data is migrated automatically.

The two long-season focus-follow rows also no longer animate every automatic `scrollTo`; they perform a mount-aware non-animated scroll on the next main run-loop turn, reducing focus hitching without changing season availability or navigation.

## Subtitle delay

The delay value is passed through `UniversalVideoSurface` → `PlaybackKitKSPlayerHost` → `KSPlayerVideoSurface` and applied only in the existing subtitle rendering bridge. Positive values display subtitles later; negative values display them earlier. Playback URL, decoder, video clock, and audio clock are not modified.

## Protected systems

Phase 6 failover, Source Intelligence ranking implementation, Alternate Audio clients, trailers, Live TV, episode alerts, Production & Ratings metadata, and Stable Protection remain unchanged.

## Validation performed

- All Swift files parsed successfully.
- Per-title memory and resume cache sources passed standalone Swift type-checking.
- Runtime memory test passed show-level language suggestion, exact-episode subtitle delay, exact-episode source memory, and remembered-source prioritization.
- Runtime freeze test completed 240 resume updates through the main-call path in under 0.5 seconds while file encoding/writing remained utility-queue work.
- Phase 7 source contract passed 18/18 checks.
- Both plists and project versions validated at 1.0.647 / 647.
- Complete baseline hash comparison and clean archive extraction verification are included.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV testing is required before Phase 8.
