# v1165 Deep Audit — Live TV Quick Guide Type-Check Correction

## Base and scope

- Base: packaged v1164 only.
- Marketing version: 1.0.693.
- Build: 693.
- Backend: v674 unchanged.
- Purpose: compile-only correction for the GitHub Actions failure in v1164.

## GitHub Actions failure

The supplied v1164 build log contained one build-stopping Swift error:

- `DebridChannelsTVOSApp.swift:19300:9`
- `the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

The failing expression was `liveQuickGuideCategoryStrip`, added as part of the v1162 Live TV Quick Guide category/typography work and carried unchanged through v1164. The expression combined a large `HStack`, `ForEach`, nested conditional font sizes/weights, conditional colors, padding, background and overlay shapes in a single generic SwiftUI tree.

No app-icon, PlaybackKit, trailer, resume, Sports, VOD theme, Source Intelligence, or asset-catalog compiler error was present in the supplied log.

## Correction

v1165 preserves the exact visual constants and behavior but decomposes the expression:

- Adds nested typed `LiveQuickGuideCategoryChip: View`.
- Moves the selected/unselected chip typography, padding, fill and stroke values into small computed properties.
- Precomputes the category strip's compact/non-compact spacing and font sizes before constructing the `HStack`.
- Keeps the same category window, selection logic, channel count, `UP / DOWN CATEGORY` label, colors, Avenir typography, capsule geometry and compact/full Quick Guide dimensions.

This is a compiler-complexity correction only; it does not change Quick Guide navigation or presentation design.

## Preservation

Compared with v1164, the only inherited files changed are:

1. `Sources/DebridChannelsTVOSApp.swift` — type-check decomposition only.
2. `Sources/Info.plist` — version/build only.
3. `TopShelfExtension/Info.plist` — version/build only.
4. `project.yml` — version/build only.

All other Swift files are byte-for-byte identical to v1164. The v1164 landscape tvOS launcher icon assets are byte-for-byte unchanged.

Therefore v1165 preserves the v1164/v1162 work including:

- trailer audio stabilization/finalized local remux-cache staging;
- Live TV Quick Guide categories including My Favorites and provider categories;
- full-bleed Gracenote Quick Guide imagery;
- Quick Guide channel/program typography;
- playback resume/autostart and source-independent Find Links resume;
- automatic LEFT/RIGHT scrub seeking;
- Sports direct-live routing and Sports navigation cleanup;
- VOD overlay theme system and Original overlay preservation;
- dynamic Live TV wallpaper/performance modes;
- Source Intelligence, failover, per-title memory and PlaybackKit behavior;
- v1164 landscape app-icon presentation.

## Local validation

- 54/54 Swift files passed `swiftc -frontend -parse`.
- Source diff against v1164 was inspected and limited to the Quick Guide type-check decomposition.
- Both plists parse successfully.
- `project.yml`, app plist and Top Shelf plist all report 1.0.693 / 693.
- All non-main Swift files hash-identical to v1164.
- App icon asset files hash-identical to v1164.

GitHub Actions/Xcode remains authoritative for full SwiftUI type checking and tvOS compilation.
