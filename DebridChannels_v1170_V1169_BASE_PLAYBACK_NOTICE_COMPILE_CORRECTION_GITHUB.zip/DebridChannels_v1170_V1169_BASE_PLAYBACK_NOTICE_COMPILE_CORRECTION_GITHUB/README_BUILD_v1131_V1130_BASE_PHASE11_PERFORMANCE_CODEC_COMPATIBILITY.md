# Debrid Channels v1131 — Phase 11 Performance & Codec Compatibility

**Base:** packaged v1130 only  
**Marketing version:** 1.0.659  
**Build:** 659  
**Backend pairing:** v673  

## Purpose
This is the Phase 11 candidate. It introduces a narrow codec/container compatibility policy while preserving the existing KSPlayer + Tapframe KSPNUVIO playback architecture and forced hardware decoding. It does not globally change the path used by normal H.264/HEVC titles.

## App-side compatibility policy
- Normal H.264 and ordinary HEVC/Main10/HDR retain the existing v993 smooth decoded-frame path.
- Dolby Vision Profile 7 or 12-bit HEVC hints select the asynchronous VideoToolbox compatibility lane.
- MPEG-2/interlaced-risk VOD enables KSPlayer auto-deinterlace.
- WebM, MPEG-TS, AVI, AV1, VP9, VC-1 and legacy codec/container hints receive a larger bounded probe/analyze window.
- Existing Source Intelligence metadata is reused; no new network call occurs in the render/startup path.
- Playback Health gains a Phase 11 compatibility note.

## Preservation
Smart Info remains overlay-gated and playback-isolated. Phase 10 security, Alternate Audio lifecycle, automatic source failover, per-title playback memory, resume/history, trailers, Live TV, CatalogStore, artwork, and episode alerts remain preserved. Navigation Sounds remain removed.

## Release gate
Local source/tests are validation only. GitHub Actions is the authoritative Xcode/tvOS compilation test. Physical Apple TV codec behavior is not claimed until tested. Keep v1130 + backend v672 as rollback until v1131 + v673 pass.
