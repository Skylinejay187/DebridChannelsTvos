# Deep Audit — v1155 Wallpaper Themes / Performance Modes

## Why this pass
v1152 solved Live TV grid slowdown by replacing four large blurred SwiftUI ellipses with one asynchronous Canvas at 8 fps and pausing wallpaper redraw during rapid D-pad travel. v1155 preserves that behavior as Compatibility mode and expands the engine without returning to expensive live blur stacks.

## Wallpaper render ownership
`LiveTVScreen.liveWallpaperOwnsRenderBudget` is the hard gate. Dynamic wallpaper is mounted only when all conditions are true:
- Dynamic Live Wallpaper is enabled.
- selectedTab is Live TV.
- no playback URL is active.
- no media detail is mounted.
- Search is closed.
- Live TV quick panel is closed.
- Full Guide is closed.
- channel action panel is closed.

Because the Timeline/Canvas is removed rather than merely hidden, Home, Movies, Shows, Sports, Favorites, Settings, Search, guide/detail/quick-panel states and video playback perform zero wallpaper animation work.

## Navigation priority
D-pad/channel movement pauses wallpaper Timeline redraws immediately. Resume delay is profile-controlled:
- Compatibility: 360 ms
- Balanced: 280 ms
- High Performance: 160 ms

## Performance modes
Compatibility is the default and preserves the known v1152 8 fps behavior. Balanced uses 15 fps. High Performance uses 30 fps and adds additional Canvas detail. All modes continue to freeze wallpaper during active navigation and fully suspend it outside the uncovered Live TV grid or during playback.

## Theme families
20 presets share the same asynchronous Canvas renderer:
Spotlight Smoke; Cinematic Smoke; Cinema Projector; Midnight Projector; Golden Premiere; Theater Haze; Live TV Broadcast; Broadcast Signal; Newsroom Pulse; Sports Arena; Studio Backlights; Retro TV Glow; Neon Cinema; Starfield Cinema; Film Noir Smoke; Blue Nebula; Purple Haze; Emerald Mist; Ember Smoke; Aurora Fog.

Theme-specific geometry uses radial smoke gradients, spotlight/projector polygons, broadcast bands, signal curves, studio panels, arena horizon light, neon sweeps, deterministic dust and star particles. There are no animated SwiftUI `.blur()` stacks in the wallpaper renderer.

## Playback isolation
The wallpaper renderer checks `store.playbackURL == nil`, and the app already replaces the heavy browser tree with the playback presentation when playback begins. v1155 additionally cancels pending wallpaper resume tasks when playback becomes active. Hardware video decode and player engine settings are not controlled by Visual Performance mode.

## Protected behavior
Exact function preservation versus packaged v1154:
- applyAutomaticResumeIfAvailable
- scheduleAutomaticResumeAfterSurfaceStart
- saveResumePositionIfNeeded
- switchToKSPlayerEngine
- seekAbsolute
- scrubTimelineAndSeek
- commitTimelineScrubIfNeeded
- startPlayerClock
- sourceSelectedPlaybackItem

Byte-identical protected files versus v1154 include CatalogStore.swift, PlaybackResumeCache.swift, AutomaticSourceFailoverManager.swift, PerTitlePlaybackMemory.swift, UniversalCodecSupport.swift, PlaybackKitFoundation.swift, PlaybackKitKSPlayerSurface.swift, Phase15FinalIntegration.swift, SportsCenterViewModel.swift, and TrailerServiceManager.swift.
