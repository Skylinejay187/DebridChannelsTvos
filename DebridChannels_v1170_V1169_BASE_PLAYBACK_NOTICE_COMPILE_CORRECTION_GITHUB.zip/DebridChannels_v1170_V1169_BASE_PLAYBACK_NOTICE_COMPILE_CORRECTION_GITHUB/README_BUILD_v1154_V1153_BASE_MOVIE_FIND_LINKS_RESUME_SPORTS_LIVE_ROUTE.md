# v1154 — Movie Find Links Resume + Sports Direct Live Route

Build from packaged v1153 only. Backend v674 unchanged.

### Test on physical Apple TV

1. Movie: play to ~25 minutes, exit, open Media Information → Find Links, choose a different/high-quality source. It must resume at the same saved point.
2. Sports: choose an automatically classified M3U sports channel, manually assigned channel, and manually added sports channel. Select and Play/Pause must tune immediately; Media Information / Find Links must not appear.
3. Sports navigation: leave Sports with Back, then select Home; repeat by selecting Home directly from the Sports top menu. No old Sports metadata/detail/focus state should remain.
4. Scrubber: LEFT/RIGHT automatic seeking must behave exactly as v1153.
