# Debrid Channels tvOS v1081

Base: **v1074 only**
Version: **1.0.609**
Build: **609**

## Rollback boundary

This release deliberately returns to v1074 and contains **no Movie Mode code** from v1075-v1080. Movie Mode remains a backlog concept only.

## Included changes

### 1. Full-width catalog rows

- Removes the fixed twelve-poster display cap from the active catalog rail.
- Calculates enough progressively smaller portrait cards to fill the complete tvOS viewport.
- Keeps a two-card render buffer for smooth rightward focus movement.
- Does not mount an entire 100+ item row at once; every item remains reachable as focus advances.
- Catalog loading, paging, previews, media information, search, and focus logic remain the v1074 production behavior.

### 2. Built-in trailer loading and complete audio

The external YouTube application chip remains removed. The built-in Trailer button may still use YouTube invisibly through the backend resolver.

- Tries the durable audio-complete backend remux contract first.
- Falls back to the proven compatible resolver contract when the deployed backend does not recognize the new remux flags.
- Both resolver paths must still produce a self-contained media URL; split video/audio responses remain in the backend remux lane.
- Downloads the complete trailer into the app cache before KSPlayer opens it.
- Rejects playlists and undersized/incomplete downloads.
- Requires real video and audio tracks.
- Verifies audio covers at least 98% of the video and ends no more than the small MP4 edit-list tolerance before atomically publishing the local file.
- Uses a new v1081 trailer cache namespace so failed or incomplete older entries are not reused.
- Keeps the v1074 focused-preview audio isolation so preview teardown cannot interrupt trailer sound.

The included backend helper now contains executable FFmpeg/ffprobe finalization utilities for both split and progressive inputs. It pads/normalizes audio to video duration, verifies the closed output, and atomically renames the completed MP4.

### 3. Source link confirmation

- Keeps the compact transparent source-information confirmation card.
- Shows one action chip only: **Play Source**.
- Removes the Return/Cancel chip.
- Pressing Back cancels and returns focus to the exact selected Source Intelligence link.
- Provider mixing, Top Recommended Link, ranking, paging, selection, and playback handoff are unchanged.

## Preserved from v1074

- Normal Debrid Channels home/catalog interface.
- Media-information popup, advisory, Featured Cast, connector behavior, and Source Intelligence.
- Multi-provider Real-Debrid/TorBox mixing inherited by the v1074 lineage.
- VOD, Live TV, search, favorites, episode alerts, trailers, and Top Shelf.
- KSPlayer remains the internal playback engine.

## Validation boundary

- All Swift sources pass syntax parsing.
- App and Top Shelf plists parse and match 1.0.609 (609).
- `project.yml` parses and matches the same version/build.
- Backend helper passes Python compilation and synthetic FFmpeg tests that reproduce a five-second video with two-second audio and verify the finalized output has full-duration audio.
- GitHub Actions/Xcode remains the authoritative tvOS compilation gate.
- Physical Apple TV testing remains required against the deployed trailer backend.
