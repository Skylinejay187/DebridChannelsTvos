# Debrid Channels tvOS/iOS — v1142 Phase 15 Compile Correction

- Candidate: v1142
- Marketing version: 1.0.670
- Build: 670
- Base: packaged v1141 only
- Backend: v674 unchanged
- Scope: compile-only correction for the v1141 Phase 15 physical-test candidate

## GitHub Actions failure diagnosed

The uploaded GitHub log reached the real Xcode Swift compile step and failed in exactly one app source location:

`Sources/Phase15FinalIntegration.swift:505`

Xcode reported:

`the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

The failing expression was the compact `Phase15SourceBadge` SwiftUI body. It combined a file-private `String.ifEmpty` helper reference, ternary `Color` expressions, `foregroundStyle`, capsule fill, and capsule stroke in one generic SwiftUI chain.

## v1142 correction

The source-picker badge is now deliberately split into small typed subexpressions:

- `displayText: String` performs the empty-string fallback locally.
- `labelColor: Color` resolves the foreground color.
- `borderColor: Color` resolves the outline color.
- The view body uses `foregroundColor(labelColor)` plus separately typed fill/stroke expressions.
- The inaccessible cross-file `text.ifEmpty(...)` dependency is removed from this view.

This is a compile correction only. The v1141 Phase 15 behavior remains intact: Cast Explorer focus correction, upward profile navigation, scrubber ownership, live KSPNUVIO gain, complete episode loading, isolated Source Intelligence selection, and real-clock automatic resume correction are not redesigned in this candidate.

## Preservation / diff discipline

Only four inherited source/config files differ from packaged v1141:

- `Sources/Phase15FinalIntegration.swift` — compiler correction only.
- `Sources/Info.plist` — version bump to 1.0.670 / 670.
- `TopShelfExtension/Info.plist` — matching version bump.
- `project.yml` — matching XcodeGen version bump.

Key Phase 15 / playback files including `CatalogStore.swift`, `DebridChannelsTVOSApp.swift`, `PlaybackKitKSPlayerSurface.swift`, `PerTitlePlaybackMemory.swift`, and `AutomaticSourceFailoverManager.swift` remain byte-identical to v1141. Backend v674 is unchanged.

## Local validation

- 53/53 app + Top Shelf Swift files pass Swift parser validation.
- App and Top Shelf plists parse and report 1.0.670 / 670.
- `project.yml` parses with MARKETING_VERSION 1.0.670 and CURRENT_PROJECT_VERSION 670.
- Static compile-hotspot contracts pass.

GitHub Actions/Xcode remains the authoritative SwiftUI type-check and tvOS compile test.
