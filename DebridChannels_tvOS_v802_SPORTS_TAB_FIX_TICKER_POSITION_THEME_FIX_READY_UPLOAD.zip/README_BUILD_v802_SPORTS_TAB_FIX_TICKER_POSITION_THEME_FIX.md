# Debrid Channels tvOS v802 - Sports tab + ticker theme/position fix

- Restored Sports top-menu routing by keeping Sports selectable/hit-testable in the global top menu while preserving Home/Movies/Shows quick-panel focus ownership.
- Sports selection now clears stale live quick-panel/menu focus state and nudges content focus so the active Sports quick-panel surface opens.
- Moved the Movies/Shows release ticker to the physical left edge and the lowest available bottom safe lane; it hides when that lane is not available.
- Reused `NewEpisodeAlertTheme` for Movies/Shows ticker visuals so it matches the existing episode alert banner theme system.
- Kept ticker visibility gated behind the existing no-panel/no-detail/no-search/no-playback checks, including Sports panel ownership.
