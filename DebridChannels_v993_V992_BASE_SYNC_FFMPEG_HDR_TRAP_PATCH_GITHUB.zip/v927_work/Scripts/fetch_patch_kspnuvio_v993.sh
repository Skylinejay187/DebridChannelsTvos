#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REVISION="69a73e5e22184c6db254eb2919f81768afb57a81"
ARCHIVE_URL="https://codeload.github.com/tapframe/KSPNUVIO/zip/${REVISION}"
CACHE_DIR="${ROOT_DIR}/.build-cache/kspnuvio-v993"
ARCHIVE_PATH="${CACHE_DIR}/KSPNUVIO-${REVISION}.zip"
EXTRACT_DIR="${CACHE_DIR}/extract"
VENDOR_DIR="${ROOT_DIR}/Vendor/KSPNUVIO"
PATCH_MARKER="${VENDOR_DIR}/.debridchannels-v993-ffmpegdecode-patched"
EXPECTED_FFMPEGDECODE_BLOB="77f39b6f47db61c1fa2bb9715348442e5d64d1ba"
EXPECTED_PACKAGE_BLOB="5b7b515e1209e0965dd2a79dde5a189c1550e9b5"

if [[ -f "${PATCH_MARKER}" ]] && grep -q "${REVISION}" "${PATCH_MARKER}"; then
  echo "KSPNUVIO v993 decoder patch already present."
  exit 0
fi

rm -rf "${EXTRACT_DIR}"
mkdir -p "${CACHE_DIR}" "${EXTRACT_DIR}"

echo "============================================================"
echo "DEBRID CHANNELS V993 FETCHING PINNED KSPNUVIO DECODER SOURCE"
echo "revision=${REVISION}"
echo "============================================================"

curl -fL --retry 5 --retry-delay 4 --connect-timeout 30 \
  -o "${ARCHIVE_PATH}" "${ARCHIVE_URL}"
unzip -q "${ARCHIVE_PATH}" -d "${EXTRACT_DIR}"

SOURCE_DIR="$(find "${EXTRACT_DIR}" -mindepth 1 -maxdepth 1 -type d -name 'KSPNUVIO-*' | head -n 1)"
if [[ -z "${SOURCE_DIR}" || ! -f "${SOURCE_DIR}/Package.swift" ]]; then
  echo "ERROR: Could not locate extracted KSPNUVIO package."
  exit 1
fi

FFMPEG_FILE="${SOURCE_DIR}/Sources/KSPlayer/MEPlayer/FFmpegDecode.swift"
if [[ ! -f "${FFMPEG_FILE}" ]]; then
  echo "ERROR: Pinned FFmpegDecode.swift is missing."
  exit 1
fi

if command -v git >/dev/null 2>&1; then
  ACTUAL_DECODER_BLOB="$(git hash-object "${FFMPEG_FILE}")"
  ACTUAL_PACKAGE_BLOB="$(git hash-object "${SOURCE_DIR}/Package.swift")"
  if [[ "${ACTUAL_DECODER_BLOB}" != "${EXPECTED_FFMPEGDECODE_BLOB}" ]]; then
    echo "ERROR: FFmpegDecode.swift does not match audited pinned source."
    echo "expected=${EXPECTED_FFMPEGDECODE_BLOB} actual=${ACTUAL_DECODER_BLOB}"
    exit 1
  fi
  if [[ "${ACTUAL_PACKAGE_BLOB}" != "${EXPECTED_PACKAGE_BLOB}" ]]; then
    echo "ERROR: Package.swift does not match audited pinned source."
    echo "expected=${EXPECTED_PACKAGE_BLOB} actual=${ACTUAL_PACKAGE_BLOB}"
    exit 1
  fi
fi

python3 - "${FFMPEG_FILE}" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()
original = text

replacements = [
    (
        'closedCaptionsPacket.corePacket?.pointee.size = Int32(sideData.size)',
        'closedCaptionsPacket.corePacket?.pointee.size = Int32(clamping: sideData.size)'
    ),
    (
'''                            } else if sideData.type == AV_FRAME_DATA_SEI_UNREGISTERED {
                                let size = sideData.size
                                if size > AV_UUID_LEN {
                                    let str = String(cString: sideData.data.advanced(by: Int(AV_UUID_LEN)))
                                    options.sei(string: str)
                                }
''',
'''                            } else if sideData.type == AV_FRAME_DATA_SEI_UNREGISTERED {
                                // The SEI payload is length-delimited and is not guaranteed to end in a
                                // NUL byte. Bound the read to sideData.size instead of String(cString:),
                                // which can walk beyond the payload on malformed or unusual HEVC streams.
                                let size = Int(clamping: sideData.size)
                                let uuidLength = Int(AV_UUID_LEN)
                                if size > uuidLength {
                                    let payload = UnsafeBufferPointer(
                                        start: sideData.data.advanced(by: uuidLength),
                                        count: size - uuidLength
                                    )
                                    let string = String(decoding: payload.prefix { $0 != 0 }, as: UTF8.self)
                                    if !string.isEmpty {
                                        options.sei(string: string)
                                    }
                                }
'''
    ),
    (
'''                            } else if sideData.type == AV_FRAME_DATA_DOVI_RPU_BUFFER {
                                let data = sideData.data.withMemoryRebound(to: [UInt8].self, capacity: 1) { $0 }
                            } else if sideData.type == AV_FRAME_DATA_DOVI_METADATA { // AVDOVIMetadata
                                let data = sideData.data.withMemoryRebound(to: AVDOVIMetadata.self, capacity: 1) { $0 }
                                let header = av_dovi_get_header(data)
                                let mapping = av_dovi_get_mapping(data)
                                let color = av_dovi_get_color(data)
//                                frame.corePixelBuffer?.transferFunction = kCVImageBufferTransferFunction_ITU_R_2020
                            } else if sideData.type == AV_FRAME_DATA_DYNAMIC_HDR_PLUS { // AVDynamicHDRPlus
                                let data = sideData.data.withMemoryRebound(to: AVDynamicHDRPlus.self, capacity: 1) { $0 }.pointee
                            } else if sideData.type == AV_FRAME_DATA_DYNAMIC_HDR_VIVID { // AVDynamicHDRVivid
                                let data = sideData.data.withMemoryRebound(to: AVDynamicHDRVivid.self, capacity: 1) { $0 }.pointee
''',
'''                            } else if sideData.type == AV_FRAME_DATA_DOVI_RPU_BUFFER {
                                // Metadata is propagated by VideoToolbox/format descriptions elsewhere.
                                // Do not reinterpret an unvalidated side-data buffer when no value is used.
                            } else if sideData.type == AV_FRAME_DATA_DOVI_METADATA {
                                // Intentionally ignored here; the previous code dereferenced the payload
                                // only to discard every result.
                            } else if sideData.type == AV_FRAME_DATA_DYNAMIC_HDR_PLUS {
                                // Intentionally ignored here; avoid unvalidated pointer rebinding.
                            } else if sideData.type == AV_FRAME_DATA_DYNAMIC_HDR_VIVID {
                                // Intentionally ignored here; avoid unvalidated pointer rebinding.
'''
    ),
    (
'''                                    display_primaries_r_x: UInt16(data.display_primaries.0.0.num).bigEndian,
                                    display_primaries_r_y: UInt16(data.display_primaries.0.1.num).bigEndian,
                                    display_primaries_g_x: UInt16(data.display_primaries.1.0.num).bigEndian,
                                    display_primaries_g_y: UInt16(data.display_primaries.1.1.num).bigEndian,
                                    display_primaries_b_x: UInt16(data.display_primaries.2.1.num).bigEndian,
                                    display_primaries_b_y: UInt16(data.display_primaries.2.1.num).bigEndian,
                                    white_point_x: UInt16(data.white_point.0.num).bigEndian,
                                    white_point_y: UInt16(data.white_point.1.num).bigEndian,
                                    minLuminance: UInt32(data.min_luminance.num).bigEndian,
                                    maxLuminance: UInt32(data.max_luminance.num).bigEndian
''',
'''                                    // FFmpeg metadata rationals can legally contain negative or
                                    // oversized numerators. Swift's normal UInt conversions trap on
                                    // those values, which caused the v990 HEVC SIGTRAP. Clamp instead.
                                    display_primaries_r_x: UInt16(clamping: data.display_primaries.0.0.num).bigEndian,
                                    display_primaries_r_y: UInt16(clamping: data.display_primaries.0.1.num).bigEndian,
                                    display_primaries_g_x: UInt16(clamping: data.display_primaries.1.0.num).bigEndian,
                                    display_primaries_g_y: UInt16(clamping: data.display_primaries.1.1.num).bigEndian,
                                    display_primaries_b_x: UInt16(clamping: data.display_primaries.2.0.num).bigEndian,
                                    display_primaries_b_y: UInt16(clamping: data.display_primaries.2.1.num).bigEndian,
                                    white_point_x: UInt16(clamping: data.white_point.0.num).bigEndian,
                                    white_point_y: UInt16(clamping: data.white_point.1.num).bigEndian,
                                    minLuminance: UInt32(clamping: data.min_luminance.num).bigEndian,
                                    maxLuminance: UInt32(clamping: data.max_luminance.num).bigEndian
'''
    ),
    (
'''                                    MaxCLL: UInt16(data.MaxCLL).bigEndian,
                                    MaxFALL: UInt16(data.MaxFALL).bigEndian
''',
'''                                    MaxCLL: UInt16(clamping: data.MaxCLL).bigEndian,
                                    MaxFALL: UInt16(clamping: data.MaxFALL).bigEndian
'''
    ),
    (
'''                                    ambient_illuminance: UInt32(data.ambient_illuminance.num).bigEndian,
                                    ambient_light_x: UInt16(data.ambient_light_x.num).bigEndian,
                                    ambient_light_y: UInt16(data.ambient_light_y.num).bigEndian
''',
'''                                    ambient_illuminance: UInt32(clamping: data.ambient_illuminance.num).bigEndian,
                                    ambient_light_x: UInt16(clamping: data.ambient_light_x.num).bigEndian,
                                    ambient_light_y: UInt16(clamping: data.ambient_light_y.num).bigEndian
'''
    ),
]

for old, new in replacements:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"Expected exactly one decoder patch match, found {count}: {old[:80]!r}")
    text = text.replace(old, new, 1)

if text == original:
    raise SystemExit("Decoder patch made no changes")

path.write_text(text)
PY

mkdir -p "$(dirname "${VENDOR_DIR}")"
rm -rf "${VENDOR_DIR}"
mv "${SOURCE_DIR}" "${VENDOR_DIR}"
printf 'revision=%s\npatch=v993-safe-ffmpeg-hdr-side-data\n' "${REVISION}" > "${PATCH_MARKER}"

echo "Patched local KSPNUVIO ready at ${VENDOR_DIR}"
grep -n "UInt16(clamping\|String(decoding\|Int32(clamping" \
  "${VENDOR_DIR}/Sources/KSPlayer/MEPlayer/FFmpegDecode.swift" | head -40
