import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// vBRDC051: TorBox-native Usenet discovery + playback support.
///
/// This intentionally does not gate on a TorBox plan name. If the saved TorBox API key can
/// use Voyager Usenet search and the Main API Usenet endpoints, Source Intelligence uses it.
/// Unsupported accounts simply return a capability/API error while the rest of the source
/// fan-out continues normally.
struct TorBoxUsenetSearchResult: Hashable {
    var hash: String
    var rawTitle: String
    var normalizedTitle: String
    var sizeBytes: Int64
    var tracker: String
    var nzbURL: String
    var age: String
    var cached: Bool
    var owned: Bool
}

enum TorBoxUsenetError: LocalizedError {
    case missingAPIKey
    case unsupportedIdentity
    case http(Int, String)
    case invalidResponse(String)
    case unavailable(String)
    case timedOut(String)

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "TorBox API key is missing."
        case .unsupportedIdentity:
            return "This title does not have an IMDb/TMDB/TVDB identity for TorBox Usenet search."
        case let .http(code, detail):
            return detail.isEmpty ? "TorBox returned HTTP \(code)." : "TorBox returned HTTP \(code): \(detail)"
        case let .invalidResponse(detail):
            return detail.isEmpty ? "TorBox returned an unexpected response." : detail
        case let .unavailable(detail):
            return detail
        case let .timedOut(detail):
            return detail
        }
    }
}

enum TorBoxUsenetClient {
    private static let searchBase = "https://search-api.torbox.app"
    private static let apiBase = "https://api.torbox.app/v1/api/usenet"

    // vBRDC051: Voyager has shipped more than one Usenet result schema in public
    // clients (for example age as either a String or number, and nzb/nzb_link aliases).
    // Keep parsing deliberately tolerant so one field-type change cannot make the entire
    // provider disappear from Source Intelligence.
    static func search(item: MediaItem, apiKey: String, session: URLSession = .shared) async throws -> [TorBoxUsenetSearchResult] {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw TorBoxUsenetError.missingAPIKey }

        var firstError: Error?

        // Primary route: stable media identity. Current TorBox-compatible clients pass
        // `search_user_engines=true`; without it Voyager can omit the user's configured
        // engines and return a much smaller/empty NZB set. Explicitly keep cached_only
        // false because Debrid Channels wants both cached and uncached Usenet releases.
        if let identity = searchIdentity(for: item) {
            do {
                let results = try await searchByID(
                    identityType: identity.type,
                    identityID: identity.id,
                    item: item,
                    apiKey: key,
                    session: session
                )
                if !results.isEmpty { return deduplicated(results) }
            } catch {
                firstError = error
            }
        }

        // vBRDC051 fallback: TorBox also exposes /usenet/search/{query}. This catches
        // incomplete/stale IMDb↔TVDB metadata mappings and titles where the ID endpoint
        // legitimately has no NZBs even though Voyager full-text search does.
        let query = fullTextSearchQuery(for: item)
        if !query.isEmpty {
            do {
                let results = try await searchByQuery(query, item: item, apiKey: key, session: session)
                if !results.isEmpty { return deduplicated(results) }
                // A successful full-text request with zero results is a real zero-result
                // outcome, even if the optional ID pass failed before it.
                return []
            } catch {
                if let firstError {
                    let first = firstError.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    let second = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    let firstMessage = first.isEmpty ? "unknown error" : first
                    let secondMessage = second.isEmpty ? "unknown error" : second
                    throw TorBoxUsenetError.unavailable(
                        "TorBox Voyager Usenet search failed (ID: \(firstMessage); query: \(secondMessage))."
                    )
                }
                throw error
            }
        }

        if let firstError { throw firstError }
        throw TorBoxUsenetError.unsupportedIdentity
    }

    private static func searchByID(
        identityType: String,
        identityID: String,
        item: MediaItem,
        apiKey: String,
        session: URLSession
    ) async throws -> [TorBoxUsenetSearchResult] {
        var components = URLComponents(string: "\(searchBase)/usenet/\(identityType):\(identityID)")!
        components.queryItems = commonSearchQueryItems(for: item)
        guard let url = components.url else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet ID search URL.")
        }
        return try await performSearch(url: url, apiKey: apiKey, session: session)
    }

    private static func searchByQuery(
        _ query: String,
        item: MediaItem,
        apiKey: String,
        session: URLSession
    ) async throws -> [TorBoxUsenetSearchResult] {
        let disallowed = CharacterSet(charactersIn: "/?#")
        let allowed = CharacterSet.urlPathAllowed.subtracting(disallowed)
        guard let encoded = query.addingPercentEncoding(withAllowedCharacters: allowed), !encoded.isEmpty,
              var components = URLComponents(string: "\(searchBase)/usenet/search/\(encoded)") else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet query search URL.")
        }
        components.queryItems = commonSearchQueryItems(for: item)
        guard let url = components.url else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet query search URL.")
        }
        return try await performSearch(url: url, apiKey: apiKey, session: session)
    }

    private static func commonSearchQueryItems(for item: MediaItem) -> [URLQueryItem] {
        var items = [
            URLQueryItem(name: "metadata", value: "false"),
            URLQueryItem(name: "check_cache", value: "true"),
            URLQueryItem(name: "check_owned", value: "true"),
            URLQueryItem(name: "search_user_engines", value: "true"),
            URLQueryItem(name: "cached_only", value: "false")
        ]
        if let season = item.seasonNumber, season >= 0 {
            items.append(URLQueryItem(name: "season", value: String(season)))
        }
        if let episode = item.episodeNumber, episode > 0 {
            items.append(URLQueryItem(name: "episode", value: String(episode)))
        }
        return items
    }

    private static func performSearch(url: URL, apiKey: String, session: URLSession) async throws -> [TorBoxUsenetSearchResult] {
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/vBRDC054 TorBoxUsenet", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        return try parseSearchResponse(data)
    }

    private static func parseSearchResponse(_ data: Data) throws -> [TorBoxUsenetSearchResult] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an unreadable Usenet response.")
        }
        if let success = bool(root["success"]), !success {
            let detail = string(root["detail"] ?? root["error"]) ?? "TorBox Usenet search is unavailable for this account."
            throw TorBoxUsenetError.unavailable(detail)
        }

        // TorBox's envelope is normally { success, data: { nzbs: [...] } }, while
        // some public SDK/test fixtures expose the search payload directly. Accept both.
        let payload = root["data"] ?? root
        let objects: [[String: Any]]
        if let dictionary = payload as? [String: Any] {
            if let list = dictionary["nzbs"] as? [[String: Any]] {
                objects = list
            } else if let list = dictionary["results"] as? [[String: Any]] {
                objects = list
            } else if dictionary["raw_title"] != nil || dictionary["title"] != nil || dictionary["name"] != nil {
                objects = [dictionary]
            } else {
                objects = []
            }
        } else if let list = payload as? [[String: Any]] {
            objects = list
        } else {
            objects = []
        }

        return objects.compactMap { entry in
            let rawTitle = string(entry["raw_title"] ?? entry["title"] ?? entry["name"]) ?? ""
            let normalizedTitle = string(entry["title"] ?? entry["name"] ?? entry["raw_title"]) ?? rawTitle
            let hash = string(entry["hash"]) ?? ""
            let nzbURL = string(entry["nzb"] ?? entry["nzb_link"] ?? entry["download_link"] ?? entry["link"]) ?? ""
            guard !rawTitle.isEmpty, !hash.isEmpty || !nzbURL.isEmpty else { return nil }

            var tracker = string(entry["tracker"] ?? entry["source"]) ?? ""
            if tracker.isEmpty, let indexer = entry["indexer"] as? [String: Any] {
                tracker = string(indexer["name"] ?? indexer["title"]) ?? ""
            }

            return TorBoxUsenetSearchResult(
                hash: hash,
                rawTitle: rawTitle,
                normalizedTitle: normalizedTitle,
                sizeBytes: max(0, integer64(entry["size"] ?? entry["bytes"]) ?? 0),
                tracker: tracker,
                nzbURL: nzbURL,
                age: string(entry["age"]) ?? "",
                cached: bool(entry["cached"] ?? entry["is_cached"]) ?? false,
                owned: bool(entry["owned"] ?? entry["is_owned"]) ?? false
            )
        }
    }

    private static func deduplicated(_ results: [TorBoxUsenetSearchResult]) -> [TorBoxUsenetSearchResult] {
        var seen = Set<String>()
        return results.filter { result in
            let key: String
            if !result.hash.isEmpty { key = "hash:\(result.hash.lowercased())" }
            else if !result.nzbURL.isEmpty { key = "nzb:\(result.nzbURL.lowercased())" }
            else { key = "title:\(result.normalizedTitle.lowercased())" }
            return seen.insert(key).inserted
        }
    }

    private static func fullTextSearchQuery(for item: MediaItem) -> String {
        var parts = [item.title.trimmingCharacters(in: .whitespacesAndNewlines)].filter { !$0.isEmpty }
        if let season = item.seasonNumber, season >= 0 {
            if let episode = item.episodeNumber, episode > 0 {
                parts.append(String(format: "S%02dE%02d", season, episode))
            } else {
                parts.append(String(format: "S%02d", season))
            }
        } else {
            let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
            if !year.isEmpty { parts.append(year) }
        }
        return parts.joined(separator: " ")
    }

    static func resolve(_ result: TorBoxUsenetSearchResult, apiKey: String, session: URLSession = .shared) async throws -> URL {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw TorBoxUsenetError.missingAPIKey }

        // If Voyager says the item is already owned, reuse the existing TorBox job rather
        // than creating a duplicate. It may still be downloading/unpacking, so wait on that
        // job instead of falling through to a second create request.
        if result.owned, !result.hash.isEmpty,
           let existing = try? await existingDownload(hash: result.hash, apiKey: key, session: session) {
            if let playable = try await playableURLIfReady(download: existing, apiKey: key, session: session) {
                return playable
            }
            if let existingID = integer(existing["id"]), existingID > 0 {
                return try await waitForPlayableDownload(
                    id: existingID,
                    timeout: result.cached ? 120 : 600,
                    apiKey: key,
                    session: session
                )
            }
        }

        guard !result.nzbURL.isEmpty else {
            throw TorBoxUsenetError.unavailable("TorBox found this Usenet release but did not expose an NZB handoff URL.")
        }

        let downloadID = try await createDownload(result: result, apiKey: key, session: session)
        return try await waitForPlayableDownload(
            id: downloadID,
            timeout: result.cached ? 120 : 600,
            apiKey: key,
            session: session
        )
    }

    static func qualityLabel(for title: String) -> String {
        let h = title.lowercased()
        var parts: [String] = []
        if h.contains("2160") || h.contains("4k") { parts.append("4K") }
        else if h.contains("1440") { parts.append("1440p") }
        else if h.contains("1080") { parts.append("1080p") }
        else if h.contains("720") { parts.append("720p") }
        else { parts.append("Usenet") }
        if h.contains("remux") { parts.append("REMUX") }
        else if h.contains("web-dl") || h.contains("webdl") { parts.append("WEB-DL") }
        else if h.contains("bluray") || h.contains("blu-ray") { parts.append("BluRay") }
        if h.contains("dolby vision") || h.contains("dovi") || h.contains(".dv.") { parts.append("DV") }
        if h.contains("hdr10+") || h.contains("hdr10plus") { parts.append("HDR10+") }
        else if h.contains("hdr") { parts.append("HDR") }
        return parts.joined(separator: " • ")
    }

    static func sizeLabel(bytes: Int64) -> String {
        guard bytes > 0 else { return "" }
        let gb = Double(bytes) / 1_073_741_824.0
        if gb >= 1 { return String(format: "%.2f GB", gb) }
        let mb = Double(bytes) / 1_048_576.0
        return String(format: "%.0f MB", mb)
    }

    // MARK: - Main API

    private static func createDownload(result: TorBoxUsenetSearchResult, apiKey: String, session: URLSession) async throws -> Int {
        guard let url = URL(string: "\(apiBase)/createusenetdownload") else {
            throw TorBoxUsenetError.invalidResponse("TorBox Usenet create URL is invalid.")
        }

        // TorBox's current client integrations use the URL-encoded `link` form for
        // an already-hosted NZB handoff (multipart is reserved for uploading a local
        // .nzb file). Keep the opaque Voyager URL inside TorBox's own API boundary.
        var form = URLComponents()
        form.queryItems = [
            URLQueryItem(name: "link", value: result.nzbURL),
            URLQueryItem(name: "name", value: String(result.rawTitle.prefix(190))),
            URLQueryItem(name: "post_processing", value: "-1"),
            URLQueryItem(name: "as_queued", value: "false"),
            URLQueryItem(name: "add_only_if_cached", value: "false")
        ]

        var request = URLRequest(url: url, timeoutInterval: 20)
        request.httpMethod = "POST"
        request.httpBody = form.percentEncodedQuery?.data(using: .utf8)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/vBRDC054 TorBoxUsenet", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox did not return a Usenet download ID.")
        }
        if let success = root["success"] as? Bool, !success {
            throw TorBoxUsenetError.unavailable(string(root["detail"]) ?? "TorBox could not create the Usenet download.")
        }
        guard let payload = root["data"] as? [String: Any],
              let id = integer(payload["usenetdownload_id"] ?? payload["usenet_download_id"] ?? payload["id"]), id > 0 else {
            throw TorBoxUsenetError.invalidResponse("TorBox accepted the NZB but did not return a usable download ID.")
        }
        return id
    }

    private static func existingDownload(hash: String, apiKey: String, session: URLSession) async throws -> [String: Any]? {
        guard let url = URL(string: "\(apiBase)/mylist?limit=1000") else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let items: [[String: Any]]
        if let list = root["data"] as? [[String: Any]] { items = list }
        else if let one = root["data"] as? [String: Any] { items = [one] }
        else { items = [] }
        return items.first { string($0["hash"])?.caseInsensitiveCompare(hash) == .orderedSame }
    }

    private static func getDownload(id: Int, apiKey: String, session: URLSession) async throws -> [String: Any] {
        var components = URLComponents(string: "\(apiBase)/mylist")!
        components.queryItems = [
            URLQueryItem(name: "id", value: String(id)),
            URLQueryItem(name: "bypass_cache", value: "true")
        ]
        guard let url = components.url else { throw TorBoxUsenetError.invalidResponse("TorBox Usenet status URL is invalid.") }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox returned an unreadable Usenet status response.")
        }
        if let object = root["data"] as? [String: Any] { return object }
        if let list = root["data"] as? [[String: Any]], let first = list.first { return first }
        throw TorBoxUsenetError.invalidResponse("TorBox did not return the selected Usenet download.")
    }

    private static func waitForPlayableDownload(id: Int, timeout: TimeInterval, apiKey: String, session: URLSession) async throws -> URL {
        let deadline = Date().addingTimeInterval(timeout)
        var lastState = "preparing"
        while Date() < deadline {
            try Task.checkCancellation()
            let download = try await getDownload(id: id, apiKey: apiKey, session: session)
            lastState = string(download["download_state"]) ?? lastState
            if let playable = try await playableURLIfReady(download: download, apiKey: apiKey, session: session) {
                return playable
            }
            if isFailureState(lastState) {
                throw TorBoxUsenetError.unavailable("TorBox could not prepare this Usenet source (\(lastState)).")
            }
            try await Task.sleep(nanoseconds: 4_000_000_000)
        }
        throw TorBoxUsenetError.timedOut("TorBox is still preparing this Usenet source (\(lastState)). Try it again after the download finishes in TorBox.")
    }

    private static func playableURLIfReady(download: [String: Any], apiKey: String, session: URLSession) async throws -> URL? {
        let finished = bool(download["download_finished"]) ?? false
        let present = bool(download["download_present"]) ?? false
        let cached = bool(download["cached"]) ?? false
        guard (finished && present) || (cached && present) else { return nil }
        guard let usenetID = integer(download["id"]), usenetID > 0 else { return nil }
        guard let file = preferredVideoFile(from: download), let fileID = integer(file["id"]), fileID >= 0 else { return nil }
        return try await requestDownloadURL(usenetID: usenetID, fileID: fileID, apiKey: apiKey, session: session)
    }

    private static func requestDownloadURL(usenetID: Int, fileID: Int, apiKey: String, session: URLSession) async throws -> URL {
        var components = URLComponents(string: "\(apiBase)/requestdl")!
        var queryItems = [
            URLQueryItem(name: "token", value: apiKey),
            URLQueryItem(name: "usenet_id", value: String(usenetID)),
            URLQueryItem(name: "zip_link", value: "false")
        ]
        if fileID != 0 {
            queryItems.append(URLQueryItem(name: "file_id", value: String(fileID)))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw TorBoxUsenetError.invalidResponse("TorBox Usenet playback URL is invalid.") }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox did not return a stream URL.")
        }
        let raw = string(root["data"]) ?? ((root["data"] as? [String: Any]).flatMap { string($0["link"] ?? $0["url"]) })
        guard let raw, let playable = URL(string: raw), ["http", "https"].contains(playable.scheme?.lowercased() ?? "") else {
            throw TorBoxUsenetError.invalidResponse("TorBox prepared the Usenet download but did not return a playable CDN URL.")
        }
        return playable
    }

    private static func preferredVideoFile(from download: [String: Any]) -> [String: Any]? {
        guard let files = download["files"] as? [[String: Any]], !files.isEmpty else { return nil }
        let videoExtensions = ["mkv", "mp4", "m4v", "mov", "m2ts", "ts", "webm", "avi"]
        let archiveExtensions = ["rar", "zip", "7z", "par2", "nzb", "nfo", "sfv"]
        let candidates = files.filter { file in
            let name = (string(file["name"] ?? file["short_name"]) ?? "").lowercased()
            let ext = name.split(separator: ".").last.map(String.init) ?? ""
            let mime = (string(file["mimetype"]) ?? "").lowercased()
            let sample = name.contains("sample") || name.contains("trailer") || name.contains("proof")
            return !sample && (videoExtensions.contains(ext) || mime.hasPrefix("video/"))
        }
        if let best = candidates.max(by: { (integer64($0["size"]) ?? 0) < (integer64($1["size"]) ?? 0) }) { return best }
        return files
            .filter { file in
                let name = (string(file["name"] ?? file["short_name"]) ?? "").lowercased()
                let ext = name.split(separator: ".").last.map(String.init) ?? ""
                return !archiveExtensions.contains(ext)
            }
            .max(by: { (integer64($0["size"]) ?? 0) < (integer64($1["size"]) ?? 0) })
    }

    private static func isFailureState(_ value: String) -> Bool {
        let h = value.lowercased()
        return ["failed", "error", "dead", "missing", "invalid", "cancelled", "canceled", "repair_failed", "unpack_failed"].contains { h.contains($0) }
    }

    private static func searchIdentity(for item: MediaItem) -> (type: String, id: String)? {
        let imdb = (item.imdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if imdb.lowercased().hasPrefix("tt"), imdb.count >= 9 { return ("imdb", imdb) }
        let tmdb = (item.tmdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !tmdb.isEmpty { return ("tmdb", tmdb) }
        let tvdb = (item.tvdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !tvdb.isEmpty { return ("tvdb", tvdb) }
        return nil
    }

    private static func dataWithTransientRetry(request: URLRequest, session: URLSession, maxAttempts: Int = 3) async throws -> (Data, URLResponse) {
        var attempt = 0
        while true {
            do {
                return try await session.data(for: request)
            } catch {
                attempt += 1
                guard attempt < maxAttempts, isTransientNetworkError(error) else {
                    let host = request.url?.host ?? "TorBox endpoint"
                    let detail = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    throw TorBoxUsenetError.unavailable("\(host) connection failed: \(detail.isEmpty ? "Unknown network error" : detail)")
                }
                let delay = UInt64(350_000_000 * attempt)
                try? await Task.sleep(nanoseconds: delay)
            }
        }
    }

    private static func isTransientNetworkError(_ error: Error) -> Bool {
        let code: Int
        if let urlError = error as? URLError {
            code = urlError.errorCode
        } else {
            let ns = error as NSError
            guard ns.domain == NSURLErrorDomain else { return false }
            code = ns.code
        }
        let transientCodes: Set<Int> = [
            URLError.cannotFindHost.rawValue,
            URLError.dnsLookupFailed.rawValue,
            URLError.cannotConnectToHost.rawValue,
            URLError.networkConnectionLost.rawValue,
            URLError.notConnectedToInternet.rawValue,
            URLError.timedOut.rawValue
        ]
        return transientCodes.contains(code)
    }

    private static func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200...299).contains(http.statusCode) else {
            var detail = ""
            if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                detail = string(root["detail"] ?? root["error"]) ?? ""
            }
            throw TorBoxUsenetError.http(http.statusCode, detail)
        }
    }

    private static func string(_ value: Any?) -> String? {
        if let value = value as? String { return value.trimmingCharacters(in: .whitespacesAndNewlines) }
        if let value = value as? NSNumber { return value.stringValue }
        return nil
    }

    private static func integer(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    private static func integer64(_ value: Any?) -> Int64? {
        if let value = value as? Int64 { return value }
        if let value = value as? Int { return Int64(value) }
        if let value = value as? NSNumber { return value.int64Value }
        if let value = value as? String { return Int64(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    private static func bool(_ value: Any?) -> Bool? {
        if let value = value as? Bool { return value }
        if let value = value as? NSNumber { return value.boolValue }
        if let value = value as? String {
            switch value.lowercased() {
            case "true", "1", "yes": return true
            case "false", "0", "no": return false
            default: return nil
            }
        }
        return nil
    }
}
