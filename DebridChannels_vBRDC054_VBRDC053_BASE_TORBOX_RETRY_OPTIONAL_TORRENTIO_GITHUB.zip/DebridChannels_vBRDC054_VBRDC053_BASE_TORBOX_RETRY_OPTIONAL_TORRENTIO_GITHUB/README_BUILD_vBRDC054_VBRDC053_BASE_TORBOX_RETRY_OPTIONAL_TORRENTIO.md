# Debrid Channels vBRDC054

**Release ID:** vBRDC054  
**Marketing version:** 1.0.757  
**Apple build:** 757  
**Base:** packaged vBRDC053 only  
**Backend:** v692 unchanged

## Scope

vBRDC054 is a focused correction for two physical Apple TV findings from vBRDC053:

1. TorBox Connection Status could report one generic red failure when any one of the Main API, Usenet API, or Voyager hostname/request failed, making the real failing TorBox surface impossible to identify. Source Intelligence could therefore show the TorBox Usenet provider while returning no NZB rows without enough device-side diagnosis.
2. Entering a global Real-Debrid or TorBox API key automatically generated/activated managed Torrentio. Torrentio must be an explicit optional addon instead of a side effect of connecting a debrid account.

## TorBox / Usenet correction

The TorBox health check is now split into three independent checks using TorBox's current documented service endpoints:

- Main account API: `api.torbox.app/v1/api/user/me`
- Main Usenet API: `api.torbox.app/v1/api/usenet/mylist`
- Voyager Usenet search: `search-api.torbox.app/usenet/...`

Settings now reports each result independently and summarizes the account as:

- `API + Usenet + Voyager connected`
- `Partially connected (N/3 checks)`
- `TorBox endpoints unreachable`

Failures identify the exact hostname so a physical-device DNS/routing failure is distinguishable from an authentication/API failure.

Both Connection Status and the production `TorBoxUsenetClient` now retry transient DNS/network failures up to three attempts for `cannotFindHost`, DNS lookup failure, connection loss, connection failure, offline state, and timeout. Production Usenet errors also include the endpoint hostname.

The native Voyager discovery behavior from vBRDC051/vBRDC053 is retained:

- metadata-ID search first
- full-text fallback
- `search_user_engines=true`
- `cached_only=false`
- cache and owned checks
- no Pro-only client gate

Native TorBox Usenet remains independent of Torrentio.

## Torrentio is now explicit opt-in

New preference:

`managedTorrentioEnabled = false`

A TorBox or Real-Debrid key alone no longer creates any managed Torrentio manifest. Settings now exposes `Enable Torrentio (optional)`. Torrentio cache/CAM controls are shown only after the user enables it.

The hard gate lives in `ManagedAddonBridge`, not only in the Settings UI, so background/source discovery cannot accidentally regenerate Torrentio while the toggle is off.

Connection Status reports `Optional addon disabled` when managed Torrentio is off rather than presenting it as connected simply because a debrid API key exists.

The preference is included in profile backup/restore and the release-candidate restore allowlist.

Existing manually saved Stremio/Torrentio URLs are not touched and remain credential-isolated Saved JSON addons.

## Preserved behavior

- Managed Debridio remains removed.
- Managed Comet remains removed.
- Saved Stremio addon health checks remain available.
- Main Real-Debrid and TorBox credentials remain the authoritative global credentials.
- Legacy Torrentio override-key migration remains intact for upgrades.
- Backend v692 is unchanged.
- vBRDC049 playback/graphics stability files are byte-for-byte unchanged from packaged vBRDC053.

## Validation

Local validation performed before packaging:

- 28/28 vBRDC054 static contracts pass.
- All production Swift source files parse.
- Focused Global Debrid Bridge / health Swift typecheck passes.
- Focused `TorBoxUsenetClient` Swift typecheck passes with its minimal fixture.
- Runtime optional-Torrentio test passes: API key alone produces zero managed Torrentio manifests; explicit opt-in produces manifests; disabling removes them again.
- App and Top Shelf plists parse and match 1.0.757 / 757 / vBRDC054.
- `project.yml` parses and matches version/build.
- KSP patch scripts remain syntax-valid.
- Playback preservation comparison passes byte-for-byte for the locked vBRDC049 stability files.
- Final package SHA and ZIP integrity are generated after this document.

GitHub Actions/Xcode remains the authoritative Apple-platform compile.
