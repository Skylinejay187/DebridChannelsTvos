from pathlib import Path
import plistlib

ROOT = Path(__file__).resolve().parents[1]

def txt(rel):
    return (ROOT / rel).read_text(errors='replace')

def ok(name, cond):
    if not cond:
        raise AssertionError(name)
    print('PASS', name)

proj = txt('project.yml')
app_swift = txt('Sources/DebridChannelsTVOSApp.swift')
unity = txt('Sources/UnitySurfaceSystem.swift')
app = plistlib.load(open(ROOT / 'Sources/Info.plist', 'rb'))
top = plistlib.load(open(ROOT / 'TopShelfExtension/Info.plist', 'rb'))

# Release identity
ok('release id', app.get('DebridChannelsReleaseID') == 'vBRDC059')
ok('code name', app.get('DebridChannelsCodeName') == 'UNITY')
ok('marketing version', app.get('CFBundleShortVersionString') == '1.0.762')
ok('build number', app.get('CFBundleVersion') == '762')
ok('topshelf parity', top.get('CFBundleShortVersionString') == '1.0.762' and top.get('CFBundleVersion') == '762')
ok('project version parity', proj.count('MARKETING_VERSION: 1.0.762') >= 2 and proj.count('CURRENT_PROJECT_VERSION: 762') >= 2)
ok('Unity source included in project', 'Sources/UnitySurfaceSystem.swift' in proj)

# Unity presentation contract
ok('Unity codename constant', 'static let displayCodeName = "UNITY"' in unity)
ok('Live root role', 'case liveRoot' in unity)
ok('Catalog branch role', 'case catalogBranch' in unity)
ok('Sports branch role', 'case sportsBranch' in unity)
ok('Catalog tabs mapped as one branch', 'case .home, .movies, .shows:' in unity)
ok('Sports mapped as connected branch', 'case .sports:' in unity and 'return .sportsBranch' in unity)
ok('Connected back collapses to Live TV', 'case .catalogBranch, .sportsBranch:' in unity and 'return .live' in unity)

# Root theme continuity: no theme may swap out the Live TV root.
ok('Artwork4 root special case removed', 'artwork4CatalogOverlayActive' not in app_swift)
ok('Catalog branch uses Unity contract', 'let catalogOverlayActive = UnitySurfaceSystem.catalogBranchActive(for: store.selectedTab)' in app_swift)
ok('LiveTV root remains mounted for catalog branch', 'Every Home/Movies/Shows branch keeps the exact same Live TV root mounted' in app_swift)
ok('Theme-neutral catalog root renders LiveTVScreen', 'LiveTVScreen()\n                        .disabled(onboardingActive || catalogOverlayActive' in app_swift)
ok('Explicit Unity dissolve transition', 'Unity branch transition: every catalog theme dissolves over the' in app_swift and '.transition(.opacity)' in app_swift)
ok('Catalog close uses Unity back destination', 'store.selectedTab = UnitySurfaceSystem.backDestination(from: store.selectedTab)' in app_swift)
ok('Quick-panel ownership centralized', app_swift.count('UnitySurfaceSystem.quickPanelBranchActive(for: store.selectedTab)') >= 2)

# All existing Live TV themes remain available; no visual choice removed.
for theme in [
    'Classic Dark', 'Channels Glass', 'Frosted Guide', 'Pure Black', 'Midnight Blue',
    'Neon Edge', 'Carbon OLED', 'Artwork', 'Artwork 2', 'Artwork 3 Hero',
    'Artwork 4 Hero 2', 'Artwork 5 Floating'
]:
    ok(f'theme preserved: {theme}', f'"{theme}"' in app_swift)

# About page explains the system and keeps legal/provider wording.
ok('About shows Code Name', 'Text("Code Name")' in app_swift and 'installedAppCodeName.uppercased()' in app_swift)
ok('About describes single-tree system', 'UNITY is Debrid Channels\' single-tree viewing system' in app_swift)
ok('No hosting disclaimer preserved', 'Debrid Channels does not host, store, upload, redistribute, or provide movies, shows, live TV channels, or other content.' in app_swift)

# Scope guards: vBRDC058 TorBox and playback assets remain present and untouched by architecture additions.
ok('TorBox client still in project', 'Sources/TorBoxUsenetClient.swift' in proj)
ok('KSPlayer patch path unchanged', 'Scripts/fetch_patch_kspnuvio_vBRDC043.sh' in proj)
ok('PlaybackKit still included', 'Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift' in proj)

print('ALL vBRDC059 UNITY CONTRACTS PASS')
