import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Network) && canImport(Security)
import Network
import Security
#endif

/// vBRDC058: TorBox-native Usenet discovery + playback support.
///
/// This intentionally does not gate on a TorBox plan name. The same saved TorBox API key
/// authenticates Voyager discovery and the Main API Usenet endpoints. vBRDC058 keeps the
/// normal URLSession path first, then uses a narrow DNS-over-HTTPS + TLS/SNI fallback only
/// when tvOS cannot resolve search-api.torbox.app through the local resolver.
struct TorBoxUsenetSearchResult: Hashable {
    var hash: String
    var rawTitle: String
    var normalizedTitle: String
    var sizeBytes: Int64
    var tracker: String
    var nzbURL: String
    var age: String
    var cached: Bool
    var owned: Bool
}

enum TorBoxUsenetError: LocalizedError {
    case missingAPIKey
    case unsupportedIdentity
    case http(Int, String)
    case invalidResponse(String)
    case unavailable(String)
    case timedOut(String)

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "TorBox API key is missing."
        case .unsupportedIdentity:
            return "This title does not have an IMDb/TMDB/TVDB identity for TorBox Usenet search."
        case let .http(code, detail):
            return detail.isEmpty ? "TorBox returned HTTP \(code)." : "TorBox returned HTTP \(code): \(detail)"
        case let .invalidResponse(detail):
            return detail.isEmpty ? "TorBox returned an unexpected response." : detail
        case let .unavailable(detail):
            return detail
        case let .timedOut(detail):
            return detail
        }
    }
}

enum TorBoxUsenetClient {
    private static let searchBase = "https://search-api.torbox.app"
    private static let apiBase = "https://api.torbox.app/v1/api/usenet"

    // vBRDC051: Voyager has shipped more than one Usenet result schema in public
    // clients (for example age as either a String or number, and nzb/nzb_link aliases).
    // Keep parsing deliberately tolerant so one field-type change cannot make the entire
    // provider disappear from Source Intelligence.
    static func search(item: MediaItem, apiKey: String, session: URLSession = .shared) async throws -> [TorBoxUsenetSearchResult] {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw TorBoxUsenetError.missingAPIKey }

        var firstError: Error?

        // Primary route: stable media identity. Current TorBox-compatible clients pass
        // `search_user_engines=true`; without it Voyager can omit the user's configured
        // engines and return a much smaller/empty NZB set. Explicitly keep cached_only
        // false because Debrid Channels wants both cached and uncached Usenet releases.
        if let identity = searchIdentity(for: item) {
            do {
                let results = try await searchByID(
                    identityType: identity.type,
                    identityID: identity.id,
                    item: item,
                    apiKey: key,
                    session: session
                )
                if !results.isEmpty { return deduplicated(results) }
            } catch {
                firstError = error
            }
        }

        // vBRDC051 fallback: TorBox also exposes /usenet/search/{query}. This catches
        // incomplete/stale IMDb↔TVDB metadata mappings and titles where the ID endpoint
        // legitimately has no NZBs even though Voyager full-text search does.
        let query = fullTextSearchQuery(for: item)
        if !query.isEmpty {
            do {
                let results = try await searchByQuery(query, item: item, apiKey: key, session: session)
                if !results.isEmpty { return deduplicated(results) }
                // A successful full-text request with zero results is a real zero-result
                // outcome, even if the optional ID pass failed before it.
                return []
            } catch {
                if let firstError {
                    let first = firstError.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    let second = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    let firstMessage = first.isEmpty ? "unknown error" : first
                    let secondMessage = second.isEmpty ? "unknown error" : second
                    throw TorBoxUsenetError.unavailable(
                        "TorBox Voyager Usenet search failed (ID: \(firstMessage); query: \(secondMessage))."
                    )
                }
                throw error
            }
        }

        if let firstError { throw firstError }
        throw TorBoxUsenetError.unsupportedIdentity
    }

    private static func searchByID(
        identityType: String,
        identityID: String,
        item: MediaItem,
        apiKey: String,
        session: URLSession
    ) async throws -> [TorBoxUsenetSearchResult] {
        var components = URLComponents(string: "\(searchBase)/usenet/\(identityType):\(identityID)")!
        components.queryItems = commonSearchQueryItems(for: item)
        guard let url = components.url else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet ID search URL.")
        }
        return try await performSearch(url: url, apiKey: apiKey, session: session)
    }

    private static func searchByQuery(
        _ query: String,
        item: MediaItem,
        apiKey: String,
        session: URLSession
    ) async throws -> [TorBoxUsenetSearchResult] {
        let disallowed = CharacterSet(charactersIn: "/?#")
        let allowed = CharacterSet.urlPathAllowed.subtracting(disallowed)
        guard let encoded = query.addingPercentEncoding(withAllowedCharacters: allowed), !encoded.isEmpty,
              var components = URLComponents(string: "\(searchBase)/usenet/search/\(encoded)") else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet query search URL.")
        }
        components.queryItems = commonSearchQueryItems(for: item)
        guard let url = components.url else {
            throw TorBoxUsenetError.invalidResponse("Could not build the TorBox Usenet query search URL.")
        }
        return try await performSearch(url: url, apiKey: apiKey, session: session)
    }

    private static func commonSearchQueryItems(for item: MediaItem) -> [URLQueryItem] {
        var items = [
            URLQueryItem(name: "metadata", value: "false"),
            URLQueryItem(name: "check_cache", value: "true"),
            URLQueryItem(name: "check_owned", value: "true"),
            URLQueryItem(name: "search_user_engines", value: "true"),
            URLQueryItem(name: "cached_only", value: "false")
        ]
        if let season = item.seasonNumber, season >= 0 {
            items.append(URLQueryItem(name: "season", value: String(season)))
        }
        if let episode = item.episodeNumber, episode > 0 {
            items.append(URLQueryItem(name: "episode", value: String(episode)))
        }
        return items
    }

    private static func performSearch(url: URL, apiKey: String, session: URLSession) async throws -> [TorBoxUsenetSearchResult] {
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        request.setValue("DebridChannels-tvOS/vBRDC058 TorBoxUsenet", forHTTPHeaderField: "User-Agent")

        do {
            let (data, response) = try await searchDataWithTransientRetry(request: request, session: session)
            try validate(response: response, data: data)
            return try parseSearchResponse(data)
        } catch {
            guard isDNSResolutionError(error) else {
                if error is TorBoxUsenetError { throw error }
                let host = request.url?.host ?? "TorBox Search"
                let detail = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                throw TorBoxUsenetError.unavailable("\(host) connection failed: \(detail.isEmpty ? "Unknown network error" : detail)")
            }

            // Some ISP/router DNS filters resolve api.torbox.app but suppress the separate
            // Voyager hostname. Resolve only that TorBox hostname through public DoH and
            // keep HTTPS authentication end-to-end by connecting to the returned IP with
            // TLS SNI still set to search-api.torbox.app. No TorBox token is sent to DoH.
            let fallback = try await voyagerSearchViaDoH(url: url, apiKey: apiKey, session: session)
            guard (200...299).contains(fallback.statusCode) else {
                var detail = ""
                if let root = try? JSONSerialization.jsonObject(with: fallback.body) as? [String: Any] {
                    detail = string(root["detail"] ?? root["error"]) ?? ""
                }
                throw TorBoxUsenetError.http(fallback.statusCode, detail)
            }
            return try parseSearchResponse(fallback.body)
        }
    }

    private static func searchDataWithTransientRetry(
        request: URLRequest,
        session: URLSession,
        maxAttempts: Int = 3
    ) async throws -> (Data, URLResponse) {
        var attempt = 0
        while true {
            do {
                return try await session.data(for: request)
            } catch {
                attempt += 1
                guard attempt < maxAttempts, isTransientNetworkError(error) else { throw error }
                try? await Task.sleep(nanoseconds: UInt64(350_000_000 * attempt))
            }
        }
    }

    private static func isDNSResolutionError(_ error: Error) -> Bool {
        if let urlError = error as? URLError {
            return urlError.code == .cannotFindHost || urlError.code == .dnsLookupFailed
        }
        let ns = error as NSError
        return ns.domain == NSURLErrorDomain && [URLError.cannotFindHost.rawValue, URLError.dnsLookupFailed.rawValue].contains(ns.code)
    }

    private struct RawVoyagerHTTPResponse {
        var statusCode: Int
        var body: Data
    }

    private static func voyagerSearchViaDoH(
        url: URL,
        apiKey: String,
        session: URLSession
    ) async throws -> RawVoyagerHTTPResponse {
        #if canImport(Network) && canImport(Security)
        let host = url.host ?? "search-api.torbox.app"
        guard host.caseInsensitiveCompare("search-api.torbox.app") == .orderedSame else {
            throw TorBoxUsenetError.unavailable("DNS fallback is restricted to TorBox Voyager.")
        }
        let addresses = try await resolveIPv4ViaDoH(host: host, session: session)
        guard !addresses.isEmpty else {
            throw TorBoxUsenetError.unavailable("TorBox Voyager could not be resolved through the device DNS or DNS-over-HTTPS.")
        }

        var lastError: Error?
        for address in addresses.prefix(4) {
            do {
                return try await rawTLSGET(url: url, connectAddress: address, serverName: host, apiKey: apiKey)
            } catch {
                lastError = error
            }
        }
        let detail = lastError?.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        throw TorBoxUsenetError.unavailable("TorBox Voyager DNS was recovered, but the secure connection failed: \(detail.isEmpty ? "Unknown TLS/network error" : detail)")
        #else
        throw TorBoxUsenetError.unavailable("TorBox Voyager could not be resolved by this device.")
        #endif
    }

    private static func resolveIPv4ViaDoH(host: String, session: URLSession) async throws -> [String] {
        // Use literal Cloudflare resolver IPs so this fallback does not depend on the same
        // local DNS path that failed for Voyager. The TorBox API key is never included.
        let resolvers = ["1.1.1.1", "1.0.0.1"]
        var lastError: Error?

        for resolver in resolvers {
            do {
                var components = URLComponents(string: "https://\(resolver)/dns-query")!
                components.queryItems = [
                    URLQueryItem(name: "name", value: host),
                    URLQueryItem(name: "type", value: "A")
                ]
                guard let url = components.url else { continue }
                var request = URLRequest(url: url, timeoutInterval: 8)
                request.setValue("application/dns-json", forHTTPHeaderField: "Accept")
                request.setValue("DebridChannels-tvOS/vBRDC058 DoH", forHTTPHeaderField: "User-Agent")
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { continue }
                guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { continue }
                let status = integer(root["Status"]) ?? 0
                guard status == 0 else { continue }
                let answers = root["Answer"] as? [[String: Any]] ?? []
                let values = answers.compactMap { answer -> String? in
                    guard (integer(answer["type"]) ?? 0) == 1 else { return nil }
                    let value = string(answer["data"]) ?? ""
                    return isIPv4Address(value) ? value : nil
                }
                if !values.isEmpty {
                    var seen = Set<String>()
                    return values.filter { seen.insert($0).inserted }
                }
            } catch {
                lastError = error
            }
        }

        if let lastError { throw lastError }
        throw TorBoxUsenetError.unavailable("DNS-over-HTTPS returned no IPv4 address for TorBox Voyager.")
    }

    private static func isIPv4Address(_ value: String) -> Bool {
        let parts = value.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 4 else { return false }
        return parts.allSatisfy { part in
            guard let number = Int(part), (0...255).contains(number) else { return false }
            return String(number) == part || (part.count > 1 && part.first == "0")
        }
    }

    #if canImport(Network) && canImport(Security)
    private final class RawTLSBox: @unchecked Sendable {
        let lock = NSLock()
        var completed = false
        var buffer = Data()
        var timeoutWork: DispatchWorkItem?
    }

    private static func rawTLSGET(
        url: URL,
        connectAddress: String,
        serverName: String,
        apiKey: String
    ) async throws -> RawVoyagerHTTPResponse {
        try await withCheckedThrowingContinuation { continuation in
            let tls = NWProtocolTLS.Options()
            sec_protocol_options_set_tls_server_name(tls.securityProtocolOptions, serverName)
            let tcp = NWProtocolTCP.Options()
            let parameters = NWParameters(tls: tls, tcp: tcp)
            let port = NWEndpoint.Port(rawValue: 443)!
            let connection = NWConnection(host: NWEndpoint.Host(connectAddress), port: port, using: parameters)
            let queue = DispatchQueue(label: "app.debridchannels.torbox-voyager-doh")
            let box = RawTLSBox()

            func finish(_ result: Result<RawVoyagerHTTPResponse, Error>) {
                box.lock.lock()
                guard !box.completed else {
                    box.lock.unlock()
                    return
                }
                box.completed = true
                let timeoutWork = box.timeoutWork
                box.lock.unlock()
                timeoutWork?.cancel()
                connection.stateUpdateHandler = nil
                connection.cancel()
                continuation.resume(with: result)
            }

            func receiveNext() {
                connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { data, _, isComplete, error in
                    if let data, !data.isEmpty {
                        box.lock.lock()
                        box.buffer.append(data)
                        let snapshot = box.buffer
                        box.lock.unlock()
                        if let parsed = try? parseRawHTTPResponse(snapshot, requireCompleteBody: true) {
                            finish(.success(parsed))
                            return
                        }
                    }
                    if let error {
                        finish(.failure(error))
                        return
                    }
                    if isComplete {
                        box.lock.lock()
                        let finalData = box.buffer
                        box.lock.unlock()
                        do {
                            finish(.success(try parseRawHTTPResponse(finalData, requireCompleteBody: false)))
                        } catch {
                            finish(.failure(error))
                        }
                        return
                    }
                    receiveNext()
                }
            }

            connection.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
                    var target = components?.percentEncodedPath ?? url.path
                    if target.isEmpty { target = "/" }
                    if let query = components?.percentEncodedQuery, !query.isEmpty { target += "?\(query)" }
                    let request = "GET \(target) HTTP/1.1\r\n" +
                        "Host: \(serverName)\r\n" +
                        "Authorization: Bearer \(apiKey)\r\n" +
                        "Accept: application/json\r\n" +
                        "Accept-Encoding: identity\r\n" +
                        "User-Agent: DebridChannels-tvOS/vBRDC058 TorBoxUsenet\r\n" +
                        "Connection: close\r\n\r\n"
                    guard let bytes = request.data(using: .utf8) else {
                        finish(.failure(TorBoxUsenetError.invalidResponse("Could not encode the TorBox Voyager request.")))
                        return
                    }
                    connection.send(content: bytes, completion: .contentProcessed { error in
                        if let error { finish(.failure(error)); return }
                        receiveNext()
                    })
                case let .failed(error):
                    finish(.failure(error))
                case .cancelled:
                    break
                default:
                    break
                }
            }

            let timeoutWork = DispatchWorkItem {
                finish(.failure(TorBoxUsenetError.timedOut("TorBox Voyager secure DNS fallback timed out.")))
            }
            box.timeoutWork = timeoutWork
            queue.asyncAfter(deadline: .now() + 18, execute: timeoutWork)
            connection.start(queue: queue)
        }
    }

    private static func parseRawHTTPResponse(_ data: Data, requireCompleteBody: Bool) throws -> RawVoyagerHTTPResponse {
        let delimiter = Data("\r\n\r\n".utf8)
        guard let headerRange = data.range(of: delimiter) else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an incomplete HTTP response.")
        }
        let headerData = data[..<headerRange.lowerBound]
        guard let headerText = String(data: headerData, encoding: .utf8) else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned unreadable HTTP headers.")
        }
        let lines = headerText.components(separatedBy: "\r\n")
        guard let statusLine = lines.first else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned no HTTP status.")
        }
        let statusParts = statusLine.split(separator: " ", maxSplits: 2)
        guard statusParts.count >= 2, let statusCode = Int(statusParts[1]) else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an invalid HTTP status.")
        }

        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let name = line[..<colon].trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            let value = line[line.index(after: colon)...].trimmingCharacters(in: .whitespacesAndNewlines)
            headers[name] = value
        }

        let bodyStart = headerRange.upperBound
        let body = Data(data[bodyStart...])
        if headers["transfer-encoding"]?.lowercased().contains("chunked") == true {
            let decoded = try decodeChunkedBody(body, requireComplete: requireCompleteBody)
            return RawVoyagerHTTPResponse(statusCode: statusCode, body: decoded)
        }
        if let rawLength = headers["content-length"], let length = Int(rawLength) {
            if requireCompleteBody && body.count < length {
                throw TorBoxUsenetError.invalidResponse("TorBox Voyager response body is still arriving.")
            }
            guard body.count >= length else {
                throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned a truncated response.")
            }
            return RawVoyagerHTTPResponse(statusCode: statusCode, body: Data(body.prefix(length)))
        }
        if requireCompleteBody {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager response body is still arriving.")
        }
        return RawVoyagerHTTPResponse(statusCode: statusCode, body: body)
    }

    private static func decodeChunkedBody(_ data: Data, requireComplete: Bool) throws -> Data {
        var output = Data()
        var index = data.startIndex
        let crlf = Data("\r\n".utf8)

        while index < data.endIndex {
            guard let lineRange = data[index...].range(of: crlf) else {
                throw TorBoxUsenetError.invalidResponse(requireComplete ? "TorBox Voyager chunk is still arriving." : "TorBox Voyager returned malformed chunked data.")
            }
            guard let sizeLine = String(data: data[index..<lineRange.lowerBound], encoding: .utf8) else {
                throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an invalid chunk size.")
            }
            let sizeToken = sizeLine.split(separator: ";", maxSplits: 1).first.map(String.init) ?? ""
            guard let size = Int(sizeToken.trimmingCharacters(in: .whitespacesAndNewlines), radix: 16) else {
                throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an invalid chunk size.")
            }
            index = lineRange.upperBound
            if size == 0 { return output }
            guard data.distance(from: index, to: data.endIndex) >= size + 2 else {
                throw TorBoxUsenetError.invalidResponse(requireComplete ? "TorBox Voyager chunk is still arriving." : "TorBox Voyager returned a truncated chunk.")
            }
            let end = data.index(index, offsetBy: size)
            output.append(data[index..<end])
            index = end
            guard data.distance(from: index, to: data.endIndex) >= 2,
                  data[index..<data.index(index, offsetBy: 2)].elementsEqual(crlf) else {
                throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned malformed chunk framing.")
            }
            index = data.index(index, offsetBy: 2)
        }

        throw TorBoxUsenetError.invalidResponse(requireComplete ? "TorBox Voyager chunked body is still arriving." : "TorBox Voyager returned an incomplete chunked body.")
    }
    #endif

    private static func parseSearchResponse(_ data: Data) throws -> [TorBoxUsenetSearchResult] {
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox Voyager returned an unreadable Usenet response.")
        }
        if let success = bool(root["success"]), !success {
            let detail = string(root["detail"] ?? root["error"]) ?? "TorBox Usenet search is unavailable for this account."
            throw TorBoxUsenetError.unavailable(detail)
        }

        // TorBox's envelope is normally { success, data: { nzbs: [...] } }, while
        // some public SDK/test fixtures expose the search payload directly. Accept both.
        let payload = root["data"] ?? root
        let objects: [[String: Any]]
        if let dictionary = payload as? [String: Any] {
            if let list = dictionary["nzbs"] as? [[String: Any]] {
                objects = list
            } else if let list = dictionary["results"] as? [[String: Any]] {
                objects = list
            } else if dictionary["raw_title"] != nil || dictionary["title"] != nil || dictionary["name"] != nil {
                objects = [dictionary]
            } else {
                objects = []
            }
        } else if let list = payload as? [[String: Any]] {
            objects = list
        } else {
            objects = []
        }

        return objects.compactMap { entry in
            let rawTitle = string(entry["raw_title"] ?? entry["title"] ?? entry["name"]) ?? ""
            let normalizedTitle = string(entry["title"] ?? entry["name"] ?? entry["raw_title"]) ?? rawTitle
            let hash = string(entry["hash"]) ?? ""
            let nzbURL = string(entry["nzb"] ?? entry["nzb_link"] ?? entry["download_link"] ?? entry["link"]) ?? ""
            guard !rawTitle.isEmpty, !hash.isEmpty || !nzbURL.isEmpty else { return nil }

            var tracker = string(entry["tracker"] ?? entry["source"]) ?? ""
            if tracker.isEmpty, let indexer = entry["indexer"] as? [String: Any] {
                tracker = string(indexer["name"] ?? indexer["title"]) ?? ""
            }

            return TorBoxUsenetSearchResult(
                hash: hash,
                rawTitle: rawTitle,
                normalizedTitle: normalizedTitle,
                sizeBytes: max(0, integer64(entry["size"] ?? entry["bytes"]) ?? 0),
                tracker: tracker,
                nzbURL: nzbURL,
                age: string(entry["age"]) ?? "",
                cached: bool(entry["cached"] ?? entry["is_cached"]) ?? false,
                owned: bool(entry["owned"] ?? entry["is_owned"]) ?? false
            )
        }
    }

    private static func deduplicated(_ results: [TorBoxUsenetSearchResult]) -> [TorBoxUsenetSearchResult] {
        var seen = Set<String>()
        return results.filter { result in
            let key: String
            if !result.hash.isEmpty { key = "hash:\(result.hash.lowercased())" }
            else if !result.nzbURL.isEmpty { key = "nzb:\(result.nzbURL.lowercased())" }
            else { key = "title:\(result.normalizedTitle.lowercased())" }
            return seen.insert(key).inserted
        }
    }

    private static func fullTextSearchQuery(for item: MediaItem) -> String {
        var parts = [item.title.trimmingCharacters(in: .whitespacesAndNewlines)].filter { !$0.isEmpty }
        if let season = item.seasonNumber, season >= 0 {
            if let episode = item.episodeNumber, episode > 0 {
                parts.append(String(format: "S%02dE%02d", season, episode))
            } else {
                parts.append(String(format: "S%02d", season))
            }
        } else {
            let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
            if !year.isEmpty { parts.append(year) }
        }
        return parts.joined(separator: " ")
    }

    static func resolve(_ result: TorBoxUsenetSearchResult, apiKey: String, session: URLSession = .shared) async throws -> URL {
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { throw TorBoxUsenetError.missingAPIKey }

        // If Voyager says the item is already owned, reuse the existing TorBox job rather
        // than creating a duplicate. It may still be downloading/unpacking, so wait on that
        // job instead of falling through to a second create request.
        if result.owned, !result.hash.isEmpty,
           let existing = try? await existingDownload(hash: result.hash, apiKey: key, session: session) {
            if let playable = try await playableURLIfReady(download: existing, apiKey: key, session: session) {
                return playable
            }
            if let existingID = integer(existing["id"]), existingID > 0 {
                return try await waitForPlayableDownload(
                    id: existingID,
                    timeout: result.cached ? 120 : 600,
                    apiKey: key,
                    session: session
                )
            }
        }

        guard !result.nzbURL.isEmpty else {
            throw TorBoxUsenetError.unavailable("TorBox found this Usenet release but did not expose an NZB handoff URL.")
        }

        let downloadID = try await createDownload(result: result, apiKey: key, session: session)
        return try await waitForPlayableDownload(
            id: downloadID,
            timeout: result.cached ? 120 : 600,
            apiKey: key,
            session: session
        )
    }

    static func qualityLabel(for title: String) -> String {
        let h = title.lowercased()
        var parts: [String] = []
        if h.contains("2160") || h.contains("4k") { parts.append("4K") }
        else if h.contains("1440") { parts.append("1440p") }
        else if h.contains("1080") { parts.append("1080p") }
        else if h.contains("720") { parts.append("720p") }
        else { parts.append("Usenet") }
        if h.contains("remux") { parts.append("REMUX") }
        else if h.contains("web-dl") || h.contains("webdl") { parts.append("WEB-DL") }
        else if h.contains("bluray") || h.contains("blu-ray") { parts.append("BluRay") }
        if h.contains("dolby vision") || h.contains("dovi") || h.contains(".dv.") { parts.append("DV") }
        if h.contains("hdr10+") || h.contains("hdr10plus") { parts.append("HDR10+") }
        else if h.contains("hdr") { parts.append("HDR") }
        return parts.joined(separator: " • ")
    }

    static func sizeLabel(bytes: Int64) -> String {
        guard bytes > 0 else { return "" }
        let gb = Double(bytes) / 1_073_741_824.0
        if gb >= 1 { return String(format: "%.2f GB", gb) }
        let mb = Double(bytes) / 1_048_576.0
        return String(format: "%.0f MB", mb)
    }

    // MARK: - Main API

    private static func createDownload(result: TorBoxUsenetSearchResult, apiKey: String, session: URLSession) async throws -> Int {
        guard let url = URL(string: "\(apiBase)/createusenetdownload") else {
            throw TorBoxUsenetError.invalidResponse("TorBox Usenet create URL is invalid.")
        }

        // vBRDC056: current TorBox Usenet create is multipart/form-data for either
        // an NZB upload or an accessible NZB link. We only send the link here.
        let boundary = "DebridChannels-\(UUID().uuidString)"
        let fields: [(String, String)] = [
            ("link", result.nzbURL)
        ]
        var body = Data()
        for (name, value) in fields {
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(name)\"\r\n\r\n".data(using: .utf8)!)
            body.append(value.data(using: .utf8)!)
            body.append("\r\n".data(using: .utf8)!)
        }
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        var request = URLRequest(url: url, timeoutInterval: 20)
        request.httpMethod = "POST"
        request.httpBody = body
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/vBRDC058 TorBoxUsenet", forHTTPHeaderField: "User-Agent")

        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox did not return a Usenet download ID.")
        }
        if let success = root["success"] as? Bool, !success {
            throw TorBoxUsenetError.unavailable(string(root["detail"]) ?? "TorBox could not create the Usenet download.")
        }
        guard let payload = root["data"] as? [String: Any],
              let id = integer(payload["usenetdownload_id"] ?? payload["usenet_download_id"] ?? payload["id"]), id > 0 else {
            throw TorBoxUsenetError.invalidResponse("TorBox accepted the NZB but did not return a usable download ID.")
        }
        return id
    }

    private static func existingDownload(hash: String, apiKey: String, session: URLSession) async throws -> [String: Any]? {
        guard let url = URL(string: "\(apiBase)/mylist?limit=1000") else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        let items: [[String: Any]]
        if let list = root["data"] as? [[String: Any]] { items = list }
        else if let one = root["data"] as? [String: Any] { items = [one] }
        else { items = [] }
        return items.first { string($0["hash"])?.caseInsensitiveCompare(hash) == .orderedSame }
    }

    private static func getDownload(id: Int, apiKey: String, session: URLSession) async throws -> [String: Any] {
        var components = URLComponents(string: "\(apiBase)/mylist")!
        components.queryItems = [
            URLQueryItem(name: "id", value: String(id)),
            URLQueryItem(name: "bypass_cache", value: "true")
        ]
        guard let url = components.url else { throw TorBoxUsenetError.invalidResponse("TorBox Usenet status URL is invalid.") }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox returned an unreadable Usenet status response.")
        }
        if let object = root["data"] as? [String: Any] { return object }
        if let list = root["data"] as? [[String: Any]], let first = list.first { return first }
        throw TorBoxUsenetError.invalidResponse("TorBox did not return the selected Usenet download.")
    }

    private static func waitForPlayableDownload(id: Int, timeout: TimeInterval, apiKey: String, session: URLSession) async throws -> URL {
        let deadline = Date().addingTimeInterval(timeout)
        var lastState = "preparing"
        while Date() < deadline {
            try Task.checkCancellation()
            let download = try await getDownload(id: id, apiKey: apiKey, session: session)
            lastState = string(download["download_state"]) ?? lastState
            if let playable = try await playableURLIfReady(download: download, apiKey: apiKey, session: session) {
                return playable
            }
            if isFailureState(lastState) {
                throw TorBoxUsenetError.unavailable("TorBox could not prepare this Usenet source (\(lastState)).")
            }
            try await Task.sleep(nanoseconds: 4_000_000_000)
        }
        throw TorBoxUsenetError.timedOut("TorBox is still preparing this Usenet source (\(lastState)). Try it again after the download finishes in TorBox.")
    }

    private static func playableURLIfReady(download: [String: Any], apiKey: String, session: URLSession) async throws -> URL? {
        let finished = bool(download["download_finished"]) ?? false
        let present = bool(download["download_present"]) ?? false
        let cached = bool(download["cached"]) ?? false
        guard (finished && present) || (cached && present) else { return nil }
        guard let usenetID = integer(download["id"]), usenetID > 0 else { return nil }
        guard let file = preferredVideoFile(from: download), let fileID = integer(file["id"]), fileID >= 0 else { return nil }
        return try await requestDownloadURL(usenetID: usenetID, fileID: fileID, apiKey: apiKey, session: session)
    }

    private static func requestDownloadURL(usenetID: Int, fileID: Int, apiKey: String, session: URLSession) async throws -> URL {
        var components = URLComponents(string: "\(apiBase)/requestdl")!
        var queryItems = [
            URLQueryItem(name: "token", value: apiKey),
            URLQueryItem(name: "usenet_id", value: String(usenetID)),
            URLQueryItem(name: "zip_link", value: "false")
        ]
        if fileID != 0 {
            queryItems.append(URLQueryItem(name: "file_id", value: String(fileID)))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw TorBoxUsenetError.invalidResponse("TorBox Usenet playback URL is invalid.") }
        var request = URLRequest(url: url, timeoutInterval: 15)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await dataWithTransientRetry(request: request, session: session)
        try validate(response: response, data: data)
        guard let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw TorBoxUsenetError.invalidResponse("TorBox did not return a stream URL.")
        }
        let raw = string(root["data"]) ?? ((root["data"] as? [String: Any]).flatMap { string($0["link"] ?? $0["url"]) })
        guard let raw, let playable = URL(string: raw), ["http", "https"].contains(playable.scheme?.lowercased() ?? "") else {
            throw TorBoxUsenetError.invalidResponse("TorBox prepared the Usenet download but did not return a playable CDN URL.")
        }
        return playable
    }

    private static func preferredVideoFile(from download: [String: Any]) -> [String: Any]? {
        guard let files = download["files"] as? [[String: Any]], !files.isEmpty else { return nil }
        let videoExtensions = ["mkv", "mp4", "m4v", "mov", "m2ts", "ts", "webm", "avi"]
        let archiveExtensions = ["rar", "zip", "7z", "par2", "nzb", "nfo", "sfv"]
        let candidates = files.filter { file in
            let name = (string(file["name"] ?? file["short_name"]) ?? "").lowercased()
            let ext = name.split(separator: ".").last.map(String.init) ?? ""
            let mime = (string(file["mimetype"]) ?? "").lowercased()
            let sample = name.contains("sample") || name.contains("trailer") || name.contains("proof")
            return !sample && (videoExtensions.contains(ext) || mime.hasPrefix("video/"))
        }
        if let best = candidates.max(by: { (integer64($0["size"]) ?? 0) < (integer64($1["size"]) ?? 0) }) { return best }
        return files
            .filter { file in
                let name = (string(file["name"] ?? file["short_name"]) ?? "").lowercased()
                let ext = name.split(separator: ".").last.map(String.init) ?? ""
                return !archiveExtensions.contains(ext)
            }
            .max(by: { (integer64($0["size"]) ?? 0) < (integer64($1["size"]) ?? 0) })
    }

    private static func isFailureState(_ value: String) -> Bool {
        let h = value.lowercased()
        return ["failed", "error", "dead", "missing", "invalid", "cancelled", "canceled", "repair_failed", "unpack_failed"].contains { h.contains($0) }
    }

    private static func searchIdentity(for item: MediaItem) -> (type: String, id: String)? {
        let imdb = (item.imdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if imdb.lowercased().hasPrefix("tt"), imdb.count >= 9 { return ("imdb", imdb) }
        let tmdb = (item.tmdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !tmdb.isEmpty { return ("tmdb", tmdb) }
        let tvdb = (item.tvdbId ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if !tvdb.isEmpty { return ("tvdb", tvdb) }
        return nil
    }

    private static func dataWithTransientRetry(request: URLRequest, session: URLSession, maxAttempts: Int = 3) async throws -> (Data, URLResponse) {
        var attempt = 0
        while true {
            do {
                return try await session.data(for: request)
            } catch {
                attempt += 1
                guard attempt < maxAttempts, isTransientNetworkError(error) else {
                    let host = request.url?.host ?? "TorBox endpoint"
                    let detail = error.localizedDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    throw TorBoxUsenetError.unavailable("\(host) connection failed: \(detail.isEmpty ? "Unknown network error" : detail)")
                }
                let delay = UInt64(350_000_000 * attempt)
                try? await Task.sleep(nanoseconds: delay)
            }
        }
    }

    private static func isTransientNetworkError(_ error: Error) -> Bool {
        let code: Int
        if let urlError = error as? URLError {
            code = urlError.errorCode
        } else {
            let ns = error as NSError
            guard ns.domain == NSURLErrorDomain else { return false }
            code = ns.code
        }
        let transientCodes: Set<Int> = [
            URLError.cannotFindHost.rawValue,
            URLError.dnsLookupFailed.rawValue,
            URLError.cannotConnectToHost.rawValue,
            URLError.networkConnectionLost.rawValue,
            URLError.notConnectedToInternet.rawValue,
            URLError.timedOut.rawValue
        ]
        return transientCodes.contains(code)
    }

    private static func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { return }
        guard (200...299).contains(http.statusCode) else {
            var detail = ""
            if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                detail = string(root["detail"] ?? root["error"]) ?? ""
            }
            throw TorBoxUsenetError.http(http.statusCode, detail)
        }
    }

    private static func string(_ value: Any?) -> String? {
        if let value = value as? String { return value.trimmingCharacters(in: .whitespacesAndNewlines) }
        if let value = value as? NSNumber { return value.stringValue }
        return nil
    }

    private static func integer(_ value: Any?) -> Int? {
        if let value = value as? Int { return value }
        if let value = value as? NSNumber { return value.intValue }
        if let value = value as? String { return Int(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    private static func integer64(_ value: Any?) -> Int64? {
        if let value = value as? Int64 { return value }
        if let value = value as? Int { return Int64(value) }
        if let value = value as? NSNumber { return value.int64Value }
        if let value = value as? String { return Int64(value.trimmingCharacters(in: .whitespacesAndNewlines)) }
        return nil
    }

    private static func bool(_ value: Any?) -> Bool? {
        if let value = value as? Bool { return value }
        if let value = value as? NSNumber { return value.boolValue }
        if let value = value as? String {
            switch value.lowercased() {
            case "true", "1", "yes": return true
            case "false", "0", "no": return false
            default: return nil
            }
        }
        return nil
    }
}
