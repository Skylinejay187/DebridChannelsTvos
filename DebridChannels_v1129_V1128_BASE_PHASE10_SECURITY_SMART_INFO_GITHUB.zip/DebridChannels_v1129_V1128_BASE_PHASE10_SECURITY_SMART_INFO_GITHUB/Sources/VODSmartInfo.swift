import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

enum VODSmartInfoPanelMode: String, CaseIterable, Hashable {
    case off
    case trivia
    case relatedTitles
    case castSpotlight
    case seriesInfo
    case auto

    var displayName: String {
        switch self {
        case .off: return "Off"
        case .trivia: return "Trivia"
        case .relatedTitles: return "Related Titles"
        case .castSpotlight: return "Cast Spotlight"
        case .seriesInfo: return "Series Info"
        case .auto: return "Auto"
        }
    }

    var next: VODSmartInfoPanelMode {
        let values = Self.allCases
        guard let index = values.firstIndex(of: self) else { return .auto }
        return values[(index + 1) % values.count]
    }
}

struct VODSmartInfoCard: Identifiable, Hashable {
    let id: String
    let kind: VODSmartInfoPanelMode
    let eyebrow: String
    let title: String
    let body: String
    let detail: String?
    let imageURL: String?
}

private struct WikidataSearchEnvelope: Decodable {
    struct Result: Decodable {
        let id: String
        let label: String?
        let description: String?
    }
    let search: [Result]
}

private struct WikidataEntityEnvelope: Decodable {
    struct Entity: Decodable {
        struct Label: Decodable { let value: String }
        struct Claim: Decodable {
            struct MainSnak: Decodable {
                struct DataValue: Decodable {
                    let entityID: String?

                    private enum CodingKeys: String, CodingKey { case id }

                    init(from decoder: Decoder) throws {
                        // Wikidata entity datavalues also contain numeric-id/entity-type fields.
                        // Decode only the stable Q-id without requiring every value to be a String.
                        if let container = try? decoder.container(keyedBy: CodingKeys.self) {
                            entityID = try? container.decode(String.self, forKey: .id)
                        } else {
                            entityID = nil
                        }
                    }
                }
                let datavalue: DataValue?
            }
            let mainsnak: MainSnak
        }
        let labels: [String: Label]?
        let claims: [String: [Claim]]?
    }
    let entities: [String: Entity]
}


private struct TMDBExternalIDsEnvelope: Decodable {
    let wikidataID: String?

    enum CodingKeys: String, CodingKey {
        case wikidataID = "wikidata_id"
    }
}

private struct TMDBRecommendationsEnvelope: Decodable {
    struct Result: Decodable {
        let id: Int
        let title: String?
        let name: String?
        let overview: String?
        let backdrop_path: String?
        let poster_path: String?
        let vote_average: Double?
    }
    let results: [Result]
}

enum VODSmartInfoService {
    private static let cacheLock = NSLock()
    private static var cache: [String: (Date, [VODSmartInfoCard])] = [:]
    private static let cacheTTL: TimeInterval = 7 * 24 * 60 * 60

    static func cards(
        for item: MediaItem,
        mode: VODSmartInfoPanelMode,
        tmdbAPIKey: String
    ) async -> [VODSmartInfoCard] {
        guard mode != .off else { return [] }
        let key = cacheKey(item: item, mode: mode)
        if let cached = cachedCards(for: key) { return cached }

        let cards: [VODSmartInfoCard]
        switch mode {
        case .trivia:
            cards = await verifiedTriviaCards(for: item, tmdbAPIKey: tmdbAPIKey)
        case .relatedTitles:
            cards = await relatedTitleCards(for: item, tmdbAPIKey: tmdbAPIKey)
        case .castSpotlight:
            cards = castCards(for: item)
        case .seriesInfo:
            cards = seriesCards(for: item)
        case .auto:
            let trivia = await verifiedTriviaCards(for: item, tmdbAPIKey: tmdbAPIKey)
            if !trivia.isEmpty {
                cards = trivia
            } else {
                let series = seriesCards(for: item)
                if !series.isEmpty {
                    cards = series
                } else {
                    let cast = castCards(for: item)
                    if !cast.isEmpty {
                        cards = cast
                    } else {
                        cards = await relatedTitleCards(for: item, tmdbAPIKey: tmdbAPIKey)
                    }
                }
            }
        case .off:
            cards = []
        }
        store(cards, for: key)
        return cards
    }

    private static func cacheKey(item: MediaItem, mode: VODSmartInfoPanelMode) -> String {
        [item.id, item.tmdbId ?? "", item.imdbId ?? "", "s\(item.seasonNumber ?? -1)", "e\(item.episodeNumber ?? -1)", mode.rawValue].joined(separator: "|")
    }

    private static func cachedCards(for key: String) -> [VODSmartInfoCard]? {
        cacheLock.lock(); defer { cacheLock.unlock() }
        guard let value = cache[key], Date().timeIntervalSince(value.0) < cacheTTL else {
            cache.removeValue(forKey: key)
            return nil
        }
        return value.1
    }

    private static func store(_ cards: [VODSmartInfoCard], for key: String) {
        cacheLock.lock(); defer { cacheLock.unlock() }
        cache[key] = (Date(), cards)
        if cache.count > 80 {
            let sorted = cache.sorted { $0.value.0 < $1.value.0 }
            for entry in sorted.prefix(cache.count - 64) { cache.removeValue(forKey: entry.key) }
        }
    }

    private static func castCards(for item: MediaItem) -> [VODSmartInfoCard] {
        item.castMembers
            .filter { !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .prefix(6)
            .enumerated()
            .map { index, member in
                VODSmartInfoCard(
                    id: "cast-\(index)-\(member.id)",
                    kind: .castSpotlight,
                    eyebrow: "CAST SPOTLIGHT",
                    title: member.name,
                    body: member.role?.trimmingCharacters(in: .whitespacesAndNewlines).nonEmpty.map { "Plays \($0)" } ?? "Featured cast member",
                    detail: nil,
                    imageURL: member.imageURL
                )
            }
    }

    private static func seriesCards(for item: MediaItem) -> [VODSmartInfoCard] {
        guard item.seasonNumber != nil || item.episodeNumber != nil || item.type.lowercased().contains("episode") || item.type.lowercased().contains("series") || item.type.lowercased() == "tv" else { return [] }
        var parts: [String] = []
        if let season = item.seasonNumber, let episode = item.episodeNumber { parts.append("Season \(season), Episode \(episode)") }
        else if let season = item.seasonNumber { parts.append("Season \(season)") }
        if let air = item.airDateString?.trimmingCharacters(in: .whitespacesAndNewlines), !air.isEmpty { parts.append("Aired \(air)") }
        if !item.genres.isEmpty { parts.append(item.genres.prefix(3).joined(separator: " • ")) }
        guard !parts.isEmpty else { return [] }
        return [VODSmartInfoCard(
            id: "series-\(item.id)-\(item.seasonNumber ?? -1)-\(item.episodeNumber ?? -1)",
            kind: .seriesInfo,
            eyebrow: "SERIES INTELLIGENCE",
            title: item.title,
            body: parts.joined(separator: "  •  "),
            detail: item.directors.first.map { "Directed by \($0)" },
            imageURL: item.landscapeURL
        )]
    }

    private static func relatedTitleCards(for item: MediaItem, tmdbAPIKey: String) async -> [VODSmartInfoCard] {
        let key = tmdbAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, let tmdbID = Int(item.tmdbId ?? "") else { return [] }
        let type = (item.seasonNumber != nil || item.episodeNumber != nil || item.type.lowercased().contains("tv") || item.type.lowercased().contains("series") || item.type.lowercased().contains("show")) ? "tv" : "movie"
        var components = URLComponents(string: "https://api.themoviedb.org/3/\(type)/\(tmdbID)/recommendations")
        components?.queryItems = [URLQueryItem(name: "api_key", value: key), URLQueryItem(name: "language", value: "en-US"), URLQueryItem(name: "page", value: "1")]
        guard let url = components?.url else { return [] }
        do {
            let data = try await fetch(url: url, maximumBytes: 800_000)
            let payload = try JSONDecoder().decode(TMDBRecommendationsEnvelope.self, from: data)
            return payload.results.prefix(5).compactMap { result in
                let title = (result.title ?? result.name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !title.isEmpty, title.caseInsensitiveCompare(item.title) != .orderedSame else { return nil }
                let overview = (result.overview ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let imagePath = result.backdrop_path ?? result.poster_path
                let imageURL = imagePath.map { "https://image.tmdb.org/t/p/w780\($0)" }
                let rating = result.vote_average.flatMap { $0 > 0 ? String(format: "%.1f / 10", $0) : nil }
                return VODSmartInfoCard(
                    id: "related-\(result.id)",
                    kind: .relatedTitles,
                    eyebrow: "MORE LIKE THIS",
                    title: title,
                    body: overview.isEmpty ? "Recommended from your configured metadata provider." : overview,
                    detail: rating,
                    imageURL: imageURL
                )
            }
        } catch {
            return []
        }
    }

    private static func verifiedTriviaCards(for item: MediaItem, tmdbAPIKey: String) async -> [VODSmartInfoCard] {
        guard let entityID = await matchingWikidataEntity(for: item, tmdbAPIKey: tmdbAPIKey) else { return [] }
        guard let entity = await wikidataEntity(id: entityID) else { return [] }
        let claims = entity.claims ?? [:]
        var cards: [VODSmartInfoCard] = []

        let filmingLocationIDs = entityIDs(from: claims["P915"])
        if !filmingLocationIDs.isEmpty {
            let ids = filmingLocationIDs
            let labels = await wikidataLabels(ids: Array(ids.prefix(3)))
            for id in ids.prefix(2) {
                guard let label = labels[id], !label.isEmpty else { continue }
                cards.append(.init(id: "trivia-location-\(entityID)-\(id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Filming Location", body: "Verified production data lists \(label) as a filming location.", detail: "Source • Wikidata", imageURL: nil))
            }
        }
        let awardIDs = entityIDs(from: claims["P166"])
        if !awardIDs.isEmpty {
            let ids = awardIDs
            let labels = await wikidataLabels(ids: Array(ids.prefix(3)))
            for id in ids.prefix(2) {
                guard let label = labels[id], !label.isEmpty else { continue }
                cards.append(.init(id: "trivia-award-\(entityID)-\(id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Award Recognition", body: "This title is associated with \(label).", detail: "Source • Wikidata", imageURL: nil))
            }
        }
        let sourceMaterialIDs = entityIDs(from: claims["P144"])
        if !sourceMaterialIDs.isEmpty {
            let ids = sourceMaterialIDs
            let labels = await wikidataLabels(ids: Array(ids.prefix(2)))
            for id in ids.prefix(1) {
                guard let label = labels[id], !label.isEmpty else { continue }
                cards.append(.init(id: "trivia-based-\(entityID)-\(id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Source Material", body: "Verified structured data identifies \(label) as source material for this title.", detail: "Source • Wikidata", imageURL: nil))
            }
        }
        return Array(cards.prefix(5))
    }

    private static func matchingWikidataEntity(for item: MediaItem, tmdbAPIKey: String) async -> String? {
        // Prefer TMDB's exact external-ID relationship when a user configured a TMDB key.
        // This avoids title collisions (remakes, same-name series, regional titles) before
        // falling back to a conservative Wikidata title/type/year search.
        if let exact = await tmdbWikidataID(for: item, tmdbAPIKey: tmdbAPIKey) { return exact }

        var components = URLComponents(string: "https://www.wikidata.org/w/api.php")
        components?.queryItems = [
            URLQueryItem(name: "action", value: "wbsearchentities"),
            URLQueryItem(name: "search", value: item.title),
            URLQueryItem(name: "language", value: "en"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "limit", value: "8"),
            URLQueryItem(name: "origin", value: "*")
        ]
        guard let url = components?.url else { return nil }
        do {
            let data = try await fetch(url: url, maximumBytes: 500_000)
            let payload = try JSONDecoder().decode(WikidataSearchEnvelope.self, from: data)
            let title = normalized(item.title)
            let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
            let isSeries = item.seasonNumber != nil || item.episodeNumber != nil || item.type.lowercased().contains("series") || item.type.lowercased().contains("show") || item.type.lowercased() == "tv"
            let expectedMarkers = isSeries ? ["television", "tv series", "series"] : ["film", "movie"]
            let candidates = payload.search.filter { result in
                guard normalized(result.label ?? "") == title else { return false }
                let description = (result.description ?? "").lowercased()
                let typeMatches = expectedMarkers.contains { description.contains($0) }
                let yearMatches = year.isEmpty || description.contains(year)
                return typeMatches && yearMatches
            }
            return candidates.first?.id
        } catch {
            return nil
        }
    }

    private static func tmdbWikidataID(for item: MediaItem, tmdbAPIKey: String) async -> String? {
        let key = tmdbAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, let tmdbID = Int(item.tmdbId ?? "") else { return nil }
        let lowerType = item.type.lowercased()
        // Episode-level TMDB external IDs require the parent series ID. MediaItem does not
        // expose that separately here, so episode identities use the strict Wikidata fallback.
        if item.episodeNumber != nil || lowerType.contains("episode") { return nil }
        let isSeries = item.seasonNumber != nil || lowerType.contains("tv") || lowerType.contains("series") || lowerType.contains("show")
        let kind = isSeries ? "tv" : "movie"
        var components = URLComponents(string: "https://api.themoviedb.org/3/\(kind)/\(tmdbID)/external_ids")
        components?.queryItems = [URLQueryItem(name: "api_key", value: key)]
        guard let url = components?.url else { return nil }
        do {
            let data = try await fetch(url: url, maximumBytes: 300_000)
            let payload = try JSONDecoder().decode(TMDBExternalIDsEnvelope.self, from: data)
            let value = payload.wikidataID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            return value.hasPrefix("Q") ? value : nil
        } catch {
            return nil
        }
    }

    private static func wikidataEntity(id: String) async -> WikidataEntityEnvelope.Entity? {
        var components = URLComponents(string: "https://www.wikidata.org/w/api.php")
        components?.queryItems = [
            URLQueryItem(name: "action", value: "wbgetentities"),
            URLQueryItem(name: "ids", value: id),
            URLQueryItem(name: "props", value: "claims|labels"),
            URLQueryItem(name: "languages", value: "en"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "origin", value: "*")
        ]
        guard let url = components?.url else { return nil }
        do {
            let data = try await fetch(url: url, maximumBytes: 1_000_000)
            return try JSONDecoder().decode(WikidataEntityEnvelope.self, from: data).entities[id]
        } catch { return nil }
    }

    private static func wikidataLabels(ids: [String]) async -> [String: String] {
        guard !ids.isEmpty else { return [:] }
        var components = URLComponents(string: "https://www.wikidata.org/w/api.php")
        components?.queryItems = [
            URLQueryItem(name: "action", value: "wbgetentities"),
            URLQueryItem(name: "ids", value: ids.joined(separator: "|")),
            URLQueryItem(name: "props", value: "labels"),
            URLQueryItem(name: "languages", value: "en"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "origin", value: "*")
        ]
        guard let url = components?.url else { return [:] }
        do {
            let data = try await fetch(url: url, maximumBytes: 700_000)
            let entities = try JSONDecoder().decode(WikidataEntityEnvelope.self, from: data).entities
            return Dictionary(uniqueKeysWithValues: entities.compactMap { key, value in
                guard let label = value.labels?["en"]?.value else { return nil }
                return (key, label)
            })
        } catch { return [:] }
    }

    private static func entityIDs(from claims: [WikidataEntityEnvelope.Entity.Claim]?) -> [String] {
        guard let claims else { return [] }
        return claims.compactMap { $0.mainsnak.datavalue?.entityID }.uniquedPreservingOrder()
    }

    private static func fetch(url: URL, maximumBytes: Int) async throws -> Data {
        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        request.cachePolicy = .returnCacheDataElseLoad
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/1.0 SmartInfo", forHTTPHeaderField: "User-Agent")
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 8
        config.timeoutIntervalForResource = 10
        config.requestCachePolicy = .returnCacheDataElseLoad
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard data.count <= maximumBytes else { throw URLError(.dataLengthExceedsMaximum) }
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        return data
    }

    private static func normalized(_ value: String) -> String {
        value.lowercased().unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }.map(String.init).joined()
    }
}
