# v262 VOD Single-Step Panel Focus

- Fixes Siri Remote ghost double-move skipping overlay chips.
- Converts overlay controls/options to real plain SwiftUI Buttons.
- Prevents parent overlay tap from double-selecting or closing panels.
- Makes option panels focus their first/current option so they can be selected.
- Preserves KSPlayer default, VOD cache warming, and v261 visual overlay work.
