# Debrid Channels tvOS v14 Safe Launch

Upload this ZIP as-is/contents to GitHub. The workflow recursively extracts the embedded source ZIP, generates the Xcode project using XcodeGen, builds an unsigned tvOS app, and uploads an IPA artifact.

v14 focus:
- Safe launch fallback home screen
- Landscape cards by default
- tvOS-safe layout editor controls
- No Real Debrid/Torbox wiring yet
- No auto catalog network fetch on launch
- No Stepper / roundedBorder TextField usage
