# vBRDC321 — Phase 3 Preview / Catalog Reliability Carry-Forward
Version 1.0.1023 (1023)

Hardware feedback from v320 showed Phase 2 was not sufficient:
- catalog posters still stranded blank during ordinary browsing
- Spotlight related artwork was cropped and themed logos were not reliably visible

Changes:
1. Shared artwork backend remains primary, but /api/image failures now receive one bounded
   public-origin fallback. Successful fallback bytes are stored under the same durable Signal
   cache identity, so future mounts remain cache-first.
2. Phase 2 prefetch queue also performs the same bounded fallback rather than silently treating
   a failed relay as hydrated artwork.
3. Spotlight related cards use explicit stable geometry and aspect-fit artwork, preventing
   landscape/poster artwork from being cropped out. The themed-logo box is reserved and stable.
4. Phase 3 preview isolation begins here: after the 35-second focused-card preview finishes,
   Signal releases the AVPlayerItem/decoder immediately while keeping the single AVPlayer pool.
   This reduces dormant decoder/compositor pressure without removing previews or changing trailers.
5. UNITY, full VOD playback, full Live TV playback, and approved trailer behavior are preserved.

Phase 4 addition locked:
- EPG/Gracenote cold-start, foreground, sleep/wake and overnight-idle reliability
- durable last-known-good EPG/logo snapshots
- automatic watchdog/retry with stale-generation protection
- Gracenote -> channel-logo fallback and forced visible rehydration
- no blank Guide/Grid while a refresh is in progress
