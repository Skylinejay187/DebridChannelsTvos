# vBRDC324 — System-Wide Performance Re-Core
Version 1.0.1026 (1026)

No visual/UNITY feature removal.

- Targets the actual MAIN GridOSCatalogOverlay used by Home / Movies / TV Shows; VOD
  playback-browse is explicitly excluded from the new main-catalog metadata repair.
- Found the old TMDB background artwork enrichment function was disabled and had no call sites.
  v324 adds a new bounded missing-artwork repair for the mounted three-row MAIN corridor:
  max 24 identities, concurrency 3, one atomic publication after enrichment.
- Existing global artwork byte cache/prefetch/backend-origin fallback remains.
- Media Information Play / Trailer / Find Links visuals use Equatable leaf isolation so unchanged
  chip gradient/shadow trees are not rebuilt on every focus step.
- Settings buttons use Equatable leaf isolation for the same reason.
- Compound Settings category stacks are lazy where safe, preserving geometry and appearance.
- Background catalog-repair failures no longer write app-wide observable status.
- Nuvio architecture principles retained: stable identity, persistent mounted state, bounded work,
  Equatable leaf rendering, one coherent publication, and no focus-driven network work.
