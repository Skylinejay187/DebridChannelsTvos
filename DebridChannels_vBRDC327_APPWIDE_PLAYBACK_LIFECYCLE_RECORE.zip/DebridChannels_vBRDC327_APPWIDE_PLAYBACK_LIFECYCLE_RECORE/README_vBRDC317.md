# vBRDC317 — Phase 2 Catalog + Poster Re-Core
Version: 1.0.1019 (1019)

Based on vBRDC316. UNITY visual continuity remains locked.

Phase 2 changes:
- Fixes the catalog poster prefetch starvation bug: the old prefetch API accepted a corridor
  but only launched the first two URLs and never pumped the rest after those completed.
- Adds a bounded ordered poster hydration queue. Visible identities stay first; two requests
  run concurrently and completion automatically starts the next queued poster.
- Catalog snapshot hydration now warms 3 rows / up to 21 ordered poster identities without
  tying network work to every Siri Remote focus event.
- Hydration remains source-byte-only; visible cards still perform exact display-sized decode.
- Spotlight Hub related cards prefer compact themed title logos when available, with title
  text as fallback.
- Spotlight Hub proactively hydrates its three related artwork/logo pairs after the related
  snapshot arrives.
- Existing stable renderedRows snapshot, hidden-work guards, v316 UNITY root restoration,
  preview architecture, trailers, VOD and Live TV playback are preserved.

Validation performed here:
- swiftc frontend parse across all Swift source files.
- project version metadata synchronization.
This is not a full Xcode/tvOS semantic build.
