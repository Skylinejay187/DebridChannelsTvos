Debrid Channels tvOS v20

Ready-to-upload repo package. GitHub Actions builds the unsigned tvOS IPA from the embedded source zip.

Fixes v19 CatalogStore compile errors and preserves Android-style hero/menu structure.
