# APP-WIDE REGRESSION LOCKS — vBRDC190

These locks are additive to all prior packaged regression locks.

1. **Donor lock** — vBRDC190 is derived only from packaged vBRDC189.
2. **Player-engine behavior lock** — removing the VOD `Player Engine` chip must not remove or alter KSPlayer/AVPlayer engine support, compatibility logic, engine settings, or playback routing.
3. **Even-rail lock** — the vBRDC189 non-scrolling mathematically-even VOD control rail must remain non-scrolling. Focus movement may scale/glow the focused chip but must not pan the rail.
4. **Video-Fit lock** — the vBRDC189 Video Fit & Aspect Ratio chip and all of its picture-geometry modes remain available and must not restart playback.
5. **Single-owner Media Info feature lock** — Production & Ratings and Collector Showcase may never render enabled together. Valid states are Off, Production & Ratings, or Collector Showcase.
6. **Collector lifecycle lock** — Collector Showcase artwork rotation/fetch work is scoped to the optional foreground Media Information feature and must not become always-on VOD background work.
7. **Playback publication lock** — Collector Showcase foreground artwork may publish during active VOD playback without reopening/replacing the playing source.
8. **Fallback lock** — missing specialty artwork must degrade to collection/key art/title-logo fallback rather than a permanently blank right-side panel.
9. **Live TV isolation lock** — Collector Showcase is a VOD Media Information option only and must not change Live TV playback geometry or guide behavior.
10. **Icon lock** — vBRDC188 approved main icon remains byte-identical in vBRDC190.
11. **Catalog UNITY lock** — Home / Movies / TV Shows playback catalog browsing and vBRDC187 identity-strict themed-logo ownership remain untouched.
12. **No mockup/design generation** — this build is source implementation only.
