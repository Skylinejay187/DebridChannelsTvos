# Debrid Channels tvOS v606 — Rollback Player + Upcoming Episode Alert Fix

Base: v602_COMPILE_FIX_READY_UPLOAD

Scope:
- Reverted the v603/v605 VOD player-path/audio-option experiments by rebuilding from v602.
- Restored the prior Debrid Channels / Streaming Catalogs / Movies / Shows logo sizing from v602.
- Restored v602 play/pause-center-button behavior and playback cadence path.
- Fixed new episode alert selection so it ignores the highlighted season and resolves from the full fetched episode list.
- Alert target now uses math for the upcoming episode in the latest known season: highest known season/episode + 1 episode.

Untouched:
- Membership
- Sports
- Trailers
- Channels DVR / TVE
- Backup / Restore
- Backend
