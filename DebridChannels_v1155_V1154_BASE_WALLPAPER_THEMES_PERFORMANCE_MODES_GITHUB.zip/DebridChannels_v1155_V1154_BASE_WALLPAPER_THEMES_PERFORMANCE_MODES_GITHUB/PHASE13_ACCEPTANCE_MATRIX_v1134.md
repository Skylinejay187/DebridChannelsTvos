# Phase 13 Acceptance Matrix — v1134

This is the pre-production Phase 13 gate. Phase 15 performs the final production matrix.

- [ ] GitHub Actions Xcode/tvOS build succeeds.
- [ ] App launches with rollout lane Internal Testing.
- [ ] Normal VOD startup reaches genuine first frame.
- [ ] Automatic source failover remains pre-first-frame only.
- [ ] Alternate Audio prepare/handoff/restore remains session-owned.
- [ ] Unrecoverable Alternate Audio failure restores original source.
- [ ] Emergency Disable Experimental Playback disables experimental playback and survives relaunch.
- [ ] Restore Stable UI Defaults clears the Phase 13 kill switch without deleting user data.
- [ ] Embedded audio/subtitle switching remains correct.
- [ ] Subtitle delay and per-title memory remain correct.
- [ ] Resume/history remains background-persisted.
- [ ] Up Next remains exact-episode owned.
- [ ] Search/Favorites focus restoration remains correct.
- [ ] Live TV guide/Gracenote/playback remain correct.
- [ ] Trailers retain complete video/audio behavior.
- [ ] Episode alerts continue during VOD.
- [ ] Phase 11 problematic codec samples are retested.
- [ ] Phase 12 Playback Health recovery controls remain correct.
- [ ] v1133 long-session memory test remains improved/plateaus.
- [ ] Cast Explorer opens only after explicit cast selection.
- [ ] Cast Explorer shows the exact TMDB person when person ID is available.
- [ ] Cast Explorer movies/TV/upcoming rows populate with a configured TMDB key.
- [ ] Cast Explorer closes without changing playback position/state.
- [ ] Cast Explorer Wikidata facts do not attach to a conflicting birth year.
- [ ] Net worth is hidden when no verified USD Wikidata value exists.
- [ ] Backend v674 restart/recovery remains healthy.
- [ ] v1133 + backend v674 rollback remains available.
