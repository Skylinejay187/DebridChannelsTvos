# v1141 Phase 15 Physical Apple TV Test Matrix

1. **Cast Explorer focus chrome** — Focus Known For/Movie/TV cards. Only restrained Debrid Channels focus should appear; no large white system platter.
2. **Cast Explorer vertical return** — Move down through multiple credit sections, then press UP from a credit rail. The view must return to the cast member image/information and remain navigable.
3. **VOD scrubber** — From the VOD control chips/collapsed controls, press UP to the scrubber. Featured Cast must not steal focus. Left/right must scrub only after timeline focus is established.
4. **Live amplification** — During active KSPlayer VOD, cycle Off/+3/+6/+9/+12 dB. Picture, timestamp, source URL, play state, subtitles, audio track, and player surface must remain continuous with no restart/reload.
5. **All seasons** — Open Full Episode Browser while playing a mid-season episode such as Reacher S03E03. Confirm Season 1 through the newest available normal season and every returned episode are accessible.
6. **Cast movie source picker** — Open Cast Explorer, choose another movie, confirm switch. Source Intelligence picker must appear; selecting a dead source must leave current playback paused/unchanged and permit another choice.
7. **Cast TV source picker** — Choose another TV series from Cast Explorer. Full Episode Browser opens first; choose an episode, confirm, then select exact source in Source Intelligence.
8. **Source-state isolation** — Cancel a Cast Explorer source selection and return to current VOD. Current title Source Intelligence/Alternate Audio state must remain intact.
9. **Automatic resume** — Play beyond 8 seconds, exit, reopen the exact same title/episode and same link. Playback must begin/seek to the saved timestamp rather than 0:00. Progress is not considered restored until real player clock confirms it.
10. **Resume + failover** — With saved progress, force a pre-first-frame source failure. Replacement source should retain the same resume target and the existing failover indicator.
11. **Regression** — Verify audio/subtitle track memory, subtitle delay, source memory, Alternate Audio, Phase 8 Up Next, Live TV Top/Bottom Quick Guide, favorites/search, and VOD overlay controls remain operational.
