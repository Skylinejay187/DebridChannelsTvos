# v1147 GitHub Compile Correction Audit

## Base
- Built only from packaged v1146.
- App version: 1.0.675 (build 675).
- Backend remains v674 unchanged.

## GitHub Actions failure in v1146
The uploaded GitHub Actions log shows two actual compiler errors, both in `Sources/Phase15FinalIntegration.swift`:

1. Line 338, `Phase15EpisodeCard.body`: Swift compiler unable to type-check the expression in reasonable time.
2. Line 558, `Phase15VODSourcePickerRow.body`: Swift compiler unable to type-check the expression in reasonable time.

The remaining PlaybackKit output in the log is warnings only. The build fails because those two Phase 15 SwiftUI expressions became too large after the platter-free focus conversion.

## Correction
No v1146 playback behavior was rolled back. The two failing SwiftUI expressions were decomposed into smaller typed stages:

- `Phase15EpisodeCard`
  - `accessibleCard`
  - `animatedCard`
  - `interactiveCard`
  - `cardSurface`
  - `artworkSurface`
  - separate background/border views

- `Phase15VODSourcePickerRow`
  - `accessibleRow`
  - `animatedRow`
  - `interactiveRow`
  - `rowSurface`
  - `sourceBadges`
  - separate colors/background/border/accessibility label

This preserves the same focusable custom content, Select actions, focused scale/animation, visual styling, and accessibility behavior while giving the Swift compiler substantially smaller expressions to type-check.

## Locked v1146 behavior preserved
All Swift source files other than `Phase15FinalIntegration.swift` are byte-identical to packaged v1146, including:

- automatic real-clock resume correction
- 3-attempt in-place resume verification
- 5-second resume progress persistence
- 90 ms automatic LEFT/RIGHT timeline seek
- PlaybackKit KSPlayer surface
- resume cache
- per-title playback memory
- UniversalCodecSupport
- automatic failover
- CatalogStore
- trailer service

Phase 15 remains Button-free for the Full Episode Browser/source picker focus path, so the white tvOS system platter correction is preserved.

## Local validation
- Swift parse: 52/52 files passed.
- Static/version/hash contracts: 30/30 passed.
- Xcode/tvOS GitHub Actions remains the authoritative full type-check/build test.
