# v1140 GitHub Build Error Analysis

## Failure from uploaded GitHub Actions log

The v1139 archive was extracted and XcodeGen/project discovery completed. KSPlayer compiled far enough to emit warnings, and the app target entered Swift compilation.

The actual blocking compiler diagnostic was:

`Sources/DebridChannelsTVOSApp.swift:23131:25: error: the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

This occurred in `V1111FeaturedCastPosterCard.body`, where Phase 15 Cast Explorer interaction had extended an already-large SwiftUI view into one generic expression containing:
- layout;
- two `.task` modifiers;
- cast-index normalization;
- tvOS focus ownership;
- focus-request handling;
- tap selection;
- focus decoration;
- accessibility modifiers.

## v1140 correction

The exact behavior was retained but decomposed into separately type-checked stages:
- `presentationLayout`
- `taskManagedPresentation`
- `focusManagedPresentation`
- `decoratedPresentation`

The two async task bodies and focus/tap handlers were also moved into named helper functions. This removes the Release compiler's single-expression inference bottleneck without changing:
- 4-second initial full-poster hold;
- 7-second cast rotation;
- focus ownership rules;
- compact/full Featured Cast modes;
- Cast Explorer Select action;
- accessibility behavior.

## Scope

v1140 is a corrective build from packaged v1139 only. No backend, KSPlayer vendor, source-resolution, Live TV, trailer, Alternate Audio, catalog, Search, Favorites, or Phase 15 service file was changed by the compile correction.
