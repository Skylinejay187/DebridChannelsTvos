# v1051 Physical Apple TV Checklist — Popup Artwork and VOD Input States

## Popup artwork

- Enable Connected Popup Background Artwork.
- Open movie details and confirm artwork is contained within all four rounded panel edges.
- Confirm no image or tint appears outside the connected popup.
- Confirm artwork preserves its aspect ratio without stretching.
- Close/reopen details while switching between Artwork and Transparent.

## Overlay hidden

- Start VOD and let the overlay disappear.
- Press Left once: playback moves back 30 seconds and the main overlay stays hidden.
- Press Right once: playback moves forward 60 seconds and the main overlay stays hidden.
- Repeat several times and confirm each command is applied immediately.

## Overlay visible, drawer collapsed

- Show the VOD overlay with the shelf collapsed.
- Confirm the chevron—not the scrubber—is focused.
- Confirm the scrubber dot has no focus halo.
- Press Left/Right and confirm the scrubber does not move.
- Press Up or Select and confirm the drawer opens without changing playback time.

## Drawer expanded

- Move Up from the control shelf to the scrubber.
- Press Left/Right and confirm preview movement is visible.
- Press Select to commit and confirm one seek occurs.
- Open/close the drawer without touching Left/Right and confirm no seek occurs.

## Regression

- Verify Resume, Restart, Back 30, Forward 60, Audio, Subtitles, Episodes, Player Engine, External Player, and Settings.
- Verify current time remains on the left and Featured Cast remains isolated on the right.
- Verify built-in catalogs still bootstrap/recover and the All-in-One toggle remains functional.
