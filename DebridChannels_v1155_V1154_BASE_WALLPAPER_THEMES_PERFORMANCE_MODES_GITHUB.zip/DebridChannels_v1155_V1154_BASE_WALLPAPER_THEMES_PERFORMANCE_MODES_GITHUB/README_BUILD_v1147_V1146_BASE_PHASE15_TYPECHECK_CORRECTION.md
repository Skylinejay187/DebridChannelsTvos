# Debrid Channels v1147 — v1146 Phase 15 Type-Check Correction

- Marketing version: **1.0.675**
- Build: **675**
- Base: **packaged v1146 only**
- Backend: **v674 unchanged**

v1147 is a compile-only correction for the two `Phase15FinalIntegration.swift` SwiftUI expressions reported by GitHub Actions. It does not roll back v1146 automatic resume, platter-free VOD focus, or automatic scrub seeking.

The episode card and source-picker row were decomposed into smaller helper views/modifier stages so Swift can type-check them within Xcode's limit while preserving runtime behavior.

Validation artifacts:
- `BUILD_ERROR_AUDIT_v1147.md`
- `SWIFT_PARSE_v1147.log`
- `STATIC_CONTRACT_v1147.log`
- `VALIDATION_RESULTS_v1147.json`
