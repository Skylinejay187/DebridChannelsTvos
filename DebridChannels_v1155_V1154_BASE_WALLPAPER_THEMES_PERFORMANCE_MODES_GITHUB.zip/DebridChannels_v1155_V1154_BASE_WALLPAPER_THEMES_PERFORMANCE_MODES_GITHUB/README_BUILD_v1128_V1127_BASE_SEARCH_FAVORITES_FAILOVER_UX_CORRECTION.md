# Debrid Channels v1128 — Search/Favorites/Automatic Failover UX Correction

## Base discipline

- Built only from the packaged v1127 Phase 9 GitHub workflow ZIP.
- Marketing version: 1.0.656
- Build: 656
- No Phase 10 security work is started in this candidate.
- No new backend change is introduced. Preserve the Phase 9 backend v670 integration/runtime patch associated with v1127.
- Navigation Sounds remain removed.

## Corrections

### Automatic source failover indication

Phase 6 failover was already functioning, but the existing notice was only internal loading/status state and could disappear too quickly when the replacement rendered. v1128 adds a dedicated non-interactive VOD banner:

`Source unavailable — trying the next ranked link • ranked source X of Y`

The banner remains visible for approximately 3.2 seconds even if the replacement reaches stable first frame immediately. It does not alter failover ranking, playback URLs, KSPlayer, player clocks, or post-first-frame switching policy.

### Search → Favorites persistence

The existing `favoriteMediaIds` key was being written correctly. The failure was reconstruction: Global Favorites rebuilt movie/show objects only from currently loaded `store.rows`, so a Search-only result could have a saved key but no object to display.

v1128 preserves `favoriteMediaIds` as the authoritative key and adds `favoriteMediaSnapshotsV1` only as a compact object fallback. When a title is favorited, a bounded snapshot is saved without franchise recursion. Global Favorites continues to prefer current catalog rows, then appends a persisted Search-only favorite only when no loaded catalog item represents it. Removing a favorite removes its snapshot as well.

### Search Media Information focus isolation

Search results remain mounted so query/results and exact focused card can be restored after Details or playback. While a Search-owned media-information view is open, however, the Search grid is now disabled, removed from hit testing, and hidden from accessibility focus. Directional input can no longer scroll Search behind the detail.

Search media information now uses an opaque full-screen Search-owned stage with a restrained selected-title backdrop and centers the existing Media Information panel. Closing it returns to the exact Search query/results/focus state.

## Preserved systems

The following remain byte-identical to packaged v1127:

- PlaybackKit KSPlayer surface/foundation
- Tapframe KSPNUVIO package
- AutomaticSourceFailoverManager policy
- Source Intelligence manager
- Alternate Audio bridge/discovery/cancellation clients
- Playback resume persistence
- Phase 7 playback memory
- Trailer service
- Live TV guide cache/Gracenote persistence
- Universal codec support
- CatalogStore resolver/catalog logic
- VOD production metadata
- Episode alerts

The v1126/v1127 UI behavior is retained, including centered Live TV information, Top Quick Guide / Bottom Quick Guide, and the two VOD themed-logo controls.

## Local validation

- Swift syntax parsing: 46/46 source files passed.
- App + Top Shelf plists: 1.0.656 / 656.
- Project base and target version settings: 1.0.656 / 656.
- Search Favorites persistence contract: 8/8.
- Search modal focus contract: 8/8.
- Automatic failover indicator contract: 8/8.
- Protected systems hash comparison: 15/15 byte-identical.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV behavior is not claimed until tested by the user.
