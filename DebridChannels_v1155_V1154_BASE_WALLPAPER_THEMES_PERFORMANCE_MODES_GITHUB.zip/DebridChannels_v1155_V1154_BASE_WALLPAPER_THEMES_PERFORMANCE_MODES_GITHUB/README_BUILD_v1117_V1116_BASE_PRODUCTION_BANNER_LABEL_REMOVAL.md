# Debrid Channels v1117 — Production Banner Label Removal

- Base: v1116 only
- Marketing version: 1.0.645
- Build: 645
- Backend: continue using v669; no backend update is required

## Change

The visible **PRODUCTION & RATINGS** capsule and building icon were removed from the rotating Production & Ratings banner because they covered artwork. The banner now remains unobstructed except for the existing transparent title clearlogo and optional production-company logo/name. All production facts below the banner remain unchanged.

## Preserved

- 138-point banner canvas
- Full visible aspect-fit artwork
- Exact 7-second artwork rotation
- Persistent artwork index across overlay hide/show
- Budget, box office, runtime, status, rating, date, country, language, studio/network facts
- v1116 long-season scrolling and Artwork 4 / Hero 2 quality fix
- Phase 6 failover and all playback systems

GitHub Actions remains the authoritative Xcode/tvOS compilation test.
