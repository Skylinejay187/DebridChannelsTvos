# Debrid Channels v1135 — Phase 13 Cast Explorer Compile Fix

**Marketing version:** 1.0.663  
**Build:** 663  
**Base:** packaged v1134 only  
**Backend:** v674 unchanged  

## GitHub failure corrected

The attached GitHub Actions log shows one real Swift compiler blocker in the v1134 application target:

`DebridChannelsTVOSApp.swift:22077:48: error: 'controlSize' is unavailable in tvOS`

The failing expression was `ProgressView().controlSize(.large)` inside Cast Explorer's loading presentation. v1135 removes only the unavailable modifier and retains `ProgressView()`. The adjacent KSPNUVIO/AVFoundation diagnostics in the log are warnings and were not the build failure.

## Scope discipline

v1135 is a Phase 13 compile-fix replacement. Phase 14 features are not stacked into this candidate. Cast Explorer pause/resume behavior, Media Information entry, expanded person data, accessibility polish, and Audio Boost are recorded in `PHASE14_LOCKED_REQUIREMENTS_FROM_V1135.md` for the next phase after this build passes.

## Local validation

- 51/51 application Swift files passed `swiftc -parse`.
- Both app and Top Shelf plists validate as 1.0.663 / 663.
- `project.yml` contains 1.0.663 / 663 for both relevant targets.
- Zero `controlSize(.large)` references remain in Swift sources.
- Backend v674 is unchanged.
- GitHub Actions remains the authoritative tvOS/Xcode compilation test.
