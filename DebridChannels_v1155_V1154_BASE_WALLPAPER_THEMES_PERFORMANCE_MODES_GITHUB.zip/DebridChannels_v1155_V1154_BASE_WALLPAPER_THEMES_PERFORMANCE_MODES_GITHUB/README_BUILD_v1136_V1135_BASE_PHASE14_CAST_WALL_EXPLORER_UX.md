# Debrid Channels v1136 — Phase 14 Cast Wall / Cast Explorer / UX

- Base: packaged v1135 only
- Marketing version: 1.0.664
- Build: 664
- Backend: v674 unchanged
- Audio amplification: intentionally deferred to Phase 15

## Phase 14 corrections

### VOD Cast Wall
- The one-time four-second full-poster title hold is now playback-presentation-owned rather than transient-view-owned.
- The hold is claimed before sleeping, so hiding/remounting the VOD overlay cannot restart the delay.
- Cast cycling is an overlay-gated cancellable async task instead of a permanently autoconnected Timer publisher.
- The current cast index remains player-owned and survives VOD overlay hide/show.
- Cast is now an explicit VOD focus zone. UP navigation can request the Cast Wall directly rather than allowing the control scroller/scroll container to compete for focus.
- Focusing the full-poster Cast Wall during the initial title hold immediately reveals the cast surface.
- Parent VOD Select handling does not steal focus back from the Cast Wall.

### Cast Explorer playback ownership
- Selecting a cast member during VOD records whether playback was actually playing, then pauses it.
- Siri Remote Play/Pause is ignored while Cast Explorer is open.
- DPAD/Select are isolated from seeking and VOD controls while Cast Explorer owns the screen.
- Back/Close resumes only if playback was playing before Cast Explorer opened; pre-paused playback stays paused.
- No player rebuild, source switch, seek, Alternate Audio mutation, subtitle change, or audio-session change is introduced.

### Media Information → Cast Explorer
- Movie and series Media Information cast rows are now navigable/selectable.
- Selecting a visible cast member opens the same Cast Explorer service used by VOD.
- This route has no playback ownership and never touches KSPlayer/player state.
- Cast Explorer work is cancelled on title change/disappear/close.

### Expanded person information
- Complete available TMDB movie and TV acting credits are retained rather than capped at 24 titles.
- Upcoming credits are retained rather than capped at 16 titles.
- Existing biography, birthday/age, birthplace, profession, popularity, education, awards, citizenship, sourced USD net-worth statement, Known For, Movies, TV Shows, and Upcoming remain.
- Open Wikidata enrichment now also supports documented spouse, partner, children, parents, and siblings.
- Absence of relationship data is not interpreted as “single”; Debrid Channels does not invent relationship status or net worth.

### Accessibility/UX
- Media Information cast cards receive meaningful accessibility labels/hints.
- Cast Explorer remains a contained focus environment with a deterministic Close action.
- The Cast Wall focus path is explicit rather than relying on tvOS to choose between the cast surface and a scroll container.

## Preserved systems

19 protected playback/catalog/backend-facing source files are byte-identical to v1135, including KSPlayer/KSPNUVIO surfaces, Phase 11 codec compatibility, Source Intelligence, Alternate Audio clients, trailer service, Live TV guide cache, Production & Ratings service, CatalogStore, resume/history, per-title playback memory, episode alerts, Phase 6 failover, Release Stability memory management, and the Phase 12 Discovery panel.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV behavior is not claimed until tested.
