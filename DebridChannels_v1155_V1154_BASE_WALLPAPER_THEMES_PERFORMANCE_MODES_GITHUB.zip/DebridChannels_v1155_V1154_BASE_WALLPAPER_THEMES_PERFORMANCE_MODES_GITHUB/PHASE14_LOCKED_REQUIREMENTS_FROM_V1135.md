# Phase 14 locked requirements carried from v1135

- Cast Explorer must open from both Media Information cast and VOD Featured Cast.
- Opening Cast Explorer from Media Information must not initialize or touch playback.
- If VOD is actively playing when a cast member is selected, pause the existing player before Cast Explorer presentation.
- Record whether playback was actually playing before the explorer opened.
- Exiting Cast Explorer resumes only when it had been playing beforehand; if it was already paused, it stays paused.
- Cast Explorer must never rebuild KSPlayer, seek, alter the playback clock, change source, audio/subtitle selection, Alternate Audio state, or failover state.
- Expand person information: full filmography, TV credits, upcoming projects, roles, biography, age/birthday/birthplace, popularity, occupations, awards, education, public spouse/partner/relationship data, publicly documented children/family, and sourced net-worth statements when available. Never infer or fabricate missing personal facts.
- Add Phase 14 Audio Boost only after inspecting the active KSPNUVIO/KSPlayer audio path; default Off and protect against clipping.
- Phase 14 begins only after v1135 passes GitHub Actions and physical Apple TV smoke testing.
