# Debrid Channels v1137 — Phase 14 Cast Card Type-Check Compile Fix

- Base: packaged v1136 only
- Marketing version: 1.0.665
- Build: 665
- Backend: v674 unchanged
- Roadmap phase: Phase 14 corrective replacement

## GitHub Actions failure from v1136

The authoritative Xcode/tvOS workflow reached app compilation and failed at `Sources/DebridChannelsTVOSApp.swift:9031` in `CompactHeroCastCard.body` with:

`the compiler is unable to type-check this expression in reasonable time; try breaking up the expression into distinct sub-expressions`

No second Swift compiler error was present in the supplied workflow log. KSPlayer/AVFoundation messages around the failure were warnings.

## Correction

The existing `CompactHeroCastCard` presentation was preserved but decomposed into small typed SwiftUI subexpressions: avatar, role text, text block, card content, background, border, sizing constants, and accessibility text. The focus scale, orange selected border, shadow, dimensions, typography, image/fallback initials, role line, accessibility label, and Cast Explorer hint remain functionally equivalent.

This is a compile-fix replacement only. It does not alter Cast Wall cycling, Cast Explorer pause/resume ownership, Media Information Cast Explorer routing, KSPlayer/KSPNUVIO, codec compatibility, Source Intelligence, Alternate Audio, VOD playback, Live TV, Phase 13 rollout protection, or backend behavior.

## Local validation

- 54/54 Swift files: syntax parse passed.
- Both plists: 1.0.665 / 665.
- project.yml: 1.0.665 / 665 for the app/extension targets.
- Exactly four original v1136 files changed: the app source containing the failing card and the three version-bearing files.
- Final archive extraction and complete package hash verification passed.

GitHub Actions remains the authoritative Xcode/tvOS compilation test. Physical Apple TV behavior is not claimed until user testing.
