# v1149 Deep Audit — Connected Popup Artwork + Sports Direct Tune

Base: packaged v1148 only  
Marketing version: 1.0.677  
Build: 677  
Backend: unchanged from v1148 (v674)

## 1. Connected Popup Background Artwork

The Appearance toggle itself was not broken. `connectedMediaPopupArtworkEnabled` was correctly stored and read by `MediaInfoPopup`. The visible layer had been reduced to an almost imperceptible presentation: the connected popup rendered its artwork at only 0.055 opacity and then used `.blendMode(.screen)` over an otherwise transparent/dark glass panel.

v1149 keeps the same setting key and artwork identity path, but makes the enabled state visibly meaningful:

- contained artwork remains clipped to the exact 860×858 connected popup silhouette;
- saturation is raised to 0.92 and contrast to 1.08;
- artwork opacity is raised to 0.34;
- the screen blend is removed;
- a controlled black readability gradient is layered over the image so metadata remains legible;
- Search-owned media information now also obeys the same On/Off setting rather than drawing its background artwork regardless of the toggle.

When the setting is Off, the connected popup does not mount the artwork layer.

## 2. Sports live-channel routing

Root cause: `SportsFoundationQuickPanelSurface` uses `GridOSFixedSlotCatalogRail`, the same generic rail used for movie/show cards. Both Select and Play/Pause call `openSelected()`. That function unconditionally called `store.openDetail(...)` for every item except the Sports removal row. Sports channels produced by `SportsCenterViewModel` are `MediaItem(type: "live")` with their real stream URL stored in `previewURL`, so they were incorrectly routed into VOD Media Information/Source Intelligence.

v1149 adds one narrow route before `openDetail`:

- only while `store.selectedTab == .sports`;
- only for `selectedItem.type == "live"`;
- validate the existing live `previewURL`;
- call `store.startPlayback(...)` directly;
- return before VOD Media Information can open.

Because both Select and Play/Pause already converge on `openSelected()`, both controls now tune a real Sports channel immediately. Non-live Sports cards and actual movie/show VOD items retain their existing information/detail behavior.

## 3. Protected systems

The following v1148 functions were compared text-for-text and are unchanged:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`

Protected source files verified byte-identical to v1148 include PlaybackResumeCache, AutomaticSourceFailoverManager, PerTitlePlaybackMemory, UniversalCodecSupport, both PlaybackKit core files, Phase15FinalIntegration, CatalogStore, TrailerServiceManager, and SportsCenterViewModel.

## 4. Local validation

- Swift parse: 55/55 passed.
- Static/preservation contracts: 40/40 passed.
- Only four inherited files changed before validation/audit artifacts were added:
  - `Sources/DebridChannelsTVOSApp.swift`
  - `Sources/Info.plist`
  - `TopShelfExtension/Info.plist`
  - `project.yml`

GitHub Actions/Xcode and physical Apple TV testing remain authoritative for full compilation and runtime behavior.
