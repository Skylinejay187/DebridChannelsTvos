# v1144 Physical Apple TV Test Matrix

Run this after GitHub Actions compiles v1144. Do not promote Phase 15 solely from local validation.

## 1. Automatic resume — highest priority

1. Play a VOD title from a direct source for at least 2–3 minutes.
2. Exit normally so progress is saved.
3. Confirm Media Information still shows the expected progress percentage.
4. Reopen **the same source/link**.
5. Expected: playback automatically jumps to the saved timestamp rather than beginning from 0:00.
6. Repeat after fully leaving the title and after relaunching the app.
7. Repeat on a series episode.
8. Verify a title watched past the completion threshold still clears resume as before.

## 2. Full Episode Browser focus

- Open Full Episode Browser during VOD playback.
- Focus Close, All Seasons, each season, and multiple episode cards.
- Expected: no white system platter/background. Focus is restrained orange/dark.
- Move repeatedly across rows and seasons; no large white card should appear.

## 3. Episode Browser performance

- Browse a long show with several seasons.
- Hold LEFT/RIGHT and move UP/DOWN through multiple visible rows.
- Switch All Seasons → several seasons → All Seasons.
- Type and clear episode searches.
- Expected: focus remains responsive; no full-grid animation/reflow on each focus move.
- Verify every available season/episode still appears.

## 4. Overlay hide playback continuity

- During smooth VOD playback, reveal/hide the overlay at least 20 times.
- Include natural 15-second auto-hide cycles.
- Expected: no recurring single-frame skip/hitch immediately after chrome disappears.
- Repeat while the overlay has loaded Featured Cast/Production artwork.

## 5. Cast Explorer scope

- Media Information: cast is visible but not focusable/clickable and cannot open Cast Explorer.
- VOD overlay: Featured Cast remains focusable when the VOD router owns that zone and still opens Cast Explorer.
- Cast Explorer credit selection and Source Intelligence source picker still work.

## 6. Volume amplification regression

- While VOD is actively playing, cycle Off/+3/+6/+9/+12 dB.
- Expected: audible gain changes without timestamp reset, source reload, KSPlayer recreation, first-frame/loading screen, or HDMI re-handshake.
- Live TV and trailers remain unaffected.

## 7. Source switching / failover

- Choose a Cast Explorer movie/show/episode and select a ranked source.
- Verify current playback remains protected until confirmation/source selection.
- Verify automatic pre-first-frame source failover and its visible fallback notice still behave as before.
