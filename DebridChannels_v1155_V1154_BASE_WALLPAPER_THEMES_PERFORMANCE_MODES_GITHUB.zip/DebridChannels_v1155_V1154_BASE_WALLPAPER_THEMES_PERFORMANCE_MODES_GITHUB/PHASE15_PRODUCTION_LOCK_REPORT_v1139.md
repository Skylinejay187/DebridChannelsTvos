# v1139 Phase 15 Production Lock Report

## Candidate state

v1139 / 1.0.667 / 667 is a **Phase 15 release candidate**, not a Stable release yet.

The package was derived only from the supplied v1138 source ZIP. Backend v674 is unchanged. v1138 remains the rollback candidate until authoritative build and physical acceptance gates pass.

## Promotion policy

The app's rollout manager remains fail-closed. Phase 15 advances the acceptance-matrix contract to revision 2 but does **not** call `setChannel(.stable)` or auto-enable risky playback features.

Stable promotion requires:

1. Successful GitHub Actions tvOS/Xcode build.
2. Complete physical Apple TV execution of `PHASE15_FINAL_REGRESSION_MATRIX_v1139.md`.
3. No unresolved crash, focus, audio/video sync, handoff, Search/Favorites, guide, relaunch, backend-restart, or rollback regression.

## Release-critical Phase 15 additions

- Searchable/clickable Cast Explorer credits using canonical TMDB identities.
- Media Information cast-credit navigation through the existing details stack.
- In-VOD cast-credit movie/show switching with explicit viewer confirmation.
- Full provider-backed VOD episode browser with search and dynamic season filtering.
- Confirmed in-VOD exact episode switching through existing source ranking/playback publication.
- VOD-only Off/+3/+6/+9/+12 dB amplification using the pinned KSPNUVIO FFmpeg audio-filter graph.
- Updated acceptance matrix and final QA audit metadata.

## Deep-audit fixes before packaging

- Added missing XcodeGen target membership for the new Phase 15 source file.
- Removed the obsolete fake eight-season VOD panel and its stale selected-season state.
- Made unknown/corrupt persisted amplification values fail closed to Off.
- Confirmed no new Navigation Sounds code is active.
- Confirmed no original v1138 file was removed.
- Confirmed 20 release-sensitive protected files are byte-identical to v1138.

## Production lock

Until the two authoritative gates pass:

- Do not mark v1139 Stable.
- Keep v1138 available for immediate rollback.
- Keep backend v674 deployed unless an independently verified backend issue requires a new backend candidate.
- Do not begin unrelated feature work.
- Do not remove existing emergency/experimental rollback controls.
- Do not use `docker compose down -v`.
