# Compile-correction note

v1140 is built only from the packaged v1139 candidate. It changes no Phase 15 feature contract. It decomposes the Featured Cast/Cast Explorer SwiftUI modifier chain that Xcode could not type-check in reasonable time, then advances the app/Top Shelf version to 1.0.668 (668). Physical Apple TV acceptance remains required.

# v1140 Phase 15 Final Regression Matrix

Status vocabulary:

- **LOCAL PASS** — source/package/static contract validated in this build workspace.
- **GITHUB PENDING** — authoritative Xcode/tvOS compile must pass in GitHub Actions.
- **PHYSICAL PENDING** — behavior must be exercised on the physical Apple TV before Stable promotion.

| Acceptance area | Local result | Required physical test before Stable |
|---|---|---|
| Normal movie VOD startup / genuine first frame | LOCAL PASS — protected playback path unchanged | PHYSICAL PENDING |
| Normal TV episode startup / exact episode identity | LOCAL PASS — protected playback path unchanged | PHYSICAL PENDING |
| Manual movie link/source switch | LOCAL PASS — Source Intelligence protected | PHYSICAL PENDING |
| Manual show/episode link switch | LOCAL PASS — existing handoff + new confirmed episode path | PHYSICAL PENDING |
| Clock advancement after every handoff | LOCAL PASS — generation/clock guards retained | PHYSICAL PENDING |
| Pause/resume | LOCAL PASS — no core toggle path rewrite | PHYSICAL PENDING |
| Repeated seeking / scrubber resume | LOCAL PASS — Phase 14 path preserved | PHYSICAL PENDING |
| Embedded audio switching | LOCAL PASS — track plumbing preserved | PHYSICAL PENDING |
| Alternate Audio discovery/prepare/handoff/restore | LOCAL PASS — protected clients byte-identical | PHYSICAL PENDING |
| Subtitle switching | LOCAL PASS — protected renderer/selection path | PHYSICAL PENDING |
| Subtitle delay and exact episode memory | LOCAL PASS — protected per-title memory path | PHYSICAL PENDING |
| Resume playback / background persistence | LOCAL PASS — persistence files byte-identical | PHYSICAL PENDING |
| Automatic source failover | LOCAL PASS — Phase 6 manager byte-identical | PHYSICAL PENDING; verify no post-first-frame silent switch |
| Up Next | LOCAL PASS — existing Phase 8 path retained | PHYSICAL PENDING |
| Trailer playback and trailer audio | LOCAL PASS — TrailerServiceManager byte-identical | PHYSICAL PENDING |
| Episode alerts while VOD plays | LOCAL PASS — NewEpisodeAlertsManager byte-identical | PHYSICAL PENDING |
| Search details/return restoration | LOCAL PASS — no Phase 15 Search focus rewrite | PHYSICAL PENDING |
| Search-only Favorites persistence | LOCAL PASS — v1128+ behavior retained | PHYSICAL PENDING |
| Full-width catalog rows | LOCAL PASS — no catalog layout rewrite | PHYSICAL PENDING |
| First-card row entry | LOCAL PASS — focus policy preserved | PHYSICAL PENDING |
| Exact-card popup return | LOCAL PASS | PHYSICAL PENDING |
| Exact-card playback return | LOCAL PASS | PHYSICAL PENDING |
| Guide startup | LOCAL PASS — guide cache protected | PHYSICAL PENDING |
| Live TV playback / Gracenote persistence | LOCAL PASS — Live TV protected files unchanged | PHYSICAL PENDING |
| Top Quick Guide | LOCAL PASS — no Phase 15 change | PHYSICAL PENDING |
| Bottom Quick Guide | LOCAL PASS — no Phase 15 change | PHYSICAL PENDING |
| App relaunch | LOCAL PASS — rollout/persistence schemas parse | PHYSICAL PENDING |
| Backend v674 restart/recovery | LOCAL PASS — no backend changes in v1140 | PHYSICAL PENDING |
| Emergency kill switch / rollback | LOCAL PASS — Phase 13 acceptance schema v2; StableFeatureGate preserved | PHYSICAL PENDING |
| Phase 11 codec/container compatibility | LOCAL PASS — codec compatibility file byte-identical | PHYSICAL PENDING across approved codec matrix |
| Cast Explorer search | LOCAL PASS — 16/16 interaction contract | PHYSICAL PENDING |
| Cast Explorer credit selection from Media Information | LOCAL PASS — canonical MediaItem + normal openDetail path | PHYSICAL PENDING |
| Cast Explorer cross-title selection during VOD | LOCAL PASS — confirmation required before source resolution | PHYSICAL PENDING |
| Cancel cross-title switch | LOCAL PASS — current playback remains paused/unchanged | PHYSICAL PENDING |
| Confirm cross-title movie switch | LOCAL PASS — resolverReady + playFirstDirectStream | PHYSICAL PENDING |
| Confirm cross-title TV show switch | LOCAL PASS — TMDB TV identity + normal source path | PHYSICAL PENDING |
| Full Episode Browser loads real provider episodes | LOCAL PASS — fetchSeriesEpisodes only | PHYSICAL PENDING |
| Episode browser search by SxEy/title/description/date | LOCAL PASS — 18/18 contract | PHYSICAL PENDING |
| Episode browser season filtering | LOCAL PASS — dynamic real seasons | PHYSICAL PENDING |
| Episode browser playback confirmation | LOCAL PASS — shared VOD confirmation path | PHYSICAL PENDING |
| VOD Volume Amplification Off | LOCAL PASS — audioFilters cleared | PHYSICAL PENDING |
| VOD Volume Amplification +3/+6/+9/+12 dB | LOCAL PASS — pinned KSPNUVIO FFmpeg filter path verified | PHYSICAL PENDING; listen for clipping/distortion and A/V sync |
| Amplification while paused | LOCAL PASS — timestamp/play-state preservation coded | PHYSICAL PENDING |
| Amplification after seek | LOCAL PASS — authoritative timestamp used | PHYSICAL PENDING |
| Amplification with Alternate Audio bridge | LOCAL PASS — same KS audio-filter path | PHYSICAL PENDING |
| Live TV amplification isolation | LOCAL PASS — gain forced 0 | PHYSICAL PENDING |
| Trailer amplification isolation | LOCAL PASS — trailer excluded from VOD style | PHYSICAL PENDING |
| Navigation Sounds | LOCAL PASS — remains removed | PHYSICAL PENDING only to verify no residual click/audio path |
| Production & Ratings / logo controls / Featured Cast | LOCAL PASS — metadata files protected | PHYSICAL PENDING |

## Release gate

**GitHub Actions: PENDING**  
**Physical Apple TV matrix: PENDING**  
**Stable promotion: BLOCKED until both pass**  
**Rollback: v1138**  
**Backend: v674 unchanged**
