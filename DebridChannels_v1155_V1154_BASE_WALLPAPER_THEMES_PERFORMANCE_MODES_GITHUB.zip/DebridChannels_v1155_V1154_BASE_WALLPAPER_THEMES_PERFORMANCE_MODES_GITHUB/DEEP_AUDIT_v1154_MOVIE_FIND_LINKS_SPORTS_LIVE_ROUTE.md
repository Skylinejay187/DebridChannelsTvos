# Debrid Channels v1154 Deep Audit

**Marketing version:** 1.0.682  
**Build:** 682  
**Base:** packaged v1153 only  
**Backend:** v674 unchanged

## Physical findings addressed

1. A movie that resumed correctly from the normal Play button could lose the same resume point after opening **Find Links** and choosing another source.
2. Sports channels added automatically, assigned manually, or sourced from M3U could open generic **Media Information / Play / Find Links** instead of tuning the live stream.
3. Leaving Sports could retain transient detail/restore metadata that interfered with later Home/Live TV navigation.

## Movie Find Links resume root cause and correction

Find Links deliberately hydrates a title into `sourceSearchItem` so Source Intelligence can query stronger TMDB/IMDb/provider identities. The selected-source launch path then reused that hydrated item as the **playback item**, even though the normal Play path launched the original Media Information item. This allowed manual source selection to enter playback with a different identity than the path that created the resume checkpoint.

v1154 introduces `sourceSelectedPlaybackItem()` in the connected Media Information surface. For movies, the selected source now launches using the **original `item` identity exactly** (id, TMDB/IMDb/TVDB fields, title, year, type, catalog), while only non-identity artwork/credit metadata may be filled from the resolver item. Exact episodes continue using their selected episode object so season/episode identity stays precise.

Both direct HTTP source selection and debrid/infoHash resolution use this helper. The v1153 alias-capable `PlaybackResumeCache` remains byte-identical and now acts as compatibility protection rather than the primary bridge between two different movie launch identities.

## Sports direct-tune root cause and correction

`SportsCenterViewModel` already creates each matched M3U channel correctly as `MediaItem(type: "live", previewURL: channel.streamURL)`. However, `SportsHubScreen.sportsFoundationRows()` converted those real channel rows into a second layer of **league summary cards** (`type: "sports"`, `previewURL: nil`). Those summaries could only route to generic Media Information.

v1154 removes that summary-card indirection. The Sports quick panel now appends the classifier's real channel rows directly. Automatic sports matches, assigned groups, and manually added channel IDs therefore remain `type="live"` cards with their real stream URL.

Two direct-tune guards now apply:

- `GridOSFixedSlotCatalogRail.openSelected()` tunes **any** `type="live"` item directly; it no longer depends on `selectedTab == .sports`.
- `CatalogStore.openDetail()` has a central invariant: if a `type="live"` item with a URL reaches the generic detail API anyway, it bypasses Media Information and starts live playback immediately.

This makes the screenshot failure state (a real live M3U channel showing Play / Find Links) unreachable through normal app routing.

## Sports navigation cleanup

v1154 adds `CatalogStore.clearSportsPresentationStateForNavigation(reason:)`, which clears transient Sports/detail state when leaving Sports or when a live detail call is redirected to playback. It clears:

- selected detail and detail back stack
- detail hydration task/generation and presentation anchor
- Source Intelligence transient state
- quick-panel restore item/canonical/row/index/focus tokens
- stale Live TV quick-panel flag
- top-menu focus lock

Sports Back/Exit uses this cleanup before returning to Live TV. Selecting another top-menu tab while leaving Sports also uses it before the destination tab mounts.

## Explicit preservation

The following v1153 playback behavior is intentionally unchanged:

- `applyAutomaticResumeIfAvailable`
- `scheduleAutomaticResumeAfterSurfaceStart`
- `saveResumePositionIfNeeded`
- `switchToKSPlayerEngine`
- `seekAbsolute`
- `scrubTimelineAndSeek`
- `commitTimelineScrubIfNeeded`
- `startPlayerClock`

The working automatic LEFT/RIGHT scrubber therefore remains untouched.

Byte-identical protected files include `PlaybackResumeCache.swift`, `AutomaticSourceFailoverManager.swift`, `PerTitlePlaybackMemory.swift`, `UniversalCodecSupport.swift`, PlaybackKit core files, `Phase15FinalIntegration.swift`, `SportsCenterViewModel.swift`, and `TrailerServiceManager.swift`.

## Local validation

- Swift syntax parse: **54/54** files passed.
- Static / preservation contracts: **34/34** passed.
- App + Top Shelf plist versions: **1.0.682 / 682**.
- Only functional source files changed from v1153: `DebridChannelsTVOSApp.swift` and `CatalogStore.swift` (plus version files and v1154 audit/validation artifacts).

GitHub Actions/Xcode remains the authoritative tvOS compile, followed by physical Apple TV testing.
