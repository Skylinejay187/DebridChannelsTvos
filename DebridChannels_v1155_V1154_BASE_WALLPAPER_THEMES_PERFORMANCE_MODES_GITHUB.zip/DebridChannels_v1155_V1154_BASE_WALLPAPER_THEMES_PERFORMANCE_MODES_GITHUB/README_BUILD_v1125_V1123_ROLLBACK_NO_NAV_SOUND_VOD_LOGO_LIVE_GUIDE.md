# Debrid Channels v1125

**Candidate:** v1125  
**Marketing version:** 1.0.653  
**Build:** 653  
**Source base:** packaged v1123 only  
**Backend:** v669 unchanged

## Rollback and removal

v1124 was rejected after physical Apple TV testing showed that its custom root-hosting experiment changed the app's displayed aspect ratio. v1125 does not contain that root wrapper. It starts from packaged v1123, restores the normal SwiftUI `WindowGroup`/`RootView` presentation, and removes Navigation Sounds completely.

Removed runtime pieces include the single NavigationSoundManager, its WAV asset, all focus/playback/trailer hooks, the redesigned Settings control, project resource membership, and the navigation-sound backup/default key. No replacement sound pipeline was added.

## VOD themed-logo controls

VOD Playback Settings now contains two independent persistent controls, both defaulting Off:

- **Poster Themed Logo** — Show title artwork over the portrait poster.
- **Production & Ratings Logo** — Show title artwork in the Production & Ratings banner.

The large themed logo in the main VOD information section remains unchanged. Featured Cast, Production & Ratings metadata, 138-point rotating artwork, Source Intelligence, and player startup remain independent.

## Live TV playback UI

The Live TV playback control panel is now bounded to a compact 1180-point canvas rather than spanning nearly the complete screen. It preserves current/next program metadata, artwork/logo fallback, progress, audio, subtitles, settings, and close controls.

Playback Settings now offers **Guide Mode: Quick Guide** or **Guide Mode: Full Guide**. Quick Guide is a horizontal program-card rail over playback with focused-channel details below. Full Guide uses the existing saved Live TV focus snapshot and returns to the existing full guide without creating another guide implementation.

## Validation

- 46/46 Swift files parsed successfully.
- Both application plists validated at 1.0.653 (653).
- project.yml parsed and all declared source/resource paths exist.
- Navigation-sound runtime code, asset, setting, and project membership are absent.
- Normal v1123 application root presentation is restored; no v1124 custom root hosting remains.
- 22 protected playback, codec, catalog, Live TV persistence, Alternate Audio, trailer, resume, and backend files are byte-identical to v1123.
- GitHub Actions remains the authoritative Xcode/tvOS compilation test.
- Physical Apple TV display and behavior are not claimed as confirmed until tested.

v1120 remains the stable rollback candidate. Phase 9 remains paused until v1125 passes GitHub Actions and physical Apple TV testing. Phase 11 remains the planned codec-compatibility phase.
