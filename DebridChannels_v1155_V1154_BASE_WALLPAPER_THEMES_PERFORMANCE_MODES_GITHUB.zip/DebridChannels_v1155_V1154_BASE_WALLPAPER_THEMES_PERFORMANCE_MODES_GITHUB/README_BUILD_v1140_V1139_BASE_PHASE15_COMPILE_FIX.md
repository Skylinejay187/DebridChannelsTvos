# Debrid Channels v1140 — Phase 15 Compile Correction

- Candidate: **v1140**
- Marketing version: **1.0.668**
- Build: **668**
- Base: **packaged v1139 only**
- Backend: **v674 unchanged**
- Stable rollback: **v1138**

## Why this build exists

The uploaded GitHub Actions log showed one real compiler blocker in v1139:

`DebridChannelsTVOSApp.swift:23131:25: error: the compiler is unable to type-check this expression in reasonable time`

The failure was inside `V1111FeaturedCastPosterCard.body`, after the Phase 15 Cast Explorer interaction was added to an already-large SwiftUI modifier chain.

v1140 preserves the Phase 15 feature behavior and only decomposes that expression into smaller separately type-checked views and named handlers/tasks.

## Phase 15 remains included

- searchable/clickable Cast Explorer credits;
- existing Media Information/details pipeline outside playback;
- confirmed movie/show switching from VOD;
- full real episode browser/search and confirmed episode switching;
- VOD-only Off/+3/+6/+9/+12 dB amplification through pinned KSPNUVIO audio filters;
- existing Source Intelligence/session ownership/failover rules;
- Phase 15 production acceptance matrix.

## Local validation

- 53/53 app and Top Shelf Swift files parse successfully.
- App plist, Top Shelf plist, and both XcodeGen target version declarations agree at 1.0.668 / 668.
- The pre-audit diff from packaged v1139 is restricted to five expected files: the one SwiftUI compile correction, release-audit metadata, two plists, and project versioning.
- Phase15FinalIntegration.swift, CastExplorerService.swift, CatalogStore.swift, SourceIntelligenceManager.swift, Alternate Audio/failover/VOD ownership files, the complete pinned KSPNUVIO vendor tree, and backend runtime trees remain byte-identical to v1139.

## Remaining authoritative gates

GitHub Actions Release compilation is still authoritative because this environment does not contain Apple's Xcode/tvOS SDK. After GitHub passes, run the full physical Apple TV Phase 15 matrix before Stable promotion.
