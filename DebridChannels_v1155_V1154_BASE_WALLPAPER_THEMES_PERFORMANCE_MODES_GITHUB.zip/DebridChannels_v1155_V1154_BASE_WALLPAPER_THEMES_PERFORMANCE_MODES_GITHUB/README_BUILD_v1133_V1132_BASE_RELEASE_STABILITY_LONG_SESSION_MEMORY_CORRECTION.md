# Debrid Channels v1133 — Release Stability / Long-Session Memory Correction

- Base: packaged v1132 only
- Marketing version: 1.0.661
- Build: 661
- Backend pair: v674 unchanged (`1.8.15.84-v674-phase12-diagnostics-recovery`)
- Roadmap position: release-blocking stability correction before Phase 13
- v1132 base ZIP SHA-256: `223fe17679155b5a0662cb83a103b5ba440beda12acd9c259c3a6cd08ec09d55`
- backend v674 ZIP SHA-256: `d941567bf33def5daf471c9deb7455a9105472ce9389279cdfbe6cca1c4edddc`

## Why this pass exists
Physical-use symptoms reported that the app becomes progressively sluggish over time and that playback can eventually suffer. Static source inspection found genuine long-session memory-pressure and lifecycle problems consistent with that behavior. This pass does not claim a single proven retain-cycle leak; instead it corrects the concrete retained-memory/runaway-work paths found during the audit.

## Main findings corrected

1. **Decoded artwork reservoir was too large for a media player.** `PremiumRemoteImageLoader` could retain up to 220 MB / 420 decoded full-resolution images while the app also deliberately upgrades TMDB artwork to `/original/`. The cache is now 96 MB / 160 images during normal browsing and only 32 MB while VOD owns the decoder. Full source artwork quality and existing URL selection are preserved.
2. **VOD did not release catalog artwork before playback.** VOD entry now cancels image/prefetch work and clears decoded catalog artwork, matching the memory discipline already used by full-screen Live TV.
3. **Decorative VOD artwork could repopulate memory after playback started.** When the VOD overlay hides, decoded cast/production/discovery artwork and its image work are released. VOD exit clears the decorative cache again before catalog remount.
4. **Artwork prefetch/decode pressure was too aggressive.** Speculative image prefetch concurrency is reduced from 10 to 4, and artwork uses an ephemeral no-URLCache session. Decode intermediates are scoped inside an autorelease pool.
5. **Decorative metadata work was not fully overlay-owned.** Review-score, Production & Ratings, and Discovery enrichment are now gated by genuine first frame + visible VOD overlay + no child panel. Hidden overlay or opened sub-panel cancels decorative work; reopening resumes from cached/pending state. Production artwork rotation also respects the overlay-awake state.
6. **Several process-lifetime caches had no hard cap.** Source-track summaries, OMDb/TMDB advisory facts, Rotten Tomatoes scores, top-bar advisor IDs, and the trailer resolver memory cache are now bounded. Optional metadata caches are purged on memory pressure.
7. **Background suspend retained unnecessary decoded artwork.** The decoded NSCache reservoir is now released when the scene becomes inactive while currently mounted views keep their own images.

## Deep audit results
- Player/session teardown was inspected through PlaybackKit, KSPlayer surface ownership, AVPlayer end/time observers, focused preview cleanup, and VOD session close. No obvious process-lifetime KSPlayer/player-surface retain leak was found.
- 65 stored `Task` variables were discovered and every one has a cancellation path by static audit.
- NotificationCenter observer removal coverage: add=4, remove=5.
- AVPlayer periodic/boundary observer removal coverage: add=2, remove=6.
- Always-running episode-alert scanning remains intentionally preserved.
- Live TV guide/session caches were not aggressively cleared because they are replacement snapshots required for Gracenote/guide persistence rather than append-only growth.

## Long-session instrumentation
`ReleaseStabilityMemoryAuditManager` is event-driven only. It records physical footprint at VOD entry, VOD close, a 1.5-second post-close settle point, and memory-pressure events. It also logs image work, source-track cache count, and optional-task registry count. It has no polling timer. This gives the physical Apple TV test a way to confirm whether repeated play/exit cycles plateau instead of ratcheting upward.

## Preserved behavior
KSPlayer/Tapframe KSPNUVIO, forced hardware decoding, Phase 11 codec compatibility, Phase 12 diagnostics/recovery, Source Intelligence, Alternate Audio, automatic source failover, per-title playback memory, background resume/history persistence, trailers, Live TV guide/cache/playback, episode alerts, Production & Ratings presentation, Featured Cast modes, and the three-state Discovery panel (`Off` default / `Other Show Recommendations` / `Did You Know`) remain preserved.

Navigation Sounds remain abandoned and absent. No backend code was changed.

## Validation
- 52/52 Swift sources parse successfully.
- Release-stability contract: 38/38 checks pass.
- `ReleaseStabilityMemoryAuditManager.swift` independently type-checks with strict dependency stubs.
- Both plists and project.yml validate as 1.0.661 / 661.
- 19/19 protected systems are byte-identical to v1132.
- Backend v674 remains byte-for-byte the supplied backend ZIP.

GitHub Actions remains the authoritative Xcode/tvOS compiler. Physical Apple TV long-session behavior is not claimed fixed until tested. Keep v1132 + backend v674 as rollback until v1133 passes GitHub Actions and physical testing. Phase 13 must not begin until this stability gate is accepted.
