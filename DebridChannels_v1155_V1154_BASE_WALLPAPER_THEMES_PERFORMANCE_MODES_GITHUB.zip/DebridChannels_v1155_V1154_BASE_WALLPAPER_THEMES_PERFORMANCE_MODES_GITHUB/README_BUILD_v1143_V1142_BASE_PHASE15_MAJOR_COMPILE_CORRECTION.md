# Debrid Channels v1143 — Phase 15 Major Compile Correction

- Base: packaged v1142 only
- Marketing version: 1.0.671
- Build: 671
- Backend: v674 unchanged
- Rollback candidate: v1140 remains the last pre-v1141 physical-test correction line; v1142 is the direct source base for this compile repair.

## Scope

v1143 is a compile-only corrective pass for the two real errors in the supplied GitHub Actions log. It does not intentionally alter Phase 15 feature behavior.

### CatalogStore immutable identity
The complete-series loader still normalizes an exact episode back to the parent series before requesting every season/episode, but it now creates a parent-series `MediaItem` copy because `MediaItem.id` is intentionally immutable.

### Cast Explorer compiler boundary
The physical-test Cast Explorer card still uses app-owned orange focus styling with the system focus platter disabled. Its large SwiftUI expression has been split into small views and `AnyView` stages so Xcode does not need to infer one huge generic expression.

## Preserved Phase 15 corrections
Cast Explorer navigation and source selection, complete season/episode browsing, isolated source fan-out, live VOD gain controls, automatic resume correction, Source Intelligence isolation, KSPlayer/KSPNUVIO and all v1141 behavior remain in the inherited source.

GitHub Actions/Xcode remains the authoritative tvOS compile gate.
