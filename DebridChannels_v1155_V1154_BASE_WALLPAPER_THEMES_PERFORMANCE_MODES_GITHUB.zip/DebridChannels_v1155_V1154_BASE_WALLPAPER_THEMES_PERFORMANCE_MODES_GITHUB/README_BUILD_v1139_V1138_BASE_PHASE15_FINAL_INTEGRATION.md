# Debrid Channels v1139 — Phase 15 Final Integration & Production Lock Candidate

- Candidate: **v1139**
- Marketing version: **1.0.667**
- Build: **667**
- Source base: **supplied packaged v1138 only**
- Supplied v1138 ZIP SHA-256: `74570e5d518ea5380a444652c7b08a1ee26a2dc34d6000a923df85844f0d7e52`
- Backend: **v674 unchanged**
- Rollback until release gates pass: **v1138**
- Release channel: **do not promote to Stable yet**

## Phase 15 scope

This candidate integrates the user-requested release features into the existing production paths rather than creating parallel resolvers or players.

### Cast Explorer — searchable, clickable, playable

- Cast Explorer now searches the selected person's loaded movie/TV credits by title, role, year, and media type.
- Credits are deduplicated by `mediaType + TMDB id` and are real tvOS `Button` controls with focus/accessibility behavior.
- Every selected credit is converted to a canonical `MediaItem` with an explicit TMDB movie/TV identity.
- From normal Media Information, selecting a credit uses `CatalogStore.openDetail(... origin:)`, preserving the existing Search/Favorites/catalog detail-navigation and return behavior.
- From an active VOD overlay, selecting another cast credit does **not** switch immediately. It opens a confirmation panel first.
- After confirmation, Cast Explorer targets use the existing `resolverReadyStreamItem` hydration and `playFirstDirectStream` Source Intelligence/playback pipeline.
- A switch is considered successful only after `CatalogStore` publishes a new immutable playback presentation generation. Failure leaves the original playback session paused and unchanged.

### Full Episode Browser — search and watch from VOD

- The previous placeholder/hardcoded VOD season list was removed.
- The VOD Episodes button opens a full-screen episode browser backed only by the existing `CatalogStore.fetchSeriesEpisodes` metadata path.
- It supports real season filters plus search by `SxEy`, episode title, description, and air date.
- Episodes are sorted by real season/episode numbers and the active episode is marked **NOW PLAYING**.
- Selecting an episode uses the same Phase 15 confirmation overlay and the same existing ranked source/playback path used elsewhere in the app.
- Browser fetches are guarded by playback-presentation ID and playback URL so a stale request cannot populate a replacement session.

### VOD Volume Amplification

VOD Playback Settings now provides a single persistent control cycling:

- Off
- +3 dB
- +6 dB
- +9 dB
- +12 dB

Implementation is in the locked Tapframe KSPNUVIO/KSPlayer pipeline. The app passes the approved VOD gain to `KSOptions.audioFilters` as FFmpeg's `volume=XdB` filter. The pinned KSPNUVIO revision is unchanged at `69a73e5e22184c6db254eb2919f81768afb57a81`.

Primary-source verification performed during Phase 15:

- The pinned KSPNUVIO `KSOptions` exposes `public var audioFilters = [String]()`.
- The same pinned revision's `MEPlayer/Filter.swift` joins `options.audioFilters` and builds/configures the libavfilter graph.
- Official FFmpeg filter documentation accepts dB volume expressions such as `volume=6dB`.

The gain is attached only when `isVODStylePlayback && !muteAudio`. Live TV receives 0 dB at the app surface boundary, trailers are excluded from `isVODStylePlayback`, Off clears the filter, no `AVAudioSession`/system-volume path was added, and VOD hardware decoding remains forced.

Changing the setting preserves the authoritative playback timestamp and play/pause intent. The current immutable KS surface is regenerated at that clock; if a user had manually selected another compatibility engine, the app returns through the existing KSPlayer switch path instead of starting a second audio engine.

## Deep release audit corrections made during Phase 15

The release audit found and corrected issues before packaging:

1. **Critical target-membership issue:** `Phase15FinalIntegration.swift` existed in the work tree but was not originally listed in the XcodeGen app target. It is now explicitly included in `project.yml`.
2. **Obsolete VOD episode UI:** the old hardcoded `1...8` season options and stale `selectedEpisodeSeason`/`S1` control label were removed rather than shipped beside the real browser.
3. **Fail-closed amplification preference:** an invalid/corrupt persisted gain now resolves to Off instead of silently snapping to a high gain.
4. **Release acceptance contract:** Phase 13's passive acceptance-matrix schema advances to revision 2 and includes Cast Explorer interaction, confirmed VOD title/episode switching, full episode search, VOD amplification isolation, and rollback behavior. The candidate still does not auto-promote itself to Stable.
5. **Stale final-QA metadata:** the old v1040/1.0.569 release audit metadata was replaced with the v1139 Phase 15 release matrix.

No new backend endpoint, direct Phase 15 network client, navigation-sound path, player replacement, Movie Mode code, or parallel playback engine was added.

## Preserved architecture

The following remain locked:

- KSPlayer with the Tapframe KSPNUVIO fork.
- Pinned KSPNUVIO revision `69a73e5e22184c6db254eb2919f81768afb57a81`.
- Forced VOD hardware decoding.
- Phase 6 pre-first-frame automatic source failover and exact session identity.
- Source Intelligence ranking and playback ownership.
- Alternate Audio discovery/bridge/cancellation/diagnostics and manual lifecycle.
- Phase 9 bridge lifecycle/resource behavior.
- Trailer service and trailer audio behavior.
- Live TV guide cache/Gracenote persistence and playback path.
- Resume/history background persistence and per-title playback memory.
- Subtitle delay renderer/memory.
- Episode alerts.
- VOD Production & Ratings / Smart Info behavior.
- Search/Favorites/focus fixes.
- Navigation Sounds remain removed.

Twenty specifically protected source files were hash-compared and remain byte-identical to v1138. See `PROTECTED_SYSTEMS_PRESERVATION_v1139.json`.

## Local validation completed

- Swift syntax parsing: **53/53 passed**.
- Foundation-only rollout/final-QA manager type checks: passed with required dependencies.
- Cast Explorer interaction contract: **16/16**.
- Confirmed VOD title-switch contract: **16/16**.
- Full episode browser/search contract: **18/18**.
- Volume amplification contract: **23/23**.
- Release-blocker static audit: **19/19**.
- Protected systems: **20/20 byte-identical**.
- Both application plists: **1.0.667 / 667**.
- XcodeGen project versions: **1.0.667 / 667**.
- Project YAML parsed successfully and every declared application source path exists.

## Gates intentionally still pending

Local static/package validation is **not** a substitute for the release gates below:

1. GitHub Actions Xcode/tvOS compilation.
2. Physical Apple TV Phase 15 acceptance matrix.

The app remains an **Internal Testing/release candidate**, not Stable, until both gates pass. v1138 remains the rollback version. Do not begin unrelated feature development before the Phase 15 physical matrix is complete.
