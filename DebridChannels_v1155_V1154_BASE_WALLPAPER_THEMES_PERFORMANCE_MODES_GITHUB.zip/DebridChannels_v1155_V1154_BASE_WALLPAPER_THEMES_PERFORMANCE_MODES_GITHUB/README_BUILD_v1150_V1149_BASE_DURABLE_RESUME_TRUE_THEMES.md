# Debrid Channels v1150 — Durable Resume + True Top Menu Themes

- Marketing version: **1.0.678**
- Build: **678**
- Base: **packaged v1149 only**
- Resume reference donor: **packaged v1130**, used only to verify the known-working automatic resume jump path
- Backend: **v674 unchanged**

## What v1150 fixes

### 1. Resume progress now survives process exit
The physical-test clue was that the visible playback position could disappear after the app was swiped away. The current KSPlayer path was publishing its real decoder clock to PlaybackKit, but the resume cache was not guaranteed to receive/flush the newest clock before tvOS suspended or terminated the app.

v1150 keeps the known-working v1130 automatic-resume jump behavior and fixes persistence around it:

- Real KSPlayer decoder-clock updates now checkpoint the existing `PlaybackResumeCacheManager` every five seconds through the existing throttle.
- Player teardown performs a synchronous durable resume save and drains the resume writer queue.
- App inactive/background transitions perform the same durable checkpoint/flush before suspension.
- Resume JSON continues to use an atomic Application Support write.
- A resume-persistence floor protects a good saved timestamp while the v1130 resume-only KSPlayer reload briefly reports startup `0:00`; those temporary low clock callbacks cannot overwrite the previous checkpoint.

The actual v1130 resume jump functions remain unchanged: `scheduleAutomaticResumeAfterSurfaceStart`, `switchToKSPlayerEngine`, `seekAbsolute`, and `startPlayerClock` match the donor exactly. `applyAutomaticResumeIfAvailable` differs from the donor only by arming the persistence floor.

### 2. Automatic scrubber preserved
The working automatic LEFT/RIGHT timeline behavior is not changed. `scrubTimelineAndSeek` and `commitTimelineScrubIfNeeded` are byte-identical to v1149, including the 90 ms coalesced automatic seek.

### 3. Top-right VOD recommendation/trivia bar removed completely
The runtime panel, state/tasks, VOD settings control, stable-default key, release-security key, memory-pressure hook, project source entry, and `Sources/VODSmartInfo.swift` implementation were removed. There is no VOD `More Like This` / trivia discovery panel left to render or run in the background.

### 4. Appearance now has structurally different top-menu themes
The top menu no longer maps most choices to the same pill layout with different colors. v1150 has **22 themes across 10 actual visual families**:

- Classic rail
- Segmented
- Floating tiles
- Icon dock
- Minimal line
- Cinema marquee
- Studio ribbon
- Circle dock / compact icons
- Monochrome blocks
- Poster tabs

New selectable themes include **Icon Dock, Floating Tiles, Cinema Marquee, Studio Ribbon, Segmented Control, Compact Icons, Neon Line, and Poster Tabs** in addition to the prior theme names.

### 5. More Appearance colors and fonts
- Top-menu accents: **41 choices**
- Shared Popup/Top Menu typography presets: **66 choices**
- Added real-family variants including American Typewriter, Avenir Next Condensed, Copperplate, Menlo, Trebuchet MS, Hoefler Text, Marker Felt, Chalkboard SE, and Times New Roman mappings.
- Top-menu rendering now applies the selected typography preset's kerning/tracking instead of a fixed tracking value.

## Preserved from v1149

- Sports live-channel direct tune
- Connected Popup Background Artwork visibility correction
- PlaybackKit core
- KSPlayer surface implementation
- Universal codec support
- Automatic source failover
- Per-title playback memory
- Phase 15 episode browser
- CatalogStore
- Trailer service
- Sports center model

## Local validation

- Swift syntax parse: **54/54 passed**
- Static/preservation contracts: **88/88 passed**
- App + Top Shelf plist versions: **1.0.678 / 678**
- `project.yml` parsed successfully and versions match

GitHub Actions/Xcode is authoritative for full tvOS compilation. Physical Apple TV testing remains authoritative for resume persistence and player behavior.
