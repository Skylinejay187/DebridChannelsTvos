# Debrid Channels v1153

- Base: packaged v1152 only
- Marketing version: 1.0.681
- Build: 681
- Backend: v674 unchanged
- Scope: source-independent movie/episode resume identity + visible movie/episode remaining time
- Automatic LEFT/RIGHT scrubber: unchanged from v1152
- v1130-derived automatic resume jump: unchanged from v1152
- GitHub Actions/Xcode and physical Apple TV testing remain authoritative.
