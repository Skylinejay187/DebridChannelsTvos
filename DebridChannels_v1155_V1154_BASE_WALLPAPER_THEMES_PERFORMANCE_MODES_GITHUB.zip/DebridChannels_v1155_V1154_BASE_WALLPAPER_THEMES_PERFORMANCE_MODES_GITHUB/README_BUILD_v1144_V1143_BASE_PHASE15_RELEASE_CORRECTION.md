# Debrid Channels v1144 — Phase 15 Release Correction

**Marketing version:** 1.0.672  
**Build:** 672  
**Base:** packaged v1143 only  
**Backend:** v674 unchanged  
**Resume donor/reference:** packaged v1133 only

## Purpose

v1144 is a focused Phase 15 physical-test corrective build. It addresses the remaining automatic-resume regression, native white focus treatment and sluggishness in the Full Episode Browser, the intermittent frame hitch immediately after hiding the VOD overlay, and removes Cast Explorer entry from Media Information while retaining it in VOD playback.

## Automatic resume

The saved resume database was not the broken component: `PlaybackResumeCache.swift` is byte-identical to the known-good v1133 implementation. The regression was the later startup application strategy. v1144 restores the exact v1133 resume functions, including its bounded delayed startup seek and one-time KSPlayer surface refresh for automatic/manual resume. Normal seeks remain in-place.

## Full Episode Browser

- Episode metadata is transformed and sorted once into prepared rows instead of rebuilding titles/search text/date formatting during focus movement.
- Four-column `LazyVGrid` remains, but whole-grid focus relayout animations are disabled.
- Episode cards use local restrained focus scale only; the costly focus shadow was removed.
- Episode cards, season chips, Close, and the search field suppress the native tvOS focus platter.
- Focused cards/chips/Close use Debrid Channels orange/dark styling instead of a white system panel.
- ISO-8601 dates containing fractional seconds are normalized into the existing `SxEy • AIRED/TODAY/UPCOMING <date>` presentation.
- The v1141 complete-series logic remains unchanged: exact parent-series identity + configured metadata merged with TVMaze fallback by exact season/episode.

## VOD overlay hide hitch

Phase 15 can hold substantially more cast/episode artwork than older releases. The hidden-overlay path was synchronously clearing the complete decoded image NSCache on the MainActor at the exact frame the video chrome disappeared. v1144 no longer does that. It cancels obsolete network/prefetch/in-flight work but retains decoded entries under the already-enforced 32 MB VOD cache ceiling. Full purges remain on VOD entry/exit and lifecycle pressure paths.

The 15-second active-playback auto-hide also removes the chrome atomically rather than animating the entire overlay tree over the video compositor.

## Cast Explorer scope

Media Information cast rows are presentation-only again and do not enter the focus graph or expose Cast Explorer actions. VOD playback retains the full Cast Explorer, clickable credits, episode/title switching, confirmation, and Source Intelligence-style source selection.

## Preserved systems

The following critical files are byte-identical to v1143: `CatalogStore.swift`, both current PlaybackKit audio/player integration files, `PlaybackResumeCache.swift`, `AutomaticSourceFailover.swift`, and `SourceIntelligenceManager.swift`. Backend v674 is unchanged.

## Local validation

- Swift parse: 53/53 files.
- Static release-correction contracts: 47/47.
- Plists parse and agree on 1.0.672 / 672.
- `project.yml` parses and agrees on 1.0.672 / 672.
- Exactly six inherited source/config files changed before this report set was added.

GitHub Actions/Xcode and physical Apple TV testing remain authoritative.
