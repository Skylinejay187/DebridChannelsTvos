# Debrid Channels tvOS/iOS — v1141 Phase 15 Physical-Test Corrections

- Candidate: v1141
- Marketing version: 1.0.669
- Build: 669
- Base: packaged v1140 only
- Backend: v674 unchanged
- Scope: Phase 15 corrective pass; no new phase

## Physical Apple TV issues corrected

### 1. Cast Explorer focus platter
`V1134CastCreditCard` is no longer a SwiftUI `Button`. It is an app-owned focusable/selectable card with the system focus effect disabled and Debrid Channels' orange focus outline/scale only. This removes the large white focused-card platter seen on physical tvOS.

### 2. Cast Explorer can always return to the person profile
The vertical Cast Explorer now uses `ScrollViewReader` with a stable profile anchor. UP from any focused credit rail explicitly scrolls back to the cast member profile/information and hands focus to the fixed top control, preventing the horizontal credit rails from trapping the user below the profile.

### 3. VOD scrubber focus ownership
When the VOD control shelf is revealed, Featured Cast is removed from the native focus graph immediately. Timeline focus is claimed one main-run-loop turn after the scrubber is mounted, so tvOS cannot geometrically fall back to the cast portrait. UP from the control chips also uses this same deterministic timeline claim.

### 4. Volume Amplification is live and does not restart playback
Off / +3 / +6 / +9 / +12 dB updates the active KSPNUVIO `KSOptions.audioFilters` on the existing KSPlayer session. The amplification action does not change the URL, seek serial, reload token, surface token, first-frame gate, timestamp, or play/pause state. KSPNUVIO's existing audio filter path observes the updated filter string and rebuilds only the FFmpeg audio filter graph.

If the user has explicitly selected AVPlayer, the preference is saved but the app does not silently restart or switch engines merely to obtain amplification.

### 5. Full Episode Browser loads the parent series
Opening Full Episode Browser from a currently playing episode now strips the episode-shaped title/ID into the parent-series lookup identity before querying series metadata. Example physical-test input `Reacher S03E03 Number 2 with a Bullet` becomes parent title `Reacher` for the inventory lookup.

Configured Stremio series metadata remains primary. The existing TVMaze complete-series episode inventory is merged by exact season/episode identity and fills missing seasons/episodes. If configured Stremio metadata returns no episode inventory, TVMaze is used as the complete-series fallback.

### 6. Cast Explorer / Episode Browser source choice
Selecting another Cast Explorer movie or an exact episode does not auto-play an arbitrary link. After switch confirmation, Debrid Channels opens a dedicated Source Intelligence picker showing the ranked direct links and lets the user choose the exact source.

A Cast Explorer TV-series credit first opens the full episode browser. Selecting an exact episode then proceeds to the same Source Intelligence picker.

Importantly, Phase 15 source preparation now reuses Phase 8's isolated provider fan-out. It does not call the global `findStreams` path while VOD is active, so it does not replace the current title's visible Source Intelligence/Alternate Audio state.

### 7. Automatic resume restored
The saved resume entry was already being persisted, which is why Media Information could display the correct progress percentage. The broken part was startup application/confirmation.

v1141 now:
- primes KSPlayer `startPlayTime` from the saved exact-title/episode position;
- starts PlaybackKit's diagnostic clock at 0 so a cached timestamp cannot masquerade as a real first-frame/player-clock callback;
- keeps the pending resume target until the actual KSPlayer clock reaches the saved position;
- issues bounded corrective absolute seeks only after a usable real player clock/first frame exists;
- never recreates the KSPlayer surface merely to apply a resume seek;
- uses the same real-clock confirmation path for the manual Resume backup chip.

## Preservation
The correction changes only seven inherited source/configuration files from v1140:

- `Sources/CatalogStore.swift`
- `Sources/DebridChannelsTVOSApp.swift`
- `Sources/Info.plist`
- `Sources/Phase15FinalIntegration.swift`
- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift`
- `TopShelfExtension/Info.plist`
- `project.yml`

No backend change is required for this correction. Backend v674 remains the expected backend.

Navigation Sounds remain removed. KSPlayer/KSPNUVIO remain the playback architecture; hardware video decoding policy is not changed.

## Local validation
- Swift parser: 55/55 Swift source files passed.
- Phase 15 static physical-test correction contracts: 32/32 passed.
- Both app/Top Shelf plists parse and report 1.0.669 / 669.
- `project.yml` parses and includes `Phase15FinalIntegration.swift` in the tvOS target.
- Final archive extraction/hash verification is performed after packaging.

## Release gate
This is a candidate. GitHub Actions/Xcode tvOS compilation and physical Apple TV testing remain authoritative. Do not promote to Stable solely from local parser/static validation.
