# v1148 Deep Audit — Working Resume Donor + Appearance Expansion

## Base and donor
- Base: packaged v1147 only.
- Working resume donor supplied by user: packaged v1130 only.
- Backend: unchanged from current line (v674).
- Marketing/build: 1.0.676 / 676.

## Resume root-cause comparison
The v1145/v1146 resume experiments diverged from the known-working v1130 behavior. v1146 waited for a decoder clock and used in-place seek verification; v1130 instead queues the saved resume target, gives the KS surface a bounded startup window, and uses a resume-only KSPlayer surface reload/start-time seek. The donor marks that startup resume applied immediately after issuing the proven resume path.

v1146 also added direct five-second persistence from the KS decoder callback. If resume failed and playback remained near zero, that new callback writer could eventually replace a previously useful saved position with the new low clock. That writer is not present in v1130 and is removed in v1148.

## Exact donor-matched resume functions
The following functions in v1148 are exact text matches to v1130:
1. `applyAutomaticResumeIfAvailable()`
2. `scheduleAutomaticResumeAfterSurfaceStart()`
3. `saveResumePositionIfNeeded(force:)`
4. `switchToKSPlayerEngine(manual:fallbackReason:startAt:)`
5. `seekAbsolute(_:directionSeconds:revealControls:markAutomaticResume:precise:)`

This restores the donor's resume-only `ksStartTimeSeconds + ksSeekSerial + ksSurfaceToken` behavior while ordinary timeline seeks remain direct in-place seeks.

## Resume support files audited
These files were intentionally not modified:
- `Sources/PlaybackResumeCache.swift` — byte-identical to both v1147 and working donor v1130.
- `Sources/AutomaticSourceFailoverManager.swift` — byte-identical to both v1147 and v1130.
- `Sources/PerTitlePlaybackMemory.swift` — byte-identical to both v1147 and v1130.
- `Sources/UniversalCodecSupport.swift` — byte-identical to v1147.
- `Sources/PlaybackKit/PlaybackKitKSPlayerSurface.swift` — byte-identical to v1147. Comparison against v1130 shows later differences are Phase 11/15 codec/audio-gain work, not resume control flow.
- `Sources/PlaybackKit/PlaybackKitFoundation.swift` — byte-identical to v1147.

## Scrubber protection
The user confirmed automatic LEFT/RIGHT scrubbing works. No scrubber behavior was changed in v1148.
- `scrubTimelineAndSeek(by:)` is byte-identical to v1147.
- `commitTimelineScrubIfNeeded()` is byte-identical to v1147.
- The v1146 90 ms automatic scrub seek debounce remains intact.

## Appearance expansion
Existing storage keys and picker architecture are retained.

### Top Menu themes
Existing 6 themes remain and 8 new themes are added:
- Aurora Glass
- Sapphire Glass
- Emerald Glass
- Ruby Noir
- Sunset Glass
- Purple Nebula
- Monochrome
- Copper Cinema

Total: 14 themes.

### Top Menu accent colors
Existing choices remain. New accents include Amber, Champagne, Copper, Bronze, Mint, Teal, Aqua, Sapphire, Violet, Magenta, Pink, Rose, and Graphite.

Total: 29 accent choices including Auto Match Theme.

### Shared font themes
`PopupTypography.presets` remains the single shared typography library consumed by both Popup Font and Top Menu Font pickers. New presets:
- Apple TV Bold
- Apple TV Clean
- Glass UI
- Cinema Wide
- Luxury Serif
- Sports Network
- Newsroom
- Retro Broadcast
- Arcade
- Terminal
- Future Display
- Midnight Sans
- Ultra Clean
- Comfort Rounded

Total: 54 shared font presets.

No font files are bundled or added; the new themes use the existing system/built-in typography paths.

## Validation
- Swift parse: 53/53 Swift source files passed.
- Static contract: 47/47 checks passed before packaging.
- Version/plist checks passed for app and Top Shelf extension.
- GitHub Actions/Xcode remains authoritative for full tvOS compilation.
