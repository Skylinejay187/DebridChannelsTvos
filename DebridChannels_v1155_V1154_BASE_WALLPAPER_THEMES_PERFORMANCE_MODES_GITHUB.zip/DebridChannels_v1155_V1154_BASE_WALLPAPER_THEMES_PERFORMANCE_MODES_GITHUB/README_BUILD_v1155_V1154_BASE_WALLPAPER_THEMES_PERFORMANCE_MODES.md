# Debrid Channels v1155 — Wallpaper Themes + Performance Modes

Base: packaged v1154 only. Backend remains v674.
Marketing version: 1.0.683. Build: 683.

## Scope
- Expand Dynamic Live Wallpaper from 6 to 20 lightweight Canvas-rendered themes.
- Restore/include a dedicated Spotlight Smoke theme with moving light beams through smoke.
- Add Visual Performance modes: Compatibility, Balanced, High Performance.
- Preserve the v1152 performance principle that Live TV navigation always outranks wallpaper rendering.
- Completely suspend live-wallpaper rendering when the active uncovered Live TV grid is not on screen, including Home, Movies, Shows, Sports, Favorites, Settings, Search, guides, detail/quick panels, and all video playback.

## Performance profiles
- Compatibility: 8 fps wallpaper, conservative detail, 360 ms navigation-settle delay. This is the v1152-compatible behavior and remains the default.
- Balanced: 15 fps wallpaper, moderate detail, 280 ms navigation-settle delay.
- High Performance: 30 fps wallpaper, richer Canvas detail, 160 ms navigation-settle delay, intended for faster/newer Apple TV hardware.

Core UI and video playback are not frame-capped by these modes. Hardware video decoding stays independent.

## Preservation
The v1154 movie Find Links resume path, sports direct-live routing/cleanup, automatic resume functions, and automatic LEFT/RIGHT scrubber are unchanged. PlaybackKit, resume cache, failover, per-title memory, Phase 15, SportsCenterViewModel, CatalogStore, and trailer manager are byte-identical to v1154.
