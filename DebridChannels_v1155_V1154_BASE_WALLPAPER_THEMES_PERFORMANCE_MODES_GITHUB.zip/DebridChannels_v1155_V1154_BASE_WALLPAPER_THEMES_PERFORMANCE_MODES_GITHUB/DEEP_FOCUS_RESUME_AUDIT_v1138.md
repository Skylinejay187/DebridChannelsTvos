# v1138 Deep Focus + Resume Audit

## Media Information cast selection
- Found: cast cards were presentation-only; parent canvas owned focus and activation.
- Fix: native Button/FocusState wrappers only for the active Media Information cast rows.
- Directional routing: existing `routeMediaInformationCast` remains authoritative.
- Select: opens `openMediaInformationCastExplorer` directly.
- Exit from cast row: explicitly restores the parent canvas focus.
- VOD playback: not involved in this route.

## VOD scrubber focus
- Found: `V1111FeaturedCastPosterCard` used `.focusable(isCastSelectable)` continuously.
- Consequence: tvOS geometry could select Cast before the timeline despite `focusedZone` saying timeline.
- Fix: `.focusable(isCastSelectable && focusActive)` where `focusActive` is supplied from `focusedZone == .cast`.
- Resulting route: chips → timeline → Cast; Cast ↓ → timeline.
- Cast rotation task/index behavior was not modified.

## Resume
- Confirmed byte-identical to v1135 before this correction: `applyAutomaticResumeIfAvailable`, `scheduleAutomaticResumeAfterSurfaceStart`, `saveResumePositionIfNeeded`, and `PlaybackResumeCache.swift` storage logic.
- Found latent timing race: an early automatic seek could be marked applied before KSPlayer surfaced a usable clock.
- Fix: prime `ksStartTimeSeconds`/absolute target before surface creation; wait for first-frame/player-clock readiness; confirm if already at target; otherwise issue a corrective absolute seek.
- Ready KS surface: uses seek serial rather than forced surface recreation.
- Manual Resume chip remains as backup if no stable clock arrives.

## Scope
No backend changes. No codec changes. No Alternate Audio changes. No Source Intelligence changes. No Cast Explorer service changes.
