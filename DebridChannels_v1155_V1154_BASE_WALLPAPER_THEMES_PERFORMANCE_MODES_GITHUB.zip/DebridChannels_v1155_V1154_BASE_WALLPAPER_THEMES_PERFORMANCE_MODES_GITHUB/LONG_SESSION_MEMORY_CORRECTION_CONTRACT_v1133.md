# v1133 Long-Session Memory Correction Contract

PASS criteria for this candidate:

- Preserve `/original/` premium artwork selection; do not regress Artwork 4 / Hero 2 URL quality.
- Normal browsing decoded image cache must be bounded to 96 MB / 160 entries.
- VOD-exclusive decoded cache ceiling must be 32 MB.
- Entering VOD must cancel speculative/active artwork work and release decoded catalog artwork.
- Hiding the VOD overlay must cancel decorative image work and release decoded decorative artwork.
- Exiting VOD must clear VOD decorative artwork before catalog remount.
- Artwork prefetch concurrency must be <= 4.
- Artwork transport must use an ephemeral session with URL cache disabled.
- Production/ratings/review/discovery enrichment must not continue while VOD overlay is hidden or a child panel owns the overlay.
- Production artwork rotation must be idle when its overlay presentation is asleep.
- Process-lifetime optional metadata caches must have hard bounds and memory-pressure release paths.
- Long-session instrumentation must be event-driven and must not poll playback.
- KSPlayer/KSPNUVIO, Phase 11 codec logic, Source Intelligence, Alternate Audio, Live TV guide/cache, resume/history, per-title memory, trailers, automatic failover, and episode alerts must remain protected.
- Navigation Sounds must remain absent.
- Backend v674 must remain unchanged.
