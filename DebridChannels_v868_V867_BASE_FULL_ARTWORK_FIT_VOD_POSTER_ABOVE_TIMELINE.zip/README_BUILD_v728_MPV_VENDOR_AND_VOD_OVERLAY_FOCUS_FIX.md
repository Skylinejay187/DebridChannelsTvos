# v728 MPV Vendor + VOD Overlay Focus Fix

Targeted fixes from v727:

- MPV no longer uses SwiftPM MPVKit package resolution, because MPVKit and KSPlayer/FFmpegKit both expose duplicate Libav* SwiftPM targets.
- Added a vendored MPVKit bootstrap build phase that clones MPVKit only to copy a ready MPVKit framework/xcframework into `Vendor/MPVKit` before compile/link/embed.
- Added `Vendor/MPVKit/MPVKit.xcframework` as an embedded framework dependency so `canImport(MPVKit)` can become true and MPV stops showing as unavailable when the framework is present.
- VOD overlay chips are now native focusable buttons again; removed the explicit `.focusable(false)` that prevented tvOS from treating each chip as a real focus target.
- VOD chip rail now has a hard screen-width frame, clipping, larger vertical focus padding, and extra trailing scroll runway so every chip can scroll into view.
- Cast wall widened and cast cards compacted for the theater overlay so the right side no longer cuts off the fourth cast member.

If MPVKit's upstream repository does not contain a ready binary framework, the build will fail intentionally with a clear message instead of producing another fake MPV option.
