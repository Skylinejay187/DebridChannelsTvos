# DebridChannels tvOS v766 — Sports Center Rebuild + Global Ticker

Base: v765 Playback Awareness + Source Intelligence Fix

Scope kept separate from playback:
- Reworked Sports Center toward an event-first sports hub with a large broadcast-style hero.
- Added SportsCenter-style live score ticker visual treatment.
- Added optional global Sports ticker overlay using the existing Sports Score Ticker setting.
- Added automatic sports channel classifier for M3U/Xtream/Live TV channels so sports-specific channels are grouped into NFL, NBA, MLB, NHL, Soccer, Combat Sports, Motorsports, College Sports, Regional Sports, Live Sports Channels, and Sports / Other.
- Preserved Live TV / Movies / Shows navigation harmony. Sports groups point to the same live stream URLs as the Live TV grid.
- Did not touch VOD playback, English audio, Real-Debrid resolver, Source Intelligence playback logic, or cache architecture.

Validation:
- swiftc -parse Sources/*.swift passed with existing UniversalCodecSupport warning only.
