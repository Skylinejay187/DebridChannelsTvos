# DebridChannels tvOS v785 — Architecture Migration Step 11

## Scope
Step 11 only: Alerts manager unification.

## Changes
- Added `Sources/NewEpisodeAlertsManager.swift`.
- Centralized new-episode alert schedule helpers:
  - selected scan frequency lookup
  - heartbeat delay calculation
  - sleep duration conversion
  - schedule date formatting
- Centralized scanner verification report decoration.
- Centralized developer/test alert construction.

## Preserved behavior
- New episode banner side, theme, and duration remain unchanged.
- Interactive popup behavior remains unchanged.
- No-focus-steal banner behavior remains unchanged.
- Followed show scanning continues through existing `CatalogStore` logic.
- Existing UserDefaults keys remain unchanged.
- No Sports, Live TV, Source Intelligence, trailer, playback, membership, or catalog behavior changed.
