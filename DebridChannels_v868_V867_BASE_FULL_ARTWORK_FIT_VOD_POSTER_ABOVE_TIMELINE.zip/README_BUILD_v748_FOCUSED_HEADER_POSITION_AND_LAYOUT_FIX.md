DebridChannels tvOS v748_FOCUSED_HEADER_POSITION_AND_LAYOUT_FIX

- Restores KSPlayer as the default VOD player for new installs and users without a saved VOD engine preference.
- Preserves explicit manual AVPlayer and MPV selections; MPV remains available for runtime testing and is not auto-selected as the default.
- Keeps the KSPlayer native seek path for timeline scrubbing, Resume, Back 30, and Forward 30 using the active KSPlayer layer instance.
- Moves only the focused provider/category header upward so the provider icon/name sits above the focused card instead of overlapping poster artwork.
- Leaves catalog row/card geometry, next-row labels, provider identifiers, top menu, and Artwork 2 / Artwork 5 floating backgrounds unchanged.
- Updates the build marker for GitHub Actions/upload identification.
