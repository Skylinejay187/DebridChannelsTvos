DebridChannels tvOS v751_LIVE_PANEL_CHIP_QUICK_GUIDE_TIP_ARTWORK_TUNING_FIX

Base: v750_LIVE_TV_FOCUS_RESTORE_CRITICAL_FIX.

Changes:
- Guide Tools Force Refresh and category controls now suppress the oversized tvOS focus platter and clip custom focus to the visible chip bounds.
- Live TV playback shows a one-time hidden-overlay tip: "Press Up or Down to open Quick Guide". The tip is Live TV only, does not take focus, auto-dismisses, persists per install/profile, and clears immediately when Quick Guide opens.
- Artwork 5 Floating keeps the cinematic floating artwork treatment while reducing grid-darkening overlays so Live TV cards remain readable.
- Artwork 3 Hero now includes the themed media/title logo over the hero background when available, with text fallback only when no logo exists.

Marker:
DEBRID_CHANNELS_TVOS_BUILD_V751_LIVE_PANEL_CHIP_QUICK_GUIDE_TIP_ARTWORK_TUNING_FIX_READY_UPLOAD
