# v710_STREMIO_CATALOG_FAST_LOAD_COMPILE_FIX

Compile-only follow-up to v710 fast-load.

Fixes:
- Added required `await` around actor-isolated elapsed-time logging inside async task-group closures.
- Broke the large Streaming Catalog overlay SwiftUI expression into smaller helper views.

No behavior changes were intended.
