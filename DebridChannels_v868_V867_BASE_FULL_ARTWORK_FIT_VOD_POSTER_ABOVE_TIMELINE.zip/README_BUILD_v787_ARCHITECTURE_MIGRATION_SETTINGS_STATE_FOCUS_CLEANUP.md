# DebridChannels tvOS v787 — Architecture Migration Step 13

Baseline: v786_ARCHITECTURE_MIGRATION_PLAYBACK_STATE_MANAGER_READY_UPLOAD

Scope: Step 13 only — Settings state/focus cleanup.

Changes:
- Added `Sources/SettingsStateFocusManager.swift`.
- Moved Settings category row offset math into a dedicated manager.
- Moved Settings category left/right debounce helper into the manager.
- Moved adjacent-category routing helper into the manager.
- Kept SettingsScreen UI, AppStorage keys, focus order, category names, player toggles, trailer toggles, membership/top-menu behavior, and backup/restore controls unchanged.

Preservation rules:
- No playback engine changes.
- No Sports changes.
- No Live TV guide/cache changes.
- No alerts behavior changes.
- No catalog artwork behavior changes.
- No Source Intelligence behavior changes.

Build marker: v787_ARCHITECTURE_MIGRATION_SETTINGS_STATE_FOCUS_CLEANUP
