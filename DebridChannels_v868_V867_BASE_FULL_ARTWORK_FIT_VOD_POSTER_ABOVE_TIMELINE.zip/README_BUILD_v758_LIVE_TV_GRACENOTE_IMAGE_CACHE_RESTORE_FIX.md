# v758 Live TV Gracenote Image Cache Restore Fix

- Restores cached Live TV guide/program image URLs immediately when returning from Settings/Home navigation.
- Keeps existing Gracenote artwork visible while scheduled or force guide refreshes are loading.
- Avoids replacing known program image URLs with generic channel/provider placeholders during tile rebuilds.
- Leaves source-mode invalidation intact for real Live TV account/source changes.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V758_LIVE_TV_GRACENOTE_IMAGE_CACHE_RESTORE_FIX`
