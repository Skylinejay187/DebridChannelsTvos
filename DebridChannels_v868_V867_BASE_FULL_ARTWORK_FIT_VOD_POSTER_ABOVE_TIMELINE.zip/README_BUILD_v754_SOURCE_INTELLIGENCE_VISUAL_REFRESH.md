v754_SOURCE_INTELLIGENCE_VISUAL_REFRESH

Scope:
- Kept the v753 Source Intelligence resolving, ranking, episode matching, and 25-link batching logic intact.
- Redesigned the Source Intelligence overlay as a premium glass panel.
- Added a large Best Match hero card for the first ranked source.
- Added compact premium cards for secondary ranked links.
- Added clear visual badges for Cached, Exact Episode/Movie, 4K, English, Lowest GB, and codec.
- Added source confidence meters and stronger highlight/glow styling for focused and high-confidence sources.
- Increased visible Source Intelligence results to 6 per page while keeping Left/Right paging and Up/Down focus behavior.

Local verification:
- `swiftc` is not installed in this environment, so a local Swift parse/build could not be run here.
- Static call-site checks were run with `rg` after the UI-only edits.
