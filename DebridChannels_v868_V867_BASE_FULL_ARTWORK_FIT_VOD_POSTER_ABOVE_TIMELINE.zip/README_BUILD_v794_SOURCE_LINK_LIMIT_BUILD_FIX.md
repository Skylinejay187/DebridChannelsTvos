# v794 Source Link Limit Build Fix

Scoped build fix for v794 Production Hardening Backend API Contract + Source Intelligence link limit.

Fix:
- Added the new Source Intelligence focus cases (`sourceLinks25`, `sourceLinks50`) to the Settings D-pad routing switches.
- Preserved default 25-link behavior and optional 50-link setting.
- No UI redesign, player changes, navigation redesign, or backend endpoint changes.

Validation:
- Swift parse check passes for all Sources/*.swift.
