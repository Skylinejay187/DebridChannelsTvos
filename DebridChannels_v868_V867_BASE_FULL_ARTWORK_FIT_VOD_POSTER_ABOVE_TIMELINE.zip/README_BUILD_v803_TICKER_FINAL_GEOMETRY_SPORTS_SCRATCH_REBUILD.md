# Debrid Channels tvOS v803 - Ticker final geometry + Sports scratch rebuild

- Moved Movies/Shows and Sports tickers down to sit directly above the computed top-right Live TV card frame.
- Ticker trailing edge now snaps to the rightmost top-row card trailing edge, with a 10pt bottom gap above the card.
- Movies/Shows ticker manager now alternates available movie and show items in movie/show order.
- Rewired the active Sports route to a scratch-built quick panel surface using `SportsScratch*` hero, event row, and channel row components.
- Sports remains a quick panel over the Live TV backing layout and does not activate the old fullscreen SportsCenter page.
- Sports quick panel includes a large score/game hero plus Live & Upcoming Games, Sports Channels, Leagues, Favorite Teams, Highlights / Trending, and Sports News rows.
- Long-press/context menu removal on Sports channel cards persists removed channel IDs and normalized names.
- Sports classifier rows filter persisted removed IDs/names so removed channels are not re-added on refresh.
- Playback, KSPlayer, AVPlayer, Source Intelligence, Membership, guide/cache/parsing, backend, and Media Info were not changed.
