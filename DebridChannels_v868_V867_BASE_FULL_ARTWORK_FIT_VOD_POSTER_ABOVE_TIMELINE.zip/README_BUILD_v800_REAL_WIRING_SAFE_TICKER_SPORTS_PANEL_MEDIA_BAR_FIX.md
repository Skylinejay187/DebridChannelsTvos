# Debrid Channels tvOS v800 — Real Wiring Safe Ticker / Sports Panel / Media Bar Fix

Base: v799 Media Info Top Bar Transparency ZIP.

This build fix intentionally wires the features into the active rendered paths instead of leaving unused code in parallel views.

## Active UI wiring fixed
- Sports now renders as a Harmony quick-panel-style overlay on top of the Live TV surface instead of replacing the app surface as a disconnected section.
- The active RootView route for `.sports` now keeps LiveTVScreen behind SportsHubScreen and puts the Sports panel at the same overlay layer pattern used by catalog panels.
- The top menu remains visually present but is removed from focus/hit-testing while Sports owns the quick-panel focus, matching Movies/Shows panel behavior.

## Ticker safe-lane rules fixed
- Global Movies/Shows ticker and Sports ticker now only render when no quick panel, detail overlay, search overlay, live panel, or player owns focus.
- Sports is now included in the quick-panel ownership check, so all global tickers hide while Sports is open.
- Sports panel no longer renders its own internal ticker/crawl; sports information remains in the hero and scoreboard rails.
- Tickers use a reserved top-chrome safe lane and hide when there is not enough geometry to stay above card rows.

## Sports removal action fixed
- Sports channel cards keep the context menu action: “Remove from Sports Section”.
- Long-press is also wired directly as a fallback for tvOS custom focus cards.
- Removed channels persist in `sportsExcludedChannelIds` and are removed from manual sports IDs so the classifier cannot re-add them.

## Media Info top bar setting fixed
- The existing Settings row remains under Appearance.
- The active Media Info top bar reads `mediaInfoTopBarTransparency` and changes only the black/glass top bar background.
- Poster dimming, hero artwork, chips, text, buttons, cast, credits, and lower details remain unchanged.
- The top bar view is keyed by the selected transparency value to force visible updates when the setting changes.

## Out of scope / untouched
- No playback engine changes.
- No KSPlayer/AVPlayer changes.
- No Source Intelligence changes.
- No membership changes.
- No Live TV guide/cache changes.
- No Movies/Shows redesign.
