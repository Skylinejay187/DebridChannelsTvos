# v732 Real libmpv Vendor Fetch

- Keeps MPVKit fully removed so it cannot collide with FFmpegKit/KSPlayer SwiftPM `Libav*` targets.
- Adds `Vendor/libmpv/libmpv.framework` as the MPV link/embed target.
- Adds a pre-build fetch step that downloads a real tvOS libmpv/mpv xcframework artifact, extracts the tvOS arm64 framework slice, and vendors it before link/embed.
- Fails loudly if no real tvOS libmpv artifact is available instead of producing a fake MPV option.

Expected GitHub Actions log now includes:

```text
DEBRID CHANNELS TVOS V732 FETCHING REAL LIBMPV / MPV XCFRAMEWORK
Downloading real libmpv tvOS artifact: ...
Vendored libmpv.framework bytes: ...
```
