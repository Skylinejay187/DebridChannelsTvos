# v731 LIBMPV-ONLY FIRST SCOPE

- Removed MPVKit and the DebridMPV SwiftPM wrapper completely.
- FFmpegKit remains the only SwiftPM FFmpeg/Libav provider.
- MPV availability is no longer faked. MPV only becomes selectable when a real tvOS `mpv.xcframework`, `libmpv.xcframework`, `MPV.framework`, or `libmpv.framework` is vendored outside SwiftPM.
- Project build verification now confirms no MPVKit package should appear in the SwiftPM resolve graph.
- OMDb/Rotten Tomatoes is intentionally left for the next scope after the MPV package architecture is clean.

Important: libmpv cannot simply reuse the already downloaded FFmpegKit Swift package at runtime. A real libmpv binary must be compiled/packaged against its media libraries. The important fix here is preventing MPVKit from bringing a second SwiftPM Libav graph into the app.
