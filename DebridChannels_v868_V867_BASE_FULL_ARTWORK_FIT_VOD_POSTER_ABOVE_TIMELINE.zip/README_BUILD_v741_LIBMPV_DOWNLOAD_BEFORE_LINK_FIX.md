# v741 Libmpv Download Before Link Fix

Fixes the v740 failure where Xcode linked the tiny placeholder `Libmpv.framework` before the fetch script could replace it.

Changes:
- Removed `Vendor/MPV/Libmpv.xcframework` from XcodeGen framework dependencies so Xcode no longer validates/links the placeholder before scripts run.
- Kept MPVKit removed from SwiftPM.
- Kept KSPlayer + FFmpegKit unchanged.
- Fetches real `Libmpv.xcframework` in a pre-build script before Swift compile/link.
- Uses weak framework linker flags for `Libmpv`.
- Adds a post-build embed script that copies the downloaded tvOS `Libmpv.framework` slice into the app bundle.
- Fails loudly if the downloaded/embedded framework is missing or too small.

Expected log markers:
- `DEBRID CHANNELS TVOS V740 FETCHING REAL LIBMPV XCFRAMEWORK`
- `Downloading real tvOS-compatible Libmpv.xcframework asset`
- `Real Libmpv.xcframework is present before compile/link`
- `DEBRID CHANNELS TVOS V741 EMBED LIBMPV RUNTIME FRAMEWORK`
