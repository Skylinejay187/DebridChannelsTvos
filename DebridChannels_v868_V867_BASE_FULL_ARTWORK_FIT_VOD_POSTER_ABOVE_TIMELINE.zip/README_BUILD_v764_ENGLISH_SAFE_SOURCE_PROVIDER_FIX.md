# v764 English Safe Source Provider Fix

Base: v763 recovery baseline / v764 emergency stability rollback.

Applied only safe, targeted changes:
- Stremio addon streams are ranked English-first inside each configured addon response.
- Configured addon URLs are still respected exactly; no global language filtering removes user-configured results.
- Source Intelligence keeps provider split/picker row for installed providers such as Torrentio, MediaFusion, Comet, Debrido, and TorBox.
- KSPlayer English audio selection is one-shot and guarded: it waits until KSPlayer exposes non-empty audio tracks, never indexes empty arrays, and never calls startup AVURLAsset probing.
- Startup loadRealMediaTrackMetadata(from:) remains disabled to avoid the previous SIGTRAP crash.

Validation:
- swiftc -parse Sources/*.swift passed.
