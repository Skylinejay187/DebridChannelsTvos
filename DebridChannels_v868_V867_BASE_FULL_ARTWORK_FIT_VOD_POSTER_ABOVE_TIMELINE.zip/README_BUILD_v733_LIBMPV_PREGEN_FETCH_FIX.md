# v733 LIBMPV PREGEN FETCH FIX

- MPVKit remains fully removed.
- FFmpegKit remains the only SwiftPM FFmpeg provider.
- Added `Scripts/fetch_libmpv_vendor.sh` and wired it with XcodeGen `preGenCommand` so libmpv is fetched before `xcodebuild` validates linked frameworks.
- Kept a build verifier that fails clearly if `Vendor/libmpv/libmpv.framework` is missing or fake/small.

Expected log change:
- `Generate Xcode Project` should now show `DEBRID CHANNELS TVOS V733 PREGEN FETCH REAL LIBMPV`.
- SwiftPM Resolve Package Graph should still only show KSPlayer/FFmpegKit; libmpv is not SwiftPM and will not appear there.
