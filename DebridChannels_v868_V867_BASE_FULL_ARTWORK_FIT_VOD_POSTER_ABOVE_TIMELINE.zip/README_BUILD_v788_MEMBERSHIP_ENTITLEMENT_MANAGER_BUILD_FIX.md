# DebridChannels tvOS v788 — Membership Entitlement Manager Build Fix

Baseline:
- DebridChannels_tvOS_v788_ARCHITECTURE_MIGRATION_MEMBERSHIP_ENTITLEMENT_MANAGER_READY_UPLOAD.zip

Fix:
- Corrected `MembershipScreen.refreshTrialStatus()` after step 14 migration.
- The screen-level restore/status refresh accidentally referenced `context.backendBaseURL`, `context.deviceId`, and `context.deviceName` outside the scope where `context` exists.
- Replaced that call with the existing MembershipScreen values: `backendBaseURL`, `deviceId`, and `deviceName`.

Scope:
- Build fix only.
- No membership behavior changes.
- Trial lockout, owner login taps, restore/devices access, and plan UI preserved.
