# v801 Bottom-left ticker + media bar layer fix

Base: v800 real wiring fix.

Changes:
- Movies/Shows ticker moved from the top card area to the bottom-left safe gutter under the Live TV grid.
- Sports ticker overlay now uses the existing PremiumSportsTickerShell theme and anchors to the same bottom safe lane.
- Tickers remain hidden whenever quick panels, detail overlay, search, playback, membership lockout, or onboarding own the screen.
- Media Info top bar transparency note clarified: the black/glass background and secondary background layer both follow the same transparency scale.

No playback, Source Intelligence, membership, guide parser, or catalog logic changed.
