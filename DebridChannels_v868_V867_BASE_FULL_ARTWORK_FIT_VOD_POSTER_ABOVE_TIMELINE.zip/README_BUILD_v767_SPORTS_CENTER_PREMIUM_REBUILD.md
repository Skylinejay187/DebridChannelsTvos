# DebridChannels tvOS v767 — Sports Center Premium Rebuild

Base: v766 Sports Center Rebuild + Global Ticker

Scope:
- Rebuilt Sports Center visual presentation into a broadcast-style SportsCenter hub.
- Added premium stadium backdrop, diagonal broadcast texture, hero scoreboard panel, and larger event-first hero design.
- Replaced generic ticker look with premium DC SportsCenter ticker shell.
- Global ticker avoids the Live TV grid surface to prevent covering/competing with live TV cards.
- Kept sports-only M3U routing/classifier foundation and existing sports data model.
- No playback/VOD/English audio/Source Intelligence logic changed.

Verification:
- swiftc -parse Sources/*.swift passed.
