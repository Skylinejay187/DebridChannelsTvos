v753_SOURCE_INTELLIGENCE_ALERTS_METADATA_REBUILD

Scope:
- Source Intelligence now filters stream searches to playable stream-capable providers only. Catalog-only metadata providers such as Cinemeta/TMDB are marked metadata-only and are not queried as link providers.
- Source results publish ranked batches of 25 with a visible batch status, cancel state, and stale-search generation guard.
- Episode ranking keeps exact SxxExx matches ahead of season packs, pushes wrong explicit episodes down/out, and labels exact matches in the Source Intelligence UI.
- Source Intelligence overlay is reorganized into Best Matches, Resolving, and Other Sources sections with compact source metadata pills.
- New episode heartbeat starts while the app is active, respects the selected 5/10/30 minute interval, restarts after catalog load, persists last/next checked timestamps, and keeps foreground banner presentation.
- Metadata enrichment keeps TMDB primary for posters/backdrops/logos, uses IMDb bridging/OMDb Rotten Tomatoes paths already present in the app, and adds a v753 artwork cache keyed by TMDB/IMDb/media ID.

Local verification:
- `swiftc` is not installed in this environment, so source parsing/building could not be run locally.
- Static call-site checks were run with `rg` after edits.
