# v764 Scrubber / Status / Provider Retention Fix

Base: current working v764 recovery package from clean v763 lineage.

Scope intentionally narrow:
- Restored a real focusable timeline target for VOD scrubber focus lock.
- Restored VOD status chips below the timeline: current/total, remaining, watched percent, cache status, and source info.
- Fixed Source Intelligence provider switching so provider chips filter already-found links instead of launching a new search and clearing results.
- Balanced All Providers results across detected providers within the 50-link cap so one addon cannot dominate the whole list.
- Increased Source Intelligence overlay vertical room and moved it upward to prevent the last visible link from being clipped at the bottom.

Not changed:
- No playback startup metadata probing was re-enabled.
- No English/audio-player startup logic was changed in this pass.
- No mini-player, PiP, multi-view, VOD Links chip, or playback experiment code was added.

Validation:
- `swiftc -parse Sources/*.swift` passed.
