DebridChannels tvOS v749_HEADER_SPACING_AND_ROW_FLASH_FIX

- Moves only the focused provider/category header upward by increasing its own bottom spacing; row/card geometry, focused card size, next-row labels, bottom text, player systems, and catalog loading remain unchanged.
- Scopes focused-row artwork identity by row ID plus media ID so previous-row image requests are cancelled when row focus changes.
- Gates media-info backdrop/logo artwork by selected media ID for a fresh render pass before any detail artwork URL is supplied.
- Keeps media-info on a neutral black placeholder/fade until the selected item artwork is allowed to load.
- Prevents previous row poster/backdrop/logo artwork from feeding the new details overlay during row-to-detail handoff.
- Updates the build marker for GitHub Actions/upload identification.
