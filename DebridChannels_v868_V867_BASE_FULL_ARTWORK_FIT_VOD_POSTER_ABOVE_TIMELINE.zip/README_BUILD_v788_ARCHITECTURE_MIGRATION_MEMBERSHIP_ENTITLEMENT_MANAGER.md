# DebridChannels tvOS v788 — Architecture Migration Step 14

Step 14 only: Membership/entitlement manager cleanup.

## Scope
- Added `MembershipEntitlementManager.swift`.
- Centralized trial expiry parsing, lockout decision, bootstrap marker, expired-trial marking, backend request context, and entitlement apply mapping.
- Preserved existing backend entitlement source-of-truth behavior.
- Preserved trial lockout, paid/admin unlock, Membership tab routing, owner access path, Restore/Devices behavior, and existing UI.

## Not changed
- No Sports changes.
- No Live TV guide/cache changes.
- No playback/player engine changes.
- No Source Intelligence changes.
- No settings visual/focus behavior changes.

Build marker:
`DEBRID_CHANNELS_TVOS_BUILD_V788_ARCHITECTURE_MIGRATION_MEMBERSHIP_ENTITLEMENT_MANAGER`
