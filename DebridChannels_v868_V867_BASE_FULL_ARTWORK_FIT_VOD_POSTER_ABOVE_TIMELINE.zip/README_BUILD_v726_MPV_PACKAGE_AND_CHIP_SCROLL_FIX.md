# v726 MPV Package + VOD Chip Scroll Fix

- Added MPVKit Swift Package dependency to `project.yml` so GitHub Actions/Xcode resolves and downloads MPVKit/libmpv during build instead of only searching empty Vendor paths.
- Added `_MPVKit` and `Libmpv` compile detection guards alongside `MPVKit`, `MPV`, and `libmpv`.
- Expanded MPV runtime lookup to include `_MPVKit` runtime class names.
- Changed VOD controls into one horizontal scrollable chip rail so every chip can be reached with Left/Right.
- Added the Close chip to the scroll order and simplified Up/Down so Up returns to timeline cleanly.
