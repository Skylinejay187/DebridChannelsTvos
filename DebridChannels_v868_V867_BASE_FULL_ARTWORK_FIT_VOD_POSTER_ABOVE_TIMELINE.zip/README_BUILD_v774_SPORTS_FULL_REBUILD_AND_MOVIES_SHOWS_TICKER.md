# DebridChannels tvOS v774 — Sports Full Rebuild + Movies/Shows Release Ticker

Base: v773 Trailer v400 Exact Restore

Changes:
- Sports rebuilt to use the screenshot-style Sports Media Center layout path.
- Sports screen now uses the full live viewing surface layout instead of the older cluttered SportsReborn layout.
- Removed the negative-overlap quick-channel block that caused Live & Upcoming and Live Sports Channels to collide.
- Sports global ticker defaults OFF.
- Added Movies & Shows release ticker, defaults ON.
- Movies/Shows ticker is separate from sports ticker and appears as a compact bottom-left alert with poster/title/type info.
- Added Settings toggle for Movies & Shows Release Ticker.
- No playback engine changes.
- v400 trailer restore from v773 preserved.
