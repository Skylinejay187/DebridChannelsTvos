# DebridChannels tvOS v795 — Production Hardening: Diagnostics & Developer Tools

Base: v794 build-fix 2.

Scope only:
- Added `DiagnosticsDeveloperToolsManager.swift`.
- Added read-only diagnostic snapshot support for:
  - Playback
  - Network / API
  - Live TV guide/cache
  - Source Intelligence
  - Membership / entitlement
  - App-wide state
- Added a reusable `DiagnosticsDeveloperToolsPanel` view for future safe internal debug screens.

Rules preserved:
- No UI redesign.
- No normal navigation changes.
- No playback engine changes.
- No source/provider behavior changes.
- No membership behavior changes.
- No backend endpoint changes.

This is a passive production QA tool layer only.
