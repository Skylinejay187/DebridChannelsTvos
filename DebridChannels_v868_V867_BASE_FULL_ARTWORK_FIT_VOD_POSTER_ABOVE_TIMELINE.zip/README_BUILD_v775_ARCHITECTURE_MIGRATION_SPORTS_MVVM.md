# Debrid Channels tvOS v775 — Architecture Migration Start: Sports MVVM

Baseline: `DebridChannels_tvOS_v774_SPORTS_FULL_REBUILD_AND_MOVIES_SHOWS_TICKER_BUILD_FIX_2_READY_UPLOAD.zip`

Migration step completed:
1. Sports Center MVVM rebuild

What changed:
- Added `Sources/SportsCenterViewModel.swift`.
- Moved Sports Hub screen-derived rows/status logic out of `SportsHubScreen`.
- Preserved v774 Sports layout, channel grouping, score/ticker feed behavior, and playback opening behavior.
- Kept the sports classifier logic behavior-identical inside the new view model for this pass.
- Updated build marker to `DEBRID_CHANNELS_TVOS_BUILD_V775_ARCHITECTURE_MIGRATION_SPORTS_MVVM`.

What was intentionally not changed yet:
- Sports provider layer remains in `SportsLiveZoneModel`.
- Full `SportsChannelClassifierManager` split is next migration step.
- Movies/Shows ticker, trailer cleanup, Source Intelligence, resolver, Live TV cache, alerts, playback, settings, and membership cleanup were untouched.

Verification notes:
- `project.yml` now includes `Sources/SportsCenterViewModel.swift`.
- Brace/parenthesis balance checked for edited Swift files.
- No app behavior was intentionally redesigned in this build.
