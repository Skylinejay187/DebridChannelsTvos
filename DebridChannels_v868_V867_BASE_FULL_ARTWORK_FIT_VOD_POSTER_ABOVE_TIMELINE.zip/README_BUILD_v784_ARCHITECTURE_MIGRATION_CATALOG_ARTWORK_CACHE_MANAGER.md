# DebridChannels tvOS v784 — Architecture Migration: Catalog Artwork/Cache Manager

## Scope
Step 10 only from the architecture migration plan.

## What changed
- Added `Sources/CatalogArtworkCacheManager.swift`.
- Moved catalog artwork URL selection helpers into the manager:
  - preferred backdrop selection: landscape → preview → poster
  - themed logo URL normalization
  - provider labeling: Fanart / TMDB / Cinemeta / Stremio
- Moved catalog artwork theme flag interpretation into the manager:
  - Artwork background enablement
  - Artwork 2 / Artwork 3 Hero / Artwork 4 Hero 2 / Artwork 5 Floating
  - transparent panel / floating quick panel / hero depth decisions
  - existing backdrop opacity, saturation, and contrast values
- Added the new source file to `project.yml`.

## Behavior preservation
- No UI layout changes.
- No poster quality/provider changes.
- No RemoteImageFit or AsyncImage rendering behavior changed.
- No Live TV guide/session behavior changed.
- No Sports, trailers, playback, membership, or Source Intelligence behavior changed.

## Build marker
`v784_ARCHITECTURE_MIGRATION_CATALOG_ARTWORK_CACHE_MANAGER`
