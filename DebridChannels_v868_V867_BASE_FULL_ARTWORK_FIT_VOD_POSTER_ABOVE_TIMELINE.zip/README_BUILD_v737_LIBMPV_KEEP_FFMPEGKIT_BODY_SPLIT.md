# v737 LIBMPV KEEP FFMPEGKIT BODY SPLIT

- Do not replace KSPlayer/FFmpegKit with MPVKit.
- Build log confirms FFmpegKit is providing a `libmpv` target and processing `Sources/libmpv.xcframework`.
- The current failure is not an MPV download failure; it is SwiftUI type-checking in `DebridChannelsTVOSApp.swift`.
- Split the large VOD player bottom chrome into `vodBottomChromeLayer` so the main player `body` type-checks faster.
- Keep MPVKit removed to avoid duplicate `Libavcodec`, `Libavfilter`, etc. package targets.
