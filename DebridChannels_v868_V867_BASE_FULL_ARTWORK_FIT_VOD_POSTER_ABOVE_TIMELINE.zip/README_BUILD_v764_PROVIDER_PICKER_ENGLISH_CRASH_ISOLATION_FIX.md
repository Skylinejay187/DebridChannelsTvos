# v764 Provider Picker + English Crash Isolation Fix

Base: v763 recovery baseline / v764 stability package.

Fixes in this pass:
- Kept Stremio English-first stream ranking from configured addon results.
- Kept provider picker row for installed source addons such as Torrentio, MediaFusion, Comet, Debrido, TorBox.
- Moved provider-picker state/focus mutations onto the main actor to prevent SwiftUI state races while providers resolve.
- Changed provider chip ForEach identity to stable offsets to avoid duplicate provider-name identity traps.
- Disabled Source Intelligence AVURLAsset background probing from the panel; it now uses safe addon/title metadata only.
- Delayed KSPlayer English audio selection until explicit `.readyToPlay`, then applies once after a short delay and only if tracks exist.
- Kept `loadRealMediaTrackMetadata(from:)` startup probing disabled.

Validation:
- `swiftc -parse Sources/*.swift` passed.
