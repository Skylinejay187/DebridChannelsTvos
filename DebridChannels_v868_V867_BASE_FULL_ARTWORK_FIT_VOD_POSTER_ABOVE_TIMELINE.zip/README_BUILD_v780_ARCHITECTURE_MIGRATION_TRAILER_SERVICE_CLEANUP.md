# DebridChannels tvOS v780 — Architecture Migration Step 6

Baseline: v779_ARCHITECTURE_MIGRATION_MOVIES_SHOWS_TICKER_MANAGER

Scope: Step 6 only — Trailer service cleanup using the stable v400/v399-style trailer lane.

Changes:
- Added `Sources/TrailerServiceManager.swift`.
- Centralized trailer identity/cache-key generation in the manager.
- Centralized direct-preview URL guard logic in the manager.
- Centralized IMDb/TMDB trailer ID extraction helpers in the manager.
- Centralized playable trailer URL filtering in the manager.
- Kept CatalogStore public trailer APIs and current UI/playback behavior intact.

Preserved behavior:
- Trailer button remains trailer-only and does not trigger movie/show source scanning.
- Stremio/addon trailer scanning remains disabled for now.
- KinoCheck/TMDB/YouTube backend resolver chain remains unchanged.
- Existing trailer cache key behavior remains title/year/type based.
- No changes to Sports Center, sports ticker, movies/shows ticker UI, Source Intelligence, VOD playback, Live TV, membership, or settings.

Migration status:
- Completed migration item 6 of 15.
- Next planned migration item: Source Intelligence manager cleanup.
