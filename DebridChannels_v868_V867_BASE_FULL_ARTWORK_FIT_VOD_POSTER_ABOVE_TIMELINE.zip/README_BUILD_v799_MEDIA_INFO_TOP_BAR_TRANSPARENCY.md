# DebridChannels tvOS v799 — Media Info Top Bar Transparency

Scope: targeted Appearance setting only.

Changes:
- Added Settings → Appearance → Media Info Top Bar Transparency.
- Options:
  - Solid / 0% Transparency: current/default black top-bar background.
  - Medium / 50% Transparency: same bar with half-strength black/glass background.
  - Clear / 100% Transparency: removes the black top-bar background.
- Applies only to the black/glass background layer of the top media information bar.
- Preserves poster, metric chips, advisory bubble, hero artwork, half-dark poster/background treatment, buttons, credits, Sports, Live TV, Movies/Shows quick panel, playback, and backend logic.
- Persists setting in UserDefaults and includes it in existing settings export/import.

Verification notes:
- No Sports logic changes.
- No ticker logic changes.
- No playback/KSPlayer changes.
- No Source Intelligence changes.
