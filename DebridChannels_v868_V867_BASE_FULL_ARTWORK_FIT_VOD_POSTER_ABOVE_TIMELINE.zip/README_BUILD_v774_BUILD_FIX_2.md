# v774 Build Fix 2

Fixed remaining Swift exhaustive switch errors in Settings focus navigation by adding `moviesShowsTickerToggle` to both DOWN and UP focus paths.

Validation:
- `swiftc -parse` passed for project Swift sources.
- No playback logic changed.
