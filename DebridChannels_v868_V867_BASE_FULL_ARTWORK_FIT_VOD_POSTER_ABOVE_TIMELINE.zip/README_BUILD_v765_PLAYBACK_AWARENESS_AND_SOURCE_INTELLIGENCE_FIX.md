# DebridChannels tvOS v765 — Playback Awareness and Source Intelligence Fix

Base: v764 working build.

Narrow changes only:
- Media information Play button now reports staged startup status: Preparing Playback, Finding Best Available Source, Resolving Real-Debrid when applicable, Testing Stream, and Opening Player.
- Fast dead-link preflight marks only definitive HTTP 403/404/410 sources as unavailable and tries the next ranked source.
- Dead links are not saved to last-link cache.
- No playback engine, English audio, KSPlayer, AVPlayer, metadata probing, resolver, timeline, or cache architecture changes.
