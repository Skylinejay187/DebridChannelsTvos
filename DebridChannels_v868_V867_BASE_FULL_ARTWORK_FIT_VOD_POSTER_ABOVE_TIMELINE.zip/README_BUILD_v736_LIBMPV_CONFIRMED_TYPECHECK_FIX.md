# v736 libmpv confirmed + Swift body type-check fix

This pass does not add MPVKit. MPVKit remains removed.

Important: libmpv is expected to appear in the build log as an explicit dependency/product from the existing FFmpegKit package, not as a separate Fetching line. The previous v735 log confirmed:

- Explicit dependency on target 'libmpv' in project 'FFmpegKit'
- ProcessXCFramework ... FFmpegKit/Sources/libmpv.xcframework ... libmpv.framework
- Copy ... DebridChannelsTVOS.app/Frameworks/libmpv.framework
- SwiftCompile MPVPlaybackEngine.swift / MPVPlayerViewModel.swift / MPVRenderView.swift

Actual failure was SwiftUI type-checking in DebridChannelsTVOSApp.swift body. This pass extracts playback surface selection into playbackSurfaceLayer(_:), reducing the body generic expression size while keeping AVPlayer / KSPlayer / VLC / libmpv routing intact.
