# DebridChannels tvOS v779 — Architecture Migration Step 5

Baseline: v778_ARCHITECTURE_MIGRATION_SPORTS_TICKER_FAVORITES_MANAGER

## Scope
Step 5 only: Movies/Shows ticker manager.

## Changes
- Added `Sources/MoviesShowsTickerManager.swift`.
- Moved Movies/Shows release ticker item filtering/capping logic out of `MoviesShowsReleaseTickerOverlay`.
- Moved ticker badge text and metadata-line formatting into the manager.
- Registered the new manager file in `project.yml`.

## Behavior preservation
- Ticker remains bottom-left.
- Same visibility gate remains in the root app shell.
- Same item source: current catalog rows.
- Same filter: movie / series / show.
- Same cap: 24 items.
- Same 5.5-second card rotation and visual card design.

## Migration checklist
1. Sports Center MVVM rebuild — done in v775.
2. Sports channel classifier manager — done in v776.
3. Sports scores/schedules provider layer — done in v777.
4. Sports ticker + favorite teams manager — done in v778.
5. Movies/Shows ticker manager — done in v779.
