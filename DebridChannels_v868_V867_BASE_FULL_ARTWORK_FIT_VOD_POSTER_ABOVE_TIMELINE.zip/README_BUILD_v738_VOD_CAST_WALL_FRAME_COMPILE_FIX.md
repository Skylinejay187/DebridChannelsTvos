# DebridChannels tvOS v738 — VOD Cast Wall Frame Compile Fix

Scope:
- Fixed the SwiftUI compile error from v737 at `VODTheaterCastWall`.
- The prior build used `.frame(width:minHeight:maxHeight:alignment:)`, which is not a valid SwiftUI overload.
- Replaced it with two chained frame modifiers:
  - fixed width frame
  - bounded min/max height frame

Preserved from v737:
- FFmpegKit remains the single FFmpeg provider.
- MPVKit remains removed.
- libmpv path remains based on the existing FFmpegKit-backed integration work.
- VOD overlay body split remains preserved.
