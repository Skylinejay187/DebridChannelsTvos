DebridChannels tvOS v746_VOD_SEEK_RT_MPV_PROVIDER_ROW_POLISH

- Preserves v742+ Libmpv packaging/signing and v745 native-style VOD overlay baseline.
- Adds MPV runtime diagnostics for create/init/loadfile/render/playback/first-frame/fallback state.
- Keeps MPV as the first attempt when selected, including MKV, with KSPlayer fallback only after MPV failure.
- Improves OMDb/Rotten Tomatoes lookup by resolving IMDb IDs from explicit metadata, embedded ids, or TMDB external IDs.
- Keeps KSPlayer accurate seek enabled and routes Back 30, Forward 30, and timeline scrubs to the active KSPlayer instance.
- Refreshes VOD chips with compact Apple-style glass styling.
- Removes duplicate provider/category labels from the quick panel and replaces pill/badge headers with flat provider/category marks.
- Keeps cast wall capped at five and shrink-wrapped to visible cast content.
