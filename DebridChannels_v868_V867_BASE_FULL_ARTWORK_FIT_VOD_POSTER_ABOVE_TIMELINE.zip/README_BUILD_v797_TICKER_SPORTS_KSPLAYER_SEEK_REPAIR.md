# Debrid Channels tvOS v797 — Ticker Placement + Sports Redesign + KSPlayer Seek Restore

Scope: targeted repair build after v796.

Changes:
- Restored KSPlayer seek/fast-forward/rewind behavior using direct seek jumping without changing player engines.
- Kept Movies/Shows and Sports tickers, but moved them into top safe overlay lanes so they do not cover Live TV grid cards.
- Hid both tickers while Home/Movies/Shows quick catalog panels are active and while Live TV quick panel is open.
- Added themed compact ticker styling for safer Live TV placement.
- Refreshed Sports Center visual structure with a standalone command header and reduced oversized hero footprint.
- Added Sports Section removal support: long-press/context menu on a sports channel card can remove it from Sports.
- Persisted removed sports channels in `sportsExcludedChannelIds` so automatic classification does not re-add them.

Preserved:
- No MVVM migration.
- No new playback engine.
- No Live TV source/cache rewrite.
- No unrelated settings/navigation changes.
