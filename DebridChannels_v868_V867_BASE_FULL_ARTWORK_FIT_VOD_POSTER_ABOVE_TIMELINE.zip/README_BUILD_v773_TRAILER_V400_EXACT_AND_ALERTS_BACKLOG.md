# v773 Trailer v400 Exact Restore + Ticker/Sports Backlog

- Restored trailer popup playback surface to the v400 KSPlayer-only lane.
- Removed trailer-specific routeHint/display-match/reload/id churn from trailer surface.
- Backend remains responsible for resolving/remuxing to one direct playable trailer URL.
- No VOD playback changes.
- Sports full rebuild and Movie/Show ticker are acknowledged as next larger UI module work.
