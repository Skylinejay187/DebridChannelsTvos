# v730 MPV Module Alias + OMDb/RT + VOD Overlay Fix

Changes:
- Adds `LocalPackages/DebridMPV`, a local SwiftPM wrapper around `mpvkit/MPVKit`.
- Uses SwiftPM `moduleAliases` for MPVKit `Libav*` binary targets so MPVKit can coexist with existing KSPlayer/FFmpegKit without the duplicate `Libavcodec`, `Libavfilter`, etc. resolver crash.
- Adds `DebridMPV` to the XcodeGen target dependencies so GitHub Actions should show MPVKit fetching/resolving again.
- Keeps MPV Settings as a real selectable engine path instead of an unavailable placeholder.
- Improves OMDb Rotten Tomatoes score lookup by retrying title/year when IMDb-id lookup returns no RT score.
- Tightens VOD overlay horizontal chip rail so every chip has bounded tvOS focus scrolling.
- Shrinks/rebounds the Cast Wall so it no longer clips on the right edge.

Validation target:
- Build log should show `mpvkit/MPVKit` through `LocalPackages/DebridMPV`.
- Build should no longer fail with duplicate `Libav*` package targets.
