DebridChannels tvOS v747_NATIVE_OVERLAY_MPV_RUNTIME_CACHE_ENGLISH_FIX_READY_UPLOAD

- Restores lower v702/v711-style catalog row placement with provider/category icons and no header pill background.
- Clears media info detail state between items so prior poster/backdrop/logo artwork cannot flash while the next item loads.
- Routes cache-enabled VOD playback through the local cache proxy for AVPlayer, KSPlayer, and MPV when available.
- Extends VOD overlay auto-hide to 15 seconds of full inactivity and resets the timer on remote/focus/timeline/chip interaction.
- Adds English-first metadata and track preferences across TMDB metadata, AVPlayer, KSPlayer, and MPV.
- Adds MPV runtime diagnostics for create/init/render/loadfile/playback/first-frame failure paths.
- Gates all internal player surfaces behind first-frame readiness so users see the poster/logo/backdrop loading overlay instead of black AVPlayer/KSPlayer/MPV render surfaces.
- Preserves v742+ Libmpv install/signing, package structure, source intelligence, trailer, membership, and tvOS upload layout.
