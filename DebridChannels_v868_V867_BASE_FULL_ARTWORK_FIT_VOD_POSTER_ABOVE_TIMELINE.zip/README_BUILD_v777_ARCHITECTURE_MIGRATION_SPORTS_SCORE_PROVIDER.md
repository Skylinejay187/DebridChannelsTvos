# DebridChannels tvOS v777 — Architecture Migration Step 3

Baseline: `DebridChannels_tvOS_v776_ARCHITECTURE_MIGRATION_SPORTS_CLASSIFIER_MANAGER_READY_UPLOAD.zip`

## Scope
Step 3 only: Sports scores/schedules provider layer.

## Changes
- Added `Sources/SportsScoresScheduleProvider.swift`.
- Moved ESPN scoreboard fetch/mapping out of `SportsLiveZoneModel`.
- Moved TheSportsDB daily schedule fetch/mapping out of `SportsLiveZoneModel`.
- Updated `SportsLiveZoneModel.load(...)` to call the provider while preserving the same combined arrays, ticker text, fallback behavior, and status wording.
- Added the new provider to `project.yml` sources.

## Preserved
- Sports Center layout and rows.
- Sports classifier behavior from v776.
- Sports ticker behavior.
- Favorite teams, highlights, sports-only M3U, PPV, command center, theater, and heat map behavior.
- No unrelated Live TV, VOD, trailer, membership, catalog, or playback changes.

## Migration checklist
1. Sports Center MVVM rebuild — done in v775.
2. Sports channel classifier manager — done in v776.
3. Sports scores/schedules provider layer — done in v777.
4. Sports ticker + favorite teams manager — next.
