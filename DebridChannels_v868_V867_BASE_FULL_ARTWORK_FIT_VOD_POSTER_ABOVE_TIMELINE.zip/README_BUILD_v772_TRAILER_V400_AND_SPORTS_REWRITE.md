# DebridChannels tvOS v772 — Trailer v400 Restore + Sports Rewrite Pass

Base: v771 Sports Media Center build.

Changes:
- Restored the proven v400 trailer resolve lane:
  - single `/trailers/resolve` backend endpoint
  - `prefer4k=false`, `minHeight=720`, `maxHeight=1080`
  - `fast=true`, `reuseCache=true`, `singleFlight=true`
  - cache polling restored for prepared trailer jobs
  - no app-side Stremio trailer scanning
  - no raw YouTube page playback in app
- Locked trailer popup playback back to KSPlayer only.
- Replaced Sports Center surface with a new Sports Reborn layout pass:
  - live sports viewing stage
  - right-side live score board
  - inside Sports Wire ticker
  - live/upcoming event rail
  - smart sports channel rows
  - bottom-left global ticker remains separate

No VOD/player-startup logic changed.
