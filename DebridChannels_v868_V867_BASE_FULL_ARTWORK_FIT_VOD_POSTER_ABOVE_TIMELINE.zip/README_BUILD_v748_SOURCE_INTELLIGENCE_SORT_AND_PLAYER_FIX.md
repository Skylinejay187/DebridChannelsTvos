DebridChannels tvOS v748_SOURCE_INTELLIGENCE_SORT_AND_PLAYER_FIX

- Carries forward the KSPlayer default VOD player restore, focused header position fix, and KSPlayer native seek/scrub path.
- Sorts Source Intelligence links by cached first, explicit English first, 4K/2160p first, lowest GB/file size within matching resolution, then codec/provider reliability.
- Auto-selects the highest ranked direct source for Play instead of resuming a stale previous source before ranking.
- Shows Source Intelligence resolution, language, size, codec, provider, direct-play status, and cache status in source rows/details.
- Prevents uncached or non-English sources from ranking above cached English 4K sources when metadata is available.
- Updates the build marker for GitHub Actions/upload identification.
