# v734 LIBMPV FROM FFMPEGKIT PRODUCT

- Removed MPVKit completely.
- Removed separate Vendor/libmpv framework dependency that Xcode validated before scripts could run.
- Added direct app dependency on `libmpv` product from `kingslay/FFmpegKit` 6.1.3.
- This keeps FFmpegKit as the only SwiftPM FFmpeg/Libav provider, avoiding duplicate Libavcodec/Libavfilter targets.
- Build log should still show only KSPlayer and FFmpegKit packages, but the target dependency graph should include `libmpv` from FFmpegKit.
