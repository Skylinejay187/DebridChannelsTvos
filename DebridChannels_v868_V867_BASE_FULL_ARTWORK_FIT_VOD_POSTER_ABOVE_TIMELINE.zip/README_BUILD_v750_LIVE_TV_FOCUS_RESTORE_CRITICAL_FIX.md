DebridChannels tvOS v750_LIVE_TV_FOCUS_RESTORE_CRITICAL_FIX

- Saves Live TV focus before channel playback: channel ID, channel index, category/filter row ID, rendered grid window, origin, and guide/grid state.
- Restores focus after playback closes to the exact prior Live TV card when available, or the nearest valid channel if the previous channel no longer exists.
- Restores grid/guide scroll window and reasserts tile/guide focus over multiple run-loop passes so directional navigation works immediately.
- Prevents focus from falling back to the top menu or nil after closing Live TV playback.
- Applies through the central Live TV play path used by grid, full guide, My Favorites/category filters, and channel routes.
- Preserves v749 previous-row artwork flash fix, focused header spacing, KSPlayer default/scrub fixes, first-frame gating, OMDb/RT display, and Source Intelligence sorting.
