# DebridChannels tvOS v782 — Architecture Migration Step 8

Baseline: v781 Source Intelligence manager cleanup.

Scope: Step 8 only — Debrid resolver/preflight manager.

Changes:
- Added `Sources/DebridResolverPreflightManager.swift`.
- Moved direct playable URL normalization into the manager.
- Moved alternate direct-link ordering into the manager.
- Moved subtitle URL extraction into the manager.
- Moved lightweight HEAD/range preflight into the manager.
- Kept `CatalogStore` wrapper methods so existing playback/source handoff call sites remain stable.
- Added the new manager file to `project.yml`.

Preserved behavior:
- Source Intelligence UI and ranking unchanged.
- Direct-play link selection unchanged.
- Known-dead 403/404/410 rejection behavior unchanged.
- HEAD/preflight failures still return unknown instead of blocking playback.
- Playback fallback URL ordering unchanged.
- Subtitle URL collection unchanged.

Migration status:
1. Sports Center MVVM rebuild — done v775
2. Sports channel classifier manager — done v776
3. Sports scores/schedules provider layer — done v777
4. Sports ticker + favorite teams manager — done v778
5. Movies/Shows ticker manager — done v779
6. Trailer service cleanup using v400 logic — done v780
7. Source Intelligence manager cleanup — done v781
8. Debrid resolver/preflight manager — done v782
