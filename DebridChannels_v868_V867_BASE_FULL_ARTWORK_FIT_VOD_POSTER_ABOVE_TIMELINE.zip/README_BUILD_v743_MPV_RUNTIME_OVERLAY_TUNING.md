# v743 — MPV runtime bridge + VOD overlay tuning

Fixes from v742 test:

- Keeps MPV selectable/default, but replaces the placeholder Obj-C wrapper runtime probe with a direct `libmpv` C-symbol bridge.
- Attempts to load streams through `mpv_create` / `mpv_initialize` / `mpv_command(loadfile)` instead of looking for nonexistent MPVKit wrapper classes.
- Adds an MPV startup watchdog so a black MPV surface does not stay stuck forever; if no progress/render movement is detected it falls back to KSPlayer with a clear reason.
- Shrinks the VOD controls chip box height back to a compact Apple-style rail.
- Removes the animated `scrollTo` second-pass that caused a double-scroll feel; chip focus now snaps into view after focus moves.
- Increases chip movement debounce to reduce duplicate D-pad movement.
- Restores cast wall capacity from 3 people to up to 6 people and makes the cast row horizontally clipped/scrollable so it does not cut off names/cards.
