# DebridChannels tvOS v794 — Production Hardening: Backend API Contract Cleanup + Source Intelligence Link Limit

Base: v793_PRODUCTION_HARDENING_PERFORMANCE_LOADING_OPTIMIZATION

Scope:
- Production hardening pass 5 only.
- Backend/API contract cleanup notes retained as a low-risk hardening pass.
- Source Intelligence default maximum links changed to 25.
- Added Settings → Source Intelligence → link limit selection:
  - 25 Links / Recommended
  - 50 Links
- Link limit is persisted in AppStorage/UserDefaults using `sourceIntelligenceMaximumLinks`.
- Source Intelligence ranking, provider balancing, quality sorting, paging, and playback handoff are preserved.

Behavior:
- Default remains fast/responsive at 25 ranked links.
- Users can opt into 50 links from Settings when they want more fallback choices.
- No UI redesign, navigation changes, or player engine changes.
