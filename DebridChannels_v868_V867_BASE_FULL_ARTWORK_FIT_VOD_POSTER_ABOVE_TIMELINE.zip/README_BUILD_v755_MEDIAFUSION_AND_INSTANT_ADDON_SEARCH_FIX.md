v755_MEDIAFUSION_AND_INSTANT_ADDON_SEARCH_FIX

Scope:
- Kept v753/v754 Source Intelligence resolving, ranking, episode matching, and 25-link batching intact.
- Added progressive addon catalog search for the Search screen.
- Search now shows local loaded catalog results immediately, starts TMDB quickly, and loads addon catalog results in the background.
- Added query-change cancellation and debounce for TMDB and addon searches.
- Added addon result cache keyed by query/provider and emits cached addon results immediately.
- Added per-provider statuses: Loading, Results, No results, Timed out, Failed.
- Added per-addon timeout and a conservative concurrent addon request limit.
- Stream-only addons are skipped for catalog search.
- Mixed MediaFusion addons use catalog resources for Search/Browse metadata only; Source Intelligence remains responsible for `/stream/{type}/{id}.json` playable links.
- TMDB search no longer blocks result rendering on per-title logo lookup; detail metadata enrichment can still resolve logos later.

Local verification:
- `swiftc` is not installed in this environment, so a local Swift parse/build could not be run here.
- Static call-site checks were run with `rg` after edits.
