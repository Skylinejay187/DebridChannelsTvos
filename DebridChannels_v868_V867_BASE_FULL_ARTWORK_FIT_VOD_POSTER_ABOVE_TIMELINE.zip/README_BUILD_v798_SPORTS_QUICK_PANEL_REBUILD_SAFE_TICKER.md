# DebridChannels tvOS v798

Targeted repair build:

- Rebuilt Sports surface to use the quick-panel-style SportsReborn media center.
- Sports now opens with a real sports hero/scores stage first.
- Sports rows now follow with live/upcoming sports information and verified sports TV channel cards.
- Added long-press/context action on sports channel cards: Remove from Sports Section.
- Removed sports channels persist via sportsExcludedChannelIds so classifier does not re-add them.
- Sports exclusion changes refresh the SportsCenterViewModel immediately.
- Movie/show and sports tickers use top chrome safe-lane math instead of floating over cards.
- Tickers remain hidden while catalog/quick panel surfaces are active.
- Playback, Source Intelligence, membership, Live TV guide, catalogs, and KSPlayer logic were left alone.
