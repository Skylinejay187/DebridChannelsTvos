# v739 REAL LIBMPV XCFRAMEWORK VENDOR

Scope:
- Removed the fake `FFmpegKit product: libmpv` dependency.
- Kept KSPlayer + FFmpegKit package graph unchanged.
- Added a real local XcodeGen framework dependency: `Vendor/MPV/Libmpv.xcframework`.
- Added a pre-build fetch step that downloads `Libmpv.xcframework.zip` from MPVKit release assets before Swift compile/link.
- MPVKit is not added as a SwiftPM package, avoiding duplicate SwiftPM Libav targets.
- MPV availability now keys off `canImport(Libmpv)` / `canImport(libmpv)` / `canImport(MPV)` from the vendored xcframework.

Expected build log:
- You should still see only KSPlayer + FFmpegKit in Swift Package resolve.
- During the target build, you should now also see `DEBRID CHANNELS TVOS V739 FETCHING REAL LIBMPV XCFRAMEWORK` and `Downloading real tvOS-compatible Libmpv.xcframework asset`.

Next scope after this build passes:
- OMDb/Rotten Tomatoes real lookup wiring into advisory/media info.
