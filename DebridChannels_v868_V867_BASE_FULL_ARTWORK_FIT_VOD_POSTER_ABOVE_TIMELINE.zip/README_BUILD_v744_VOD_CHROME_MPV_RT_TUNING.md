# v744 VOD Chrome, MPV runtime, OMDb/RT tuning

- Reduced VOD controls chrome height; removed Controls/help microcopy.
- Removed duplicate chip focus movement causing double-scroll/skips.
- Cast wall now displays up to 5 cast members in the compact VOD overlay.
- OMDb key lookup accepts common saved key aliases and prioritizes Rotten Tomatoes in advisory facts.
- MPV no longer silently looks like KSPlayer after a user-selected/default MPV failure; it reports the Metal render bridge issue instead of pretending MPV played.
- Kept KSPlayer fallback for automatic compatibility routes only.
