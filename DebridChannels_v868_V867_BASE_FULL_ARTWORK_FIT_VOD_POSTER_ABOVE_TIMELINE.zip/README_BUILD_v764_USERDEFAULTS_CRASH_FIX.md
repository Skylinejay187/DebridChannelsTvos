# v764 UserDefaults Crash Fix

Apple TV crash log `DebridChannelsTVOS-2026-06-23-172939.ips` showed the app aborting in CoreFoundation preferences:

- `__CFPREFERENCES_HAS_DETECTED_THIS_APP_TRYING_TO_STORE_TOO_MUCH_DATA__`
- `NSUserDefaults setObject:forKey:`
- `LastPlaybackLinkCacheManager.save(item:link:url:)`
- `MediaInfoPopup.activate()`

Fix:

- Stop writing Last Playback Link cache into `UserDefaults`.
- Store last-link cache in Application Support JSON file instead.
- Bound cache to 30 entries.
- Trim large URL/title/source fields before writing.
- Add encoded payload guard so link-memory cache can never exceed 48 KB.
- Keep failure non-fatal because last-link memory is convenience-only.

No playback engine, English audio, scrubber, or provider picker behavior was changed in this pass.
