# v740 Libmpv Placeholder Prebuild Fix

- Fixes the v739 build failure where XcodeGen linked `Vendor/MPV/Libmpv.xcframework` but Xcode stopped before prebuild scripts because the xcframework had no `Info.plist`.
- Adds a tiny, valid xcframework placeholder so Xcode can load the project graph.
- The V740 prebuild script then deletes/replaces the placeholder with the real `Libmpv.xcframework.zip` from the MPVKit release before Swift compile/link.
- MPVKit is still not added as a SwiftPM package, so KSPlayer + FFmpegKit remain the only SwiftPM media stack and there is no duplicate Libav target conflict.
