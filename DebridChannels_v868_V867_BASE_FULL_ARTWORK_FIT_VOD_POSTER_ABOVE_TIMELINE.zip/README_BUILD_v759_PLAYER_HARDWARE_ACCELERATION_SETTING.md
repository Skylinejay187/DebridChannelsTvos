Debrid Channels tvOS v759 - Player Hardware Acceleration Setting

Changes:
- Added Settings -> VOD Player -> Hardware Acceleration with Auto / Recommended, Force On, and Force Off options.
- Persisted the setting with AppStorage key vodHardwareAccelerationMode. Default is Auto / Recommended.
- KSPlayer now honors the setting through KSOptions.hardwareDecode.
- MPV now applies hwdec before loadfile: videotoolbox,auto-safe for Auto, videotoolbox for Force On, and no for Force Off, while keeping the Metal/gpu renderer requests.
- VLC now passes best-effort libVLC hardware options through TVVLCKit when available.
- AVPlayer remains on Apple's native path and reports diagnostics when software-only override is not exposed.
- Playback diagnostics now show Hardware Acceleration Setting, Active Decoder, Renderer, and hardware fallback reason.

Default VOD player remains KSPlayer.

Validation:
- Static source wiring was checked in the v759 tree.
- Local Swift/Xcode compile could not be run in this environment because swift, swiftc, xcodegen, and xcodebuild are not installed.
