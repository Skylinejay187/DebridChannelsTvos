DebridChannels tvOS v748_ROW_HEIGHT_AND_KSPLAYER_SCRUB_FIX

- Carries forward v747 native overlay, MPV runtime diagnostics, cache-first playback, English-first metadata/tracks, and first-frame loading gate fixes.
- Lowers the catalog quick-panel rail toward the bottom using v702/v711-style grounded placement while preserving provider/logo/category text and next-row labels.
- Keeps the top menu and Artwork 2 / Artwork 5 floating background behavior unchanged.
- Routes KSPlayer Back 30, Forward 30, and timeline scrub requests to the active KSPlayerLayer native seek API.
- Clamps KSPlayer seek targets to the active media duration, runs seek on the main thread, resumes playback after seek when appropriate, and logs rejected non-seekable/live seek attempts.
- Updates the build marker for GitHub Actions/upload identification.
