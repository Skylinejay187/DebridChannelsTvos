# DebridChannels tvOS v769 — Sports Live Viewing Center

Base: v768 Stability Prefs Fix

Changes:
- Reworked Sports top area from decorative hero into a live sports viewing surface.
- Added large selected-game viewing panel with score/status language and live-watch action when stream URL exists.
- Added right-side live scoreboard stack for other games while browsing/tuning.
- Added quick sports channel switch row using auto-routed M3U/Xtream sports channels.
- Kept sports ticker inside the Sports section surface rather than overlaying occupied Live TV/Movie grid space.
- Preserved v768 UserDefaults oversized-storage crash fixes.

Not changed:
- Playback engine logic
- English audio selection
- Source Intelligence playback logic
- UserDefaults cache architecture from v768

Validation:
- swiftc -parse Sources/*.swift passed with existing warning only.
