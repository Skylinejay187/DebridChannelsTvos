# v752_TOP_MENU_THEMES_LIVE_TIP_TMDB_LOGO_FIX

- Replaced the oversized top menu theme list with implemented presets only: Transparent Black Glass, Darker Glass, Lighter Glass, Minimal / No Background, Artwork Blend Mode, and Classic.
- Wired each top menu preset to the active `TopMenuBar` rendering path with distinct rail fill, stroke, focus fill, glow, spacing, and background behavior. Old saved theme names normalize to the closest implemented preset when the picker opens.
- Tightened the Live TV Quick Guide first-run tip so it appears only for Live playback after a first frame is ready, the overlay is hidden, no panel/Quick Guide is open, and the tip has not been shown before.
- Added a Settings debug reset for `liveQuickGuideTipShown` to reproduce fresh-profile testing without reinstalling.
- Added TMDB title-logo lookup for TMDB search results, TMDB default shelves, and detail metadata fallback, with TV and movie logo endpoints supported.
