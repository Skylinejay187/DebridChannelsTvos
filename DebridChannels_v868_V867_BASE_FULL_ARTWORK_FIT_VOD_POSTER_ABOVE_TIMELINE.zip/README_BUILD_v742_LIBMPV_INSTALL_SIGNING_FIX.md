# v742 Libmpv Install Signing Fix

Fixes the IPA install/signing crash where Plume/apple-codesign panicked while signing `Payload/DebridChannelsTVOS.app/Frameworks/Libmpv.framework`:

```text
index out of bounds: the len is 0 but the index is 0
```

Root cause: the downloaded MPVKit `Libmpv.xcframework` asset is usable at compile/link time, but the selected tvOS `Libmpv.framework` behaves like a static-style framework payload and should not be embedded as a runtime framework. Plume tries to sign the embedded framework as a dynamic framework and crashes.

Changes:

- Keeps real `Libmpv.xcframework` download before compile/link.
- Removes the post-build step that embedded `Libmpv.framework` into the app bundle.
- Adds a post-build cleanup step that deletes any accidental embedded `Libmpv.framework` before IPA packaging/signing.
- Leaves MPV framework available for compile-time/link-time detection.
- Does not reintroduce MPVKit SwiftPM, so FFmpegKit remains the only SwiftPM FFmpeg provider.
