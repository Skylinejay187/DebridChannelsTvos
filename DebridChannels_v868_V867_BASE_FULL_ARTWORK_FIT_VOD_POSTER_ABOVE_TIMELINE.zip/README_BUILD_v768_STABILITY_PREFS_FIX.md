# v768 Stability Preferences Fix

Source logs in Archive.zip showed repeated tvOS aborts from:
`__CFPREFERENCES_HAS_DETECTED_THIS_APP_TRYING_TO_STORE_TOO_MUCH_DATA__`

Crash paths:
- `LiveTVSourceModel.persistGuidePrograms(_:)`
- `CatalogStore.cacheArtwork(for:poster:backdrop:logo:)`
- SwiftUI/AppStorage write path

Fixes:
- Moved Live TV loaded channel cache from UserDefaults into file cache.
- Moved Live TV guide-program cache from UserDefaults into file cache.
- Removed old oversized Live TV UserDefaults payloads after migration.
- Capped metadata artwork cache before writing to UserDefaults.
- Capped catalog row cache placeholder before writing to UserDefaults.
- No playback logic changes.
- No sports design changes.

Validation:
- swiftc -parse passed.
