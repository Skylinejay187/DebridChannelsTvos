# DebridChannels tvOS v785 Alerts Manager Unification Build Fix

Scope: build fix only for Step 11.

Fix:
- Removed dependency on the fileprivate `Date.iso8601String` helper from `NewEpisodeAlertsManager.swift`.
- Added a local private ISO8601 day formatter for the developer test alert date string.

Behavior:
- No UI behavior changes.
- No alert timing, banner side, duration, focus, Sports, Live TV, Source Intelligence, or playback changes.
