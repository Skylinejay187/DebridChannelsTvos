# v727 MPV SwiftPM Duplicate Target Build Fix

Fixes the GitHub Actions failure during `Detect Scheme` / Swift Package resolution:

`multiple similar targets 'Libavcodec', 'Libavdevice', 'Libavfilter' ... appear in package 'ffmpegkit' and 'mpvkit'`

## Change

- Removed MPVKit from `project.yml` Swift Package dependencies because MPVKit and KSPlayer/FFmpegKit both expose overlapping `Libav*` SwiftPM targets and Xcode 16.4 refuses to resolve the graph.
- Kept the MPV runtime code and framework search paths intact.
- MPV remains auto-detected from vendored binary frameworks at:
  - `Vendor/MPVKit`
  - `Vendor/MPV`
  - `Vendor/libmpv`
  - `Carthage/Build`

## Result

- CI package resolution should pass again.
- KSPlayer remains available.
- MPV selection remains wired, but a vendored MPV/MPVKit/libmpv tvOS framework is required for the MPV engine to compile as an available real engine without SwiftPM target collisions.
