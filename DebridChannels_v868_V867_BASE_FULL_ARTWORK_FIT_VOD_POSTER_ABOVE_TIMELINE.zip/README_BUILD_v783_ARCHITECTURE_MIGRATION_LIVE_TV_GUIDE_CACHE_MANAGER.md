# DebridChannels tvOS v783 — Architecture Migration Step 9

## Scope
Step 9 only: Live TV guide/cache manager cleanup.

## Changes
- Added `Sources/LiveTVGuideCacheManager.swift`.
- Centralized Live TV large-state persistence for loaded channels and guide programs.
- Centralized refresh TTL / last-refresh bookkeeping.
- Kept provider loading, XMLTV parsing, Xtream short EPG, guide artwork retention, Force Refresh behavior, and focused-card progress behavior unchanged.

## Safety
- No UI redesign.
- No player changes.
- No Sports / VOD / Source Intelligence changes.
- Existing cache keys and file names preserved:
  - `liveTVLoadedChannelsV165` / `liveTVLoadedChannelsV165.json`
  - `liveTVGuideProgramsV191` / `liveTVGuideProgramsV191.json`
  - `liveTVLastRefreshV191`

## Migration status
Completed migration step 9 of 15.
Next: step 10 — Catalog artwork/cache manager cleanup.
