# DebridChannels tvOS v781 — Architecture Migration Step 7

## Source baseline
- Started from v780: `DebridChannels_tvOS_v780_ARCHITECTURE_MIGRATION_TRAILER_SERVICE_CLEANUP_READY_UPLOAD.zip`

## Migration step completed
7. Source Intelligence manager cleanup

## What changed
- Added `Sources/SourceIntelligenceManager.swift`.
- Moved Source Intelligence ranking/provider helper logic into the manager:
  - English-first Stremio stream prioritization
  - Provider canonicalization and provider-filter matching
  - Balanced provider distribution for All Providers
  - Source Intelligence stream sorting/ranking
  - Episode exact-match / season-pack / wrong-episode ranking rules
- Updated `CatalogStore` to delegate those decisions to `SourceIntelligenceManager` while preserving network search state, published UI state, source statuses, and playback handoff in `CatalogStore`.
- Added the new manager file to `project.yml` source list.

## Behavior preservation
- Source Intelligence UI unchanged.
- Provider picker behavior unchanged.
- All Providers balancing unchanged.
- English/Multi/Dual priority unchanged.
- Cached/direct/highest-quality sorting unchanged.
- Episode-specific filtering and ranking unchanged.
- No Sports, Movies/Shows ticker, Trailer, Playback, Live TV, Membership, Settings, or Alerts behavior changed.

## Next migration step
8. Debrid resolver/preflight manager
