# v756 Source Intelligence Black Glass Search MediaFusion Fix

- Rebuilt from v755 and preserved the working Source Intelligence ranking/search path.
- Redesigned Source Intelligence as a bounded black-glass overlay with clipped content, compact hero best match, six-link paging, ellipsized long filenames, blue focus accents, and green reserved for cache/confidence.
- Removed visible Search addon/status chips while keeping async addon catalog loading, cancellation, debounce, timeout, progressive merging, and query/provider cache behavior.
- Removed Cinemeta/Streaming Catalogs from playable Source Intelligence provider options; catalog metadata remains search/browse only.
- Restored episode Source Intelligence artwork fallback: selected episode still, then show/season poster/backdrop.
- Kept initial Source Intelligence publishing to the ranked top 25 while background resolving continues without expanding the visible list upfront.
- Hardened MediaFusion handling: configured path is preserved when deriving catalog/stream bases, catalog endpoints stay in search/browse, stream endpoints stay in Source Intelligence, and MediaFusion status reports manifest failure, missing stream endpoint, timeout, invalid JSON, zero streams, and debrid/direct-link failure.

Verification:
- Static scans confirmed no missing `copyMediaItem` call.
- Local Swift compile was not run because `swiftc` is not installed in this environment.
