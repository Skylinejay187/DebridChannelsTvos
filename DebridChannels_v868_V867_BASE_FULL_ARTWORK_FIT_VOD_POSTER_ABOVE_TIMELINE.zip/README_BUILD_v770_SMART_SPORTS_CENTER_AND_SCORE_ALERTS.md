# DebridChannels tvOS v770 — Smart Sports Center and Score Alerts

Base: v769 Sports Live Viewing Center + v768 stability prefs fix lineage.

Scope:
- Sports Center becomes a Smart Sports Center / sports media hub instead of generic chips.
- Global sports ticker converted to a compact bottom-left sports alert, similar to episode alerts, so it does not block catalog cards, Live TV grid, settings, or overlays.
- Full SportsCenter-style ticker remains only inside the Sports section.
- Sports M3U/Xtream/Live TV channels auto-route into richer sports sections.
- Added smarter classifier buckets: NFL, NBA, MLB, NHL, Soccer, Wrestling, UFC/MMA, Boxing, Motorsports, College Sports, Regional Sports, Sports News, Live Sports Channels, Sports/Other.
- Classifier now prioritizes specific leagues/sports before generic ESPN/Sports terms.
- Favorite-team and universal score ticker foundation preserved.
- No playback/player logic changes.
- No VOD metadata probing changes.
- No Source Intelligence resolver changes.

Notes:
- This is the first structure pass for the full Sports Media Center concept.
- Public sports score feeds remain best-effort and gracefully fall back if unavailable.
