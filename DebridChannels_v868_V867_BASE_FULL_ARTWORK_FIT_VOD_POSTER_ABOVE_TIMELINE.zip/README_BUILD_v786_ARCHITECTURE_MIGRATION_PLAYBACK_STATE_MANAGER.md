# DebridChannels tvOS v786 - Architecture Migration Step 12

## Scope
Step 12 only: Playback state manager cleanup.

## Changes
- Added `Sources/PlaybackStateManager.swift`.
- Centralized lightweight playback state decisions:
  - active engine display name
  - loading/status labels
  - resume eligibility helper
  - seek target clamping helper
  - watched percentage helper
- Wired the existing player overlay's active engine name through the new manager.

## Behavior preservation
- No player engine changes.
- No overlay layout changes.
- No timeline/scrubber focus changes.
- No resume cache behavior changes.
- No Source Intelligence handoff changes.
- No Live TV player fallback changes.

## Build lineage
Starts from v785 Alerts manager unification build fix.
