import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

// v1132 Phase 12: the failed six-mode Smart Info experiment is replaced by one
// intentionally small discovery panel. Off is the default; the only opt-in modes
// are other-show recommendations and verified Did You Know facts.
enum VODSmartInfoPanelMode: String, CaseIterable, Hashable {
    case off
    case recommendations
    case trivia

    var displayName: String {
        switch self {
        case .off: return "Off"
        case .recommendations: return "Other Show Recommendations"
        case .trivia: return "Did You Know"
        }
    }

    var next: VODSmartInfoPanelMode {
        let values = Self.allCases
        guard let index = values.firstIndex(of: self) else { return .off }
        return values[(index + 1) % values.count]
    }
}

struct VODSmartInfoCard: Identifiable, Hashable {
    let id: String
    let kind: VODSmartInfoPanelMode
    let eyebrow: String
    let title: String
    let body: String
    let detail: String?
    let imageURL: String?
}

private struct TMDBRecommendationsEnvelope: Decodable {
    struct Result: Decodable {
        let id: Int
        let name: String?
        let title: String?
        let overview: String?
        let backdropPath: String?
        let posterPath: String?
        let voteAverage: Double?

        enum CodingKeys: String, CodingKey {
            case id, name, title, overview
            case backdropPath = "backdrop_path"
            case posterPath = "poster_path"
            case voteAverage = "vote_average"
        }
    }
    let results: [Result]
}

private struct TMDBExternalIDsEnvelope: Decodable {
    let wikidataID: String?
    enum CodingKeys: String, CodingKey { case wikidataID = "wikidata_id" }
}

private struct WikidataSearchEnvelope: Decodable {
    struct Result: Decodable {
        let id: String
        let label: String?
        let description: String?
    }
    let search: [Result]
}

private struct WikidataEntityEnvelope: Decodable {
    struct Entity: Decodable {
        struct Label: Decodable { let value: String }
        struct Claim: Decodable {
            struct MainSnak: Decodable {
                struct DataValue: Decodable {
                    let entityID: String?
                    private enum CodingKeys: String, CodingKey { case id }
                    init(from decoder: Decoder) throws {
                        if let container = try? decoder.container(keyedBy: CodingKeys.self) {
                            entityID = try? container.decode(String.self, forKey: .id)
                        } else {
                            entityID = nil
                        }
                    }
                }
                let datavalue: DataValue?
            }
            let mainsnak: MainSnak
        }
        let labels: [String: Label]?
        let claims: [String: [Claim]]?
    }
    let entities: [String: Entity]
}

enum VODSmartInfoService {
    private static let cacheLock = NSLock()
    private static var cache: [String: (Date, [VODSmartInfoCard])] = [:]
    private static let cacheTTL: TimeInterval = 7 * 24 * 60 * 60

    static func cards(for item: MediaItem, mode: VODSmartInfoPanelMode, tmdbAPIKey: String) async -> [VODSmartInfoCard] {
        guard mode != .off else { return [] }
        let key = [item.id, item.tmdbId ?? "", item.imdbId ?? "", "s\(item.seasonNumber ?? -1)", "e\(item.episodeNumber ?? -1)", mode.rawValue].joined(separator: "|")
        if let cached = cachedCards(for: key) { return cached }

        let result: [VODSmartInfoCard]
        switch mode {
        case .recommendations:
            result = await recommendationCards(for: item, tmdbAPIKey: tmdbAPIKey)
        case .trivia:
            result = await didYouKnowCards(for: item, tmdbAPIKey: tmdbAPIKey)
        case .off:
            result = []
        }
        store(result, for: key)
        return result
    }

    // Recommendations deliberately combine TMDB's recommendation and similar-TV
    // relationships when the user supplied a TMDB key. This is TV-first: an episode
    // or show asks for other shows, never other episodes of the current series.
    private static func recommendationCards(for item: MediaItem, tmdbAPIKey: String) async -> [VODSmartInfoCard] {
        let key = tmdbAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, let tmdbID = Int(item.tmdbId ?? "") else { return [] }
        let isTV = item.seasonNumber != nil || item.episodeNumber != nil || ["tv", "show", "series", "episode"].contains { item.type.lowercased().contains($0) }
        let kind = isTV ? "tv" : "movie"
        let routes = ["recommendations", "similar"]
        var merged: [TMDBRecommendationsEnvelope.Result] = []

        for route in routes {
            guard var components = URLComponents(string: "https://api.themoviedb.org/3/\(kind)/\(tmdbID)/\(route)") else { continue }
            components.queryItems = [
                URLQueryItem(name: "api_key", value: key),
                URLQueryItem(name: "language", value: "en-US"),
                URLQueryItem(name: "page", value: "1")
            ]
            guard let url = components.url else { continue }
            if let data = try? await fetch(url: url, maximumBytes: 900_000),
               let payload = try? JSONDecoder().decode(TMDBRecommendationsEnvelope.self, from: data) {
                merged.append(contentsOf: payload.results)
            }
        }

        var seen = Set<Int>()
        let currentTitle = normalized(item.title)
        return merged.compactMap { candidate -> VODSmartInfoCard? in
            guard seen.insert(candidate.id).inserted else { return nil }
            let title = (candidate.name ?? candidate.title ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !title.isEmpty, normalized(title) != currentTitle else { return nil }
            let overview = (candidate.overview ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let imagePath = candidate.backdropPath ?? candidate.posterPath
            let imageURL = imagePath.map { "https://image.tmdb.org/t/p/w780\($0)" }
            let rating = candidate.voteAverage.flatMap { $0 > 0 ? String(format: "%.1f / 10", $0) : nil }
            return VODSmartInfoCard(
                id: "recommendation-\(candidate.id)",
                kind: .recommendations,
                eyebrow: "YOU MAY ALSO LIKE",
                title: title,
                body: overview.isEmpty ? "Another title related to what you're watching." : overview,
                detail: rating,
                imageURL: imageURL
            )
        }.prefixArray(5)
    }

    // Trivia is intentionally broader than novelty facts. We derive our own short
    // wording from verified structured data rather than copying prose from websites.
    // Wikidata is keyless/open; existing MediaItem metadata is used as a safe fallback.
    private static func didYouKnowCards(for item: MediaItem, tmdbAPIKey: String) async -> [VODSmartInfoCard] {
        var cards: [VODSmartInfoCard] = []

        if let entityID = await matchingWikidataEntity(for: item, tmdbAPIKey: tmdbAPIKey),
           let entity = await wikidataEntity(id: entityID) {
            let claims = entity.claims ?? [:]
            let factSpecs: [(String, String, String, String)] = [
                ("P915", "Filming Location", "Production records list %@ as a filming location.", "location"),
                ("P144", "Source Material", "This title is based on or adapted from %@.", "source"),
                ("P166", "Award Recognition", "This title is associated with %@.", "award"),
                ("P57", "Behind the Camera", "%@ is credited as a director.", "director"),
                ("P58", "Written By", "%@ is credited as a screenwriter.", "writer"),
                ("P272", "Production", "%@ is listed as a production company.", "company"),
                ("P449", "Original Network", "%@ is listed as an original broadcaster/network.", "network"),
                ("P495", "Country of Origin", "Structured production data lists %@ as a country of origin.", "country"),
                ("P364", "Original Language", "%@ is listed as an original language.", "language")
            ]
            for (property, title, format, suffix) in factSpecs where cards.count < 7 {
                let ids = entityIDs(from: claims[property])
                guard !ids.isEmpty else { continue }
                let labels = await wikidataLabels(ids: Array(ids.prefix(3)))
                for id in ids.prefix(2) where cards.count < 7 {
                    guard let label = labels[id]?.trimmingCharacters(in: .whitespacesAndNewlines), !label.isEmpty else { continue }
                    cards.append(VODSmartInfoCard(
                        id: "trivia-\(suffix)-\(entityID)-\(id)",
                        kind: .trivia,
                        eyebrow: "DID YOU KNOW?",
                        title: title,
                        body: String(format: format, label),
                        detail: "Verified structured data • Wikidata",
                        imageURL: nil
                    ))
                }
            }
        }

        // Exact in-app metadata is useful verified context when open-data claims are
        // sparse. This does not issue another network request.
        if cards.count < 5, let director = item.directors.first?.trimmingCharacters(in: .whitespacesAndNewlines), !director.isEmpty {
            cards.append(.init(id: "local-director-\(item.id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Director", body: "\(director) is credited as a director of what you're watching.", detail: "Current title metadata", imageURL: nil))
        }
        if cards.count < 5, !item.genres.isEmpty {
            cards.append(.init(id: "local-genres-\(item.id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Genre", body: "This title is categorized as \(item.genres.prefix(3).joined(separator: ", ")).", detail: "Current title metadata", imageURL: nil))
        }
        if cards.count < 5, let air = item.airDateString?.trimmingCharacters(in: .whitespacesAndNewlines), !air.isEmpty {
            cards.append(.init(id: "local-airdate-\(item.id)-\(air)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "Original Air Date", body: "This episode/title is recorded with an air date of \(air).", detail: "Current title metadata", imageURL: nil))
        }
        if cards.count < 5, let cast = item.castMembers.first, !cast.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let role = cast.role?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let body = role.isEmpty ? "\(cast.name) appears in the current title." : "\(cast.name) appears as \(role)."
            cards.append(.init(id: "local-cast-\(item.id)-\(cast.id)", kind: .trivia, eyebrow: "DID YOU KNOW?", title: "On Screen", body: body, detail: "Current title metadata", imageURL: cast.imageURL))
        }
        return cards.prefixArray(7)
    }

    private static func matchingWikidataEntity(for item: MediaItem, tmdbAPIKey: String) async -> String? {
        if let exact = await tmdbWikidataID(for: item, tmdbAPIKey: tmdbAPIKey) { return exact }
        guard var components = URLComponents(string: "https://www.wikidata.org/w/api.php") else { return nil }
        components.queryItems = [
            URLQueryItem(name: "action", value: "wbsearchentities"),
            URLQueryItem(name: "search", value: item.title),
            URLQueryItem(name: "language", value: "en"),
            URLQueryItem(name: "format", value: "json"),
            URLQueryItem(name: "limit", value: "8"),
            URLQueryItem(name: "origin", value: "*")
        ]
        guard let url = components.url,
              let data = try? await fetch(url: url, maximumBytes: 500_000),
              let payload = try? JSONDecoder().decode(WikidataSearchEnvelope.self, from: data) else { return nil }
        let target = normalized(item.title)
        let year = item.year.trimmingCharacters(in: .whitespacesAndNewlines)
        let isTV = item.seasonNumber != nil || item.episodeNumber != nil || ["tv", "show", "series", "episode"].contains { item.type.lowercased().contains($0) }
        let markers = isTV ? ["television", "tv series", "series"] : ["film", "movie"]
        return payload.search.first { result in
            guard normalized(result.label ?? "") == target else { return false }
            let description = (result.description ?? "").lowercased()
            return markers.contains(where: { description.contains($0) }) && (year.isEmpty || description.contains(year))
        }?.id
    }

    private static func tmdbWikidataID(for item: MediaItem, tmdbAPIKey: String) async -> String? {
        let key = tmdbAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, let tmdbID = Int(item.tmdbId ?? "") else { return nil }
        let lower = item.type.lowercased()
        if item.episodeNumber != nil || lower.contains("episode") { return nil }
        let isTV = item.seasonNumber != nil || ["tv", "show", "series"].contains { lower.contains($0) }
        guard var components = URLComponents(string: "https://api.themoviedb.org/3/\(isTV ? "tv" : "movie")/\(tmdbID)/external_ids") else { return nil }
        components.queryItems = [URLQueryItem(name: "api_key", value: key)]
        guard let url = components.url,
              let data = try? await fetch(url: url, maximumBytes: 300_000),
              let payload = try? JSONDecoder().decode(TMDBExternalIDsEnvelope.self, from: data) else { return nil }
        let id = payload.wikidataID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return id.hasPrefix("Q") ? id : nil
    }

    private static func wikidataEntity(id: String) async -> WikidataEntityEnvelope.Entity? {
        guard var components = URLComponents(string: "https://www.wikidata.org/w/api.php") else { return nil }
        components.queryItems = [URLQueryItem(name: "action", value: "wbgetentities"), URLQueryItem(name: "ids", value: id), URLQueryItem(name: "props", value: "claims|labels"), URLQueryItem(name: "languages", value: "en"), URLQueryItem(name: "format", value: "json"), URLQueryItem(name: "origin", value: "*")]
        guard let url = components.url,
              let data = try? await fetch(url: url, maximumBytes: 1_000_000),
              let envelope = try? JSONDecoder().decode(WikidataEntityEnvelope.self, from: data) else { return nil }
        return envelope.entities[id]
    }

    private static func wikidataLabels(ids: [String]) async -> [String: String] {
        guard !ids.isEmpty, var components = URLComponents(string: "https://www.wikidata.org/w/api.php") else { return [:] }
        components.queryItems = [URLQueryItem(name: "action", value: "wbgetentities"), URLQueryItem(name: "ids", value: ids.joined(separator: "|")), URLQueryItem(name: "props", value: "labels"), URLQueryItem(name: "languages", value: "en"), URLQueryItem(name: "format", value: "json"), URLQueryItem(name: "origin", value: "*")]
        guard let url = components.url,
              let data = try? await fetch(url: url, maximumBytes: 700_000),
              let entities = try? JSONDecoder().decode(WikidataEntityEnvelope.self, from: data).entities else { return [:] }
        var result: [String: String] = [:]
        for (id, entity) in entities {
            if let label = entity.labels?["en"]?.value { result[id] = label }
        }
        return result
    }

    private static func entityIDs(from claims: [WikidataEntityEnvelope.Entity.Claim]?) -> [String] {
        var seen = Set<String>()
        return (claims ?? []).compactMap { claim in
            guard let id = claim.mainsnak.datavalue?.entityID, seen.insert(id).inserted else { return nil }
            return id
        }
    }

    private static func cachedCards(for key: String) -> [VODSmartInfoCard]? {
        cacheLock.lock(); defer { cacheLock.unlock() }
        guard let value = cache[key], Date().timeIntervalSince(value.0) < cacheTTL else {
            cache.removeValue(forKey: key)
            return nil
        }
        return value.1
    }

    private static func store(_ cards: [VODSmartInfoCard], for key: String) {
        cacheLock.lock(); defer { cacheLock.unlock() }
        cache[key] = (Date(), cards)
        if cache.count > 80 {
            let sorted = cache.sorted { $0.value.0 < $1.value.0 }
            for entry in sorted.prefix(cache.count - 64) { cache.removeValue(forKey: entry.key) }
        }
    }

    private static func fetch(url: URL, maximumBytes: Int) async throws -> Data {
        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        request.cachePolicy = .returnCacheDataElseLoad
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/1.0 DiscoveryPanel", forHTTPHeaderField: "User-Agent")
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 8
        config.timeoutIntervalForResource = 10
        config.requestCachePolicy = .returnCacheDataElseLoad
        config.urlCache = nil
        let session = URLSession(configuration: config)
        defer { session.invalidateAndCancel() }
        let (data, response) = try await session.data(for: request)
        guard data.count <= maximumBytes else { throw URLError(.dataLengthExceedsMaximum) }
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else { throw URLError(.badServerResponse) }
        return data
    }

    private static func normalized(_ value: String) -> String {
        value.lowercased().unicodeScalars.filter { CharacterSet.alphanumerics.contains($0) }.map(String.init).joined()
    }
}

private extension Array {
    func prefixArray(_ count: Int) -> [Element] { Array(prefix(count)) }
}
