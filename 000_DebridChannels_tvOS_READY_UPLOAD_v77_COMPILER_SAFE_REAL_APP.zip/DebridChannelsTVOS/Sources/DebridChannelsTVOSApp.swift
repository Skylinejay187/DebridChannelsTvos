import SwiftUI
import AVKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

// MARK: - Root

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack {
            switch store.selectedTab {
            case .home, .movies, .shows:
                HomeView(filter: store.selectedTab)
            case .live:
                LiveTVPlaceholder()
            case .settings:
                SettingsScreen()
            }

            if let item = store.selectedDetail {
                DetailPage(item: item)
                    .transition(.opacity)
                    .zIndex(10)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .zIndex(20)
            }
        }
    }
}

// MARK: - Shared Background / Menu

struct CinematicBackground: View {
    let item: MediaItem?
    let previewURL: URL?
    @State private var smoke = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            if let previewURL {
                SilentVideoBackground(url: previewURL)
                    .ignoresSafeArea()
                    .opacity(0.62)
            } else if let item {
                RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
                    .ignoresSafeArea()
                    .opacity(0.58)
            }

            LinearGradient(
                colors: [.black.opacity(0.20), .black.opacity(0.42), .black.opacity(0.86)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            LinearGradient(
                colors: [.black.opacity(0.20), .clear, .black.opacity(0.52)],
                startPoint: .leading,
                endPoint: .trailing
            )
            .ignoresSafeArea()

            SmokeOverlay(active: smoke)
                .ignoresSafeArea()
                .opacity(0.95)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 9.0).repeatForever(autoreverses: true)) {
                smoke.toggle()
            }
        }
    }
}

struct SmokeOverlay: View {
    let active: Bool

    var body: some View {
        ZStack {
            ForEach(0..<8, id: \.self) { index in
                Ellipse()
                    .fill(Color.white.opacity(index.isMultiple(of: 2) ? 0.050 : 0.034))
                    .frame(width: CGFloat(420 + index * 120), height: CGFloat(100 + index * 36))
                    .blur(radius: CGFloat(32 + index * 4))
                    .offset(
                        x: active ? CGFloat(-220 + index * 78) : CGFloat(250 - index * 40),
                        y: active ? CGFloat(-340 + index * 88) : CGFloat(-210 + index * 75)
                    )
                    .rotationEffect(.degrees(active ? Double(index * 13 + 8) : Double(index * -12)))
            }
        }
        .blendMode(.screen)
        .allowsHitTesting(false)
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focused: AppTab?

    var body: some View {
        HStack(alignment: .top) {
            BrandMark()
                .frame(width: 230, alignment: .leading)

            Spacer()

            HStack(spacing: 48) {
                ForEach(AppTab.allCases) { tab in
                    if tab != .settings || true {
                        Button {
                            store.selectedTab = tab
                            store.selectedDetail = nil
                        } label: {
                            VStack(spacing: 8) {
                                Text(tab.rawValue)
                                    .font(.system(size: 28, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white)
                                Capsule()
                                    .fill(store.selectedTab == tab ? Color.cyan : Color.clear)
                                    .frame(width: 52, height: 5)
                            }
                        }
                        .buttonStyle(.plain)
                        .focused($focused, equals: tab)
                    }
                }
            }

            Spacer()

            Button {
                store.status = "Search screen wiring pending."
            } label: {
                Image(systemName: "magnifyingglass")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundStyle(.white)
            }
            .buttonStyle(.plain)
            .frame(width: 92)
        }
        .padding(.horizontal, 52)
        .padding(.top, 28)
    }
}

struct BrandMark: View {
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "waveform.path.ecg")
                .font(.system(size: 32, weight: .black))
                .foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: -2) {
                Text("DEBRID")
                    .font(.system(size: 24, weight: .black))
                Text("CHANNELS")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(.cyan)
                Text("PREMIUM")
                    .font(.system(size: 13, weight: .bold))
                    .tracking(5)
                    .foregroundStyle(.cyan.opacity(0.85))
            }
            .foregroundStyle(.white)
        }
    }
}

// MARK: - Home

struct HomeView: View {
    @EnvironmentObject var store: CatalogStore
    let filter: AppTab

    @State private var focusedIndex: Int = 0
    @State private var previewURL: URL? = nil
    @State private var previewTask: Task<Void, Never>? = nil
    @State private var idleFloat = false

    private var items: [MediaItem] {
        let all = store.rows.flatMap { $0.items }
        switch filter {
        case .movies: return all.filter { !$0.type.lowercased().contains("series") }
        case .shows: return all.filter { $0.type.lowercased().contains("series") }
        default: return all
        }
    }

    private var focusedItem: MediaItem? {
        guard !items.isEmpty else { return nil }
        return items[min(max(focusedIndex, 0), items.count - 1)]
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            CinematicBackground(item: focusedItem, previewURL: previewURL)

            VStack(spacing: 34) {
                TopMenuBar()
                HomeGrid(
                    items: items,
                    focusedIndex: $focusedIndex,
                    idleFloat: idleFloat,
                    onOpen: { item in store.openDetail(item) }
                )
                Spacer(minLength: 0)
            }
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 4.6).repeatForever(autoreverses: true)) {
                idleFloat.toggle()
            }
            schedulePreview()
        }
        .onChange(of: focusedIndex) { _ in
            previewURL = nil
            schedulePreview()
        }
    }

    private func schedulePreview() {
        previewTask?.cancel()
        guard let item = focusedItem else { return }
        previewTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if !Task.isCancelled {
                previewURL = store.directPreviewURL(for: item)
            }
        }
    }
}

struct HomeGrid: View {
    let items: [MediaItem]
    @Binding var focusedIndex: Int
    let idleFloat: Bool
    let onOpen: (MediaItem) -> Void

    private let leftX: CGFloat = 52
    private let topY: CGFloat = 155
    private let cardGap: CGFloat = 18
    private let heroW: CGFloat = 720
    private let rowH: CGFloat = 305
    private let posterW: CGFloat = 230

    var body: some View {
        GeometryReader { _ in
            ZStack(alignment: .topLeading) {
                if let item = safeItem(focusedIndex) {
                    HeroWideCard(item: item, isTop: true)
                        .frame(width: heroW, height: rowH)
                        .position(x: leftX + heroW / 2, y: topY + rowH / 2)

                    ContinueWatchingCard(item: item)
                        .frame(width: heroW, height: rowH)
                        .position(x: leftX + heroW / 2, y: topY + rowH + cardGap + rowH / 2)
                }

                ForEach(0..<8, id: \.self) { slot in
                    let itemIndex = (focusedIndex + slot + 1) % max(items.count, 1)
                    if let item = safeItem(itemIndex) {
                        RightPosterCard(
                            item: item,
                            index: slot,
                            idleFloat: idleFloat,
                            action: {
                                withAnimation(.easeInOut(duration: 0.30)) {
                                    focusedIndex = itemIndex
                                }
                            },
                            open: { onOpen(item) }
                        )
                        .frame(width: posterW, height: rowH)
                        .position(positionFor(slot: slot))
                    }
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        }
        .frame(height: 660)
        .padding(.horizontal, 0)
    }

    private func safeItem(_ index: Int) -> MediaItem? {
        guard !items.isEmpty else { return nil }
        return items[index % items.count]
    }

    private func positionFor(slot: Int) -> CGPoint {
        let col = slot % 4
        let row = slot / 4
        let x0 = leftX + heroW + cardGap + posterW / 2
        let y0 = topY + rowH / 2
        return CGPoint(x: x0 + CGFloat(col) * (posterW + cardGap), y: y0 + CGFloat(row) * (rowH + cardGap))
    }
}

struct HeroWideCard: View {
    let item: MediaItem
    let isTop: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            LinearGradient(colors: [.clear, .black.opacity(0.82)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 12) {
                Spacer()
                HeroLogoText(item: item, pulse: true)
                    .frame(width: 320, height: 80, alignment: .leading)
                HStack(spacing: 10) {
                    Text(item.year)
                    Text("•")
                    Text(item.type.capitalized)
                    Text("•")
                    Text(item.catalog)
                }
                .font(.system(size: 18, weight: .black))
                .foregroundStyle(.white)
                RatingLine(item: item)
                Text(item.description)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.90))
                    .lineLimit(2)
                    .frame(width: 560, alignment: .leading)
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.cyan, lineWidth: 2.4))
        .shadow(color: .cyan.opacity(0.25), radius: 18)
    }
}

struct ContinueWatchingCard: View {
    let item: MediaItem

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill)
            Color.black.opacity(0.25)
            LinearGradient(colors: [.clear, .black.opacity(0.86)], startPoint: .top, endPoint: .bottom)
            Image(systemName: "play.circle.fill")
                .font(.system(size: 72, weight: .regular))
                .foregroundStyle(.white.opacity(0.90))
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            VStack(alignment: .leading, spacing: 10) {
                Text("Continue Watching")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(.cyan)
                Text(item.title)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                HStack {
                    Capsule().fill(Color.cyan).frame(width: 320, height: 6)
                    Capsule().fill(Color.white.opacity(0.22)).frame(width: 220, height: 6)
                    Text("35m left").font(.system(size: 17, weight: .black)).foregroundStyle(.white)
                }
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.cyan.opacity(0.85), lineWidth: 1.8))
    }
}

struct RightPosterCard: View {
    let item: MediaItem
    let index: Int
    let idleFloat: Bool
    let action: () -> Void
    let open: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        Button(action: action) {
            ZStack(alignment: .bottomLeading) {
                RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                LinearGradient(colors: [.clear, .black.opacity(0.55)], startPoint: .top, endPoint: .bottom)
            }
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(focused ? Color.cyan : Color.white.opacity(0.18), lineWidth: focused ? 3 : 1))
            .shadow(color: focused ? .cyan.opacity(0.35) : .black.opacity(0.30), radius: focused ? 18 : 8)
            .scaleEffect(focused ? 1.035 : 1.0)
            .offset(y: idleFloat ? CGFloat((index % 3) - 1) * 5 : CGFloat((index % 3) - 1) * -4)
            .animation(.easeInOut(duration: 4.8).repeatForever(autoreverses: true), value: idleFloat)
            .animation(.easeInOut(duration: 0.22), value: focused)
        }
        .buttonStyle(.plain)
        .focused($focused)
        .simultaneousGesture(LongPressGesture(minimumDuration: 0.01).onEnded { _ in open() })
    }
}

struct RatingLine: View {
    let item: MediaItem
    var body: some View {
        HStack(spacing: 10) {
            Text("IMDb")
                .font(.system(size: 14, weight: .black))
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(RoundedRectangle(cornerRadius: 5).fill(Color.yellow))
                .foregroundStyle(.black)
            Text(item.rating.isEmpty ? "—" : item.rating)
                .font(.system(size: 24, weight: .black))
                .foregroundStyle(.white)
        }
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    let pulse: Bool
    @State private var animate = false

    var body: some View {
        Text(item.title.uppercased())
            .font(.system(size: 34, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .shadow(color: .cyan.opacity(0.55), radius: animate && pulse ? 10 : 2)
            .scaleEffect(animate && pulse ? 1.025 : 1.0)
            .lineLimit(2)
            .minimumScaleFactor(0.45)
            .onAppear {
                if pulse {
                    withAnimation(.easeInOut(duration: 1.45).repeatForever(autoreverses: true)) {
                        animate = true
                    }
                }
            }
            .id(item.id)
    }
}

// MARK: - Detail

struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @State private var showTrailer = false
    @State private var trailerURL: URL? = nil

    var body: some View {
        ZStack(alignment: .topLeading) {
            DetailBackground(item: item)
            VStack(spacing: 22) {
                TopMenuBar()
                DetailContent(
                    item: item,
                    onPlay: { Task { await store.playFirstDirectStream(for: item) } },
                    onTrailer: openTrailer,
                    onFindLinks: { Task { _ = await store.findStreams(for: item) } },
                    onBack: { store.closeOrBackDetail() }
                )
                .environmentObject(store)
            }
            if showTrailer, let trailerURL {
                TrailerPopup(url: trailerURL) { showTrailer = false }
            }
        }
        .onExitCommand { store.closeOrBackDetail() }
    }

    private func openTrailer() {
        if let url = store.directPreviewURL(for: item) {
            trailerURL = url
            showTrailer = true
        } else {
            store.status = "No direct trailer URL available yet. YouTube IDs need backend conversion to direct HLS/MP4."
        }
    }
}

struct DetailBackground: View {
    let item: MediaItem
    var body: some View {
        ZStack {
            RemoteImageFit(url: item.landscapeURL ?? item.posterURL, mode: .fill).ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.12), .black.opacity(0.62), .black.opacity(0.94)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            LinearGradient(colors: [.black.opacity(0.28), .clear, .black.opacity(0.68)], startPoint: .leading, endPoint: .trailing).ignoresSafeArea()
        }
    }
}

struct DetailContent: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let onPlay: () -> Void
    let onTrailer: () -> Void
    let onFindLinks: () -> Void
    let onBack: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            Spacer(minLength: 70)
            HStack(alignment: .bottom, spacing: 34) {
                RemoteImageFit(url: item.posterURL, mode: .fill)
                    .frame(width: 220, height: 330)
                    .clipShape(RoundedRectangle(cornerRadius: 22))
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.18), lineWidth: 1))
                DetailText(item: item)
            }
            DetailButtons(onPlay: onPlay, onTrailer: onTrailer, onFindLinks: onFindLinks, onBack: onBack)
            LinkStrip(item: item).environmentObject(store)
            MoreLikeThis(current: item).environmentObject(store)
            Spacer(minLength: 0)
        }
        .padding(.leading, 84)
        .padding(.trailing, 70)
    }
}

struct DetailText: View {
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HeroLogoText(item: item, pulse: true)
                .frame(width: 820, height: 120, alignment: .leading)
            Text("\(item.year)  •  \(item.type.capitalized)  •  \(item.genres.prefix(3).joined(separator: "  •  "))")
                .font(.system(size: 27, weight: .heavy))
                .foregroundStyle(.white.opacity(0.93))
            HStack(spacing: 18) {
                ScoreBadge(label: "IMDb", value: item.rating.isEmpty ? "—" : item.rating, color: .yellow, text: .black)
                ScoreBadge(label: "RT", value: "—", color: .red, text: .white)
                ScoreBadge(label: "🍿", value: "—", color: .orange, text: .white)
            }
            Text(item.description)
                .font(.system(size: 25, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .lineLimit(3)
                .frame(width: 1030, alignment: .leading)
            Text("Directors and cast appear here when credits metadata is provided.")
                .font(.system(size: 20, weight: .semibold))
                .foregroundStyle(.white.opacity(0.70))
        }
    }
}

struct ScoreBadge: View {
    let label: String
    let value: String
    let color: Color
    let text: Color
    var body: some View {
        HStack(spacing: 8) {
            Text(label)
                .font(.system(size: 17, weight: .black))
                .padding(.horizontal, 9)
                .padding(.vertical, 5)
                .background(RoundedRectangle(cornerRadius: 6).fill(color))
                .foregroundStyle(text)
            Text(value)
                .font(.system(size: 28, weight: .black))
                .foregroundStyle(.white)
        }
    }
}

struct DetailButtons: View {
    let onPlay: () -> Void
    let onTrailer: () -> Void
    let onFindLinks: () -> Void
    let onBack: () -> Void

    var body: some View {
        HStack(spacing: 16) {
            DetailButton(title: "PLAY", action: onPlay)
            DetailButton(title: "TRAILER", action: onTrailer)
            DetailButton(title: "FIND LINKS", action: onFindLinks)
            DetailButton(title: "BACK", action: onBack)
        }
    }
}

struct DetailButton: View {
    let title: String
    let action: () -> Void
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 25, weight: .black))
                .foregroundStyle(focused ? .black : .white)
                .padding(.horizontal, 32)
                .padding(.vertical, 16)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused ? Color.white : Color.white.opacity(0.13)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.18), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .focused($focused)
    }
}

struct LinkStrip: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Selectable Links")
                .font(.system(size: 24, weight: .black))
                .foregroundStyle(.cyan)
            if store.streamLinks.isEmpty {
                Text(store.lastStreamMessage.isEmpty ? "Press Find Links to search saved Stremio sources." : store.lastStreamMessage)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 14) {
                        ForEach(store.streamLinks) { link in
                            StreamLinkButton(item: item, link: link).environmentObject(store)
                        }
                    }
                }
            }
        }
        .padding(18)
        .frame(width: 980, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 24).fill(Color.black.opacity(0.34)))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }
}

struct StreamLinkButton: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let link: StreamLink
    @FocusState private var focused: Bool
    var body: some View {
        Button {
            if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                store.playbackItem = item
                store.playbackURL = url
            } else {
                store.status = "Selected link is not direct playable yet. Resolver/backend conversion is needed."
            }
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                Text(link.quality).font(.system(size: 20, weight: .black))
                Text(link.size).font(.system(size: 15, weight: .bold))
                Text(link.source).font(.system(size: 13, weight: .semibold)).foregroundStyle(.white.opacity(0.65))
            }
            .frame(width: 165, height: 74, alignment: .leading)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 18).fill(focused ? Color.cyan.opacity(0.28) : Color.white.opacity(0.08)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused ? Color.cyan : Color.white.opacity(0.18), lineWidth: focused ? 2 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused)
    }
}

struct MoreLikeThis: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("More Like This")
                .font(.system(size: 33, weight: .black))
                .foregroundStyle(.white)
            HStack(spacing: 22) {
                ForEach(relatedItems) { item in
                    RelatedCard(item: item) { store.openDetail(item) }
                }
            }
        }
    }
    private var relatedItems: [MediaItem] {
        Array(CatalogStore.demoRows().flatMap { $0.items }.filter { $0.id != current.id }.prefix(6))
    }
}

struct RelatedCard: View {
    let item: MediaItem
    let action: () -> Void
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: action) {
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                .frame(width: 190, height: 280)
                .clipShape(RoundedRectangle(cornerRadius: 18))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused ? Color.cyan : Color.white.opacity(0.18), lineWidth: focused ? 2 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused)
    }
}

struct TrailerPopup: View {
    let url: URL
    let close: () -> Void
    var body: some View {
        ZStack {
            Color.black.opacity(0.74).ignoresSafeArea()
            VStack(spacing: 18) {
                SilentVideoBackground(url: url)
                    .frame(width: 1380, height: 650)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .background(Color.black)
                DetailButton(title: "CLOSE TRAILER", action: close)
            }
        }
    }
}

// MARK: - Player

struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL
    @State private var player: AVPlayer? = nil

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            if let player { VideoPlayer(player: player).ignoresSafeArea() } else { Color.black.ignoresSafeArea() }
            LinearGradient(colors: [.black.opacity(0.10), .clear, .black.opacity(0.92)], startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            PlayerOverlay(item: item, player: player, close: { store.closePlayer() })
        }
        .onAppear {
            let av = AVPlayer(url: url)
            player = av
            av.play()
        }
        .onDisappear { player?.pause() }
        .onExitCommand { store.closePlayer() }
    }
}

struct PlayerOverlay: View {
    let item: MediaItem
    let player: AVPlayer?
    let close: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .bottom, spacing: 28) {
                RemoteImageFit(url: item.posterURL, mode: .fill)
                    .frame(width: 165, height: 245)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading, spacing: 10) {
                    HeroLogoText(item: item, pulse: true)
                        .frame(width: 780, height: 106, alignment: .leading)
                    Text("\(item.year)  •  \(item.type.capitalized)  •  \(item.genres.prefix(2).joined(separator: "  •  "))  •  Direct Play")
                        .font(.system(size: 24, weight: .heavy))
                    Text("★ \(item.rating.isEmpty ? "—" : item.rating)   Cache: active while playing")
                        .font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.82))
                    Text(item.description)
                        .font(.system(size: 24, weight: .medium))
                        .lineLimit(2)
                        .frame(width: 1060, alignment: .leading)
                }
            }
            ProgressBar()
            PlayerControls(close: close)
        }
        .foregroundStyle(.white)
        .padding(.leading, 76)
        .padding(.bottom, 62)
    }
}

struct ProgressBar: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.22)).frame(width: 1500, height: 8)
                Capsule().fill(Color.white).frame(width: 270, height: 8)
            }
            HStack { Text("1:14"); Spacer(); Text("1:35:25") }
                .font(.system(size: 20, weight: .semibold))
                .frame(width: 1500)
                .foregroundStyle(.white.opacity(0.88))
        }
    }
}

struct PlayerControls: View {
    let close: () -> Void
    var body: some View {
        HStack(spacing: 18) {
            PlayerButton(title: "-10") { }
            PlayerButton(title: "PAUSE") { }
            PlayerButton(title: "+10") { }
            PlayerButton(title: "AUDIO") { }
            PlayerButton(title: "SUBTITLES") { }
            PlayerButton(title: "EPISODES") { }
            PlayerButton(title: "ZOOM") { }
            PlayerButton(title: "SETTINGS") { }
            PlayerButton(title: "CLOSE", action: close)
        }
    }
}

struct PlayerButton: View {
    let title: String
    var action: () -> Void = { }
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 21, weight: .black))
                .padding(.horizontal, 26)
                .padding(.vertical, 16)
                .background(Capsule().fill(focused ? Color.white : Color.black.opacity(0.48)))
                .foregroundStyle(focused ? Color.black : Color.white)
                .overlay(Capsule().stroke(.white.opacity(0.22), lineWidth: 1.2))
        }
        .buttonStyle(.plain)
        .focused($focused)
    }
}

// MARK: - Video Background

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        let player = AVPlayer(url: url)
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        player.isMuted = true
        player.play()
        return controller
    }

    func updateUIViewController(_ uiViewController: AVPlayerViewController, context: Context) { }
}

// MARK: - Settings

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @FocusState private var focused: Int?

    var body: some View {
        ZStack(alignment: .topLeading) {
            CinematicBackground(item: store.rows.first?.items.first, previewURL: nil)
            VStack(alignment: .leading, spacing: 22) {
                TopMenuBar()
                Text("Settings")
                    .font(.system(size: 62, weight: .black))
                    .foregroundStyle(.white)
                settingsPanel
                navigationPanel
                Spacer()
            }
            .padding(.leading, 110)
            .padding(.trailing, 80)
        }
    }

    private var settingsPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Stremio JSON Catalogs")
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white)
            TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
                .font(.system(size: 25, weight: .semibold))
                .foregroundStyle(.white)
                .padding(20)
                .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
                .frame(width: 1180)
                .focused($focused, equals: 0)
            HStack(spacing: 16) {
                SettingsButton(title: "Add JSON") { store.addManifestURL(manifestURL); manifestURL = "" }
                SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL") { Task { await store.loadManifest(urlString: manifestURL) } }
                SettingsButton(title: "Load All Catalogs") { Task { await store.loadAllManifests() } }
                SettingsButton(title: "Restore Demo Rows") { store.resetDemo() }
            }
            SavedURLList(urls: store.manifestURLs)
            Text("Build v77 COMPILER SAFE REAL APP")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text(store.status)
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.white.opacity(0.72))
                .frame(width: 1180, alignment: .leading)
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var navigationPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Quick Navigation")
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white)
            HStack(spacing: 18) {
                SettingsButton(title: "Home") { store.selectedTab = .home }
                SettingsButton(title: "Movies") { store.selectedTab = .movies }
                SettingsButton(title: "Shows") { store.selectedTab = .shows }
                SettingsButton(title: "Live TV") { store.selectedTab = .live }
            }
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
}

struct SavedURLList: View {
    let urls: [String]
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Saved JSON URLs")
                .font(.system(size: 20, weight: .black))
                .foregroundStyle(.cyan)
            ForEach(urls.prefix(6), id: \.self) { url in
                Text("• \(url)")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(1)
                    .frame(width: 1120, alignment: .leading)
            }
        }
    }
}

struct SettingsButton: View {
    let title: String
    let action: () -> Void
    @FocusState private var focused: Bool
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused ? Color.cyan.opacity(0.65) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused ? Color.cyan : Color.white.opacity(0.11), lineWidth: focused ? 3 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused)
    }
}

// MARK: - Live

struct LiveTVPlaceholder: View {
    var body: some View {
        ZStack {
            CinematicBackground(item: nil, previewURL: nil)
            VStack(spacing: 24) {
                Text("Live TV")
                    .font(.system(size: 76, weight: .black))
                Text("Live TV guide pass is preserved for the next native tvOS guide build.")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            }
            .foregroundStyle(.white)
        }
    }
}
