# Debrid Channels tvOS v52 Forced Source Build

This ZIP overwrites the old default workflow path:

.github/workflows/build-tvos-ipa-from-zip.yml

Run:

00 Build tvOS IPA From Source ZIP - V52 FORCED SOURCE

The workflow refuses to build if v45 markers appear.
