# Debrid Channels tvOS v48

Split landscape hero + bottom-left Continue Watching preview layout.

Upload this ZIP to GitHub. Run the included workflow. Extract the artifact ZIP, then upload only:

`DebridChannelsTVOS_v48_UPLOAD_THIS_IPA.ipa`

Preserves the v14 Signulous-compatible packaging structure.
