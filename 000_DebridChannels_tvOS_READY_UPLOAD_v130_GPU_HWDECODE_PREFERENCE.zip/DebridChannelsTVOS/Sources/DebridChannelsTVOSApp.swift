import SwiftUI
import AVKit
import Combine
import UIKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct CinematicAmbientBackground: View {
    // v85: the old center-heavy SwiftUI smoke/timeline background is no longer used in active screens.
    // This keeps the same cinematic style, but renders as a lightweight full-screen CALayer effect.
    var body: some View {
        ZStack {
            Color.black
            LightweightCinematicBackground()
        }
    }
}

struct AmbientEffectsLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            RadialGradient(
                colors: [Color.cyan.opacity(drift ? 0.20 : 0.09), Color.blue.opacity(0.05), Color.clear],
                center: drift ? .topTrailing : .bottomLeading,
                startRadius: 40,
                endRadius: 980
            )
            .scaleEffect(drift ? 1.18 : 1.0)
            .blur(radius: 18)

            RadialGradient(
                colors: [Color.white.opacity(0.065), Color.gray.opacity(0.025), Color.clear],
                center: drift ? .bottomTrailing : .topLeading,
                startRadius: 30,
                endRadius: 760
            )
            .offset(x: drift ? -80 : 70, y: drift ? 36 : -30)
            .blur(radius: 34)

            LinearGradient(
                colors: [Color.black.opacity(0.40), Color.clear, Color.black.opacity(0.68)],
                startPoint: .top,
                endPoint: .bottom
            )

            SmokeLayer(drift: drift)
                .opacity(1.0)

            DenseSmokeLayer(drift: drift)
                .opacity(1.0)

            ExtraVisibleSmokeLayer(drift: drift)
                .opacity(1.0)
        }
    }
}

struct SmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Ellipse()
                    .fill(Color.white.opacity(0.030))
                    .frame(width: CGFloat(300 + i * 95), height: CGFloat(92 + i * 31))
                    .blur(radius: CGFloat(36 + i * 5))
                    .rotationEffect(.degrees(Double(i * 11) + (drift ? 5 : -5)))
                    .offset(
                        x: CGFloat(i * 160 - 420) + (drift ? CGFloat(45 - i * 12) : CGFloat(-20 + i * 10)),
                        y: CGFloat(i * 54 - 130) + (drift ? CGFloat(20 - i * 4) : CGFloat(-12 + i * 2))
                    )
            }
        }
    }
}


struct DenseSmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.cyan.opacity(0.055), Color.white.opacity(0.070), Color.blue.opacity(0.032), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(420 + i * 70), height: CGFloat(80 + i * 16))
                    .blur(radius: CGFloat(22 + i * 2))
                    .rotationEffect(.degrees(Double(-18 + i * 7) + (drift ? 8 : -8)))
                    .offset(
                        x: CGFloat(i * 130 - 520) + (drift ? CGFloat(90 - i * 10) : CGFloat(-70 + i * 8)),
                        y: CGFloat(i * 62 - 220) + (drift ? CGFloat(38 - i * 3) : CGFloat(-30 + i * 2))
                    )
            }
        }
        .blendMode(.screen)
    }
}



struct ExtraVisibleSmokeLayer: View {
    let drift: Bool

    var body: some View {
        TimelineView(.animation) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate
            ZStack {
                ForEach(0..<11, id: \.self) { i in
                    let phase = t * (0.030 + Double(i) * 0.0025) + Double(i) * 0.74
                    let wideX = CGFloat(sin(phase)) * CGFloat(360 + i * 18)
                    let wideY = CGFloat(cos(phase * 0.67)) * CGFloat(160 + i * 9)
                    Ellipse()
                        .fill(LinearGradient(
                            colors: [Color.white.opacity(0.16), Color.cyan.opacity(0.13), Color.gray.opacity(0.09), Color.clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        ))
                        .frame(width: CGFloat(560 + i * 115), height: CGFloat(118 + i * 24))
                        .blur(radius: CGFloat(24 + i * 3))
                        .rotationEffect(.degrees(Double(i * 13) + sin(phase * 0.45) * 22.0))
                        .offset(
                            x: CGFloat(i * 135 - 690) + wideX,
                            y: CGFloat(i * 58 - 300) + wideY
                        )
                }
            }
        }
        .blendMode(.screen)
    }
}



struct FocusedSmokeOverlay: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<7, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.115), Color.cyan.opacity(0.07), Color.gray.opacity(0.06), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(520 + i * 100), height: CGFloat(84 + i * 18))
                    .blur(radius: CGFloat(28 + i * 3))
                    .rotationEffect(.degrees(Double(-16 + i * 8) + (drift ? 10 : -10)))
                    .offset(
                        x: CGFloat(i * 150 - 520) + (drift ? CGFloat(95 - i * 10) : CGFloat(-80 + i * 8)),
                        y: CGFloat(i * 68 - 210) + (drift ? CGFloat(44 - i * 4) : CGFloat(-34 + i * 3))
                    )
            }
        }
        .blendMode(.screen)
        .opacity(0.95)
    }
}

struct HomeArtworkBackground: View {
    let item: MediaItem

    private var backgroundURL: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black
            RemoteImageFit(url: backgroundURL, mode: .fill)
                .ignoresSafeArea()
                .scaleEffect(1.01)
                .opacity(0.86)
                .saturation(1.08)
                .contrast(1.04)
            // Keep the home readable without blurring or washing out the selected artwork.
            LinearGradient(
                colors: [Color.black.opacity(0.58), Color.black.opacity(0.28), Color.black.opacity(0.72)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
    }
}


struct PreviewAwareHomeBackground: View {
    let item: MediaItem
    let previewActive: Bool

    var body: some View {
        ZStack {
            // v80: keep the approved ambient/smoke background visible by default.
            // The focused artwork is not used as the static home background anymore.
            Color.clear
            if previewActive, let preview = item.previewURL, let url = URL(string: preview) {
                SilentVideoBackground(url: url)
                    .ignoresSafeArea()
                    .opacity(0.94)
                    .overlay(Color.black.opacity(0.30))
                    .transition(.opacity.animation(.easeInOut(duration: 0.35)))
            }
        }
        .ignoresSafeArea()
    }
}

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        let player = AVPlayer(url: url)
        player.isMuted = true
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem,
            queue: .main
        ) { _ in
            player.seek(to: .zero)
            player.play()
        }
        player.play()
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if let current = controller.player?.currentItem?.asset as? AVURLAsset, current.url == url {
            controller.player?.play()
        } else {
            let player = AVPlayer(url: url)
            player.isMuted = true
            controller.player = player
            player.play()
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack(alignment: .top) {
            switch store.selectedTab {
            case .home:
                NineSlotHome(filter: nil)
            case .movies:
                NineSlotHome(filter: "movie")
            case .shows:
                NineSlotHome(filter: "series")
            case .live:
                LiveTVPlaceholder()
            case .settings:
                SettingsScreen()
            }

            if let detail = store.selectedDetail {
                DetailPage(item: detail)
                    .zIndex(2000)
            }

            if store.playbackURL == nil {
                TopMenuBar()
                    .zIndex(6000)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .id(url.absoluteString)
                    .zIndex(9000)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V108_CAREFUL_MEDIA_ENGINE_REBUILD") }
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                HStack(spacing: 48) {
                    ForEach(AppTab.allCases) { tab in
                        Button {
                            withAnimation(.spring(response: 0.36, dampingFraction: 0.82)) {
                                store.selectedTab = tab
                                store.selectedDetail = nil
                                store.detailBackStack.removeAll()
                            }
                        } label: {
                            VStack(spacing: 7) {
                                Text(tab.rawValue)
                                    .font(.system(size: 27, weight: .heavy, design: .serif))
                                    .tracking(1.8)
                                    .foregroundStyle(store.selectedTab == tab ? Color.white : Color.white.opacity(0.70))
                                Capsule()
                                    .fill(store.selectedTab == tab ? Color.cyan : Color.clear)
                                    .frame(width: tab.rawValue.count > 6 ? 78 : 54, height: 5)
                            }
                            .scaleEffect(focusedTab == tab ? 1.10 : 1.0)
                            .shadow(color: focusedTab == tab ? .cyan.opacity(0.85) : .clear, radius: 16)
                        }
                        .buttonStyle(.plain)
                        .focused($focusedTab, equals: tab)
                    }
                }
                .position(x: geo.size.width * 0.56, y: 58)
                .focusSection()

                Button {
                    store.status = "Search selected. Global top-menu focus is live; full typed search screen can be expanded without changing the v73 layout."
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(searchFocused ? Color.cyan : Color.white.opacity(0.94))
                        .scaleEffect(searchFocused ? 1.18 : 1.0)
                        .shadow(color: searchFocused ? .cyan.opacity(0.8) : .clear, radius: 16)
                }
                .buttonStyle(.plain)
                .focused($searchFocused)
                // Search sits alone on the far right, matching the approved reference.
                .position(x: geo.size.width - max(64, geo.size.width * 0.055), y: 58)
            }
            .frame(width: geo.size.width, height: 124, alignment: .top)
        }
        .frame(height: 136)
        .padding(.top, 16)
        .background(
            LinearGradient(
                colors: [Color.black.opacity(0.94), Color.black.opacity(0.72), Color.black.opacity(0.20), Color.clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .top)
        )
        .zIndex(6000)
        .focusSection()
        .onChange(of: store.menuFocusToken) { _ in
            focusedTab = store.selectedTab
            searchFocused = false
        }
    }
}

struct NineSlotHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex = 0
    @State private var selectedIndex = 0
    @State private var previewReady = false
    @State private var lastMoveAt: TimeInterval = 0
    @State private var lastOpenAt: TimeInterval = 0
    @FocusState private var isCanvasFocused: Bool

    var activeRows: [MediaRow] {
        let rows = store.rows
        guard let filter else { return rows }
        return rows.map { row in
            MediaRow(id: row.id, title: row.title, items: row.items.filter { $0.type.lowercased().contains(filter) })
        }.filter { !$0.items.isEmpty }
    }

    var currentRow: MediaRow {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        return rows[min(rowIndex, rows.count - 1)]
    }

    var items: [MediaItem] {
        currentRow.items.isEmpty ? CatalogStore.demoRows()[0].items : currentRow.items
    }

    var focused: MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        return items[normalized(selectedIndex)]
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                // Full-screen cinematic card board. The focused item is the large left card;
                // all logo/metadata/info is INSIDE that card, matching the reference layout.
                NineSlotDeck(items: items, selectedIndex: selectedIndex, rowTitle: currentRow.title, previewReady: previewReady)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

            }
            .contentShape(Rectangle())
            .focusable(true)
            .focused($isCanvasFocused)
            .onAppear { isCanvasFocused = true }
            .onTapGesture { openFocusedDebounced() }
            .onPlayPauseCommand { openFocusedDebounced() }
            .task(id: focused.id) {
                previewReady = false
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                if !Task.isCancelled { previewReady = true }
            }
            .onMoveCommand { direction in
                guard allowMove() else { return }
                switch direction {
                case .right:
                    nextItem()
                case .left:
                    previousItem()
                case .down:
                    nextRow()
                case .up:
                    if rowIndex > 0 { previousRow() } else { store.menuFocusToken += 1; isCanvasFocused = false }
                default:
                    break
                }
            }
        }
    }

    func allowMove() -> Bool {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastMoveAt > 0.16 else { return false }
        lastMoveAt = now
        return true
    }

    func openFocusedDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastOpenAt > 0.42 else { return }
        lastOpenAt = now
        store.openDetail(focused, pushCurrent: false)
    }

    func normalized(_ value: Int) -> Int {
        guard !items.isEmpty else { return 0 }
        return (value % items.count + items.count) % items.count
    }

    func nextItem() {
        guard !items.isEmpty else { return }
        withAnimation(.easeOut(duration: 0.28)) {
            selectedIndex = normalized(selectedIndex + 1)
        }
    }

    func previousItem() {
        guard !items.isEmpty else { return }
        withAnimation(.easeOut(duration: 0.28)) {
            selectedIndex = normalized(selectedIndex - 1)
        }
    }

    func nextRow() {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        guard rows.count > 1 else { return }
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = min(rowIndex + 1, rows.count - 1)
            selectedIndex = 0
        }
    }

    func previousRow() {
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}


struct NineSlotDeck: View {
    let items: [MediaItem]
    let selectedIndex: Int
    let rowTitle: String
    let previewReady: Bool
    @State private var pulse = false
    @State private var idleMotion = false
    @State private var bgDrift = false

    // v66 SHAPED SNAP GRID + HOME ARTWORK BACKGROUND:
    // No HStack/VStack flexible sizing is allowed for the main deck.
    // Every card is placed by explicit x/y coordinates from one shared grid.
    // The split line is the exact same y for left and right cards.
    // The left boxes are wider than the poster cells, but their heights are identical
    // to the top/bottom poster rows. Landscape art is clipped inside the fixed frame.
    struct Layout {
        let edge: CGFloat
        let top: CGFloat
        let gap: CGFloat
        let leftW: CGFloat
        let rowH: CGFloat
        let posterW: CGFloat
        let topY: CGFloat
        let bottomY: CGFloat
        let leftX: CGFloat
        let rightStartX: CGFloat
    }

    func layout(in size: CGSize) -> Layout {
        let W = size.width
        let H = size.height

        // v60 uses the approved snap-grid formula:
        // two landscape cards on the left, four portrait cards on the right.
        // All cards share the exact same row height. The left cards are only wider.
        let edge = max(36, min(W, H) * 0.030)
        let top = max(118, H * 0.125)
        let bottom = max(30, H * 0.040)
        let gap = max(16, min(W, H) * 0.016)

        let boardW = W - edge * 2
        let boardH = H - top - bottom

        // A landscape card should be 16:9 and a poster card 2:3.
        // Solve the row height from width AND height, then use the smaller value so
        // nothing can stretch, overflow, or change shape when artwork loads.
        let landscapeAspect: CGFloat = 16.0 / 9.0
        let posterAspect: CGFloat = 2.0 / 3.0
        let rowHFromHeight = (boardH - gap) / 2.0
        let rowHFromWidth = (boardW - gap * 4.0) / (landscapeAspect + posterAspect * 4.0)
        let rowH = max(190, min(rowHFromHeight, rowHFromWidth))

        let leftW = rowH * landscapeAspect
        let posterW = rowH * posterAspect

        // Center the two-row board vertically under the top menu when width becomes
        // the limiting factor on 16:9 screens.
        let usedH = rowH * 2.0 + gap
        let actualTop = top + max(0, (boardH - usedH) / 2.0)

        let topY = actualTop + rowH / 2.0
        let bottomY = actualTop + rowH + gap + rowH / 2.0
        let leftX = edge + leftW / 2.0
        let rightStartX = edge + leftW + gap

        return Layout(edge: edge, top: actualTop, gap: gap, leftW: leftW, rowH: rowH, posterW: posterW, topY: topY, bottomY: bottomY, leftX: leftX, rightStartX: rightStartX)
    }

    var body: some View {
        GeometryReader { geo in
            let L = layout(in: geo.size)

            ZStack(alignment: .topLeading) {
                // Background animation remains underneath; the selected artwork/video is now
                // the visible full-screen layer above it.
                AmbientEffectsLayer(drift: bgDrift)
                    .ignoresSafeArea()
                    .opacity(0.82)

                PreviewAwareHomeBackground(item: itemFor(0), previewActive: previewReady)
                    .id("home-bg-\(itemFor(0).id)-\(previewReady)")
                    .ignoresSafeArea()

                // Visible cinematic smoke now sits ABOVE the focused artwork/video background
                // and below the cards, so the effect stays visible with the selected poster.
                FocusedSmokeOverlay(drift: bgDrift)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .zIndex(20)

                BrandMark(pulse: false)
                    .frame(width: min(geo.size.width * 0.17, 320), height: 74)
                    .position(x: L.edge + min(geo.size.width * 0.17, 320) / 2, y: 48)
                    .zIndex(130)

                // LEFT TOP: fixed-width landscape hero. Same height as every right poster.
                LandscapeHeroCard(item: itemFor(0), rowTitle: rowTitle, pulse: pulse, previewReady: previewReady)
                    .id("hero-\(itemFor(0).id)")
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.topY)
                    .zIndex(70)

                // LEFT BOTTOM: fixed-width Continue Watching. Same size as top-left.
                ContinueWatchingCard(item: itemFor(0), pulse: pulse)
                    .id("continue-\(itemFor(0).id)")
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.bottomY)
                    .zIndex(65)

                // RIGHT SIDE: 4 x 2 poster grid, explicit coordinates, equal heights.
                ForEach(1...8, id: \.self) { slot in
                    let col = (slot - 1) % 4
                    let row = (slot - 1) / 4
                    let x = L.rightStartX + CGFloat(col) * (L.posterW + L.gap) + L.posterW / 2
                    let y = row == 0 ? L.topY : L.bottomY
                    PosterQueueCard(item: itemFor(slot), idleMotion: idleMotion, slot: slot)
                        .id("poster-\(slot)")
                        .frame(width: L.posterW, height: L.rowH)
                        .clipShape(RoundedRectangle(cornerRadius: 24))
                        // v66: Option G focus-float timing; no old snap/card-slide transition.
                        .position(x: x, y: y)
                        .zIndex(60)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .animation(.easeOut(duration: 0.24), value: selectedIndex)
            .clipped()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.35).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
            withAnimation(.easeInOut(duration: 9.5).repeatForever(autoreverses: true)) {
                bgDrift.toggle()
            }
            // Right-side poster motion is now driven by TimelineView inside each poster,
            // so it never stops or resets when scrolling/focus changes.
        }
    }

    func itemFor(_ slot: Int) -> MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        let index = (selectedIndex + slot) % items.count
        return items[index]
    }
}

struct BrandMark: View {
    let pulse: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "waveform.path.ecg")
                .font(.system(size: 42, weight: .bold))
                .foregroundStyle(Color.cyan)
                .shadow(color: .cyan.opacity(0.36), radius: 6)
            VStack(alignment: .leading, spacing: -2) {
                Text("DEBRID")
                    .font(.system(size: 32, weight: .black))
                Text("CHANNELS")
                    .font(.system(size: 25, weight: .black))
                    .foregroundStyle(Color.cyan)
                Text("PREMIUM")
                    .font(.system(size: 13, weight: .bold))
                    .tracking(8)
                    .foregroundStyle(.white.opacity(0.68))
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .scaleEffect(1.0)
        .allowsHitTesting(false)
    }
}

struct LandscapeHeroCard: View {
    let item: MediaItem
    let rowTitle: String
    let pulse: Bool
    let previewReady: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            HeroLandscapeArtwork(item: item)
                .overlay(
                    ZStack {
                        LinearGradient(colors: [.black.opacity(0.64), .black.opacity(0.12), .clear], startPoint: .leading, endPoint: .trailing)
                        LinearGradient(colors: [.clear, .black.opacity(0.48)], startPoint: .top, endPoint: .bottom)
                    }
                )

            VStack(alignment: .leading, spacing: 10) {
                HeroLogoText(item: item, pulse: pulse)
                    .id("hero-logo-\(item.id)")
                    .frame(maxWidth: 360, maxHeight: 88, alignment: .leading)
                    .padding(.bottom, 8)

                HStack(spacing: 10) {
                    Text(item.year)
                    Text("•")
                    Text(item.type.capitalized)
                    Text("•")
                    Text(item.catalog.isEmpty ? rowTitle : item.catalog)
                }
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white.opacity(0.93))

                HStack(spacing: 10) {
                    ForEach(item.genres.prefix(2), id: \.self) { genre in
                        Text(genre)
                            .font(.system(size: 13, weight: .bold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.42)))
                            .overlay(Capsule().stroke(.white.opacity(0.14), lineWidth: 1))
                    }
                }

                HStack(spacing: 14) {
                    Text("IMDb")
                        .font(.system(size: 16, weight: .black))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.yellow))
                    Text(item.rating)
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(.white)
                }

                Text(item.description)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(3)
                    .frame(maxWidth: 560, alignment: .leading)
            }
            .padding(.leading, 28)
            .padding(.bottom, 22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .overlay(
            RoundedRectangle(cornerRadius: 28)
                .stroke(Color.cyan.opacity(pulse ? 1.0 : 0.72), lineWidth: 4)
        )
        .shadow(color: .cyan.opacity(pulse ? 0.72 : 0.30), radius: pulse ? 30 : 16)
    }
}

struct HeroLandscapeArtwork: View {
    let item: MediaItem

    private var url: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
            RemoteImageFit(url: url, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .clipped()
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    let pulse: Bool
    @State private var logoPulse = false

    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 13 ? 40 : 58, weight: .black, design: .rounded))
                    .italic()
                    .minimumScaleFactor(0.38)
                    .lineLimit(2)
                    .foregroundStyle(LinearGradient(colors: [.white, .cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
        }
        .shadow(color: .cyan.opacity(logoPulse ? 0.95 : 0.35), radius: logoPulse ? 18 : 7)
        .scaleEffect(logoPulse ? 1.022 : 1.0)
        .onAppear { startPulse() }
        .onChange(of: item.id) { _ in startPulse() }
    }

    private func startPulse() {
        logoPulse = false
        withAnimation(.easeInOut(duration: 1.18).repeatForever(autoreverses: true)) {
            logoPulse = true
        }
    }
}


struct ContinueWatchingCard: View {
    let item: MediaItem
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // For now this uses landscape artwork as a last-scene preview placeholder.
            // When resume capture is wired, this same card will load the real saved frame thumbnail.
            HeroLandscapeArtwork(item: item)
                .overlay(Color.black.opacity(0.22))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom))

            Image(systemName: "play.circle.fill")
                .font(.system(size: 84, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .shadow(color: .black.opacity(0.85), radius: 8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            VStack(alignment: .leading, spacing: 8) {
                Text("Continue Watching")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(Color.cyan)
                HStack {
                    Text(item.title)
                        .font(.system(size: 20, weight: .bold))
                        .lineLimit(1)
                    Spacer()
                    Text("35m left")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundStyle(.white)

                GeometryReader { proxy in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.18))
                        Capsule().fill(Color.cyan).frame(width: proxy.size.width * 0.62)
                    }
                }
                .frame(height: 8)
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .shadow(color: .black.opacity(0.75), radius: 18)
    }
}

struct PosterQueueCard: View {
    let item: MediaItem
    let idleMotion: Bool
    let slot: Int

    var body: some View {
        // v88: right-side poster float/parallax animation removed completely.
        // These cards are now static so focus movement stays stable and lag-free.
        ZStack {
            LinearGradient(colors: [.black, .gray.opacity(0.16)], startPoint: .top, endPoint: .bottom)
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.13), lineWidth: 1))
        .shadow(color: .black.opacity(0.62), radius: 12)
    }
}




struct LightweightCinematicBackground: View {
    // v84: old smoke/timeline/background stacks are deleted from active detail rendering.
    // This is one UIKit-backed CALayer effect, so focus and DPAD movement stay responsive.
    var body: some View {
        FullScreenCinematicLayer()
            .opacity(0.72)
            .blendMode(.screen)
            .allowsHitTesting(false)
    }
}

struct FullScreenCinematicLayer: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false

        let glow = CAGradientLayer()
        glow.name = "DebridChannelsV85CinematicGlow"
        glow.type = .radial
        glow.colors = [UIColor.cyan.withAlphaComponent(0.22).cgColor, UIColor.blue.withAlphaComponent(0.08).cgColor, UIColor.clear.cgColor]
        glow.locations = [0.0, 0.42, 1.0]
        glow.startPoint = CGPoint(x: 0.12, y: 0.18)
        glow.endPoint = CGPoint(x: 1.0, y: 1.0)
        view.layer.addSublayer(glow)

        let sweep = CAGradientLayer()
        sweep.name = "DebridChannelsV85WideSweep"
        sweep.colors = [UIColor.clear.cgColor, UIColor.white.withAlphaComponent(0.075).cgColor, UIColor.cyan.withAlphaComponent(0.10).cgColor, UIColor.clear.cgColor]
        sweep.locations = [0.0, 0.36, 0.58, 1.0]
        sweep.startPoint = CGPoint(x: -0.25, y: 0.45)
        sweep.endPoint = CGPoint(x: 1.25, y: 0.55)
        view.layer.addSublayer(sweep)

        let move = CABasicAnimation(keyPath: "startPoint")
        move.fromValue = CGPoint(x: -0.28, y: 0.18)
        move.toValue = CGPoint(x: 0.72, y: 0.82)
        move.duration = 13.0
        move.autoreverses = true
        move.repeatCount = .infinity
        move.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        glow.add(move, forKey: "fullScreenGlowMove")

        let sweepMove = CABasicAnimation(keyPath: "transform.translation.x")
        sweepMove.fromValue = -420
        sweepMove.toValue = 420
        sweepMove.duration = 9.5
        sweepMove.autoreverses = true
        sweepMove.repeatCount = .infinity
        sweepMove.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        sweep.add(sweepMove, forKey: "wideSweepMove")
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        for layer in view.layer.sublayers ?? [] {
            layer.frame = view.bounds.insetBy(dx: -view.bounds.width * 0.18, dy: -view.bounds.height * 0.18)
        }
        CATransaction.commit()
    }
}

struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var canvasFocused: Bool
    @State private var focus: DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var isFindingLinks = false
    @State private var lastRemoteActionAt: TimeInterval = 0
    @State private var linkWindowStart: Int = 0

    enum DetailNode: Hashable {
        case play, trailer, findLinks, close, searchLinks
        case stream(Int)
        case related(Int)
    }

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(8))
    }

    let maxVisibleStreamLinks = 6

    var visibleLinks: [StreamLink] {
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(maxVisibleStreamLinks))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            HeroLandscapeArtwork(item: item)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.28))
                .overlay(LinearGradient(colors: [.black.opacity(0.78), .black.opacity(0.20), .black.opacity(0.62)], startPoint: .leading, endPoint: .trailing))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom))

            LightweightCinematicBackground()
                .ignoresSafeArea()
                .allowsHitTesting(false)

            VStack(alignment: .leading, spacing: 24) {
                Spacer().frame(height: 250)

                HeroLogoText(item: item, pulse: true)
                    .frame(width: 780, height: 132, alignment: .leading)
                    .padding(.leading, 84)

                HStack(spacing: 30) {
                    Text(item.genres.first?.uppercased() ?? item.type.uppercased())
                    Text(item.year)
                    Text(item.type.uppercased())
                    Text("152min")
                    Text("🍅 80%")
                    Text("🍿 82%")
                    Text("★ \(item.rating)")
                }
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white.opacity(0.86))
                .padding(.leading, 84)

                HStack(spacing: 22) {
                    ManualDetailButton(title: "▶ PLAY", selected: focus == .play)
                    ManualDetailButton(title: "TRAILER", selected: focus == .trailer)
                    ManualDetailButton(title: isFindingLinks ? "FINDING..." : "FIND LINKS", selected: focus == .findLinks)
                    ManualDetailButton(title: "CLOSE", selected: focus == .close)
                }
                .padding(.leading, 84)

                Text(store.lastStreamMessage.isEmpty ? "Trailers and stream links appear here when the selected metadata source provides direct URLs." : store.lastStreamMessage)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.leading, 84)
                    .frame(width: 980, alignment: .leading)

                ManualStreamLinksRow(focus: focus, visibleLinks: visibleLinks, linkWindowStart: linkWindowStart, totalLinkCount: store.streamLinks.count)
                    .padding(.leading, 84)

                Spacer()

                VStack(alignment: .leading, spacing: 18) {
                    Text("More Like This")
                        .font(.system(size: 34, weight: .black))
                    ManualRelatedRow(focus: focus, relatedItems: relatedItems)
                }
                .foregroundStyle(.white)
                .padding(.leading, 84)
                .padding(.bottom, 46)
            }

            VStack(alignment: .leading, spacing: 18) {
                Text(item.description)
                    .font(.system(size: 21, weight: .semibold))
                    .lineLimit(3)
                    .foregroundStyle(.white.opacity(0.92))
                Text("Directors: Metadata source / backend credits")
                Text("Stars: Actor information appears here when credits metadata is available")
            }
            .font(.system(size: 18, weight: .medium))
            .foregroundStyle(.white.opacity(0.78))
            .padding(22)
            .frame(width: 430, alignment: .leading)
            .background(.ultraThinMaterial.opacity(0.50), in: RoundedRectangle(cornerRadius: 26))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(.white.opacity(0.14), lineWidth: 1))
            // v128: compact media-info card so it does not cover Search Links / stream chips.
            .position(x: 1710, y: 548)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL) {
                    trailerPopup = false
                    self.trailerURL = nil
                    canvasFocused = true
                }
                .zIndex(10)
            }
        }
        .focusable(true)
        .focused($canvasFocused)
        .onAppear { canvasFocused = true; focus = .play }
        .onTapGesture { activateFocusedNodeDebounced() }
        .onPlayPauseCommand { activateFocusedNodeDebounced() }
        .onMoveCommand { direction in route(direction) }
        .task(id: item.id) {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            guard !Task.isCancelled else { return }
            // v84 keeps auto-preview opt-in and non-blocking. It no longer steals focus.
            if let url = store.directPreviewURL(for: item), !trailerPopup {
                trailerURL = url
            }
        }
        .onExitCommand {
            if trailerPopup { trailerPopup = false } else { store.closeDetail() }
        }
    }

    private func route(_ direction: MoveCommandDirection) {
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .findLinks, .close:
                store.menuFocusToken += 1
                canvasFocused = false
            case .searchLinks, .stream:
                focus = .play
            case .related:
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .findLinks, .close:
                focus = .searchLinks
            case .searchLinks, .stream:
                focus = .related(0)
            case .related:
                break
            }
        case .left:
            switch focus {
            case .play: break
            case .trailer: focus = .play
            case .findLinks: focus = .trailer
            case .close: focus = .findLinks
            case .searchLinks: focus = .close
            case .stream(let index):
                if index <= 0 { focus = .searchLinks } else {
                    let previous = index - 1
                    focus = .stream(previous)
                    ensureLinkVisible(previous)
                }
            case .related(let index): focus = .related(max(0, index - 1))
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .trailer: focus = .findLinks
            case .findLinks: focus = .close
            case .close: focus = .searchLinks
            case .searchLinks:
                if !store.streamLinks.isEmpty {
                    ensureLinkVisible(linkWindowStart)
                    focus = .stream(linkWindowStart)
                }
            case .stream(let index):
                let next = min(max(store.streamLinks.count - 1, 0), index + 1)
                focus = .stream(next)
                ensureLinkVisible(next)
            case .related(let index): focus = .related(min(max(relatedItems.count - 1, 0), index + 1))
            }
        default:
            break
        }
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + maxVisibleStreamLinks {
            linkWindowStart = max(0, clamped - maxVisibleStreamLinks + 1)
        }
    }

    private func activateFocusedNodeDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastRemoteActionAt > 0.38 else { return }
        lastRemoteActionAt = now
        activateFocusedNode()
    }

    private func activateFocusedNode() {
        switch focus {
        case .play:
            Task {
                isFindingLinks = true
                await store.playFirstDirectStream(for: item)
                isFindingLinks = false
            }
        case .trailer:
            if let url = store.directPreviewURL(for: item) ?? trailerURL {
                trailerURL = url
                trailerPopup = true
            } else {
                store.status = "No direct playable trailer URL was provided. YouTube trailer IDs need backend conversion before AVPlayer can play them."
            }
        case .findLinks, .searchLinks:
            Task {
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(0)
            }
        case .close:
            store.closeDetail()
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver/backend is needed for magnet/infoHash/debrid-only links."
            }
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}

struct ManualDetailButton: View {
    let title: String
    let selected: Bool
    var body: some View {
        Text(title)
            .font(.system(size: 26, weight: .black))
            .foregroundStyle(selected ? Color.black : Color.white)
            .padding(.horizontal, 34)
            .padding(.vertical, 18)
            .background(RoundedRectangle(cornerRadius: 18).fill(selected ? Color.cyan.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color.white.opacity(0.80) : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
            .scaleEffect(selected ? 1.075 : 1.0)
            .shadow(color: selected ? .cyan.opacity(0.65) : .clear, radius: 18)
    }
}

struct ManualStreamLinksRow: View {
    let focus: DetailPage.DetailNode
    let visibleLinks: [StreamLink]
    let linkWindowStart: Int
    let totalLinkCount: Int

    var rangeText: String? {
        guard totalLinkCount > 0 else { return nil }
        let first = min(linkWindowStart + 1, totalLinkCount)
        let last = min(linkWindowStart + visibleLinks.count, totalLinkCount)
        return "\(first)-\(last) of \(totalLinkCount)"
    }

    var body: some View {
        HStack(spacing: 14) {
            ManualLinkChip(title: "Search Links", subtitle: rangeText, selected: focus == .searchLinks, playable: true)

            if linkWindowStart > 0 {
                Text("‹")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }

            ForEach(Array(visibleLinks.enumerated()), id: \.element.id) { offset, link in
                let absoluteIndex = linkWindowStart + offset
                ManualLinkChip(title: link.quality, subtitle: link.size, selected: focus == .stream(absoluteIndex), playable: link.isDirectPlayable)
            }

            if linkWindowStart + visibleLinks.count < totalLinkCount {
                Text("›")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }
        }
        .frame(width: 1460, alignment: .leading)
    }
}

struct ManualLinkChip: View {
    let title: String
    let subtitle: String?
    let selected: Bool
    let playable: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.system(size: subtitle == nil ? 20 : 18, weight: .black))
            if let subtitle { Text(subtitle).font(.system(size: 13, weight: .semibold)).opacity(0.78) }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 22)
        .padding(.vertical, subtitle == nil ? 12 : 11)
        .background(RoundedRectangle(cornerRadius: 14).fill(selected ? Color.orange.opacity(0.76) : Color.white.opacity(playable ? 0.16 : 0.07)))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(selected ? Color.orange : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
        .scaleEffect(selected ? 1.06 : 1.0)
    }
}

struct ManualRelatedRow: View {
    let focus: DetailPage.DetailNode
    let relatedItems: [MediaItem]
    var body: some View {
        HStack(spacing: 24) {
            ForEach(Array(relatedItems.enumerated()), id: \.element.id) { index, item in
                let selected = focus == .related(index)
                ZStack(alignment: .bottomLeading) {
                    RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                    LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                    Text(item.title)
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                        .padding(14)
                }
                .frame(width: 210, height: 310)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .contentShape(RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? Color.cyan : Color.white.opacity(0.18), lineWidth: selected ? 4 : 1))
                .scaleEffect(selected ? 1.055 : 1.0)
                .shadow(color: selected ? .cyan.opacity(0.55) : .black.opacity(0.60), radius: selected ? 20 : 12)
            }
        }
    }
}

struct RelatedMoviesRow: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    @FocusState private var focusedID: String?

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != current.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(current.genres))) }
        let fallback = all.filter { $0.id != current.id }
        let chosen = sameGenre.isEmpty ? fallback : sameGenre
        return Array(chosen.prefix(8))
    }

    var body: some View {
        HStack(spacing: 24) {
            ForEach(relatedItems) { item in
                Button {
                    store.openDetail(item, pushCurrent: true)
                } label: {
                    ZStack(alignment: .bottomLeading) {
                        RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                        LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                        Text(item.title)
                            .font(.system(size: 19, weight: .black))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                            .padding(14)
                    }
                    .frame(width: 210, height: 310)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .contentShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(focusedID == item.id ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == item.id ? 4 : 1))
                    .scaleEffect(focusedID == item.id ? 1.055 : 1.0)
                    .shadow(color: focusedID == item.id ? .cyan.opacity(0.55) : .black.opacity(0.60), radius: focusedID == item.id ? 20 : 12)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: item.id)
            }
        }
        .focusSection()
        .onAppear { if focusedID == nil { focusedID = relatedItems.first?.id } }
    }
}

struct StreamLinksRow: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focusedID: String?

    var visibleLinks: [StreamLink] { Array(store.streamLinks.prefix(20)) }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                Button {
                    Task { _ = await store.findStreams(for: item) }
                } label: {
                    Text("Search Links")
                        .font(.system(size: 20, weight: .black))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(focusedID == "search" ? Color.orange.opacity(0.75) : Color.white.opacity(0.12)))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedID == "search" ? Color.orange : Color.white.opacity(0.18), lineWidth: focusedID == "search" ? 3 : 1))
                        .scaleEffect(focusedID == "search" ? 1.06 : 1.0)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: "search")

                ForEach(visibleLinks) { link in
                    Button {
                        if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                            let alternates = store.playableURLs(from: store.streamLinks, selected: link)
                            store.startPlayback(item: item, url: url, alternates: alternates, subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive retry is armed.")
                        } else {
                            store.status = "This link is not direct-playable by AVFoundation. Magnet/infoHash playback needs the planned torrent/libVLC engine or a debrid direct URL."
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(link.quality)
                                .font(.system(size: 18, weight: .heavy))
                            Text(link.size)
                                .font(.system(size: 13, weight: .semibold))
                                .opacity(0.78)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 11)
                        .background(RoundedRectangle(cornerRadius: 13).fill(focusedID == link.id.uuidString ? Color.cyan.opacity(0.58) : Color.cyan.opacity(link.isDirectPlayable ? 0.30 : 0.10)))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(focusedID == link.id.uuidString ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == link.id.uuidString ? 3 : 1))
                        .scaleEffect(focusedID == link.id.uuidString ? 1.06 : 1.0)
                    }
                    .buttonStyle(.plain)
                    .focused($focusedID, equals: link.id.uuidString)
                }
            }
            .focusSection()
        }
        .frame(width: 1220, alignment: .leading)
        .onAppear { if focusedID == nil { focusedID = "search" } }
    }
}

struct TrailerPopup: View {
    let url: URL
    let close: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(spacing: 18) {
                SilentVideoBackground(url: url)
                    .frame(width: 1540, height: 720)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .background(Color.black)
                Button("Close Trailer", action: close)
                    .font(.system(size: 26, weight: .bold))
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}


struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL

    @State private var player: AVPlayer? = nil
    @State private var controlsVisible = true
    @State private var isPlaying = true
    @State private var isLoading = true
    @State private var errorText: String? = nil
    @State private var retryText: String? = nil
    @State private var currentSeconds: Double = 0
    @State private var durationSeconds: Double = 0
    @State private var videoGravity: AVLayerVideoGravity = .resizeAspect
    @State private var timeObserver: Any? = nil
    @State private var statusObserver: NSKeyValueObservation? = nil
    @State private var hideTask: Task<Void, Never>? = nil
    @State private var endObserver: NSObjectProtocol? = nil
    @State private var renderWatchdogTask: Task<Void, Never>? = nil
    @State private var nativePrepareTask: Task<Void, Never>? = nil
    @State private var activePanel: PlayerPanel? = nil
    @State private var playbackNotice: String = ""
    @State private var lastPlayerActionAt: TimeInterval = 0
    @State private var forceVLCSurface = true
    @State private var forceMPVSurface = false
    @State private var avRetryAttemptedForCurrentURL = false
    @State private var nativeProfileText: String = ""
    @State private var vlcSeekSerial = 0
    @State private var vlcSeekSeconds: Double = 0
    @State private var vlcSurfaceToken: Int = 0
    @FocusState private var focusedControl: PlayerControl?

    enum PlayerControl: Hashable { case back10, playPause, forward10, mpv, internalVLC, audio, subtitles, episodes, zoom, settings, infuse, vlc, senplayer, close }
    enum PlayerPanel: Hashable { case audio, subtitles, episodes, settings }

    private var activeEngineName: String {
        forceMPVSurface ? "MPV/FFmpeg Internal" : "VLC Internal"
    }

    private var progress: Double {
        guard durationSeconds > 0 else { return 0 }
        return min(max(currentSeconds / durationSeconds, 0), 1)
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            UniversalVideoSurface(
                url: url,
                avPlayer: player,
                videoGravity: videoGravity,
                forceVLC: forceVLCSurface,
                routeHint: store.playbackLinkLabel,
                vlcShouldPlay: isPlaying,
                vlcSeekSerial: vlcSeekSerial,
                vlcSeekSeconds: vlcSeekSeconds,
                vlcSurfaceToken: vlcSurfaceToken,
                preferMPV: forceMPVSurface
            )
            .ignoresSafeArea()

            if isLoading {
                ZStack {
                    Color.black.opacity(0.30).ignoresSafeArea()
                    VStack(spacing: 18) {
                        ProgressView().scaleEffect(1.35)
                        Text(retryText ?? "Loading stream…")
                            .font(.system(size: 28, weight: .black))
                    }
                    .foregroundStyle(.white)
                }
                .zIndex(30)
            }

            if let errorText {
                ApplePlayerErrorCard(message: errorText) { store.closePlayer() }
                    .zIndex(40)
            }

            AppleVODChromeBackground()
                .ignoresSafeArea()
                .opacity(controlsVisible ? 1.0 : 0.0)

            if let activePanel {
                DebridPlayerPanel(
                    title: panelTitle(activePanel),
                    detail: panelDetail(activePanel),
                    close: { self.activePanel = nil; showControls() }
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
                .padding(.trailing, 76)
                .padding(.bottom, 292)
                .zIndex(15)
            }

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .bottom, spacing: 26) {
                    AppleVODPosterCard(item: item)

                    VStack(alignment: .leading, spacing: 12) {
                        HStack(spacing: 12) {
                            AppleVODBadge(text: activeEngineName, highlighted: true)
                            AppleVODBadge(text: videoGravity == .resizeAspectFill ? "Fill" : "Aspect Fit", highlighted: false)
                            AppleVODBadge(text: item.rating.isEmpty ? "NR" : "★ \(item.rating)", highlighted: false)
                            AppleVODBadge(text: item.year, highlighted: false)
                        }

                        HeroLogoText(item: item, pulse: true)
                            .frame(width: 630, height: 88, alignment: .leading)

                        Text(item.title)
                            .font(.system(size: 34, weight: .black, design: .rounded))
                            .lineLimit(1)
                            .foregroundStyle(.white)

                        Text("\(item.type.capitalized)  •  \(item.genres.prefix(3).joined(separator: "  •  "))")
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))

                        Text(item.description)
                            .font(.system(size: 21, weight: .medium, design: .rounded))
                            .lineLimit(2)
                            .foregroundStyle(.white.opacity(0.72))
                            .frame(width: 1040, alignment: .leading)
                    }
                }

                HStack(alignment: .center, spacing: 18) {
                    Text(formatTime(currentSeconds))
                        .font(.system(size: 21, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 86, alignment: .leading)
                    PlayerProgressBar(progress: progress)
                        .frame(width: 1290, height: 14)
                    Text(formatTime(durationSeconds))
                        .font(.system(size: 21, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 96, alignment: .trailing)
                }
                .foregroundStyle(.white.opacity(0.92))

                Text(playbackNotice.isEmpty ? "Selected stream: \(store.playbackLinkLabel)" : playbackNotice)
                    .font(.system(size: 18, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.56))
                    .lineLimit(1)
                    .frame(width: 1510, alignment: .leading)

                HStack(spacing: 12) {
                    PlayerControlButton(title: "−10", focus: .back10, focused: $focusedControl) { playerAction { seek(-10) } }
                    PlayerControlButton(title: isPlaying ? "Pause" : "Play", focus: .playPause, focused: $focusedControl) { playerAction { togglePlay() } }
                    PlayerControlButton(title: "+10", focus: .forward10, focused: $focusedControl) { playerAction { seek(10) } }
                    PlayerControlButton(title: "MPV", focus: .mpv, focused: $focusedControl) { playerAction { switchToMPVEngine() } }
                    PlayerControlButton(title: "VLC", focus: .internalVLC, focused: $focusedControl) { playerAction { switchToVLCEngine(manual: true) } }
                    PlayerControlButton(title: "Audio", focus: .audio, focused: $focusedControl) { playerAction { activePanel = .audio; cycleMedia(groupCharacteristic: .audible, label: "audio") } }
                    PlayerControlButton(title: "Subs", focus: .subtitles, focused: $focusedControl) { playerAction { activePanel = .subtitles; cycleMedia(groupCharacteristic: .legible, label: "subtitle") } }
                    PlayerControlButton(title: "Episodes", focus: .episodes, focused: $focusedControl) { playerAction { activePanel = .episodes; store.status = "Episode selector is wired into the Apple-style VOD overlay and ready for series episode rows."; showControls() } }
                    PlayerControlButton(title: "Zoom", focus: .zoom, focused: $focusedControl) { playerAction { toggleZoom() } }
                    PlayerControlButton(title: "Settings", focus: .settings, focused: $focusedControl) { playerAction { activePanel = .settings; store.status = "Player settings selected: MPV/VLC engine switch, external player handoff, subtitles/audio, zoom, buffering, and diagnostics."; showControls() } }
                    PlayerControlButton(title: "Infuse", focus: .infuse, focused: $focusedControl) { playerAction { openExternal(.infuse) } }
                    PlayerControlButton(title: "VLC App", focus: .vlc, focused: $focusedControl) { playerAction { openExternal(.vlc) } }
                    PlayerControlButton(title: "Sen", focus: .senplayer, focused: $focusedControl) { playerAction { openExternal(.senPlayer) } }
                    PlayerControlButton(title: "Close", focus: .close, focused: $focusedControl) { playerAction { store.closePlayer() } }
                }
                .focusSection()
            }
            .foregroundStyle(.white)
            .padding(.leading, 68)
            .padding(.bottom, 58)
            .frame(maxWidth: .infinity, alignment: .leading)
            .opacity(controlsVisible ? 1.0 : 0.0)
        }
        .onAppear { setupPlayer() }
        .onDisappear { teardownPlayer() }
        .onMoveCommand { direction in routePlayerMove(direction) }
        .onTapGesture {
            if activePanel != nil { activePanel = nil }
            showControls()
        }
        .onPlayPauseCommand { playerAction { togglePlay() } }
        .onExitCommand { store.closePlayer() }
    }

    private func playerAction(_ action: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastPlayerActionAt > 0.34 else { return }
        lastPlayerActionAt = now
        action()
        showControls()
    }

    private func routePlayerMove(_ direction: MoveCommandDirection) {
        showControls()
        let order: [PlayerControl] = [.back10, .playPause, .forward10, .mpv, .internalVLC, .audio, .subtitles, .episodes, .zoom, .settings, .infuse, .vlc, .senplayer, .close]
        let current = focusedControl ?? .playPause
        let idx = order.firstIndex(of: current) ?? 1
        switch direction {
        case .left:
            focusedControl = order[(idx - 1 + order.count) % order.count]
        case .right:
            focusedControl = order[(idx + 1) % order.count]
        case .up, .down:
            focusedControl = current
        default:
            break
        }
    }

    private func panelTitle(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio: return "Audio Tracks"
        case .subtitles: return "Subtitles"
        case .episodes: return "Episodes"
        case .settings: return "Playback Settings"
        }
    }

    private func panelDetail(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio:
            return "VLC Internal handles media track selection under the same Debrid overlay. mpv/FFmpeg is staged as the next vendored engine for even broader playback control."
        case .subtitles:
            return "Stremio subtitle URLs are captured for the overlay parser path. VLC Internal renders supported embedded/external subtitle formats through TVVLCKit when present; mpv/FFmpeg subtitle routing is staged next."
        case .episodes:
            return "Episode routing is connected to the VOD overlay and ready for series rows when the catalog/backend returns episodes."
        case .settings:
            return "Engines: VLC Internal is now the primary in-app renderer. mpv/FFmpeg is staged as the next vendored internal engine. AVPlayer is removed from the VOD decision path. External Infuse/VLC/SenPlayer handoff remains available. Current profile: \(nativeProfileText.isEmpty ? "pending" : nativeProfileText)."
        }
    }

    private func setupPlayer() {
        // v127: AVPlayer remains removed from the VOD decision path.
        // Internal playback starts with TVVLCKit/libVLC and can switch to MPVKit/libmpv under the same Debrid overlay.
        nativePrepareTask?.cancel()
        renderWatchdogTask?.cancel()
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        player?.pause()
        player = nil

        forceMPVSurface = false
        forceVLCSurface = true
        avRetryAttemptedForCurrentURL = false
        isLoading = false
        errorText = nil
        retryText = nil
        focusedControl = .playPause
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        nativeProfileText = profile.diagnostic

        #if canImport(TVVLCKit)
        isPlaying = true
        vlcSurfaceToken += 1
        playbackNotice = "VLC Internal playing • \(profile.diagnostic) • MPV/FFmpeg selectable • AVPlayer disabled"
        store.status = "V128 dual internal playback: TVVLCKit/libVLC is active; MPVKit/libmpv/FFmpeg is selectable for \(store.playbackLinkLabel)."
        #else
        isPlaying = false
        forceControlsVisible()
        playbackNotice = "TVVLCKit is not compiled into this IPA. MPVKit may still be available if the package resolved; AVPlayer is disabled in v127."
        errorText = "Internal playback needs the real TVVLCKit/libVLC payload or the future mpv/FFmpeg package. AVPlayer has been removed from the VOD path by request. Use external Infuse/VLC/SenPlayer until the embedded framework is present."
        store.status = playbackNotice
        #endif
    }

    private func prepareNativeAssetAndStart(url: URL, profile: NativePlaybackProfile) {
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 AVFoundation/MPV",
            "Accept": "video/mp4,video/quicktime,application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Range": "bytes=0-"
        ]
        let options: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": headers]
        let asset = AVURLAsset(url: url, options: options)

        nativePrepareTask = Task { @MainActor in
            do {
                // Load the real AVFoundation properties before making the visible player.
                // If these fail, AVPlayer would usually become audio-only/black or stutter.
                let playable = try await asset.load(.isPlayable)
                let tracks = try await asset.load(.tracks)
                let duration = try? await asset.load(.duration)
                let mediaCharacteristics = try? await asset.load(.availableMediaCharacteristicsWithMediaSelectionOptions)
                let videoTracks = tracks.filter { $0.mediaType == .video }
                let audioTracks = tracks.filter { $0.mediaType == .audio }

                guard !Task.isCancelled else { return }
                guard playable else {
                    handleNativePreparationFailure("VLC Internal rejected this asset as not playable before render.")
                    return
                }
                if videoTracks.isEmpty && !profile.isAppleContainer && !profile.isNativeDolbyVisionPreferred {
                    let audioCount = audioTracks.count
                    handleNativePreparationFailure("VLC Internal only exposed audio tracks (\(audioCount)) and no video track before render for \(profile.diagnostic).")
                    return
                }

                let itemAsset = AVPlayerItem(asset: asset)
                itemAsset.preferredForwardBufferDuration = profile.isHLS ? 60 : 180
                itemAsset.canUseNetworkResourcesForLiveStreamingWhilePaused = true
                itemAsset.preferredPeakBitRate = 0
                itemAsset.preferredMaximumResolution = CGSize(width: 4096, height: 2160)
                itemAsset.seekingWaitsForVideoCompositionRendering = true

                let av = AVPlayer(playerItem: itemAsset)
                av.appliesMediaSelectionCriteriaAutomatically = true
                av.automaticallyWaitsToMinimizeStalling = true
                av.preventsDisplaySleepDuringVideoPlayback = true
                av.allowsExternalPlayback = false

                player = av
                let durationText = duration.map { CMTimeGetSeconds($0).isFinite ? "duration \(Int(CMTimeGetSeconds($0)))s" : "duration live/unknown" } ?? "duration pending"
                let characteristicsText = mediaCharacteristics?.map { $0.rawValue }.joined(separator: ",") ?? "characteristics pending"
                playbackNotice = "VLC Internal ready • \(profile.diagnostic) • \(videoTracks.count) video track(s) • no bitrate cap • 4K/DV native path."
                store.status = "VLC Internal validation passed: \(videoTracks.count) video track(s), \(audioTracks.count) audio track(s), \(durationText), \(characteristicsText). Starting hardware playback path."
                attachNativePlayerObservers(item: itemAsset, player: av)
                av.play()
                isPlaying = true
            } catch {
                guard !Task.isCancelled else { return }
                handleNativePreparationFailure("VLC Internal asset preparation failed for \(profile.diagnostic): \(error.localizedDescription)")
            }
        }
    }

    private func handleNativePreparationFailure(_ message: String) {
        isLoading = false
        forceControlsVisible()
        store.status = message
        #if canImport(TVVLCKit)
        if UniversalCodecSupport.vlcCompiledIn {
            retryText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            errorText = message + "\n\nAVPlayer is disabled in v126. VLC Internal/mpv-FFmpeg are the in-app engine path; use external Infuse if needed."
        } else {
            errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        }
        #else
        errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        #endif
    }

    private func attachNativePlayerObservers(item itemAsset: AVPlayerItem, player av: AVPlayer) {
        statusObserver = itemAsset.observe(\.status, options: [.new, .initial]) { observedItem, _ in
            DispatchQueue.main.async {
                switch observedItem.status {
                case .readyToPlay:
                    isLoading = false
                    durationSeconds = CMTimeGetSeconds(observedItem.duration).isFinite ? CMTimeGetSeconds(observedItem.duration) : 0
                    let dimensions = observedItem.presentationSize
                    let event = observedItem.accessLog()?.events.last
                    let bitrateText = event.map { "observed \(Int($0.observedBitrate))bps / indicated \(Int($0.indicatedBitrate))bps" } ?? "bitrate pending"
                    let sizeText = dimensions.width > 8 ? "\(Int(dimensions.width))×\(Int(dimensions.height))" : "video size pending"
                    playbackNotice = "VLC Internal playing • \(nativeProfileText) • \(sizeText) • \(bitrateText)"
                    store.status = "Playback route: \(activeEngineName); \(nativeProfileText); video size \(sizeText); \(bitrateText); selected \(store.playbackLinkLabel)"
                    av.play()
                    isPlaying = true
                    startRenderWatchdog(for: observedItem, player: av)
                    scheduleAutoHide()
                case .failed:
                    isLoading = false
                    let message = observedItem.error?.localizedDescription ?? "The selected stream could not be played."
                    if let next = store.advanceToNextPlaybackURL(after: url) {
                        retryText = "Stream failed; retrying next source…"
                        errorText = nil
                        store.status = "Playback failed on one source: \(message). Retrying \(next.absoluteString.prefix(80))…"
                    } else {
                        forceControlsVisible()
                        errorText = message + "\nEngine: \(activeEngineName). VLC Internal failed after validated setup; try VLC Internal or external Infuse/VLC/SenPlayer for this stream."
                    }
                default:
                    break
                }
            }
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { time in
            if !forceVLCSurface {
                currentSeconds = CMTimeGetSeconds(time).isFinite ? CMTimeGetSeconds(time) : 0
            }
                if let duration = av.currentItem?.duration {
                let seconds = CMTimeGetSeconds(duration)
                if seconds.isFinite { durationSeconds = seconds }
            }
            if !forceVLCSurface { isPlaying = av.timeControlStatus == .playing }
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: itemAsset, queue: .main) { _ in
            isPlaying = false
            controlsVisible = true
            focusedControl = .playPause
        }

        if !store.playbackSubtitleURLs.isEmpty {
            store.status = "Captured \(store.playbackSubtitleURLs.count) external subtitle URL(s) from the selected Stremio stream."
        }
    }

    private func teardownPlayer() {
        hideTask?.cancel()
        nativePrepareTask?.cancel()
        nativePrepareTask = nil
        renderWatchdogTask?.cancel()
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        player?.pause()
        player = nil
    }

    private func openExternal(_ target: ExternalPlaybackTarget) {
        player?.pause()
        isPlaying = false
        forceControlsVisible()
        ExternalPlayerLauncher.open(target, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
            store.status = message
        }
    }

    private func switchToMPVEngine() {
        forceControlsVisible()
        // v128: MPVKit resolved on some builds but the runtime SwiftUI surface can crash on tvOS.
        // Do not instantiate MPVVideoPlayer until the compiled libmpv surface is validated on-device.
        // Keep playback alive on VLC Internal and show a clear status instead of crashing the app.
        player?.pause()
        forceMPVSurface = false
        forceVLCSurface = true
        vlcSurfaceToken += 1
        isPlaying = true
        isLoading = false
        errorText = nil
        #if canImport(MPVKit)
        playbackNotice = "MPV/FFmpeg is compiled but disabled in v128 because the MPV render surface is crashing on tvOS. VLC Internal remains active under the Debrid overlay."
        store.status = playbackNotice
        #else
        playbackNotice = "MPVKit/libmpv/FFmpeg is not compiled into this IPA. VLC Internal remains available if TVVLCKit is embedded."
        store.status = playbackNotice
        #endif
    }

    private func switchToVLCEngine(manual: Bool) {
        #if canImport(TVVLCKit)
        player?.pause()
        forceMPVSurface = false
        forceVLCSurface = true
        vlcSurfaceToken += 1
        isPlaying = true
        isLoading = false
        errorText = nil
        playbackNotice = manual ? "VLC Internal selected manually for this stream." : "Switched to VLC Internal after VLC Internal failure/audio-only detection."
        store.status = playbackNotice
        #else
        playbackNotice = "VLC Internal is not available in this IPA because TVVLCKit was not compiled in."
        store.status = playbackNotice
        #endif
    }

    private func togglePlay() {
        if forceVLCSurface {
            isPlaying.toggle()
            if isPlaying { showControls() } else { forceControlsVisible() }
            return
        }
        guard let player else { return }
        if player.timeControlStatus == .playing {
            player.pause()
            isPlaying = false
            forceControlsVisible()
        } else {
            player.play()
            isPlaying = true
            showControls()
        }
    }

    private func seek(_ seconds: Double) {
        if forceVLCSurface {
            vlcSeekSeconds = seconds
            vlcSeekSerial += 1
            showControls()
            return
        }
        guard let player else { return }
        let current = CMTimeGetSeconds(player.currentTime())
        let target = max(0, current + seconds)
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        showControls()
    }

    private func toggleZoom() {
        videoGravity = videoGravity == .resizeAspect ? .resizeAspectFill : .resizeAspect
        showControls()
    }

    private func cycleMedia(groupCharacteristic: AVMediaCharacteristic, label: String) {
        guard !forceVLCSurface else {
            store.status = "\(label.capitalized) selection for VLC Internal is handled by TVVLCKit; full track picker is staged for the next VLC controls pass."
            showControls()
            return
        }
        guard let item = player?.currentItem, let group = item.asset.mediaSelectionGroup(forMediaCharacteristic: groupCharacteristic) else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let options = group.options
        guard !options.isEmpty else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let current = item.currentMediaSelection.selectedMediaOption(in: group)
        let nextIndex: Int
        if let current, let idx = options.firstIndex(of: current) {
            nextIndex = (idx + 1) % options.count
        } else {
            nextIndex = 0
        }
        item.select(options[nextIndex], in: group)
        store.status = "Selected \(label): \(options[nextIndex].displayName)"
        showControls()
    }

    private func startRenderWatchdog(for item: AVPlayerItem, player: AVPlayer) {
        renderWatchdogTask?.cancel()
        renderWatchdogTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard errorText == nil, !forceVLCSurface else { return }
            let size = item.presentationSize
            let hasVideo = size.width > 8 && size.height > 8
            let likelyPlaying = player.timeControlStatus == .playing || player.rate > 0
            if !hasVideo && likelyPlaying {
                #if canImport(TVVLCKit)
                if !avRetryAttemptedForCurrentURL && UniversalCodecSupport.vlcCompiledIn {
                    avRetryAttemptedForCurrentURL = true
                    retryText = "VLC Internal produced audio/no video; switching this same URL to VLC Internal…"
                    switchToVLCEngine(manual: false)
                    forceControlsVisible()
                    return
                }
                #endif
                isLoading = false
                forceControlsVisible()
                errorText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            }
        }
    }

    private func forceControlsVisible() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
    }

    private func showControls() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
        scheduleAutoHide()
    }

    private func scheduleAutoHide() {
        hideTask?.cancel()
        guard isPlaying, activePanel == nil, errorText == nil, !isLoading else { return }
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard isPlaying, activePanel == nil, errorText == nil, !isLoading else { return }
            withAnimation(.easeInOut(duration: 0.28)) { controlsVisible = false }
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds > 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }
}

struct ApplePlayerErrorCard: View {
    let message: String
    let close: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 18) {
            Text("Playback Error")
                .font(.system(size: 34, weight: .black, design: .rounded))
            Text(message)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.78))
            Button(action: close) {
                Text("Close Player")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(focused ? .black : .white)
                    .padding(.horizontal, 34)
                    .padding(.vertical, 15)
                    .background(Capsule().fill(focused ? Color.white : Color.white.opacity(0.16)))
            }
            .buttonStyle(.plain)
            .focused($focused)
        }
        .padding(42)
        .frame(maxWidth: 900)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .foregroundStyle(.white)
        .shadow(color: .black.opacity(0.55), radius: 30)
        .onAppear { focused = true }
    }
}

struct AppleVODPosterCard: View {
    let item: MediaItem

    var body: some View {
        RemoteImageFit(url: item.posterURL, mode: .fill)
            .frame(width: 178, height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.24), lineWidth: 1))
            .shadow(color: .black.opacity(0.68), radius: 18, x: 0, y: 10)
            .overlay(alignment: .bottomLeading) {
                Text(item.rating.isEmpty ? "NR" : "★ \(item.rating)")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                    .padding(10)
            }
    }
}

struct AppleVODBadge: View {
    let text: String
    let highlighted: Bool

    var body: some View {
        Text(text)
            .font(.system(size: 17, weight: .black, design: .rounded))
            .foregroundStyle(highlighted ? .black : .white.opacity(0.86))
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(highlighted ? Color.white.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(Capsule().stroke(Color.white.opacity(highlighted ? 0.0 : 0.16), lineWidth: 1))
    }
}

struct AppleVODChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.clear, .black.opacity(0.16), .black.opacity(0.92)],
                startPoint: .top,
                endPoint: .bottom
            )
            LinearGradient(
                colors: [.black.opacity(0.18), .clear, .black.opacity(0.16)],
                startPoint: .leading,
                endPoint: .trailing
            )
            VStack { Spacer() }
                .background(
                    Rectangle()
                        .fill(Color.black.opacity(0.22))
                        .background(.ultraThinMaterial)
                        .frame(height: 420),
                    alignment: .bottom
                )
        }
    }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        view.playerLayer.videoGravity = videoGravity
        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        view.playerLayer.player = player
        view.playerLayer.videoGravity = videoGravity
    }
}

struct DebridPlayerPanel: View {
    let title: String
    let detail: String
    let close: () -> Void
    @FocusState private var closeFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.system(size: 34, weight: .black))
            Text(detail)
                .font(.system(size: 23, weight: .semibold))
                .foregroundStyle(.white.opacity(0.82))
                .lineLimit(5)
            Button(action: close) {
                Text("CLOSE PANEL")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(closeFocused ? .black : .white)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 14)
                    .background(Capsule().fill(closeFocused ? Color.white : Color.white.opacity(0.14)))
                    .overlay(Capsule().stroke(Color.white.opacity(0.4), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .focused($closeFocused)
        }
        .foregroundStyle(.white)
        .padding(30)
        .frame(width: 520, alignment: .leading)
        .background(.ultraThinMaterial.opacity(0.92), in: RoundedRectangle(cornerRadius: 30))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.55), radius: 26)
        .focusSection()
        .onAppear { closeFocused = true }
    }
}

struct PlayerChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.clear, .black.opacity(0.25), .black.opacity(0.92)], startPoint: .top, endPoint: .bottom)
            LinearGradient(colors: [.black.opacity(0.18), .clear, .black.opacity(0.20)], startPoint: .leading, endPoint: .trailing)
        }
    }
}

struct PlayerProgressBar: View {
    let progress: Double

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.18))
                Capsule().fill(Color.white.opacity(0.72)).frame(width: proxy.size.width * min(max(progress, 0), 1))
                Circle().fill(Color.white).frame(width: 18, height: 18).offset(x: max(0, proxy.size.width * min(max(progress, 0), 1) - 9))
            }
        }
    }
}

struct PlayerControlButton: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let action: () -> Void

    var isSelected: Bool { focused.wrappedValue == focus }

    var body: some View {
        Text(title)
            .font(.system(size: 20, weight: .black, design: .rounded))
            .foregroundStyle(isSelected ? Color.black : Color.white.opacity(0.92))
            .padding(.horizontal, 21)
            .padding(.vertical, 13)
            .background(
                Capsule().fill(isSelected ? Color.white.opacity(0.94) : Color.white.opacity(0.105))
            )
            .overlay(Capsule().stroke(isSelected ? Color.white.opacity(0.98) : Color.white.opacity(0.20), lineWidth: isSelected ? 2 : 1))
            .scaleEffect(isSelected ? 1.055 : 1.0)
            .shadow(color: isSelected ? Color.white.opacity(0.28) : .clear, radius: 13)
            .contentShape(Capsule())
            .focusable(true)
            .focused(focused, equals: focus)
            .onTapGesture(perform: action)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @FocusState private var focused: SettingsFocus?

    enum SettingsFocus: Hashable { case manifest, add, load, loadAll, reset, home, movies, shows, live }

    var body: some View {
        ZStack {
            CinematicAmbientBackground().ignoresSafeArea()

            VStack(alignment: .leading, spacing: 22) {
                Text("Settings")
                    .font(.system(size: 62, weight: .black))
                    .foregroundStyle(.white)
                    .padding(.top, 132)

                VStack(alignment: .leading, spacing: 16) {
                    Text("Stremio JSON Catalogs")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)

                    TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
                        .font(.system(size: 25, weight: .semibold))
                        .foregroundStyle(.white)
                        .padding(20)
                        .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.cyan : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
                        .focused($focused, equals: .manifest)
                        .frame(width: 1180)

                    HStack(spacing: 16) {
                        SettingsButton(title: "Add JSON", focus: .add, focused: $focused) {
                            store.addManifestURL(manifestURL)
                            manifestURL = ""
                        }
                        SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL", focus: .load, focused: $focused) {
                            Task { await store.loadManifest(urlString: manifestURL) }
                        }
                        SettingsButton(title: "Load All Catalogs", focus: .loadAll, focused: $focused) {
                            Task { await store.loadAllManifests() }
                        }
                        SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                            store.resetDemo()
                        }
                    }

                    VStack(alignment: .leading, spacing: 8) {
                        Text("Saved JSON URLs")
                            .font(.system(size: 20, weight: .black))
                            .foregroundStyle(.cyan)
                        ForEach(store.manifestURLs.prefix(5), id: \.self) { url in
                            Text("• \(url)")
                                .font(.system(size: 17, weight: .semibold))
                                .foregroundStyle(.white.opacity(0.72))
                                .lineLimit(1)
                                .frame(width: 1120, alignment: .leading)
                        }
                    }
                    .padding(.top, 4)

                    Text("Build v85 FULL 1-8 CLEAN PASS")
                        .font(.system(size: 22, weight: .black))
                        .foregroundStyle(Color.cyan)
                    Text(store.status)
                        .font(.system(size: 22, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .frame(width: 1180, alignment: .leading)
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                VStack(alignment: .leading, spacing: 14) {
                    Text("Quick Navigation")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundStyle(.white)
                    HStack(spacing: 18) {
                        SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                        SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                        SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                        SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
                    }
                }
                .padding(28)
                .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
                .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))

                Spacer()
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
        }
        .onAppear { focused = .manifest }
        .onMoveCommand { direction in routeSettings(direction) }
    }

    private func routeSettings(_ direction: MoveCommandDirection) {
        switch direction {
        case .right:
            switch focused {
            case .manifest: focused = .add
            case .add: focused = .load
            case .load: focused = .loadAll
            case .loadAll: focused = .reset
            case .reset: focused = .home
            case .home: focused = .movies
            case .movies: focused = .shows
            case .shows: focused = .live
            case .live, .none: focused = .manifest
            }
        case .left:
            switch focused {
            case .manifest: focused = .live
            case .add: focused = .manifest
            case .load: focused = .add
            case .loadAll: focused = .load
            case .reset: focused = .loadAll
            case .home: focused = .reset
            case .movies: focused = .home
            case .shows: focused = .movies
            case .live, .none: focused = .shows
            }
        case .down:
            switch focused {
            case .manifest: focused = .add
            case .add, .load, .loadAll, .reset: focused = .home
            case .home, .movies, .shows, .live: break
            case .none: focused = .manifest
            }
        case .up:
            switch focused {
            case .home, .movies, .shows, .live: focused = .add
            case .add, .load, .loadAll, .reset: focused = .manifest
            case .manifest: store.menuFocusToken += 1
            case .none: focused = .manifest
            }
        default:
            break
        }
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}

struct LiveTVPlaceholder: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            VStack(spacing: 24) {
                Text("Live TV")
                    .font(.system(size: 76, weight: .black))
                Text("Live TV layout is preserved for the next native tvOS guide pass.")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.74))
            }
            .foregroundStyle(.white)
        }
    }
}
