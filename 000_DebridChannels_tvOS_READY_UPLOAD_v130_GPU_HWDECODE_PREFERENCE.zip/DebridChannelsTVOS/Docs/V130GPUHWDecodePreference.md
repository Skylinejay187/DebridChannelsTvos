# V130 GPU Hardware Decode Preference

- VLC/TVVLCKit now requests Apple VideoToolbox hardware decode with `avcodec-hw=videotoolbox` instead of generic `any`.
- VLC cache was increased to reduce 4K debrid stutter while keeping late-frame dropping enabled.
- MPV/FFmpeg hardware preference options are centralized for the future stable mpv renderer: `hwdec=videotoolbox`, `vo=gpu`, `gpu-api=metal`.
- This requests/prefer hardware decoding; it cannot force Apple TV hardware to decode codecs/profiles the hardware does not support.
- v73 Home/detail visuals preserved.
