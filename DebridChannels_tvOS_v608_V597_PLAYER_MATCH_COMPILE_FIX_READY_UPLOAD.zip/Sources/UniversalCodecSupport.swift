import SwiftUI
import AVFoundation
import AVKit

#if canImport(TVVLCKit)
import TVVLCKit
#endif
#if canImport(KSPlayer)
import KSPlayer
#endif

// v155 VOD controls/audio/placement repair:
// - MPV remains fully removed from active source/package wiring.
// - KSPlayer remains primary and TVVLCKit/libVLC remains fallback.
// - Removed low-latency FFmpeg flags that can cause slow/juddery film playback on tvOS.
// - Keeps overlay refresh isolated from the video surface and restores stable buffering.



struct NativePlaybackProfile {
    let normalizedHint: String
    let isHLS: Bool
    let isAppleContainer: Bool
    let isMatroskaOrUnsupportedContainer: Bool
    let isLikelyDolbyVision: Bool
    let isNativeDolbyVisionPreferred: Bool
    let isLikelyHDR: Bool
    let isLikelyUnsupportedAudioOnlyRisk: Bool
    let requiresVLCForContainer: Bool

    var diagnostic: String {
        var flags: [String] = []
        if isHLS { flags.append("HLS") }
        if isAppleContainer { flags.append("Apple container") }
        if isLikelyDolbyVision { flags.append("Dolby Vision hint") }
        if isNativeDolbyVisionPreferred { flags.append("Native DV preferred") }
        if isLikelyHDR { flags.append("HDR hint") }
        if isMatroskaOrUnsupportedContainer { flags.append("MKV/unsupported container") }
        if isLikelyUnsupportedAudioOnlyRisk { flags.append("audio-only risk") }
        return flags.isEmpty ? "generic HTTP stream" : flags.joined(separator: " • ")
    }
}

enum UniversalCodecSupport {
    static let buildMarker = "DEBRID_CHANNELS_TVOS_BUILD_V444_LIVE_GRID_BOTTOM_BAR_FIX"

    static var vlcCompiledIn: Bool {
        #if canImport(TVVLCKit)
        return true
        #else
        return false
        #endif
    }


    static var ksPlayerCompiledIn: Bool {
        #if canImport(KSPlayer)
        return true
        #else
        return false
        #endif
    }

    static func profile(for url: URL, hint: String = "") -> NativePlaybackProfile {
        let value = (url.absoluteString + " " + hint).lowercased()
        let isHLS = value.contains(".m3u8") || value.contains("application/vnd.apple.mpegurl") || value.contains("mpegurl")
        let isAppleContainer = isHLS || value.contains(".mp4") || value.contains("%2emp4") || value.contains(".m4v") || value.contains("%2em4v") || value.contains(".mov") || value.contains("%2emov")
        let isMatroska = value.contains(".mkv") || value.contains("%2emkv") || value.contains("matroska")
        let unsupportedContainer = isMatroska || value.contains(".avi") || value.contains("%2eavi") || value.contains(".webm") || value.contains("%2ewebm") || value.contains(".vob") || value.contains("%2evob")
        let isDolbyVision = value.contains("dolby vision") || value.contains(" dolbyvision") || value.contains(" dv ") || value.contains("dvhe") || value.contains("dvh1") || value.contains("profile 5") || value.contains("profile 7") || value.contains("profile 8")
        let nativeDVPreferred = isAppleContainer && (value.contains("profile 5") || value.contains("profile 8") || value.contains("dvhe.05") || value.contains("dvhe.08") || value.contains("dvh1") || isHLS)
        let hdr = isDolbyVision || value.contains("hdr10") || value.contains("hdr10+") || value.contains("hlg") || value.contains("bt2020") || value.contains("main10")
        let audioRisk = value.contains(" dts") || value.contains("dts-hd") || value.contains("dtshd") || value.contains("truehd") || value.contains("mlp") || value.contains("atmos truehd") || value.contains("vp9") || value.contains("av1")
        let profile7 = value.contains("profile 7") || value.contains("dvhe.07") || value.contains("dolby vision profile 7")
        let requiresVLC = unsupportedContainer || profile7 || audioRisk
        return NativePlaybackProfile(
            normalizedHint: value,
            isHLS: isHLS,
            isAppleContainer: isAppleContainer,
            isMatroskaOrUnsupportedContainer: unsupportedContainer,
            isLikelyDolbyVision: isDolbyVision,
            isNativeDolbyVisionPreferred: nativeDVPreferred,
            isLikelyHDR: hdr,
            isLikelyUnsupportedAudioOnlyRisk: audioRisk || profile7,
            requiresVLCForContainer: requiresVLC
        )
    }

    static func shouldPreferVLC(for url: URL, hint: String = "") -> Bool {
        let p = profile(for: url, hint: hint)
        if p.normalizedHint.hasPrefix("magnet:") { return false }
        // v126: AVPlayer is no longer the internal VOD default. Use VLC for all direct internal playback.
        return true
    }

    static func playbackEngineName(for url: URL, hint: String = "") -> String {
        if ksPlayerCompiledIn && vlcCompiledIn { return "KSPlayer/FFmpeg/Metal primary + TVVLCKit/libVLC fallback" }
        if ksPlayerCompiledIn { return "KSPlayer/FFmpeg/Metal internal engine" }
        if vlcCompiledIn { return "TVVLCKit/libVLC internal engine" }
        return "No internal engine compiled; KSPlayer/TVVLCKit missing"
    }


    static func inferredSourceFPS(for profile: NativePlaybackProfile) -> String {
        let value = profile.normalizedHint
        if value.contains("23.976") || value.contains("23_976") || value.contains("24000/1001") { return "23.976 target" }
        if value.contains("24fps") || value.contains(" 24 ") || value.contains(".24.") { return "24 target" }
        if value.contains("25fps") || value.contains(" 25 ") || value.contains(".25.") { return "25 target" }
        if value.contains("29.97") || value.contains("30000/1001") { return "29.97 target" }
        if value.contains("30fps") || value.contains(" 30 ") || value.contains(".30.") { return "30 target" }
        if value.contains("50fps") || value.contains(" 50 ") || value.contains(".50.") { return "50 target" }
        if value.contains("59.94") || value.contains("60000/1001") { return "59.94 target" }
        if value.contains("60fps") || value.contains(" 60 ") || value.contains(".60.") { return "60 target" }
        // Most VOD movie/show files are 23.976/24p even when the file name only exposes 1080p/2160p.
        return "23.976/24 target"
    }

    static func magnetDiagnostic(for value: String) -> String? {
        let lower = value.lowercased()
        guard lower.hasPrefix("magnet:") || lower.contains("infohash") else { return nil }
        return "Magnet/infoHash items require the torrent framework/service path before playback. Direct TorBox/debrid HTTP(S) stream URLs play in-app; raw torrent streaming is isolated from AVFoundation."
    }
}


struct DebridPlaybackDiagnostics: Equatable {
    var activeEngine: String
    var hwDecode: String
    var renderBackend: String
    var decoder: String
    var fps: String
    var droppedFrames: String
    var notes: String
}

enum DebridPlaybackDiagnosticsFactory {
    static func make(engine: String, profile: NativePlaybackProfile, controlsVisible: Bool, isPlaying: Bool) -> DebridPlaybackDiagnostics {
        let isKS = engine.lowercased().contains("ksplayer")
        let isVLC = engine.lowercased().contains("vlc")
        let render = isKS ? "Metal path active" : (isVLC ? "VLC drawable active" : "Unknown")
        let decoder = isKS ? "KS VideoToolbox/FFmpeg" : (isVLC ? "libVLC/VideoToolbox when available" : "Unknown")
        let hw = isKS ? "Preferred/engine-reported" : (isVLC ? "Preferred/engine-managed" : "Unknown")
        let fps = UniversalCodecSupport.inferredSourceFPS(for: profile)
        let dropped = isPlaying ? "Engine monitor" : "0 idle"
        var noteBits: [String] = []
        noteBits.append("content cadence")
        if profile.isHLS { noteBits.append("HLS") }
        if profile.isLikelyHDR { noteBits.append("HDR/DV hint") }
        if profile.isMatroskaOrUnsupportedContainer { noteBits.append("MKV/container fallback risk") }
        if !controlsVisible { noteBits.append("overlay idle") } else { noteBits.append("overlay visible") }
        return DebridPlaybackDiagnostics(activeEngine: engine, hwDecode: hw, renderBackend: render, decoder: decoder, fps: fps, droppedFrames: dropped, notes: noteBits.joined(separator: " • "))
    }
}

struct UniversalVideoSurface: View {
    let url: URL
    let avPlayer: AVPlayer?
    let videoGravity: AVLayerVideoGravity
    var forceVLC: Bool = true
    var routeHint: String = ""
    var vlcShouldPlay: Bool = true
    var vlcSeekSerial: Int = 0
    var vlcSeekSeconds: Double = 0
    var vlcSurfaceToken: Int = 0
    var ksShouldPlay: Bool = true
    var ksSeekSerial: Int = 0
    var ksSeekSeconds: Double = 0
    var ksReloadToken: Int = 0
    var ksStartTimeSeconds: Double = 0
    var ksSeekIsAbsolute: Bool = false
    var preferKSPlayer: Bool = true
    var preferAVFoundation: Bool = false
    var externalAudioURL: URL? = nil
    var externalAudioOffsetMS: Int = 0

    @ViewBuilder
    var body: some View {
        if preferAVFoundation {
            AVPlayerControllerSurface(player: avPlayer, videoGravity: videoGravity)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
        } else if preferKSPlayer {
            #if canImport(KSPlayer)
            KSPlayerVideoSurface(url: url, shouldPlay: ksShouldPlay, seekSerial: ksSeekSerial, seekSeconds: ksSeekSeconds, seekIsAbsolute: ksSeekIsAbsolute, reloadToken: ksReloadToken, startTimeSeconds: ksStartTimeSeconds, externalAudioURL: externalAudioURL, externalAudioOffsetMS: externalAudioOffsetMS)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
            #else
            MissingInternalEngineSurface(message: "KSPlayer/FFmpeg/Metal was not compiled into this IPA. Use VLC Internal while the KSPlayer package resolves.")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
            #endif
        } else {
            #if canImport(TVVLCKit)
            TVVLCKitVideoSurface(url: url, shouldPlay: vlcShouldPlay, seekSerial: vlcSeekSerial, seekSeconds: vlcSeekSeconds, seekIsAbsolute: false, reloadToken: vlcSurfaceToken, externalAudioURL: externalAudioURL, externalAudioOffsetMS: externalAudioOffsetMS)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
            #else
            MissingInternalEngineSurface(message: "TVVLCKit/libVLC was not compiled into this IPA. Use KSPlayer Internal or external Infuse/VLC/SenPlayer.")
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.black)
            #endif
        }
    }
}


#if canImport(KSPlayer)
struct KSPlayerVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    let startTimeSeconds: Double
    let externalAudioURL: URL?
    let externalAudioOffsetMS: Int
    var muteAudio: Bool = false
    var contentMode: UIView.ContentMode = .scaleAspectFit

    final class KSContainerView: UIView {
        override var canBecomeFocused: Bool { false }
        override func didMoveToWindow() {
            super.didMoveToWindow()
            isUserInteractionEnabled = false
        }
        override func layoutSubviews() {
            super.layoutSubviews()
            clipsToBounds = true
            subviews.forEach { child in
                child.transform = .identity
                child.frame = bounds
                child.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            }
            stripKSPlayerChrome(in: self)
        }
        func stripKSPlayerChrome(in root: UIView) {
            for child in root.subviews {
                let className = String(describing: type(of: child)).lowercased()
                let isChrome = child is UIControl || child is UILabel || child is UIStackView || child is UIButton || className.contains("toolbar") || className.contains("control") || className.contains("button") || className.contains("slider") || className.contains("mask") || className.contains("caption")
                if isChrome {
                    child.isHidden = true
                    child.alpha = 0
                    child.isUserInteractionEnabled = false
                } else {
                    child.isUserInteractionEnabled = false
                    stripKSPlayerChrome(in: child)
                }
            }
        }
    }

    final class Coordinator {
        var playerLayer: KSPlayerLayer?
        var currentURL: URL?
        var lastSeekSerial: Int = 0
        var lastReloadToken: Int = -1
        var currentStartTimeSeconds: Double = 0
        var currentExternalAudioURL: URL?
        var currentExternalAudioOffsetMS: Int = 0
        var currentMuteAudio: Bool = false
        var currentContentMode: UIView.ContentMode = .scaleAspectFit
        var currentShouldPlay: Bool? = nil
    }

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> KSContainerView {
        let view = KSContainerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: KSContainerView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func makeOptions(url: URL, muteAudio: Bool = false, startTimeSeconds: Double = 0) -> KSOptions {
        let options = KSOptions()
        KSOptions.isAutoPlay = true
        let lowerURL = url.absoluteString.lowercased()
        let isTrailerPlayback = lowerURL.contains("/trailers/") || lowerURL.contains("trailer")
        let isAppleNativeFriendly = lowerURL.contains(".m3u8") || lowerURL.contains(".mp4") || lowerURL.contains(".mov") || lowerURL.contains("/hls")
        // v608: keep the v597 KSPlayer surface/overlay path, but for Apple-native-friendly
        // VOD/HLS/MP4 URLs let the KSPlayer package try its AVFoundation-backed player first.
        // That is the route tvOS can honor for system Match Frame Rate / Match Dynamic Range.
        // MKV/remux/unknown links still keep the FFmpeg/Metal engine first for compatibility.
        if !isTrailerPlayback && isAppleNativeFriendly {
            KSOptions.firstPlayerType = KSAVPlayer.self
            KSOptions.secondPlayerType = KSMEPlayer.self
        } else {
            KSOptions.firstPlayerType = KSMEPlayer.self
            KSOptions.secondPlayerType = KSAVPlayer.self
        }
        options.isSecondOpen = true
        options.isAccurateSeek = false
        options.isSeekedAutoPlay = true
        options.startPlayTime = max(0, startTimeSeconds)
        options.preferredForwardBufferDuration = isTrailerPlayback ? 0 : 0
        options.maxBufferDuration = isTrailerPlayback ? 3 : 3
        options.hardwareDecode = true
        options.asynchronousDecompression = true
        options.videoAdaptable = true
        options.autoSelectEmbedSubtitle = false
        options.registerRemoteControll = false
        options.userAgent = isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer"
        options.avOptions = [
            "AVURLAssetHTTPHeaderFieldsKey": [
                "User-Agent": isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
                "Accept": "*/*",
                "Connection": "keep-alive"
            ]
        ]
        var formatOptions: [String: String] = [
            "reconnect": "1",
            "reconnect_streamed": "1",
            "reconnect_delay_max": "5",
            "fflags": isTrailerPlayback ? "nobuffer+genpts" : "nobuffer",
            "flags": isTrailerPlayback ? "" : "low_delay",
            "cache": isTrailerPlayback ? "0" : "0",
            "rw_timeout": "15000000",
            "user_agent": isTrailerPlayback ? "DebridChannels-tvOS/438 TrailerKSPlayer" : "DebridChannels-tvOS/158 KSPlayer",
            "preferred_language": "eng,en,English",
            "preferred_audio_language": "eng,en,English",
            "audio_language": "eng,en,English",
            "alang": "eng,en,English",
            "slang": "off",
            "subtitles": "0",
            "sn": "1",
            "analyzeduration": isTrailerPlayback ? "1000000" : "100000",
            "probesize": isTrailerPlayback ? "262144" : "16384",
            "thread_queue_size": "8192",
            "max_delay": isTrailerPlayback ? "100000" : "100000",
            "sync": "audio",
            "fpsprobesize": isTrailerPlayback ? "240" : "120"
        ]
        if isTrailerPlayback {
            formatOptions.removeValue(forKey: "flags")
        }
        if muteAudio {
            formatOptions["an"] = "1"
            formatOptions["audio_disable"] = "1"
            formatOptions["volume"] = "0"
        }
        options.formatContextOptions = formatOptions
        return options
    }


    private func performBestEffortSeek(layer: KSPlayerLayer, seconds: Double, isAbsolute: Bool) {
        let value = NSNumber(value: seconds)
        if let object = layer.player as? NSObject {
            let absoluteSelectors = [
                "seekToTime:",
                "seekTo:",
                "setCurrentPlaybackTime:",
                "setCurrentTime:"
            ]
            let relativeSelectors = [
                "seek:",
                "seekBy:"
            ]
            let selectorNames = isAbsolute ? absoluteSelectors + relativeSelectors : relativeSelectors + absoluteSelectors
            for name in selectorNames {
                let selector = NSSelectorFromString(name)
                if object.responds(to: selector) {
                    _ = object.perform(selector, with: value)
                    return
                }
            }
        }
    }

    private func applyAudioMuteState(_ layer: KSPlayerLayer, muteAudio: Bool) {
        if let object = layer.player as? NSObject {
            let mutedSelector = NSSelectorFromString("setMuted:")
            let volumeSelector = NSSelectorFromString("setVolume:")
            if object.responds(to: mutedSelector) { object.setValue(muteAudio, forKey: "muted") }
            if object.responds(to: volumeSelector) { object.setValue(muteAudio ? 0.0 : 1.0, forKey: "volume") }
        }
    }

    private func configure(view: KSContainerView, coordinator: Coordinator) {
        if coordinator.currentURL == url, coordinator.lastReloadToken == reloadToken, let layer = coordinator.playerLayer {
            if coordinator.currentExternalAudioURL != externalAudioURL || coordinator.currentExternalAudioOffsetMS != externalAudioOffsetMS || coordinator.currentMuteAudio != muteAudio || coordinator.currentContentMode != contentMode {
                coordinator.currentExternalAudioURL = externalAudioURL
                coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
                coordinator.currentMuteAudio = muteAudio
                coordinator.currentContentMode = contentMode
                // Smart Alternate Audio v1: keep the main video URL active and carry the selected
                // alternate audio reference/sync offset in the surface state. KSPlayer package APIs
                // differ by version for external audio attachment, so this v1 hook is non-crashing
                // and ready for the engine-specific attachment call when exposed by the compiled SDK.
            }
            view.subviews.forEach { child in
                child.contentMode = contentMode
                child.layer.contentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
                child.frame = view.bounds
            }
            if seekSerial != coordinator.lastSeekSerial {
                coordinator.lastSeekSerial = seekSerial
                performBestEffortSeek(layer: layer, seconds: seekSeconds, isAbsolute: seekIsAbsolute)
                if shouldPlay { layer.play() }
            }
            applyAudioMuteState(layer, muteAudio: muteAudio)
            // v408: KSPlayer can crash on some tvOS/package builds if play()/pause() is
            // spammed on every SwiftUI state refresh. Only send the command when the
            // requested playback state actually changes. This stabilizes Pause -> Play
            // without changing URL, cache, seek, overlay, or Live TV behavior.
            if coordinator.currentShouldPlay != shouldPlay {
                coordinator.currentShouldPlay = shouldPlay
                if shouldPlay { layer.play() } else { layer.pause() }
            }
            // v436 trailer playback restore: some trailer sources render the first frame
            // while KSPlayer remains internally paused after SwiftUI refreshes. For trailer
            // URLs only, keep the existing single layer alive and re-assert play on update.
            if shouldPlay, isTrailerURL(url) {
                forceStartTrailerLayerIfNeeded(layer, url: url)
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.20) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.65) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.40) { forceStartTrailerLayerIfNeeded(layer, url: url) }
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.50) { forceStartTrailerLayerIfNeeded(layer, url: url) }
            }
            return
        }

        coordinator.playerLayer?.pause()
        coordinator.playerLayer?.stop()
        view.subviews.forEach { $0.removeFromSuperview() }
        coordinator.currentURL = url
        coordinator.lastReloadToken = reloadToken
        coordinator.currentStartTimeSeconds = startTimeSeconds
        coordinator.currentExternalAudioURL = externalAudioURL
        coordinator.currentExternalAudioOffsetMS = externalAudioOffsetMS
        coordinator.currentMuteAudio = muteAudio
        coordinator.currentContentMode = contentMode
        coordinator.currentShouldPlay = shouldPlay
        coordinator.lastSeekSerial = seekSerial

        let options = makeOptions(url: url, muteAudio: muteAudio, startTimeSeconds: startTimeSeconds)
        let layer = KSPlayerLayer(url: url, isAutoPlay: true, options: options, delegate: nil)
        coordinator.playerLayer = layer
        if let playerView = layer.player.view {
            playerView.backgroundColor = .black
            playerView.isOpaque = true
            playerView.clearsContextBeforeDrawing = false
            playerView.contentMode = contentMode
            playerView.layer.contentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
            playerView.layer.drawsAsynchronously = true
            playerView.layer.contentsScale = UIScreen.main.scale
            playerView.isUserInteractionEnabled = false
            playerView.transform = .identity
            playerView.frame = view.bounds
            playerView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            playerView.clipsToBounds = true
            view.addSubview(playerView)
            view.setNeedsLayout()
            view.layoutIfNeeded()
            view.subviews.forEach { $0.frame = view.bounds }
        }
        applyAudioMuteState(layer, muteAudio: muteAudio)
        if !muteAudio { applyDefaultTracks(layer) }
        if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url) } else { layer.pause() }
        // v419 trailer-only fix: the trailer URL can load and render its first
        // frame before KSPlayer/FFmpeg is actually in a running state. Keep the
        // rescue tiny and scoped to trailer URLs only so main VOD playback is not
        // affected. This does not create a second layer/player; it nudges the
        // same attached KSPlayerLayer after decoder/track metadata becomes ready.
        for delay in [0.10, 0.35, 0.75, 1.20, 2.00, 3.20, 4.80] {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                view.subviews.forEach { child in
                    child.transform = .identity
                    child.contentMode = contentMode
                    child.layer.contentsGravity = contentMode == .scaleAspectFill ? .resizeAspectFill : .resizeAspect
                    child.frame = view.bounds
                    child.autoresizingMask = [.flexibleWidth, .flexibleHeight]
                }
                view.setNeedsLayout()
                view.layoutIfNeeded()
                view.stripKSPlayerChrome(in: view)
                if !muteAudio { applyDefaultTracks(layer) }
                applyAudioMuteState(layer, muteAudio: muteAudio)
                if shouldPlay { forceStartTrailerLayerIfNeeded(layer, url: url) }
            }
        }
    }

    private func isTrailerURL(_ url: URL) -> Bool {
        let lower = url.absoluteString.lowercased()
        return lower.contains("/trailers/") || lower.contains("trailer") || lower.contains("remux-cache") || lower.contains("kinocheck")
    }

    private func forceStartTrailerLayerIfNeeded(_ layer: KSPlayerLayer, url: URL) {
        let isTrailerPlayback = isTrailerURL(url)
        // Main VOD playback keeps its existing conservative play/pause behavior.
        guard isTrailerPlayback else { layer.play(); return }
        layer.play()
        if let object = layer.player as? NSObject {
            let selectors = ["play", "resume", "start"]
            for name in selectors {
                let selector = NSSelectorFromString(name)
                if object.responds(to: selector) { _ = object.perform(selector) }
            }
        }
    }

    private func applyDefaultTracks(_ layer: KSPlayerLayer) {
        let audioTracks = layer.player.tracks(mediaType: .audio)
        let normalizedEnglishCodes: Set<String> = ["en", "eng", "en-us", "en-gb", "english"]
        if let english = audioTracks.first(where: { track in
            let lang = (track.languageCode ?? track.language ?? "").lowercased()
            let name = track.name.lowercased()
            return normalizedEnglishCodes.contains(lang) || lang.hasPrefix("en") || lang.contains("eng") || name.contains("english") || name.contains("eng ") || name == "eng"
        }) {
            layer.player.select(track: english)
        }
        // Subtitles are intentionally default-off. The visible Debrid overlay will expose explicit subtitle selection later.
    }

    static func dismantleUIView(_ uiView: KSContainerView, coordinator: Coordinator) {
        coordinator.playerLayer?.pause()
        coordinator.playerLayer?.stop()
        coordinator.playerLayer = nil
        uiView.subviews.forEach { $0.removeFromSuperview() }
    }
}
#endif


struct MissingInternalEngineSurface: View {
    let message: String
    var body: some View {
        ZStack {
            Color.black
            VStack(spacing: 18) {
                Text("Internal Engine Missing")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                Text(message)
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.72))
                    .frame(maxWidth: 980)
            }
            .foregroundStyle(.white)
            .padding(42)
        }
    }
}

#if canImport(TVVLCKit)
struct TVVLCKitVideoSurface: UIViewRepresentable {
    let url: URL
    let shouldPlay: Bool
    let seekSerial: Int
    let seekSeconds: Double
    let seekIsAbsolute: Bool
    let reloadToken: Int
    var externalAudioURL: URL? = nil
    var externalAudioOffsetMS: Int = 0

    final class Coordinator {
        let player = VLCMediaPlayer()
        var currentURL: URL?
        var lastSeekSerial: Int = 0
        var lastReloadToken: Int = -1
        var currentStartTimeSeconds: Double = 0
        var currentExternalAudioURL: URL?
        var currentExternalAudioOffsetMS: Int = 0
    }

    final class VLCView: UIView {}

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> VLCView {
        let view = VLCView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        configure(view: view, coordinator: context.coordinator)
        return view
    }

    func updateUIView(_ view: VLCView, context: Context) {
        configure(view: view, coordinator: context.coordinator)
    }

    private func configure(view: VLCView, coordinator: Coordinator) {
        // v129: Always attach the drawable before playback. Without this, TVVLCKit can start
        // decoding audio before the tvOS UIView is attached, causing black video until VLC is
        // selected manually.
        coordinator.player.drawable = view

        let shouldReload = coordinator.currentURL != url || coordinator.lastReloadToken != reloadToken
        if shouldReload {
            coordinator.currentURL = url
            coordinator.lastReloadToken = reloadToken
            coordinator.lastSeekSerial = seekSerial
            coordinator.player.stop()
            coordinator.player.drawable = view

            let media = VLCMedia(url: url)
            media.addOptions([
                "network-caching": "1200",
                "file-caching": "1200",
                "live-caching": "900",
                "http-reconnect": "1",
                "audio-language": "eng,en",
                "sub-language": "",
                "no-spu": "1",
                "drop-late-frames": "1",
                "skip-frames": "1",
                "clock-jitter": "0",
                "clock-synchro": "1"
            ])
            coordinator.player.media = media

            if shouldPlay {
                coordinator.player.play()
                for delay in [0.20, 0.85, 1.80] {
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                        coordinator.player.drawable = view
                        if coordinator.currentURL == url && !coordinator.player.isPlaying {
                            coordinator.player.play()
                        }
                    }
                }
            }
        }

        if seekSerial != coordinator.lastSeekSerial {
            coordinator.lastSeekSerial = seekSerial
            let target = max(0, coordinator.player.time.intValue + Int32(seekSeconds * 1000.0))
            coordinator.player.time = VLCTime(int: target)
        }

        if shouldPlay {
            if !coordinator.player.isPlaying {
                coordinator.player.drawable = view
                coordinator.player.play()
            }
        } else {
            if coordinator.player.isPlaying { coordinator.player.pause() }
        }
    }

    static func dismantleUIView(_ uiView: VLCView, coordinator: Coordinator) {
        coordinator.player.stop()
    }
}
#endif


// v106: AVPlayerViewController-backed surface used only as a rendering container.
// Apple transport controls remain disabled; Debrid Channels draws its own overlay.
// resizeAspect is the default so video keeps the source aspect ratio and does not crop/stretch.
struct AVPlayerControllerSurface: UIViewControllerRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if controller.player !== player {
            controller.player = player
        }
        controller.showsPlaybackControls = false
        controller.videoGravity = videoGravity
        controller.view.backgroundColor = .black
    }

    static func dismantleUIViewController(_ controller: AVPlayerViewController, coordinator: ()) {
        controller.player = nil
    }
}

// DEBRID_CHANNELS_TVOS_BUILD_V160_VOD_UI_ARTWORK_CONTROLS_CAREFUL
