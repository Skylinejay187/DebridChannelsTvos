# Debrid Channels tvOS v89 Compile Target Cleanup

Upload this ZIP to the GitHub repository root and run the existing `00 Build tvOS IPA From Source ZIP - UNIVERSAL DEVICE BUILD` workflow.

## What changed in v89

- Fixed the exit code 65 target pollution issue from v88.
- Removed architecture/audit/version Swift files from the app compile target.
- Moved those files to `DebridChannelsTVOS/Docs/` as non-compiling markdown references.
- Locked `project.yml` to compile only the real app source files:
  - `Sources/CatalogStore.swift`
  - `Sources/DebridChannelsTVOSApp.swift`
  - `Sources/RemoteImageFit.swift`
- Preserved v73 visual baseline and v88 interaction/runtime changes.

## Build marker

`DEBRID_CHANNELS_TVOS_BUILD_V89_COMPILE_TARGET_CLEANUP`


Build marker: DEBRID_CHANNELS_TVOS_BUILD_V90_COMPILE_FIX
