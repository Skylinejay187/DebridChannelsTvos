# vBRDC359 — Direct Preview Trailers + Preview Mirror Chrome Fix

Version: 1.0.1061 (1061)
Base: vBRDC358B only.

Changes:
- Focused catalog previews now try the same app-native Trailerio/YouTube Innertube direct resolver as the full Trailer action before direct metadata and legacy backend fallback.
- Native trailer resolver memory TTL increased from 30 minutes to 60 minutes.
- Preview Mirror catalog overlays no longer inherit the Live TV persistent top navigation/search/clock chrome.
- Hidden-top-menu guidance is temporary: it disappears immediately when the top menu is revealed and automatically after 15 seconds while hidden.
- Preview Mirror UP NEXT moved from the upper-left header to the footer beside NOW ON AIR.
- Existing AetherEngine playback architecture and Live TV grid navigation remain unchanged.
