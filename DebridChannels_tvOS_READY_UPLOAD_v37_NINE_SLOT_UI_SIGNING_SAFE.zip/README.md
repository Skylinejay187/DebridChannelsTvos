# Debrid Channels tvOS v37

Ready-to-upload GitHub repo package.

- Uses v14-compatible IPA packaging structure for Signulous compatibility.
- Native tvOS SwiftUI app.
- 9-card fixed layout: one large focused card on the left, eight queue cards on the right.
- Menu bar is clickable/focusable.
- Stremio manifest catalog loading remains in Settings.

Upload the contents of this repo package to GitHub and run:

`00 Build tvOS IPA From Source ZIP`

Download the artifact ZIP, extract it, then upload only:

`DebridChannelsTVOS_v37_UPLOAD_THIS_IPA.ipa`
