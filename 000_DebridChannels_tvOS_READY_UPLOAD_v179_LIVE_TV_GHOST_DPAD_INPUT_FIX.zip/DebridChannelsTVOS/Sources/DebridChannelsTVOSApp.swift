import SwiftUI
import AVKit
import Combine
import UIKit

@main
struct DebridChannelsTVOSApp: App {
    @StateObject private var store = CatalogStore()
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
        }
    }
}

struct CinematicAmbientBackground: View {
    // v85: the old center-heavy SwiftUI smoke/timeline background is no longer used in active screens.
    // This keeps the same cinematic style, but renders as a lightweight full-screen CALayer effect.
    var body: some View {
        ZStack {
            Color.black
            LightweightCinematicBackground()
        }
    }
}

struct AmbientEffectsLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            RadialGradient(
                colors: [Color.cyan.opacity(drift ? 0.20 : 0.09), Color.blue.opacity(0.05), Color.clear],
                center: drift ? .topTrailing : .bottomLeading,
                startRadius: 40,
                endRadius: 980
            )
            .scaleEffect(drift ? 1.18 : 1.0)
            .blur(radius: 18)

            RadialGradient(
                colors: [Color.white.opacity(0.065), Color.gray.opacity(0.025), Color.clear],
                center: drift ? .bottomTrailing : .topLeading,
                startRadius: 30,
                endRadius: 760
            )
            .offset(x: drift ? -80 : 70, y: drift ? 36 : -30)
            .blur(radius: 34)

            LinearGradient(
                colors: [Color.black.opacity(0.40), Color.clear, Color.black.opacity(0.68)],
                startPoint: .top,
                endPoint: .bottom
            )

            SmokeLayer(drift: drift)
                .opacity(1.0)

            DenseSmokeLayer(drift: drift)
                .opacity(1.0)

            ExtraVisibleSmokeLayer(drift: drift)
                .opacity(1.0)
        }
    }
}

struct SmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Ellipse()
                    .fill(Color.white.opacity(0.030))
                    .frame(width: CGFloat(300 + i * 95), height: CGFloat(92 + i * 31))
                    .blur(radius: CGFloat(36 + i * 5))
                    .rotationEffect(.degrees(Double(i * 11) + (drift ? 5 : -5)))
                    .offset(
                        x: CGFloat(i * 160 - 420) + (drift ? CGFloat(45 - i * 12) : CGFloat(-20 + i * 10)),
                        y: CGFloat(i * 54 - 130) + (drift ? CGFloat(20 - i * 4) : CGFloat(-12 + i * 2))
                    )
            }
        }
    }
}


struct DenseSmokeLayer: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<6, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.cyan.opacity(0.055), Color.white.opacity(0.070), Color.blue.opacity(0.032), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(420 + i * 70), height: CGFloat(80 + i * 16))
                    .blur(radius: CGFloat(22 + i * 2))
                    .rotationEffect(.degrees(Double(-18 + i * 7) + (drift ? 8 : -8)))
                    .offset(
                        x: CGFloat(i * 130 - 520) + (drift ? CGFloat(90 - i * 10) : CGFloat(-70 + i * 8)),
                        y: CGFloat(i * 62 - 220) + (drift ? CGFloat(38 - i * 3) : CGFloat(-30 + i * 2))
                    )
            }
        }
        .blendMode(.screen)
    }
}



struct ExtraVisibleSmokeLayer: View {
    let drift: Bool

    var body: some View {
        TimelineView(.animation) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate
            ZStack {
                ForEach(0..<11, id: \.self) { i in
                    let phase = t * (0.030 + Double(i) * 0.0025) + Double(i) * 0.74
                    let wideX = CGFloat(sin(phase)) * CGFloat(360 + i * 18)
                    let wideY = CGFloat(cos(phase * 0.67)) * CGFloat(160 + i * 9)
                    Ellipse()
                        .fill(LinearGradient(
                            colors: [Color.white.opacity(0.16), Color.cyan.opacity(0.13), Color.gray.opacity(0.09), Color.clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        ))
                        .frame(width: CGFloat(560 + i * 115), height: CGFloat(118 + i * 24))
                        .blur(radius: CGFloat(24 + i * 3))
                        .rotationEffect(.degrees(Double(i * 13) + sin(phase * 0.45) * 22.0))
                        .offset(
                            x: CGFloat(i * 135 - 690) + wideX,
                            y: CGFloat(i * 58 - 300) + wideY
                        )
                }
            }
        }
        .blendMode(.screen)
    }
}



struct FocusedSmokeOverlay: View {
    let drift: Bool

    var body: some View {
        ZStack {
            ForEach(0..<7, id: \.self) { i in
                Capsule()
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.115), Color.cyan.opacity(0.07), Color.gray.opacity(0.06), Color.clear],
                        startPoint: .leading,
                        endPoint: .trailing
                    ))
                    .frame(width: CGFloat(520 + i * 100), height: CGFloat(84 + i * 18))
                    .blur(radius: CGFloat(28 + i * 3))
                    .rotationEffect(.degrees(Double(-16 + i * 8) + (drift ? 10 : -10)))
                    .offset(
                        x: CGFloat(i * 150 - 520) + (drift ? CGFloat(95 - i * 10) : CGFloat(-80 + i * 8)),
                        y: CGFloat(i * 68 - 210) + (drift ? CGFloat(44 - i * 4) : CGFloat(-34 + i * 3))
                    )
            }
        }
        .blendMode(.screen)
        .opacity(0.95)
    }
}

struct HomeArtworkBackground: View {
    let item: MediaItem

    private var backgroundURL: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            Color.black
            RemoteImageFit(url: backgroundURL, mode: .fill)
                .ignoresSafeArea()
                .scaleEffect(1.01)
                .opacity(0.86)
                .saturation(1.08)
                .contrast(1.04)
            // Keep the home readable without blurring or washing out the selected artwork.
            LinearGradient(
                colors: [Color.black.opacity(0.58), Color.black.opacity(0.28), Color.black.opacity(0.72)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        }
        .ignoresSafeArea()
    }
}


struct PreviewAwareHomeBackground: View {
    let item: MediaItem
    let previewActive: Bool

    var body: some View {
        ZStack {
            // v80: keep the approved ambient/smoke background visible by default.
            // The focused artwork is not used as the static home background anymore.
            Color.clear
            if previewActive, let preview = item.previewURL, let url = URL(string: preview) {
                SilentVideoBackground(url: url)
                    .ignoresSafeArea()
                    .opacity(0.94)
                    .overlay(Color.black.opacity(0.30))
                    .transition(.opacity.animation(.easeInOut(duration: 0.35)))
            }
        }
        .ignoresSafeArea()
    }
}

struct SilentVideoBackground: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> AVPlayerViewController {
        let controller = AVPlayerViewController()
        let player = AVPlayer(url: url)
        player.isMuted = true
        controller.player = player
        controller.showsPlaybackControls = false
        controller.videoGravity = .resizeAspectFill
        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player.currentItem,
            queue: .main
        ) { _ in
            player.seek(to: .zero)
            player.play()
        }
        player.play()
        return controller
    }

    func updateUIViewController(_ controller: AVPlayerViewController, context: Context) {
        if let current = controller.player?.currentItem?.asset as? AVURLAsset, current.url == url {
            controller.player?.play()
        } else {
            let player = AVPlayer(url: url)
            player.isMuted = true
            controller.player = player
            player.play()
        }
    }
}

struct RootView: View {
    @EnvironmentObject var store: CatalogStore

    var body: some View {
        ZStack(alignment: .top) {
            switch store.selectedTab {
            case .home:
                NineSlotHome(filter: nil)
            case .movies:
                NineSlotHome(filter: "movie")
            case .shows:
                NineSlotHome(filter: "series")
            case .live:
                LiveTVScreen()
            case .settings:
                SettingsScreen()
            }

            if let detail = store.selectedDetail {
                DetailPage(item: detail)
                    .zIndex(2000)
            }

            if store.playbackURL == nil {
                TopMenuBar()
                    .zIndex(6000)
            }

            if let url = store.playbackURL, let item = store.playbackItem {
                VODPlayerScreen(item: item, url: url)
                    .id(url.absoluteString)
                    .zIndex(9000)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .ignoresSafeArea(.all)
        .onAppear { print("DEBRID_CHANNELS_TVOS_BUILD_V166_COMPILE_FIX_LIVE_TV_NATIVE_SOURCES") }
    }
}

struct TopMenuBar: View {
    @EnvironmentObject var store: CatalogStore
    @FocusState private var focusedTab: AppTab?
    @FocusState private var searchFocused: Bool

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                HStack(spacing: 48) {
                    ForEach(AppTab.allCases) { tab in
                        Button {
                            withAnimation(.spring(response: 0.36, dampingFraction: 0.82)) {
                                store.selectedTab = tab
                                store.selectedDetail = nil
                                store.detailBackStack.removeAll()
                            }
                        } label: {
                            VStack(spacing: 7) {
                                Text(tab.rawValue)
                                    .font(.system(size: 27, weight: .heavy, design: .serif))
                                    .tracking(1.8)
                                    .foregroundStyle(store.selectedTab == tab ? Color.white : Color.white.opacity(0.70))
                                Capsule()
                                    .fill(store.selectedTab == tab ? Color.cyan : Color.clear)
                                    .frame(width: tab.rawValue.count > 6 ? 78 : 54, height: 5)
                            }
                            .scaleEffect(focusedTab == tab ? 1.10 : 1.0)
                            .shadow(color: focusedTab == tab ? .cyan.opacity(0.85) : .clear, radius: 16)
                        }
                        .buttonStyle(.plain)
                        .focused($focusedTab, equals: tab)
                    }
                }
                .position(x: geo.size.width * 0.50, y: 58)
                .focusSection()

                Button {
                    store.status = "Search selected. Global top-menu focus is live; full typed search screen can be expanded without changing the v73 layout."
                } label: {
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(searchFocused ? Color.cyan : Color.white.opacity(0.94))
                        .scaleEffect(searchFocused ? 1.18 : 1.0)
                        .shadow(color: searchFocused ? .cyan.opacity(0.8) : .clear, radius: 16)
                }
                .buttonStyle(.plain)
                .focused($searchFocused)
                // Search sits alone on the far right, matching the approved reference.
                .position(x: geo.size.width - max(64, geo.size.width * 0.055), y: 58)
            }
            .frame(width: geo.size.width, height: 124, alignment: .top)
        }
        .frame(height: 136)
        .padding(.top, 16)
        .background(
            LinearGradient(
                colors: [Color.black.opacity(0.94), Color.black.opacity(0.72), Color.black.opacity(0.20), Color.clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .top)
        )
        .zIndex(6000)
        .focusSection()
        .onChange(of: store.menuFocusToken) { _ in
            focusedTab = store.selectedTab
            searchFocused = false
        }
    }
}

struct NineSlotHome: View {
    @EnvironmentObject var store: CatalogStore
    let filter: String?
    @State private var rowIndex = 0
    @State private var selectedIndex = 0
    @State private var previewReady = false
    @State private var lastMoveAt: TimeInterval = 0
    @State private var lastOpenAt: TimeInterval = 0
    @FocusState private var isCanvasFocused: Bool

    var activeRows: [MediaRow] {
        let rows = store.rows
        guard let filter else { return rows }
        return rows.map { row in
            MediaRow(id: row.id, title: row.title, items: row.items.filter { $0.type.lowercased().contains(filter) })
        }.filter { !$0.items.isEmpty }
    }

    var currentRow: MediaRow {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        return rows[min(rowIndex, rows.count - 1)]
    }

    var items: [MediaItem] {
        currentRow.items.isEmpty ? CatalogStore.demoRows()[0].items : currentRow.items
    }

    var focused: MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        return items[normalized(selectedIndex)]
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                Color.black.ignoresSafeArea()

                // Full-screen cinematic card board. The focused item is the large left card;
                // all logo/metadata/info is INSIDE that card, matching the reference layout.
                NineSlotDeck(items: items, selectedIndex: selectedIndex, rowTitle: currentRow.title, previewReady: previewReady)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()

            }
            .contentShape(Rectangle())
            .focusable(true)
            .focused($isCanvasFocused)
            .onAppear { isCanvasFocused = true }
            .onTapGesture { openFocusedDebounced() }
            .onPlayPauseCommand { openFocusedDebounced() }
            .task(id: focused.id) {
                previewReady = false
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                if !Task.isCancelled { previewReady = true }
            }
            .onMoveCommand { direction in
                guard allowMove() else { return }
                switch direction {
                case .right:
                    nextItem()
                case .left:
                    previousItem()
                case .down:
                    nextRow()
                case .up:
                    if rowIndex > 0 { previousRow() } else { store.menuFocusToken += 1; isCanvasFocused = false }
                default:
                    break
                }
            }
        }
    }

    func allowMove() -> Bool {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastMoveAt > 0.16 else { return false }
        lastMoveAt = now
        return true
    }

    func openFocusedDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastOpenAt > 0.42 else { return }
        lastOpenAt = now
        store.openDetail(focused, pushCurrent: false)
    }

    func normalized(_ value: Int) -> Int {
        guard !items.isEmpty else { return 0 }
        return (value % items.count + items.count) % items.count
    }

    func nextItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.44, dampingFraction: 0.88, blendDuration: 0.06)) {
            selectedIndex = normalized(selectedIndex + 1)
        }
    }

    func previousItem() {
        guard !items.isEmpty else { return }
        withAnimation(.spring(response: 0.44, dampingFraction: 0.88, blendDuration: 0.06)) {
            selectedIndex = normalized(selectedIndex - 1)
        }
    }

    func nextRow() {
        let rows = activeRows.isEmpty ? CatalogStore.demoRows() : activeRows
        guard rows.count > 1 else { return }
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = min(rowIndex + 1, rows.count - 1)
            selectedIndex = 0
        }
    }

    func previousRow() {
        withAnimation(.spring(response: 0.50, dampingFraction: 0.86)) {
            rowIndex = max(rowIndex - 1, 0)
            selectedIndex = 0
        }
    }
}


struct NineSlotDeck: View {
    let items: [MediaItem]
    let selectedIndex: Int
    let rowTitle: String
    let previewReady: Bool
    @State private var pulse = false
    @State private var idleMotion = false
    @State private var bgDrift = false

    // v66 SHAPED SNAP GRID + HOME ARTWORK BACKGROUND:
    // No HStack/VStack flexible sizing is allowed for the main deck.
    // Every card is placed by explicit x/y coordinates from one shared grid.
    // The split line is the exact same y for left and right cards.
    // The left boxes are wider than the poster cells, but their heights are identical
    // to the top/bottom poster rows. Landscape art is clipped inside the fixed frame.
    struct Layout {
        let edge: CGFloat
        let top: CGFloat
        let gap: CGFloat
        let leftW: CGFloat
        let rowH: CGFloat
        let posterW: CGFloat
        let topY: CGFloat
        let bottomY: CGFloat
        let leftX: CGFloat
        let rightStartX: CGFloat
    }

    func layout(in size: CGSize) -> Layout {
        let W = size.width
        let H = size.height

        // v60 uses the approved snap-grid formula:
        // two landscape cards on the left, four portrait cards on the right.
        // All cards share the exact same row height. The left cards are only wider.
        let edge = max(36, min(W, H) * 0.030)
        let top = max(118, H * 0.125)
        let bottom = max(30, H * 0.040)
        let gap = max(16, min(W, H) * 0.016)

        let boardW = W - edge * 2
        let boardH = H - top - bottom

        // A landscape card should be 16:9 and a poster card 2:3.
        // Solve the row height from width AND height, then use the smaller value so
        // nothing can stretch, overflow, or change shape when artwork loads.
        let landscapeAspect: CGFloat = 16.0 / 9.0
        let posterAspect: CGFloat = 2.0 / 3.0
        let rowHFromHeight = (boardH - gap) / 2.0
        let rowHFromWidth = (boardW - gap * 4.0) / (landscapeAspect + posterAspect * 4.0)
        let rowH = max(190, min(rowHFromHeight, rowHFromWidth))

        let leftW = rowH * landscapeAspect
        let posterW = rowH * posterAspect

        // Center the two-row board vertically under the top menu when width becomes
        // the limiting factor on 16:9 screens.
        let usedH = rowH * 2.0 + gap
        let actualTop = top + max(0, (boardH - usedH) / 2.0)

        let topY = actualTop + rowH / 2.0
        let bottomY = actualTop + rowH + gap + rowH / 2.0
        let leftX = edge + leftW / 2.0
        let rightStartX = edge + leftW + gap

        return Layout(edge: edge, top: actualTop, gap: gap, leftW: leftW, rowH: rowH, posterW: posterW, topY: topY, bottomY: bottomY, leftX: leftX, rightStartX: rightStartX)
    }

    var body: some View {
        GeometryReader { geo in
            let L = layout(in: geo.size)

            ZStack(alignment: .topLeading) {
                // Background animation remains underneath; the selected artwork/video is now
                // the visible full-screen layer above it.
                AmbientEffectsLayer(drift: bgDrift)
                    .ignoresSafeArea()
                    .opacity(0.82)

                PreviewAwareHomeBackground(item: itemFor(0), previewActive: previewReady)
                    .id("home-bg-\(itemFor(0).id)-\(previewReady)")
                    .ignoresSafeArea()

                // Visible cinematic smoke now sits ABOVE the focused artwork/video background
                // and below the cards, so the effect stays visible with the selected poster.
                FocusedSmokeOverlay(drift: bgDrift)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
                    .zIndex(20)

                BrandMark(pulse: false)
                    .frame(width: min(geo.size.width * 0.17, 320), height: 74)
                    .position(x: L.edge + min(geo.size.width * 0.17, 320) / 2, y: 48)
                    .zIndex(130)

                // LEFT TOP: fixed-width landscape hero. Same height as every right poster.
                LandscapeHeroCard(item: itemFor(0), rowTitle: rowTitle, pulse: false, previewReady: previewReady)
                    .id("hero-\(itemFor(0).id)")
                    .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .move(edge: .leading).combined(with: .opacity)))
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.topY)
                    .zIndex(70)

                // LEFT BOTTOM: fixed-width Continue Watching. Same size as top-left.
                ContinueWatchingCard(item: itemFor(0), pulse: pulse)
                    .id("continue-\(itemFor(0).id)")
                    .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .move(edge: .leading).combined(with: .opacity)))
                    .frame(width: L.leftW, height: L.rowH)
                    .clipShape(RoundedRectangle(cornerRadius: 28))
                    // v66: Option G focus-float timing; no old snap/card-slide transition.
                    .position(x: L.leftX, y: L.bottomY)
                    .zIndex(65)

                // RIGHT SIDE: 4 x 2 poster grid, explicit coordinates, equal heights.
                ForEach(1...8, id: \.self) { slot in
                    let col = (slot - 1) % 4
                    let row = (slot - 1) / 4
                    let x = L.rightStartX + CGFloat(col) * (L.posterW + L.gap) + L.posterW / 2
                    let y = row == 0 ? L.topY : L.bottomY
                    PosterQueueCard(item: itemFor(slot), idleMotion: idleMotion, slot: slot)
                        .id("poster-\(slot)-\(itemFor(slot).id)")
                        .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .move(edge: .leading).combined(with: .opacity)))
                        .frame(width: L.posterW, height: L.rowH)
                        .clipShape(RoundedRectangle(cornerRadius: 24))
                        // v66: Option G focus-float timing; no old snap/card-slide transition.
                        .position(x: x, y: y)
                        .zIndex(60)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .animation(.spring(response: 0.44, dampingFraction: 0.88, blendDuration: 0.06), value: selectedIndex)
            .clipped()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.35).repeatForever(autoreverses: true)) {
                pulse.toggle()
            }
            withAnimation(.easeInOut(duration: 9.5).repeatForever(autoreverses: true)) {
                bgDrift.toggle()
            }
            // Right-side poster motion is now driven by TimelineView inside each poster,
            // so it never stops or resets when scrolling/focus changes.
        }
    }

    func itemFor(_ slot: Int) -> MediaItem {
        guard !items.isEmpty else { return CatalogStore.demoRows()[0].items[0] }
        let index = (selectedIndex + slot) % items.count
        return items[index]
    }
}

struct BrandMark: View {
    let pulse: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "waveform.path.ecg")
                .font(.system(size: 42, weight: .bold))
                .foregroundStyle(Color.cyan)
                .shadow(color: .cyan.opacity(0.36), radius: 6)
            VStack(alignment: .leading, spacing: -2) {
                Text("DEBRID")
                    .font(.system(size: 32, weight: .black))
                Text("CHANNELS")
                    .font(.system(size: 25, weight: .black))
                    .foregroundStyle(Color.cyan)
                Text("PREMIUM")
                    .font(.system(size: 13, weight: .bold))
                    .tracking(8)
                    .foregroundStyle(.white.opacity(0.68))
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .scaleEffect(1.0)
        .allowsHitTesting(false)
    }
}

struct LandscapeHeroCard: View {
    let item: MediaItem
    let rowTitle: String
    let pulse: Bool
    let previewReady: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            HeroLandscapeArtwork(item: item)
                .overlay(
                    ZStack {
                        LinearGradient(colors: [.black.opacity(0.64), .black.opacity(0.12), .clear], startPoint: .leading, endPoint: .trailing)
                        LinearGradient(colors: [.clear, .black.opacity(0.48)], startPoint: .top, endPoint: .bottom)
                    }
                )

            VStack(alignment: .leading, spacing: 10) {
                HeroLogoText(item: item, pulse: pulse)
                    .id("hero-logo-\(item.id)")
                    .frame(maxWidth: 360, maxHeight: 88, alignment: .leading)
                    .padding(.bottom, 8)

                HStack(spacing: 10) {
                    Text(item.year)
                    Text("•")
                    Text(item.type.capitalized)
                    Text("•")
                    Text(item.catalog.isEmpty ? rowTitle : item.catalog)
                }
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white.opacity(0.93))

                HStack(spacing: 10) {
                    ForEach(item.genres.prefix(2), id: \.self) { genre in
                        Text(genre)
                            .font(.system(size: 13, weight: .bold))
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Capsule().fill(Color.black.opacity(0.42)))
                            .overlay(Capsule().stroke(.white.opacity(0.14), lineWidth: 1))
                    }
                }

                HStack(spacing: 14) {
                    Text("IMDb")
                        .font(.system(size: 16, weight: .black))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(RoundedRectangle(cornerRadius: 6).fill(Color.yellow))
                    Text(item.rating)
                        .font(.system(size: 30, weight: .black))
                        .foregroundStyle(.white)
                }

                Text(item.description)
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.96))
                    .lineLimit(3)
                    .frame(maxWidth: 560, alignment: .leading)
            }
            .padding(.leading, 28)
            .padding(.bottom, 22)
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
        .overlay(
            RoundedRectangle(cornerRadius: 28)
                .stroke(Color.cyan.opacity(0.72), lineWidth: 4)
        )
        .shadow(color: .cyan.opacity(0.40), radius: 20)
    }
}

struct HeroLandscapeArtwork: View {
    let item: MediaItem

    private var url: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [.black, .blue.opacity(0.14)], startPoint: .topLeading, endPoint: .bottomTrailing)
            RemoteImageFit(url: url, mode: .fill)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .compositingGroup()
        }
        .clipped()
    }
}



struct DetailBackdropArtwork: View {
    let item: MediaItem

    private var url: String? {
        if let landscape = item.landscapeURL, !landscape.isEmpty { return landscape }
        if let poster = item.posterURL, !poster.isEmpty { return poster }
        return nil
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                LinearGradient(colors: [.black, .blue.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing)
                // Detail-only backdrop fit path: keep the artwork at true 16:9 presentation,
                // slightly overscan only to remove the visible left-edge seam/artifact seen on projector output.
                RemoteImageFit(url: url, mode: .fill)
                    .frame(width: geo.size.width, height: geo.size.height)
                    .aspectRatio(16.0/9.0, contentMode: .fill)
                    .scaleEffect(1.018)
                    .offset(x: 10)
                    .clipped()
                    .compositingGroup()
                    .drawingGroup(opaque: true, colorMode: .extendedLinear)
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .clipped()
        }
    }
}

struct HeroLogoText: View {
    let item: MediaItem
    let pulse: Bool
    @State private var pulsePhase = false

    var body: some View {
        Group {
            if let logo = item.logoURL, !logo.isEmpty {
                RemoteImageFit(url: logo, mode: .fit)
            } else {
                Text(item.title.uppercased())
                    .font(.system(size: item.title.count > 13 ? 40 : 58, weight: .black, design: .rounded))
                    .italic()
                    .minimumScaleFactor(0.38)
                    .lineLimit(2)
                    .foregroundStyle(LinearGradient(colors: [.white, .cyan, .blue], startPoint: .topLeading, endPoint: .bottomTrailing))
            }
        }
        // v152: blue lighting stays behind themed logos. Home hero and VOD pass
        // pulse=false for a steady glow; ONLY the media-detail logo passes pulse=true.
        .shadow(color: .cyan.opacity(pulse ? (pulsePhase ? 0.86 : 0.48) : 0.48), radius: pulse ? (pulsePhase ? 28 : 13) : 13)
        .shadow(color: .blue.opacity(pulse ? (pulsePhase ? 0.48 : 0.24) : 0.24), radius: pulse ? (pulsePhase ? 48 : 22) : 22)
        .scaleEffect(pulse ? (pulsePhase ? 1.022 : 1.0) : 1.0)
        .onAppear {
            guard pulse else { return }
            withAnimation(.easeInOut(duration: 1.65).repeatForever(autoreverses: true)) {
                pulsePhase = true
            }
        }
        .onChange(of: pulse) { newValue in
            if !newValue { pulsePhase = false }
        }
    }
}


struct ContinueWatchingCard: View {
    let item: MediaItem
    let pulse: Bool

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            // For now this uses landscape artwork as a last-scene preview placeholder.
            // When resume capture is wired, this same card will load the real saved frame thumbnail.
            HeroLandscapeArtwork(item: item)
                .overlay(Color.black.opacity(0.22))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom))

            Image(systemName: "play.circle.fill")
                .font(.system(size: 84, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .shadow(color: .black.opacity(0.85), radius: 8)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)

            VStack(alignment: .leading, spacing: 8) {
                Text("Continue Watching")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(Color.cyan)
                HStack {
                    Text(item.title)
                        .font(.system(size: 20, weight: .bold))
                        .lineLimit(1)
                    Spacer()
                    Text("35m left")
                        .font(.system(size: 18, weight: .bold))
                }
                .foregroundStyle(.white)

                GeometryReader { proxy in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.18))
                        Capsule().fill(Color.cyan).frame(width: proxy.size.width * 0.62)
                    }
                }
                .frame(height: 8)
            }
            .padding(24)
        }
        .clipShape(RoundedRectangle(cornerRadius: 26))
        .overlay(RoundedRectangle(cornerRadius: 26).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .shadow(color: .black.opacity(0.75), radius: 18)
    }
}

struct PosterQueueCard: View {
    let item: MediaItem
    let idleMotion: Bool
    let slot: Int

    var body: some View {
        // v88: right-side poster float/parallax animation removed completely.
        // These cards are now static so focus movement stays stable and lag-free.
        ZStack {
            LinearGradient(colors: [.black, .gray.opacity(0.16)], startPoint: .top, endPoint: .bottom)
            RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fit)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .drawingGroup(opaque: false)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.13), lineWidth: 1))
        .shadow(color: .black.opacity(0.62), radius: 12)
    }
}




struct LightweightCinematicBackground: View {
    // v84: old smoke/timeline/background stacks are deleted from active detail rendering.
    // This is one UIKit-backed CALayer effect, so focus and DPAD movement stay responsive.
    var body: some View {
        FullScreenCinematicLayer()
            .opacity(0.72)
            .blendMode(.screen)
            .allowsHitTesting(false)
    }
}

struct FullScreenCinematicLayer: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = false

        let glow = CAGradientLayer()
        glow.name = "DebridChannelsV85CinematicGlow"
        glow.type = .radial
        glow.colors = [UIColor.cyan.withAlphaComponent(0.22).cgColor, UIColor.blue.withAlphaComponent(0.08).cgColor, UIColor.clear.cgColor]
        glow.locations = [0.0, 0.42, 1.0]
        glow.startPoint = CGPoint(x: 0.12, y: 0.18)
        glow.endPoint = CGPoint(x: 1.0, y: 1.0)
        view.layer.addSublayer(glow)

        let sweep = CAGradientLayer()
        sweep.name = "DebridChannelsV85WideSweep"
        sweep.colors = [UIColor.clear.cgColor, UIColor.white.withAlphaComponent(0.075).cgColor, UIColor.cyan.withAlphaComponent(0.10).cgColor, UIColor.clear.cgColor]
        sweep.locations = [0.0, 0.36, 0.58, 1.0]
        sweep.startPoint = CGPoint(x: -0.25, y: 0.45)
        sweep.endPoint = CGPoint(x: 1.25, y: 0.55)
        view.layer.addSublayer(sweep)

        let move = CABasicAnimation(keyPath: "startPoint")
        move.fromValue = CGPoint(x: -0.28, y: 0.18)
        move.toValue = CGPoint(x: 0.72, y: 0.82)
        move.duration = 13.0
        move.autoreverses = true
        move.repeatCount = .infinity
        move.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        glow.add(move, forKey: "fullScreenGlowMove")

        let sweepMove = CABasicAnimation(keyPath: "transform.translation.x")
        sweepMove.fromValue = -420
        sweepMove.toValue = 420
        sweepMove.duration = 9.5
        sweepMove.autoreverses = true
        sweepMove.repeatCount = .infinity
        sweepMove.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        sweep.add(sweepMove, forKey: "wideSweepMove")
        return view
    }

    func updateUIView(_ view: UIView, context: Context) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        for layer in view.layer.sublayers ?? [] {
            layer.frame = view.bounds.insetBy(dx: -view.bounds.width * 0.18, dy: -view.bounds.height * 0.18)
        }
        CATransaction.commit()
    }
}

struct DetailPage: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var canvasFocused: Bool
    @State private var focus: DetailNode = .play
    @State private var trailerPopup = false
    @State private var trailerURL: URL? = nil
    @State private var isFindingLinks = false
    @State private var lastRemoteActionAt: TimeInterval = 0
    @State private var linkWindowStart: Int = 0

    enum DetailNode: Hashable {
        case play, trailer, findLinks, close, searchLinks
        case stream(Int)
        case related(Int)
    }

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != item.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(item.genres))) }
        let fallback = all.filter { $0.id != item.id }
        return Array((sameGenre.isEmpty ? fallback : sameGenre).prefix(8))
    }

    let maxVisibleStreamLinks = 6

    var visibleLinks: [StreamLink] {
        Array(store.streamLinks.dropFirst(linkWindowStart).prefix(maxVisibleStreamLinks))
    }

    var body: some View {
        ZStack(alignment: .topLeading) {
            DetailBackdropArtwork(item: item)
                .ignoresSafeArea()
                .overlay(Color.black.opacity(0.28))
                .overlay(LinearGradient(colors: [.black.opacity(0.78), .black.opacity(0.20), .black.opacity(0.62)], startPoint: .leading, endPoint: .trailing))
                .overlay(LinearGradient(colors: [.clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom))

            LightweightCinematicBackground()
                .ignoresSafeArea()
                .allowsHitTesting(false)

            VStack(alignment: .leading, spacing: 24) {
                Spacer().frame(height: 250)

                // v152: media-information/detail section is the ONLY place where the themed logo pulses.
                HeroLogoText(item: item, pulse: true)
                    .frame(width: 780, height: 132, alignment: .leading)
                    .padding(.leading, 84)

                HStack(spacing: 30) {
                    Text(item.genres.first?.uppercased() ?? item.type.uppercased())
                    Text(item.year)
                    Text(item.type.uppercased())
                    Text("152min")
                    Text("🍅 80%")
                    Text("🍿 82%")
                    Text("★ \(item.rating)")
                }
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white.opacity(0.86))
                .padding(.leading, 84)

                HStack(spacing: 22) {
                    ManualDetailButton(title: "▶ PLAY", selected: focus == .play)
                    ManualDetailButton(title: "TRAILER", selected: focus == .trailer)
                    ManualDetailButton(title: isFindingLinks ? "FINDING..." : "FIND LINKS", selected: focus == .findLinks)
                    ManualDetailButton(title: "CLOSE", selected: focus == .close)
                }
                .padding(.leading, 84)

                Text(store.lastStreamMessage.isEmpty ? "Trailers and stream links appear here when the selected metadata source provides direct URLs." : store.lastStreamMessage)
                    .font(.system(size: 20, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .padding(.leading, 84)
                    .frame(width: 980, alignment: .leading)

                ManualStreamLinksRow(focus: focus, visibleLinks: visibleLinks, linkWindowStart: linkWindowStart, totalLinkCount: store.streamLinks.count)
                    .padding(.leading, 84)

                Spacer()

                VStack(alignment: .leading, spacing: 18) {
                    Text("More Like This")
                        .font(.system(size: 34, weight: .black))
                    ManualRelatedRow(focus: focus, relatedItems: relatedItems)
                }
                .foregroundStyle(.white)
                .padding(.leading, 84)
                .padding(.bottom, 46)
            }

            VStack(alignment: .leading, spacing: 14) {
                Text(item.description)
                    .font(.system(size: 16, weight: .semibold))
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                    .foregroundStyle(.white.opacity(0.94))
                Text("Directors: Metadata source / backend credits")
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
                Text("Stars: Actor information appears here when credits metadata is available")
                    .lineLimit(nil)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .font(.system(size: 14, weight: .medium))
            .foregroundStyle(.white.opacity(0.80))
            .padding(16)
            .frame(width: 430, alignment: .leading)
            .frame(minHeight: 248, alignment: .leading)
            .background(.ultraThinMaterial.opacity(0.46), in: RoundedRectangle(cornerRadius: 24))
            .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.14), lineWidth: 1))
            // v160: mathematically pinned beside the stream-link arrow area, moved a half-inch right from v159.
            .position(x: 1238, y: 622)

            if trailerPopup, let trailerURL {
                TrailerPopup(url: trailerURL) {
                    trailerPopup = false
                    self.trailerURL = nil
                    canvasFocused = true
                }
                .zIndex(10)
            }
        }
        .focusable(true)
        .focused($canvasFocused)
        .onAppear { canvasFocused = true; focus = .play }
        .onTapGesture { activateFocusedNodeDebounced() }
        .onPlayPauseCommand { activateFocusedNodeDebounced() }
        .onMoveCommand { direction in route(direction) }
        .task(id: item.id) {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            guard !Task.isCancelled else { return }
            // v84 keeps auto-preview opt-in and non-blocking. It no longer steals focus.
            if let url = store.directPreviewURL(for: item), !trailerPopup {
                trailerURL = url
            }
        }
        .onExitCommand {
            if trailerPopup { trailerPopup = false } else { store.closeDetail() }
        }
    }

    private func route(_ direction: MoveCommandDirection) {
        switch direction {
        case .up:
            switch focus {
            case .play, .trailer, .findLinks, .close:
                store.menuFocusToken += 1
                canvasFocused = false
            case .searchLinks, .stream:
                focus = .play
            case .related:
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(linkWindowStart)
            }
        case .down:
            switch focus {
            case .play, .trailer, .findLinks, .close:
                focus = .searchLinks
            case .searchLinks, .stream:
                focus = .related(0)
            case .related:
                break
            }
        case .left:
            switch focus {
            case .play: break
            case .trailer: focus = .play
            case .findLinks: focus = .trailer
            case .close: focus = .findLinks
            case .searchLinks: focus = .close
            case .stream(let index):
                if index <= 0 { focus = .searchLinks } else {
                    let previous = index - 1
                    focus = .stream(previous)
                    ensureLinkVisible(previous)
                }
            case .related(let index): focus = .related(max(0, index - 1))
            }
        case .right:
            switch focus {
            case .play: focus = .trailer
            case .trailer: focus = .findLinks
            case .findLinks: focus = .close
            case .close: focus = .searchLinks
            case .searchLinks:
                if !store.streamLinks.isEmpty {
                    ensureLinkVisible(linkWindowStart)
                    focus = .stream(linkWindowStart)
                }
            case .stream(let index):
                let next = min(max(store.streamLinks.count - 1, 0), index + 1)
                focus = .stream(next)
                ensureLinkVisible(next)
            case .related(let index): focus = .related(min(max(relatedItems.count - 1, 0), index + 1))
            }
        default:
            break
        }
    }

    private func ensureLinkVisible(_ absoluteIndex: Int) {
        guard !store.streamLinks.isEmpty else { linkWindowStart = 0; return }
        let clamped = min(max(absoluteIndex, 0), store.streamLinks.count - 1)
        if clamped < linkWindowStart {
            linkWindowStart = clamped
        } else if clamped >= linkWindowStart + maxVisibleStreamLinks {
            linkWindowStart = max(0, clamped - maxVisibleStreamLinks + 1)
        }
    }

    private func activateFocusedNodeDebounced() {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastRemoteActionAt > 0.38 else { return }
        lastRemoteActionAt = now
        activateFocusedNode()
    }

    private func activateFocusedNode() {
        switch focus {
        case .play:
            Task {
                isFindingLinks = true
                await store.playFirstDirectStream(for: item)
                isFindingLinks = false
            }
        case .trailer:
            if let url = store.directPreviewURL(for: item) ?? trailerURL {
                trailerURL = url
                trailerPopup = true
            } else {
                store.status = "No direct playable trailer URL was provided. YouTube trailer IDs need backend conversion before AVPlayer can play them."
            }
        case .findLinks, .searchLinks:
            Task {
                isFindingLinks = true
                _ = await store.findStreams(for: item)
                isFindingLinks = false
                linkWindowStart = 0
                focus = store.streamLinks.isEmpty ? .searchLinks : .stream(0)
            }
        case .close:
            store.closeDetail()
        case .stream(let index):
            guard store.streamLinks.indices.contains(index) else { return }
            ensureLinkVisible(index)
            let link = store.streamLinks[index]
            if link.isDirectPlayable, let url = CatalogStore.makePlayableURL(from: link.url) {
                store.startPlayback(item: item, url: url, alternates: store.playableURLs(from: store.streamLinks, selected: link), subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive fallback is armed across all direct playable links.")
            } else {
                store.status = "This link is not direct-playable yet. A resolver/backend is needed for magnet/infoHash/debrid-only links."
            }
        case .related(let index):
            guard relatedItems.indices.contains(index) else { return }
            store.openDetail(relatedItems[index], pushCurrent: true)
        }
    }
}

struct ManualDetailButton: View {
    let title: String
    let selected: Bool
    var body: some View {
        Text(title)
            .font(.system(size: 26, weight: .black))
            .foregroundStyle(selected ? Color.black : Color.white)
            .padding(.horizontal, 34)
            .padding(.vertical, 18)
            .background(RoundedRectangle(cornerRadius: 18).fill(selected ? Color.cyan.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color.white.opacity(0.80) : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
            .scaleEffect(selected ? 1.075 : 1.0)
            .shadow(color: selected ? .cyan.opacity(0.65) : .clear, radius: 18)
    }
}

struct ManualStreamLinksRow: View {
    let focus: DetailPage.DetailNode
    let visibleLinks: [StreamLink]
    let linkWindowStart: Int
    let totalLinkCount: Int

    var rangeText: String? {
        guard totalLinkCount > 0 else { return nil }
        let first = min(linkWindowStart + 1, totalLinkCount)
        let last = min(linkWindowStart + visibleLinks.count, totalLinkCount)
        return "\(first)-\(last) of \(totalLinkCount)"
    }

    var body: some View {
        HStack(spacing: 14) {
            ManualLinkChip(title: "Search Links", subtitle: rangeText, selected: focus == .searchLinks, playable: true)

            if linkWindowStart > 0 {
                Text("‹")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }

            ForEach(Array(visibleLinks.enumerated()), id: \.element.id) { offset, link in
                let absoluteIndex = linkWindowStart + offset
                ManualLinkChip(title: link.quality, subtitle: link.size, selected: focus == .stream(absoluteIndex), playable: link.isDirectPlayable)
            }

            if linkWindowStart + visibleLinks.count < totalLinkCount {
                Text("›")
                    .font(.system(size: 42, weight: .black))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(width: 24)
            }
        }
        .frame(width: 1460, alignment: .leading)
    }
}

struct ManualLinkChip: View {
    let title: String
    let subtitle: String?
    let selected: Bool
    let playable: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title).font(.system(size: subtitle == nil ? 20 : 18, weight: .black))
            if let subtitle { Text(subtitle).font(.system(size: 13, weight: .semibold)).opacity(0.78) }
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 22)
        .padding(.vertical, subtitle == nil ? 12 : 11)
        .background(RoundedRectangle(cornerRadius: 14).fill(selected ? Color.orange.opacity(0.76) : Color.white.opacity(playable ? 0.16 : 0.07)))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(selected ? Color.orange : Color.white.opacity(0.18), lineWidth: selected ? 3 : 1))
        .scaleEffect(selected ? 1.06 : 1.0)
    }
}

struct ManualRelatedRow: View {
    let focus: DetailPage.DetailNode
    let relatedItems: [MediaItem]
    var body: some View {
        HStack(spacing: 24) {
            ForEach(Array(relatedItems.enumerated()), id: \.element.id) { index, item in
                let selected = focus == .related(index)
                ZStack(alignment: .bottomLeading) {
                    RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fit)
                    LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                    Text(item.title)
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                        .lineLimit(2)
                        .padding(14)
                }
                .frame(width: 210, height: 310)
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .contentShape(RoundedRectangle(cornerRadius: 20))
                .overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? Color.cyan : Color.white.opacity(0.18), lineWidth: selected ? 4 : 1))
                .scaleEffect(selected ? 1.055 : 1.0)
                .shadow(color: selected ? .cyan.opacity(0.55) : .black.opacity(0.60), radius: selected ? 20 : 12)
            }
        }
    }
}

struct RelatedMoviesRow: View {
    @EnvironmentObject var store: CatalogStore
    let current: MediaItem
    @FocusState private var focusedID: String?

    var relatedItems: [MediaItem] {
        let allRows = store.rows.isEmpty ? CatalogStore.demoRows() : store.rows
        let all = allRows.flatMap { $0.items }
        let sameGenre = all.filter { $0.id != current.id && (!$0.genres.isEmpty && !Set($0.genres).isDisjoint(with: Set(current.genres))) }
        let fallback = all.filter { $0.id != current.id }
        let chosen = sameGenre.isEmpty ? fallback : sameGenre
        return Array(chosen.prefix(8))
    }

    var body: some View {
        HStack(spacing: 24) {
            ForEach(relatedItems) { item in
                Button {
                    store.openDetail(item, pushCurrent: true)
                } label: {
                    ZStack(alignment: .bottomLeading) {
                        RemoteImageFit(url: item.posterURL ?? item.landscapeURL, mode: .fill)
                        LinearGradient(colors: [.clear, .black.opacity(0.72)], startPoint: .top, endPoint: .bottom)
                        Text(item.title)
                            .font(.system(size: 19, weight: .black))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                            .padding(14)
                    }
                    .frame(width: 210, height: 310)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .contentShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(focusedID == item.id ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == item.id ? 4 : 1))
                    .scaleEffect(focusedID == item.id ? 1.055 : 1.0)
                    .shadow(color: focusedID == item.id ? .cyan.opacity(0.55) : .black.opacity(0.60), radius: focusedID == item.id ? 20 : 12)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: item.id)
            }
        }
        .focusSection()
        .onAppear { if focusedID == nil { focusedID = relatedItems.first?.id } }
    }
}

struct StreamLinksRow: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    @FocusState private var focusedID: String?

    var visibleLinks: [StreamLink] { Array(store.streamLinks.prefix(20)) }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 14) {
                Button {
                    Task { _ = await store.findStreams(for: item) }
                } label: {
                    Text("Search Links")
                        .font(.system(size: 20, weight: .black))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 22)
                        .padding(.vertical, 12)
                        .background(RoundedRectangle(cornerRadius: 14).fill(focusedID == "search" ? Color.orange.opacity(0.75) : Color.white.opacity(0.12)))
                        .overlay(RoundedRectangle(cornerRadius: 14).stroke(focusedID == "search" ? Color.orange : Color.white.opacity(0.18), lineWidth: focusedID == "search" ? 3 : 1))
                        .scaleEffect(focusedID == "search" ? 1.06 : 1.0)
                }
                .buttonStyle(.plain)
                .focused($focusedID, equals: "search")

                ForEach(visibleLinks) { link in
                    Button {
                        if link.isDirectPlayable, let raw = link.url, let url = URL(string: raw) {
                            let alternates = store.playableURLs(from: store.streamLinks, selected: link)
                            store.startPlayback(item: item, url: url, alternates: alternates, subtitles: store.subtitleURLs(from: link), label: "Opening selected stream: \(link.quality) \(link.size) from \(link.source). Adaptive retry is armed.")
                        } else {
                            store.status = "This link is not direct-playable by AVFoundation. Magnet/infoHash playback needs the planned torrent/libVLC engine or a debrid direct URL."
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(link.quality)
                                .font(.system(size: 18, weight: .heavy))
                            Text(link.size)
                                .font(.system(size: 13, weight: .semibold))
                                .opacity(0.78)
                        }
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 11)
                        .background(RoundedRectangle(cornerRadius: 13).fill(focusedID == link.id.uuidString ? Color.cyan.opacity(0.58) : Color.cyan.opacity(link.isDirectPlayable ? 0.30 : 0.10)))
                        .overlay(RoundedRectangle(cornerRadius: 13).stroke(focusedID == link.id.uuidString ? Color.cyan : Color.white.opacity(0.18), lineWidth: focusedID == link.id.uuidString ? 3 : 1))
                        .scaleEffect(focusedID == link.id.uuidString ? 1.06 : 1.0)
                    }
                    .buttonStyle(.plain)
                    .focused($focusedID, equals: link.id.uuidString)
                }
            }
            .focusSection()
        }
        .frame(width: 1220, alignment: .leading)
        .onAppear { if focusedID == nil { focusedID = "search" } }
    }
}

struct TrailerPopup: View {
    let url: URL
    let close: () -> Void

    var body: some View {
        ZStack {
            Color.black.opacity(0.72).ignoresSafeArea()
            VStack(spacing: 18) {
                SilentVideoBackground(url: url)
                    .frame(width: 1540, height: 720)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .background(Color.black)
                Button("Close Trailer", action: close)
                    .font(.system(size: 26, weight: .bold))
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}


struct VODPlayerScreen: View {
    @EnvironmentObject var store: CatalogStore
    let item: MediaItem
    let url: URL

    @State private var player: AVPlayer? = nil
    @State private var controlsVisible = true
    @State private var isPlaying = true
    @State private var isLoading = true
    @State private var errorText: String? = nil
    @State private var retryText: String? = nil
    @State private var currentSeconds: Double = 0
    @State private var durationSeconds: Double = 0
    @State private var videoGravity: AVLayerVideoGravity = .resizeAspect
    @State private var timeObserver: Any? = nil
    @State private var statusObserver: NSKeyValueObservation? = nil
    @State private var hideTask: Task<Void, Never>? = nil
    @State private var endObserver: NSObjectProtocol? = nil
    @State private var renderWatchdogTask: Task<Void, Never>? = nil
    @State private var nativePrepareTask: Task<Void, Never>? = nil
    @State private var activePanel: PlayerPanel? = nil
    @State private var playbackNotice: String = ""
    @State private var lastPlayerActionAt: TimeInterval = 0
    @State private var lastPlayerMoveAt: TimeInterval = 0
    @State private var forceVLCSurface = false
    @State private var forceKSPlayerSurface = true
    @State private var avRetryAttemptedForCurrentURL = false
    @State private var nativeProfileText: String = ""
    @State private var diagnosticsTick: Int = 0
    @State private var vlcSeekSerial = 0
    @State private var vlcSeekSeconds: Double = 0
    @State private var vlcSurfaceToken: Int = 0
    @FocusState private var focusedControl: PlayerControl?
    @FocusState private var playerCanvasFocused: Bool
    @AppStorage("vodCacheLimitGB") private var vodCacheLimitGB: Int = 10
    @StateObject private var cacheSession = TemporaryVODCacheSession()
    @State private var playbackClockTask: Task<Void, Never>? = nil
    @State private var lastKnownControlFocus: PlayerControl = .playPause

    enum PlayerControl: Hashable { case back10, playPause, forward10, ksplayer, internalVLC, audio, subtitles, episodes, zoom, settings, infuse, vlc, senplayer, close }
    enum PlayerPanel: Hashable { case audio, subtitles, episodes, settings }

    private var activeEngineName: String {
        forceKSPlayerSurface ? "KSPlayer Internal" : "VLC Internal"
    }

    private var progress: Double {
        guard durationSeconds > 0 else { return 0 }
        return min(max(currentSeconds / durationSeconds, 0), 1)
    }

    private var remainingSeconds: Double {
        guard durationSeconds > 0 else { return 0 }
        return max(durationSeconds - currentSeconds, 0)
    }

    private var progressPercentText: String {
        guard durationSeconds > 0 else { return "0%" }
        return "\(Int((progress * 100).rounded()))%"
    }

    private var isLivePlayback: Bool {
        item.type.lowercased() == "live" || store.playbackLinkLabel.localizedCaseInsensitiveContains("Live TV")
    }

    private var activePlaybackURL: URL {
        isLivePlayback ? url : (cacheSession.playbackURL ?? url)
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            UniversalVideoSurface(
                url: activePlaybackURL,
                avPlayer: player,
                videoGravity: videoGravity,
                forceVLC: forceVLCSurface,
                routeHint: store.playbackLinkLabel,
                vlcShouldPlay: isPlaying,
                vlcSeekSerial: vlcSeekSerial,
                vlcSeekSeconds: vlcSeekSeconds,
                vlcSurfaceToken: vlcSurfaceToken,
                ksShouldPlay: isPlaying,
                ksSeekSerial: vlcSeekSerial,
                ksSeekSeconds: vlcSeekSeconds,
                preferKSPlayer: forceKSPlayerSurface
            )
            .ignoresSafeArea()

            if isLoading {
                ZStack {
                    Color.black.opacity(0.30).ignoresSafeArea()
                    DebridMovieLoadingView(message: retryText ?? "Loading movie…")
                }
                .zIndex(30)
            }

            if let errorText {
                ApplePlayerErrorCard(message: errorText) { store.closePlayer() }
                    .zIndex(40)
            }

            // v151: diagnostics are useful, but keeping a diagnostic panel alive over every playing
            // frame adds SwiftUI/compositing work exactly where cadence is most sensitive. Show it while
            // paused/loading/settings are open, not during normal hidden-controls playback.
            if !isPlaying || activePanel == .settings || isLoading || errorText != nil {
                DebridPlaybackDiagnosticsPanel(diagnostics: currentPlaybackDiagnostics())
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                    .padding(.top, 42)
                    .padding(.trailing, 54)
                    .zIndex(12)
                    .transition(.opacity)
            }

            if controlsVisible || !isPlaying || activePanel != nil {
                AppleVODChromeBackground()
                    .ignoresSafeArea()
                    .opacity(isPlaying ? 0.18 : 1.0)
                    .allowsHitTesting(false)
            }

            if let activePanel {
                DebridPlayerPanel(
                    title: panelTitle(activePanel),
                    detail: panelDetail(activePanel),
                    close: { self.activePanel = nil; showControls() }
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .trailing)
                .padding(.trailing, 76)
                .padding(.bottom, 292)
                .zIndex(15)
            }

            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .bottom, spacing: 26) {
                    AppleVODPosterCard(item: item)

                    VStack(alignment: .leading, spacing: 12) {
                        // v152: VOD overlay keeps the themed logo, but it is static only.
                        // No pulse animation, and no extra large title text.
                        HeroLogoText(item: item, pulse: false)
                            .frame(width: 520, height: 82, alignment: .leading)
                            .allowsHitTesting(false)

                        HStack(spacing: 12) {
                            AppleVODBadge(text: activeEngineName, highlighted: true)
                            AppleVODBadge(text: videoGravity == .resizeAspectFill ? "Fill" : "Aspect Fit", highlighted: false)
                            AppleVODBadge(text: item.rating.isEmpty ? "NR" : "★ \(item.rating)", highlighted: false)
                            AppleVODBadge(text: item.year, highlighted: false)
                        }

                        Text("\(item.type.capitalized)  •  \(item.genres.prefix(3).joined(separator: "  •  "))")
                            .font(.system(size: 22, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))

                        Text(item.description)
                            .font(.system(size: 21, weight: .medium, design: .rounded))
                            .lineLimit(2)
                            .foregroundStyle(.white.opacity(0.72))
                            .frame(width: 1040, alignment: .leading)
                    }
                }

                HStack(alignment: .center, spacing: 18) {
                    Text(formatTime(currentSeconds))
                        .font(.system(size: 21, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 86, alignment: .leading)
                    PlayerProgressBar(progress: progress)
                        .frame(width: 1290, height: 14)
                    Text(formatTime(durationSeconds))
                        .font(.system(size: 21, weight: .black, design: .rounded))
                        .monospacedDigit()
                        .frame(width: 96, alignment: .trailing)
                }
                .foregroundStyle(.white.opacity(0.92))

                VODRuntimeProgressSummary(
                    title: item.title,
                    current: formatTime(currentSeconds),
                    total: isLivePlayback ? "LIVE" : formatTime(durationSeconds),
                    remaining: isLivePlayback ? "LIVE" : formatTime(remainingSeconds),
                    percent: isLivePlayback ? "LIVE" : progressPercentText,
                    cacheLabel: isLivePlayback ? "Live TV: cache disabled" : cacheLimitLabel,
                    cacheUsed: isLivePlayback ? "0.00GB" : String(format: "%.2fGB", cacheUsedGB),
                    cacheLimit: isLivePlayback ? "Disabled" : (cacheLimitGBValue == 0 ? "Unlimited" : String(format: "%.0fGB", cacheLimitGBValue))
                )
                .frame(width: 1510, alignment: .leading)

                if !isLivePlayback {
                    VODCacheProgressRow(cacheLabel: cacheLimitLabel, usedGB: cacheUsedGB, limitGB: cacheLimitGBValue, progress: cacheFillProgress, status: cacheSession.statusText)
                        .frame(width: 1510, alignment: .leading)
                }

                HStack(spacing: 12) {
                    PlayerControlButton(title: "−10", focus: .back10, focused: $focusedControl) { playerAction { seek(-10) } }
                    PlayerControlButton(title: isPlaying ? "Pause" : "Play", focus: .playPause, focused: $focusedControl) { playerAction { togglePlay() } }
                    PlayerControlButton(title: "+10", focus: .forward10, focused: $focusedControl) { playerAction { seek(10) } }
                    PlayerControlButton(title: "KS", focus: .ksplayer, focused: $focusedControl) { playerAction { switchToKSPlayerEngine(manual: true) } }
                    PlayerControlButton(title: "VLC", focus: .internalVLC, focused: $focusedControl) { playerAction { switchToVLCEngine(manual: true) } }
                    PlayerControlButton(title: "Audio", focus: .audio, focused: $focusedControl) { playerAction { activePanel = .audio; cycleMedia(groupCharacteristic: .audible, label: "audio") } }
                    PlayerControlButton(title: "Subs", focus: .subtitles, focused: $focusedControl) { playerAction { activePanel = .subtitles; cycleMedia(groupCharacteristic: .legible, label: "subtitle") } }
                    PlayerControlButton(title: "Episodes", focus: .episodes, focused: $focusedControl) { playerAction { activePanel = .episodes; store.status = "Episode selector is wired into the Apple-style VOD overlay and ready for series episode rows."; showControls() } }
                    PlayerControlButton(title: "Zoom", focus: .zoom, focused: $focusedControl) { playerAction { toggleZoom() } }
                    PlayerControlButton(title: "Settings", focus: .settings, focused: $focusedControl) { playerAction { cycleCacheLimit(); activePanel = .settings; store.status = isLivePlayback ? "Live TV cache is disabled; playback uses the direct TS/HLS stream." : "VOD cache set to \(cacheLimitLabel). Settings cycles 5GB / 10GB / Unlimited while keeping controls visible."; forceControlsVisibleForNavigation() } }
                    PlayerControlButton(title: "Infuse", focus: .infuse, focused: $focusedControl) { playerAction { openExternal(.infuse) } }
                    PlayerControlButton(title: "VLC App", focus: .vlc, focused: $focusedControl) { playerAction { openExternal(.vlc) } }
                    PlayerControlButton(title: "Sen", focus: .senplayer, focused: $focusedControl) { playerAction { openExternal(.senPlayer) } }
                    PlayerControlButton(title: "Close", focus: .close, focused: $focusedControl) { playerAction { store.closePlayer() } }
                }
                .focusSection()
            }
            .foregroundStyle(.white)
            .padding(.leading, 68)
            .padding(.bottom, 58)
            .frame(maxWidth: .infinity, alignment: .leading)
            .opacity(controlsVisible ? 1.0 : 0.0)
            .allowsHitTesting(controlsVisible)
            .animation(isPlaying ? nil : .easeInOut(duration: 0.22), value: controlsVisible)
        }
        .focusable(true)
        .focused($playerCanvasFocused)
        .onAppear { playerCanvasFocused = true; setupPlayer(); forceControlsVisibleForNavigation(); focusedControl = .playPause; lastKnownControlFocus = .playPause }
        .onDisappear { teardownPlayer() }
        .onMoveCommand { direction in routePlayerMove(direction) }
        .onTapGesture {
            if !controlsVisible { forceControlsVisibleForNavigation(); focusedControl = lastKnownControlFocus; return }
            if activePanel != nil { activePanel = nil; forceControlsVisibleForNavigation(); return }
            // v162: the player shell owns Select so native tvOS button focus cannot double-advance.
            // D-pad left/right only changes our manual focus value; Select triggers the focused control once.
            activateFocusedPlayerControl()
        }
        .onPlayPauseCommand { playerAction { togglePlay() } }
        .onExitCommand { store.closePlayer() }
    }

    private func activateFocusedPlayerControl() {
        lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        switch focusedControl ?? lastKnownControlFocus {
        case .back10: playerAction { seek(-10) }
        case .playPause: playerAction { togglePlay() }
        case .forward10: playerAction { seek(10) }
        case .ksplayer: playerAction { switchToKSPlayerEngine(manual: true) }
        case .internalVLC: playerAction { switchToVLCEngine(manual: true) }
        case .audio: playerAction { activePanel = .audio; cycleMedia(groupCharacteristic: .audible, label: "audio") }
        case .subtitles: playerAction { activePanel = .subtitles; cycleMedia(groupCharacteristic: .legible, label: "subtitle") }
        case .episodes: playerAction { activePanel = .episodes; store.status = "Episode selector is wired into the Apple-style VOD overlay and ready for series episode rows."; forceControlsVisibleForNavigation() }
        case .zoom: playerAction { toggleZoom() }
        case .settings: playerAction { cycleCacheLimit(); activePanel = .settings; store.status = isLivePlayback ? "Live TV cache is disabled; playback uses the direct TS/HLS stream." : "VOD cache set to \(cacheLimitLabel). Settings cycles 5GB / 10GB / Unlimited while keeping controls visible."; forceControlsVisibleForNavigation() }
        case .infuse: playerAction { openExternal(.infuse) }
        case .vlc: playerAction { openExternal(.vlc) }
        case .senplayer: playerAction { openExternal(.senPlayer) }
        case .close: playerAction { store.closePlayer() }
        }
    }

    private func playerAction(_ action: () -> Void) {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastPlayerActionAt > 0.44 else { return }
        lastPlayerActionAt = now
        action()
    }

    private func routePlayerMove(_ direction: MoveCommandDirection) {
        let now = Date().timeIntervalSinceReferenceDate
        guard now - lastPlayerMoveAt > 0.26 else { return }
        lastPlayerMoveAt = now
        if !controlsVisible {
            forceControlsVisibleForNavigation()
            focusedControl = lastKnownControlFocus
            return
        }
        forceControlsVisibleForNavigation()
        let order: [PlayerControl] = [.back10, .playPause, .forward10, .ksplayer, .internalVLC, .audio, .subtitles, .episodes, .zoom, .settings, .infuse, .vlc, .senplayer, .close]
        let current = focusedControl ?? lastKnownControlFocus
        let idx = order.firstIndex(of: current) ?? 1
        switch direction {
        case .left:
            focusedControl = order[(idx - 1 + order.count) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .right:
            focusedControl = order[(idx + 1) % order.count]
            lastKnownControlFocus = focusedControl ?? lastKnownControlFocus
        case .up, .down:
            focusedControl = current
        default:
            break
        }
    }

    private func panelTitle(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio: return "Audio Tracks"
        case .subtitles: return "Subtitles"
        case .episodes: return "Episodes"
        case .settings: return "Playback Settings"
        }
    }

    private func panelDetail(_ panel: PlayerPanel) -> String {
        switch panel {
        case .audio:
            return "KSPlayer and VLC Internal handle media track selection under the same Debrid overlay. Experimental player code has been fully removed from this build."
        case .subtitles:
            return "Stremio subtitle URLs are captured for the overlay parser path. Subtitles default off and can be enabled from the Debrid overlay when supported by the active engine."
        case .episodes:
            return "Episode routing is connected to the VOD overlay and ready for series rows when the catalog/backend returns episodes."
        case .settings:
            return "Engines: KSPlayer clean video surface is primary, VLC Internal is selectable fallback, and external Infuse/VLC/SenPlayer handoff remains available. v155 repairs VOD control focus to prevent double-skips, reinforces English audio preference, and moves media information right/down while preserving smooth v154 cadence settings. English audio is enforced where tracks expose language metadata and subtitles default off. Cache limit: \(cacheLimitLabel). Current profile: \(nativeProfileText.isEmpty ? "pending" : nativeProfileText)."
        }
    }

    private func currentPlaybackDiagnostics() -> DebridPlaybackDiagnostics {
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        let engine = activeEngineName
        var diag = DebridPlaybackDiagnosticsFactory.make(engine: engine, profile: profile, controlsVisible: controlsVisible, isPlaying: isPlaying)
        if isLoading {
            diag.fps = "Loading"
            diag.droppedFrames = "Pending"
        }
        if !playbackNotice.isEmpty {
            diag.notes = playbackNotice
        }
        _ = diagnosticsTick
        return diag
    }

    private func startDiagnosticsPulse() {
        Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                diagnosticsTick &+= 1
            }
        }
    }

    private func setupPlayer() {
        // v127: AVPlayer remains removed from the VOD decision path.
        // Internal playback uses KSPlayer primary and TVVLCKit/libVLC fallback under the same Debrid overlay.
        nativePrepareTask?.cancel()
        renderWatchdogTask?.cancel()
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        player?.pause()
        player = nil

        forceVLCSurface = false
        forceKSPlayerSurface = true
        avRetryAttemptedForCurrentURL = false
        isLoading = true
        errorText = nil
        retryText = "Preparing player…"
        focusedControl = .playPause
        let profile = UniversalCodecSupport.profile(for: url, hint: store.playbackLinkLabel)
        if isLivePlayback {
            cacheSession.stopAndDelete()
            currentSeconds = 0
            durationSeconds = 0
        } else {
            cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
        }
        nativeProfileText = profile.diagnostic
        if durationSeconds <= 0 { durationSeconds = runtimeSeconds(for: item) }
        currentSeconds = max(currentSeconds, 0)
        startPlayerClock()

        #if canImport(KSPlayer)
        isPlaying = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.1) {
            if errorText == nil { isLoading = false }
        }
        playbackNotice = "KSPlayer internal • English audio preferred • subtitles off • \(profile.diagnostic) • VLC fallback ready"
        store.status = isLivePlayback ? "V179 Live TV playback: ghost DPAD double-click fixed by single-owner focus routing, black-glass guide theme active, direct TS/HLS playback, cache disabled." : "V173 VOD playback: real temp cache proxy active, DPAD focus preserved, KSPlayer primary and VLC fallback ready."
        #elseif canImport(TVVLCKit)
        forceKSPlayerSurface = false
        forceVLCSurface = true
        isPlaying = true
        vlcSurfaceToken += 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.1) {
            if errorText == nil { isLoading = false }
        }
        playbackNotice = "KSPlayer was not compiled; VLC Internal fallback active • \(profile.diagnostic)"
        store.status = "V155 playback fallback: TVVLCKit/libVLC is active because KSPlayer did not compile into this IPA."
        #else
        isPlaying = false
        forceControlsVisibleForNavigation()
        playbackNotice = "KSPlayer did not compile into this IPA and TVVLCKit is not available. External players remain available."
        errorText = "Internal playback needs KSPlayer Raw Layer/FFmpeg or TVVLCKit/libVLC compiled into the IPA. Use external Infuse/VLC/SenPlayer until an internal engine is present."
        store.status = playbackNotice
        #endif
    }

    private func prepareNativeAssetAndStart(url: URL, profile: NativePlaybackProfile) {
        let headers: [String: String] = [
            "User-Agent": "DebridChannels-tvOS/1.0 KSPlayer/VLC",
            "Accept": "video/mp4,video/quicktime,application/vnd.apple.mpegurl,application/x-mpegURL,video/*,application/octet-stream,*/*;q=0.8",
            "Accept-Encoding": "identity",
            "Connection": "keep-alive",
            "Range": "bytes=0-"
        ]
        let options: [String: Any] = ["AVURLAssetHTTPHeaderFieldsKey": headers]
        let asset = AVURLAsset(url: url, options: options)

        nativePrepareTask = Task { @MainActor in
            do {
                // Load the real AVFoundation properties before making the visible player.
                // If these fail, AVPlayer would usually become audio-only/black or stutter.
                let playable = try await asset.load(.isPlayable)
                let tracks = try await asset.load(.tracks)
                let duration = try? await asset.load(.duration)
                let mediaCharacteristics = try? await asset.load(.availableMediaCharacteristicsWithMediaSelectionOptions)
                let videoTracks = tracks.filter { $0.mediaType == .video }
                let audioTracks = tracks.filter { $0.mediaType == .audio }

                guard !Task.isCancelled else { return }
                guard playable else {
                    handleNativePreparationFailure("VLC Internal rejected this asset as not playable before render.")
                    return
                }
                if videoTracks.isEmpty && !profile.isAppleContainer && !profile.isNativeDolbyVisionPreferred {
                    let audioCount = audioTracks.count
                    handleNativePreparationFailure("VLC Internal only exposed audio tracks (\(audioCount)) and no video track before render for \(profile.diagnostic).")
                    return
                }

                let itemAsset = AVPlayerItem(asset: asset)
                itemAsset.preferredForwardBufferDuration = profile.isHLS ? 60 : 180
                itemAsset.canUseNetworkResourcesForLiveStreamingWhilePaused = true
                itemAsset.preferredPeakBitRate = 0
                itemAsset.preferredMaximumResolution = CGSize(width: 4096, height: 2160)
                itemAsset.seekingWaitsForVideoCompositionRendering = true

                let av = AVPlayer(playerItem: itemAsset)
                av.appliesMediaSelectionCriteriaAutomatically = true
                av.automaticallyWaitsToMinimizeStalling = true
                av.preventsDisplaySleepDuringVideoPlayback = true
                av.allowsExternalPlayback = false

                player = av
                let durationText = duration.map { CMTimeGetSeconds($0).isFinite ? "duration \(Int(CMTimeGetSeconds($0)))s" : "duration live/unknown" } ?? "duration pending"
                let characteristicsText = mediaCharacteristics?.map { $0.rawValue }.joined(separator: ",") ?? "characteristics pending"
                playbackNotice = "VLC Internal ready • \(profile.diagnostic) • \(videoTracks.count) video track(s) • no bitrate cap • 4K/DV native path."
                store.status = "VLC Internal validation passed: \(videoTracks.count) video track(s), \(audioTracks.count) audio track(s), \(durationText), \(characteristicsText). Starting hardware playback path."
                attachNativePlayerObservers(item: itemAsset, player: av)
                av.play()
                isPlaying = true
            } catch {
                guard !Task.isCancelled else { return }
                handleNativePreparationFailure("VLC Internal asset preparation failed for \(profile.diagnostic): \(error.localizedDescription)")
            }
        }
    }

    private func handleNativePreparationFailure(_ message: String) {
        isLoading = false
        forceControlsVisibleForNavigation()
        store.status = message
        #if canImport(TVVLCKit)
        if UniversalCodecSupport.vlcCompiledIn {
            retryText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            errorText = message + "\n\nInternal playback uses KSPlayer primary and VLC fallback; use external Infuse if needed."
        } else {
            errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        }
        #else
        errorText = message + "\n\nTVVLCKit is not compiled into this IPA, so only VLC Internal/external players are available."
        #endif
    }

    private func attachNativePlayerObservers(item itemAsset: AVPlayerItem, player av: AVPlayer) {
        statusObserver = itemAsset.observe(\.status, options: [.new, .initial]) { observedItem, _ in
            DispatchQueue.main.async {
                switch observedItem.status {
                case .readyToPlay:
                    isLoading = false
                    durationSeconds = CMTimeGetSeconds(observedItem.duration).isFinite ? CMTimeGetSeconds(observedItem.duration) : 0
                    let dimensions = observedItem.presentationSize
                    let event = observedItem.accessLog()?.events.last
                    let bitrateText = event.map { "observed \(Int($0.observedBitrate))bps / indicated \(Int($0.indicatedBitrate))bps" } ?? "bitrate pending"
                    let sizeText = dimensions.width > 8 ? "\(Int(dimensions.width))×\(Int(dimensions.height))" : "video size pending"
                    playbackNotice = "VLC Internal playing • \(nativeProfileText) • \(sizeText) • \(bitrateText)"
                    store.status = "Playback route: \(activeEngineName); \(nativeProfileText); video size \(sizeText); \(bitrateText); selected \(store.playbackLinkLabel)"
                    av.play()
                    isPlaying = true
                    startRenderWatchdog(for: observedItem, player: av)
                    scheduleAutoHide()
                case .failed:
                    isLoading = false
                    let message = observedItem.error?.localizedDescription ?? "The selected stream could not be played."
                    if let next = store.advanceToNextPlaybackURL(after: url) {
                        retryText = "Stream failed; retrying next source…"
                        errorText = nil
                        store.status = "Playback failed on one source: \(message). Retrying \(next.absoluteString.prefix(80))…"
                    } else {
                        forceControlsVisibleForNavigation()
                        errorText = message + "\nEngine: \(activeEngineName). VLC Internal failed after validated setup; try VLC Internal or external Infuse/VLC/SenPlayer for this stream."
                    }
                default:
                    break
                }
            }
        }

        timeObserver = av.addPeriodicTimeObserver(forInterval: CMTime(seconds: 1.25, preferredTimescale: 600), queue: .main) { time in
            if !forceVLCSurface {
                currentSeconds = CMTimeGetSeconds(time).isFinite ? CMTimeGetSeconds(time) : 0
            }
                if let duration = av.currentItem?.duration {
                let seconds = CMTimeGetSeconds(duration)
                if seconds.isFinite { durationSeconds = seconds }
            }
            if !forceVLCSurface { isPlaying = av.timeControlStatus == .playing }
        }

        endObserver = NotificationCenter.default.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: itemAsset, queue: .main) { _ in
            isPlaying = false
            controlsVisible = true
            focusedControl = .playPause
        }

        if !store.playbackSubtitleURLs.isEmpty {
            store.status = "Captured \(store.playbackSubtitleURLs.count) external subtitle URL(s) from the selected Stremio stream."
        }
    }

    private func teardownPlayer() {
        hideTask?.cancel()
        nativePrepareTask?.cancel()
        nativePrepareTask = nil
        renderWatchdogTask?.cancel()
        playbackClockTask?.cancel()
        playbackClockTask = nil
        if let timeObserver, let player { player.removeTimeObserver(timeObserver) }
        statusObserver?.invalidate()
        if let endObserver { NotificationCenter.default.removeObserver(endObserver) }
        endObserver = nil
        player?.pause()
        player = nil
        cacheSession.stopAndDelete()
    }

    private func openExternal(_ target: ExternalPlaybackTarget) {
        player?.pause()
        isPlaying = false
        forceControlsVisibleForNavigation()
        ExternalPlayerLauncher.open(target, streamURL: url, title: item.title, subtitles: store.playbackSubtitleURLs.map(\.absoluteString)) { message in
            store.status = message
        }
    }

    private func switchToKSPlayerEngine(manual: Bool) {
        player?.pause()
        forceVLCSurface = false
        forceKSPlayerSurface = true
        isPlaying = true
        isLoading = false
        errorText = nil
        #if canImport(KSPlayer)
        playbackNotice = manual ? "KSPlayer tvOS-Safe Native-First selected manually for this stream." : "KSPlayer tvOS-Safe Native-First selected as primary internal engine."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "KSPlayer is not compiled into this IPA. Staying on VLC Internal fallback."
        store.status = playbackNotice
        switchToVLCEngine(manual: false)
        #endif
    }

    private func switchToVLCEngine(manual: Bool) {
        #if canImport(TVVLCKit)
        player?.pause()
        forceKSPlayerSurface = false
        forceVLCSurface = true
        vlcSurfaceToken += 1
        isPlaying = true
        isLoading = false
        errorText = nil
        playbackNotice = manual ? "VLC Internal selected manually for this stream." : "Switched to VLC Internal fallback."
        startPlayerClock()
        store.status = playbackNotice
        #else
        playbackNotice = "VLC Internal is not available in this IPA because TVVLCKit was not compiled in."
        store.status = playbackNotice
        #endif
    }

    private func togglePlay() {
        if forceKSPlayerSurface || forceVLCSurface {
            isPlaying.toggle()
            if isPlaying {
                hideTask?.cancel()
                withAnimation(.easeInOut(duration: 0.14)) { controlsVisible = false }
            } else {
                forceControlsVisibleForNavigation()
            }
            store.status = isPlaying ? "Playback resumed; controls hidden." : "Playback paused; controls remain visible."
            return
        }
        guard let player else { return }
        if player.timeControlStatus == .playing {
            player.pause()
            isPlaying = false
            forceControlsVisibleForNavigation()
        } else {
            player.play()
            isPlaying = true
            hideTask?.cancel()
            withAnimation(.easeInOut(duration: 0.14)) { controlsVisible = false }
        }
    }

    private func seek(_ seconds: Double) {
        if forceKSPlayerSurface {
            currentSeconds = max(0, min(durationSeconds > 0 ? durationSeconds : Double.greatestFiniteMagnitude, currentSeconds + seconds))
            vlcSeekSeconds = seconds
            vlcSeekSerial += 1
            store.status = "KSPlayer seek command sent to the video surface."
            forceControlsVisibleForNavigation()
            return
        }
        if forceVLCSurface {
            currentSeconds = max(0, min(durationSeconds > 0 ? durationSeconds : Double.greatestFiniteMagnitude, currentSeconds + seconds))
            vlcSeekSeconds = seconds
            vlcSeekSerial += 1
            forceControlsVisibleForNavigation()
            return
        }
        guard let player else { return }
        let current = CMTimeGetSeconds(player.currentTime())
        let target = max(0, current + seconds)
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        showControls()
    }

    private func toggleZoom() {
        videoGravity = videoGravity == .resizeAspect ? .resizeAspectFill : .resizeAspect
        showControls()
    }

    private func cycleMedia(groupCharacteristic: AVMediaCharacteristic, label: String) {
        guard !forceKSPlayerSurface && !forceVLCSurface else {
            store.status = "\(label.capitalized) default is set by the active internal engine: English audio preferred, subtitles off by default. Full track list UI remains inside the Debrid overlay settings panel."
            showControls()
            return
        }
        guard let item = player?.currentItem, let group = item.asset.mediaSelectionGroup(forMediaCharacteristic: groupCharacteristic) else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let options = group.options
        guard !options.isEmpty else {
            store.status = "No alternate \(label) tracks were found in this stream."
            showControls()
            return
        }
        let current = item.currentMediaSelection.selectedMediaOption(in: group)
        let nextIndex: Int
        if let current, let idx = options.firstIndex(of: current) {
            nextIndex = (idx + 1) % options.count
        } else {
            nextIndex = 0
        }
        item.select(options[nextIndex], in: group)
        store.status = "Selected \(label): \(options[nextIndex].displayName)"
        showControls()
    }

    private func startRenderWatchdog(for item: AVPlayerItem, player: AVPlayer) {
        renderWatchdogTask?.cancel()
        renderWatchdogTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 5_000_000_000)
            guard errorText == nil, !forceVLCSurface, !forceKSPlayerSurface else { return }
            let size = item.presentationSize
            let hasVideo = size.width > 8 && size.height > 8
            let likelyPlaying = player.timeControlStatus == .playing || player.rate > 0
            if !hasVideo && likelyPlaying {
                #if canImport(TVVLCKit)
                if !avRetryAttemptedForCurrentURL && UniversalCodecSupport.vlcCompiledIn {
                    avRetryAttemptedForCurrentURL = true
                    retryText = "VLC Internal produced audio/no video; switching this same URL to VLC Internal…"
                    switchToVLCEngine(manual: false)
                    forceControlsVisibleForNavigation()
                    return
                }
                #endif
                isLoading = false
                forceControlsVisibleForNavigation()
                errorText = "AVPlayer is disabled in v126. VLC Internal is the primary in-app renderer."
            }
        }
    }

    private func forceControlsVisible() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
    }

    private var cacheLimitLabel: String {
        vodCacheLimitGB == -1 ? "Unlimited" : "\(vodCacheLimitGB)GB"
    }

    private var cacheLimitGBValue: Double {
        vodCacheLimitGB == -1 ? 0 : Double(vodCacheLimitGB)
    }

    private var cacheFillProgress: Double {
        cacheSession.progress
    }

    private var cacheUsedGB: Double {
        cacheSession.usedGB
    }

    private func cycleCacheLimit() {
        if isLivePlayback {
            cacheSession.stopAndDelete()
            store.status = "Live TV cache remains disabled. VOD-only cache protects TS/HLS playback from recording or progress-cache behavior."
            return
        }
        switch vodCacheLimitGB {
        case 5: vodCacheLimitGB = 10
        case 10: vodCacheLimitGB = -1
        default: vodCacheLimitGB = 5
        }
        // Restart the temporary watch-session cache with the new limit. This cache is deleted on player exit.
        cacheSession.start(originURL: url, limitGB: vodCacheLimitGB)
    }

    private func forceControlsVisibleForNavigation() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.16)) { controlsVisible = true }
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard isPlaying, activePanel == nil, errorText == nil, !isLoading else { return }
            withAnimation(.easeInOut(duration: 0.16)) { controlsVisible = false }
        }
    }

    private func showControls() {
        hideTask?.cancel()
        withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = true }
        scheduleAutoHide()
    }

    private func scheduleAutoHide() {
        hideTask?.cancel()
        guard isPlaying, activePanel == nil, errorText == nil, !isLoading else { return }
        hideTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            guard isPlaying, activePanel == nil, errorText == nil, !isLoading else { return }
            withAnimation(.easeInOut(duration: 0.18)) { controlsVisible = false }
        }
    }

    private func runtimeSeconds(for item: MediaItem) -> Double {
        // The current catalog demo/runtime source often uses 152min. Keep this robust until backend runtime arrives.
        if item.description.lowercased().contains("short") { return 0 }
        return 152 * 60
    }

    private func startPlayerClock() {
        playbackClockTask?.cancel()
        playbackClockTask = Task { @MainActor in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                guard isPlaying, errorText == nil, !isLoading else { continue }
                guard forceKSPlayerSurface || forceVLCSurface else { continue }
                if durationSeconds > 0 { currentSeconds = min(durationSeconds, currentSeconds + 1) } else { currentSeconds += 1 }
            }
        }
    }

    private func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds > 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }
}


struct DebridPlaybackDiagnosticsPanel: View {
    let diagnostics: DebridPlaybackDiagnostics

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("PLAYBACK DIAGNOSTICS")
                .font(.system(size: 14, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
            diagnosticRow("Active Engine", diagnostics.activeEngine)
            diagnosticRow("HW Decode", diagnostics.hwDecode)
            diagnosticRow("Render Backend", diagnostics.renderBackend)
            diagnosticRow("Decoder", diagnostics.decoder)
            diagnosticRow("FPS", diagnostics.fps)
            diagnosticRow("Dropped Frames", diagnostics.droppedFrames)
            Text(diagnostics.notes)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
                .lineLimit(2)
                .frame(width: 360, alignment: .leading)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
        .background(.black.opacity(0.44), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(.white.opacity(0.12), lineWidth: 1))
        .allowsHitTesting(false)
    }

    private func diagnosticRow(_ key: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(key)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.50))
                .frame(width: 118, alignment: .leading)
            Text(value)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .lineLimit(1)
        }
    }
}


struct DebridMovieLoadingView: View {
    let message: String
    @State private var spin = false
    @State private var glow = false

    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .stroke(.white.opacity(0.12), lineWidth: 8)
                    .frame(width: 92, height: 92)
                Circle()
                    .trim(from: 0.08, to: 0.78)
                    .stroke(.white.opacity(0.92), style: StrokeStyle(lineWidth: 8, lineCap: .round))
                    .frame(width: 92, height: 92)
                    .rotationEffect(.degrees(spin ? 360 : 0))
                Circle()
                    .fill(.white.opacity(glow ? 0.24 : 0.10))
                    .frame(width: 24, height: 24)
                    .shadow(color: .white.opacity(0.45), radius: glow ? 22 : 8)
            }
            Text(message)
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundStyle(.white)
            Text("Preparing the best internal playback engine")
                .font(.system(size: 18, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
        }
        .padding(.horizontal, 42)
        .padding(.vertical, 34)
        .background(.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(.white.opacity(0.14), lineWidth: 1))
        .onAppear {
            withAnimation(.linear(duration: 1.0).repeatForever(autoreverses: false)) { spin = true }
            withAnimation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true)) { glow = true }
        }
    }
}

struct ApplePlayerErrorCard: View {
    let message: String
    let close: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        VStack(spacing: 18) {
            Text("Playback Error")
                .font(.system(size: 34, weight: .black, design: .rounded))
            Text(message)
                .font(.system(size: 22, weight: .semibold, design: .rounded))
                .multilineTextAlignment(.center)
                .foregroundStyle(.white.opacity(0.78))
            Button(action: close) {
                Text("Close Player")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                    .foregroundStyle(focused ? .black : .white)
                    .padding(.horizontal, 34)
                    .padding(.vertical, 15)
                    .background(Capsule().fill(focused ? Color.white : Color.white.opacity(0.16)))
            }
            .buttonStyle(.plain)
            .focused($focused)
        }
        .padding(42)
        .frame(maxWidth: 900)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 34, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 34, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .foregroundStyle(.white)
        .shadow(color: .black.opacity(0.55), radius: 30)
        .onAppear { focused = true }
    }
}

struct AppleVODPosterCard: View {
    let item: MediaItem

    var body: some View {
        RemoteImageFit(url: item.posterURL, mode: .fit)
            .frame(width: 178, height: 260)
            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(Color.white.opacity(0.24), lineWidth: 1))
            .shadow(color: .black.opacity(0.68), radius: 18, x: 0, y: 10)
            .overlay(alignment: .bottomLeading) {
                Text(item.rating.isEmpty ? "NR" : "★ \(item.rating)")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial, in: Capsule())
                    .padding(10)
            }
    }
}

struct AppleVODBadge: View {
    let text: String
    let highlighted: Bool

    var body: some View {
        Text(text)
            .font(.system(size: 17, weight: .black, design: .rounded))
            .foregroundStyle(highlighted ? .black : .white.opacity(0.86))
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(Capsule().fill(highlighted ? Color.white.opacity(0.92) : Color.white.opacity(0.12)))
            .overlay(Capsule().stroke(Color.white.opacity(highlighted ? 0.0 : 0.16), lineWidth: 1))
    }
}

struct AppleVODChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.clear, .black.opacity(0.16), .black.opacity(0.92)],
                startPoint: .top,
                endPoint: .bottom
            )
            LinearGradient(
                colors: [.black.opacity(0.18), .clear, .black.opacity(0.16)],
                startPoint: .leading,
                endPoint: .trailing
            )
            VStack { Spacer() }
                .background(
                    Rectangle()
                        .fill(Color.black.opacity(0.22))
                        .background(.ultraThinMaterial)
                        .frame(height: 420),
                    alignment: .bottom
                )
        }
    }
}

struct VideoSurface: UIViewRepresentable {
    let player: AVPlayer?
    let videoGravity: AVLayerVideoGravity

    final class PlayerLayerView: UIView {
        override static var layerClass: AnyClass { AVPlayerLayer.self }
        var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
    }

    func makeUIView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.backgroundColor = .black
        view.isUserInteractionEnabled = false
        view.playerLayer.videoGravity = videoGravity
        view.playerLayer.player = player
        return view
    }

    func updateUIView(_ view: PlayerLayerView, context: Context) {
        view.playerLayer.player = player
        view.playerLayer.videoGravity = videoGravity
    }
}

struct DebridPlayerPanel: View {
    let title: String
    let detail: String
    let close: () -> Void
    @FocusState private var closeFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(title)
                .font(.system(size: 34, weight: .black))
            Text(detail)
                .font(.system(size: 23, weight: .semibold))
                .foregroundStyle(.white.opacity(0.82))
                .lineLimit(5)
            Button(action: close) {
                Text("CLOSE PANEL")
                    .font(.system(size: 22, weight: .black))
                    .foregroundStyle(closeFocused ? .black : .white)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 14)
                    .background(Capsule().fill(closeFocused ? Color.white : Color.white.opacity(0.14)))
                    .overlay(Capsule().stroke(Color.white.opacity(0.4), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .focused($closeFocused)
        }
        .foregroundStyle(.white)
        .padding(30)
        .frame(width: 520, alignment: .leading)
        .background(.ultraThinMaterial.opacity(0.92), in: RoundedRectangle(cornerRadius: 30))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .shadow(color: .black.opacity(0.55), radius: 26)
        .focusSection()
        .onAppear { closeFocused = true }
    }
}

struct PlayerChromeBackground: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [.clear, .black.opacity(0.25), .black.opacity(0.92)], startPoint: .top, endPoint: .bottom)
            LinearGradient(colors: [.black.opacity(0.18), .clear, .black.opacity(0.20)], startPoint: .leading, endPoint: .trailing)
        }
    }
}

struct PlayerProgressBar: View {
    let progress: Double

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.18))
                Capsule().fill(Color.white.opacity(0.72)).frame(width: proxy.size.width * min(max(progress, 0), 1))
                Circle().fill(Color.white).frame(width: 18, height: 18).offset(x: max(0, proxy.size.width * min(max(progress, 0), 1) - 9))
            }
        }
    }
}


struct VODRuntimeProgressSummary: View {
    let title: String
    let current: String
    let total: String
    let remaining: String
    let percent: String
    let cacheLabel: String
    let cacheUsed: String
    let cacheLimit: String

    var body: some View {
        HStack(spacing: 18) {
            Text(title)
                .font(.system(size: 20, weight: .black, design: .rounded))
                .lineLimit(1)
                .frame(maxWidth: 520, alignment: .leading)
            Text("Time \(current) / \(total)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Remaining \(remaining)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Progress \(percent)")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .monospacedDigit()
            Text("Cache \(cacheUsed) / \(cacheLimit) (\(cacheLabel))")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .lineLimit(1)
        }
        .foregroundStyle(.white.opacity(0.86))
        .padding(.horizontal, 4)
        .accessibilityLabel("\(title), playback time \(current) of \(total), \(percent) complete, \(remaining) remaining, cache \(cacheUsed) of \(cacheLimit)")
    }
}

struct VODCacheProgressRow: View {
    let cacheLabel: String
    let usedGB: Double
    let limitGB: Double
    let progress: Double
    let status: String

    var body: some View {
        HStack(spacing: 14) {
            Text("Cache")
                .font(.system(size: 16, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.58))
            ZStack(alignment: .leading) {
                Capsule().fill(.white.opacity(0.10))
                Capsule().fill(LinearGradient(colors: [.cyan.opacity(0.92), .blue.opacity(0.72)], startPoint: .leading, endPoint: .trailing))
                    .frame(width: max(8, 330 * progress))
            }
            .frame(width: 330, height: 8)
            Text(limitGB == 0 ? String(format: "%.2f GB / Unlimited", usedGB) : String(format: "%.2f GB / %@", usedGB, cacheLabel))
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.46))
            Text("• \(status)")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Text("• English audio preferred • Subtitles off")
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.34))
        }
        .lineLimit(1)
    }
}

struct PlayerControlButton: View {
    let title: String
    let focus: VODPlayerScreen.PlayerControl
    var focused: FocusState<VODPlayerScreen.PlayerControl?>.Binding
    let action: () -> Void

    private var selected: Bool { focused.wrappedValue == focus }
    private var foregroundColor: Color { selected ? .black : .white.opacity(0.92) }
    private var fillColor: Color { selected ? .white.opacity(0.94) : .white.opacity(0.105) }
    private var strokeColor: Color { selected ? .white.opacity(0.98) : .white.opacity(0.20) }
    private var strokeWidth: CGFloat { selected ? 2 : 1 }
    private var buttonScale: CGFloat { selected ? 1.055 : 1.0 }
    private var glowColor: Color { selected ? .white.opacity(0.28) : .clear }

    var body: some View {
        controlLabel
            .background(controlBackground)
            .overlay(controlStroke)
            .scaleEffect(buttonScale)
            .shadow(color: glowColor, radius: 13)
            .contentShape(Capsule())
            // v166: keep player-shell DPAD routing; avoid native tvOS Button focus stealing overlay controls.
            .focusable(false)
            .accessibilityLabel(title)
    }

    private var controlLabel: some View {
        Text(title)
            .font(.system(size: 20, weight: .black, design: .rounded))
            .foregroundStyle(foregroundColor)
            .padding(.horizontal, 21)
            .padding(.vertical, 13)
    }

    private var controlBackground: some View {
        Capsule().fill(fillColor)
    }

    private var controlStroke: some View {
        Capsule().stroke(strokeColor, lineWidth: strokeWidth)
    }
}

struct SettingsScreen: View {
    @EnvironmentObject var store: CatalogStore
    @AppStorage("stremioManifestURL") private var manifestURL: String = "https://v3-cinemeta.strem.io/manifest.json"
    @AppStorage("liveChannelsDvrBaseURL") private var liveChannelsDvrBaseURL: String = ""
    @AppStorage("liveHDHomeRunManualURL") private var liveHDHomeRunManualURL: String = ""
    @AppStorage("liveHDHomeRunManualGuideURL") private var liveHDHomeRunManualGuideURL: String = ""
    @AppStorage("liveM3UURL") private var liveM3UURL: String = ""
    @AppStorage("liveXMLTVURL") private var liveXMLTVURL: String = ""
    @AppStorage("liveXtreamServer") private var liveXtreamServer: String = ""
    @AppStorage("liveXtreamUsername") private var liveXtreamUsername: String = ""
    @AppStorage("liveXtreamPassword") private var liveXtreamPassword: String = ""
    @FocusState private var focused: SettingsFocus?
    @State private var lastSettingsDpadMoveAt: Date = .distantPast

    enum SettingsFocus: Hashable { case manifest, add, load, loadAll, reset, liveDvr, liveHDHRManual, liveHDHRGuideURL, liveM3U, liveXMLTV, liveXtreamServer, liveXtreamUsername, liveXtreamPassword, home, movies, shows, live }

    var body: some View {
        ZStack {
            CinematicAmbientBackground().ignoresSafeArea()
            settingsScroll
        }
        .onAppear { focused = .manifest }
        // v179: Let the tvOS focus engine own Settings DPAD movement. The prior
        // manual routeSettings() handler fought the native ScrollView/TextField focus
        // movement, causing one Siri Remote click to jump two controls.
    }

    private var settingsScroll: some View {
        ScrollView(.vertical, showsIndicators: true) {
            VStack(alignment: .leading, spacing: 22) {
                settingsTitle
                stremioCard
                quickNavigationCard
                Spacer(minLength: 80)
            }
            .frame(width: 1280, alignment: .leading)
            .padding(.leading, 120)
            .padding(.bottom, 120)
        }
    }

    private var settingsTitle: some View {
        Text("Settings")
            .font(.system(size: 62, weight: .black))
            .foregroundStyle(.white)
            .padding(.top, 132)
    }

    private var stremioCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            stremioHeader
            manifestInput
            manifestButtons
            savedManifestList
            liveTVSourcesSection
            buildStatusSection
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.055)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var stremioHeader: some View {
        Text("Stremio JSON Catalogs")
            .font(.system(size: 28, weight: .bold))
            .foregroundStyle(.white)
    }

    private var manifestInput: some View {
        TextField("Paste Stremio manifest JSON URL", text: $manifestURL)
            .font(.system(size: 25, weight: .semibold))
            .foregroundStyle(.white)
            .padding(20)
            .background(RoundedRectangle(cornerRadius: 18).fill(Color.white.opacity(0.08)))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused == .manifest ? Color.cyan : Color.white.opacity(0.12), lineWidth: focused == .manifest ? 3 : 1))
            .focused($focused, equals: .manifest)
            .frame(width: 1180)
    }

    private var manifestButtons: some View {
        HStack(spacing: 16) {
            SettingsButton(title: "Add JSON", focus: .add, focused: $focused) {
                store.addManifestURL(manifestURL)
                manifestURL = ""
            }
            SettingsButton(title: store.isLoading ? "Loading..." : "Load This URL", focus: .load, focused: $focused) {
                Task { await store.loadManifest(urlString: manifestURL) }
            }
            SettingsButton(title: "Load All Catalogs", focus: .loadAll, focused: $focused) {
                Task { await store.loadAllManifests() }
            }
            SettingsButton(title: "Restore Demo Rows", focus: .reset, focused: $focused) {
                store.resetDemo()
            }
        }
    }

    private var savedManifestList: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Saved JSON URLs")
                .font(.system(size: 20, weight: .black))
                .foregroundStyle(.cyan)
            ForEach(store.manifestURLs.prefix(5), id: \.self) { url in
                Text("• \(url)")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(1)
                    .frame(width: 1120, alignment: .leading)
            }
        }
        .padding(.top, 4)
    }

    private var liveTVSourcesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Live TV Sources")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            liveTextField("Channels DVR base URL, example http://192.168.1.50:8089", text: $liveChannelsDvrBaseURL, focus: .liveDvr)
            liveTextField("HDHomeRun manual IP or lineup URL, example http://hdhomerun.local/lineup.json", text: $liveHDHomeRunManualURL, focus: .liveHDHRManual)
            liveTextField("HDHomeRun/XMLTV Gracenotes guide URL", text: $liveHDHomeRunManualGuideURL, focus: .liveHDHRGuideURL)
            liveTextField("M3U playlist URL", text: $liveM3UURL, focus: .liveM3U)
            liveTextField("XMLTV guide URL", text: $liveXMLTVURL, focus: .liveXMLTV)
            xtreamFields
            Text("v179 rebuilds Settings/Guide DPAD ownership so the tvOS focus engine handles normal movement once, while Debrid Channels only handles special Live TV transitions. Black-glass Live TV styling and manual DVR/M3U/XMLTV/Xtream sources are preserved.")
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(.white.opacity(0.68))
                .frame(width: 1120, alignment: .leading)
        }
        .padding(.top, 6)
    }

    private func liveTextField(_ placeholder: String, text: Binding<String>, focus: SettingsFocus) -> some View {
        TextField(placeholder, text: text)
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(.white)
            .padding(14)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
            .focused($focused, equals: focus)
            .frame(width: 1120)
    }

    private func liveToggleButton(title: String, subtitle: String, isOn: Binding<Bool>, focus: SettingsFocus) -> some View {
        Button {
            isOn.wrappedValue.toggle()
        } label: {
            HStack(spacing: 16) {
                RoundedRectangle(cornerRadius: 16)
                    .fill(isOn.wrappedValue ? Color.cyan.opacity(0.85) : Color.white.opacity(0.12))
                    .frame(width: 86, height: 44)
                    .overlay(alignment: isOn.wrappedValue ? .trailing : .leading) {
                        Circle().fill(Color.white).frame(width: 34, height: 34).padding(5)
                    }
                VStack(alignment: .leading, spacing: 4) {
                    Text("\(title): \(isOn.wrappedValue ? "On" : "Off")")
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(.white)
                    Text(subtitle)
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.62))
                        .lineLimit(2)
                }
                Spacer()
            }
            .padding(14)
            .frame(width: 1120)
            .background(RoundedRectangle(cornerRadius: 14).fill(Color.white.opacity(0.07)))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(focused == focus ? Color.orange : Color.white.opacity(0.12), lineWidth: focused == focus ? 3 : 1))
        }
        .buttonStyle(.plain)
        .focused($focused, equals: focus)
    }

    private var xtreamFields: some View {
        HStack(spacing: 10) {
            TextField("Xtream server", text: $liveXtreamServer)
                .focused($focused, equals: .liveXtreamServer)
            TextField("Username", text: $liveXtreamUsername)
                .focused($focused, equals: .liveXtreamUsername)
            TextField("Password", text: $liveXtreamPassword)
                .focused($focused, equals: .liveXtreamPassword)
        }
        .font(.system(size: 18, weight: .semibold))
        .foregroundStyle(.white)
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.07)))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(isXtreamFieldFocused ? Color.orange : Color.white.opacity(0.12), lineWidth: isXtreamFieldFocused ? 3 : 1))
        .frame(width: 1120)
    }

    private var buildStatusSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Build v179 LIVE_TV_GHOST_DPAD_INPUT_FIX")
                .font(.system(size: 22, weight: .black))
                .foregroundStyle(Color.cyan)
            Text(store.status)
                .font(.system(size: 22, weight: .medium))
                .foregroundStyle(.white.opacity(0.72))
                .frame(width: 1180, alignment: .leading)
        }
    }

    private var quickNavigationCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Quick Navigation")
                .font(.system(size: 28, weight: .bold))
                .foregroundStyle(.white)
            HStack(spacing: 18) {
                SettingsButton(title: "Home", focus: .home, focused: $focused) { store.selectedTab = .home }
                SettingsButton(title: "Movies", focus: .movies, focused: $focused) { store.selectedTab = .movies }
                SettingsButton(title: "Shows", focus: .shows, focused: $focused) { store.selectedTab = .shows }
                SettingsButton(title: "Live TV", focus: .live, focused: $focused) { store.selectedTab = .live }
            }
        }
        .padding(28)
        .background(RoundedRectangle(cornerRadius: 28).fill(Color.white.opacity(0.045)))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }

    private var isXtreamFieldFocused: Bool {
        focused == .liveXtreamServer || focused == .liveXtreamUsername || focused == .liveXtreamPassword
    }

    private func acceptSingleSettingsDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSettingsDpadMoveAt) > 0.32 else { return false }
        lastSettingsDpadMoveAt = now
        return true
    }

    private func routeSettings(_ direction: MoveCommandDirection) {
        switch direction {
        case .right:
            switch focused {
            case .manifest: focused = .add
            case .add: focused = .load
            case .load: focused = .loadAll
            case .loadAll: focused = .reset
            case .liveXtreamServer: focused = .liveXtreamUsername
            case .liveXtreamUsername: focused = .liveXtreamPassword
            case .reset: focused = .liveDvr
            case .home: focused = .movies
            case .movies: focused = .shows
            case .shows: focused = .live
            case .live, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .liveXtreamPassword, .none: break
            }
        case .left:
            switch focused {
            case .add: focused = .manifest
            case .load: focused = .add
            case .loadAll: focused = .load
            case .reset: focused = .loadAll
            case .liveXtreamUsername: focused = .liveXtreamServer
            case .liveXtreamPassword: focused = .liveXtreamUsername
            case .movies: focused = .home
            case .shows: focused = .movies
            case .live: focused = .shows
            case .manifest, .liveDvr, .liveHDHRManual, .liveHDHRGuideURL, .liveM3U, .liveXMLTV, .liveXtreamServer, .home, .none: break
            }
        case .down:
            switch focused {
            case .manifest: focused = .add
            case .add, .load, .loadAll, .reset: focused = .liveDvr
            case .liveDvr: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveM3U
            case .liveM3U: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword: focused = .home
            case .home, .movies, .shows, .live: break
            case .none: focused = .manifest
            }
        case .up:
            switch focused {
            case .home, .movies, .shows, .live: focused = .liveXtreamServer
            case .liveXtreamServer, .liveXtreamUsername, .liveXtreamPassword: focused = .liveXMLTV
            case .liveXMLTV: focused = .liveM3U
            case .liveM3U: focused = .liveHDHRGuideURL
            case .liveHDHRGuideURL: focused = .liveHDHRManual
            case .liveHDHRManual: focused = .liveDvr
            case .liveDvr: focused = .add
            case .add, .load, .loadAll, .reset: focused = .manifest
            case .manifest: store.menuFocusToken += 1
            case .none: focused = .manifest
            }
        default:
            break
        }
    }
}

struct SettingsButton: View {
    let title: String
    let focus: SettingsScreen.SettingsFocus
    var focused: FocusState<SettingsScreen.SettingsFocus?>.Binding
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 24, weight: .bold))
                .foregroundStyle(.white)
                .padding(.horizontal, 28)
                .padding(.vertical, 18)
                .background(RoundedRectangle(cornerRadius: 18).fill(focused.wrappedValue == focus ? Color.orange.opacity(0.75) : Color.white.opacity(0.09)))
                .overlay(RoundedRectangle(cornerRadius: 18).stroke(focused.wrappedValue == focus ? Color.orange : Color.white.opacity(0.11), lineWidth: focused.wrappedValue == focus ? 3 : 1))
                .scaleEffect(focused.wrappedValue == focus ? 1.06 : 1.0)
        }
        .buttonStyle(.plain)
        .focused(focused, equals: focus)
    }
}



struct LiveTVChannel: Identifiable, Hashable {
    let id: Int
    let logo: String
    let number: String
    let name: String
    let category: String
    let now: String
    let next: String
    let description: String
    let accent: Color
    var streamURL: String = ""
    var iconURL: String = ""
    var tvgID: String = ""
    var source: String = "Demo"
}

struct LiveProgram: Identifiable, Hashable {
    let id = UUID()
    let title: String
    let width: CGFloat
    let isLive: Bool
    var description: String = ""
    var startText: String = ""
    var endText: String = ""
}

struct LiveTVLoadedChannel: Identifiable, Hashable, Codable {
    var id: Int
    var logo: String
    var number: String
    var name: String
    var category: String
    var now: String
    var next: String
    var description: String
    var streamURL: String
    var iconURL: String
    var tvgID: String
    var source: String

    func uiChannel() -> LiveTVChannel {
        LiveTVChannel(
            id: id,
            logo: logo,
            number: number,
            name: name,
            category: category,
            now: now,
            next: next,
            description: description,
            accent: LiveTVSourceModel.accent(for: category),
            streamURL: streamURL,
            iconURL: iconURL,
            tvgID: tvgID,
            source: source
        )
    }
}

@MainActor
final class LiveTVSourceModel: ObservableObject {
    @Published var channels: [LiveTVChannel] = LiveTVScreen.sampleChannels
    @Published var guidePrograms: [String: [LiveProgram]] = [:]
    @Published var status: String = "Live TV demo lineup ready. Configure Channels DVR, M3U/XMLTV, or Xtream in Settings, then reopen Live TV."
    @Published var isLoading: Bool = false

    private let cacheKey = "liveTVLoadedChannelsV165"
    private let guideCacheKey = "liveTVGuideProgramsV165"

    nonisolated static func accent(for category: String) -> Color {
        switch category.lowercased() {
        case "sports": return .red
        case "news": return .red
        case "kids": return .orange
        case "movies": return .cyan
        case "hd": return .blue
        case "favorites": return .indigo
        case "comedy": return .mint
        default: return .gray
        }
    }

    func loadCachedOrDemo() {
        guard let data = UserDefaults.standard.data(forKey: cacheKey),
              let saved = try? JSONDecoder().decode([LiveTVLoadedChannel].self, from: data),
              !saved.isEmpty else { return }
        channels = saved.map { $0.uiChannel() }
        status = "Cached Live TV lineup • \(channels.count) channels"
    }

    func refreshFromConfiguredSources() async {
        isLoading = true
        defer { isLoading = false }
        let defaults = UserDefaults.standard
        let dvrBase = defaults.string(forKey: "liveChannelsDvrBaseURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManual = defaults.string(forKey: "liveHDHomeRunManualURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let hdhrManualGuide = defaults.string(forKey: "liveHDHomeRunManualGuideURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let m3uURL = defaults.string(forKey: "liveM3UURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let xmltvURL = defaults.string(forKey: "liveXMLTVURL")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let xtreamServer = defaults.string(forKey: "liveXtreamServer")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let xtreamUser = defaults.string(forKey: "liveXtreamUsername")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let xtreamPass = defaults.string(forKey: "liveXtreamPassword")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

        var loaded: [LiveTVChannel] = []
        var messages: [String] = []
        var xmlGuide = ""
        guidePrograms = [:]

        if !dvrBase.isEmpty {
            let result = await loadChannelsDVR(base: dvrBase, allowAutoScan: false)
            loaded.append(contentsOf: result.channels)
            messages.append(result.message)
            let storedDvrBase = UserDefaults.standard.string(forKey: "liveChannelsDvrBaseURL") ?? dvrBase
            let dvrGuideBase = normalizeServerBase(storedDvrBase, defaultPort: 8089)
            if !dvrGuideBase.isEmpty { xmlGuide = await fetchText("\(dvrGuideBase)/devices/ANY/guide/xmltv?duration=86400", accept: "application/xml,text/xml,*/*", maxBytes: 16 * 1024 * 1024) ?? xmlGuide }
            if !dvrGuideBase.isEmpty && xmlGuide.isEmpty { xmlGuide = await fetchText("\(dvrGuideBase)/devices/ANY/guide/xmltv", accept: "application/xml,text/xml,*/*", maxBytes: 16 * 1024 * 1024) ?? xmlGuide }
        }

        if !hdhrManual.isEmpty {
            let hdhr = await loadHDHomeRun(manual: hdhrManual, allowAutoScan: false)
            var hdhrChannels = hdhr.channels
            messages.append(hdhr.message)
            if !hdhrManualGuide.isEmpty,
               let hdhrXML = await fetchText(hdhrManualGuide, accept: "application/xml,text/xml,*/*", maxBytes: 12 * 1024 * 1024) {
                hdhrChannels = applyXMLTVIcons(hdhrXML, to: hdhrChannels, baseURL: urlBase(hdhrManualGuide))
                let hdhrGuide = parseXMLTV(hdhrXML, channels: hdhrChannels)
                for (key, value) in hdhrGuide { guidePrograms[key] = value }
                xmlGuide = xmlGuide.isEmpty ? hdhrXML : xmlGuide
                messages.append("HDHomeRun XMLTV/Gracenotes guide matched \(hdhrGuide.count) channel(s)")
            }
            loaded.append(contentsOf: hdhrChannels)
        }

        if !m3uURL.isEmpty {
            let m3u = await loadM3U(url: m3uURL, source: "M3U/XMLTV")
            loaded.append(contentsOf: m3u.channels)
            messages.append(m3u.message)
        }

        if !xmltvURL.isEmpty {
            xmlGuide = await fetchText(xmltvURL, accept: "application/xml,text/xml,*/*", maxBytes: 12 * 1024 * 1024) ?? xmlGuide
            if !xmlGuide.isEmpty { messages.append("XMLTV guide loaded") }
        }

        if !xtreamServer.isEmpty && !xtreamUser.isEmpty && !xtreamPass.isEmpty {
            let xtream = await loadXtream(server: xtreamServer, username: xtreamUser, password: xtreamPass)
            loaded.append(contentsOf: xtream.channels)
            messages.append(xtream.message)
        }

        var finalized = dedupe(loaded)
        if !xmlGuide.isEmpty {
            finalized = applyXMLTVIcons(xmlGuide, to: finalized, baseURL: !xmltvURL.isEmpty ? urlBase(xmltvURL) : (!dvrBase.isEmpty ? normalizeServerBase(dvrBase, defaultPort: 8089) : ""))
            guidePrograms = parseXMLTV(xmlGuide, channels: finalized)
            let guideCount = guidePrograms.values.reduce(0) { $0 + $1.count }
            if guideCount > 0 { messages.append("Guide matched \(guidePrograms.count) channel(s) / \(guideCount) program(s)") }
        }

        if !finalized.isEmpty {
            channels = finalized.sorted { channelSortKey($0.number) < channelSortKey($1.number) || (channelSortKey($0.number) == channelSortKey($1.number) && $0.name < $1.name) }
            let persist = channels.map { LiveTVLoadedChannel(id: $0.id, logo: $0.logo, number: $0.number, name: $0.name, category: $0.category, now: $0.now, next: $0.next, description: $0.description, streamURL: $0.streamURL, iconURL: $0.iconURL, tvgID: $0.tvgID, source: $0.source) }
            if let data = try? JSONEncoder().encode(persist) { UserDefaults.standard.set(data, forKey: cacheKey) }
            status = messages.joined(separator: " • ").ifEmpty("Loaded \(channels.count) Live TV channels")
        } else {
            status = messages.joined(separator: " • ").ifEmpty("No configured Live TV source returned channels. Demo lineup remains visible.")
        }
    }

    private func normalizeServerBase(_ raw: String, defaultPort: Int?) -> String {
        var clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        clean = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        if clean.isEmpty { return clean }
        if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") {
            clean = "http://" + clean
        }
        guard let defaultPort,
              var components = URLComponents(string: clean),
              components.port == nil,
              let host = components.host,
              !host.isEmpty else { return clean }
        components.port = defaultPort
        return components.string ?? clean
    }

    private func channelsDVRCandidates(rawBase: String, allowAutoScan: Bool) -> [String] {
        let trimmed = rawBase.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return [] }
        return [normalizeServerBase(trimmed, defaultPort: 8089)]
    }

    private func loadChannelsDVR(base rawBase: String, allowAutoScan: Bool = true) async -> (channels: [LiveTVChannel], message: String) {
        let candidates = channelsDVRCandidates(rawBase: rawBase, allowAutoScan: allowAutoScan)
        var best: ([LiveTVChannel], String)? = nil
        for base in candidates {
        var combined: [LiveTVChannel] = []
        let m3uCandidates = [
            "\(base)/devices/ANY/channels.m3u",
            "\(base)/devices/ANY/channels.m3u?format=ts&codec=copy",
            "\(base)/devices/ANY/channels.m3u?format=ts"
        ]
        for url in m3uCandidates {
            if let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 6 * 1024 * 1024) {
                combined += parseM3U(text, source: "Channels DVR", baseURL: base)
            }
        }

        var devices = await fetchDVRDevices(base: base)
        if !devices.contains("ANY") { devices.append("ANY") }
        for device in devices {
            let encDevice = urlEncode(device)
            if let data = await fetchText("\(base)/devices/\(encDevice)/channels", accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024),
               let list = parseDVRChannelsJSON(data, base: base, device: device), !list.isEmpty {
                combined += list
            }
        }
        let groups = await loadDVRLineupGroups(base: base)
        let mapped = combined.map { channel -> LiveTVChannel in
            let extra = groups.first { _, members in
                members.contains(channel.number.lowercased()) || members.contains(channel.name.lowercased()) || (!channel.tvgID.isEmpty && members.contains(channel.tvgID.lowercased()))
            }?.key
            if let extra, !extra.isEmpty {
                return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: normalizeCategory(extra, fallback: channel.category), now: channel.now, next: channel.next, description: channel.description, accent: Self.accent(for: extra), streamURL: channel.streamURL, iconURL: channel.iconURL, tvgID: channel.tvgID, source: channel.source)
            }
            return channel
        }
        let out = dedupe(mapped)
        if !out.isEmpty { UserDefaults.standard.set(base, forKey: "liveChannelsDvrBaseURL"); return (out, "Channels DVR native • \(out.count) channel(s) • \(base)") }
        best = (out, "Channels DVR returned no channels at \(base)")
        }
        return best ?? ([], allowAutoScan ? "Channels DVR auto-scan found no server" : "Channels DVR not configured")
    }

    private func loadHDHomeRun(manual: String, allowAutoScan: Bool) async -> (channels: [LiveTVChannel], message: String) {
        var all: [LiveTVChannel] = []
        var messages: [String] = []
        for url in hdHomeRunManualCandidates(manual) {
            if url.lowercased().hasSuffix(".m3u") {
                let m3u = await loadM3U(url: url, source: "HDHomeRun")
                all.append(contentsOf: m3u.channels.map { ch in
                    LiveTVChannel(id: ch.id, logo: ch.logo, number: ch.number, name: ch.name, category: ch.category.ifEmpty("HDHomeRun"), now: ch.now, next: ch.next, description: ch.description, accent: Self.accent(for: ch.category), streamURL: ch.streamURL, iconURL: ch.iconURL, tvgID: ch.tvgID, source: "HDHomeRun")
                })
                messages.append("HDHomeRun manual M3U • \(m3u.channels.count)")
            } else if url.lowercased().hasSuffix(".xml") {
                if let xml = await fetchText(url, accept: "application/xml,text/xml,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunXMLLineup(xml, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual XML • \(parsed.count)")
                }
            } else {
                if let json = await fetchText(url, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: urlBase(url))
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun manual JSON • \(parsed.count)")
                }
            }
        }
        if allowAutoScan {
            let devices = await discoverHDHomeRunDevices()
            for device in devices {
                if let json = await fetchText(device.lineupURL, accept: "application/json,*/*", maxBytes: 4 * 1024 * 1024) {
                    let parsed = parseHDHomeRunJSONLineup(json, base: device.baseURL)
                    all.append(contentsOf: parsed)
                    messages.append("HDHomeRun auto \(device.name) • \(parsed.count)")
                }
            }
            if devices.isEmpty { messages.append("HDHomeRun auto-scan found no devices") }
        }
        let out = dedupe(all)
        return (out, out.isEmpty ? messages.joined(separator: " • ").ifEmpty("HDHomeRun off/no channels") : "HDHomeRun • \(out.count) channel(s) • " + messages.joined(separator: " • "))
    }

    private struct HDHomeRunDeviceCandidate { let name: String; let baseURL: String; let lineupURL: String }

    private func discoverHDHomeRunDevices() async -> [HDHomeRunDeviceCandidate] {
        guard let text = await fetchText("http://my.hdhomerun.com/discover", accept: "application/json,*/*", maxBytes: 512 * 1024),
              let data = text.data(using: .utf8),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.compactMap { obj in
            let base = stringValue(obj, keys: ["BaseURL", "BaseUrl", "baseURL"]).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
            let lineup = stringValue(obj, keys: ["LineupURL", "LineupUrl", "lineupURL"]).ifEmpty(base.isEmpty ? "" : base + "/lineup.json")
            guard !base.isEmpty, !lineup.isEmpty else { return nil }
            let name = stringValue(obj, keys: ["FriendlyName", "DeviceID", "DeviceId"]).ifEmpty("HDHomeRun")
            return HDHomeRunDeviceCandidate(name: name, baseURL: base, lineupURL: lineup)
        }
    }

    private func hdHomeRunManualCandidates(_ raw: String) -> [String] {
        let tokens = raw.split(whereSeparator: { $0 == "," || $0 == ";" || $0 == "\n" }).map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        var out: [String] = []
        for token in tokens {
            var clean = token
            if !clean.lowercased().hasPrefix("http://") && !clean.lowercased().hasPrefix("https://") { clean = "http://" + clean }
            let lower = clean.lowercased()
            if lower.hasSuffix("/lineup.json") || lower.hasSuffix("/lineup.m3u") || lower.hasSuffix("/lineup.xml") {
                out.append(clean)
            } else if lower.hasSuffix("/discover.json") {
                let base = String(clean.dropLast("/discover.json".count)).trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            } else {
                let base = clean.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
                out += [base + "/lineup.json", base + "/lineup.m3u", base + "/lineup.xml"]
            }
        }
        var seen = Set<String>()
        return out.filter { seen.insert($0).inserted }
    }

    private func parseHDHomeRunJSONLineup(_ json: String, base: String) -> [LiveTVChannel] {
        guard let data = json.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return [] }
        return arr.enumerated().compactMap { index, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Guide", "number", "channel"])
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "CallSign"]).ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = stringValue(obj, keys: ["URL", "StreamURL", "PlayURL", "url"]).ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            guard !stream.isEmpty else { return nil }
            let icon = stringValue(obj, keys: ["ImageURL", "GuideImageURL", "LogoURL", "StationLogo", "IconURL", "logo"])
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func parseHDHomeRunXMLLineup(_ xml: String, base: String) -> [LiveTVChannel] {
        guard let regex = try? NSRegularExpression(pattern: #"<Program[^>]*>(.*?)</Program>"#, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        let ns = xml as NSString
        return regex.matches(in: xml, range: NSRange(location: 0, length: ns.length)).enumerated().compactMap { index, match in
            let body = ns.substring(with: match.range(at: 1))
            let number = tagText(body, tag: "GuideNumber")
            let name = tagText(body, tag: "GuideName").ifEmpty("HDHomeRun \(number.ifEmpty(String(index + 1)))")
            let stream = tagText(body, tag: "URL").ifEmpty(number.isEmpty ? "" : base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/auto/v" + number)
            let icon = tagText(body, tag: "ImageURL").ifEmpty(tagText(body, tag: "GuideImageURL")).ifEmpty(tagText(body, tag: "LogoURL")).ifEmpty(tagText(body, tag: "IconURL"))
            guard !stream.isEmpty else { return nil }
            return makeChannel(name: name, number: number, url: absoluteStreamURL(stream, base: base), source: "HDHomeRun", category: "HDHomeRun", iconURL: absoluteLogoURL(icon, base: base), tvgID: number)
        }
    }

    private func urlBase(_ raw: String) -> String {
        guard let url = URL(string: raw), let scheme = url.scheme, let host = url.host else { return raw }
        let port = url.port.map { ":\($0)" } ?? ""
        return "\(scheme)://\(host)\(port)"
    }

    private func fetchDVRDevices(base: String) async -> [String] {
        guard let text = await fetchText("\(base)/devices", accept: "application/json,*/*", maxBytes: 512 * 1024), let data = text.data(using: .utf8) else { return [] }
        var names: [String] = []
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            for obj in arr { addDeviceName(from: obj, into: &names) }
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if let arr = obj["devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            if let arr = obj["Devices"] as? [[String: Any]] { for item in arr { addDeviceName(from: item, into: &names) } }
            addDeviceName(from: obj, into: &names)
        }
        var seen = Set<String>()
        return names.filter { value in
            let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty && clean.uppercased() != "ANY" else { return false }
            return seen.insert(clean).inserted
        }
    }

    private func addDeviceName(from obj: [String: Any], into names: inout [String]) {
        for key in ["name", "Name", "DeviceID", "DeviceId", "deviceID", "id", "ID"] {
            if let value = obj[key] as? String, !value.isEmpty { names.append(value) }
        }
    }

    private func parseDVRChannelsJSON(_ text: String, base: String, device: String) -> [LiveTVChannel]? {
        guard let data = text.data(using: .utf8) else { return nil }
        let raw: Any?
        if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            raw = arr
        } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            raw = obj["channels"] as? [[String: Any]] ?? obj["Channels"] as? [[String: Any]]
        } else { raw = nil }
        guard let arr = raw as? [[String: Any]] else { return nil }
        return arr.enumerated().compactMap { idx, obj in
            let number = stringValue(obj, keys: ["GuideNumber", "Number", "number", "channelNumber", "ChannelNumber"])
            let id = stringValue(obj, keys: ["id", "ID", "GuideNumber", "Number", "StationID", "stationID", "TmsId", "tmsId", "GuideID", "guideID"]).ifEmpty(number)
            let name = stringValue(obj, keys: ["GuideName", "Name", "name", "channel"]).ifEmpty("Channel \(number.ifEmpty(id.ifEmpty("\(idx+1)")))")
            let playbackKey = number.ifEmpty(id)
            guard !playbackKey.isEmpty else { return nil }
            let url = "\(base)/devices/\(urlEncode(device))/channels/\(urlEncode(playbackKey))/stream.mpg?format=ts&codec=copy"
            let rawIcon = stringValue(obj, keys: ["ImageURL", "Image", "imageUrl", "LogoURL", "logoUrl", "logo", "tvg-logo", "icon", "Icon", "stationLogo", "StationLogo", "Logo", "PreferredImage", "GracenoteLogo", "gracenoteLogo"])
            var icon = absoluteLogoURL(rawIcon, base: base)
            if icon.isEmpty && !id.isEmpty { icon = "\(base)/images/station/\(urlEncode(id))" }
            let category = inferCategory(name: name, explicit: "Channels DVR")
            return makeChannel(name: name, number: number, url: url, source: "Channels DVR", category: category, iconURL: icon, tvgID: id)
        }
    }

    private func loadDVRLineupGroups(base: String) async -> [String: Set<String>] {
        guard let text = await fetchText("\(base)/dvr/lineups", accept: "application/json,*/*", maxBytes: 2 * 1024 * 1024), let data = text.data(using: .utf8) else { return [:] }
        let root = try? JSONSerialization.jsonObject(with: data)
        var entries: [[String: Any]] = []
        if let arr = root as? [[String: Any]] { entries = arr }
        if let obj = root as? [String: Any] {
            entries = (obj["lineups"] as? [[String: Any]]) ?? (obj["Lineups"] as? [[String: Any]]) ?? (obj["items"] as? [[String: Any]]) ?? []
        }
        var result: [String: Set<String>] = [:]
        for obj in entries {
            let name = stringValue(obj, keys: ["name", "Name", "title", "Title", "group", "Group"]).ifEmpty("Channels DVR")
            var members = Set<String>()
            func add(_ any: Any?) {
                if let s = any as? String { members.insert(s.lowercased()) }
                if let n = any as? NSNumber { members.insert(n.stringValue.lowercased()) }
                if let arr = any as? [Any] { arr.forEach { add($0) } }
                if let dict = any as? [String: Any] {
                    for key in ["GuideNumber", "Number", "number", "GuideName", "Name", "name", "id", "ID"] { add(dict[key]) }
                }
            }
            for key in ["channels", "Channels", "members", "Members", "items", "Items"] { add(obj[key]) }
            if !members.isEmpty { result[name] = members }
        }
        return result
    }

    private func loadM3U(url: String, source: String) async -> (channels: [LiveTVChannel], message: String) {
        guard let text = await fetchText(url, accept: "audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", maxBytes: 18 * 1024 * 1024) else { return ([], "M3U failed") }
        let channels = parseM3U(text, source: source, baseURL: "")
        return (channels, channels.isEmpty ? "M3U returned no channels" : "M3U/XMLTV • \(channels.count) channel(s)")
    }

    private func parseM3U(_ text: String, source: String, baseURL: String) -> [LiveTVChannel] {
        var out: [LiveTVChannel] = []
        var meta = ""
        for raw in text.components(separatedBy: .newlines) {
            let line = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("#EXTINF") { meta = line; continue }
            if line.isEmpty || line.hasPrefix("#") { continue }
            guard !meta.isEmpty else { continue }
            let name = meta.components(separatedBy: ",").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Channel \(out.count + 1)"
            let tvgName = attr(meta, "tvg-name")
            let displayName = tvgName.ifEmpty(name)
            let group = attr(meta, "group-title")
            let number = attr(meta, "tvg-chno").ifEmpty(attr(meta, "channel-number")).ifEmpty(attr(meta, "ch-number"))
            let tvgId = attr(meta, "tvc-guide-stationid").ifEmpty(attr(meta, "tvg-id")).ifEmpty(attr(meta, "channel-id"))
            let icon = absoluteLogoURL(attr(meta, "tvg-logo").ifEmpty(attr(meta, "logo")).ifEmpty(attr(meta, "x-tvg-url")), base: baseURL)
            out.append(makeChannel(name: displayName, number: number, url: absoluteStreamURL(line, base: baseURL), source: source, category: inferCategory(name: displayName, explicit: group), iconURL: icon, tvgID: tvgId))
            meta = ""
        }
        return out
    }

    private func loadXtream(server: String, username: String, password: String) async -> (channels: [LiveTVChannel], message: String) {
        let base = normalizeServerBase(server, defaultPort: nil)
        let user = urlEncode(username)
        let pass = urlEncode(password)
        var categoryMap: [String: String] = [:]
        if let catsText = await fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_categories", accept: "application/json,*/*", maxBytes: 2 * 1024 * 1024),
           let data = catsText.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
            for obj in arr {
                let id = stringValue(obj, keys: ["category_id"])
                let name = stringValue(obj, keys: ["category_name"])
                if !id.isEmpty && !name.isEmpty { categoryMap[id] = name }
            }
        }
        guard let text = await fetchText("\(base)/player_api.php?username=\(user)&password=\(pass)&action=get_live_streams", accept: "application/json,*/*", maxBytes: 12 * 1024 * 1024), let data = text.data(using: .utf8), let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return ([], "Xtream failed or returned invalid JSON") }
        let channels = arr.compactMap { obj -> LiveTVChannel? in
            let id = stringValue(obj, keys: ["stream_id"])
            guard !id.isEmpty else { return nil }
            let ext = stringValue(obj, keys: ["container_extension"]).ifEmpty("m3u8")
            let name = stringValue(obj, keys: ["name"]).ifEmpty("Channel \(id)")
            let cat = stringValue(obj, keys: ["category_name"]).ifEmpty(categoryMap[stringValue(obj, keys: ["category_id"])] ?? "IPTV")
            let epg = stringValue(obj, keys: ["epg_channel_id", "epg_id"])
            let num = stringValue(obj, keys: ["num"])
            let icon = stringValue(obj, keys: ["stream_icon"])
            return makeChannel(name: name, number: num, url: "\(base)/live/\(user)/\(pass)/\(id).\(ext)", source: "Xtream/IPTV", category: inferCategory(name: name, explicit: cat), iconURL: icon, tvgID: epg)
        }
        return (channels, channels.isEmpty ? "Xtream returned no channels" : "Xtream/IPTV • \(channels.count) channel(s)")
    }

    private func makeChannel(name: String, number: String, url: String, source: String, category: String, iconURL: String, tvgID: String) -> LiveTVChannel {
        let cleanLogo = channelLogo(name: name)
        let idSeed = "\(source)|\(number)|\(name)|\(url)".unicodeScalars.reduce(0) { ($0 &* 31 &+ Int($1.value)) & 0x7fffffff }
        return LiveTVChannel(id: max(1, idSeed), logo: cleanLogo, number: number, name: name, category: category, now: name, next: "Guide data loading", description: source, accent: Self.accent(for: category), streamURL: url, iconURL: iconURL, tvgID: tvgID, source: source)
    }

    private func applyXMLTVIcons(_ xml: String, to channels: [LiveTVChannel], baseURL: String = "") -> [LiveTVChannel] {
        let icons = xmltvChannelIcons(xml)
        guard !icons.isEmpty else { return channels }
        return channels.map { channel in
            if !channel.iconURL.isEmpty { return channel }
            let keys = channelMatchingKeys(channel)
            guard let rawIcon = keys.compactMap({ icons[$0] }).first(where: { !$0.isEmpty }) else { return channel }
            let icon = absoluteLogoURL(rawIcon, base: baseURL)
            return LiveTVChannel(id: channel.id, logo: channel.logo, number: channel.number, name: channel.name, category: channel.category, now: channel.now, next: channel.next, description: channel.description, accent: channel.accent, streamURL: channel.streamURL, iconURL: icon, tvgID: channel.tvgID, source: channel.source)
        }
    }

    private func xmltvChannelIcons(_ xml: String) -> [String: String] {
        var out: [String: String] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            let icon = firstXMLIcon(in: body)
            guard !icon.isEmpty else { continue }
            var keys = Set<String>()
            for key in xmltvLookupKeys(id) { keys.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { out[key] = icon }
        }
        return out
    }


    private func firstXMLIcon(in body: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<icon[^>]*src=\"([^\"]+)\"[^>]*/?>", options: [.caseInsensitive]) else { return "" }
        let ns = body as NSString
        guard let match = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), match.numberOfRanges > 1 else { return "" }
        return ns.substring(with: match.range(at: 1)).xmlDecoded()
    }

    private func parseXMLTV(_ xml: String, channels: [LiveTVChannel]) -> [String: [LiveProgram]] {
        // Ported from Android LiveGuideProgramResolver: do not assume XMLTV
        // attribute order. Channels DVR/XMLTV providers can emit channel/start/stop
        // in different orders, and older tvOS builds missed those programmes.
        var programsByKey: [String: [LiveProgram]] = [:]
        let channelNames = channelLookupNames(xml)
        let programRegex = try? NSRegularExpression(pattern: #"<programme\s+([^>]*)>(.*?)</programme>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        let matches = programRegex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? []
        for match in matches.prefix(12000) {
            let attrs = ns.substring(with: match.range(at: 1))
            let body = ns.substring(with: match.range(at: 2))
            let channelID = xmlAttr(attrs, "channel")
            guard !channelID.isEmpty else { continue }
            let startRaw = xmlAttr(attrs, "start")
            let stopRaw = xmlAttr(attrs, "stop")
            let title = tagText(body, tag: "title").ifEmpty("No information")
            let desc = tagText(body, tag: "desc")
            let isLive = isProgramLive(startRaw, stopRaw)
            let minutes = durationMinutes(startRaw, stopRaw)
            let width = CGFloat(max(120, min(560, Int((Double(minutes) / 30.0) * 120.0))))
            let program = LiveProgram(title: title, width: width, isLive: isLive, description: desc, startText: guideTimeText(startRaw).ifEmpty(isLive ? "Now" : ""), endText: guideTimeText(stopRaw))
            var keys = Set<String>()
            for key in xmltvLookupKeys(channelID) { keys.insert(key) }
            for alias in channelNames[channelID] ?? [] {
                for key in xmltvLookupKeys(alias) { keys.insert(key) }
            }
            for key in keys where !key.isEmpty { programsByKey[key, default: []].append(program) }
        }
        var resolved: [String: [LiveProgram]] = [:]
        for channel in channels {
            let keys = channelMatchingKeys(channel)
            if let found = keys.compactMap({ programsByKey[$0] }).first(where: { !$0.isEmpty }) {
                resolved[channelKey(channel)] = Array(found.prefix(10))
            }
        }
        return resolved
    }


    private func isProgramLive(_ start: String, _ stop: String) -> Bool {
        guard let s = xmltvDate(start), let e = xmltvDate(stop) else { return false }
        let now = Date()
        return s <= now && now < e
    }

    private func guideTimeText(_ raw: String) -> String {
        guard let date = xmltvDate(raw) else { return "" }
        return date.formatted(date: .omitted, time: .shortened)
    }

    private func xmltvDate(_ raw: String) -> Date? {
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else { return nil }
        if let epoch = Double(cleaned) {
            let seconds = epoch > 100_000_000_000 ? epoch / 1000.0 : epoch
            return Date(timeIntervalSince1970: seconds)
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        for format in ["yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss Z", "yyyyMMddHHmmssZ", "yyyyMMddHHmmss", "yyyyMMddHHmm Z", "yyyyMMddHHmmZ"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: cleaned) { return date }
        }
        return nil
    }

    private func durationMinutes(_ start: String, _ stop: String) -> Int {
        guard let s = xmltvDate(start), let e = xmltvDate(stop), e > s else { return 30 }
        return max(15, min(240, Int(e.timeIntervalSince(s) / 60.0)))
    }

    private func xmlAttr(_ attrs: String, _ name: String) -> String {
        let escaped = NSRegularExpression.escapedPattern(for: name)
        guard let regex = try? NSRegularExpression(pattern: "(?:^|\\s)" + escaped + "=\\\"([^\\\"]*)\\\"", options: [.caseInsensitive]) else { return "" }
        let ns = attrs as NSString
        guard let m = regex.firstMatch(in: attrs, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func xmltvLookupKeys(_ raw: String) -> [String] {
        let value = raw.xmlDecoded().trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return [] }
        var keys = Set<String>()
        func add(_ candidate: String) {
            let clean = candidate.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !clean.isEmpty else { return }
            keys.insert(clean.lowercased())
            let normalized = normalizeGuideKey(clean)
            if !normalized.isEmpty { keys.insert(normalized) }
        }
        add(value)
        add(value.replacingOccurrences(of: ".", with: "-"))
        add(value.replacingOccurrences(of: "-", with: "."))
        add(value.replacingOccurrences(of: "_", with: "."))
        add(value.components(separatedBy: ".").first ?? value)
        add(value.components(separatedBy: "-").first ?? value)
        if let digitMatch = value.range(of: #"[0-9]{3,}"#, options: .regularExpression) {
            add(String(value[digitMatch]))
        }
        if let match = value.range(of: #"^([0-9]+(?:[.\-_][0-9]+)?)\s+(.+)$"#, options: .regularExpression) {
            let pair = String(value[match]).split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
            if let first = pair.first {
                add(String(first))
                add(String(first).replacingOccurrences(of: "-", with: "."))
                add(String(first).replacingOccurrences(of: ".", with: "-"))
            }
            if pair.count > 1 { add(String(pair[1])) }
        }
        return Array(keys)
    }

    private func normalizeGuideKey(_ value: String) -> String {
        var clean = value.lowercased()
        for token in ["fhd", "uhd", "4k", "hd"] { clean = clean.replacingOccurrences(of: token, with: "") }
        return clean.components(separatedBy: CharacterSet.alphanumerics.inverted).joined()
    }


    private func channelLookupNames(_ xml: String) -> [String: Set<String>] {
        var out: [String: Set<String>] = [:]
        let regex = try? NSRegularExpression(pattern: #"<channel\s+[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</channel>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
        let ns = xml as NSString
        for match in regex?.matches(in: xml, range: NSRange(location: 0, length: ns.length)) ?? [] {
            let id = ns.substring(with: match.range(at: 1)).xmlDecoded()
            let body = ns.substring(with: match.range(at: 2))
            var names = Set<String>()
            for key in xmltvLookupKeys(id) { names.insert(key) }
            let nameRegex = try? NSRegularExpression(pattern: #"<display-name[^>]*>(.*?)</display-name>"#, options: [.caseInsensitive, .dotMatchesLineSeparators])
            for m in nameRegex?.matches(in: body, range: NSRange(location: 0, length: (body as NSString).length)) ?? [] {
                let display = (body as NSString).substring(with: m.range(at: 1)).xmlDecoded()
                for key in xmltvLookupKeys(display) { names.insert(key) }
                let parts = display.split(maxSplits: 1, whereSeparator: { $0.isWhitespace })
                if let first = parts.first { for key in xmltvLookupKeys(String(first)) { names.insert(key) } }
                if parts.count > 1 { for key in xmltvLookupKeys(String(parts[1])) { names.insert(key) } }
            }
            out[id] = names
        }
        return out
    }


    func programs(for channel: LiveTVChannel) -> [LiveProgram] {
        let key = channelKey(channel)
        if let direct = guidePrograms[key], !direct.isEmpty { return direct }
        return [
            LiveProgram(title: channel.now, width: 240, isLive: true, description: channel.description),
            LiveProgram(title: channel.next, width: 360, isLive: false),
            LiveProgram(title: channel.category == "Sports" ? "Live Sports" : channel.now, width: 300, isLive: false),
            LiveProgram(title: channel.category == "Movies" ? "Feature Presentation" : channel.next, width: 330, isLive: false)
        ]
    }

    private func channelMatchingKeys(_ channel: LiveTVChannel) -> [String] {
        var keys = Set<String>()
        for raw in [channel.tvgID, channel.number, channel.name, channel.logo, "\(channel.number) \(channel.name)"] {
            for key in xmltvLookupKeys(raw) { keys.insert(key) }
        }
        return Array(keys)
    }


    private func channelKey(_ channel: LiveTVChannel) -> String { "\(channel.source)|\(channel.number)|\(channel.name)".lowercased() }

    private func dedupe(_ channels: [LiveTVChannel]) -> [LiveTVChannel] {
        var seen = Set<String>()
        var out: [LiveTVChannel] = []
        for channel in channels {
            let key = !channel.number.isEmpty ? "num:\(channel.number)" : (!channel.streamURL.isEmpty ? "url:\(channel.streamURL)" : "name:\(channel.name.lowercased())")
            if seen.insert(key).inserted { out.append(channel) }
        }
        return out
    }

    private func fetchText(_ urlString: String, accept: String = "*/*", maxBytes: Int = 4 * 1024 * 1024) async -> String? {
        guard let url = URL(string: urlString) else { return nil }
        var request = URLRequest(url: url, timeoutInterval: 12)
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("DebridChannels-tvOS/177", forHTTPHeaderField: "User-Agent")
        do {
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) { return nil }
            return String(data: Data(data.prefix(maxBytes)), encoding: .utf8)
        } catch { return nil }
    }

    private func attr(_ meta: String, _ key: String) -> String {
        let pattern = "(?:^|\\s)" + NSRegularExpression.escapedPattern(for: key) + "=\"([^\"]*)\""
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { return "" }
        let ns = meta as NSString
        guard let m = regex.firstMatch(in: meta, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func stringValue(_ obj: [String: Any], keys: [String]) -> String {
        for key in keys {
            if let s = obj[key] as? String, !s.isEmpty { return s }
            if let n = obj[key] as? NSNumber { return n.stringValue }
        }
        return ""
    }

    private func tagText(_ body: String, tag: String) -> String {
        guard let regex = try? NSRegularExpression(pattern: "<\(tag)[^>]*>(.*?)</\(tag)>", options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return "" }
        let ns = body as NSString
        guard let m = regex.firstMatch(in: body, range: NSRange(location: 0, length: ns.length)), m.numberOfRanges > 1 else { return "" }
        return ns.substring(with: m.range(at: 1)).xmlDecoded()
    }

    private func channelLogo(name: String) -> String {
        let words = name.components(separatedBy: CharacterSet.alphanumerics.inverted).filter { !$0.isEmpty }
        if words.count >= 2 { return words.prefix(2).compactMap { $0.first.map(String.init) }.joined().uppercased() }
        return String(name.prefix(8)).uppercased()
    }

    private func inferCategory(name: String, explicit: String) -> String {
        let cleaned = explicit.split(separator: ";").first.map(String.init) ?? explicit
        if !cleaned.isEmpty && cleaned.lowercased() != "channels dvr" && cleaned.lowercased() != "iptv" { return normalizeCategory(cleaned, fallback: cleaned) }
        return normalizeCategory("", fallback: name)
    }

    private func normalizeCategory(_ raw: String, fallback: String) -> String {
        let lower = (raw + " " + fallback).lowercased()
        if lower.contains("sport") || lower.contains("espn") { return "Sports" }
        if lower.contains("news") || lower.contains("cnn") || lower.contains("msnbc") { return "News" }
        if lower.contains("kid") || lower.contains("cartoon") || lower.contains("disney") || lower.contains("nick") { return "Kids" }
        if lower.contains("movie") || lower.contains("hbo") || lower.contains("cinema") || lower.contains("starz") { return "Movies" }
        if lower.contains("favorite") { return "Favorites" }
        if lower.contains("hd") { return "HD" }
        if lower.contains("drama") { return "Drama" }
        return raw.isEmpty ? "All" : raw
    }

    private func absoluteLogoURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func absoluteStreamURL(_ raw: String, base: String) -> String {
        let clean = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return "" }
        if clean.lowercased().hasPrefix("http") { return clean }
        if clean.hasPrefix("/") { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + clean }
        if !base.isEmpty { return base.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + clean }
        return clean
    }

    private func urlEncode(_ value: String) -> String { value.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? value }
    private func channelSortKey(_ value: String) -> Double { Double(value.replacingOccurrences(of: ".", with: ".").components(separatedBy: CharacterSet(charactersIn: "0123456789.").inverted).joined()) ?? Double.greatestFiniteMagnitude }
}

private extension String {
    func ifEmpty(_ replacement: String) -> String { isEmpty ? replacement : self }
    func xmlDecoded() -> String {
        replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
    }
}

private enum LiveTVTheme {
    static let glassAccent = Color(red: 0.06, green: 0.075, blue: 0.09)
    static let glassPanel = Color.white.opacity(0.085)
    static let glassPanelFocused = Color.white.opacity(0.145)
    static let glassStroke = Color.white.opacity(0.16)
    static let liveProgram = Color.white.opacity(0.78)
    static let liveProgramText = Color.black.opacity(0.88)
}

struct LiveTVScreen: View {
    @EnvironmentObject var store: CatalogStore
    @StateObject private var liveModel = LiveTVSourceModel()
    private let baseCategories = ["All", "HD", "Favorites", "Movies", "Sports", "Drama", "News", "Kids"]

    @State private var selectedCategory: String = "All"
    @State private var selectedChannelID: Int = 6003
    @State private var showGuide: Bool = false
    @FocusState private var categoryFocus: String?
    @FocusState private var tileFocus: Int?
    @FocusState private var guideFocus: Int?
    @State private var lastDpadMoveAt: Date = .distantPast
    @State private var lastSelectAt: Date = .distantPast

    private var categories: [String] {
        var set = baseCategories
        for cat in liveModel.channels.map(\.category) where !cat.isEmpty && !set.contains(cat) { set.append(cat) }
        return set
    }

    private var visibleChannels: [LiveTVChannel] {
        if selectedCategory == "All" { return liveModel.channels }
        if selectedCategory == "HD" { return liveModel.channels.filter { $0.category == "HD" || Int($0.number) ?? 0 >= 6000 || $0.name.localizedCaseInsensitiveContains("HD") } }
        return liveModel.channels.filter { $0.category == selectedCategory }
    }

    private var selectedChannel: LiveTVChannel {
        liveModel.channels.first(where: { $0.id == selectedChannelID }) ?? liveModel.channels.first ?? LiveTVScreen.sampleChannels[0]
    }

    private var isFocusedTileLastBoxInRow: Bool {
        guard let focused = tileFocus,
              let index = visibleChannels.firstIndex(where: { $0.id == focused }) else { return false }
        return ((index + 1) % 4 == 0) || index == visibleChannels.count - 1
    }

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .topLeading) {
                liveBackground(channel: selectedChannel)

                VStack(alignment: .leading, spacing: 22) {
                    topCategoryRail
                        .padding(.top, 128)
                        .padding(.horizontal, 96)

                    if showGuide {
                        guideView(size: geo.size)
                            .transition(.asymmetric(insertion: .move(edge: .trailing).combined(with: .opacity), removal: .opacity))
                            .padding(.horizontal, 76)
                    } else {
                        liveGrid(size: geo.size)
                            .padding(.horizontal, 92)
                    }
                }

                VStack(alignment: .trailing, spacing: 10) {
                    if liveModel.isLoading {
                        ProgressView().tint(.white)
                    }
                    Text(liveModel.status)
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white.opacity(0.78))
                        .multilineTextAlignment(.trailing)
                        .frame(width: 520, alignment: .trailing)
                }
                .position(x: geo.size.width - 340, y: 92)

                if !showGuide {
                    guideHint
                        .position(x: geo.size.width - 210, y: 132)
                }
            }
            .frame(width: geo.size.width, height: geo.size.height)
            .focusSection()
            .onAppear {
                liveModel.loadCachedOrDemo()
                categoryFocus = selectedCategory
                tileFocus = selectedChannelID
                Task { await liveModel.refreshFromConfiguredSources(); if let first = visibleChannels.first { selectedChannelID = first.id; tileFocus = first.id } }
            }
            .onMoveCommand { direction in
                routeLiveSpecialMove(direction)
            }
        }
        .background(Color.black.ignoresSafeArea())
    }


    private func acceptSingleDpadStep() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastDpadMoveAt) > 0.32 else { return false }
        lastDpadMoveAt = now
        return true
    }

    private func acceptSingleSelect() -> Bool {
        let now = Date()
        guard now.timeIntervalSince(lastSelectAt) > 0.30 else { return false }
        lastSelectAt = now
        return true
    }

    private func routeLiveSpecialMove(_ direction: MoveCommandDirection) {
        // v179: normal grid/guide DPAD movement is owned by tvOS native focus.
        // We only intercept the two app-specific transitions. This avoids the old
        // double-step bug where SwiftUI focus moved once and our manual router moved
        // the selection a second time on the same remote click.
        if showGuide {
            guard direction == .left, acceptSingleDpadStep() else { return }
            withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) {
                showGuide = false
                tileFocus = selectedChannelID
            }
            return
        }

        guard direction == .right,
              isFocusedTileLastBoxInRow,
              acceptSingleDpadStep()
        else { return }

        withAnimation(.spring(response: 0.36, dampingFraction: 0.86)) {
            showGuide = true
            guideFocus = selectedChannelID
            tileFocus = selectedChannelID
        }
    }

    private func moveGuideFocus(_ delta: Int) {
        guard let current = guideFocus ?? tileFocus ?? visibleChannels.first?.id, let index = visibleChannels.firstIndex(where: { $0.id == current }) else { return }
        let target = min(max(index + delta, 0), visibleChannels.count - 1)
        selectedChannelID = visibleChannels[target].id
        guideFocus = selectedChannelID
    }

    private func liveBackground(channel: LiveTVChannel) -> some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.035, green: 0.045, blue: 0.055), Color.black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            RadialGradient(colors: [channel.accent.opacity(0.45), .clear], center: .topTrailing, startRadius: 80, endRadius: 920)
                .ignoresSafeArea()

            Rectangle()
                .fill(Color.black.opacity(0.35))
                .ignoresSafeArea()
        }
    }

    private var topCategoryRail: some View {
        HStack(spacing: 34) {
            ForEach(categories, id: \.self) { category in
                Button {
                    selectedCategory = category
                    if let first = visibleChannels.first { selectedChannelID = first.id; tileFocus = first.id }
                    tileFocus = selectedChannelID
                } label: {
                    Text(category)
                        .font(.system(size: 28, weight: category == selectedCategory ? .heavy : .semibold))
                        .foregroundStyle(category == selectedCategory ? .white : .white.opacity(0.54))
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(categoryFocus == category ? Color.white.opacity(0.12) : Color.clear)
                        )
                        .overlay(alignment: .bottom) {
                            if category == selectedCategory {
                                Capsule().fill(Color.cyan.opacity(0.9)).frame(height: 5).offset(y: 8)
                            }
                        }
                }
                .buttonStyle(.plain)
                .focused($categoryFocus, equals: category)
            }
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 10)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.34)))
    }

    private func liveGrid(size: CGSize) -> some View {
        ScrollViewReader { proxy in
            ScrollView(.vertical, showsIndicators: false) {
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 36), count: 4), spacing: 34) {
                    ForEach(visibleChannels) { channel in
                        liveTile(channel: channel)
                            .id(channel.id)
                    }
                }
                .padding(.top, 8)
                .padding(.bottom, 110)
            }
            .frame(maxHeight: size.height - 212)
            .onChange(of: tileFocus) { value in
                if let value {
                    withAnimation(.easeOut(duration: 0.14)) {
                        proxy.scrollTo(value, anchor: .center)
                    }
                }
            }
        }
    }

    private func liveTile(channel: LiveTVChannel) -> some View {
        let isFocused = tileFocus == channel.id
        return Button {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            play(channel: channel)
        } label: {
            LiveTVGridTileContent(channel: channel, isFocused: isFocused)
        }
        .buttonStyle(.plain)
        .contentShape(RoundedRectangle(cornerRadius: 4))
        .focusable(true)
        .focused($tileFocus, equals: channel.id)
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            play(channel: channel)
        }
        .onChange(of: tileFocus) { value in
            if let value { selectedChannelID = value }
        }
    }

    private var guideHint: some View {
        HStack(spacing: 10) {
            Image(systemName: "arrow.right.circle.fill")
            Text("Press RIGHT for full guide")
        }
        .font(.system(size: 22, weight: .bold))
        .foregroundStyle(.white.opacity(0.84))
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .background(Capsule().fill(Color.black.opacity(0.56)).overlay(Capsule().stroke(Color.white.opacity(0.14), lineWidth: 1)))
    }

    private func guideView(size: CGSize) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            guidePreview(channel: selectedChannel)
            ScrollViewReader { proxy in
                ScrollView(.vertical, showsIndicators: true) {
                    LazyVStack(spacing: 12) {
                        ForEach(visibleChannels) { channel in
                            guideRow(channel: channel, rowWidth: size.width - 180)
                                .id(channel.id)
                        }
                    }
                    .padding(.bottom, 120)
                }
                .frame(maxWidth: .infinity, maxHeight: size.height - 390, alignment: .topLeading)
                .onChange(of: guideFocus) { value in
                    if let value {
                        withAnimation(.easeOut(duration: 0.18)) {
                            proxy.scrollTo(value, anchor: .center)
                        }
                    }
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: size.height - 150, alignment: .topLeading)
    }

    private var guideSideRail: some View {
        VStack(spacing: 24) {
            VStack(spacing: 26) {
                Image(systemName: "heart")
                Image(systemName: "list.bullet")
                Image(systemName: "rectangle.grid.2x2")
                Image(systemName: "circle")
                Image(systemName: "book")
                Image(systemName: "magnifyingglass")
            }
            .font(.system(size: 30, weight: .semibold))
            .foregroundStyle(.white.opacity(0.56))
            .frame(maxWidth: .infinity)
            .padding(.top, 26)
            VStack(alignment: .trailing, spacing: 22) {
                ForEach(categories, id: \.self) { category in
                    Text(category == "All" ? "All Channels" : category == "HD" ? "HD Channels" : category)
                        .font(.system(size: 26, weight: category == selectedCategory ? .bold : .medium))
                        .foregroundStyle(category == selectedCategory ? .white : .white.opacity(0.56))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                        .onTapGesture { selectedCategory = category }
                }
            }
            Spacer()
        }
        .padding(.top, 68)
        .padding(.horizontal, 14)
        .background(Color.black.opacity(0.18))
    }

    private func guidePreview(channel: LiveTVChannel) -> some View {
        HStack(alignment: .top, spacing: 26) {
            ZStack {
                RoundedRectangle(cornerRadius: 4).fill(Color.white.opacity(0.92))
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase { case .success(let image): image.resizable().scaledToFit().padding(22); default: Text(channel.logo).font(.system(size: 52, weight: .black, design: .rounded)).foregroundStyle(channel.accent).padding(22) }
                    }
                } else {
                    Text(channel.logo).font(.system(size: 52, weight: .black, design: .rounded)).minimumScaleFactor(0.5).foregroundStyle(channel.accent).padding(22)
                }
            }
            .frame(width: 390, height: 178)
            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.white.opacity(0.8), lineWidth: 2))
            VStack(alignment: .leading, spacing: 10) {
                Text(channel.now).font(.system(size: 42, weight: .bold))
                Text(channel.next).font(.system(size: 26, weight: .semibold)).foregroundStyle(.white.opacity(0.58))
                HStack(spacing: 10) { guideBadge("HD"); guideBadge("CC"); guideBadge(channel.category == "Kids" ? "TV-Y7" : "TV-14") }
                Text(channel.description).font(.system(size: 25, weight: .medium)).foregroundStyle(.white.opacity(0.72)).lineLimit(2)
            }
        }
        .padding(.top, 12)
        .padding(.trailing, 40)
    }

    private func guideBadge(_ text: String) -> some View {
        Text(text).font(.system(size: 18, weight: .heavy)).foregroundStyle(.white).padding(.horizontal, 14).padding(.vertical, 8).background(RoundedRectangle(cornerRadius: 2).fill(Color.black.opacity(0.58)).overlay(RoundedRectangle(cornerRadius: 2).stroke(Color.white.opacity(0.16), lineWidth: 1)))
    }

    private var guideTimeSlots: [String] {
        let calendar = Calendar.current
        let now = Date()
        let minute = calendar.component(.minute, from: now)
        let flooredMinute = minute < 30 ? 0 : 30
        let base = calendar.date(bySettingHour: calendar.component(.hour, from: now), minute: flooredMinute, second: 0, of: now) ?? now
        return (0..<5).compactMap { offset in
            calendar.date(byAdding: .minute, value: offset * 30, to: base)?.formatted(date: .omitted, time: .shortened)
        }
    }

    private var timeHeader: some View {
        HStack(spacing: 10) {
            Text("").frame(width: 230)
            ForEach(guideTimeSlots, id: \.self) { time in
                Text(time).font(.system(size: 24, weight: .bold)).foregroundStyle(.white.opacity(0.48)).frame(width: 260, alignment: .leading)
            }
        }
    }

    private func guideRow(channel: LiveTVChannel, rowWidth: CGFloat) -> some View {
        let isFocused = guideFocus == channel.id
        let channelColumnWidth: CGFloat = 230
        let programCount = 4
        let programWidth = max(190, (rowWidth - channelColumnWidth - 54) / CGFloat(programCount))
        let programs = Array(liveModel.programs(for: channel).prefix(programCount))

        return HStack(spacing: 10) {
            HStack(spacing: 12) {
                if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
                    AsyncImage(url: url) { phase in
                        switch phase {
                        case .success(let image): image.resizable().scaledToFit()
                        default: Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1)
                        }
                    }
                    .frame(width: 86, height: 46)
                } else {
                    Text(channel.logo).font(.system(size: 22, weight: .black)).lineLimit(1).frame(width: 86, alignment: .leading)
                }
                Text(channel.number).font(.system(size: 25, weight: .bold)).foregroundStyle(.white.opacity(0.78))
            }
            .padding(.horizontal, 14)
            .frame(width: channelColumnWidth, height: 74, alignment: .leading)
            .background((isFocused ? LiveTVTheme.glassPanelFocused : LiveTVTheme.glassPanel))
            .clipShape(RoundedRectangle(cornerRadius: 4))

            ForEach(programs) { program in
                GuideProgramCell(program: program, width: programWidth)
            }

            if programs.count < programCount {
                ForEach(0..<(programCount - programs.count), id: \.self) { _ in
                    GuideEmptyProgramCell(width: programWidth)
                }
            }
        }
        .frame(width: rowWidth, alignment: .leading)
        .clipped()
        .contentShape(Rectangle())
        .focusable(true)
        .focused($guideFocus, equals: channel.id)
        .onTapGesture {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onPlayPauseCommand {
            guard acceptSingleSelect() else { return }
            selectedChannelID = channel.id
            guideFocus = channel.id
            play(channel: channel)
        }
        .onChange(of: guideFocus) { value in if let value { selectedChannelID = value } }
    }


private struct GuideProgramCell: View {
    let program: LiveProgram
    let width: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(program.title)
                .font(.system(size: 22, weight: program.isLive ? .bold : .semibold))
                .lineLimit(1)
                .foregroundStyle(program.isLive ? .black : .white.opacity(0.84))
            if !program.startText.isEmpty {
                Text(program.startText)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(program.isLive ? .black.opacity(0.62) : .white.opacity(0.42))
            }
        }
        .frame(width: width, height: 74, alignment: .leading)
        .padding(.horizontal, 14)
        .background(program.isLive ? Color.white.opacity(0.82) : LiveTVTheme.glassPanel)
        .clipShape(RoundedRectangle(cornerRadius: 4))
        .overlay(alignment: .bottomLeading) {
            if program.isLive { Rectangle().fill(Color.white.opacity(0.9)).frame(width: max(44, width * 0.32), height: 4) }
        }
    }
}

private struct GuideEmptyProgramCell: View {
    let width: CGFloat

    var body: some View {
        Text("No guide data")
            .font(.system(size: 20, weight: .semibold))
            .foregroundStyle(.white.opacity(0.36))
            .frame(width: width, height: 74, alignment: .leading)
            .padding(.horizontal, 14)
            .background(LiveTVTheme.glassPanel)
            .clipShape(RoundedRectangle(cornerRadius: 4))
    }
}

    private func play(channel: LiveTVChannel) {
        guard let url = URL(string: channel.streamURL), !channel.streamURL.isEmpty else { liveModel.status = "No playable URL for \(channel.name). Configure Channels DVR/M3U/Xtream source."; return }
        let item = MediaItem(id: "live-\(channel.id)", title: channel.name, year: "Live", type: "live", catalog: channel.source, description: channel.description, genres: [channel.category, channel.source], rating: "", posterURL: channel.iconURL, landscapeURL: nil, logoURL: nil, previewURL: nil)
        store.startPlayback(item: item, url: url, alternates: [], subtitles: [], label: "Live TV direct stream: \(channel.name) • \(channel.source) • \(channel.number) • TS/HLS cache disabled")
    }

    static let sampleChannels: [LiveTVChannel] = [
        LiveTVChannel(id: 6003, logo: "CBS", number: "6003", name: "The Talk", category: "Drama", now: "The Young and the Restless", next: "The Bold and the Beautiful", description: "A live daytime lineup with drama, interviews, and entertainment news.", accent: .gray),
        LiveTVChannel(id: 6011, logo: "COMEDY", number: "6011", name: "South Park", category: "Favorites", now: "South Park", next: "Catfish: The TV Show", description: "South Park goes gluten free in this animated comedy block.", accent: .indigo),
        LiveTVChannel(id: 6013, logo: "MTV", number: "6013", name: "Catfish", category: "Favorites", now: "Catfish: The TV Show", next: "Catfish: The TV Show", description: "Online relationships, mysteries, and reveals.", accent: .gray),
        LiveTVChannel(id: 6017, logo: "CMT", number: "6017", name: "Mike & Molly", category: "Comedy", now: "Mike & Molly", next: "Mom", description: "Classic sitcom blocks and comfort comedy favorites.", accent: .mint),
        LiveTVChannel(id: 6019, logo: "BET", number: "6019", name: "black-ish", category: "Drama", now: "black-ish", next: "Tyler Perry's Meet the Browns", description: "Comedy, family stories, and drama favorites.", accent: .gray),
        LiveTVChannel(id: 6021, logo: "TV LAND", number: "6021", name: "Bonanza", category: "Drama", now: "Bonanza", next: "Gunsmoke", description: "Classic TV westerns and vintage drama blocks.", accent: .green),
        LiveTVChannel(id: 6022, logo: "PARAMOUNT", number: "6022", name: "Mom", category: "HD", now: "Mom", next: "Two and a Half Men", description: "HD sitcom favorites with back-to-back episodes.", accent: .blue),
        LiveTVChannel(id: 6031, logo: "ESPN", number: "6031", name: "SportsCenter", category: "Sports", now: "SportsCenter", next: "NFL Live", description: "Live sports news, highlights, and analysis.", accent: .red),
        LiveTVChannel(id: 6044, logo: "CNN", number: "6044", name: "CNN Newsroom", category: "News", now: "CNN Newsroom", next: "The Lead", description: "Breaking news and live national coverage.", accent: .red),
        LiveTVChannel(id: 6052, logo: "NICK", number: "6052", name: "SpongeBob", category: "Kids", now: "SpongeBob SquarePants", next: "The Loud House", description: "Animated favorites for kids and family viewing.", accent: .orange),
        LiveTVChannel(id: 6060, logo: "HBO", number: "6060", name: "Feature Movie", category: "Movies", now: "Feature Presentation", next: "Behind the Scenes", description: "Premium movie presentation with cinematic artwork.", accent: .cyan),
        LiveTVChannel(id: 6070, logo: "WEATHER", number: "6070", name: "Weather Headlines", category: "News", now: "Weather Headlines", next: "Local Forecast", description: "Regional weather headlines, storms, and local forecast updates.", accent: .teal)
    ]
}

private struct LiveTVGridTileContent: View {
    let channel: LiveTVChannel
    let isFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            LiveTVGridTileArtwork(channel: channel)
                .aspectRatio(16/9, contentMode: .fit)

            LiveTVGridTileFooter(channel: channel, isFocused: isFocused)
        }
        .background(Color.black.opacity(0.34))
        .clipShape(RoundedRectangle(cornerRadius: 4))
        .overlay(tileBorder)
        .scaleEffect(isFocused ? 1.025 : 1.0)
        .shadow(color: isFocused ? Color.cyan.opacity(0.55) : .clear, radius: 18)
    }

    private var tileBorder: some View {
        RoundedRectangle(cornerRadius: 4)
            .stroke(isFocused ? Color.cyan.opacity(0.95) : Color.white.opacity(0.06), lineWidth: isFocused ? 4 : 1)
    }
}

private struct LiveTVGridTileArtwork: View {
    let channel: LiveTVChannel

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            tileBackground
            tileLogo
            nowBadge
        }
    }

    private var tileBackground: some View {
        RoundedRectangle(cornerRadius: 4)
            .fill(
                LinearGradient(
                    colors: [channel.accent.opacity(0.95), channel.accent.opacity(0.34), Color.white.opacity(0.88)],
                    startPoint: .bottomLeading,
                    endPoint: .topTrailing
                )
            )
    }

    @ViewBuilder
    private var tileLogo: some View {
        if let url = URL(string: channel.iconURL), !channel.iconURL.isEmpty {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let image):
                    image.resizable().scaledToFit().padding(26)
                default:
                    fallbackLogo
                }
            }
        } else {
            fallbackLogo
        }
    }

    private var fallbackLogo: some View {
        Text(channel.logo)
            .font(.system(size: channel.logo.count > 6 ? 42 : 54, weight: .black, design: .rounded))
            .foregroundStyle(Color.white)
            .minimumScaleFactor(0.45)
            .lineLimit(2)
            .shadow(color: .black.opacity(0.42), radius: 7)
            .padding(22)
    }

    private var nowBadge: some View {
        Text(channel.now)
            .font(.system(size: 28, weight: .heavy))
            .foregroundStyle(.white)
            .shadow(radius: 4)
            .padding(18)
            .opacity(channel.id % 2 == 0 ? 0.0 : 1.0)
    }
}

private struct LiveTVGridTileFooter: View {
    let channel: LiveTVChannel
    let isFocused: Bool

    var body: some View {
        HStack(spacing: 12) {
            Text(channel.logo)
                .font(.system(size: 18, weight: .black))
                .frame(width: 70, alignment: .leading)
            Text(channel.name)
                .font(.system(size: 23, weight: .semibold))
                .lineLimit(1)
            Spacer()
        }
        .foregroundStyle(.white.opacity(0.92))
        .padding(.horizontal, 18)
        .frame(height: 58)
        .background(isFocused ? LiveTVTheme.glassPanelFocused : LiveTVTheme.glassPanel)
    }
}

