# Debrid Channels vBRDC175 — Live TV Black Glass Rebuild

Marketing version: 1.0.878
Build: 878
Release ID: vBRDC175
Donor/source of truth: packaged vBRDC174 only.

## Live TV Grid
- Rebuilt the visible Live TV deck shell from scratch while preserving the fixed 4x3 paging/navigation logic.
- Preserved the information payload inside every card, the user-selected focus ring, and the bottom-right page indicator exactly.
- Replaced the v171 floating depth plate/accent halo with a cleaner single-plane black-glass broadcast card.
- Preserved the v170 velocity-friendly focus spring, with a restrained single elevation shadow and perspective transform.
- Removed the ambient deck/stage wash so Dynamic Wallpaper/background reads through the full Live TV canvas.
- Removed the broad header halo and Signal TV outer glow; reduced animated header identity to 88% of its prior footprint.
- Restyled the grid-only left tools rail to the same restrained black-glass system without changing its logic.

## Full Guide
- Guide remains dynamic-wallpaper-free.
- Preserved the v170/v174 live preview function byte-for-byte, including full-frame Aspect Fit playback.
- Rebuilt the Guide surface as black glass with a new channel/program information treatment.
- Restyled category chip/drop-down, channel column, program cells, empty cells and hero information panel.
- Exit/Back hint remains outside the live preview and never overlays broadcast pixels.

## Top Menu Live TV hitch
- Added a targeted, non-CatalogStore notification when a top-menu traversal begins while Live TV is selected.
- Live TV immediately cancels only speculative focused-card preview/prefetch work before the top-menu focus walk.
- The notification fires once per top-menu visit, not once per tab crossing.
- Dynamic Wallpaper and decoded grid pixels stay mounted; catalogs are untouched.

## Regression locks
- LiveTVGrid page badge section is byte-identical to vBRDC174.
- Guide live preview function is byte-identical to vBRDC174.
- LiveTVGridTileFooter (inside-card information) is byte-identical to vBRDC174.
- CatalogStore.swift is byte-identical to vBRDC174.
- PlaybackKitKSPlayerSurface.swift (including vBRDC174 Alternate Audio compile correction) is byte-identical to vBRDC174.
- AlternateAudioDiscoveryClient.swift is byte-identical to vBRDC174.
