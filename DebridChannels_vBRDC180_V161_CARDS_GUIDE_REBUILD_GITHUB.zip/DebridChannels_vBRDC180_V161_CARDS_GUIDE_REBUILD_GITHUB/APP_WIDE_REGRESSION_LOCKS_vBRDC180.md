# vBRDC180 Regression Locks

1. Base is packaged vBRDC179. v161 is a visual donor for Live TV card appearance only.
2. Do not restore v161 store, playback, guide, catalog, alternate-audio, or runtime logic.
3. Live TV cards preserve the v161 visual shell while retaining v179 station-logo cache/reliability internals.
4. Keep v179 All Channels / selected-station / Up Next header additions.
5. Keep fixed 4x3 Live TV paging, smooth focus animation, and bottom-right PAGE indicator.
6. Guide live preview remains Aspect Fit, audio enabled, and untouched in its playback path.
7. Guide Exit / Back Menu hint remains beside the preview, never inside it.
8. Guide colors must come from the selected Live TV theme. Pure Black must not receive a forced blue surface.
9. Dynamic Wallpaper remains Live-TV-grid-only; do not mount it in full Guide.
10. CatalogStore.swift, PlaybackKitKSPlayerSurface.swift, AlternateAudioDiscoveryClient.swift, and KSPNUVIO remain unchanged from v179.
