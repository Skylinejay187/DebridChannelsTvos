# Debrid Channels vBRDC174 — Compile Fix: Concrete FFmpeg Audio Track

Built only from packaged vBRDC173.

## GitHub Actions failure fixed
Xcode 16.4 rejected passing `any MediaPlayerTrack` to KSPlayer's
`select(track: some MediaPlayerTrack)` in the local Alternate Audio controller.

The pinned Tapframe KSPNUVIO KSMEPlayer track list is backed by the public
`FFmpegAssetTrack` class. vBRDC174 casts the selected existential track back to
`FFmpegAssetTrack` before calling KSMEPlayer's normal `select(track:)` path.

No Live TV, Guide, Favorites, Sports, VOD cache, UI, or other behavior was
changed in this compile-only build.

Version: vBRDC174 / 1.0.877 / 877
